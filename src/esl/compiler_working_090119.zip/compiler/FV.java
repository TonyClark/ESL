package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
import static esl.compiler.Types.*;
// import static esl.Lists.*;
import java.util.function.Supplier;
public class FV {
  public static ESLVal getSelf() { return $null; }
  private static ESLVal remStr = new ESLVal(new Function(new ESLVal("remStr"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal s = $args[0];
  ESLVal ss = $args[1];
  return remove.apply(s,ss);
    }
  });
  private static ESLVal remStrs = new ESLVal(new Function(new ESLVal("remStrs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal ss1 = $args[0];
  ESLVal ss2 = $args[1];
  return removeAll.apply(ss1,ss2);
    }
  });
  public static ESLVal bindingFV = new ESLVal(new Function(new ESLVal("bindingFV"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal b = $args[0];
  {ESLVal _v1 = b;
        
        switch(_v1.termName) {
        case "TypeBind": {ESLVal $33 = _v1.termRef(0);
          ESLVal $32 = _v1.termRef(1);
          ESLVal $31 = _v1.termRef(2);
          ESLVal $30 = _v1.termRef(3);
          
          {ESLVal v0 = $33;
          
          {ESLVal v1 = $32;
          
          {ESLVal v2 = $31;
          
          {ESLVal v3 = $30;
          
          return ESLVal.list();
        }
        }
        }
        }
        }
      case "CnstrBind": {ESLVal $29 = _v1.termRef(0);
          ESLVal $28 = _v1.termRef(1);
          ESLVal $27 = _v1.termRef(2);
          ESLVal $26 = _v1.termRef(3);
          
          {ESLVal v0 = $29;
          
          {ESLVal v1 = $28;
          
          {ESLVal v2 = $27;
          
          {ESLVal v3 = $26;
          
          return ESLVal.list();
        }
        }
        }
        }
        }
      case "FunBind": {ESLVal $25 = _v1.termRef(0);
          ESLVal $24 = _v1.termRef(1);
          ESLVal $23 = _v1.termRef(2);
          ESLVal $22 = _v1.termRef(3);
          ESLVal $21 = _v1.termRef(4);
          ESLVal $20 = _v1.termRef(5);
          ESLVal $19 = _v1.termRef(6);
          
          {ESLVal v0 = $25;
          
          {ESLVal v1 = $24;
          
          {ESLVal v2 = $23;
          
          {ESLVal v3 = $22;
          
          {ESLVal v4 = $21;
          
          {ESLVal body = $20;
          
          {ESLVal guard = $19;
          
          return remStrs.apply(new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal p = $l0.head();
                $l0 = $l0.tail();
                ESLVal $l1 = patternNames.apply(p);
          while(!$l1.isNil()) {
            ESLVal n = $l1.head();
            $l1 = $l1.tail();
            $v.add(n);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v2),freeVars.apply(body));
        }
        }
        }
        }
        }
        }
        }
        }
      case "FunBinds": {ESLVal $11 = _v1.termRef(0);
          ESLVal $10 = _v1.termRef(1);
          
          if($10.isCons())
          {ESLVal $12 = $10.head();
            ESLVal $13 = $10.tail();
            
            switch($12.termName) {
            case "FunCase": {ESLVal $18 = $12.termRef(0);
              ESLVal $17 = $12.termRef(1);
              ESLVal $16 = $12.termRef(2);
              ESLVal $15 = $12.termRef(3);
              ESLVal $14 = $12.termRef(4);
              
              {ESLVal n = $11;
              
              {ESLVal l = $18;
              
              {ESLVal args = $17;
              
              {ESLVal t = $16;
              
              {ESLVal g = $15;
              
              {ESLVal e = $14;
              
              {ESLVal cases = $13;
              
              return ESLVal.list();
            }
            }
            }
            }
            }
            }
            }
            }
            default: return error(new ESLVal("case error at Pos(230,815)").add(ESLVal.list(_v1)));
          }
          }
        else if($10.isNil())
          return error(new ESLVal("case error at Pos(230,815)").add(ESLVal.list(_v1)));
        else return error(new ESLVal("case error at Pos(230,815)").add(ESLVal.list(_v1)));
        }
      case "Binding": {ESLVal $9 = _v1.termRef(0);
          ESLVal $8 = _v1.termRef(1);
          ESLVal $7 = _v1.termRef(2);
          ESLVal $6 = _v1.termRef(3);
          ESLVal $5 = _v1.termRef(4);
          
          {ESLVal v0 = $9;
          
          {ESLVal v1 = $8;
          
          {ESLVal v2 = $7;
          
          {ESLVal v3 = $6;
          
          {ESLVal v4 = $5;
          
          return freeVars.apply(v4);
        }
        }
        }
        }
        }
        }
      case "DataBind": {ESLVal $4 = _v1.termRef(0);
          ESLVal $3 = _v1.termRef(1);
          ESLVal $2 = _v1.termRef(2);
          ESLVal $1 = _v1.termRef(3);
          
          {ESLVal v0 = $4;
          
          {ESLVal v1 = $3;
          
          {ESLVal v2 = $2;
          
          {ESLVal v3 = $1;
          
          return ESLVal.list();
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(230,815)").add(ESLVal.list(_v1)));
      }
      }
    }
  });
  private static ESLVal armFV = new ESLVal(new Function(new ESLVal("armFV"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal a = $args[0];
  {ESLVal _v2 = a;
        
        switch(_v2.termName) {
        case "BArm": {ESLVal $37 = _v2.termRef(0);
          ESLVal $36 = _v2.termRef(1);
          ESLVal $35 = _v2.termRef(2);
          ESLVal $34 = _v2.termRef(3);
          
          {ESLVal l = $37;
          
          {ESLVal ps = $36;
          
          {ESLVal g = $35;
          
          {ESLVal e = $34;
          
          {ESLVal bound = new java.util.function.Function<ESLVal,ESLVal>() {
              public ESLVal apply(ESLVal $l0) {
                ESLVal $a = $nil;
                java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                while(!$l0.isNil()) { 
                  ESLVal p = $l0.head();
                  $l0 = $l0.tail();
                  ESLVal $l1 = patternNames.apply(p);
            while(!$l1.isNil()) {
              ESLVal n = $l1.head();
              $l1 = $l1.tail();
              $v.add(n);
            }
                }
                for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                return $a;
              }}.apply(ps);
          
          return remStrs.apply(bound,freeVars.apply(g).add(freeVars.apply(e)));
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(842,993)").add(ESLVal.list(_v2)));
      }
      }
    }
  });
  public static ESLVal freeVars = new ESLVal(new Function(new ESLVal("freeVars"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  {ESLVal _v3 = e;
        
        switch(_v3.termName) {
        case "ActExp": {ESLVal $189 = _v3.termRef(0);
          ESLVal $188 = _v3.termRef(1);
          ESLVal $187 = _v3.termRef(2);
          ESLVal $186 = _v3.termRef(3);
          ESLVal $185 = _v3.termRef(4);
          ESLVal $184 = _v3.termRef(5);
          ESLVal $183 = _v3.termRef(6);
          ESLVal $182 = _v3.termRef(7);
          
          {ESLVal l = $189;
          
          {ESLVal name = $188;
          
          {ESLVal args = $187;
          
          {ESLVal exports = $186;
          
          {ESLVal parent = $185;
          
          {ESLVal bindings = $184;
          
          {ESLVal init = $183;
          
          {ESLVal handlers = $182;
          
          {ESLVal _v11 = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v6 = $qualArg;
                  
                  switch(_v6.termName) {
                  case "Dec": {ESLVal $199 = _v6.termRef(0);
                    ESLVal $198 = _v6.termRef(1);
                    ESLVal $197 = _v6.termRef(2);
                    ESLVal $196 = _v6.termRef(3);
                    
                    {ESLVal _v16 = $199;
                    
                    {ESLVal n = $198;
                    
                    {ESLVal t = $197;
                    
                    {ESLVal dt = $196;
                    
                    return ESLVal.list(ESLVal.list(n));
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v6;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(args).flatten().flatten();
          ESLVal _v12 = new java.util.function.Function<ESLVal,ESLVal>() {
              public ESLVal apply(ESLVal $l0) {
                ESLVal $a = $nil;
                java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                while(!$l0.isNil()) { 
                  ESLVal b = $l0.head();
                  $l0 = $l0.tail();
                  $v.add(bindingName.apply(b));
                }
                for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                return $a;
              }}.apply(bindings);
          ESLVal _v13 = new java.util.function.Function<ESLVal,ESLVal>() {
              public ESLVal apply(ESLVal $l0) {
                ESLVal $a = $nil;
                java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                while(!$l0.isNil()) { 
                  ESLVal b = $l0.head();
                  $l0 = $l0.tail();
                  ESLVal $l1 = bindingFV.apply(b);
            while(!$l1.isNil()) {
              ESLVal n = $l1.head();
              $l1 = $l1.tail();
              $v.add(n);
            }
                }
                for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                return $a;
              }}.apply(bindings);
          ESLVal _v14 = new java.util.function.Function<ESLVal,ESLVal>() {
              public ESLVal apply(ESLVal $l0) {
                ESLVal $a = $nil;
                java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                while(!$l0.isNil()) { 
                  ESLVal a = $l0.head();
                  $l0 = $l0.tail();
                  ESLVal $l1 = armFV.apply(a);
            while(!$l1.isNil()) {
              ESLVal n = $l1.head();
              $l1 = $l1.tail();
              $v.add(n);
            }
                }
                for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                return $a;
              }}.apply(handlers);
          ESLVal _v15 = ((Supplier<ESLVal>)() -> { 
              if(parent.eql($null).boolVal)
                return ESLVal.list();
                else
                  return freeVars.apply(parent);
            }).get();
          
          return remStrs.apply(_v11,freeVars.apply(name).add(_v15.add(freeVars.apply(init)))).add(remStrs.apply(_v11.add(_v12),_v13.add(_v14)));
        }
        }
        }
        }
        }
        }
        }
        }
        }
        }
      case "Apply": {ESLVal $181 = _v3.termRef(0);
          ESLVal $180 = _v3.termRef(1);
          ESLVal $179 = _v3.termRef(2);
          
          {ESLVal v0 = $181;
          
          {ESLVal v1 = $180;
          
          {ESLVal v2 = $179;
          
          return freeVars.apply(v1).add(new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal e = $l0.head();
                $l0 = $l0.tail();
                ESLVal $l1 = freeVars.apply(e);
          while(!$l1.isNil()) {
            ESLVal n = $l1.head();
            $l1 = $l1.tail();
            $v.add(n);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v2));
        }
        }
        }
        }
      case "ApplyTypeExp": {ESLVal $178 = _v3.termRef(0);
          ESLVal $177 = _v3.termRef(1);
          ESLVal $176 = _v3.termRef(2);
          
          {ESLVal v0 = $178;
          
          {ESLVal v1 = $177;
          
          {ESLVal v2 = $176;
          
          return freeVars.apply(v1);
        }
        }
        }
        }
      case "ArrayRef": {ESLVal $175 = _v3.termRef(0);
          ESLVal $174 = _v3.termRef(1);
          ESLVal $173 = _v3.termRef(2);
          
          {ESLVal v0 = $175;
          
          {ESLVal v1 = $174;
          
          {ESLVal v2 = $173;
          
          return freeVars.apply(v1).add(freeVars.apply(v2));
        }
        }
        }
        }
      case "ArrayUpdate": {ESLVal $172 = _v3.termRef(0);
          ESLVal $171 = _v3.termRef(1);
          ESLVal $170 = _v3.termRef(2);
          ESLVal $169 = _v3.termRef(3);
          
          {ESLVal v0 = $172;
          
          {ESLVal v1 = $171;
          
          {ESLVal v2 = $170;
          
          {ESLVal v3 = $169;
          
          return freeVars.apply(v1).add(freeVars.apply(v2).add(freeVars.apply(v3)));
        }
        }
        }
        }
        }
      case "BagExp": {ESLVal $168 = _v3.termRef(0);
          ESLVal $167 = _v3.termRef(1);
          
          {ESLVal v0 = $168;
          
          {ESLVal v1 = $167;
          
          return new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal e = $l0.head();
                $l0 = $l0.tail();
                ESLVal $l1 = freeVars.apply(e);
          while(!$l1.isNil()) {
            ESLVal n = $l1.head();
            $l1 = $l1.tail();
            $v.add(n);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v1);
        }
        }
        }
      case "Become": {ESLVal $166 = _v3.termRef(0);
          ESLVal $165 = _v3.termRef(1);
          
          {ESLVal v0 = $166;
          
          {ESLVal v1 = $165;
          
          return freeVars.apply(v1);
        }
        }
        }
      case "BinExp": {ESLVal $164 = _v3.termRef(0);
          ESLVal $163 = _v3.termRef(1);
          ESLVal $162 = _v3.termRef(2);
          ESLVal $161 = _v3.termRef(3);
          
          {ESLVal v0 = $164;
          
          {ESLVal v1 = $163;
          
          {ESLVal v2 = $162;
          
          {ESLVal v3 = $161;
          
          return freeVars.apply(v1).add(freeVars.apply(v3));
        }
        }
        }
        }
        }
      case "Block": {ESLVal $160 = _v3.termRef(0);
          ESLVal $159 = _v3.termRef(1);
          
          {ESLVal v0 = $160;
          
          {ESLVal v1 = $159;
          
          return new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal e = $l0.head();
                $l0 = $l0.tail();
                ESLVal $l1 = freeVars.apply(e);
          while(!$l1.isNil()) {
            ESLVal n = $l1.head();
            $l1 = $l1.tail();
            $v.add(n);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v1);
        }
        }
        }
      case "BoolExp": {ESLVal $158 = _v3.termRef(0);
          ESLVal $157 = _v3.termRef(1);
          
          {ESLVal v0 = $158;
          
          {ESLVal v1 = $157;
          
          return ESLVal.list();
        }
        }
        }
      case "Case": {ESLVal $156 = _v3.termRef(0);
          ESLVal $155 = _v3.termRef(1);
          ESLVal $154 = _v3.termRef(2);
          ESLVal $153 = _v3.termRef(3);
          
          {ESLVal v0 = $156;
          
          {ESLVal v1 = $155;
          
          {ESLVal v2 = $154;
          
          {ESLVal v3 = $153;
          
          return new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal e = $l0.head();
                $l0 = $l0.tail();
                ESLVal $l1 = freeVars.apply(e);
          while(!$l1.isNil()) {
            ESLVal n = $l1.head();
            $l1 = $l1.tail();
            $v.add(n);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v2).add(new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal a = $l0.head();
                $l0 = $l0.tail();
                ESLVal $l1 = armFV.apply(a);
          while(!$l1.isNil()) {
            ESLVal n = $l1.head();
            $l1 = $l1.tail();
            $v.add(n);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v3));
        }
        }
        }
        }
        }
      case "Cmp": {ESLVal $145 = _v3.termRef(0);
          ESLVal $144 = _v3.termRef(1);
          ESLVal $143 = _v3.termRef(2);
          
          if($143.isCons())
          {ESLVal $146 = $143.head();
            ESLVal $147 = $143.tail();
            
            switch($146.termName) {
            case "BQual": {ESLVal $152 = $146.termRef(0);
              ESLVal $151 = $146.termRef(1);
              ESLVal $150 = $146.termRef(2);
              
              {ESLVal l = $145;
              
              {ESLVal _v9 = $144;
              
              {ESLVal ql = $152;
              
              {ESLVal qp = $151;
              
              {ESLVal qe = $150;
              
              {ESLVal qs = $147;
              
              return freeVars.apply(qe).add(remStrs.apply(patternNames.apply(qp),freeVars.apply(new ESLVal("Cmp",l,_v9,qs))));
            }
            }
            }
            }
            }
            }
            }
          case "PQual": {ESLVal $149 = $146.termRef(0);
              ESLVal $148 = $146.termRef(1);
              
              {ESLVal l = $145;
              
              {ESLVal _v8 = $144;
              
              {ESLVal ql = $149;
              
              {ESLVal qe = $148;
              
              {ESLVal qs = $147;
              
              return freeVars.apply(qe).add(freeVars.apply(new ESLVal("Cmp",l,_v8,qs)));
            }
            }
            }
            }
            }
            }
            default: return error(new ESLVal("case error at Pos(1025,6155)").add(ESLVal.list(_v3)));
          }
          }
        else if($143.isNil())
          {ESLVal l = $145;
            
            {ESLVal _v10 = $144;
            
            return freeVars.apply(_v10);
          }
          }
        else return error(new ESLVal("case error at Pos(1025,6155)").add(ESLVal.list(_v3)));
        }
      case "Cons": {ESLVal $142 = _v3.termRef(0);
          ESLVal $141 = _v3.termRef(1);
          
          {ESLVal v0 = $142;
          
          {ESLVal v1 = $141;
          
          return freeVars.apply(v0).add(freeVars.apply(v1));
        }
        }
        }
      case "For": {ESLVal $140 = _v3.termRef(0);
          ESLVal $139 = _v3.termRef(1);
          ESLVal $138 = _v3.termRef(2);
          ESLVal $137 = _v3.termRef(3);
          
          {ESLVal v0 = $140;
          
          {ESLVal v1 = $139;
          
          {ESLVal v2 = $138;
          
          {ESLVal v3 = $137;
          
          return freeVars.apply(v2).add(remStrs.apply(patternNames.apply(v1),freeVars.apply(v3)));
        }
        }
        }
        }
        }
      case "FunExp": {ESLVal $136 = _v3.termRef(0);
          ESLVal $135 = _v3.termRef(1);
          ESLVal $134 = _v3.termRef(2);
          ESLVal $133 = _v3.termRef(3);
          ESLVal $132 = _v3.termRef(4);
          
          {ESLVal v0 = $136;
          
          {ESLVal v1 = $135;
          
          {ESLVal v2 = $134;
          
          {ESLVal v3 = $133;
          
          {ESLVal v4 = $132;
          
          return remStrs.apply(new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v5 = $qualArg;
                
                switch(_v5.termName) {
                case "Dec": {ESLVal $195 = _v5.termRef(0);
                  ESLVal $194 = _v5.termRef(1);
                  ESLVal $193 = _v5.termRef(2);
                  ESLVal $192 = _v5.termRef(3);
                  
                  {ESLVal l = $195;
                  
                  {ESLVal n = $194;
                  
                  {ESLVal t = $193;
                  
                  {ESLVal dt = $192;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                }
                default: {ESLVal _0 = _v5;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(v2).flatten().flatten(),freeVars.apply(v1).add(freeVars.apply(v4)));
        }
        }
        }
        }
        }
        }
      case "Grab": {ESLVal $131 = _v3.termRef(0);
          ESLVal $130 = _v3.termRef(1);
          ESLVal $129 = _v3.termRef(2);
          
          {ESLVal v0 = $131;
          
          {ESLVal v1 = $130;
          
          {ESLVal v2 = $129;
          
          return new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v4 = $qualArg;
                
                switch(_v4.termName) {
                case "VarDynamicRef": {ESLVal $191 = _v4.termRef(0);
                  ESLVal $190 = _v4.termRef(1);
                  
                  {ESLVal l = $191;
                  
                  {ESLVal _v7 = $190;
                  
                  return ESLVal.list(new java.util.function.Function<ESLVal,ESLVal>() {
                    public ESLVal apply(ESLVal $l0) {
                      ESLVal $a = $nil;
                      java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                      while(!$l0.isNil()) { 
                        ESLVal n = $l0.head();
                        $l0 = $l0.tail();
                        $v.add(n);
                      }
                      for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                      return $a;
                    }}.apply(freeVars.apply(_v7)));
                }
                }
                }
                default: {ESLVal _0 = _v4;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(v1).flatten().flatten().add(freeVars.apply(v2));
        }
        }
        }
        }
      case "If": {ESLVal $128 = _v3.termRef(0);
          ESLVal $127 = _v3.termRef(1);
          ESLVal $126 = _v3.termRef(2);
          ESLVal $125 = _v3.termRef(3);
          
          {ESLVal v0 = $128;
          
          {ESLVal v1 = $127;
          
          {ESLVal v2 = $126;
          
          {ESLVal v3 = $125;
          
          return freeVars.apply(v1).add(freeVars.apply(v2).add(freeVars.apply(v3)));
        }
        }
        }
        }
        }
      case "IntExp": {ESLVal $124 = _v3.termRef(0);
          ESLVal $123 = _v3.termRef(1);
          
          {ESLVal v0 = $124;
          
          {ESLVal v1 = $123;
          
          return ESLVal.list();
        }
        }
        }
      case "FloatExp": {ESLVal $122 = _v3.termRef(0);
          ESLVal $121 = _v3.termRef(1);
          
          {ESLVal v0 = $122;
          
          {ESLVal v1 = $121;
          
          return ESLVal.list();
        }
        }
        }
      case "Fold": {ESLVal $120 = _v3.termRef(0);
          ESLVal $119 = _v3.termRef(1);
          ESLVal $118 = _v3.termRef(2);
          
          {ESLVal v0 = $120;
          
          {ESLVal v1 = $119;
          
          {ESLVal v2 = $118;
          
          return freeVars.apply(v2);
        }
        }
        }
        }
      case "Head": {ESLVal $117 = _v3.termRef(0);
          
          {ESLVal v0 = $117;
          
          return freeVars.apply(v0);
        }
        }
      case "Let": {ESLVal $116 = _v3.termRef(0);
          ESLVal $115 = _v3.termRef(1);
          ESLVal $114 = _v3.termRef(2);
          
          {ESLVal v0 = $116;
          
          {ESLVal v1 = $115;
          
          {ESLVal v2 = $114;
          
          return new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal b = $l0.head();
                $l0 = $l0.tail();
                ESLVal $l1 = bindingFV.apply(b);
          while(!$l1.isNil()) {
            ESLVal n = $l1.head();
            $l1 = $l1.tail();
            $v.add(n);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v1).add(remStrs.apply(new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal b = $l0.head();
                $l0 = $l0.tail();
                $v.add(bindingName.apply(b));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v1),freeVars.apply(v2)));
        }
        }
        }
        }
      case "Letrec": {ESLVal $113 = _v3.termRef(0);
          ESLVal $112 = _v3.termRef(1);
          ESLVal $111 = _v3.termRef(2);
          
          {ESLVal v0 = $113;
          
          {ESLVal v1 = $112;
          
          {ESLVal v2 = $111;
          
          return remStrs.apply(new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal b = $l0.head();
                $l0 = $l0.tail();
                $v.add(bindingName.apply(b));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v1),new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal b = $l0.head();
                $l0 = $l0.tail();
                ESLVal $l1 = bindingFV.apply(b);
          while(!$l1.isNil()) {
            ESLVal n = $l1.head();
            $l1 = $l1.tail();
            $v.add(n);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v1).add(freeVars.apply(v2)));
        }
        }
        }
        }
      case "List": {ESLVal $110 = _v3.termRef(0);
          ESLVal $109 = _v3.termRef(1);
          
          {ESLVal v0 = $110;
          
          {ESLVal v1 = $109;
          
          return new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal e = $l0.head();
                $l0 = $l0.tail();
                ESLVal $l1 = freeVars.apply(e);
          while(!$l1.isNil()) {
            ESLVal n = $l1.head();
            $l1 = $l1.tail();
            $v.add(n);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v1);
        }
        }
        }
      case "Module": {ESLVal $108 = _v3.termRef(0);
          ESLVal $107 = _v3.termRef(1);
          ESLVal $106 = _v3.termRef(2);
          ESLVal $105 = _v3.termRef(3);
          ESLVal $104 = _v3.termRef(4);
          ESLVal $103 = _v3.termRef(5);
          ESLVal $102 = _v3.termRef(6);
          
          {ESLVal v0 = $108;
          
          {ESLVal v1 = $107;
          
          {ESLVal v2 = $106;
          
          {ESLVal v3 = $105;
          
          {ESLVal v4 = $104;
          
          {ESLVal v5 = $103;
          
          {ESLVal v6 = $102;
          
          return remStrs.apply(new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal b = $l0.head();
                $l0 = $l0.tail();
                $v.add(bindingName.apply(b));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v6),new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal b = $l0.head();
                $l0 = $l0.tail();
                ESLVal $l1 = bindingFV.apply(b);
          while(!$l1.isNil()) {
            ESLVal n = $l1.head();
            $l1 = $l1.tail();
            $v.add(n);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v6));
        }
        }
        }
        }
        }
        }
        }
        }
      case "New": {ESLVal $101 = _v3.termRef(0);
          ESLVal $100 = _v3.termRef(1);
          ESLVal $99 = _v3.termRef(2);
          
          {ESLVal v0 = $101;
          
          {ESLVal v1 = $100;
          
          {ESLVal v2 = $99;
          
          return freeVars.apply(v1).add(new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal e = $l0.head();
                $l0 = $l0.tail();
                ESLVal $l1 = freeVars.apply(e);
          while(!$l1.isNil()) {
            ESLVal n = $l1.head();
            $l1 = $l1.tail();
            $v.add(n);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v2));
        }
        }
        }
        }
      case "NewArray": {ESLVal $98 = _v3.termRef(0);
          ESLVal $97 = _v3.termRef(1);
          ESLVal $96 = _v3.termRef(2);
          
          {ESLVal v0 = $98;
          
          {ESLVal v1 = $97;
          
          {ESLVal v2 = $96;
          
          return freeVars.apply(v2);
        }
        }
        }
        }
      case "NewJava": {ESLVal $95 = _v3.termRef(0);
          ESLVal $94 = _v3.termRef(1);
          ESLVal $93 = _v3.termRef(2);
          ESLVal $92 = _v3.termRef(3);
          
          {ESLVal v0 = $95;
          
          {ESLVal v1 = $94;
          
          {ESLVal v2 = $93;
          
          {ESLVal v3 = $92;
          
          return new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal e = $l0.head();
                $l0 = $l0.tail();
                ESLVal $l1 = freeVars.apply(e);
          while(!$l1.isNil()) {
            ESLVal n = $l1.head();
            $l1 = $l1.tail();
            $v.add(n);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v3);
        }
        }
        }
        }
        }
      case "NewTable": {ESLVal $91 = _v3.termRef(0);
          ESLVal $90 = _v3.termRef(1);
          ESLVal $89 = _v3.termRef(2);
          
          {ESLVal v0 = $91;
          
          {ESLVal v1 = $90;
          
          {ESLVal v2 = $89;
          
          return ESLVal.list();
        }
        }
        }
        }
      case "Not": {ESLVal $88 = _v3.termRef(0);
          ESLVal $87 = _v3.termRef(1);
          
          {ESLVal v0 = $88;
          
          {ESLVal v1 = $87;
          
          return freeVars.apply(v1);
        }
        }
        }
      case "Now": {ESLVal $86 = _v3.termRef(0);
          
          {ESLVal v0 = $86;
          
          return ESLVal.list();
        }
        }
      case "NullExp": {ESLVal $85 = _v3.termRef(0);
          
          {ESLVal v0 = $85;
          
          return ESLVal.list();
        }
        }
      case "PLet": {ESLVal $84 = _v3.termRef(0);
          ESLVal $83 = _v3.termRef(1);
          ESLVal $82 = _v3.termRef(2);
          
          {ESLVal v0 = $84;
          
          {ESLVal v1 = $83;
          
          {ESLVal v2 = $82;
          
          return new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal b = $l0.head();
                $l0 = $l0.tail();
                ESLVal $l1 = bindingFV.apply(b);
          while(!$l1.isNil()) {
            ESLVal n = $l1.head();
            $l1 = $l1.tail();
            $v.add(n);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v1).add(remStrs.apply(new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal b = $l0.head();
                $l0 = $l0.tail();
                $v.add(bindingName.apply(b));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v1),freeVars.apply(v2)));
        }
        }
        }
        }
      case "Probably": {ESLVal $81 = _v3.termRef(0);
          ESLVal $80 = _v3.termRef(1);
          ESLVal $79 = _v3.termRef(2);
          ESLVal $78 = _v3.termRef(3);
          ESLVal $77 = _v3.termRef(4);
          
          {ESLVal v0 = $81;
          
          {ESLVal v1 = $80;
          
          {ESLVal v2 = $79;
          
          {ESLVal v3 = $78;
          
          {ESLVal v4 = $77;
          
          return freeVars.apply(v1).add(freeVars.apply(v3).add(freeVars.apply(v4)));
        }
        }
        }
        }
        }
        }
      case "Record": {ESLVal $76 = _v3.termRef(0);
          ESLVal $75 = _v3.termRef(1);
          
          {ESLVal v0 = $76;
          
          {ESLVal v1 = $75;
          
          return new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal b = $l0.head();
                $l0 = $l0.tail();
                ESLVal $l1 = bindingFV.apply(b);
          while(!$l1.isNil()) {
            ESLVal n = $l1.head();
            $l1 = $l1.tail();
            $v.add(n);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v1);
        }
        }
        }
      case "RefSuper": {ESLVal $74 = _v3.termRef(0);
          ESLVal $73 = _v3.termRef(1);
          
          {ESLVal v0 = $74;
          
          {ESLVal v1 = $73;
          
          return ESLVal.list();
        }
        }
        }
      case "Ref": {ESLVal $72 = _v3.termRef(0);
          ESLVal $71 = _v3.termRef(1);
          ESLVal $70 = _v3.termRef(2);
          
          {ESLVal v0 = $72;
          
          {ESLVal v1 = $71;
          
          {ESLVal v2 = $70;
          
          return freeVars.apply(v1);
        }
        }
        }
        }
      case "Self": {ESLVal $69 = _v3.termRef(0);
          
          {ESLVal v0 = $69;
          
          return ESLVal.list();
        }
        }
      case "Send": {ESLVal $68 = _v3.termRef(0);
          ESLVal $67 = _v3.termRef(1);
          ESLVal $66 = _v3.termRef(2);
          
          {ESLVal v0 = $68;
          
          {ESLVal v1 = $67;
          
          {ESLVal v2 = $66;
          
          return freeVars.apply(v1).add(freeVars.apply(v2));
        }
        }
        }
        }
      case "SendSuper": {ESLVal $65 = _v3.termRef(0);
          ESLVal $64 = _v3.termRef(1);
          
          {ESLVal v0 = $65;
          
          {ESLVal v1 = $64;
          
          return freeVars.apply(v1);
        }
        }
        }
      case "SendTimeSuper": {ESLVal $63 = _v3.termRef(0);
          
          {ESLVal v0 = $63;
          
          return ESLVal.list();
        }
        }
      case "SetExp": {ESLVal $62 = _v3.termRef(0);
          ESLVal $61 = _v3.termRef(1);
          
          {ESLVal v0 = $62;
          
          {ESLVal v1 = $61;
          
          return new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal e = $l0.head();
                $l0 = $l0.tail();
                ESLVal $l1 = freeVars.apply(e);
          while(!$l1.isNil()) {
            ESLVal n = $l1.head();
            $l1 = $l1.tail();
            $v.add(n);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v1);
        }
        }
        }
      case "StrExp": {ESLVal $60 = _v3.termRef(0);
          ESLVal $59 = _v3.termRef(1);
          
          {ESLVal v0 = $60;
          
          {ESLVal v1 = $59;
          
          return ESLVal.list();
        }
        }
        }
      case "Tail": {ESLVal $58 = _v3.termRef(0);
          
          {ESLVal v0 = $58;
          
          return freeVars.apply(v0);
        }
        }
      case "Term": {ESLVal $57 = _v3.termRef(0);
          ESLVal $56 = _v3.termRef(1);
          ESLVal $55 = _v3.termRef(2);
          ESLVal $54 = _v3.termRef(3);
          
          {ESLVal v0 = $57;
          
          {ESLVal v1 = $56;
          
          {ESLVal v2 = $55;
          
          {ESLVal v3 = $54;
          
          return new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal e = $l0.head();
                $l0 = $l0.tail();
                ESLVal $l1 = freeVars.apply(e);
          while(!$l1.isNil()) {
            ESLVal n = $l1.head();
            $l1 = $l1.tail();
            $v.add(n);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v3);
        }
        }
        }
        }
        }
      case "TermRef": {ESLVal $53 = _v3.termRef(0);
          ESLVal $52 = _v3.termRef(1);
          
          {ESLVal v0 = $53;
          
          {ESLVal v1 = $52;
          
          return freeVars.apply(v0);
        }
        }
        }
      case "Throw": {ESLVal $51 = _v3.termRef(0);
          ESLVal $50 = _v3.termRef(1);
          ESLVal $49 = _v3.termRef(2);
          
          {ESLVal v0 = $51;
          
          {ESLVal v1 = $50;
          
          {ESLVal v2 = $49;
          
          return freeVars.apply(v2);
        }
        }
        }
        }
      case "Try": {ESLVal $48 = _v3.termRef(0);
          ESLVal $47 = _v3.termRef(1);
          ESLVal $46 = _v3.termRef(2);
          
          {ESLVal v0 = $48;
          
          {ESLVal v1 = $47;
          
          {ESLVal v2 = $46;
          
          return freeVars.apply(v1).add(new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal a = $l0.head();
                $l0 = $l0.tail();
                ESLVal $l1 = armFV.apply(a);
          while(!$l1.isNil()) {
            ESLVal n = $l1.head();
            $l1 = $l1.tail();
            $v.add(n);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v2));
        }
        }
        }
        }
      case "Update": {ESLVal $45 = _v3.termRef(0);
          ESLVal $44 = _v3.termRef(1);
          ESLVal $43 = _v3.termRef(2);
          
          {ESLVal v0 = $45;
          
          {ESLVal v1 = $44;
          
          {ESLVal v2 = $43;
          
          return ESLVal.list(v1).add(freeVars.apply(v2));
        }
        }
        }
        }
      case "Unfold": {ESLVal $42 = _v3.termRef(0);
          ESLVal $41 = _v3.termRef(1);
          ESLVal $40 = _v3.termRef(2);
          
          {ESLVal v0 = $42;
          
          {ESLVal v1 = $41;
          
          {ESLVal v2 = $40;
          
          return freeVars.apply(v2);
        }
        }
        }
        }
      case "Var": {ESLVal $39 = _v3.termRef(0);
          ESLVal $38 = _v3.termRef(1);
          
          {ESLVal v0 = $39;
          
          {ESLVal v1 = $38;
          
          return ESLVal.list(v1);
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(1025,6155)").add(ESLVal.list(_v3)));
      }
      }
    }
  });
public static void main(String[] args) {
  }
}