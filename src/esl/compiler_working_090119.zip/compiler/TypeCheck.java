package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
// import static esl.Lists.*;
import static esl.compiler.Types.*;
import static esl.Tables.*;
import static esl.Displays.*;
import static esl.compiler.UnusedVars.*;
import java.util.function.Supplier;
public class TypeCheck {
  public static ESLVal getSelf() { return $null; }
  private static ESLVal ppPattern = new ESLVal(new Function(new ESLVal("ppPattern"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v1 = p;
        
        switch(_v1.termName) {
        case "PAdd": {ESLVal $33 = _v1.termRef(0);
          ESLVal $32 = _v1.termRef(1);
          ESLVal $31 = _v1.termRef(2);
          
          {ESLVal l = $33;
          
          {ESLVal p1 = $32;
          
          {ESLVal p2 = $31;
          
          return ppPattern.apply(p1).add(new ESLVal(" + ").add(ppPattern.apply(p2)));
        }
        }
        }
        }
      case "PVar": {ESLVal $30 = _v1.termRef(0);
          ESLVal $29 = _v1.termRef(1);
          ESLVal $28 = _v1.termRef(2);
          
          {ESLVal l = $30;
          
          {ESLVal n = $29;
          
          {ESLVal t = $28;
          
          return n;
        }
        }
        }
        }
      case "PTerm": {ESLVal $25 = _v1.termRef(0);
          ESLVal $24 = _v1.termRef(1);
          ESLVal $23 = _v1.termRef(2);
          ESLVal $22 = _v1.termRef(3);
          
          if($23.isCons())
          {ESLVal $26 = $23.head();
            ESLVal $27 = $23.tail();
            
            {ESLVal l = $25;
            
            {ESLVal n = $24;
            
            {ESLVal ts = $23;
            
            {ESLVal ps = $22;
            
            return n.add(ppTypes.apply(ts,ESLVal.list()).add(new ESLVal("").add(ppPatterns.apply(ps))));
          }
          }
          }
          }
          }
        else if($23.isNil())
          {ESLVal l = $25;
            
            {ESLVal n = $24;
            
            {ESLVal ps = $22;
            
            return n.add(ppPatterns.apply(ps));
          }
          }
          }
        else {ESLVal l = $25;
            
            {ESLVal n = $24;
            
            {ESLVal ts = $23;
            
            {ESLVal ps = $22;
            
            return n.add(ppTypes.apply(ts,ESLVal.list()).add(new ESLVal("").add(ppPatterns.apply(ps))));
          }
          }
          }
          }
        }
      case "PApplyType": {ESLVal $21 = _v1.termRef(0);
          ESLVal $20 = _v1.termRef(1);
          ESLVal $19 = _v1.termRef(2);
          
          {ESLVal l = $21;
          
          {ESLVal _v1109 = $20;
          
          {ESLVal ts = $19;
          
          return ppPattern.apply(_v1109).add(ppTypes.apply(ts,ESLVal.list()));
        }
        }
        }
        }
      case "PNil": {ESLVal $18 = _v1.termRef(0);
          
          {ESLVal l = $18;
          
          return new ESLVal("[]");
        }
        }
      case "PEmptySet": {ESLVal $17 = _v1.termRef(0);
          
          {ESLVal l = $17;
          
          return new ESLVal("Set{}");
        }
        }
      case "PEmptyBag": {ESLVal $16 = _v1.termRef(0);
          
          {ESLVal l = $16;
          
          return new ESLVal("Bag{}");
        }
        }
      case "PInt": {ESLVal $15 = _v1.termRef(0);
          ESLVal $14 = _v1.termRef(1);
          
          {ESLVal l = $15;
          
          {ESLVal n = $14;
          
          return new ESLVal("").add(n);
        }
        }
        }
      case "PBool": {ESLVal $13 = _v1.termRef(0);
          ESLVal $12 = _v1.termRef(1);
          
          {ESLVal l = $13;
          
          {ESLVal b = $12;
          
          return new ESLVal("").add(b);
        }
        }
        }
      case "PStr": {ESLVal $11 = _v1.termRef(0);
          ESLVal $10 = _v1.termRef(1);
          
          {ESLVal l = $11;
          
          {ESLVal s = $10;
          
          return s;
        }
        }
        }
      case "PCons": {ESLVal $9 = _v1.termRef(0);
          ESLVal $8 = _v1.termRef(1);
          ESLVal $7 = _v1.termRef(2);
          
          {ESLVal l = $9;
          
          {ESLVal h = $8;
          
          {ESLVal t = $7;
          
          return ppPattern.apply(h).add(new ESLVal(":").add(ppPattern.apply(t)));
        }
        }
        }
        }
      case "PSetCons": {ESLVal $6 = _v1.termRef(0);
          ESLVal $5 = _v1.termRef(1);
          ESLVal $4 = _v1.termRef(2);
          
          {ESLVal l = $6;
          
          {ESLVal p1 = $5;
          
          {ESLVal p2 = $4;
          
          return new ESLVal("Set{").add(ppPattern.apply(p1).add(new ESLVal(" | ").add(ppPattern.apply(p2).add(new ESLVal("}")))));
        }
        }
        }
        }
      case "PBagCons": {ESLVal $3 = _v1.termRef(0);
          ESLVal $2 = _v1.termRef(1);
          ESLVal $1 = _v1.termRef(2);
          
          {ESLVal l = $3;
          
          {ESLVal p1 = $2;
          
          {ESLVal p2 = $1;
          
          return new ESLVal("Bag{").add(ppPattern.apply(p1).add(new ESLVal(" | ").add(ppPattern.apply(p2).add(new ESLVal("}")))));
        }
        }
        }
        }
        default: {ESLVal _v1110 = _v1;
          
          return new ESLVal("<unknown: ").add(_v1110.add(new ESLVal(">")));
        }
      }
      }
    }
  });
  private static ESLVal ppPatterns = new ESLVal(new Function(new ESLVal("ppPatterns"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal ps = $args[0];
  return map.apply(ppPattern,ps);
    }
  });
  private static ESLVal p0 = new ESLVal("Pos",$zero,$zero);
  private static ESLVal actType0 = new ESLVal("ActType",p0,ESLVal.list(),ESLVal.list());
  private static ESLVal contentType = new ESLVal("UnionType",p0,ESLVal.list(new ESLVal("TermType",p0,new ESLVal("RawText"),ESLVal.list(new ESLVal("StrType",p0))),new ESLVal("TermType",p0,new ESLVal("ESLSource"),ESLVal.list(new ESLVal("StrType",p0),new ESLVal("StrType",p0))),new ESLVal("TermType",p0,new ESLVal("JavaSource"),ESLVal.list(new ESLVal("StrType",p0),new ESLVal("StrType",p0),new ESLVal("StrType",p0)))));
  private static ESLVal editMessage = new ESLVal("MessageType",p0,ESLVal.list(new ESLVal("TermType",p0,new ESLVal("Edit"),ESLVal.list(contentType))));
  private static ESLVal env0 = ESLVal.list(new ESLVal("Map",new ESLVal("edb"),new ESLVal("ActType",p0,ESLVal.list(new ESLVal("Dec",p0,new ESLVal("button"),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("StrType",p0),new ESLVal("StrType",p0),new ESLVal("StrType",p0),new ESLVal("StrType",p0),new ESLVal("FunType",p0,ESLVal.list(),new ESLVal("VoidType",p0))),new ESLVal("VoidType",p0)),$null),new ESLVal("Dec",p0,new ESLVal("display"),new ESLVal("ForallType",p0,ESLVal.list(new ESLVal("T")),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("StrType",p0),new ESLVal("VarType",p0,new ESLVal("T"))),new ESLVal("VarType",p0,new ESLVal("T")))),$null)),ESLVal.list(editMessage))),new ESLVal("Map",new ESLVal("kill"),new ESLVal("ForallType",p0,ESLVal.list(new ESLVal("T")),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("VarType",p0,new ESLVal("T"))),new ESLVal("VoidType",p0)))),new ESLVal("Map",new ESLVal("print"),new ESLVal("ForallType",p0,ESLVal.list(new ESLVal("T")),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("VarType",p0,new ESLVal("T"))),new ESLVal("VoidType",p0)))),new ESLVal("Map",new ESLVal("parse"),new ESLVal("ForallType",p0,ESLVal.list(new ESLVal("T")),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("StrType",p0)),new ESLVal("VarType",p0,new ESLVal("T"))))),new ESLVal("Map",new ESLVal("random"),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("IntType",p0)),new ESLVal("IntType",p0))),new ESLVal("Map",new ESLVal("wait"),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("IntType",p0)),new ESLVal("VoidType",p0))),new ESLVal("Map",new ESLVal("stopAll"),new ESLVal("FunType",p0,ESLVal.list(),new ESLVal("VoidType",p0))),new ESLVal("Map",new ESLVal("isqrt"),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("IntType",p0)),new ESLVal("FloatType",p0))),new ESLVal("Map",new ESLVal("round"),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("FloatType",p0)),new ESLVal("IntType",p0))),new ESLVal("Map",new ESLVal("builtin"),new ESLVal("ForallType",p0,ESLVal.list(new ESLVal("T")),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("StrType",p0),new ESLVal("StrType",p0),new ESLVal("IntType",p0)),new ESLVal("VarType",p0,new ESLVal("T"))))));
  private static ESLVal cnstrEnv0 = ESLVal.list(new ESLVal("Map",new ESLVal("Time"),new ESLVal("UnionType",p0,ESLVal.list(new ESLVal("TermType",p0,new ESLVal("Time"),ESLVal.list(new ESLVal("IntType",p0)))))));
  private static ESLVal tenv0 = ESLVal.list(new ESLVal("Map",new ESLVal("EditType"),contentType),new ESLVal("Map",new ESLVal("Time"),new ESLVal("UnionType",p0,ESLVal.list(new ESLVal("TermType",p0,new ESLVal("Time"),ESLVal.list(new ESLVal("IntType",p0)))))),new ESLVal("Map",new ESLVal("Point"),new ESLVal("UnionType",p0,ESLVal.list(new ESLVal("TermType",p0,new ESLVal("Point"),ESLVal.list(new ESLVal("IntType",p0),new ESLVal("IntType",p0)))))));
  private static ESLVal ppTypeEnv = new ESLVal(new Function(new ESLVal("ppTypeEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal env = $args[0];
  {ESLVal[] s = new ESLVal[]{new ESLVal("[")};
        
        {{
        ESLVal _v4 = env;
        while(_v4.isCons()) {
          ESLVal _v3 = _v4.headVal;
          {ESLVal _v2 = new ESLVal(new Function(new ESLVal("forp"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  {ESLVal _v5 = _v3;
                    
                    switch(_v5.termName) {
                    case "Map": {ESLVal $35 = _v5.termRef(0);
                      ESLVal $34 = _v5.termRef(1);
                      
                      {ESLVal n = $35;
                      
                      {ESLVal t = $34;
                      
                      {s[0] = s[0].add(n.add(new ESLVal("->").add(ppType.apply(t,env).add(new ESLVal(",")))));
                    return $null;}
                    }
                    }
                    }
                    default: {ESLVal $$$ = _v5;
                      
                      return $null;
                    }
                  }
                  }
                }
              });
            
            _v2.apply();
          }
          _v4 = _v4.tailVal;}
      }
      return s[0].add(new ESLVal("]"));}
      }
    }
  });
  private static ESLVal ppTypes = new ESLVal(new Function(new ESLVal("ppTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal ts = $args[0];
  ESLVal env = $args[1];
  return map.apply(ppType0.apply(env),ts);
    }
  });
  private static ESLVal getTypeName = new ESLVal(new Function(new ESLVal("getTypeName"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t0 = $args[0];
  ESLVal env = $args[1];
  {ESLVal[] name = new ESLVal[]{$null};
        
        {{
        ESLVal _v8 = env;
        while(_v8.isCons()) {
          ESLVal _v7 = _v8.headVal;
          {ESLVal _v6 = new ESLVal(new Function(new ESLVal("forp"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  {ESLVal _v9 = _v7;
                    
                    switch(_v9.termName) {
                    case "Map": {ESLVal $37 = _v9.termRef(0);
                      ESLVal $36 = _v9.termRef(1);
                      
                      {ESLVal n = $37;
                      
                      {ESLVal t = $36;
                      
                      if(typeEqual.apply(t0,t).boolVal)
                      {name[0] = n;
                      return $null;}
                      else
                        return $null;
                    }
                    }
                    }
                    default: {ESLVal $$$ = _v9;
                      
                      return $null;
                    }
                  }
                  }
                }
              });
            
            _v6.apply();
          }
          _v8 = _v8.tailVal;}
      }
      return name[0];}
      }
    }
  });
  private static ESLVal ppType0 = new ESLVal(new Function(new ESLVal("ppType0"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal env = $args[0];
  return new ESLVal(new Function(new ESLVal("fun194"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal t = $args[0];
        return ppType.apply(t,env);
          }
        });
    }
  });
  private static ESLVal ppHandlers = new ESLVal(new Function(new ESLVal("ppHandlers"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal handlers = $args[0];
  ESLVal env = $args[1];
  {ESLVal _v10 = handlers;
        
        if(_v10.isCons())
        {ESLVal $38 = _v10.head();
          ESLVal $39 = _v10.tail();
          
          switch($38.termName) {
          case "MessageType": {ESLVal $41 = $38.termRef(0);
            ESLVal $40 = $38.termRef(1);
            
            if($40.isCons())
            {ESLVal $42 = $40.head();
              ESLVal $43 = $40.tail();
              
              {ESLVal l = $41;
              
              {ESLVal t = $42;
              
              {ESLVal ts = $43;
              
              {ESLVal hs = $39;
              
              return ppType.apply(t,env).add(new ESLVal("; ").add(ppHandlers.apply(hs,env)));
            }
            }
            }
            }
            }
          else if($40.isNil())
            return error(new ESLVal("case error at Pos(5471,5605)").add(ESLVal.list(_v10)));
          else return error(new ESLVal("case error at Pos(5471,5605)").add(ESLVal.list(_v10)));
          }
          default: return error(new ESLVal("case error at Pos(5471,5605)").add(ESLVal.list(_v10)));
        }
        }
      else if(_v10.isNil())
        return new ESLVal("");
      else return error(new ESLVal("case error at Pos(5471,5605)").add(ESLVal.list(_v10)));
      }
    }
  });
  private static ESLVal ppDecs = new ESLVal(new Function(new ESLVal("ppDecs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal decs = $args[0];
  ESLVal env = $args[1];
  {ESLVal _v11 = decs;
        
        if(_v11.isCons())
        {ESLVal $44 = _v11.head();
          ESLVal $45 = _v11.tail();
          
          switch($44.termName) {
          case "Dec": {ESLVal $49 = $44.termRef(0);
            ESLVal $48 = $44.termRef(1);
            ESLVal $47 = $44.termRef(2);
            ESLVal $46 = $44.termRef(3);
            
            {ESLVal l = $49;
            
            {ESLVal n = $48;
            
            {ESLVal t = $47;
            
            {ESLVal d = $46;
            
            {ESLVal _v1108 = $45;
            
            return n.add(new ESLVal("::").add(ppType.apply(t,env).add(new ESLVal("; ").add(ppDecs.apply(_v1108,env)))));
          }
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(5646,5760)").add(ESLVal.list(_v11)));
        }
        }
      else if(_v11.isNil())
        return new ESLVal("");
      else return error(new ESLVal("case error at Pos(5646,5760)").add(ESLVal.list(_v11)));
      }
    }
  });
  private static ESLVal ppType = new ESLVal(new Function(new ESLVal("ppType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  ESLVal env = $args[1];
  if(getTypeName.apply(t,env).neql($null).boolVal)
        return getTypeName.apply(t,env);
        else
          {ESLVal _v12 = t;
            
            switch(_v12.termName) {
            case "ActType": {ESLVal $119 = _v12.termRef(0);
              ESLVal $118 = _v12.termRef(1);
              ESLVal $117 = _v12.termRef(2);
              
              {ESLVal l = $119;
              
              {ESLVal decs = $118;
              
              {ESLVal handlers = $117;
              
              return new ESLVal("Act { ").add(ppHandlers.apply(handlers,env).add(new ESLVal(" }")));
            }
            }
            }
            }
          case "ApplyType": {ESLVal $116 = _v12.termRef(0);
              ESLVal $115 = _v12.termRef(1);
              ESLVal $114 = _v12.termRef(2);
              
              {ESLVal l = $116;
              
              {ESLVal n = $115;
              
              {ESLVal args = $114;
              
              return n.add(map.apply(ppType0.apply(env),args));
            }
            }
            }
            }
          case "ApplyTypeFun": {ESLVal $113 = _v12.termRef(0);
              ESLVal $112 = _v12.termRef(1);
              ESLVal $111 = _v12.termRef(2);
              
              {ESLVal l = $113;
              
              {ESLVal op = $112;
              
              {ESLVal args = $111;
              
              return ppType.apply(op,env).add(map.apply(ppType0.apply(env),args));
            }
            }
            }
            }
          case "ArrayType": {ESLVal $110 = _v12.termRef(0);
              ESLVal $109 = _v12.termRef(1);
              
              {ESLVal l = $110;
              
              {ESLVal _v1107 = $109;
              
              return new ESLVal("Array[").add(ppType.apply(_v1107,env).add(new ESLVal("]")));
            }
            }
            }
          case "BagType": {ESLVal $108 = _v12.termRef(0);
              ESLVal $107 = _v12.termRef(1);
              
              {ESLVal l = $108;
              
              {ESLVal _v1106 = $107;
              
              return new ESLVal("Set{").add(ppType.apply(_v1106,env).add(new ESLVal("}")));
            }
            }
            }
          case "BoolType": {ESLVal $106 = _v12.termRef(0);
              
              {ESLVal l = $106;
              
              return new ESLVal("Bool");
            }
            }
          case "ExtendedAct": {ESLVal $105 = _v12.termRef(0);
              ESLVal $104 = _v12.termRef(1);
              ESLVal $103 = _v12.termRef(2);
              ESLVal $102 = _v12.termRef(3);
              
              {ESLVal l = $105;
              
              {ESLVal parent = $104;
              
              {ESLVal decs = $103;
              
              {ESLVal handlers = $102;
              
              return new ESLVal("Act extends ").add(ppType.apply(parent,env).add(new ESLVal(" { ").add(ppHandlers.apply(handlers,env).add(new ESLVal(" }")))));
            }
            }
            }
            }
            }
          case "FloatType": {ESLVal $101 = _v12.termRef(0);
              
              {ESLVal l = $101;
              
              return new ESLVal("Float");
            }
            }
          case "FieldType": {ESLVal $100 = _v12.termRef(0);
              ESLVal $99 = _v12.termRef(1);
              ESLVal $98 = _v12.termRef(2);
              
              {ESLVal l = $100;
              
              {ESLVal n = $99;
              
              {ESLVal _v1105 = $98;
              
              return n.add(new ESLVal("::").add(ppType.apply(_v1105,env)));
            }
            }
            }
            }
          case "ForallType": {ESLVal $97 = _v12.termRef(0);
              ESLVal $96 = _v12.termRef(1);
              ESLVal $95 = _v12.termRef(2);
              
              {ESLVal l = $97;
              
              {ESLVal ns = $96;
              
              {ESLVal _v1104 = $95;
              
              return new ESLVal("Forall").add(ns.add(new ESLVal(".").add(ppType.apply(_v1104,env))));
            }
            }
            }
            }
          case "FunType": {ESLVal $94 = _v12.termRef(0);
              ESLVal $93 = _v12.termRef(1);
              ESLVal $92 = _v12.termRef(2);
              
              {ESLVal l = $94;
              
              {ESLVal d = $93;
              
              {ESLVal r = $92;
              
              return map.apply(ppType0.apply(env),d).add(new ESLVal("->").add(ppType.apply(r,env)));
            }
            }
            }
            }
          case "TaggedFunType": {ESLVal $91 = _v12.termRef(0);
              ESLVal $90 = _v12.termRef(1);
              ESLVal $89 = _v12.termRef(2);
              ESLVal $88 = _v12.termRef(3);
              
              {ESLVal l = $91;
              
              {ESLVal d = $90;
              
              {ESLVal p = $89;
              
              {ESLVal r = $88;
              
              return map.apply(ppType0.apply(env),d).add(new ESLVal("->").add(ppType.apply(r,env)));
            }
            }
            }
            }
            }
          case "IntType": {ESLVal $87 = _v12.termRef(0);
              
              {ESLVal l = $87;
              
              return new ESLVal("Int");
            }
            }
          case "ListType": {ESLVal $86 = _v12.termRef(0);
              ESLVal $85 = _v12.termRef(1);
              
              {ESLVal l = $86;
              
              {ESLVal _v1103 = $85;
              
              return new ESLVal("[").add(ppType.apply(_v1103,env).add(new ESLVal("]")));
            }
            }
            }
          case "NullType": {ESLVal $84 = _v12.termRef(0);
              
              {ESLVal l = $84;
              
              return new ESLVal("Null");
            }
            }
          case "ObserverType": {ESLVal $83 = _v12.termRef(0);
              ESLVal $82 = _v12.termRef(1);
              ESLVal $81 = _v12.termRef(2);
              
              {ESLVal l = $83;
              
              {ESLVal s = $82;
              
              {ESLVal m = $81;
              
              return new ESLVal("Observer[").add(ppType.apply(s,env).add(new ESLVal(",").add(ppType.apply(m,env).add(new ESLVal("]")))));
            }
            }
            }
            }
          case "ObservedType": {ESLVal $80 = _v12.termRef(0);
              ESLVal $79 = _v12.termRef(1);
              ESLVal $78 = _v12.termRef(2);
              
              {ESLVal l = $80;
              
              {ESLVal s = $79;
              
              {ESLVal m = $78;
              
              return new ESLVal("Observed[").add(ppType.apply(s,env).add(new ESLVal(",").add(ppType.apply(m,env).add(new ESLVal("]")))));
            }
            }
            }
            }
          case "RecType": {ESLVal $77 = _v12.termRef(0);
              ESLVal $76 = _v12.termRef(1);
              ESLVal $75 = _v12.termRef(2);
              
              {ESLVal l = $77;
              
              {ESLVal n = $76;
              
              {ESLVal _v1102 = $75;
              
              return new ESLVal("rec ").add(n.add(new ESLVal(".").add(ppType.apply(_v1102,env))));
            }
            }
            }
            }
          case "RecordType": {ESLVal $74 = _v12.termRef(0);
              ESLVal $73 = _v12.termRef(1);
              
              {ESLVal l = $74;
              
              {ESLVal fs = $73;
              
              return new ESLVal("{").add(ppDecs.apply(fs,env).add(new ESLVal("}")));
            }
            }
            }
          case "SetType": {ESLVal $72 = _v12.termRef(0);
              ESLVal $71 = _v12.termRef(1);
              
              {ESLVal l = $72;
              
              {ESLVal _v1101 = $71;
              
              return new ESLVal("Set{").add(ppType.apply(_v1101,env).add(new ESLVal("}")));
            }
            }
            }
          case "StrType": {ESLVal $70 = _v12.termRef(0);
              
              {ESLVal l = $70;
              
              return new ESLVal("Str");
            }
            }
          case "TableType": {ESLVal $69 = _v12.termRef(0);
              ESLVal $68 = _v12.termRef(1);
              ESLVal $67 = _v12.termRef(2);
              
              {ESLVal l = $69;
              
              {ESLVal k = $68;
              
              {ESLVal v = $67;
              
              return new ESLVal("Hash[").add(ppType.apply(k,env).add(new ESLVal(",").add(ppType.apply(v,env).add(new ESLVal("]")))));
            }
            }
            }
            }
          case "TermType": {ESLVal $66 = _v12.termRef(0);
              ESLVal $65 = _v12.termRef(1);
              ESLVal $64 = _v12.termRef(2);
              
              {ESLVal l = $66;
              
              {ESLVal n = $65;
              
              {ESLVal ts = $64;
              
              return n.add(map.apply(ppType0.apply(env),ts));
            }
            }
            }
            }
          case "TypeFun": {ESLVal $63 = _v12.termRef(0);
              ESLVal $62 = _v12.termRef(1);
              ESLVal $61 = _v12.termRef(2);
              
              {ESLVal l = $63;
              
              {ESLVal ns = $62;
              
              {ESLVal _v1100 = $61;
              
              return new ESLVal("Fun").add(ns.add(new ESLVal(".").add(ppType.apply(_v1100,env))));
            }
            }
            }
            }
          case "UnfoldType": {ESLVal $60 = _v12.termRef(0);
              ESLVal $59 = _v12.termRef(1);
              
              {ESLVal l = $60;
              
              {ESLVal _v1099 = $59;
              
              return new ESLVal("unfold ").add(ppType.apply(_v1099,env));
            }
            }
            }
          case "UnionType": {ESLVal $58 = _v12.termRef(0);
              ESLVal $57 = _v12.termRef(1);
              
              {ESLVal l = $58;
              
              {ESLVal ts = $57;
              
              return new ESLVal("union ").add(map.apply(ppType0.apply(env),ts));
            }
            }
            }
          case "VarType": {ESLVal $56 = _v12.termRef(0);
              ESLVal $55 = _v12.termRef(1);
              
              {ESLVal l = $56;
              
              {ESLVal n = $55;
              
              return n;
            }
            }
            }
          case "VoidType": {ESLVal $54 = _v12.termRef(0);
              
              {ESLVal l = $54;
              
              return new ESLVal("Void");
            }
            }
          case "UnionRef": {ESLVal $53 = _v12.termRef(0);
              ESLVal $52 = _v12.termRef(1);
              ESLVal $51 = _v12.termRef(2);
              
              {ESLVal l = $53;
              
              {ESLVal _v1098 = $52;
              
              {ESLVal n = $51;
              
              return ppType.apply(_v1098,env).add(new ESLVal(".").add(n));
            }
            }
            }
            }
          case "TypeClosure": {ESLVal $50 = _v12.termRef(0);
              
              {ESLVal f = $50;
              
              return f.add(new ESLVal(""));
            }
            }
            default: {ESLVal x = _v12;
              
              return new ESLVal("<unknown ").add(x.add(new ESLVal(">")));
            }
          }
          }
    }
  });
  private static ESLVal typeEnv = new ESLVal(new Function(new ESLVal("typeEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal defs = $args[0];
  {ESLVal _v13 = defs;
        
        if(_v13.isCons())
        {ESLVal $120 = _v13.head();
          ESLVal $121 = _v13.tail();
          
          switch($120.termName) {
          case "TypeBind": {ESLVal $129 = $120.termRef(0);
            ESLVal $128 = $120.termRef(1);
            ESLVal $127 = $120.termRef(2);
            ESLVal $126 = $120.termRef(3);
            
            {ESLVal l = $129;
            
            {ESLVal n = $128;
            
            {ESLVal t = $127;
            
            {ESLVal e = $126;
            
            {ESLVal ds = $121;
            
            return typeEnv.apply(ds).cons(new ESLVal("Map",n,t));
          }
          }
          }
          }
          }
          }
        case "DataBind": {ESLVal $125 = $120.termRef(0);
            ESLVal $124 = $120.termRef(1);
            ESLVal $123 = $120.termRef(2);
            ESLVal $122 = $120.termRef(3);
            
            {ESLVal l = $125;
            
            {ESLVal n = $124;
            
            {ESLVal t = $123;
            
            {ESLVal e = $122;
            
            {ESLVal ds = $121;
            
            return typeEnv.apply(ds).cons(new ESLVal("Map",n,t));
          }
          }
          }
          }
          }
          }
          default: {ESLVal b = $120;
            
            {ESLVal ds = $121;
            
            return typeEnv.apply(ds);
          }
          }
        }
        }
      else if(_v13.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(8034,8277)").add(ESLVal.list(_v13)));
      }
    }
  });
  private static ESLVal cnstrEnv = new ESLVal(new Function(new ESLVal("cnstrEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal defs = $args[0];
  ESLVal env = $args[1];
  {ESLVal _v14 = defs;
        
        if(_v14.isCons())
        {ESLVal $130 = _v14.head();
          ESLVal $131 = _v14.tail();
          
          switch($130.termName) {
          case "TypeBind": {ESLVal $139 = $130.termRef(0);
            ESLVal $138 = $130.termRef(1);
            ESLVal $137 = $130.termRef(2);
            ESLVal $136 = $130.termRef(3);
            
            switch($137.termName) {
            case "RecType": {ESLVal $144 = $137.termRef(0);
              ESLVal $143 = $137.termRef(1);
              ESLVal $142 = $137.termRef(2);
              
              switch($142.termName) {
              case "UnionType": {ESLVal $146 = $142.termRef(0);
                ESLVal $145 = $142.termRef(1);
                
                {ESLVal l = $139;
                
                {ESLVal n = $138;
                
                {ESLVal ll = $144;
                
                {ESLVal m = $143;
                
                {ESLVal lll = $146;
                
                {ESLVal ts = $145;
                
                {ESLVal e = $136;
                
                {ESLVal ds = $131;
                
                return getConstructors.apply(l,lookupType.apply(n,env),lookupType.apply(n,env)).add(cnstrEnv.apply(ds,env));
              }
              }
              }
              }
              }
              }
              }
              }
              }
              default: {ESLVal l = $139;
                
                {ESLVal n = $138;
                
                {ESLVal t = $137;
                
                {ESLVal e = $136;
                
                {ESLVal ds = $131;
                
                return cnstrEnv.apply(ds,env);
              }
              }
              }
              }
              }
            }
            }
          case "UnionType": {ESLVal $141 = $137.termRef(0);
              ESLVal $140 = $137.termRef(1);
              
              {ESLVal l = $139;
              
              {ESLVal n = $138;
              
              {ESLVal lll = $141;
              
              {ESLVal ts = $140;
              
              {ESLVal e = $136;
              
              {ESLVal ds = $131;
              
              return getConstructors.apply(l,lookupType.apply(n,env),lookupType.apply(n,env)).add(cnstrEnv.apply(ds,env));
            }
            }
            }
            }
            }
            }
            }
            default: {ESLVal l = $139;
              
              {ESLVal n = $138;
              
              {ESLVal t = $137;
              
              {ESLVal e = $136;
              
              {ESLVal ds = $131;
              
              return cnstrEnv.apply(ds,env);
            }
            }
            }
            }
            }
          }
          }
        case "DataBind": {ESLVal $135 = $130.termRef(0);
            ESLVal $134 = $130.termRef(1);
            ESLVal $133 = $130.termRef(2);
            ESLVal $132 = $130.termRef(3);
            
            {ESLVal l = $135;
            
            {ESLVal n = $134;
            
            {ESLVal t = $133;
            
            {ESLVal e = $132;
            
            {ESLVal ds = $131;
            
            return getConstructors.apply(l,lookupType.apply(n,env),lookupType.apply(n,env)).add(cnstrEnv.apply(ds,env));
          }
          }
          }
          }
          }
          }
          default: {ESLVal b = $130;
            
            {ESLVal ds = $131;
            
            return cnstrEnv.apply(ds,env);
          }
          }
        }
        }
      else if(_v14.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(8409,9042)").add(ESLVal.list(_v14)));
      }
    }
  });
  private static ESLVal getConstructors = new ESLVal(new Function(new ESLVal("getConstructors"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal dataType = $args[1];
  ESLVal t = $args[2];
  {ESLVal _v15 = t;
        
        switch(_v15.termName) {
        case "RecType": {ESLVal $154 = _v15.termRef(0);
          ESLVal $153 = _v15.termRef(1);
          ESLVal $152 = _v15.termRef(2);
          
          {ESLVal _v1095 = $154;
          
          {ESLVal n = $153;
          
          {ESLVal _v1096 = $152;
          
          return getConstructors.apply(_v1095,dataType,_v1096);
        }
        }
        }
        }
      case "TypeFun": {ESLVal $151 = _v15.termRef(0);
          ESLVal $150 = _v15.termRef(1);
          ESLVal $149 = _v15.termRef(2);
          
          {ESLVal _v1093 = $151;
          
          {ESLVal ns = $150;
          
          {ESLVal _v1094 = $149;
          
          return getConstructors.apply(_v1093,dataType,_v1094);
        }
        }
        }
        }
      case "UnionType": {ESLVal $148 = _v15.termRef(0);
          ESLVal $147 = _v15.termRef(1);
          
          {ESLVal _v1090 = $148;
          
          {ESLVal ts = $147;
          
          return map.apply(new ESLVal(new Function(new ESLVal("fun195"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1091 = $args[0];
          {ESLVal _v16 = _v1091;
                
                switch(_v16.termName) {
                case "TermType": {ESLVal $157 = _v16.termRef(0);
                  ESLVal $156 = _v16.termRef(1);
                  ESLVal $155 = _v16.termRef(2);
                  
                  {ESLVal _v1092 = $157;
                  
                  {ESLVal n = $156;
                  
                  {ESLVal tts = $155;
                  
                  return new ESLVal("Map",n,dataType);
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(9561,9627)").add(ESLVal.list(_v16)));
              }
              }
            }
          }),ts);
        }
        }
        }
        default: {ESLVal _v1097 = _v15;
          
          return error(new ESLVal("TypeError",l,new ESLVal("cannot extract constructors from ").add(ppType.apply(_v1097,ESLVal.list()))));
        }
      }
      }
    }
  });
  private static ESLVal checkFreeTypes = new ESLVal(new Function(new ESLVal("checkFreeTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  {ESLVal dom = typeEnvDom.apply(e);
        ESLVal ran = typeEnvRan.apply(e);
        
        {ESLVal freeNames = removeAll.apply(dom,flatten.apply(map.apply(typeFV,ran)));
        
        if(freeNames.eql($nil).boolVal)
        return $null;
        else
          return error(new ESLVal("TypeError",new ESLVal("Pos",$zero,$zero),new ESLVal("Unbound Types: ").add(freeNames)));
      }
      }
    }
  });
  private static ESLVal checkSingletonTypes = new ESLVal(new Function(new ESLVal("checkSingletonTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  {ESLVal _v17 = e;
        
        if(_v17.isCons())
        {ESLVal $158 = _v17.head();
          ESLVal $159 = _v17.tail();
          
          switch($158.termName) {
          case "Map": {ESLVal $161 = $158.termRef(0);
            ESLVal $160 = $158.termRef(1);
            
            {ESLVal n = $161;
            
            {ESLVal t = $160;
            
            {ESLVal _v1089 = $159;
            
            if(member.apply(n,typeEnvDom.apply(_v1089)).boolVal)
            return error(new ESLVal("TypeError",new ESLVal("Pos",$zero,$zero),new ESLVal("Duplicate type name: ").add(n)));
            else
              return checkSingletonTypes.apply(_v1089);
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(10331,10552)").add(ESLVal.list(_v17)));
        }
        }
      else if(_v17.isNil())
        return $null;
      else return error(new ESLVal("case error at Pos(10331,10552)").add(ESLVal.list(_v17)));
      }
    }
  });
  private static ESLVal checkSingletonConstructors = new ESLVal(new Function(new ESLVal("checkSingletonConstructors"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1081 = $args[0];
  {ESLVal _v18 = _v1081;
        
        if(_v18.isCons())
        {ESLVal $162 = _v18.head();
          ESLVal $163 = _v18.tail();
          
          switch($162.termName) {
          case "Map": {ESLVal $165 = $162.termRef(0);
            ESLVal $164 = $162.termRef(1);
            
            {ESLVal n = $165;
            
            {ESLVal t = $164;
            
            {ESLVal _v1082 = $163;
            
            if(member.apply(n,typeEnvDom.apply(_v1082)).boolVal)
            { LetRec letrec = new LetRec() {
              ESLVal throwError = new ESLVal(new Function(new ESLVal("throwError"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal _v1083 = $args[0];
                {ESLVal _v19 = _v1083;
                      
                      switch(_v19.termName) {
                      case "UnionType": {ESLVal $176 = _v19.termRef(0);
                        ESLVal $175 = _v19.termRef(1);
                        
                        {ESLVal l = $176;
                        
                        {ESLVal ts = $175;
                        
                        return error(new ESLVal("TypeError",l,new ESLVal("Duplicate constructor name: ").add(n)));
                      }
                      }
                      }
                    case "ForallType": {ESLVal $174 = _v19.termRef(0);
                        ESLVal $173 = _v19.termRef(1);
                        ESLVal $172 = _v19.termRef(2);
                        
                        {ESLVal l = $174;
                        
                        {ESLVal ns = $173;
                        
                        {ESLVal _v1087 = $172;
                        
                        return throwError.apply(_v1087);
                      }
                      }
                      }
                      }
                    case "RecType": {ESLVal $171 = _v19.termRef(0);
                        ESLVal $170 = _v19.termRef(1);
                        ESLVal $169 = _v19.termRef(2);
                        
                        {ESLVal l = $171;
                        
                        {ESLVal _v1085 = $170;
                        
                        {ESLVal _v1086 = $169;
                        
                        return throwError.apply(_v1086);
                      }
                      }
                      }
                      }
                    case "TypeFun": {ESLVal $168 = _v19.termRef(0);
                        ESLVal $167 = _v19.termRef(1);
                        ESLVal $166 = _v19.termRef(2);
                        
                        {ESLVal l = $168;
                        
                        {ESLVal ns = $167;
                        
                        {ESLVal _v1084 = $166;
                        
                        return throwError.apply(_v1084);
                      }
                      }
                      }
                      }
                      default: {ESLVal _v1088 = _v19;
                        
                        return error(new ESLVal("Duplicate constructor name: ").add(n.add(new ESLVal(" ").add(_v1088))));
                      }
                    }
                    }
                  }
                });
              
              public ESLVal get(String name) {
                switch(name) {
                  case "throwError": return throwError;
                  
                  default: throw new Error("cannot find letrec binding");
                }
                }
              };
            ESLVal throwError = letrec.get("throwError");
            
              return throwError.apply(t);}
            
            else
              return checkSingletonConstructors.apply(_v1082);
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(10665,11320)").add(ESLVal.list(_v18)));
        }
        }
      else if(_v18.isNil())
        return $null;
      else return error(new ESLVal("case error at Pos(10665,11320)").add(ESLVal.list(_v18)));
      }
    }
  });
  private static ESLVal valueDefs = new ESLVal(new Function(new ESLVal("valueDefs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal defs = $args[0];
  {ESLVal _v20 = defs;
        
        if(_v20.isCons())
        {ESLVal $177 = _v20.head();
          ESLVal $178 = _v20.tail();
          
          switch($177.termName) {
          case "TypeBind": {ESLVal $190 = $177.termRef(0);
            ESLVal $189 = $177.termRef(1);
            ESLVal $188 = $177.termRef(2);
            ESLVal $187 = $177.termRef(3);
            
            {ESLVal l = $190;
            
            {ESLVal n = $189;
            
            {ESLVal t = $188;
            
            {ESLVal e = $187;
            
            {ESLVal ds = $178;
            
            return valueDefs.apply(ds);
          }
          }
          }
          }
          }
          }
        case "DataBind": {ESLVal $186 = $177.termRef(0);
            ESLVal $185 = $177.termRef(1);
            ESLVal $184 = $177.termRef(2);
            ESLVal $183 = $177.termRef(3);
            
            {ESLVal l1 = $186;
            
            {ESLVal n = $185;
            
            {ESLVal t = $184;
            
            {ESLVal e = $183;
            
            {ESLVal ds = $178;
            
            return valueDefs.apply(ds);
          }
          }
          }
          }
          }
          }
        case "CnstrBind": {ESLVal $182 = $177.termRef(0);
            ESLVal $181 = $177.termRef(1);
            ESLVal $180 = $177.termRef(2);
            ESLVal $179 = $177.termRef(3);
            
            {ESLVal l1 = $182;
            
            {ESLVal n = $181;
            
            {ESLVal t = $180;
            
            {ESLVal e = $179;
            
            {ESLVal ds = $178;
            
            return valueDefs.apply(ds);
          }
          }
          }
          }
          }
          }
          default: {ESLVal b = $177;
            
            {ESLVal ds = $178;
            
            return valueDefs.apply(ds).cons(b);
          }
          }
        }
        }
      else if(_v20.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(11360,11670)").add(ESLVal.list(_v20)));
      }
    }
  });
  private static ESLVal valueDefsToTEnv = new ESLVal(new Function(new ESLVal("valueDefsToTEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1076 = $args[0];
  ESLVal _v1077 = $args[1];
  ESLVal _v1078 = $args[2];
  ESLVal _v1079 = $args[3];
  ESLVal _v1080 = $args[4];
  {ESLVal _v21 = _v1076;
        
        if(_v21.isCons())
        {ESLVal $191 = _v21.head();
          ESLVal $192 = _v21.tail();
          
          switch($191.termName) {
          case "FunBinds": {ESLVal $206 = $191.termRef(0);
            ESLVal $205 = $191.termRef(1);
            
            if($205.isCons())
            {ESLVal $207 = $205.head();
              ESLVal $208 = $205.tail();
              
              switch($207.termName) {
              case "FunCase": {ESLVal $213 = $207.termRef(0);
                ESLVal $212 = $207.termRef(1);
                ESLVal $211 = $207.termRef(2);
                ESLVal $210 = $207.termRef(3);
                ESLVal $209 = $207.termRef(4);
                
                {ESLVal n = $206;
                
                {ESLVal l = $213;
                
                {ESLVal args = $212;
                
                {ESLVal t = $211;
                
                {ESLVal g = $210;
                
                {ESLVal e = $209;
                
                {ESLVal cases = $208;
                
                {ESLVal ds = $192;
                
                return valueDefsToTEnv.apply(ds,_v1077,_v1078,_v1079,_v1080).cons(new ESLVal("Map",n,substTypeEnv.apply(_v1080,t)));
              }
              }
              }
              }
              }
              }
              }
              }
              }
              default: return error(new ESLVal("case error at Pos(11777,12310)").add(ESLVal.list(_v21)));
            }
            }
          else if($205.isNil())
            return error(new ESLVal("case error at Pos(11777,12310)").add(ESLVal.list(_v21)));
          else return error(new ESLVal("case error at Pos(11777,12310)").add(ESLVal.list(_v21)));
          }
        case "FunBind": {ESLVal $204 = $191.termRef(0);
            ESLVal $203 = $191.termRef(1);
            ESLVal $202 = $191.termRef(2);
            ESLVal $201 = $191.termRef(3);
            ESLVal $200 = $191.termRef(4);
            ESLVal $199 = $191.termRef(5);
            ESLVal $198 = $191.termRef(6);
            
            {ESLVal l = $204;
            
            {ESLVal n = $203;
            
            {ESLVal ps = $202;
            
            {ESLVal t = $201;
            
            {ESLVal st = $200;
            
            {ESLVal b = $199;
            
            {ESLVal g = $198;
            
            {ESLVal ds = $192;
            
            return valueDefsToTEnv.apply(ds,_v1077,_v1078,_v1079,_v1080).cons(new ESLVal("Map",n,substTypeEnv.apply(_v1080,t)));
          }
          }
          }
          }
          }
          }
          }
          }
          }
        case "Binding": {ESLVal $197 = $191.termRef(0);
            ESLVal $196 = $191.termRef(1);
            ESLVal $195 = $191.termRef(2);
            ESLVal $194 = $191.termRef(3);
            ESLVal $193 = $191.termRef(4);
            
            {ESLVal l = $197;
            
            {ESLVal n = $196;
            
            {ESLVal t = $195;
            
            {ESLVal st = $194;
            
            {ESLVal e = $193;
            
            {ESLVal ds = $192;
            
            return valueDefsToTEnv.apply(ds,_v1077,_v1078,_v1079,_v1080).cons(new ESLVal("Map",n,substTypeEnv.apply(_v1080,t)));
          }
          }
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(11777,12310)").add(ESLVal.list(_v21)));
        }
        }
      else if(_v21.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(11777,12310)").add(ESLVal.list(_v21)));
      }
    }
  });
  private static ESLVal getCache = new ESLVal(new Function(new ESLVal("getCache"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      {ESLVal cache = edb.ref("getProperty").apply(new ESLVal("typeCheckCache"));
        
        if(cache.eql($null).boolVal)
        return emptyTable;
        else
          return cache;
      }
    }
  });
  private static ESLVal setCache = new ESLVal(new Function(new ESLVal("setCache"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal cache = $args[0];
  return edb.ref("setProperty").apply(new ESLVal("typeCheckCache"),cache);
    }
  });
  private static ESLVal updateCache = new ESLVal(new Function(new ESLVal("updateCache"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal path = $args[0];
  ESLVal record = $args[1];
  ESLVal cache = $args[2];
  {ESLVal _v1075 = addEntry.apply(path,record,cache);
        
        {setCache.apply(_v1075);
      return _v1075;}
      }
    }
  });
  public static ESLVal typeCheckModule = new ESLVal(new Function(new ESLVal("typeCheckModule"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal path = $args[0];
  {print.apply(new ESLVal("[ type check ").add(path.add(new ESLVal("]"))));
      return typeCheckModuleInternal.apply(path,getCache.apply(),new ESLVal(new Function(new ESLVal("fun196"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1071 = $args[0];
        ESLVal _v1072 = $args[1];
        ESLVal _v1073 = $args[2];
        ESLVal _v1074 = $args[3];
        return $null;
          }
        }));}
    }
  });
  private static ESLVal typeCheckModuleInternal = new ESLVal(new Function(new ESLVal("typeCheckModuleInternal"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal path = $args[0];
  ESLVal cache = $args[1];
  ESLVal handler = $args[2];
  if(hasEntry.apply(path,cache).boolVal)
        {ESLVal _v22 = lookup.apply(path,cache);
          
          switch(_v22.termName) {
          case "Typed": {ESLVal $217 = _v22.termRef(0);
            ESLVal $216 = _v22.termRef(1);
            ESLVal $215 = _v22.termRef(2);
            ESLVal $214 = _v22.termRef(3);
            
            {ESLVal m = $217;
            
            {ESLVal vEnv = $216;
            
            {ESLVal cEnv = $215;
            
            {ESLVal tEnv = $214;
            
            return handler.apply(cache,vEnv,cEnv,tEnv);
          }
          }
          }
          }
          }
        case "Undefined": {
            return error(new ESLVal("recursive reference to ").add(path));
          }
          default: return error(new ESLVal("case error at Pos(13312,13546)").add(ESLVal.list(_v22)));
        }
        }
        else
          {ESLVal m = parse.apply(path);
            
            return typeCheckModuleCache.apply(m,updateCache.apply(path,new ESLVal("Undefined",new ESLVal[]{}),cache),new ESLVal(new Function(new ESLVal("fun197"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v1067 = $args[0];
            ESLVal _v1068 = $args[1];
            ESLVal _v1069 = $args[2];
            ESLVal _v1070 = $args[3];
            return handler.apply(updateCache.apply(path,new ESLVal("Typed",m,_v1068,_v1069,_v1070),_v1067),_v1068,_v1069,_v1070);
              }
            }));
          }
    }
  });
  public static ESLVal typeCheckEntryPoint = new ESLVal(new Function(new ESLVal("typeCheckEntryPoint"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal module = $args[0];
  return typeCheckModuleCache.apply(module,getCache.apply(),new ESLVal(new Function(new ESLVal("fun198"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1063 = $args[0];
        ESLVal _v1064 = $args[1];
        ESLVal _v1065 = $args[2];
        ESLVal _v1066 = $args[3];
        return $null;
          }
        }));
    }
  });
  private static ESLVal typeCheckModuleCache = new ESLVal(new Function(new ESLVal("typeCheckModuleCache"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal module = $args[0];
  ESLVal cache = $args[1];
  ESLVal handler = $args[2];
  return typeCheckModule0.apply(module,cache,new ESLVal(new Function(new ESLVal("fun199"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1059 = $args[0];
        ESLVal _v1060 = $args[1];
        ESLVal _v1061 = $args[2];
        ESLVal _v1062 = $args[3];
        {ESLVal _v23 = module;
              
              switch(_v23.termName) {
              case "Module": {ESLVal $224 = _v23.termRef(0);
                ESLVal $223 = _v23.termRef(1);
                ESLVal $222 = _v23.termRef(2);
                ESLVal $221 = _v23.termRef(3);
                ESLVal $220 = _v23.termRef(4);
                ESLVal $219 = _v23.termRef(5);
                ESLVal $218 = _v23.termRef(6);
                
                {ESLVal path = $224;
                
                {ESLVal name = $223;
                
                {ESLVal exports = $222;
                
                {ESLVal imports = $221;
                
                {ESLVal x = $220;
                
                {ESLVal y = $219;
                
                {ESLVal defs = $218;
                
                return handler.apply(_v1059,restrictTypeEnv.apply(_v1060,exports),restrictTypeEnv.apply(_v1061,exports),restrictTypeEnv.apply(_v1062,exports));
              }
              }
              }
              }
              }
              }
              }
              }
              default: return error(new ESLVal("case error at Pos(14259,14517)").add(ESLVal.list(_v23)));
            }
            }
          }
        }));
    }
  });
  private static ESLVal typeCheckModule0 = new ESLVal(new Function(new ESLVal("typeCheckModule0"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal module = $args[0];
  ESLVal cache = $args[1];
  ESLVal handler = $args[2];
  { LetRec letrec = new LetRec() {
        ESLVal _v1036 = new ESLVal(new Function(new ESLVal("processImports"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1046 = $args[0];
          ESLVal _v1047 = $args[1];
          ESLVal _v1048 = $args[2];
          {ESLVal _v24 = _v1046;
                
                if(_v24.isCons())
                {ESLVal $225 = _v24.head();
                  ESLVal $226 = _v24.tail();
                  
                  {ESLVal path = $225;
                  
                  {ESLVal _v1049 = $226;
                  
                  {ESLVal _v1050 = _v1049;
                  
                  return typeCheckModuleInternal.apply(path,_v1047,new ESLVal(new Function(new ESLVal("fun200"),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      ESLVal _v1051 = $args[0];
                  ESLVal _v1052 = $args[1];
                  ESLVal _v1053 = $args[2];
                  ESLVal _v1054 = $args[3];
                  return _v1036.apply(_v1050,_v1051,new ESLVal(new Function(new ESLVal("fun201"),getSelf()) {
                          public ESLVal apply(ESLVal... $args) {
                            ESLVal _v1055 = $args[0];
                        ESLVal _v1056 = $args[1];
                        ESLVal _v1057 = $args[2];
                        ESLVal _v1058 = $args[3];
                        return _v1048.apply(_v1055,_v1056.add(_v1052),_v1057.add(_v1053),_v1058.add(_v1054));
                          }
                        }));
                    }
                  }));
                }
                }
                }
                }
              else if(_v24.isNil())
                return _v1048.apply(_v1047,$nil,$nil,$nil);
              else return error(new ESLVal("case error at Pos(14897,15454)").add(ESLVal.list(_v24)));
              }
            }
          });
        ESLVal _v1037 = new ESLVal(new Function(new ESLVal("main"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              {ESLVal _v25 = module;
                
                switch(_v25.termName) {
                case "Module": {ESLVal $233 = _v25.termRef(0);
                  ESLVal $232 = _v25.termRef(1);
                  ESLVal $231 = _v25.termRef(2);
                  ESLVal $230 = _v25.termRef(3);
                  ESLVal $229 = _v25.termRef(4);
                  ESLVal $228 = _v25.termRef(5);
                  ESLVal $227 = _v25.termRef(6);
                  
                  {ESLVal path = $233;
                  
                  {ESLVal name = $232;
                  
                  {ESLVal exports = $231;
                  
                  {ESLVal imports = $230;
                  
                  {ESLVal x = $229;
                  
                  {ESLVal y = $228;
                  
                  {ESLVal defs = $227;
                  
                  return _v1036.apply(imports,cache,new ESLVal(new Function(new ESLVal("fun202"),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      ESLVal _v1038 = $args[0];
                  ESLVal _v1039 = $args[1];
                  ESLVal _v1040 = $args[2];
                  ESLVal _v1041 = $args[3];
                  {ESLVal _v1042 = typeEnv.apply(defs);
                        ESLVal _v1043 = mergeFunDefs.apply(defs);
                        
                        {checkDupBindings.apply(_v1043);
                      checkFreeTypes.apply(_v1042.add(_v1041.add(tenv0)));
                      checkSingletonTypes.apply(_v1042);
                      {ESLVal _v1044 = recTypes.apply(_v1042.add(_v1041.add(tenv0)));
                        
                        {ESLVal _v1045 = cnstrEnv.apply(_v1043,_v1044).add(_v1040.add(cnstrEnv0));
                        
                        {checkSingletonConstructors.apply(_v1045);
                      {ESLVal valueEnv = typeCheckValues.apply(valueDefs.apply(_v1043),new ESLVal("NullType",p0),_v1039,_v1044,_v1045);
                        
                        return handler.apply(_v1038,valueEnv,_v1045,_v1044);
                      }}
                      }
                      }}
                      }
                    }
                  }));
                }
                }
                }
                }
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(15483,16623)").add(ESLVal.list(_v25)));
              }
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "_v1036": return _v1036;
            
            case "_v1037": return _v1037;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal _v1036 = letrec.get("_v1036");
      
      ESLVal _v1037 = letrec.get("_v1037");
      
        return _v1037.apply();}
      
    }
  });
  private static ESLVal typeCheckValues = new ESLVal(new Function(new ESLVal("typeCheckValues"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1031 = $args[0];
  ESLVal _v1032 = $args[1];
  ESLVal _v1033 = $args[2];
  ESLVal _v1034 = $args[3];
  ESLVal _v1035 = $args[4];
  {ESLVal valueEnv = valueDefsToTEnv.apply(_v1031,_v1032,$nil,_v1035,_v1034).add(_v1033.add(env0));
        
        {{
        ESLVal _v26 = _v1031;
        while(_v26.isCons()) {
          ESLVal def = _v26.headVal;
          typeCheckDef.apply(def,_v1032,valueEnv,valueEnv,_v1035,_v1034);
          _v26 = _v26.tailVal;}
      }
      return valueEnv;}
      }
    }
  });
  private static ESLVal genericize = new ESLVal(new Function(new ESLVal("genericize"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal t = $args[1];
  if(length.apply(typeFV.apply(t)).eql($zero).boolVal)
        return t;
        else
          return new ESLVal("ForallType",l,typeFV.apply(t),t);
    }
  });
  private static ESLVal checkPatterns = new ESLVal(new Function(new ESLVal("checkPatterns"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal ps = $args[1];
  {ESLVal names = new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal p = $l0.head();
                $l0 = $l0.tail();
                ESLVal $l1 = patternNames.apply(p);
          while(!$l1.isNil()) {
            ESLVal n = $l1.head();
            $l1 = $l1.tail();
            $v.add(n);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(ps);
        
        if(removeDups.apply(names).neql(names).boolVal)
        return error(new ESLVal("TypeError",l,new ESLVal("duplicate pattern variables")));
        else
          return $null;
      }
    }
  });
  private static ESLVal typeCheckDef = new ESLVal(new Function(new ESLVal("typeCheckDef"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1007 = $args[0];
  ESLVal _v1008 = $args[1];
  ESLVal _v1009 = $args[2];
  ESLVal _v1010 = $args[3];
  ESLVal _v1011 = $args[4];
  ESLVal _v1012 = $args[5];
  {ESLVal _v27 = _v1007;
        
        switch(_v27.termName) {
        case "FunBinds": {ESLVal $247 = _v27.termRef(0);
          ESLVal $246 = _v27.termRef(1);
          
          {ESLVal n = $247;
          
          {ESLVal cases = $246;
          
          { LetRec letrec = new LetRec() {
          ESLVal checkArities = new ESLVal(new Function(new ESLVal("checkArities"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v1028 = $args[0];
            ESLVal _v1029 = $args[1];
            {ESLVal _v31 = _v1028;
                  
                  if(_v31.isCons())
                  {ESLVal $257 = _v31.head();
                    ESLVal $258 = _v31.tail();
                    
                    switch($257.termName) {
                    case "FunCase": {ESLVal $263 = $257.termRef(0);
                      ESLVal $262 = $257.termRef(1);
                      ESLVal $261 = $257.termRef(2);
                      ESLVal $260 = $257.termRef(3);
                      ESLVal $259 = $257.termRef(4);
                      
                      {ESLVal l = $263;
                      
                      {ESLVal args = $262;
                      
                      {ESLVal t = $261;
                      
                      {ESLVal g = $260;
                      
                      {ESLVal e = $259;
                      
                      {ESLVal _v1030 = $258;
                      
                      if(_v1029.eql(new ESLVal(-1)).or(length.apply(args).eql(_v1029)).boolVal)
                      return checkArities.apply(_v1030,length.apply(args));
                      else
                        return error(new ESLVal("TypeError",l,new ESLVal("inconsistent overloaded arity")));
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: return error(new ESLVal("case error at Pos(17830,18119)").add(ESLVal.list(_v31)));
                  }
                  }
                else if(_v31.isNil())
                  return $null;
                else return error(new ESLVal("case error at Pos(17830,18119)").add(ESLVal.list(_v31)));
                }
              }
            });
          ESLVal checkLoneVars = new ESLVal(new Function(new ESLVal("checkLoneVars"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v1026 = $args[0];
            {ESLVal _v32 = _v1026;
                  
                  if(_v32.isCons())
                  {ESLVal $264 = _v32.head();
                    ESLVal $265 = _v32.tail();
                    
                    switch($264.termName) {
                    case "FunCase": {ESLVal $270 = $264.termRef(0);
                      ESLVal $269 = $264.termRef(1);
                      ESLVal $268 = $264.termRef(2);
                      ESLVal $267 = $264.termRef(3);
                      ESLVal $266 = $264.termRef(4);
                      
                      {ESLVal l = $270;
                      
                      {ESLVal args = $269;
                      
                      {ESLVal t = $268;
                      
                      {ESLVal g = $267;
                      
                      {ESLVal e = $266;
                      
                      {ESLVal _v1027 = $265;
                      
                      {{
                      ESLVal _v33 = args;
                      while(_v33.isCons()) {
                        ESLVal arg = _v33.headVal;
                        checkLoneVar.apply(arg);
                        _v33 = _v33.tailVal;}
                    }
                    return checkLoneVars.apply(_v1027);}
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: return error(new ESLVal("case error at Pos(18178,18413)").add(ESLVal.list(_v32)));
                  }
                  }
                else if(_v32.isNil())
                  return $null;
                else return error(new ESLVal("case error at Pos(18178,18413)").add(ESLVal.list(_v32)));
                }
              }
            });
          ESLVal checkLoneVar = new ESLVal(new Function(new ESLVal("checkLoneVar"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal p = $args[0];
            {ESLVal _v34 = p;
                  
                  switch(_v34.termName) {
                  case "PVar": {ESLVal $273 = _v34.termRef(0);
                    ESLVal $272 = _v34.termRef(1);
                    ESLVal $271 = _v34.termRef(2);
                    
                    switch($271.termName) {
                    case "VoidType": {ESLVal $274 = $271.termRef(0);
                      
                      {ESLVal l = $273;
                      
                      {ESLVal _v1023 = $272;
                      
                      {ESLVal tl = $274;
                      
                      return error(new ESLVal("TypeError",l,new ESLVal("top level variables should be typed.")));
                    }
                    }
                    }
                    }
                    default: {ESLVal _v1024 = _v34;
                      
                      return $null;
                    }
                  }
                  }
                  default: {ESLVal _v1025 = _v34;
                    
                    return $null;
                  }
                }
                }
              }
            });
          
          public ESLVal get(String name) {
            switch(name) {
              case "checkArities": return checkArities;
              
              case "checkLoneVars": return checkLoneVars;
              
              case "checkLoneVar": return checkLoneVar;
              
              default: throw new Error("cannot find letrec binding");
            }
            }
          };
        ESLVal checkArities = letrec.get("checkArities");
        
        ESLVal checkLoneVars = letrec.get("checkLoneVars");
        
        ESLVal checkLoneVar = letrec.get("checkLoneVar");
        
          {checkArities.apply(cases,new ESLVal(-1));
        return checkLoneVars.apply(cases);}}
        
        }
        }
        }
      case "FunBind": {ESLVal $245 = _v27.termRef(0);
          ESLVal $244 = _v27.termRef(1);
          ESLVal $243 = _v27.termRef(2);
          ESLVal $242 = _v27.termRef(3);
          ESLVal $241 = _v27.termRef(4);
          ESLVal $240 = _v27.termRef(5);
          ESLVal $239 = _v27.termRef(6);
          
          {ESLVal l = $245;
          
          {ESLVal n = $244;
          
          {ESLVal ps = $243;
          
          {ESLVal t = $242;
          
          {ESLVal st = $241;
          
          {ESLVal b = $240;
          
          {ESLVal g = $239;
          
          {checkPatterns.apply(l,ps);
        {ESLVal argTypes = map.apply(new ESLVal(new Function(new ESLVal("fun203"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal p = $args[0];
            {ESLVal _v28 = p;
                  
                  switch(_v28.termName) {
                  case "PVar": {ESLVal $250 = _v28.termRef(0);
                    ESLVal $249 = _v28.termRef(1);
                    ESLVal $248 = _v28.termRef(2);
                    
                    {ESLVal _v1017 = $250;
                    
                    {ESLVal _v1018 = $249;
                    
                    {ESLVal _v1019 = $248;
                    
                    return substTypeEnv.apply(_v1012,_v1019);
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(19045,19111)").add(ESLVal.list(_v28)));
                }
                }
              }
            }),ps);
          ESLVal argNames = map.apply(new ESLVal(new Function(new ESLVal("fun204"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal p = $args[0];
            {ESLVal _v29 = p;
                  
                  switch(_v29.termName) {
                  case "PVar": {ESLVal $253 = _v29.termRef(0);
                    ESLVal $252 = _v29.termRef(1);
                    ESLVal $251 = _v29.termRef(2);
                    
                    {ESLVal _v1014 = $253;
                    
                    {ESLVal _v1015 = $252;
                    
                    {ESLVal _v1016 = $251;
                    
                    return _v1015;
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(19183,19227)").add(ESLVal.list(_v29)));
                }
                }
              }
            }),ps);
          
          {ESLVal bodyType = guardedExpType.apply(l,g,b,_v1008,zipTypeEnv.apply(argNames,argTypes).add(_v1009),_v1011,_v1012);
          
          {ESLVal fType = ((Supplier<ESLVal>)() -> { 
              {ESLVal _v30 = t;
                
                switch(_v30.termName) {
                case "ForallType": {ESLVal $256 = _v30.termRef(0);
                  ESLVal $255 = _v30.termRef(1);
                  ESLVal $254 = _v30.termRef(2);
                  
                  {ESLVal _v1020 = $256;
                  
                  {ESLVal ns = $255;
                  
                  {ESLVal _v1021 = $254;
                  
                  return genericize.apply(_v1020,new ESLVal("FunType",_v1020,argTypes,bodyType));
                }
                }
                }
                }
                default: {ESLVal _v1022 = _v30;
                  
                  return new ESLVal("FunType",l,argTypes,bodyType);
                }
              }
              }
            }).get();
          ESLVal dType = substTypeEnv.apply(_v1012,t);
          
          if(subType.apply(fType,dType).boolVal)
          return $null;
          else
            return error(new ESLVal("TypeError",l,new ESLVal("type of ").add(n.add(new ESLVal("::").add(ppType.apply(fType,_v1012).add(new ESLVal(" does not match declaration ").add(ppType.apply(dType,_v1012))))))));
        }
        }
        }}
        }
        }
        }
        }
        }
        }
        }
        }
      case "Binding": {ESLVal $238 = _v27.termRef(0);
          ESLVal $237 = _v27.termRef(1);
          ESLVal $236 = _v27.termRef(2);
          ESLVal $235 = _v27.termRef(3);
          ESLVal $234 = _v27.termRef(4);
          
          {ESLVal l = $238;
          
          {ESLVal n = $237;
          
          {ESLVal dt = $236;
          
          {ESLVal st = $235;
          
          {ESLVal e = $234;
          
          {ESLVal valueType = expType.apply(e,_v1008,_v1009,_v1011,_v1012);
          
          {ESLVal valueFV = typeFV.apply(valueType);
          ESLVal declaredType = lookupType.apply(n,_v1010);
          
          {ESLVal _v1013 = ((Supplier<ESLVal>)() -> { 
              if(valueFV.eql($nil).boolVal)
                return valueType;
                else
                  return new ESLVal("ForallType",l,valueFV,valueType);
            }).get();
          
          if(subType.apply(_v1013,declaredType).boolVal)
          return $null;
          else
            return error(new ESLVal("TypeError",l,new ESLVal("type of ").add(n.add(new ESLVal(" ").add(ppType.apply(_v1013,_v1012).add(new ESLVal(" does not match declared type = ").add(ppType.apply(declaredType,_v1012))))))));
        }
        }
        }
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(17711,20634)").add(ESLVal.list(_v27)));
      }
      }
    }
  });
  private static ESLVal guardedExpType = new ESLVal(new Function(new ESLVal("guardedExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1000 = $args[0];
  ESLVal _v1001 = $args[1];
  ESLVal _v1002 = $args[2];
  ESLVal _v1003 = $args[3];
  ESLVal _v1004 = $args[4];
  ESLVal _v1005 = $args[5];
  ESLVal _v1006 = $args[6];
  {ESLVal bt = expType.apply(_v1001,_v1003,_v1004,_v1005,_v1006);
        
        if(isBoolType.apply(bt).boolVal)
        return expType.apply(_v1002,_v1003,_v1004,_v1005,_v1006);
        else
          return error(new ESLVal("TypeError",_v1000,new ESLVal("guarded expression requires a boolean value: ").add(ppType.apply(bt,_v1006))));
      }
    }
  });
  private static ESLVal expType = new ESLVal(new Function(new ESLVal("expType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v978 = $args[0];
  ESLVal _v979 = $args[1];
  ESLVal _v980 = $args[2];
  ESLVal _v981 = $args[3];
  ESLVal _v982 = $args[4];
  {ESLVal _v35 = _v978;
        
        switch(_v35.termName) {
        case "ActExp": {ESLVal $410 = _v35.termRef(0);
          ESLVal $409 = _v35.termRef(1);
          ESLVal $408 = _v35.termRef(2);
          ESLVal $407 = _v35.termRef(3);
          ESLVal $406 = _v35.termRef(4);
          ESLVal $405 = _v35.termRef(5);
          ESLVal $404 = _v35.termRef(6);
          ESLVal $403 = _v35.termRef(7);
          
          {ESLVal l = $410;
          
          {ESLVal n = $409;
          
          {ESLVal args = $408;
          
          {ESLVal exports = $407;
          
          {ESLVal parent = $406;
          
          {ESLVal bindings = $405;
          
          {ESLVal init = $404;
          
          {ESLVal arms = $403;
          
          return actType.apply(l,n,args,parent,exports,bindings,init,arms,_v979,_v980,_v981,_v982);
        }
        }
        }
        }
        }
        }
        }
        }
        }
      case "Apply": {ESLVal $402 = _v35.termRef(0);
          ESLVal $401 = _v35.termRef(1);
          ESLVal $400 = _v35.termRef(2);
          
          {ESLVal l = $402;
          
          {ESLVal op = $401;
          
          {ESLVal args = $400;
          
          return applyType.apply(l,op,args,_v979,_v980,_v981,_v982);
        }
        }
        }
        }
      case "ApplyTypeExp": {ESLVal $399 = _v35.termRef(0);
          ESLVal $398 = _v35.termRef(1);
          ESLVal $397 = _v35.termRef(2);
          
          {ESLVal l = $399;
          
          {ESLVal _v999 = $398;
          
          {ESLVal ts = $397;
          
          return applyTypeExp.apply(l,_v999,ts,_v979,_v980,_v981,_v982);
        }
        }
        }
        }
      case "ArrayUpdate": {ESLVal $396 = _v35.termRef(0);
          ESLVal $395 = _v35.termRef(1);
          ESLVal $394 = _v35.termRef(2);
          ESLVal $393 = _v35.termRef(3);
          
          {ESLVal l = $396;
          
          {ESLVal a = $395;
          
          {ESLVal i = $394;
          
          {ESLVal v = $393;
          
          return arrayUpdateType.apply(l,a,i,v,_v979,_v980,_v981,_v982);
        }
        }
        }
        }
        }
      case "ArrayRef": {ESLVal $392 = _v35.termRef(0);
          ESLVal $391 = _v35.termRef(1);
          ESLVal $390 = _v35.termRef(2);
          
          {ESLVal l = $392;
          
          {ESLVal a = $391;
          
          {ESLVal i = $390;
          
          return arrayRefType.apply(l,a,i,_v979,_v980,_v981,_v982);
        }
        }
        }
        }
      case "BagExp": {ESLVal $389 = _v35.termRef(0);
          ESLVal $388 = _v35.termRef(1);
          
          {ESLVal l = $389;
          
          {ESLVal es = $388;
          
          return bagType.apply(l,es,_v979,_v980,_v981,_v982);
        }
        }
        }
      case "Become": {ESLVal $387 = _v35.termRef(0);
          ESLVal $386 = _v35.termRef(1);
          
          {ESLVal l = $387;
          
          {ESLVal _v998 = $386;
          
          return becomeType.apply(l,_v998,_v979,_v980,_v981,_v982);
        }
        }
        }
      case "BinExp": {ESLVal $385 = _v35.termRef(0);
          ESLVal $384 = _v35.termRef(1);
          ESLVal $383 = _v35.termRef(2);
          ESLVal $382 = _v35.termRef(3);
          
          {ESLVal l = $385;
          
          {ESLVal e1 = $384;
          
          {ESLVal op = $383;
          
          {ESLVal e2 = $382;
          
          return binExpType.apply(l,e1,op,e2,_v979,_v980,_v981,_v982);
        }
        }
        }
        }
        }
      case "Block": {ESLVal $381 = _v35.termRef(0);
          ESLVal $380 = _v35.termRef(1);
          
          {ESLVal l = $381;
          
          {ESLVal es = $380;
          
          return blockType.apply(l,es,_v979,_v980,_v981,_v982);
        }
        }
        }
      case "BoolExp": {ESLVal $379 = _v35.termRef(0);
          ESLVal $378 = _v35.termRef(1);
          
          {ESLVal l = $379;
          
          {ESLVal b = $378;
          
          return new ESLVal("BoolType",l);
        }
        }
        }
      case "Case": {ESLVal $377 = _v35.termRef(0);
          ESLVal $376 = _v35.termRef(1);
          ESLVal $375 = _v35.termRef(2);
          ESLVal $374 = _v35.termRef(3);
          
          {ESLVal l = $377;
          
          {ESLVal decs = $376;
          
          {ESLVal es = $375;
          
          {ESLVal arms = $374;
          
          return caseType.apply(l,es,arms,_v979,_v980,_v981,_v982);
        }
        }
        }
        }
        }
      case "Cmp": {ESLVal $373 = _v35.termRef(0);
          ESLVal $372 = _v35.termRef(1);
          ESLVal $371 = _v35.termRef(2);
          
          {ESLVal l = $373;
          
          {ESLVal _v997 = $372;
          
          {ESLVal qs = $371;
          
          return cmpType.apply(l,_v997,qs,_v979,_v980,_v981,_v982);
        }
        }
        }
        }
      case "Grab": {ESLVal $370 = _v35.termRef(0);
          ESLVal $369 = _v35.termRef(1);
          ESLVal $368 = _v35.termRef(2);
          
          {ESLVal l = $370;
          
          {ESLVal refs = $369;
          
          {ESLVal _v996 = $368;
          
          return expType.apply(_v996,_v979,_v980,_v981,_v982);
        }
        }
        }
        }
      case "FloatExp": {ESLVal $367 = _v35.termRef(0);
          ESLVal $366 = _v35.termRef(1);
          
          {ESLVal l = $367;
          
          {ESLVal f = $366;
          
          return new ESLVal("FloatType",l);
        }
        }
        }
      case "Fold": {ESLVal $365 = _v35.termRef(0);
          ESLVal $364 = _v35.termRef(1);
          ESLVal $363 = _v35.termRef(2);
          
          {ESLVal l = $365;
          
          {ESLVal t = $364;
          
          {ESLVal _v995 = $363;
          
          return foldType.apply(l,t,_v995,_v979,_v980,_v981,_v982);
        }
        }
        }
        }
      case "For": {ESLVal $362 = _v35.termRef(0);
          ESLVal $361 = _v35.termRef(1);
          ESLVal $360 = _v35.termRef(2);
          ESLVal $359 = _v35.termRef(3);
          
          {ESLVal l = $362;
          
          {ESLVal p = $361;
          
          {ESLVal list = $360;
          
          {ESLVal _v994 = $359;
          
          return forType.apply(l,p,list,_v994,_v979,_v980,_v981,_v982);
        }
        }
        }
        }
        }
      case "FunExp": {ESLVal $358 = _v35.termRef(0);
          ESLVal $357 = _v35.termRef(1);
          ESLVal $356 = _v35.termRef(2);
          ESLVal $355 = _v35.termRef(3);
          ESLVal $354 = _v35.termRef(4);
          
          {ESLVal l = $358;
          
          {ESLVal n = $357;
          
          {ESLVal args = $356;
          
          {ESLVal t = $355;
          
          {ESLVal _v993 = $354;
          
          return funType.apply(l,n,args,t,_v993,_v979,_v980,_v981,_v982);
        }
        }
        }
        }
        }
        }
      case "If": {ESLVal $353 = _v35.termRef(0);
          ESLVal $352 = _v35.termRef(1);
          ESLVal $351 = _v35.termRef(2);
          ESLVal $350 = _v35.termRef(3);
          
          {ESLVal l = $353;
          
          {ESLVal e1 = $352;
          
          {ESLVal e2 = $351;
          
          {ESLVal e3 = $350;
          
          return ifType.apply(l,e1,e2,e3,_v979,_v980,_v981,_v982);
        }
        }
        }
        }
        }
      case "IntExp": {ESLVal $349 = _v35.termRef(0);
          ESLVal $348 = _v35.termRef(1);
          
          {ESLVal l = $349;
          
          {ESLVal n = $348;
          
          return new ESLVal("IntType",l);
        }
        }
        }
      case "Let": {ESLVal $347 = _v35.termRef(0);
          ESLVal $346 = _v35.termRef(1);
          ESLVal $345 = _v35.termRef(2);
          
          {ESLVal l = $347;
          
          {ESLVal bs = $346;
          
          {ESLVal _v992 = $345;
          
          return letType.apply(l,bs,_v992,_v979,_v980,_v981,_v982);
        }
        }
        }
        }
      case "Letrec": {ESLVal $344 = _v35.termRef(0);
          ESLVal $343 = _v35.termRef(1);
          ESLVal $342 = _v35.termRef(2);
          
          {ESLVal l = $344;
          
          {ESLVal bs = $343;
          
          {ESLVal _v991 = $342;
          
          return letrecType.apply(l,bs,_v991,_v979,_v980,_v981,_v982);
        }
        }
        }
        }
      case "List": {ESLVal $341 = _v35.termRef(0);
          ESLVal $340 = _v35.termRef(1);
          
          {ESLVal l = $341;
          
          {ESLVal es = $340;
          
          return listType.apply(l,es,_v979,_v980,_v981,_v982);
        }
        }
        }
      case "Now": {ESLVal $339 = _v35.termRef(0);
          
          {ESLVal l = $339;
          
          return new ESLVal("IntType",l);
        }
        }
      case "Probably": {ESLVal $338 = _v35.termRef(0);
          ESLVal $337 = _v35.termRef(1);
          ESLVal $336 = _v35.termRef(2);
          ESLVal $335 = _v35.termRef(3);
          ESLVal $334 = _v35.termRef(4);
          
          {ESLVal l = $338;
          
          {ESLVal p = $337;
          
          {ESLVal t = $336;
          
          {ESLVal e1 = $335;
          
          {ESLVal e2 = $334;
          
          return probablyType.apply(l,p,t,e1,e2,_v979,_v980,_v981,_v982);
        }
        }
        }
        }
        }
        }
      case "PLet": {ESLVal $333 = _v35.termRef(0);
          ESLVal $332 = _v35.termRef(1);
          ESLVal $331 = _v35.termRef(2);
          
          {ESLVal l = $333;
          
          {ESLVal bs = $332;
          
          {ESLVal _v990 = $331;
          
          return letType.apply(l,bs,_v990,_v979,_v980,_v981,_v982);
        }
        }
        }
        }
      case "Record": {ESLVal $330 = _v35.termRef(0);
          ESLVal $329 = _v35.termRef(1);
          
          {ESLVal l = $330;
          
          {ESLVal fields = $329;
          
          return recordType.apply(l,fields,_v979,_v980,_v981,_v982);
        }
        }
        }
      case "Ref": {ESLVal $328 = _v35.termRef(0);
          ESLVal $327 = _v35.termRef(1);
          ESLVal $326 = _v35.termRef(2);
          
          {ESLVal l = $328;
          
          {ESLVal _v989 = $327;
          
          {ESLVal n = $326;
          
          return refType.apply(l,_v989,n,_v979,_v980,_v981,_v982);
        }
        }
        }
        }
      case "RefSuper": {ESLVal $325 = _v35.termRef(0);
          ESLVal $324 = _v35.termRef(1);
          
          {ESLVal l = $325;
          
          {ESLVal n = $324;
          
          return refType.apply(l,new ESLVal("Var",l,new ESLVal("$super")),n,_v979,_v980,_v981,_v982);
        }
        }
        }
      case "Self": {ESLVal $323 = _v35.termRef(0);
          
          {ESLVal l = $323;
          
          return _v979;
        }
        }
      case "Send": {ESLVal $318 = _v35.termRef(0);
          ESLVal $317 = _v35.termRef(1);
          ESLVal $316 = _v35.termRef(2);
          
          switch($316.termName) {
          case "Term": {ESLVal $322 = $316.termRef(0);
            ESLVal $321 = $316.termRef(1);
            ESLVal $320 = $316.termRef(2);
            ESLVal $319 = $316.termRef(3);
            
            {ESLVal l = $318;
            
            {ESLVal target = $317;
            
            {ESLVal tl = $322;
            
            {ESLVal n = $321;
            
            {ESLVal ts = $320;
            
            {ESLVal args = $319;
            
            return sendType.apply(l,target,n,args,_v979,_v980,_v981,_v982);
          }
          }
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(21112,25165)").add(ESLVal.list(_v35)));
        }
        }
      case "SendTimeSuper": {ESLVal $315 = _v35.termRef(0);
          
          {ESLVal l = $315;
          
          return new ESLVal("VoidType",l);
        }
        }
      case "SendSuper": {ESLVal $314 = _v35.termRef(0);
          ESLVal $313 = _v35.termRef(1);
          
          {ESLVal l = $314;
          
          {ESLVal _v988 = $313;
          
          return new ESLVal("VoidType",l);
        }
        }
        }
      case "SetExp": {ESLVal $312 = _v35.termRef(0);
          ESLVal $311 = _v35.termRef(1);
          
          {ESLVal l = $312;
          
          {ESLVal es = $311;
          
          return setType.apply(l,es,_v979,_v980,_v981,_v982);
        }
        }
        }
      case "StrExp": {ESLVal $310 = _v35.termRef(0);
          ESLVal $309 = _v35.termRef(1);
          
          {ESLVal l = $310;
          
          {ESLVal s = $309;
          
          return new ESLVal("StrType",l);
        }
        }
        }
      case "Term": {ESLVal $308 = _v35.termRef(0);
          ESLVal $307 = _v35.termRef(1);
          ESLVal $306 = _v35.termRef(2);
          ESLVal $305 = _v35.termRef(3);
          
          {ESLVal l = $308;
          
          {ESLVal n = $307;
          
          {ESLVal ts = $306;
          
          {ESLVal es = $305;
          
          return termType.apply(l,n,ts,es,_v979,_v980,_v981,_v982);
        }
        }
        }
        }
        }
      case "Throw": {ESLVal $304 = _v35.termRef(0);
          ESLVal $303 = _v35.termRef(1);
          ESLVal $302 = _v35.termRef(2);
          
          {ESLVal l = $304;
          
          {ESLVal t = $303;
          
          {ESLVal _v987 = $302;
          
          return throwType.apply(l,t,_v987,_v979,_v980,_v981,_v982);
        }
        }
        }
        }
      case "Try": {ESLVal $301 = _v35.termRef(0);
          ESLVal $300 = _v35.termRef(1);
          ESLVal $299 = _v35.termRef(2);
          
          {ESLVal l = $301;
          
          {ESLVal _v986 = $300;
          
          {ESLVal arms = $299;
          
          return tryType.apply(l,_v986,arms,_v979,_v980,_v981,_v982);
        }
        }
        }
        }
      case "New": {ESLVal $298 = _v35.termRef(0);
          ESLVal $297 = _v35.termRef(1);
          ESLVal $296 = _v35.termRef(2);
          
          {ESLVal l = $298;
          
          {ESLVal b = $297;
          
          {ESLVal args = $296;
          
          return newType.apply(l,b,args,_v979,_v980,_v981,_v982);
        }
        }
        }
        }
      case "NewArray": {ESLVal $295 = _v35.termRef(0);
          ESLVal $294 = _v35.termRef(1);
          ESLVal $293 = _v35.termRef(2);
          
          {ESLVal l = $295;
          
          {ESLVal t = $294;
          
          {ESLVal i = $293;
          
          return newArrayType.apply(l,t,i,_v979,_v980,_v981,_v982);
        }
        }
        }
        }
      case "NewTable": {ESLVal $292 = _v35.termRef(0);
          ESLVal $291 = _v35.termRef(1);
          ESLVal $290 = _v35.termRef(2);
          
          {ESLVal l = $292;
          
          {ESLVal key = $291;
          
          {ESLVal value = $290;
          
          return new ESLVal("TableType",l,substTypeEnv.apply(_v982,key),substTypeEnv.apply(_v982,value));
        }
        }
        }
        }
      case "NewJava": {ESLVal $289 = _v35.termRef(0);
          ESLVal $288 = _v35.termRef(1);
          ESLVal $287 = _v35.termRef(2);
          ESLVal $286 = _v35.termRef(3);
          
          {ESLVal l = $289;
          
          {ESLVal path = $288;
          
          {ESLVal t = $287;
          
          {ESLVal args = $286;
          
          {{
          ESLVal _v36 = args;
          while(_v36.isCons()) {
            ESLVal a = _v36.headVal;
            expType.apply(a,_v979,_v980,_v981,_v982);
            _v36 = _v36.tailVal;}
        }
        return substTypeEnv.apply(_v982,t);}
        }
        }
        }
        }
        }
      case "Not": {ESLVal $285 = _v35.termRef(0);
          ESLVal $284 = _v35.termRef(1);
          
          {ESLVal l = $285;
          
          {ESLVal _v985 = $284;
          
          return notType.apply(l,_v985,_v979,_v980,_v981,_v982);
        }
        }
        }
      case "NullExp": {ESLVal $283 = _v35.termRef(0);
          
          {ESLVal l = $283;
          
          return new ESLVal("ForallType",l,ESLVal.list(new ESLVal("T")),new ESLVal("VarType",l,new ESLVal("T")));
        }
        }
      case "Unfold": {ESLVal $282 = _v35.termRef(0);
          ESLVal $281 = _v35.termRef(1);
          ESLVal $280 = _v35.termRef(2);
          
          {ESLVal l = $282;
          
          {ESLVal t = $281;
          
          {ESLVal _v984 = $280;
          
          return unfoldTypeExp.apply(l,t,_v984,_v979,_v980,_v981,_v982);
        }
        }
        }
        }
      case "Update": {ESLVal $279 = _v35.termRef(0);
          ESLVal $278 = _v35.termRef(1);
          ESLVal $277 = _v35.termRef(2);
          
          {ESLVal l = $279;
          
          {ESLVal n = $278;
          
          {ESLVal _v983 = $277;
          
          return updateType.apply(l,n,_v983,_v979,_v980,_v981,_v982);
        }
        }
        }
        }
      case "Var": {ESLVal $276 = _v35.termRef(0);
          ESLVal $275 = _v35.termRef(1);
          
          {ESLVal l = $276;
          
          {ESLVal n = $275;
          
          return varType.apply(l,n,_v980);
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(21112,25165)").add(ESLVal.list(_v35)));
      }
      }
    }
  });
  private static ESLVal throwType = new ESLVal(new Function(new ESLVal("throwType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v971 = $args[0];
  ESLVal _v972 = $args[1];
  ESLVal _v973 = $args[2];
  ESLVal _v974 = $args[3];
  ESLVal _v975 = $args[4];
  ESLVal _v976 = $args[5];
  ESLVal _v977 = $args[6];
  {ESLVal valType = expType.apply(_v973,_v974,_v975,_v976,_v977);
        
        return substTypeEnv.apply(_v977,_v972);
      }
    }
  });
  private static ESLVal foldType = new ESLVal(new Function(new ESLVal("foldType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v964 = $args[0];
  ESLVal _v965 = $args[1];
  ESLVal _v966 = $args[2];
  ESLVal _v967 = $args[3];
  ESLVal _v968 = $args[4];
  ESLVal _v969 = $args[5];
  ESLVal _v970 = $args[6];
  {ESLVal eType = expType.apply(_v966,_v967,_v968,_v969,_v970);
        
        if(typeEqual.apply(substTypeEnv.apply(_v970,_v965),eType).boolVal)
        return eType;
        else
          return error(new ESLVal("TypeError",_v964,new ESLVal("fold type ").add(ppType.apply(_v965,_v970).add(new ESLVal(" does not equal ").add(ppType.apply(eType,_v970))))));
      }
    }
  });
  private static ESLVal unfoldTypeExp = new ESLVal(new Function(new ESLVal("unfoldTypeExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v955 = $args[0];
  ESLVal _v956 = $args[1];
  ESLVal _v957 = $args[2];
  ESLVal _v958 = $args[3];
  ESLVal _v959 = $args[4];
  ESLVal _v960 = $args[5];
  ESLVal _v961 = $args[6];
  {ESLVal eType = expType.apply(_v957,_v958,_v959,_v960,_v961);
        ESLVal recType = substTypeEnv.apply(_v961,_v956);
        
        {ESLVal _v37 = recType;
        
        switch(_v37.termName) {
        case "RecType": {ESLVal $413 = _v37.termRef(0);
          ESLVal $412 = _v37.termRef(1);
          ESLVal $411 = _v37.termRef(2);
          
          {ESLVal rl = $413;
          
          {ESLVal n = $412;
          
          {ESLVal _v962 = $411;
          
          if(typeEqual.apply(substType.apply(eType,n,_v962),eType).boolVal)
          return eType;
          else
            return error(new ESLVal("TypeError",_v955,new ESLVal("unfold type ").add(ppType.apply(substType.apply(eType,n,_v962),_v961).add(new ESLVal(" does not equal ").add(ppType.apply(eType,_v961))))));
        }
        }
        }
        }
        default: {ESLVal _v963 = _v37;
          
          return error(new ESLVal("TypeError",_v955,new ESLVal("unfold type expects a rec type").add(ppType.apply(recType,_v961))));
        }
      }
      }
      }
    }
  });
  private static ESLVal arrayUpdateType = new ESLVal(new Function(new ESLVal("arrayUpdateType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v947 = $args[0];
  ESLVal _v948 = $args[1];
  ESLVal _v949 = $args[2];
  ESLVal _v950 = $args[3];
  ESLVal _v951 = $args[4];
  ESLVal _v952 = $args[5];
  ESLVal _v953 = $args[6];
  ESLVal _v954 = $args[7];
  {ESLVal aType = expType.apply(_v948,_v951,_v952,_v953,_v954);
        ESLVal iType = expType.apply(_v949,_v951,_v952,_v953,_v954);
        ESLVal vType = expType.apply(_v950,_v951,_v952,_v953,_v954);
        
        {ESLVal _v38 = aType;
        
        switch(_v38.termName) {
        case "ArrayType": {ESLVal $415 = _v38.termRef(0);
          ESLVal $414 = _v38.termRef(1);
          
          {ESLVal al = $415;
          
          {ESLVal t = $414;
          
          if(isIntType.apply(iType).boolVal)
          if(typeEqual.apply(vType,t).boolVal)
            return aType;
            else
              return error(new ESLVal("TypeError",_v947,new ESLVal("value type ").add(vType.add(new ESLVal(" does not match array type ").add(t)))));
          else
            return error(new ESLVal("TypeError",_v947,new ESLVal("array index should be an integer ").add(_v949)));
        }
        }
        }
        default: {ESLVal t = _v38;
          
          return error(new ESLVal("TypeError",_v947,new ESLVal("expecting an array ").add(aType)));
        }
      }
      }
      }
    }
  });
  private static ESLVal arrayRefType = new ESLVal(new Function(new ESLVal("arrayRefType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v940 = $args[0];
  ESLVal _v941 = $args[1];
  ESLVal _v942 = $args[2];
  ESLVal _v943 = $args[3];
  ESLVal _v944 = $args[4];
  ESLVal _v945 = $args[5];
  ESLVal _v946 = $args[6];
  {ESLVal aType = expType.apply(_v941,_v943,_v944,_v945,_v946);
        ESLVal iType = expType.apply(_v942,_v943,_v944,_v945,_v946);
        
        {ESLVal _v39 = aType;
        
        switch(_v39.termName) {
        case "ArrayType": {ESLVal $417 = _v39.termRef(0);
          ESLVal $416 = _v39.termRef(1);
          
          {ESLVal al = $417;
          
          {ESLVal t = $416;
          
          if(isIntType.apply(iType).boolVal)
          return t;
          else
            return error(new ESLVal("TypeError",_v940,new ESLVal("array index should be an integer ").add(_v942)));
        }
        }
        }
        default: {ESLVal t = _v39;
          
          return error(new ESLVal("TypeError",_v940,new ESLVal("expecting an array ").add(aType)));
        }
      }
      }
      }
    }
  });
  private static ESLVal newArrayType = new ESLVal(new Function(new ESLVal("newArrayType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v933 = $args[0];
  ESLVal _v934 = $args[1];
  ESLVal _v935 = $args[2];
  ESLVal _v936 = $args[3];
  ESLVal _v937 = $args[4];
  ESLVal _v938 = $args[5];
  ESLVal _v939 = $args[6];
  {ESLVal i = expType.apply(_v935,_v936,_v937,_v938,_v939);
        
        if(isIntType.apply(i).boolVal)
        return new ESLVal("ArrayType",_v933,substTypeEnv.apply(_v939,_v934));
        else
          return error(new ESLVal("TypeError",_v933,new ESLVal("expecting an integer type: ").add(i)));
      }
    }
  });
  private static ESLVal becomeType = new ESLVal(new Function(new ESLVal("becomeType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v927 = $args[0];
  ESLVal _v928 = $args[1];
  ESLVal _v929 = $args[2];
  ESLVal _v930 = $args[3];
  ESLVal _v931 = $args[4];
  ESLVal _v932 = $args[5];
  {ESLVal bType = expType.apply(_v928,_v929,_v930,_v931,_v932);
        
        if(typeEqual.apply(bType,_v929).boolVal)
        return bType;
        else
          return error(new ESLVal("TypeError",_v927,new ESLVal("expecting become to match self type: ").add(ppType.apply(bType,_v932).add(new ESLVal(" ").add(ppType.apply(_v929,_v932))))));
      }
    }
  });
  private static ESLVal probablyType = new ESLVal(new Function(new ESLVal("probablyType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v915 = $args[0];
  ESLVal _v916 = $args[1];
  ESLVal _v917 = $args[2];
  ESLVal _v918 = $args[3];
  ESLVal _v919 = $args[4];
  ESLVal _v920 = $args[5];
  ESLVal _v921 = $args[6];
  ESLVal _v922 = $args[7];
  ESLVal _v923 = $args[8];
  {ESLVal pt = expType.apply(_v916,_v920,_v921,_v922,_v923);
        
        if(isIntType.apply(pt).boolVal)
        {ESLVal _v924 = substTypeEnv.apply(_v923,_v917);
          ESLVal _v925 = expType.apply(_v918,_v920,_v921,_v922,_v923);
          ESLVal _v926 = expType.apply(_v919,_v920,_v921,_v922,_v923);
          
          if(typeEqual.apply(_v924,_v925).and(typeEqual.apply(_v924,_v926)).boolVal)
          return _v924;
          else
            return error(new ESLVal("TypeError",_v915,new ESLVal("expecting probably arm types to agree: ").add(ppType.apply(_v925,_v923).add(new ESLVal(" ").add(ppType.apply(_v924,_v923).add(new ESLVal(" ").add(ppType.apply(_v926,_v923))))))));
        }
        else
          return error(new ESLVal("TypeError",_v915,new ESLVal("expecting an integer: ").add(ppType.apply(pt,_v923))));
      }
    }
  });
  private static ESLVal newType = new ESLVal(new Function(new ESLVal("newType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v908 = $args[0];
  ESLVal _v909 = $args[1];
  ESLVal _v910 = $args[2];
  ESLVal _v911 = $args[3];
  ESLVal _v912 = $args[4];
  ESLVal _v913 = $args[5];
  ESLVal _v914 = $args[6];
  return expType.apply(new ESLVal("Apply",_v908,_v909,_v910),_v911,_v912,_v913,_v914);
    }
  });
  private static ESLVal sendType = new ESLVal(new Function(new ESLVal("sendType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v890 = $args[0];
  ESLVal _v891 = $args[1];
  ESLVal _v892 = $args[2];
  ESLVal _v893 = $args[3];
  ESLVal _v894 = $args[4];
  ESLVal _v895 = $args[5];
  ESLVal _v896 = $args[6];
  ESLVal _v897 = $args[7];
  {ESLVal _v40 = typeNF.apply(derefType.apply(expType.apply(_v891,_v894,_v895,_v896,_v897)),_v897);
        
        switch(_v40.termName) {
        case "ActType": {ESLVal $420 = _v40.termRef(0);
          ESLVal $419 = _v40.termRef(1);
          ESLVal $418 = _v40.termRef(2);
          
          {ESLVal al = $420;
          
          {ESLVal exports = $419;
          
          {ESLVal handlers = $418;
          
          { LetRec letrec = new LetRec() {
          ESLVal findHandler = new ESLVal(new Function(new ESLVal("findHandler"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v898 = $args[0];
            {ESLVal _v41 = _v898;
                  
                  if(_v41.isCons())
                  {ESLVal $421 = _v41.head();
                    ESLVal $422 = _v41.tail();
                    
                    switch($421.termName) {
                    case "MessageType": {ESLVal $424 = $421.termRef(0);
                      ESLVal $423 = $421.termRef(1);
                      
                      if($423.isCons())
                      {ESLVal $425 = $423.head();
                        ESLVal $426 = $423.tail();
                        
                        switch($425.termName) {
                        case "TermType": {ESLVal $429 = $425.termRef(0);
                          ESLVal $428 = $425.termRef(1);
                          ESLVal $427 = $425.termRef(2);
                          
                          if($426.isCons())
                          {ESLVal $430 = $426.head();
                            ESLVal $431 = $426.tail();
                            
                            {ESLVal m = $421;
                            
                            {ESLVal _v899 = $422;
                            
                            return findHandler.apply(_v899);
                          }
                          }
                          }
                        else if($426.isNil())
                          {ESLVal ml = $424;
                            
                            {ESLVal tl = $429;
                            
                            {ESLVal m = $428;
                            
                            {ESLVal ts = $427;
                            
                            {ESLVal rest = $422;
                            
                            if(m.eql(_v892).boolVal)
                            return head.apply(_v898);
                            else
                              {ESLVal _v900 = $421;
                                
                                {ESLVal _v901 = $422;
                                
                                return findHandler.apply(_v901);
                              }
                              }
                          }
                          }
                          }
                          }
                          }
                        else {ESLVal m = $421;
                            
                            {ESLVal _v902 = $422;
                            
                            return findHandler.apply(_v902);
                          }
                          }
                        }
                        default: {ESLVal m = $421;
                          
                          {ESLVal _v903 = $422;
                          
                          return findHandler.apply(_v903);
                        }
                        }
                      }
                      }
                    else if($423.isNil())
                      {ESLVal m = $421;
                        
                        {ESLVal _v904 = $422;
                        
                        return findHandler.apply(_v904);
                      }
                      }
                    else {ESLVal m = $421;
                        
                        {ESLVal _v905 = $422;
                        
                        return findHandler.apply(_v905);
                      }
                      }
                    }
                    default: {ESLVal m = $421;
                      
                      {ESLVal _v906 = $422;
                      
                      return findHandler.apply(_v906);
                    }
                    }
                  }
                  }
                else if(_v41.isNil())
                  return error(new ESLVal("TypeError",_v890,new ESLVal("cannot find message handler named ").add(_v892)));
                else return error(new ESLVal("case error at Pos(29360,29667)").add(ESLVal.list(_v41)));
                }
              }
            });
          
          public ESLVal get(String name) {
            switch(name) {
              case "findHandler": return findHandler;
              
              default: throw new Error("cannot find letrec binding");
            }
            }
          };
        ESLVal findHandler = letrec.get("findHandler");
        
          {ESLVal _v42 = findHandler.apply(handlers);
          
          switch(_v42.termName) {
          case "MessageType": {ESLVal $433 = _v42.termRef(0);
            ESLVal $432 = _v42.termRef(1);
            
            if($432.isCons())
            {ESLVal $434 = $432.head();
              ESLVal $435 = $432.tail();
              
              switch($434.termName) {
              case "TermType": {ESLVal $438 = $434.termRef(0);
                ESLVal $437 = $434.termRef(1);
                ESLVal $436 = $434.termRef(2);
                
                if($435.isCons())
                {ESLVal $439 = $435.head();
                  ESLVal $440 = $435.tail();
                  
                  {ESLVal m = _v42;
                  
                  return error(new ESLVal("TypeError",_v890,new ESLVal("cannot find message handler named ").add(_v892.add(new ESLVal(" in ").add(handlers)))));
                }
                }
              else if($435.isNil())
                {ESLVal ml = $433;
                  
                  {ESLVal tl = $438;
                  
                  {ESLVal _v907 = $437;
                  
                  {ESLVal ts1 = $436;
                  
                  {ESLVal ts2 = expTypes.apply(_v893,_v894,_v895,_v896,_v897);
                  
                  if(length.apply(ts1).eql(length.apply(ts2)).boolVal)
                  if(subTypes.apply(ts2,ts1).boolVal)
                    {expType.apply(_v891,_v894,_v895,_v896,_v897);
                    return new ESLVal("VoidType",_v890);}
                    else
                      return error(new ESLVal("TypeError",_v890,new ESLVal("message argument types ").add(ppTypes.apply(ts2,_v897).add(new ESLVal(" do not match expected types ").add(ppTypes.apply(ts1,_v897))))));
                  else
                    return error(new ESLVal("TypeError",_v890,new ESLVal("expecting ").add(length.apply(ts1).add(new ESLVal(" args, but received ").add(length.apply(ts2))))));
                }
                }
                }
                }
                }
              else {ESLVal m = _v42;
                  
                  return error(new ESLVal("TypeError",_v890,new ESLVal("cannot find message handler named ").add(_v892.add(new ESLVal(" in ").add(handlers)))));
                }
              }
              default: {ESLVal m = _v42;
                
                return error(new ESLVal("TypeError",_v890,new ESLVal("cannot find message handler named ").add(_v892.add(new ESLVal(" in ").add(handlers)))));
              }
            }
            }
          else if($432.isNil())
            {ESLVal m = _v42;
              
              return error(new ESLVal("TypeError",_v890,new ESLVal("cannot find message handler named ").add(_v892.add(new ESLVal(" in ").add(handlers)))));
            }
          else {ESLVal m = _v42;
              
              return error(new ESLVal("TypeError",_v890,new ESLVal("cannot find message handler named ").add(_v892.add(new ESLVal(" in ").add(handlers)))));
            }
          }
          default: {ESLVal m = _v42;
            
            return error(new ESLVal("TypeError",_v890,new ESLVal("cannot find message handler named ").add(_v892.add(new ESLVal(" in ").add(handlers)))));
          }
        }
        }}
        
        }
        }
        }
        }
        default: {ESLVal t = _v40;
          
          return error(new ESLVal("TypeError",_v890,new ESLVal("expecting a behaviour type: ").add(typeNF.apply(derefType.apply(expType.apply(_v891,_v894,_v895,_v896,_v897)),_v897))));
        }
      }
      }
    }
  });
  private static ESLVal actType = new ESLVal(new Function(new ESLVal("actType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v824 = $args[0];
  ESLVal _v825 = $args[1];
  ESLVal _v826 = $args[2];
  ESLVal _v827 = $args[3];
  ESLVal _v828 = $args[4];
  ESLVal _v829 = $args[5];
  ESLVal _v830 = $args[6];
  ESLVal _v831 = $args[7];
  ESLVal _v832 = $args[8];
  ESLVal _v833 = $args[9];
  ESLVal _v834 = $args[10];
  ESLVal _v835 = $args[11];
  { LetRec letrec = new LetRec() {
        ESLVal checkObservedMessage = new ESLVal(new Function(new ESLVal("checkObservedMessage"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              {ESLVal _v43 = _v829;
                
                return $ndCase.apply(_v43,ESLVal.list(new ESLVal("$selectMid",new ESLVal(new Function(new ESLVal("add"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal $442 = $args[0];
                ESLVal $443 = $args[1];
                ESLVal $444 = $args[2];
                ESLVal $441 = $args[3];
                switch($443.termName) {
                      case "FunBind": {ESLVal $451 = $443.termRef(0);
                        ESLVal $450 = $443.termRef(1);
                        ESLVal $449 = $443.termRef(2);
                        ESLVal $448 = $443.termRef(3);
                        ESLVal $447 = $443.termRef(4);
                        ESLVal $446 = $443.termRef(5);
                        ESLVal $445 = $443.termRef(6);
                        
                        switch($450.strVal) {
                        case "observeMessage": {ESLVal bs1 = $442;
                          
                          {ESLVal _v882 = $451;
                          
                          {ESLVal ps = $449;
                          
                          {ESLVal t = $448;
                          
                          {ESLVal st = $447;
                          
                          {ESLVal g = $446;
                          
                          {ESLVal e = $445;
                          
                          {ESLVal bs2 = $444;
                          
                          {ESLVal _v44 = typeNF.apply(t,_v835);
                          
                          switch(_v44.termName) {
                          case "FunType": {ESLVal $454 = _v44.termRef(0);
                            ESLVal $453 = _v44.termRef(1);
                            ESLVal $452 = _v44.termRef(2);
                            
                            if($453.isCons())
                            {ESLVal $455 = $453.head();
                              ESLVal $456 = $453.tail();
                              
                              if($456.isCons())
                              {ESLVal $457 = $456.head();
                                ESLVal $458 = $456.tail();
                                
                                {ESLVal _v883 = _v44;
                                
                                return error(new ESLVal("TypeError",_v882,new ESLVal("expecting observeMessage to have a type signature (In) -> Maybe[Out]")));
                              }
                              }
                            else if($456.isNil())
                              {ESLVal fl = $454;
                                
                                {ESLVal d = $455;
                                
                                {ESLVal r = $452;
                                
                                return checkObserveMessageDeclaration.apply(_v882,d,r);
                              }
                              }
                              }
                            else {ESLVal _v884 = _v44;
                                
                                return error(new ESLVal("TypeError",_v882,new ESLVal("expecting observeMessage to have a type signature (In) -> Maybe[Out]")));
                              }
                            }
                          else if($453.isNil())
                            {ESLVal _v885 = _v44;
                              
                              return error(new ESLVal("TypeError",_v882,new ESLVal("expecting observeMessage to have a type signature (In) -> Maybe[Out]")));
                            }
                          else {ESLVal _v886 = _v44;
                              
                              return error(new ESLVal("TypeError",_v882,new ESLVal("expecting observeMessage to have a type signature (In) -> Maybe[Out]")));
                            }
                          }
                          default: {ESLVal _v887 = _v44;
                            
                            return error(new ESLVal("TypeError",_v882,new ESLVal("expecting observeMessage to have a type signature (In) -> Maybe[Out]")));
                          }
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        default: return $441.apply();
                      }
                      }
                      default: return $441.apply();
                    }
                  }
                }))),new ESLVal(new Function(new ESLVal("listFail"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    {ESLVal bs = _v43;
                      
                      return $null;
                    }
                  }
                }));
              }
            }
          });
        ESLVal isTime = new ESLVal(new Function(new ESLVal("isTime"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal t = $args[0];
          {ESLVal _v45 = t;
                
                switch(_v45.termName) {
                case "TermType": {ESLVal $461 = _v45.termRef(0);
                  ESLVal $460 = _v45.termRef(1);
                  ESLVal $459 = _v45.termRef(2);
                  
                  switch($460.strVal) {
                  case "Time": {ESLVal _v879 = $461;
                    
                    {ESLVal ts = $459;
                    
                    return $true;
                  }
                  }
                  default: {ESLVal _v880 = _v45;
                    
                    return $false;
                  }
                }
                }
                default: {ESLVal _v881 = _v45;
                  
                  return $false;
                }
              }
              }
            }
          });
        ESLVal checkObserveMessageDeclaration = new ESLVal(new Function(new ESLVal("checkObserveMessageDeclaration"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v876 = $args[0];
          ESLVal _v877 = $args[1];
          ESLVal _v878 = $args[2];
          if(typeEqual.apply(_v877,new ESLVal("UnionType",_v876,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v46 = $qualArg;
                    
                    switch(_v46.termName) {
                    case "MessageType": {ESLVal $463 = _v46.termRef(0);
                      ESLVal $462 = _v46.termRef(1);
                      
                      if($462.isCons())
                      {ESLVal $464 = $462.head();
                        ESLVal $465 = $462.tail();
                        
                        if($465.isCons())
                        {ESLVal $466 = $465.head();
                          ESLVal $467 = $465.tail();
                          
                          {ESLVal _0 = _v46;
                          
                          return ESLVal.list();
                        }
                        }
                      else if($465.isNil())
                        {ESLVal ml = $463;
                          
                          {ESLVal t = $464;
                          
                          return ESLVal.list(((Supplier<ESLVal>)() -> { 
                            if(isTime.apply(t).not().boolVal)
                              return ESLVal.list(t);
                              else
                                return ESLVal.list();
                          }).get());
                        }
                        }
                      else {ESLVal _0 = _v46;
                          
                          return ESLVal.list();
                        }
                      }
                    else if($462.isNil())
                      {ESLVal _0 = _v46;
                        
                        return ESLVal.list();
                      }
                    else {ESLVal _0 = _v46;
                        
                        return ESLVal.list();
                      }
                    }
                    default: {ESLVal _0 = _v46;
                      
                      return ESLVal.list();
                    }
                  }
                  }
                }
              }).map(getMessageTypes.apply(_v831)).flatten().flatten())).boolVal)
                {ESLVal _v47 = typeNF.apply(_v878,_v835);
                  
                  switch(_v47.termName) {
                  case "UnionType": {ESLVal $469 = _v47.termRef(0);
                    ESLVal $468 = _v47.termRef(1);
                    
                    if($468.isCons())
                    {ESLVal $470 = $468.head();
                      ESLVal $471 = $468.tail();
                      
                      switch($470.termName) {
                      case "TermType": {ESLVal $474 = $470.termRef(0);
                        ESLVal $473 = $470.termRef(1);
                        ESLVal $472 = $470.termRef(2);
                        
                        switch($473.strVal) {
                        case "Something": if($472.isCons())
                          {ESLVal $475 = $472.head();
                            ESLVal $476 = $472.tail();
                            
                            if($476.isCons())
                            {ESLVal $477 = $476.head();
                              ESLVal $478 = $476.tail();
                              
                              {ESLVal ms = _v47;
                              
                              return error(new ESLVal("TypeError",_v876,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v878)));
                            }
                            }
                          else if($476.isNil())
                            if($471.isCons())
                              {ESLVal $479 = $471.head();
                                ESLVal $480 = $471.tail();
                                
                                switch($479.termName) {
                                case "TermType": {ESLVal $483 = $479.termRef(0);
                                  ESLVal $482 = $479.termRef(1);
                                  ESLVal $481 = $479.termRef(2);
                                  
                                  switch($482.strVal) {
                                  case "Nothing": if($481.isCons())
                                    {ESLVal $484 = $481.head();
                                      ESLVal $485 = $481.tail();
                                      
                                      {ESLVal ms = _v47;
                                      
                                      return error(new ESLVal("TypeError",_v876,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v878)));
                                    }
                                    }
                                  else if($481.isNil())
                                    if($480.isCons())
                                      {ESLVal $486 = $480.head();
                                        ESLVal $487 = $480.tail();
                                        
                                        {ESLVal ms = _v47;
                                        
                                        return error(new ESLVal("TypeError",_v876,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v878)));
                                      }
                                      }
                                    else if($480.isNil())
                                      {ESLVal ul = $469;
                                        
                                        {ESLVal l1 = $474;
                                        
                                        {ESLVal t = $475;
                                        
                                        {ESLVal l2 = $483;
                                        
                                        return $null;
                                      }
                                      }
                                      }
                                      }
                                    else {ESLVal ms = _v47;
                                        
                                        return error(new ESLVal("TypeError",_v876,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v878)));
                                      }
                                  else {ESLVal ms = _v47;
                                      
                                      return error(new ESLVal("TypeError",_v876,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v878)));
                                    }
                                  default: {ESLVal ms = _v47;
                                    
                                    return error(new ESLVal("TypeError",_v876,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v878)));
                                  }
                                }
                                }
                                default: {ESLVal ms = _v47;
                                  
                                  return error(new ESLVal("TypeError",_v876,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v878)));
                                }
                              }
                              }
                            else if($471.isNil())
                              {ESLVal ms = _v47;
                                
                                return error(new ESLVal("TypeError",_v876,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v878)));
                              }
                            else {ESLVal ms = _v47;
                                
                                return error(new ESLVal("TypeError",_v876,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v878)));
                              }
                          else {ESLVal ms = _v47;
                              
                              return error(new ESLVal("TypeError",_v876,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v878)));
                            }
                          }
                        else if($472.isNil())
                          {ESLVal ms = _v47;
                            
                            return error(new ESLVal("TypeError",_v876,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v878)));
                          }
                        else {ESLVal ms = _v47;
                            
                            return error(new ESLVal("TypeError",_v876,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v878)));
                          }
                      case "Nothing": if($472.isCons())
                          {ESLVal $488 = $472.head();
                            ESLVal $489 = $472.tail();
                            
                            {ESLVal ms = _v47;
                            
                            return error(new ESLVal("TypeError",_v876,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v878)));
                          }
                          }
                        else if($472.isNil())
                          if($471.isCons())
                            {ESLVal $490 = $471.head();
                              ESLVal $491 = $471.tail();
                              
                              switch($490.termName) {
                              case "TermType": {ESLVal $494 = $490.termRef(0);
                                ESLVal $493 = $490.termRef(1);
                                ESLVal $492 = $490.termRef(2);
                                
                                switch($493.strVal) {
                                case "Something": if($492.isCons())
                                  {ESLVal $495 = $492.head();
                                    ESLVal $496 = $492.tail();
                                    
                                    if($496.isCons())
                                    {ESLVal $497 = $496.head();
                                      ESLVal $498 = $496.tail();
                                      
                                      {ESLVal ms = _v47;
                                      
                                      return error(new ESLVal("TypeError",_v876,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v878)));
                                    }
                                    }
                                  else if($496.isNil())
                                    if($491.isCons())
                                      {ESLVal $499 = $491.head();
                                        ESLVal $500 = $491.tail();
                                        
                                        {ESLVal ms = _v47;
                                        
                                        return error(new ESLVal("TypeError",_v876,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v878)));
                                      }
                                      }
                                    else if($491.isNil())
                                      {ESLVal ul = $469;
                                        
                                        {ESLVal l2 = $474;
                                        
                                        {ESLVal l1 = $494;
                                        
                                        {ESLVal t = $495;
                                        
                                        return $null;
                                      }
                                      }
                                      }
                                      }
                                    else {ESLVal ms = _v47;
                                        
                                        return error(new ESLVal("TypeError",_v876,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v878)));
                                      }
                                  else {ESLVal ms = _v47;
                                      
                                      return error(new ESLVal("TypeError",_v876,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v878)));
                                    }
                                  }
                                else if($492.isNil())
                                  {ESLVal ms = _v47;
                                    
                                    return error(new ESLVal("TypeError",_v876,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v878)));
                                  }
                                else {ESLVal ms = _v47;
                                    
                                    return error(new ESLVal("TypeError",_v876,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v878)));
                                  }
                                default: {ESLVal ms = _v47;
                                  
                                  return error(new ESLVal("TypeError",_v876,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v878)));
                                }
                              }
                              }
                              default: {ESLVal ms = _v47;
                                
                                return error(new ESLVal("TypeError",_v876,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v878)));
                              }
                            }
                            }
                          else if($471.isNil())
                            {ESLVal ms = _v47;
                              
                              return error(new ESLVal("TypeError",_v876,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v878)));
                            }
                          else {ESLVal ms = _v47;
                              
                              return error(new ESLVal("TypeError",_v876,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v878)));
                            }
                        else {ESLVal ms = _v47;
                            
                            return error(new ESLVal("TypeError",_v876,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v878)));
                          }
                        default: {ESLVal ms = _v47;
                          
                          return error(new ESLVal("TypeError",_v876,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v878)));
                        }
                      }
                      }
                      default: {ESLVal ms = _v47;
                        
                        return error(new ESLVal("TypeError",_v876,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v878)));
                      }
                    }
                    }
                  else if($468.isNil())
                    {ESLVal ms = _v47;
                      
                      return error(new ESLVal("TypeError",_v876,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v878)));
                    }
                  else {ESLVal ms = _v47;
                      
                      return error(new ESLVal("TypeError",_v876,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v878)));
                    }
                  }
                  default: {ESLVal ms = _v47;
                    
                    return error(new ESLVal("TypeError",_v876,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v878)));
                  }
                }
                }
                else
                  return error(new ESLVal("TypeError",_v876,new ESLVal("observeMessage must have an arg type that matches the message types of the behaviour type: ").add(ppType.apply(_v877,_v835).add(new ESLVal(" <> ").add(ppType.apply(new ESLVal("UnionType",_v876,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                      public ESLVal apply(ESLVal... $args) {
                        ESLVal $qualArg = $args[0];
                    {ESLVal _v48 = $qualArg;
                          
                          switch(_v48.termName) {
                          case "MessageType": {ESLVal $502 = _v48.termRef(0);
                            ESLVal $501 = _v48.termRef(1);
                            
                            if($501.isCons())
                            {ESLVal $503 = $501.head();
                              ESLVal $504 = $501.tail();
                              
                              if($504.isCons())
                              {ESLVal $505 = $504.head();
                                ESLVal $506 = $504.tail();
                                
                                {ESLVal _0 = _v48;
                                
                                return ESLVal.list();
                              }
                              }
                            else if($504.isNil())
                              {ESLVal ml = $502;
                                
                                {ESLVal t = $503;
                                
                                return ESLVal.list(((Supplier<ESLVal>)() -> { 
                                  if(isTime.apply(t).not().boolVal)
                                    return ESLVal.list(t);
                                    else
                                      return ESLVal.list();
                                }).get());
                              }
                              }
                            else {ESLVal _0 = _v48;
                                
                                return ESLVal.list();
                              }
                            }
                          else if($501.isNil())
                            {ESLVal _0 = _v48;
                              
                              return ESLVal.list();
                            }
                          else {ESLVal _0 = _v48;
                              
                              return ESLVal.list();
                            }
                          }
                          default: {ESLVal _0 = _v48;
                            
                            return ESLVal.list();
                          }
                        }
                        }
                      }
                    }).map(getMessageTypes.apply(_v831)).flatten().flatten()),_v835))))));
            }
          });
        ESLVal findLoc = new ESLVal(new Function(new ESLVal("findLoc"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v867 = $args[0];
          ESLVal _v868 = $args[1];
          {ESLVal _v49 = _v868;
                
                if(_v49.isCons())
                {ESLVal $507 = _v49.head();
                  ESLVal $508 = _v49.tail();
                  
                  switch($507.termName) {
                  case "Binding": {ESLVal $520 = $507.termRef(0);
                    ESLVal $519 = $507.termRef(1);
                    ESLVal $518 = $507.termRef(2);
                    ESLVal $517 = $507.termRef(3);
                    ESLVal $516 = $507.termRef(4);
                    
                    {ESLVal _v872 = $520;
                    
                    {ESLVal m = $519;
                    
                    {ESLVal t = $518;
                    
                    {ESLVal st = $517;
                    
                    {ESLVal e = $516;
                    
                    {ESLVal _v873 = $508;
                    
                    if(m.eql(_v867).boolVal)
                    return _v872;
                    else
                      {ESLVal b = $507;
                        
                        {ESLVal _v874 = $508;
                        
                        return findLoc.apply(_v867,_v874);
                      }
                      }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                case "FunBind": {ESLVal $515 = $507.termRef(0);
                    ESLVal $514 = $507.termRef(1);
                    ESLVal $513 = $507.termRef(2);
                    ESLVal $512 = $507.termRef(3);
                    ESLVal $511 = $507.termRef(4);
                    ESLVal $510 = $507.termRef(5);
                    ESLVal $509 = $507.termRef(6);
                    
                    {ESLVal _v869 = $515;
                    
                    {ESLVal m = $514;
                    
                    {ESLVal ps = $513;
                    
                    {ESLVal t = $512;
                    
                    {ESLVal st = $511;
                    
                    {ESLVal g = $510;
                    
                    {ESLVal e = $509;
                    
                    {ESLVal _v870 = $508;
                    
                    if(m.eql(_v867).boolVal)
                    return _v869;
                    else
                      {ESLVal b = $507;
                        
                        {ESLVal _v871 = $508;
                        
                        return findLoc.apply(_v867,_v871);
                      }
                      }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal b = $507;
                    
                    {ESLVal _v875 = $508;
                    
                    return findLoc.apply(_v867,_v875);
                  }
                  }
                }
                }
              else if(_v49.isNil())
                return p0;
              else return error(new ESLVal("case error at Pos(32456,32760)").add(ESLVal.list(_v49)));
              }
            }
          });
        ESLVal findType = new ESLVal(new Function(new ESLVal("findType"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v858 = $args[0];
          ESLVal _v859 = $args[1];
          {ESLVal _v50 = _v859;
                
                if(_v50.isCons())
                {ESLVal $521 = _v50.head();
                  ESLVal $522 = _v50.tail();
                  
                  switch($521.termName) {
                  case "Binding": {ESLVal $534 = $521.termRef(0);
                    ESLVal $533 = $521.termRef(1);
                    ESLVal $532 = $521.termRef(2);
                    ESLVal $531 = $521.termRef(3);
                    ESLVal $530 = $521.termRef(4);
                    
                    {ESLVal _v863 = $534;
                    
                    {ESLVal m = $533;
                    
                    {ESLVal t = $532;
                    
                    {ESLVal st = $531;
                    
                    {ESLVal e = $530;
                    
                    {ESLVal _v864 = $522;
                    
                    if(m.eql(_v858).boolVal)
                    return substTypeEnv.apply(_v835,t);
                    else
                      {ESLVal b = $521;
                        
                        {ESLVal _v865 = $522;
                        
                        return findType.apply(_v858,_v865);
                      }
                      }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                case "FunBind": {ESLVal $529 = $521.termRef(0);
                    ESLVal $528 = $521.termRef(1);
                    ESLVal $527 = $521.termRef(2);
                    ESLVal $526 = $521.termRef(3);
                    ESLVal $525 = $521.termRef(4);
                    ESLVal $524 = $521.termRef(5);
                    ESLVal $523 = $521.termRef(6);
                    
                    {ESLVal _v860 = $529;
                    
                    {ESLVal m = $528;
                    
                    {ESLVal ps = $527;
                    
                    {ESLVal t = $526;
                    
                    {ESLVal st = $525;
                    
                    {ESLVal g = $524;
                    
                    {ESLVal e = $523;
                    
                    {ESLVal _v861 = $522;
                    
                    if(m.eql(_v858).boolVal)
                    return substTypeEnv.apply(_v835,t);
                    else
                      {ESLVal b = $521;
                        
                        {ESLVal _v862 = $522;
                        
                        return findType.apply(_v858,_v862);
                      }
                      }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal b = $521;
                    
                    {ESLVal _v866 = $522;
                    
                    return findType.apply(_v858,_v866);
                  }
                  }
                }
                }
              else if(_v50.isNil())
                return $null;
              else return error(new ESLVal("case error at Pos(32814,33171)").add(ESLVal.list(_v50)));
              }
            }
          });
        ESLVal decs = new ESLVal(new Function(new ESLVal("decs"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v854 = $args[0];
          {ESLVal _v51 = _v854;
                
                if(_v51.isCons())
                {ESLVal $535 = _v51.head();
                  ESLVal $536 = _v51.tail();
                  
                  {ESLVal m = $535;
                  
                  {ESLVal _v855 = $536;
                  
                  {ESLVal _v856 = findType.apply(m,_v829);
                  ESLVal _v857 = findLoc.apply(m,_v829);
                  
                  if(_v856.eql($null).boolVal)
                  return error(new ESLVal("TypeError",_v857,new ESLVal("cannot find exported name ").add(m)));
                  else
                    return decs.apply(_v855).cons(new ESLVal("Dec",_v857,m,_v856,_v856));
                }
                }
                }
                }
              else if(_v51.isNil())
                return $nil;
              else return error(new ESLVal("case error at Pos(33214,33545)").add(ESLVal.list(_v51)));
              }
            }
          });
        ESLVal getMessageTypes = new ESLVal(new Function(new ESLVal("getMessageTypes"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v851 = $args[0];
          {ESLVal _v52 = _v851;
                
                if(_v52.isCons())
                {ESLVal $537 = _v52.head();
                  ESLVal $538 = _v52.tail();
                  
                  switch($537.termName) {
                  case "BArm": {ESLVal $542 = $537.termRef(0);
                    ESLVal $541 = $537.termRef(1);
                    ESLVal $540 = $537.termRef(2);
                    ESLVal $539 = $537.termRef(3);
                    
                    {ESLVal _v852 = $542;
                    
                    {ESLVal ps = $541;
                    
                    {ESLVal g = $540;
                    
                    {ESLVal e = $539;
                    
                    {ESLVal _v853 = $538;
                    
                    return getMessageTypes.apply(_v853).cons(getMessageType.apply(ps));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(33596,33751)").add(ESLVal.list(_v52)));
                }
                }
              else if(_v52.isNil())
                return $nil;
              else return error(new ESLVal("case error at Pos(33596,33751)").add(ESLVal.list(_v52)));
              }
            }
          });
        ESLVal getMessageType = new ESLVal(new Function(new ESLVal("getMessageType"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal ps = $args[0];
          {ESLVal _v53 = ps;
                
                if(_v53.isCons())
                {ESLVal $543 = _v53.head();
                  ESLVal $544 = _v53.tail();
                  
                  switch($543.termName) {
                  case "PTerm": {ESLVal $548 = $543.termRef(0);
                    ESLVal $547 = $543.termRef(1);
                    ESLVal $546 = $543.termRef(2);
                    ESLVal $545 = $543.termRef(3);
                    
                    if($544.isCons())
                    {ESLVal $549 = $544.head();
                      ESLVal $550 = $544.tail();
                      
                      return error(new ESLVal("case error at Pos(33801,34072)").add(ESLVal.list(_v53)));
                    }
                  else if($544.isNil())
                    {ESLVal pl = $548;
                      
                      {ESLVal termName = $547;
                      
                      {ESLVal targs = $546;
                      
                      {ESLVal _v850 = $545;
                      
                      {ESLVal ts = map.apply(new ESLVal(new Function(new ESLVal("fun205"),getSelf()) {
                          public ESLVal apply(ESLVal... $args) {
                            ESLVal p = $args[0];
                        return getPatternType.apply(_v824,p,_v832,_v833,_v834,_v835);
                          }
                        }),_v850);
                      
                      return new ESLVal("MessageType",pl,ESLVal.list(new ESLVal("TermType",pl,termName,ts)));
                    }
                    }
                    }
                    }
                    }
                  else return error(new ESLVal("case error at Pos(33801,34072)").add(ESLVal.list(_v53)));
                  }
                  default: return error(new ESLVal("case error at Pos(33801,34072)").add(ESLVal.list(_v53)));
                }
                }
              else if(_v53.isNil())
                return error(new ESLVal("case error at Pos(33801,34072)").add(ESLVal.list(_v53)));
              else return error(new ESLVal("case error at Pos(33801,34072)").add(ESLVal.list(_v53)));
              }
            }
          });
        ESLVal typeCheckArms = new ESLVal(new Function(new ESLVal("typeCheckArms"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v845 = $args[0];
          ESLVal _v846 = $args[1];
          ESLVal _v847 = $args[2];
          {ESLVal _v54 = _v845;
                
                if(_v54.isCons())
                {ESLVal $551 = _v54.head();
                  ESLVal $552 = _v54.tail();
                  
                  switch($551.termName) {
                  case "BArm": {ESLVal $556 = $551.termRef(0);
                    ESLVal $555 = $551.termRef(1);
                    ESLVal $554 = $551.termRef(2);
                    ESLVal $553 = $551.termRef(3);
                    
                    {ESLVal _v848 = $556;
                    
                    {ESLVal ps = $555;
                    
                    {ESLVal g = $554;
                    
                    {ESLVal e = $553;
                    
                    {ESLVal _v849 = $552;
                    
                    {typeCheckArm.apply(_v848,ps,g,e,_v846,_v847);
                  return typeCheckArms.apply(_v849,_v846,_v847);}
                  }
                  }
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(34148,34375)").add(ESLVal.list(_v54)));
                }
                }
              else if(_v54.isNil())
                return $null;
              else return error(new ESLVal("case error at Pos(34148,34375)").add(ESLVal.list(_v54)));
              }
            }
          });
        ESLVal typeCheckArm = new ESLVal(new Function(new ESLVal("typeCheckArm"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v836 = $args[0];
          ESLVal _v837 = $args[1];
          ESLVal _v838 = $args[2];
          ESLVal _v839 = $args[3];
          ESLVal _v840 = $args[4];
          ESLVal _v841 = $args[5];
          {ESLVal _v55 = _v837;
                
                if(_v55.isCons())
                {ESLVal $557 = _v55.head();
                  ESLVal $558 = _v55.tail();
                  
                  switch($557.termName) {
                  case "PTerm": {ESLVal $562 = $557.termRef(0);
                    ESLVal $561 = $557.termRef(1);
                    ESLVal $560 = $557.termRef(2);
                    ESLVal $559 = $557.termRef(3);
                    
                    if($558.isCons())
                    {ESLVal $563 = $558.head();
                      ESLVal $564 = $558.tail();
                      
                      return error(new ESLVal("case error at Pos(34474,34923)").add(ESLVal.list(_v55)));
                    }
                  else if($558.isNil())
                    {ESLVal pl = $562;
                      
                      {ESLVal termName = $561;
                      
                      {ESLVal targs = $560;
                      
                      {ESLVal _v842 = $559;
                      
                      {ESLVal ts = map.apply(new ESLVal(new Function(new ESLVal("fun206"),getSelf()) {
                          public ESLVal apply(ESLVal... $args) {
                            ESLVal p = $args[0];
                        return getPatternType.apply(_v836,p,_v840,_v841,_v834,_v835);
                          }
                        }),_v842);
                      
                      {patternTypes.apply(_v836,_v842,ts,_v840,_v841,_v834,_v835,new ESLVal(new Function(new ESLVal("fun207"),getSelf()) {
                      public ESLVal apply(ESLVal... $args) {
                        ESLVal _v843 = $args[0];
                    ESLVal _v844 = $args[1];
                    return expType.apply(_v839,_v840,_v844,_v834,_v835);
                      }
                    }));
                    return $null;}
                    }
                    }
                    }
                    }
                    }
                  else return error(new ESLVal("case error at Pos(34474,34923)").add(ESLVal.list(_v55)));
                  }
                  default: return error(new ESLVal("case error at Pos(34474,34923)").add(ESLVal.list(_v55)));
                }
                }
              else if(_v55.isNil())
                return error(new ESLVal("case error at Pos(34474,34923)").add(ESLVal.list(_v55)));
              else return error(new ESLVal("case error at Pos(34474,34923)").add(ESLVal.list(_v55)));
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "checkObservedMessage": return checkObservedMessage;
            
            case "isTime": return isTime;
            
            case "checkObserveMessageDeclaration": return checkObserveMessageDeclaration;
            
            case "findLoc": return findLoc;
            
            case "findType": return findType;
            
            case "decs": return decs;
            
            case "getMessageTypes": return getMessageTypes;
            
            case "getMessageType": return getMessageType;
            
            case "typeCheckArms": return typeCheckArms;
            
            case "typeCheckArm": return typeCheckArm;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal checkObservedMessage = letrec.get("checkObservedMessage");
      
      ESLVal isTime = letrec.get("isTime");
      
      ESLVal checkObserveMessageDeclaration = letrec.get("checkObserveMessageDeclaration");
      
      ESLVal findLoc = letrec.get("findLoc");
      
      ESLVal findType = letrec.get("findType");
      
      ESLVal decs = letrec.get("decs");
      
      ESLVal getMessageTypes = letrec.get("getMessageTypes");
      
      ESLVal getMessageType = letrec.get("getMessageType");
      
      ESLVal typeCheckArms = letrec.get("typeCheckArms");
      
      ESLVal typeCheckArm = letrec.get("typeCheckArm");
      
        {ESLVal parentType = ((Supplier<ESLVal>)() -> { 
            if(_v827.eql($null).boolVal)
              return actType0;
              else
                return expType.apply(_v827,_v832,_v833,_v834,_v835);
          }).get();
        ESLVal localEnv = parBind.apply(_v829,_v832,_v833,_v834,_v835);
        
        {ESLVal exportedDecs = decs.apply(_v828);
        
        {ESLVal messageTypes = getMessageTypes.apply(_v831);
        
        {ESLVal _v888 = new ESLVal("ExtendedAct",_v824,parentType,exportedDecs,messageTypes);
        ESLVal _v889 = ESLVal.list(new ESLVal("Map",new ESLVal("$super"),parentType));
        
        {typeCheckExports.apply(_v824,exportedDecs,_v829,_v888,localEnv.add(_v833),_v835,_v834);
      typeCheckValues.apply(valueDefs.apply(_v829),_v888,_v889.add(localEnv.add(_v833)),_v835,_v834);
      expType.apply(_v830,_v888,_v889.add(localEnv.add(_v833)),_v834,_v835);
      typeCheckArms.apply(_v831,_v888,_v889.add(localEnv.add(_v833)));
      checkObservedMessage.apply();
      return _v888;}
      }
      }
      }
      }}
      
    }
  });
  private static ESLVal typeCheckExports = new ESLVal(new Function(new ESLVal("typeCheckExports"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v817 = $args[0];
  ESLVal _v818 = $args[1];
  ESLVal _v819 = $args[2];
  ESLVal _v820 = $args[3];
  ESLVal _v821 = $args[4];
  ESLVal _v822 = $args[5];
  ESLVal _v823 = $args[6];
  {{
        ESLVal _v56 = _v818;
        while(_v56.isCons()) {
          ESLVal e = _v56.headVal;
          if(exists.apply(new ESLVal(new Function(new ESLVal("fun208"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal b = $args[0];
          return bindingName.apply(b).eql(decName.apply(e)).and(typeEqual.apply(lookupType.apply(decName.apply(e),_v821),decType.apply(e)));
            }
          }),_v819).boolVal)
            {}
            else
              error(new ESLVal("TypeError",_v817,new ESLVal(" cannot find export for ").add(decName.apply(e))));
          _v56 = _v56.tailVal;}
      }
      return $null;}
    }
  });
  private static ESLVal bTypeExports = new ESLVal(new Function(new ESLVal("bTypeExports"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v57 = t;
        
        switch(_v57.termName) {
        case "ExtendedAct": {ESLVal $575 = _v57.termRef(0);
          ESLVal $574 = _v57.termRef(1);
          ESLVal $573 = _v57.termRef(2);
          ESLVal $572 = _v57.termRef(3);
          
          {ESLVal l = $575;
          
          {ESLVal parent = $574;
          
          {ESLVal exports = $573;
          
          {ESLVal message = $572;
          
          return bTypeExports.apply(parent).add(exports);
        }
        }
        }
        }
        }
      case "ActType": {ESLVal $571 = _v57.termRef(0);
          ESLVal $570 = _v57.termRef(1);
          ESLVal $569 = _v57.termRef(2);
          
          {ESLVal l = $571;
          
          {ESLVal exports = $570;
          
          {ESLVal message = $569;
          
          return exports;
        }
        }
        }
        }
      case "TypeClosure": {ESLVal $568 = _v57.termRef(0);
          
          {ESLVal f = $568;
          
          return bTypeExports.apply(f.apply());
        }
        }
      case "RecType": {ESLVal $567 = _v57.termRef(0);
          ESLVal $566 = _v57.termRef(1);
          ESLVal $565 = _v57.termRef(2);
          
          {ESLVal l = $567;
          
          {ESLVal n = $566;
          
          {ESLVal _v816 = $565;
          
          return bTypeExports.apply(substType.apply(new ESLVal("RecType",l,n,_v816),n,_v816));
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(36349,36759)").add(ESLVal.list(_v57)));
      }
      }
    }
  });
  private static ESLVal cmpType = new ESLVal(new Function(new ESLVal("cmpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v802 = $args[0];
  ESLVal _v803 = $args[1];
  ESLVal _v804 = $args[2];
  ESLVal _v805 = $args[3];
  ESLVal _v806 = $args[4];
  ESLVal _v807 = $args[5];
  ESLVal _v808 = $args[6];
  {ESLVal _v58 = _v804;
        
        if(_v58.isCons())
        {ESLVal $576 = _v58.head();
          ESLVal $577 = _v58.tail();
          
          switch($576.termName) {
          case "BQual": {ESLVal $582 = $576.termRef(0);
            ESLVal $581 = $576.termRef(1);
            ESLVal $580 = $576.termRef(2);
            
            {ESLVal _v811 = $582;
            
            {ESLVal p = $581;
            
            {ESLVal list = $580;
            
            {ESLVal _v812 = $577;
            
            {ESLVal lType = expType.apply(list,_v805,_v806,_v807,_v808);
            
            {ESLVal _v59 = lType;
            
            switch(_v59.termName) {
            case "ListType": {ESLVal $584 = _v59.termRef(0);
              ESLVal $583 = _v59.termRef(1);
              
              {ESLVal ll = $584;
              
              {ESLVal t = $583;
              
              {ESLVal _v813 = _v812;
              
              return patternType.apply(_v811,p,substTypeEnv.apply(_v808,t),_v805,_v806,_v807,_v808,new ESLVal(new Function(new ESLVal("fun209"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal _v814 = $args[0];
              ESLVal _v815 = $args[1];
              return cmpType.apply(_v811,_v803,_v813,_v805,_v815,_v807,_v808);
                }
              }));
            }
            }
            }
            }
            default: {ESLVal t = _v59;
              
              return error(new ESLVal("TypeError",_v811,new ESLVal("qualifier binding expects a list: ").add(ppType.apply(t,_v808))));
            }
          }
          }
          }
          }
          }
          }
          }
          }
        case "PQual": {ESLVal $579 = $576.termRef(0);
            ESLVal $578 = $576.termRef(1);
            
            {ESLVal _v809 = $579;
            
            {ESLVal b = $578;
            
            {ESLVal _v810 = $577;
            
            {ESLVal bType = expType.apply(b,_v805,_v806,_v807,_v808);
            
            if(isBoolType.apply(bType).boolVal)
            return cmpType.apply(_v809,_v803,_v810,_v805,_v806,_v807,_v808);
            else
              return error(new ESLVal("TypeError",_v809,new ESLVal("qualifier expects a boolean type: ").add(ppType.apply(bType,_v808))));
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(36870,37856)").add(ESLVal.list(_v58)));
        }
        }
      else if(_v58.isNil())
        {ESLVal t = expType.apply(_v803,_v805,_v806,_v807,_v808);
          
          return new ESLVal("ListType",_v802,t);
        }
      else return error(new ESLVal("case error at Pos(36870,37856)").add(ESLVal.list(_v58)));
      }
    }
  });
  private static ESLVal updateType = new ESLVal(new Function(new ESLVal("updateType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v795 = $args[0];
  ESLVal _v796 = $args[1];
  ESLVal _v797 = $args[2];
  ESLVal _v798 = $args[3];
  ESLVal _v799 = $args[4];
  ESLVal _v800 = $args[5];
  ESLVal _v801 = $args[6];
  {ESLVal t = lookupType.apply(_v796,_v799);
        
        if(t.eql($null).boolVal)
        return error(new ESLVal("TypeError",_v795,new ESLVal("unbound variable ").add(_v796)));
        else
          {ESLVal valueType = expType.apply(_v797,_v798,_v799,_v800,_v801);
            
            if(subType.apply(valueType,t).boolVal)
            return valueType;
            else
              return error(new ESLVal("TypeError",_v795,new ESLVal("type of variable ").add(_v796.add(new ESLVal("::").add(ppType.apply(t,_v801).add(new ESLVal(" does not agree with value type ").add(ppType.apply(valueType,_v801))))))));
          }
      }
    }
  });
  private static ESLVal letType = new ESLVal(new Function(new ESLVal("letType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v788 = $args[0];
  ESLVal _v789 = $args[1];
  ESLVal _v790 = $args[2];
  ESLVal _v791 = $args[3];
  ESLVal _v792 = $args[4];
  ESLVal _v793 = $args[5];
  ESLVal _v794 = $args[6];
  {ESLVal env = parBind.apply(_v789,_v791,_v792,_v793,_v794);
        
        {{
        ESLVal _v60 = _v789;
        while(_v60.isCons()) {
          ESLVal b = _v60.headVal;
          typeCheckDef.apply(b,_v791,_v792,env.add(_v792),_v793,_v794);
          _v60 = _v60.tailVal;}
      }
      return expType.apply(_v790,_v791,env.add(_v792),_v793,_v794);}
      }
    }
  });
  private static ESLVal letrecType = new ESLVal(new Function(new ESLVal("letrecType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v781 = $args[0];
  ESLVal _v782 = $args[1];
  ESLVal _v783 = $args[2];
  ESLVal _v784 = $args[3];
  ESLVal _v785 = $args[4];
  ESLVal _v786 = $args[5];
  ESLVal _v787 = $args[6];
  {ESLVal env = recBind.apply(_v782,_v784,_v785,_v786,_v787);
        
        {{
        ESLVal _v61 = _v782;
        while(_v61.isCons()) {
          ESLVal b = _v61.headVal;
          typeCheckDef.apply(b,_v784,env.add(_v785),env.add(_v785),_v786,_v787);
          _v61 = _v61.tailVal;}
      }
      return expType.apply(_v783,_v784,env.add(_v785),_v786,_v787);}
      }
    }
  });
  private static ESLVal checkDupBindings = new ESLVal(new Function(new ESLVal("checkDupBindings"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal bs = $args[0];
  {ESLVal _v62 = bs;
        
        if(_v62.isCons())
        {ESLVal $585 = _v62.head();
          ESLVal $586 = _v62.tail();
          
          {ESLVal b = $585;
          
          {ESLVal _v780 = $586;
          
          if(member.apply(bindingName.apply(b),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              $v.add(bindingName.apply(b));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(_v780)).boolVal)
          return error(new ESLVal("TypeError",bindingLoc.apply(b),new ESLVal("duplicate definitions for ").add(bindingName.apply(b))));
          else
            return checkDupBindings.apply(_v780);
        }
        }
        }
      else if(_v62.isNil())
        return $null;
      else return error(new ESLVal("case error at Pos(39102,39367)").add(ESLVal.list(_v62)));
      }
    }
  });
  private static ESLVal parBind = new ESLVal(new Function(new ESLVal("parBind"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v775 = $args[0];
  ESLVal _v776 = $args[1];
  ESLVal _v777 = $args[2];
  ESLVal _v778 = $args[3];
  ESLVal _v779 = $args[4];
  {checkDupBindings.apply(_v775);
      return valueDefsToTEnv.apply(valueDefs.apply(_v775),_v776,_v777,_v778,_v779);}
    }
  });
  private static ESLVal recBind = new ESLVal(new Function(new ESLVal("recBind"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v770 = $args[0];
  ESLVal _v771 = $args[1];
  ESLVal _v772 = $args[2];
  ESLVal _v773 = $args[3];
  ESLVal _v774 = $args[4];
  return valueDefsToTEnv.apply(valueDefs.apply(_v770),_v771,_v772,_v773,_v774);
    }
  });
  private static ESLVal caseType = new ESLVal(new Function(new ESLVal("caseType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v763 = $args[0];
  ESLVal _v764 = $args[1];
  ESLVal _v765 = $args[2];
  ESLVal _v766 = $args[3];
  ESLVal _v767 = $args[4];
  ESLVal _v768 = $args[5];
  ESLVal _v769 = $args[6];
  {ESLVal ts1 = expTypes.apply(_v764,_v766,_v767,_v768,_v769);
        
        {ESLVal ts2 = armTypes.apply(_v765,ts1,_v766,_v767,_v768,_v769);
        
        if(allEqualTypes.apply(head.apply(ts2),tail.apply(ts2)).boolVal)
        return head.apply(ts2);
        else
          return error(new ESLVal("TypeError",_v763,new ESLVal("case arm types do not agree: ").add(ppTypes.apply(ts1,_v769).add(new ESLVal(" ").add(ppTypes.apply(ts2,_v769))))));
      }
      }
    }
  });
  private static ESLVal tryType = new ESLVal(new Function(new ESLVal("tryType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v756 = $args[0];
  ESLVal _v757 = $args[1];
  ESLVal _v758 = $args[2];
  ESLVal _v759 = $args[3];
  ESLVal _v760 = $args[4];
  ESLVal _v761 = $args[5];
  ESLVal _v762 = $args[6];
  {ESLVal ts1 = expTypes.apply(ESLVal.list(_v757),_v759,_v760,_v761,_v762);
        
        {ESLVal ts2 = armTypes.apply(_v758,ts1,_v759,_v760,_v761,_v762);
        
        if(allEqualTypes.apply(head.apply(ts2),tail.apply(ts2)).boolVal)
        return head.apply(ts2);
        else
          return error(new ESLVal("TypeError",_v756,new ESLVal("try arm types do not agree: ").add(ppTypes.apply(ts1,_v762).add(new ESLVal(" ").add(ppTypes.apply(ts2,_v762))))));
      }
      }
    }
  });
  private static ESLVal armTypes = new ESLVal(new Function(new ESLVal("armTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v749 = $args[0];
  ESLVal _v750 = $args[1];
  ESLVal _v751 = $args[2];
  ESLVal _v752 = $args[3];
  ESLVal _v753 = $args[4];
  ESLVal _v754 = $args[5];
  {ESLVal _v63 = _v749;
        
        if(_v63.isCons())
        {ESLVal $587 = _v63.head();
          ESLVal $588 = _v63.tail();
          
          {ESLVal a = $587;
          
          {ESLVal _v755 = $588;
          
          return armTypes.apply(_v755,_v750,_v751,_v752,_v753,_v754).cons(armType.apply(a,_v750,_v751,_v752,_v753,_v754));
        }
        }
        }
      else if(_v63.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(40732,40901)").add(ESLVal.list(_v63)));
      }
    }
  });
  private static ESLVal armType = new ESLVal(new Function(new ESLVal("armType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v741 = $args[0];
  ESLVal _v742 = $args[1];
  ESLVal _v743 = $args[2];
  ESLVal _v744 = $args[3];
  ESLVal _v745 = $args[4];
  ESLVal _v746 = $args[5];
  {ESLVal _v64 = _v741;
        
        switch(_v64.termName) {
        case "BArm": {ESLVal $592 = _v64.termRef(0);
          ESLVal $591 = _v64.termRef(1);
          ESLVal $590 = _v64.termRef(2);
          ESLVal $589 = _v64.termRef(3);
          
          {ESLVal l = $592;
          
          {ESLVal ps = $591;
          
          {ESLVal guard = $590;
          
          {ESLVal exp = $589;
          
          {checkPatterns.apply(l,ps);
        if(length.apply(ps).eql(length.apply(_v742)).boolVal)
          return patternTypes.apply(l,ps,_v742,_v743,_v744,_v745,_v746,new ESLVal(new Function(new ESLVal("fun210"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v747 = $args[0];
            ESLVal _v748 = $args[1];
            return guardedExpType.apply(l,guard,exp,_v743,_v748,_v745,_v746);
              }
            }));
          else
            return error(new ESLVal("TypeError",l,new ESLVal("number of patterns ").add(length.apply(ps).add(new ESLVal(" does not match supplied values: ").add(length.apply(_v742))))));}
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(41003,41464)").add(ESLVal.list(_v64)));
      }
      }
    }
  });
  private static ESLVal refType = new ESLVal(new Function(new ESLVal("refType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v684 = $args[0];
  ESLVal _v685 = $args[1];
  ESLVal _v686 = $args[2];
  ESLVal _v687 = $args[3];
  ESLVal _v688 = $args[4];
  ESLVal _v689 = $args[5];
  ESLVal _v690 = $args[6];
  { LetRec letrec = new LetRec() {
        ESLVal t = derefType.apply(expType.apply(_v685,_v687,_v688,_v689,_v690));
        ESLVal findExport = new ESLVal(new Function(new ESLVal("findExport"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal decs = $args[0];
          {ESLVal _v65 = decs;
                
                if(_v65.isCons())
                {ESLVal $593 = _v65.head();
                  ESLVal $594 = _v65.tail();
                  
                  switch($593.termName) {
                  case "Dec": {ESLVal $598 = $593.termRef(0);
                    ESLVal $597 = $593.termRef(1);
                    ESLVal $596 = $593.termRef(2);
                    ESLVal $595 = $593.termRef(3);
                    
                    {ESLVal _v712 = $598;
                    
                    {ESLVal m = $597;
                    
                    {ESLVal t = $596;
                    
                    {ESLVal st = $595;
                    
                    {ESLVal _v713 = $594;
                    
                    if(m.eql(_v686).boolVal)
                    return t;
                    else
                      {ESLVal d = $593;
                        
                        {ESLVal _v714 = $594;
                        
                        return findExport.apply(_v714);
                      }
                      }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal d = $593;
                    
                    {ESLVal _v715 = $594;
                    
                    return findExport.apply(_v715);
                  }
                  }
                }
                }
              else if(_v65.isNil())
                return $null;
              else return error(new ESLVal("case error at Pos(41692,41865)").add(ESLVal.list(_v65)));
              }
            }
          });
        ESLVal findField = new ESLVal(new Function(new ESLVal("findField"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal fs = $args[0];
          {ESLVal _v66 = fs;
                
                if(_v66.isCons())
                {ESLVal $599 = _v66.head();
                  ESLVal $600 = _v66.tail();
                  
                  switch($599.termName) {
                  case "Dec": {ESLVal $604 = $599.termRef(0);
                    ESLVal $603 = $599.termRef(1);
                    ESLVal $602 = $599.termRef(2);
                    ESLVal $601 = $599.termRef(3);
                    
                    {ESLVal _v707 = $604;
                    
                    {ESLVal m = $603;
                    
                    {ESLVal t = $602;
                    
                    {ESLVal ds = $601;
                    
                    {ESLVal _v708 = $600;
                    
                    if(m.eql(_v686).boolVal)
                    return t;
                    else
                      {ESLVal _v709 = $599;
                        
                        {ESLVal _v710 = $600;
                        
                        return findField.apply(_v710);
                      }
                      }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal t = $599;
                    
                    {ESLVal _v711 = $600;
                    
                    return findField.apply(_v711);
                  }
                  }
                }
                }
              else if(_v66.isNil())
                return error(new ESLVal("TypeError",_v684,new ESLVal("cannot find field name ").add(_v686)));
              else return error(new ESLVal("case error at Pos(41906,42114)").add(ESLVal.list(_v66)));
              }
            }
          });
        ESLVal exportsObserve = new ESLVal(new Function(new ESLVal("exportsObserve"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal exports = $args[0];
          {ESLVal _v67 = exports;
                
                if(_v67.isCons())
                {ESLVal $605 = _v67.head();
                  ESLVal $606 = _v67.tail();
                  
                  switch($605.termName) {
                  case "Dec": {ESLVal $610 = $605.termRef(0);
                    ESLVal $609 = $605.termRef(1);
                    ESLVal $608 = $605.termRef(2);
                    ESLVal $607 = $605.termRef(3);
                    
                    switch($609.strVal) {
                    case "observeState": switch($608.termName) {
                      case "FunType": {ESLVal $613 = $608.termRef(0);
                        ESLVal $612 = $608.termRef(1);
                        ESLVal $611 = $608.termRef(2);
                        
                        if($612.isCons())
                        {ESLVal $614 = $612.head();
                          ESLVal $615 = $612.tail();
                          
                          {ESLVal d = $605;
                          
                          {ESLVal _v702 = $606;
                          
                          return exportsObserve.apply(_v702);
                        }
                        }
                        }
                      else if($612.isNil())
                        {ESLVal dl = $610;
                          
                          {ESLVal fl = $613;
                          
                          {ESLVal stateType = $611;
                          
                          {ESLVal dt = $607;
                          
                          {ESLVal x = $606;
                          
                          return $true;
                        }
                        }
                        }
                        }
                        }
                      else {ESLVal d = $605;
                          
                          {ESLVal _v703 = $606;
                          
                          return exportsObserve.apply(_v703);
                        }
                        }
                      }
                      default: {ESLVal d = $605;
                        
                        {ESLVal _v704 = $606;
                        
                        return exportsObserve.apply(_v704);
                      }
                      }
                    }
                    default: {ESLVal d = $605;
                      
                      {ESLVal _v705 = $606;
                      
                      return exportsObserve.apply(_v705);
                    }
                    }
                  }
                  }
                  default: {ESLVal d = $605;
                    
                    {ESLVal _v706 = $606;
                    
                    return exportsObserve.apply(_v706);
                  }
                  }
                }
                }
              else if(_v67.isNil())
                return $false;
              else return error(new ESLVal("case error at Pos(42165,42324)").add(ESLVal.list(_v67)));
              }
            }
          });
        ESLVal getObserver = new ESLVal(new Function(new ESLVal("getObserver"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v691 = $args[0];
          ESLVal _v692 = $args[1];
          ESLVal _v693 = $args[2];
          {ESLVal _v68 = _v692;
                
                return $ndCase.apply(_v68,ESLVal.list(new ESLVal("$selectMid",new ESLVal(new Function(new ESLVal("add"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal $617 = $args[0];
                ESLVal $618 = $args[1];
                ESLVal $619 = $args[2];
                ESLVal $616 = $args[3];
                switch($618.termName) {
                      case "Dec": {ESLVal $623 = $618.termRef(0);
                        ESLVal $622 = $618.termRef(1);
                        ESLVal $621 = $618.termRef(2);
                        ESLVal $620 = $618.termRef(3);
                        
                        switch($622.strVal) {
                        case "observeState": switch($621.termName) {
                          case "FunType": {ESLVal $626 = $621.termRef(0);
                            ESLVal $625 = $621.termRef(1);
                            ESLVal $624 = $621.termRef(2);
                            
                            if($625.isCons())
                            {ESLVal $627 = $625.head();
                              ESLVal $628 = $625.tail();
                              
                              return $616.apply();
                            }
                          else if($625.isNil())
                            {ESLVal e1 = $617;
                              
                              {ESLVal dl = $623;
                              
                              {ESLVal fl = $626;
                              
                              {ESLVal stateType = $624;
                              
                              {ESLVal dt = $620;
                              
                              {ESLVal e2 = $619;
                              
                              {ESLVal _v69 = _v692;
                              
                              return $ndCase.apply(_v69,ESLVal.list(new ESLVal("$selectMid",new ESLVal(new Function(new ESLVal("add"),getSelf()) {
                                public ESLVal apply(ESLVal... $args) {
                                  ESLVal $630 = $args[0];
                              ESLVal $631 = $args[1];
                              ESLVal $632 = $args[2];
                              ESLVal $629 = $args[3];
                              switch($631.termName) {
                                    case "Dec": {ESLVal $636 = $631.termRef(0);
                                      ESLVal $635 = $631.termRef(1);
                                      ESLVal $634 = $631.termRef(2);
                                      ESLVal $633 = $631.termRef(3);
                                      
                                      switch($635.strVal) {
                                      case "observeMessage": switch($634.termName) {
                                        case "FunType": {ESLVal $639 = $634.termRef(0);
                                          ESLVal $638 = $634.termRef(1);
                                          ESLVal $637 = $634.termRef(2);
                                          
                                          if($638.isCons())
                                          {ESLVal $640 = $638.head();
                                            ESLVal $641 = $638.tail();
                                            
                                            if($641.isCons())
                                            {ESLVal $642 = $641.head();
                                              ESLVal $643 = $641.tail();
                                              
                                              return $629.apply();
                                            }
                                          else if($641.isNil())
                                            {ESLVal _v694 = $630;
                                              
                                              {ESLVal _v695 = $636;
                                              
                                              {ESLVal _v696 = $639;
                                              
                                              {ESLVal t = $640;
                                              
                                              {ESLVal messageType = $637;
                                              
                                              {ESLVal _v697 = $633;
                                              
                                              {ESLVal _v698 = $632;
                                              
                                              {ESLVal _v70 = typeNF.apply(messageType,_v690);
                                              
                                              switch(_v70.termName) {
                                              case "UnionType": {ESLVal $645 = _v70.termRef(0);
                                                ESLVal $644 = _v70.termRef(1);
                                                
                                                return $ndCase.apply($644,ESLVal.list(new ESLVal("$selectMid",new ESLVal(new Function(new ESLVal("add"),getSelf()) {
                                                  public ESLVal apply(ESLVal... $args) {
                                                    ESLVal $647 = $args[0];
                                                ESLVal $648 = $args[1];
                                                ESLVal $649 = $args[2];
                                                ESLVal $646 = $args[3];
                                                switch($648.termName) {
                                                      case "TermType": {ESLVal $652 = $648.termRef(0);
                                                        ESLVal $651 = $648.termRef(1);
                                                        ESLVal $650 = $648.termRef(2);
                                                        
                                                        switch($651.strVal) {
                                                        case "Something": if($650.isCons())
                                                          {ESLVal $653 = $650.head();
                                                            ESLVal $654 = $650.tail();
                                                            
                                                            if($654.isCons())
                                                            {ESLVal $655 = $654.head();
                                                              ESLVal $656 = $654.tail();
                                                              
                                                              return $646.apply();
                                                            }
                                                          else if($654.isNil())
                                                            {ESLVal ul = $645;
                                                              
                                                              {ESLVal ts1 = $647;
                                                              
                                                              {ESLVal tl = $652;
                                                              
                                                              {ESLVal _v699 = $653;
                                                              
                                                              {ESLVal ts2 = $649;
                                                              
                                                              return new ESLVal("ObserverType",_v691,stateType,_v699);
                                                            }
                                                            }
                                                            }
                                                            }
                                                            }
                                                          else return $646.apply();
                                                          }
                                                        else if($650.isNil())
                                                          return $646.apply();
                                                        else return $646.apply();
                                                        default: return $646.apply();
                                                      }
                                                      }
                                                      default: return $646.apply();
                                                    }
                                                  }
                                                }))),new ESLVal(new Function(new ESLVal("listFail"),getSelf()) {
                                                  public ESLVal apply(ESLVal... $args) {
                                                    {ESLVal _v700 = _v70;
                                                      
                                                      return error(new ESLVal("TypeError",_v691,new ESLVal("cannot find Something(t) for the message type: ").add(typeNF.apply(messageType,_v690))));
                                                    }
                                                  }
                                                }));
                                              }
                                              default: {ESLVal _v701 = _v70;
                                                
                                                return error(new ESLVal("TypeError",_v691,new ESLVal("cannot find Something(t) for the message type: ").add(typeNF.apply(messageType,_v690))));
                                              }
                                            }
                                            }
                                            }
                                            }
                                            }
                                            }
                                            }
                                            }
                                            }
                                          else return $629.apply();
                                          }
                                        else if($638.isNil())
                                          return $629.apply();
                                        else return $629.apply();
                                        }
                                        default: return $629.apply();
                                      }
                                      default: return $629.apply();
                                    }
                                    }
                                    default: return $629.apply();
                                  }
                                }
                              }))),new ESLVal(new Function(new ESLVal("listFail"),getSelf()) {
                                public ESLVal apply(ESLVal... $args) {
                                  return error(new ESLVal("case error at Pos(42498,42920)").add(ESLVal.list(_v69)));
                                }
                              }));
                            }
                            }
                            }
                            }
                            }
                            }
                            }
                          else return $616.apply();
                          }
                          default: return $616.apply();
                        }
                        default: return $616.apply();
                      }
                      }
                      default: return $616.apply();
                    }
                  }
                }))),new ESLVal(new Function(new ESLVal("listFail"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    {ESLVal es = _v68;
                      
                      return $null;
                    }
                  }
                }));
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "t": return t;
            
            case "findExport": return findExport;
            
            case "findField": return findField;
            
            case "exportsObserve": return exportsObserve;
            
            case "getObserver": return getObserver;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal t = letrec.get("t");
      
      ESLVal findExport = letrec.get("findExport");
      
      ESLVal findField = letrec.get("findField");
      
      ESLVal exportsObserve = letrec.get("exportsObserve");
      
      ESLVal getObserver = letrec.get("getObserver");
      
        {ESLVal _v71 = typeNF.apply(t,_v690);
        
        switch(_v71.termName) {
        case "StrType": {ESLVal $670 = _v71.termRef(0);
          
          {ESLVal sl = $670;
          
          if(_v686.eql(new ESLVal("explode")).boolVal)
          return new ESLVal("ListType",sl,new ESLVal("IntType",sl));
          else
            {ESLVal _v738 = $670;
              
              if(_v686.eql(new ESLVal("writeDate")).boolVal)
              return new ESLVal("FloatType",_v738);
              else
                {ESLVal _v739 = _v71;
                  
                  return error(new ESLVal("TypeError",_v684,new ESLVal("expecting a record type, but received ").add(ppType.apply(_v739,_v690))));
                }
            }
        }
        }
      case "TableType": {ESLVal $669 = _v71.termRef(0);
          ESLVal $668 = _v71.termRef(1);
          ESLVal $667 = _v71.termRef(2);
          
          {ESLVal _v721 = $669;
          
          {ESLVal k = $668;
          
          {ESLVal v = $667;
          
          if(_v686.eql(new ESLVal("get")).boolVal)
          return new ESLVal("FunType",_v721,ESLVal.list(k),v);
          else
            {ESLVal _v722 = $669;
              
              {ESLVal _v723 = $668;
              
              {ESLVal _v724 = $667;
              
              if(_v686.eql(new ESLVal("put")).boolVal)
              return new ESLVal("FunType",_v722,ESLVal.list(_v723,_v724),t);
              else
                {ESLVal _v725 = $669;
                  
                  {ESLVal _v726 = $668;
                  
                  {ESLVal _v727 = $667;
                  
                  if(_v686.eql(new ESLVal("keys")).boolVal)
                  return new ESLVal("ListType",_v725,_v726);
                  else
                    {ESLVal _v728 = $669;
                      
                      {ESLVal _v729 = $668;
                      
                      {ESLVal _v730 = $667;
                      
                      if(_v686.eql(new ESLVal("vals")).boolVal)
                      return new ESLVal("ListType",_v728,_v730);
                      else
                        {ESLVal _v731 = $669;
                          
                          {ESLVal _v732 = $668;
                          
                          {ESLVal _v733 = $667;
                          
                          if(_v686.eql(new ESLVal("hasKey")).boolVal)
                          return new ESLVal("FunType",_v731,ESLVal.list(_v732),new ESLVal("BoolType",_v731));
                          else
                            {ESLVal _v734 = $669;
                              
                              {ESLVal _v735 = $668;
                              
                              {ESLVal _v736 = $667;
                              
                              if(_v686.eql(new ESLVal("clear")).boolVal)
                              return new ESLVal("FunType",_v734,ESLVal.list(),new ESLVal("VoidType",_v734));
                              else
                                {ESLVal _v737 = _v71;
                                  
                                  return error(new ESLVal("TypeError",_v734,new ESLVal("expecting a record type, but received ").add(ppType.apply(_v737,_v690))));
                                }
                            }
                            }
                            }
                        }
                        }
                        }
                    }
                    }
                    }
                }
                }
                }
            }
            }
            }
        }
        }
        }
        }
      case "ListType": {ESLVal $666 = _v71.termRef(0);
          ESLVal $665 = _v71.termRef(1);
          
          {ESLVal ll = $666;
          
          {ESLVal _v719 = $665;
          
          if(_v686.eql(new ESLVal("implode")).boolVal)
          return new ESLVal("StrType",ll);
          else
            {ESLVal _v720 = _v71;
              
              return error(new ESLVal("TypeError",_v684,new ESLVal("expecting a record type, but received ").add(ppType.apply(_v720,_v690))));
            }
        }
        }
        }
      case "RecordType": {ESLVal $664 = _v71.termRef(0);
          ESLVal $663 = _v71.termRef(1);
          
          {ESLVal rl = $664;
          
          {ESLVal fs = $663;
          
          return findField.apply(fs);
        }
        }
        }
      case "ObservedType": {ESLVal $662 = _v71.termRef(0);
          ESLVal $661 = _v71.termRef(1);
          ESLVal $660 = _v71.termRef(2);
          
          {ESLVal _v717 = $662;
          
          {ESLVal s = $661;
          
          {ESLVal m = $660;
          
          if(_v686.eql(new ESLVal("addObserver")).boolVal)
          return new ESLVal("FunType",_v717,ESLVal.list(new ESLVal("ObserverType",_v717,s,m)),new ESLVal("VoidType",new ESLVal("Pos",$zero,$zero)));
          else
            {ESLVal _v718 = _v71;
              
              return error(new ESLVal("TypeError",_v717,new ESLVal("expecting a record type, but received ").add(ppType.apply(_v718,_v690))));
            }
        }
        }
        }
        }
      case "ActType": {ESLVal $659 = _v71.termRef(0);
          ESLVal $658 = _v71.termRef(1);
          ESLVal $657 = _v71.termRef(2);
          
          {ESLVal al = $659;
          
          {ESLVal exports = $658;
          
          {ESLVal handlers = $657;
          
          if(_v686.eql(new ESLVal("addObserver")).and(exportsObserve.apply(exports)).boolVal)
          return new ESLVal("FunType",_v684,ESLVal.list(getObserver.apply(al,exports,handlers)),new ESLVal("VoidType",new ESLVal("Pos",$zero,$zero)));
          else
            {ESLVal _v716 = findExport.apply(exports);
              
              if(_v716.eql($null).boolVal)
              return error(new ESLVal("TypeError",_v684,new ESLVal("behaviour type does not export ").add(_v686)));
              else
                return substTypeEnv.apply(_v690,_v716);
            }
        }
        }
        }
        }
        default: {ESLVal _v740 = _v71;
          
          return error(new ESLVal("TypeError",_v684,new ESLVal("expecting a record type, but received ").add(ppType.apply(_v740,_v690))));
        }
      }
      }}
      
    }
  });
  private static ESLVal derefType = new ESLVal(new Function(new ESLVal("derefType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v72 = t;
        
        switch(_v72.termName) {
        case "TypeClosure": {ESLVal $671 = _v72.termRef(0);
          
          {ESLVal f = $671;
          
          return derefType.apply(f.apply());
        }
        }
        default: {ESLVal _v683 = _v72;
          
          return _v683;
        }
      }
      }
    }
  });
  private static ESLVal recordType = new ESLVal(new Function(new ESLVal("recordType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v671 = $args[0];
  ESLVal _v672 = $args[1];
  ESLVal _v673 = $args[2];
  ESLVal _v674 = $args[3];
  ESLVal _v675 = $args[4];
  ESLVal _v676 = $args[5];
  { LetRec letrec = new LetRec() {
        ESLVal fieldTypes = new ESLVal(new Function(new ESLVal("fieldTypes"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v677 = $args[0];
          {ESLVal _v73 = _v677;
                
                if(_v73.isCons())
                {ESLVal $672 = _v73.head();
                  ESLVal $673 = _v73.tail();
                  
                  switch($672.termName) {
                  case "Binding": {ESLVal $678 = $672.termRef(0);
                    ESLVal $677 = $672.termRef(1);
                    ESLVal $676 = $672.termRef(2);
                    ESLVal $675 = $672.termRef(3);
                    ESLVal $674 = $672.termRef(4);
                    
                    {ESLVal _v678 = $678;
                    
                    {ESLVal n = $677;
                    
                    {ESLVal t = $676;
                    
                    {ESLVal st = $675;
                    
                    {ESLVal e = $674;
                    
                    {ESLVal _v679 = $673;
                    
                    {ESLVal _v680 = expType.apply(e,_v673,_v674,_v675,_v676);
                    
                    return fieldTypes.apply(_v679).cons(new ESLVal("Dec",_v678,n,_v680,_v680));
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v681 = _v73;
                    
                    return error(new ESLVal("TypeError",_v671,new ESLVal("unknown field representation: ").add(_v681)));
                  }
                }
                }
              else if(_v73.isNil())
                return $nil;
              else {ESLVal _v682 = _v73;
                  
                  return error(new ESLVal("TypeError",_v671,new ESLVal("unknown field representation: ").add(_v682)));
                }
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "fieldTypes": return fieldTypes;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal fieldTypes = letrec.get("fieldTypes");
      
        return new ESLVal("RecordType",_v671,fieldTypes.apply(_v672));}
      
    }
  });
  private static ESLVal forType = new ESLVal(new Function(new ESLVal("forType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v659 = $args[0];
  ESLVal _v660 = $args[1];
  ESLVal _v661 = $args[2];
  ESLVal _v662 = $args[3];
  ESLVal _v663 = $args[4];
  ESLVal _v664 = $args[5];
  ESLVal _v665 = $args[6];
  ESLVal _v666 = $args[7];
  {ESLVal _v667 = expType.apply(_v661,_v663,_v664,_v665,_v666);
        
        {ESLVal _v74 = _v667;
        
        switch(_v74.termName) {
        case "ListType": {ESLVal $680 = _v74.termRef(0);
          ESLVal $679 = _v74.termRef(1);
          
          {ESLVal _v668 = $680;
          
          {ESLVal t = $679;
          
          return patternType.apply(_v668,_v660,t,_v663,_v664,_v665,_v666,new ESLVal(new Function(new ESLVal("fun211"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v669 = $args[0];
          ESLVal _v670 = $args[1];
          return expType.apply(_v662,_v663,_v670,_v665,_v666);
            }
          }));
        }
        }
        }
        default: {ESLVal t = _v74;
          
          return error(new ESLVal("TypeError",_v659,new ESLVal("for type expects a list: ").add(_v661)));
        }
      }
      }
      }
    }
  });
  private static ESLVal patternTypes = new ESLVal(new Function(new ESLVal("patternTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v633 = $args[0];
  ESLVal _v634 = $args[1];
  ESLVal _v635 = $args[2];
  ESLVal _v636 = $args[3];
  ESLVal _v637 = $args[4];
  ESLVal _v638 = $args[5];
  ESLVal _v639 = $args[6];
  ESLVal _v640 = $args[7];
  {ESLVal _v75 = _v634;
        ESLVal _v76 = _v635;
        
        if(_v75.isCons())
        {ESLVal $681 = _v75.head();
          ESLVal $682 = _v75.tail();
          
          if(_v76.isCons())
          {ESLVal $683 = _v76.head();
            ESLVal $684 = _v76.tail();
            
            {ESLVal p = $681;
            
            {ESLVal _v641 = $682;
            
            {ESLVal t = $683;
            
            {ESLVal _v642 = $684;
            
            {ESLVal _v643 = _v641;
            ESLVal _v644 = _v642;
            
            return patternType.apply(_v633,p,t,_v636,_v637,_v638,_v639,new ESLVal(new Function(new ESLVal("fun212"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v645 = $args[0];
            ESLVal _v646 = $args[1];
            return patternTypes.apply(_v633,_v643,_v644,_v636,_v646,_v638,_v639,new ESLVal(new Function(new ESLVal("fun213"),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      ESLVal _v647 = $args[0];
                  ESLVal _v648 = $args[1];
                  return _v640.apply(_v647.cons(_v645),_v648);
                    }
                  }));
              }
            }));
          }
          }
          }
          }
          }
          }
        else if(_v76.isNil())
          {ESLVal _v649 = _v75;
            
            {ESLVal _v650 = _v76;
            
            return error(new ESLVal("TypeError",_v633,new ESLVal("somthing wrong with ").add(_v649.add(new ESLVal(" ").add(_v650)))));
          }
          }
        else {ESLVal _v651 = _v75;
            
            {ESLVal _v652 = _v76;
            
            return error(new ESLVal("TypeError",_v633,new ESLVal("somthing wrong with ").add(_v651.add(new ESLVal(" ").add(_v652)))));
          }
          }
        }
      else if(_v75.isNil())
        if(_v76.isCons())
          {ESLVal $685 = _v76.head();
            ESLVal $686 = _v76.tail();
            
            {ESLVal _v653 = _v75;
            
            {ESLVal _v654 = _v76;
            
            return error(new ESLVal("TypeError",_v633,new ESLVal("somthing wrong with ").add(_v653.add(new ESLVal(" ").add(_v654)))));
          }
          }
          }
        else if(_v76.isNil())
          return _v640.apply($nil,_v637);
        else {ESLVal _v655 = _v75;
            
            {ESLVal _v656 = _v76;
            
            return error(new ESLVal("TypeError",_v633,new ESLVal("somthing wrong with ").add(_v655.add(new ESLVal(" ").add(_v656)))));
          }
          }
      else {ESLVal _v657 = _v75;
          
          {ESLVal _v658 = _v76;
          
          return error(new ESLVal("TypeError",_v633,new ESLVal("somthing wrong with ").add(_v657.add(new ESLVal(" ").add(_v658)))));
        }
        }
      }
    }
  });
  private static ESLVal getPatternType = new ESLVal(new Function(new ESLVal("getPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v612 = $args[0];
  ESLVal _v613 = $args[1];
  ESLVal _v614 = $args[2];
  ESLVal _v615 = $args[3];
  ESLVal _v616 = $args[4];
  ESLVal _v617 = $args[5];
  {ESLVal _v77 = _v613;
        
        switch(_v77.termName) {
        case "PApplyType": {ESLVal $715 = _v77.termRef(0);
          ESLVal $714 = _v77.termRef(1);
          ESLVal $713 = _v77.termRef(2);
          
          {ESLVal _v630 = $715;
          
          {ESLVal _v631 = $714;
          
          {ESLVal args = $713;
          
          return error(new ESLVal("should this happen?"));
        }
        }
        }
        }
      case "PBool": {ESLVal $712 = _v77.termRef(0);
          ESLVal $711 = _v77.termRef(1);
          
          {ESLVal _v629 = $712;
          
          {ESLVal b = $711;
          
          return new ESLVal("BoolType",_v629);
        }
        }
        }
      case "PCons": {ESLVal $710 = _v77.termRef(0);
          ESLVal $709 = _v77.termRef(1);
          ESLVal $708 = _v77.termRef(2);
          
          {ESLVal _v628 = $710;
          
          {ESLVal hd = $709;
          
          {ESLVal tl = $708;
          
          return getPatternType.apply(_v628,tl,_v614,_v615,_v616,_v617);
        }
        }
        }
        }
      case "PBagCons": {ESLVal $707 = _v77.termRef(0);
          ESLVal $706 = _v77.termRef(1);
          ESLVal $705 = _v77.termRef(2);
          
          {ESLVal _v627 = $707;
          
          {ESLVal hd = $706;
          
          {ESLVal tl = $705;
          
          return getPatternType.apply(_v627,tl,_v614,_v615,_v616,_v617);
        }
        }
        }
        }
      case "PSetCons": {ESLVal $704 = _v77.termRef(0);
          ESLVal $703 = _v77.termRef(1);
          ESLVal $702 = _v77.termRef(2);
          
          {ESLVal _v626 = $704;
          
          {ESLVal hd = $703;
          
          {ESLVal tl = $702;
          
          return getPatternType.apply(_v626,tl,_v614,_v615,_v616,_v617);
        }
        }
        }
        }
      case "PNil": {ESLVal $701 = _v77.termRef(0);
          
          {ESLVal _v625 = $701;
          
          return new ESLVal("ForallType",_v625,ESLVal.list(new ESLVal("T")),new ESLVal("ListType",_v625,new ESLVal("VarType",_v625,new ESLVal("T"))));
        }
        }
      case "PNull": {ESLVal $700 = _v77.termRef(0);
          
          {ESLVal _v624 = $700;
          
          return new ESLVal("ForallType",_v624,ESLVal.list(new ESLVal("T")),new ESLVal("VarType",_v624,new ESLVal("T")));
        }
        }
      case "PEmptyBag": {ESLVal $699 = _v77.termRef(0);
          
          {ESLVal _v623 = $699;
          
          return new ESLVal("ForallType",_v623,ESLVal.list(new ESLVal("T")),new ESLVal("BagType",_v623,new ESLVal("VarType",_v623,new ESLVal("T"))));
        }
        }
      case "PEmptySet": {ESLVal $698 = _v77.termRef(0);
          
          {ESLVal _v622 = $698;
          
          return new ESLVal("ForallType",_v622,ESLVal.list(new ESLVal("T")),new ESLVal("SetType",_v622,new ESLVal("VarType",_v622,new ESLVal("T"))));
        }
        }
      case "PInt": {ESLVal $697 = _v77.termRef(0);
          ESLVal $696 = _v77.termRef(1);
          
          {ESLVal _v621 = $697;
          
          {ESLVal n = $696;
          
          return new ESLVal("IntType",_v621);
        }
        }
        }
      case "PVar": {ESLVal $695 = _v77.termRef(0);
          ESLVal $694 = _v77.termRef(1);
          ESLVal $693 = _v77.termRef(2);
          
          {ESLVal _v620 = $695;
          
          {ESLVal n = $694;
          
          {ESLVal pt = $693;
          
          return substTypeEnv.apply(_v617,pt);
        }
        }
        }
        }
      case "PStr": {ESLVal $692 = _v77.termRef(0);
          ESLVal $691 = _v77.termRef(1);
          
          {ESLVal _v619 = $692;
          
          {ESLVal s = $691;
          
          return new ESLVal("StrType",_v619);
        }
        }
        }
      case "PTerm": {ESLVal $690 = _v77.termRef(0);
          ESLVal $689 = _v77.termRef(1);
          ESLVal $688 = _v77.termRef(2);
          ESLVal $687 = _v77.termRef(3);
          
          {ESLVal _v618 = $690;
          
          {ESLVal n = $689;
          
          {ESLVal ts = $688;
          
          {ESLVal ps = $687;
          
          return lookupType.apply(n,_v616);
        }
        }
        }
        }
        }
        default: {ESLVal _v632 = _v77;
          
          return error(new ESLVal("TypeError",_v612,new ESLVal("unknown type of pattern: ").add(_v632)));
        }
      }
      }
    }
  });
  private static ESLVal patternType = new ESLVal(new Function(new ESLVal("patternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v582 = $args[0];
  ESLVal _v583 = $args[1];
  ESLVal _v584 = $args[2];
  ESLVal _v585 = $args[3];
  ESLVal _v586 = $args[4];
  ESLVal _v587 = $args[5];
  ESLVal _v588 = $args[6];
  ESLVal _v589 = $args[7];
  {ESLVal _v78 = _v583;
        
        switch(_v78.termName) {
        case "PAdd": {ESLVal $747 = _v78.termRef(0);
          ESLVal $746 = _v78.termRef(1);
          ESLVal $745 = _v78.termRef(2);
          
          {ESLVal _v610 = $747;
          
          {ESLVal p1 = $746;
          
          {ESLVal p2 = $745;
          
          return addPatternType.apply(_v610,p1,p2,_v584,_v585,_v586,_v587,_v588,_v589);
        }
        }
        }
        }
      case "PApplyType": {ESLVal $744 = _v78.termRef(0);
          ESLVal $743 = _v78.termRef(1);
          ESLVal $742 = _v78.termRef(2);
          
          {ESLVal _v608 = $744;
          
          {ESLVal _v609 = $743;
          
          {ESLVal args = $742;
          
          return applyTypePatternType.apply(_v608,_v609,substTypesEnv.apply(_v588,args),_v584,_v585,_v586,_v587,_v588,_v589);
        }
        }
        }
        }
      case "PBool": {ESLVal $741 = _v78.termRef(0);
          ESLVal $740 = _v78.termRef(1);
          
          {ESLVal _v607 = $741;
          
          {ESLVal b = $740;
          
          if(isBoolType.apply(_v584).boolVal)
          return _v589.apply(new ESLVal("BoolType",_v607),_v586);
          else
            return error(new ESLVal("TypeError",_v607,new ESLVal("type mismatch: Bool and ").add(ppType.apply(_v584,_v588))));
        }
        }
        }
      case "PBagCons": {ESLVal $739 = _v78.termRef(0);
          ESLVal $738 = _v78.termRef(1);
          ESLVal $737 = _v78.termRef(2);
          
          {ESLVal _v604 = $739;
          
          {ESLVal hd = $738;
          
          {ESLVal tl = $737;
          
          return bagConsPatternType.apply(_v604,hd,tl,_v584,_v585,_v586,_v587,_v588,new ESLVal(new Function(new ESLVal("fun214"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v605 = $args[0];
          ESLVal _v606 = $args[1];
          return _v589.apply(new ESLVal("ListType",_v604,_v605),_v606);
            }
          }));
        }
        }
        }
        }
      case "PSetCons": {ESLVal $736 = _v78.termRef(0);
          ESLVal $735 = _v78.termRef(1);
          ESLVal $734 = _v78.termRef(2);
          
          {ESLVal _v601 = $736;
          
          {ESLVal hd = $735;
          
          {ESLVal tl = $734;
          
          return setConsPatternType.apply(_v601,hd,tl,_v584,_v585,_v586,_v587,_v588,new ESLVal(new Function(new ESLVal("fun215"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v602 = $args[0];
          ESLVal _v603 = $args[1];
          return _v589.apply(new ESLVal("ListType",_v601,_v602),_v603);
            }
          }));
        }
        }
        }
        }
      case "PCons": {ESLVal $733 = _v78.termRef(0);
          ESLVal $732 = _v78.termRef(1);
          ESLVal $731 = _v78.termRef(2);
          
          {ESLVal _v598 = $733;
          
          {ESLVal hd = $732;
          
          {ESLVal tl = $731;
          
          return consPatternType.apply(_v598,hd,tl,_v584,_v585,_v586,_v587,_v588,new ESLVal(new Function(new ESLVal("fun216"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v599 = $args[0];
          ESLVal _v600 = $args[1];
          return _v589.apply(new ESLVal("ListType",_v598,_v599),_v600);
            }
          }));
        }
        }
        }
        }
      case "PNil": {ESLVal $730 = _v78.termRef(0);
          
          {ESLVal _v597 = $730;
          
          return nilType.apply(_v597,_v584,_v585,_v586,_v587,_v588,_v589);
        }
        }
      case "PNull": {ESLVal $729 = _v78.termRef(0);
          
          {ESLVal _v596 = $729;
          
          return _v589.apply(_v584,_v586);
        }
        }
      case "PEmptyBag": {ESLVal $728 = _v78.termRef(0);
          
          {ESLVal _v595 = $728;
          
          return emptyBagType.apply(_v595,_v584,_v585,_v586,_v587,_v588,_v589);
        }
        }
      case "PEmptySet": {ESLVal $727 = _v78.termRef(0);
          
          {ESLVal _v594 = $727;
          
          return emptySetType.apply(_v594,_v584,_v585,_v586,_v587,_v588,_v589);
        }
        }
      case "PInt": {ESLVal $726 = _v78.termRef(0);
          ESLVal $725 = _v78.termRef(1);
          
          {ESLVal _v593 = $726;
          
          {ESLVal n = $725;
          
          if(isIntType.apply(_v584).boolVal)
          return _v589.apply(new ESLVal("IntType",_v593),_v586);
          else
            return error(new ESLVal("TypeError",_v593,new ESLVal("type mismatch: Int and ").add(ppType.apply(_v584,_v588))));
        }
        }
        }
      case "PVar": {ESLVal $724 = _v78.termRef(0);
          ESLVal $723 = _v78.termRef(1);
          ESLVal $722 = _v78.termRef(2);
          
          {ESLVal _v592 = $724;
          
          {ESLVal n = $723;
          
          {ESLVal pt = $722;
          
          return _v589.apply(_v584,ESLVal.list(new ESLVal("Map",n,_v584)).add(_v586));
        }
        }
        }
        }
      case "PStr": {ESLVal $721 = _v78.termRef(0);
          ESLVal $720 = _v78.termRef(1);
          
          {ESLVal _v591 = $721;
          
          {ESLVal s = $720;
          
          if(isStrType.apply(_v584).boolVal)
          return _v589.apply(new ESLVal("StrType",_v591),_v586);
          else
            return error(new ESLVal("TypeError",_v591,new ESLVal("type mismatch: Str and ").add(ppType.apply(_v584,_v588))));
        }
        }
        }
      case "PTerm": {ESLVal $719 = _v78.termRef(0);
          ESLVal $718 = _v78.termRef(1);
          ESLVal $717 = _v78.termRef(2);
          ESLVal $716 = _v78.termRef(3);
          
          {ESLVal _v590 = $719;
          
          {ESLVal n = $718;
          
          {ESLVal ts = $717;
          
          {ESLVal ps = $716;
          
          return termPatternType.apply(_v590,n,substTypesEnv.apply(_v588,ts),ps,_v584,_v585,_v586,_v587,_v588,_v589);
        }
        }
        }
        }
        }
        default: {ESLVal _v611 = _v78;
          
          return error(new ESLVal("TypeError",_v582,new ESLVal("unknown type of pattern: ").add(_v611)));
        }
      }
      }
    }
  });
  private static ESLVal addPatternType = new ESLVal(new Function(new ESLVal("addPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v544 = $args[0];
  ESLVal _v545 = $args[1];
  ESLVal _v546 = $args[2];
  ESLVal _v547 = $args[3];
  ESLVal _v548 = $args[4];
  ESLVal _v549 = $args[5];
  ESLVal _v550 = $args[6];
  ESLVal _v551 = $args[7];
  ESLVal _v552 = $args[8];
  return patternType.apply(_v544,_v545,_v547,_v548,_v549,_v550,_v551,new ESLVal(new Function(new ESLVal("fun217"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v553 = $args[0];
        ESLVal _v554 = $args[1];
        return patternType.apply(_v544,_v546,_v547,_v548,_v554,_v550,_v551,new ESLVal(new Function(new ESLVal("fun218"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal _v555 = $args[0];
              ESLVal _v556 = $args[1];
              {ESLVal _v79 = _v547;
                    
                    switch(_v79.termName) {
                    case "ListType": {ESLVal $750 = _v79.termRef(0);
                      ESLVal $749 = _v79.termRef(1);
                      
                      {ESLVal tl = $750;
                      
                      {ESLVal t = $749;
                      
                      {ESLVal _v80 = _v545;
                      ESLVal _v81 = _v546;
                      
                      switch(_v80.termName) {
                      case "PCons": {ESLVal $783 = _v80.termRef(0);
                        ESLVal $782 = _v80.termRef(1);
                        ESLVal $781 = _v80.termRef(2);
                        
                        switch($781.termName) {
                        case "PNil": {ESLVal $784 = $781.termRef(0);
                          
                          switch(_v81.termName) {
                          case "PVar": {ESLVal $787 = _v81.termRef(0);
                            ESLVal $786 = _v81.termRef(1);
                            ESLVal $785 = _v81.termRef(2);
                            
                            {ESLVal l1 = $783;
                            
                            {ESLVal p = $782;
                            
                            {ESLVal l3 = $784;
                            
                            {ESLVal l4 = $787;
                            
                            {ESLVal n2 = $786;
                            
                            {ESLVal t2 = $785;
                            
                            return _v552.apply(_v547,_v556);
                          }
                          }
                          }
                          }
                          }
                          }
                          }
                          default: {ESLVal _v576 = _v80;
                            
                            {ESLVal _v577 = _v81;
                            
                            return error(new ESLVal("TypeError",_v544,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                          }
                          }
                        }
                        }
                        default: {ESLVal _v578 = _v80;
                          
                          {ESLVal _v579 = _v81;
                          
                          return error(new ESLVal("TypeError",_v544,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                        }
                        }
                      }
                      }
                    case "PVar": {ESLVal $766 = _v80.termRef(0);
                        ESLVal $765 = _v80.termRef(1);
                        ESLVal $764 = _v80.termRef(2);
                        
                        switch(_v81.termName) {
                        case "PCons": {ESLVal $779 = _v81.termRef(0);
                          ESLVal $778 = _v81.termRef(1);
                          ESLVal $777 = _v81.termRef(2);
                          
                          switch($777.termName) {
                          case "PNil": {ESLVal $780 = $777.termRef(0);
                            
                            {ESLVal l1 = $766;
                            
                            {ESLVal n = $765;
                            
                            {ESLVal _v571 = $764;
                            
                            {ESLVal l2 = $779;
                            
                            {ESLVal p = $778;
                            
                            {ESLVal l3 = $780;
                            
                            return _v552.apply(_v547,_v556);
                          }
                          }
                          }
                          }
                          }
                          }
                          }
                          default: {ESLVal _v572 = _v80;
                            
                            {ESLVal _v573 = _v81;
                            
                            return error(new ESLVal("TypeError",_v544,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                          }
                          }
                        }
                        }
                      case "PAdd": {ESLVal $769 = _v81.termRef(0);
                          ESLVal $768 = _v81.termRef(1);
                          ESLVal $767 = _v81.termRef(2);
                          
                          switch($768.termName) {
                          case "PCons": {ESLVal $772 = $768.termRef(0);
                            ESLVal $771 = $768.termRef(1);
                            ESLVal $770 = $768.termRef(2);
                            
                            switch($770.termName) {
                            case "PNil": {ESLVal $773 = $770.termRef(0);
                              
                              switch($767.termName) {
                              case "PVar": {ESLVal $776 = $767.termRef(0);
                                ESLVal $775 = $767.termRef(1);
                                ESLVal $774 = $767.termRef(2);
                                
                                {ESLVal l1 = $766;
                                
                                {ESLVal n1 = $765;
                                
                                {ESLVal t1 = $764;
                                
                                {ESLVal l2 = $769;
                                
                                {ESLVal l3 = $772;
                                
                                {ESLVal p = $771;
                                
                                {ESLVal l5 = $773;
                                
                                {ESLVal l6 = $776;
                                
                                {ESLVal n3 = $775;
                                
                                {ESLVal t3 = $774;
                                
                                return _v552.apply(_v547,_v556);
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              default: {ESLVal _v565 = _v80;
                                
                                {ESLVal _v566 = _v81;
                                
                                return error(new ESLVal("TypeError",_v544,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                              }
                              }
                            }
                            }
                            default: {ESLVal _v567 = _v80;
                              
                              {ESLVal _v568 = _v81;
                              
                              return error(new ESLVal("TypeError",_v544,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                            }
                            }
                          }
                          }
                          default: {ESLVal _v569 = _v80;
                            
                            {ESLVal _v570 = _v81;
                            
                            return error(new ESLVal("TypeError",_v544,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                          }
                          }
                        }
                        }
                        default: {ESLVal _v574 = _v80;
                          
                          {ESLVal _v575 = _v81;
                          
                          return error(new ESLVal("TypeError",_v544,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                        }
                        }
                      }
                      }
                    case "PAdd": {ESLVal $753 = _v80.termRef(0);
                        ESLVal $752 = _v80.termRef(1);
                        ESLVal $751 = _v80.termRef(2);
                        
                        switch($752.termName) {
                        case "PVar": {ESLVal $756 = $752.termRef(0);
                          ESLVal $755 = $752.termRef(1);
                          ESLVal $754 = $752.termRef(2);
                          
                          switch($751.termName) {
                          case "PCons": {ESLVal $759 = $751.termRef(0);
                            ESLVal $758 = $751.termRef(1);
                            ESLVal $757 = $751.termRef(2);
                            
                            switch($757.termName) {
                            case "PNil": {ESLVal $760 = $757.termRef(0);
                              
                              switch(_v81.termName) {
                              case "PVar": {ESLVal $763 = _v81.termRef(0);
                                ESLVal $762 = _v81.termRef(1);
                                ESLVal $761 = _v81.termRef(2);
                                
                                {ESLVal l1 = $753;
                                
                                {ESLVal l2 = $756;
                                
                                {ESLVal n1 = $755;
                                
                                {ESLVal t1 = $754;
                                
                                {ESLVal l3 = $759;
                                
                                {ESLVal p = $758;
                                
                                {ESLVal l5 = $760;
                                
                                {ESLVal l6 = $763;
                                
                                {ESLVal n3 = $762;
                                
                                {ESLVal t3 = $761;
                                
                                return _v552.apply(_v547,_v556);
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              default: {ESLVal _v557 = _v80;
                                
                                {ESLVal _v558 = _v81;
                                
                                return error(new ESLVal("TypeError",_v544,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                              }
                              }
                            }
                            }
                            default: {ESLVal _v559 = _v80;
                              
                              {ESLVal _v560 = _v81;
                              
                              return error(new ESLVal("TypeError",_v544,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                            }
                            }
                          }
                          }
                          default: {ESLVal _v561 = _v80;
                            
                            {ESLVal _v562 = _v81;
                            
                            return error(new ESLVal("TypeError",_v544,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                          }
                          }
                        }
                        }
                        default: {ESLVal _v563 = _v80;
                          
                          {ESLVal _v564 = _v81;
                          
                          return error(new ESLVal("TypeError",_v544,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                        }
                        }
                      }
                      }
                      default: {ESLVal _v580 = _v80;
                        
                        {ESLVal _v581 = _v81;
                        
                        return error(new ESLVal("TypeError",_v544,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                      }
                      }
                    }
                    }
                    }
                    }
                    }
                  case "TypeClosure": {ESLVal $748 = _v79.termRef(0);
                      
                      {ESLVal g = $748;
                      
                      return addPatternType.apply(_v544,_v545,_v546,g.apply(),_v548,_v556,_v550,_v551,_v552);
                    }
                    }
                    default: {ESLVal t = _v79;
                      
                      return error(new ESLVal("TypeError",_v544,new ESLVal("+ expects lists: ").add(ppType.apply(_v547,_v551))));
                    }
                  }
                  }
                }
              }));
          }
        }));
    }
  });
  private static ESLVal applyTypePatternType = new ESLVal(new Function(new ESLVal("applyTypePatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v531 = $args[0];
  ESLVal _v532 = $args[1];
  ESLVal _v533 = $args[2];
  ESLVal _v534 = $args[3];
  ESLVal _v535 = $args[4];
  ESLVal _v536 = $args[5];
  ESLVal _v537 = $args[6];
  ESLVal _v538 = $args[7];
  ESLVal _v539 = $args[8];
  return patternType.apply(_v531,_v532,_v534,_v535,_v536,_v537,_v538,new ESLVal(new Function(new ESLVal("fun219"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v540 = $args[0];
        ESLVal _v541 = $args[1];
        {ESLVal _v82 = typeNF.apply(_v540,_v538);
              
              switch(_v82.termName) {
              case "TypeFun": {ESLVal $793 = _v82.termRef(0);
                ESLVal $792 = _v82.termRef(1);
                ESLVal $791 = _v82.termRef(2);
                
                {ESLVal fl = $793;
                
                {ESLVal ns = $792;
                
                {ESLVal t = $791;
                
                if(length.apply(_v533).eql(length.apply(ns)).boolVal)
                {ESLVal _v543 = substTypeEnv.apply(zipTypeEnv.apply(ns,_v533).add(_v538),t);
                  
                  if(typeEqual.apply(_v543,_v534).boolVal)
                  return _v539.apply(_v543,_v541);
                  else
                    return error(new ESLVal("TypeError",_v531,new ESLVal("value type ").add(ppType.apply(_v534,_v538).add(new ESLVal(" does not match pattern type ").add(ppType.apply(_v543,_v538).add(new ESLVal(" ").add(ppTypeEnv.apply(_v538))))))));
                }
                else
                  return error(new ESLVal("TypeError",_v531,new ESLVal("expecting ").add(length.apply(ns).add(new ESLVal(" args, but suplied with ").add(length.apply(_v533))))));
              }
              }
              }
              }
            case "ForallType": {ESLVal $790 = _v82.termRef(0);
                ESLVal $789 = _v82.termRef(1);
                ESLVal $788 = _v82.termRef(2);
                
                {ESLVal fl = $790;
                
                {ESLVal ns = $789;
                
                {ESLVal t = $788;
                
                if(length.apply(_v533).eql(length.apply(ns)).boolVal)
                {ESLVal _v542 = substTypeEnv.apply(zipTypeEnv.apply(ns,_v533).add(_v538),t);
                  
                  if(typeEqual.apply(_v542,_v534).boolVal)
                  return _v539.apply(_v542,_v541);
                  else
                    return error(new ESLVal("TypeError",_v531,new ESLVal("value type ").add(ppType.apply(_v534,_v538).add(new ESLVal(" does not match pattern type ").add(ppType.apply(_v542,_v538).add(new ESLVal(" ").add(ppTypeEnv.apply(_v538))))))));
                }
                else
                  return error(new ESLVal("TypeError",_v531,new ESLVal("expecting ").add(length.apply(ns).add(new ESLVal(" args, but suplied with ").add(length.apply(_v533))))));
              }
              }
              }
              }
              default: {ESLVal t = _v82;
                
                return _v539.apply(t,_v541);
              }
            }
            }
          }
        }));
    }
  });
  private static ESLVal termPatternType = new ESLVal(new Function(new ESLVal("termPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v514 = $args[0];
  ESLVal _v515 = $args[1];
  ESLVal _v516 = $args[2];
  ESLVal _v517 = $args[3];
  ESLVal _v518 = $args[4];
  ESLVal _v519 = $args[5];
  ESLVal _v520 = $args[6];
  ESLVal _v521 = $args[7];
  ESLVal _v522 = $args[8];
  ESLVal _v523 = $args[9];
  {ESLVal _v524 = getTermPatternType.apply(_v514,_v515,_v516,_v519,_v520,_v521,_v522);
        
        if(typeEqual.apply(_v524,_v518).boolVal)
        {ESLVal _v83 = typeNF.apply(_v518,_v522);
          
          switch(_v83.termName) {
          case "UnionType": {ESLVal $795 = _v83.termRef(0);
            ESLVal $794 = _v83.termRef(1);
            
            {ESLVal ul = $795;
            
            {ESLVal cs = $794;
            
            { LetRec letrec = new LetRec() {
            ESLVal getCnstrArgs = new ESLVal(new Function(new ESLVal("getCnstrArgs"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal _v525 = $args[0];
              {ESLVal _v84 = _v525;
                    
                    if(_v84.isCons())
                    {ESLVal $796 = _v84.head();
                      ESLVal $797 = _v84.tail();
                      
                      switch($796.termName) {
                      case "TermType": {ESLVal $800 = $796.termRef(0);
                        ESLVal $799 = $796.termRef(1);
                        ESLVal $798 = $796.termRef(2);
                        
                        {ESLVal tl = $800;
                        
                        {ESLVal m = $799;
                        
                        {ESLVal args = $798;
                        
                        {ESLVal _v526 = $797;
                        
                        if(m.eql(_v515).boolVal)
                        return args;
                        else
                          {ESLVal t = $796;
                            
                            {ESLVal _v527 = $797;
                            
                            return getCnstrArgs.apply(_v527);
                          }
                          }
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal t = $796;
                        
                        {ESLVal _v528 = $797;
                        
                        return getCnstrArgs.apply(_v528);
                      }
                      }
                    }
                    }
                  else if(_v84.isNil())
                    return error(new ESLVal("TypeError",_v514,new ESLVal("cannot find constructor for ").add(_v515)));
                  else return error(new ESLVal("case error at Pos(52520,52779)").add(ESLVal.list(_v84)));
                  }
                }
              });
            
            public ESLVal get(String name) {
              switch(name) {
                case "getCnstrArgs": return getCnstrArgs;
                
                default: throw new Error("cannot find letrec binding");
              }
              }
            };
          ESLVal getCnstrArgs = letrec.get("getCnstrArgs");
          
            {ESLVal argTypes = getCnstrArgs.apply(cs);
            
            if(length.apply(_v517).eql(length.apply(argTypes)).boolVal)
            return patternTypes.apply(_v514,_v517,argTypes,_v519,_v520,_v521,_v522,new ESLVal(new Function(new ESLVal("fun220"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal _v529 = $args[0];
              ESLVal _v530 = $args[1];
              return _v523.apply(typeNF.apply(_v518,_v522),_v530);
                }
              }));
            else
              return error(new ESLVal("TypeError",_v514,new ESLVal("arity mismatch.")));
          }}
          
          }
          }
          }
          default: {ESLVal t = _v83;
            
            return error(new ESLVal("TypeError",_v514,new ESLVal("expecting a data type: ").add(_v518)));
          }
        }
        }
        else
          return error(new ESLVal("TypeError",_v514,new ESLVal("term pattern type ").add(ppType.apply(_v524,_v522).add(new ESLVal(" does not match supplied value type ").add(ppType.apply(_v518,_v522))))));
      }
    }
  });
  private static ESLVal typeNF = new ESLVal(new Function(new ESLVal("typeNF"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v507 = $args[0];
  ESLVal _v508 = $args[1];
  {ESLVal _v85 = substTypeEnv.apply(_v508,_v507);
        
        switch(_v85.termName) {
        case "ApplyTypeFun": {ESLVal $811 = _v85.termRef(0);
          ESLVal $810 = _v85.termRef(1);
          ESLVal $809 = _v85.termRef(2);
          
          {ESLVal l = $811;
          
          {ESLVal op = $810;
          
          {ESLVal args = $809;
          
          {ESLVal _v87 = typeNF.apply(op,_v508);
          
          switch(_v87.termName) {
          case "TypeFun": {ESLVal $817 = _v87.termRef(0);
            ESLVal $816 = _v87.termRef(1);
            ESLVal $815 = _v87.termRef(2);
            
            {ESLVal _v510 = $817;
            
            {ESLVal ns = $816;
            
            {ESLVal _v511 = $815;
            
            if(length.apply(args).eql(length.apply(ns)).boolVal)
            return typeNF.apply(substTypeEnv.apply(zipTypeEnv.apply(ns,args),_v511),_v508);
            else
              return error(new ESLVal("TypeError",_v510,new ESLVal("function arity error")));
          }
          }
          }
          }
          default: {ESLVal _v512 = _v87;
            
            return error(new ESLVal("TypeError",l,new ESLVal("expecting a type function: ").add(ppType.apply(typeNF.apply(op,_v508),_v508))));
          }
        }
        }
        }
        }
        }
        }
      case "TypeClosure": {ESLVal $808 = _v85.termRef(0);
          
          {ESLVal f = $808;
          
          return typeNF.apply(f.apply(),_v508);
        }
        }
      case "RecType": {ESLVal $807 = _v85.termRef(0);
          ESLVal $806 = _v85.termRef(1);
          ESLVal $805 = _v85.termRef(2);
          
          {ESLVal l = $807;
          
          {ESLVal n = $806;
          
          {ESLVal _v509 = $805;
          
          return typeNF.apply(substType.apply(new ESLVal("RecType",l,n,_v509),n,_v509),_v508);
        }
        }
        }
        }
      case "ExtendedAct": {ESLVal $804 = _v85.termRef(0);
          ESLVal $803 = _v85.termRef(1);
          ESLVal $802 = _v85.termRef(2);
          ESLVal $801 = _v85.termRef(3);
          
          {ESLVal l1 = $804;
          
          {ESLVal parent = $803;
          
          {ESLVal decs1 = $802;
          
          {ESLVal ms1 = $801;
          
          {ESLVal _v86 = typeNF.apply(parent,_v508);
          
          switch(_v86.termName) {
          case "ActType": {ESLVal $814 = _v86.termRef(0);
            ESLVal $813 = _v86.termRef(1);
            ESLVal $812 = _v86.termRef(2);
            
            {ESLVal l2 = $814;
            
            {ESLVal decs2 = $813;
            
            {ESLVal ms2 = $812;
            
            return new ESLVal("ActType",l1,decs2.add(decs1),ms2.add(ms1));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(54096,54231)").add(ESLVal.list(_v86)));
        }
        }
        }
        }
        }
        }
        }
        default: {ESLVal _v513 = _v85;
          
          return _v513;
        }
      }
      }
    }
  });
  private static ESLVal getTermPatternType = new ESLVal(new Function(new ESLVal("getTermPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v500 = $args[0];
  ESLVal _v501 = $args[1];
  ESLVal _v502 = $args[2];
  ESLVal _v503 = $args[3];
  ESLVal _v504 = $args[4];
  ESLVal _v505 = $args[5];
  ESLVal _v506 = $args[6];
  {ESLVal t = lookupType.apply(_v501,_v505);
        
        if(t.eql($null).boolVal)
        return error(new ESLVal("TypeError",_v500,new ESLVal("unknown constructor ").add(_v501)));
        else
          if(length.apply(_v502).gre($zero).boolVal)
            return getGenericTermPatternType.apply(_v500,t,_v502,_v503,_v504,_v505,_v506);
            else
              return t;
      }
    }
  });
  private static ESLVal getGenericTermPatternType = new ESLVal(new Function(new ESLVal("getGenericTermPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v491 = $args[0];
  ESLVal _v492 = $args[1];
  ESLVal _v493 = $args[2];
  ESLVal _v494 = $args[3];
  ESLVal _v495 = $args[4];
  ESLVal _v496 = $args[5];
  ESLVal _v497 = $args[6];
  {ESLVal _v88 = _v492;
        
        switch(_v88.termName) {
        case "RecType": {ESLVal $823 = _v88.termRef(0);
          ESLVal $822 = _v88.termRef(1);
          ESLVal $821 = _v88.termRef(2);
          
          {ESLVal rl = $823;
          
          {ESLVal rn = $822;
          
          {ESLVal rt = $821;
          
          return getGenericTermPatternType.apply(_v491,substType.apply(new ESLVal("RecType",rl,rn,rt),rn,rt),_v493,_v494,_v495,_v496,_v497);
        }
        }
        }
        }
      case "TypeFun": {ESLVal $820 = _v88.termRef(0);
          ESLVal $819 = _v88.termRef(1);
          ESLVal $818 = _v88.termRef(2);
          
          {ESLVal al = $820;
          
          {ESLVal ns = $819;
          
          {ESLVal _v498 = $818;
          
          if(length.apply(ns).eql(length.apply(_v493)).boolVal)
          {ESLVal e = zipTypeEnv.apply(ns,_v493);
            
            return substTypeEnv.apply(e.add(_v497),_v498);
          }
          else
            return error(new ESLVal("TypeError",_v491,new ESLVal("generic constructor mismatch")));
        }
        }
        }
        }
        default: {ESLVal _v499 = _v88;
          
          return error(new ESLVal("TypeError",_v491,new ESLVal("expecting a generic type: ").add(ppType.apply(_v499,_v497))));
        }
      }
      }
    }
  });
  private static ESLVal nilType = new ESLVal(new Function(new ESLVal("nilType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v483 = $args[0];
  ESLVal _v484 = $args[1];
  ESLVal _v485 = $args[2];
  ESLVal _v486 = $args[3];
  ESLVal _v487 = $args[4];
  ESLVal _v488 = $args[5];
  ESLVal _v489 = $args[6];
  {ESLVal _v89 = typeNF.apply(_v484,_v488);
        
        switch(_v89.termName) {
        case "ListType": {ESLVal $826 = _v89.termRef(0);
          ESLVal $825 = _v89.termRef(1);
          
          {ESLVal ltl = $826;
          
          {ESLVal et = $825;
          
          return _v489.apply(new ESLVal("ForallType",_v483,ESLVal.list(new ESLVal("T")),new ESLVal("ListType",_v483,new ESLVal("VarType",_v483,new ESLVal("T")))),_v486);
        }
        }
        }
      case "TypeClosure": {ESLVal $824 = _v89.termRef(0);
          
          {ESLVal g = $824;
          
          return nilType.apply(_v483,g.apply(),_v485,_v486,_v487,_v488,_v489);
        }
        }
        default: {ESLVal _v490 = _v89;
          
          return error(new ESLVal("TypeError",_v483,new ESLVal("expecting a list type: ").add(ppType.apply(_v490,_v488))));
        }
      }
      }
    }
  });
  private static ESLVal emptyBagType = new ESLVal(new Function(new ESLVal("emptyBagType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v475 = $args[0];
  ESLVal _v476 = $args[1];
  ESLVal _v477 = $args[2];
  ESLVal _v478 = $args[3];
  ESLVal _v479 = $args[4];
  ESLVal _v480 = $args[5];
  ESLVal _v481 = $args[6];
  {ESLVal _v90 = _v476;
        
        switch(_v90.termName) {
        case "BagType": {ESLVal $828 = _v90.termRef(0);
          ESLVal $827 = _v90.termRef(1);
          
          {ESLVal ltl = $828;
          
          {ESLVal et = $827;
          
          return _v481.apply(new ESLVal("ForallType",_v475,ESLVal.list(new ESLVal("T")),new ESLVal("BagType",_v475,new ESLVal("VarType",_v475,new ESLVal("T")))),_v478);
        }
        }
        }
        default: {ESLVal _v482 = _v90;
          
          return error(new ESLVal("TypeError",_v475,new ESLVal("expecting a bag type: ").add(ppType.apply(_v482,_v480))));
        }
      }
      }
    }
  });
  private static ESLVal emptySetType = new ESLVal(new Function(new ESLVal("emptySetType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v467 = $args[0];
  ESLVal _v468 = $args[1];
  ESLVal _v469 = $args[2];
  ESLVal _v470 = $args[3];
  ESLVal _v471 = $args[4];
  ESLVal _v472 = $args[5];
  ESLVal _v473 = $args[6];
  {ESLVal _v91 = _v468;
        
        switch(_v91.termName) {
        case "SetType": {ESLVal $830 = _v91.termRef(0);
          ESLVal $829 = _v91.termRef(1);
          
          {ESLVal ltl = $830;
          
          {ESLVal et = $829;
          
          return _v473.apply(new ESLVal("ForallType",_v467,ESLVal.list(new ESLVal("T")),new ESLVal("SetType",_v467,new ESLVal("VarType",_v467,new ESLVal("T")))),_v470);
        }
        }
        }
        default: {ESLVal _v474 = _v91;
          
          return error(new ESLVal("TypeError",_v467,new ESLVal("expecting a set type: ").add(ppType.apply(_v474,_v472))));
        }
      }
      }
    }
  });
  private static ESLVal consPatternType = new ESLVal(new Function(new ESLVal("consPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v453 = $args[0];
  ESLVal _v454 = $args[1];
  ESLVal _v455 = $args[2];
  ESLVal _v456 = $args[3];
  ESLVal _v457 = $args[4];
  ESLVal _v458 = $args[5];
  ESLVal _v459 = $args[6];
  ESLVal _v460 = $args[7];
  ESLVal _v461 = $args[8];
  {ESLVal _v92 = typeNF.apply(_v456,_v460);
        
        switch(_v92.termName) {
        case "ListType": {ESLVal $833 = _v92.termRef(0);
          ESLVal $832 = _v92.termRef(1);
          
          {ESLVal ltl = $833;
          
          {ESLVal et = $832;
          
          return patternType.apply(_v453,_v454,substTypeEnv.apply(_v460,et),_v457,_v458,_v459,_v460,new ESLVal(new Function(new ESLVal("fun221"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v462 = $args[0];
          ESLVal _v463 = $args[1];
          return patternType.apply(_v453,_v455,_v456,_v457,_v463,_v459,_v460,new ESLVal(new Function(new ESLVal("fun222"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal _v464 = $args[0];
                ESLVal _v465 = $args[1];
                return _v461.apply(_v462,_v465);
                  }
                }));
            }
          }));
        }
        }
        }
      case "TypeClosure": {ESLVal $831 = _v92.termRef(0);
          
          {ESLVal g = $831;
          
          return consPatternType.apply(_v453,_v454,_v455,g.apply(),_v457,_v458,_v459,_v460,_v461);
        }
        }
        default: {ESLVal _v466 = _v92;
          
          return error(new ESLVal("TypeError",_v453,new ESLVal("expecting a list type: ").add(ppType.apply(_v466,_v460))));
        }
      }
      }
    }
  });
  private static ESLVal bagConsPatternType = new ESLVal(new Function(new ESLVal("bagConsPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v439 = $args[0];
  ESLVal _v440 = $args[1];
  ESLVal _v441 = $args[2];
  ESLVal _v442 = $args[3];
  ESLVal _v443 = $args[4];
  ESLVal _v444 = $args[5];
  ESLVal _v445 = $args[6];
  ESLVal _v446 = $args[7];
  ESLVal _v447 = $args[8];
  {ESLVal _v93 = _v442;
        
        switch(_v93.termName) {
        case "BagType": {ESLVal $835 = _v93.termRef(0);
          ESLVal $834 = _v93.termRef(1);
          
          {ESLVal ltl = $835;
          
          {ESLVal et = $834;
          
          return patternType.apply(_v439,_v440,substTypeEnv.apply(_v446,et),_v443,_v444,_v445,_v446,new ESLVal(new Function(new ESLVal("fun223"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v448 = $args[0];
          ESLVal _v449 = $args[1];
          return patternType.apply(_v439,_v441,_v442,_v443,_v449,_v445,_v446,new ESLVal(new Function(new ESLVal("fun224"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal _v450 = $args[0];
                ESLVal _v451 = $args[1];
                return _v447.apply(_v448,_v451);
                  }
                }));
            }
          }));
        }
        }
        }
        default: {ESLVal _v452 = _v93;
          
          return error(new ESLVal("TypeError",_v439,new ESLVal("expecting a bag type: ").add(ppType.apply(_v452,_v446))));
        }
      }
      }
    }
  });
  private static ESLVal setConsPatternType = new ESLVal(new Function(new ESLVal("setConsPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v425 = $args[0];
  ESLVal _v426 = $args[1];
  ESLVal _v427 = $args[2];
  ESLVal _v428 = $args[3];
  ESLVal _v429 = $args[4];
  ESLVal _v430 = $args[5];
  ESLVal _v431 = $args[6];
  ESLVal _v432 = $args[7];
  ESLVal _v433 = $args[8];
  {ESLVal _v94 = _v428;
        
        switch(_v94.termName) {
        case "SetType": {ESLVal $837 = _v94.termRef(0);
          ESLVal $836 = _v94.termRef(1);
          
          {ESLVal ltl = $837;
          
          {ESLVal et = $836;
          
          return patternType.apply(_v425,_v426,substTypeEnv.apply(_v432,et),_v429,_v430,_v431,_v432,new ESLVal(new Function(new ESLVal("fun225"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v434 = $args[0];
          ESLVal _v435 = $args[1];
          return patternType.apply(_v425,_v427,_v428,_v429,_v435,_v431,_v432,new ESLVal(new Function(new ESLVal("fun226"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal _v436 = $args[0];
                ESLVal _v437 = $args[1];
                return _v433.apply(_v434,_v437);
                  }
                }));
            }
          }));
        }
        }
        }
        default: {ESLVal _v438 = _v94;
          
          return error(new ESLVal("TypeError",_v425,new ESLVal("expecting a set type: ").add(ppType.apply(_v438,_v432))));
        }
      }
      }
    }
  });
  private static ESLVal binExpType = new ESLVal(new Function(new ESLVal("binExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v416 = $args[0];
  ESLVal _v417 = $args[1];
  ESLVal _v418 = $args[2];
  ESLVal _v419 = $args[3];
  ESLVal _v420 = $args[4];
  ESLVal _v421 = $args[5];
  ESLVal _v422 = $args[6];
  ESLVal _v423 = $args[7];
  {ESLVal _v95 = _v418;
        
        switch(_v95.strVal) {
        case "+": return plusExpType.apply(_v416,_v417,_v419,_v420,_v421,_v422,_v423);
      case "-": return subExpType.apply(_v416,_v417,_v419,_v420,_v421,_v422,_v423);
      case "*": return mulExpType.apply(_v416,_v417,_v419,_v420,_v421,_v422,_v423);
      case "/": return divExpType.apply(_v416,_v417,_v419,_v420,_v421,_v422,_v423);
      case ":": return consExpType.apply(_v416,_v417,_v419,_v420,_v421,_v422,_v423);
      case "=": return eqlExpType.apply(_v416,_v417,_v419,_v420,_v421,_v422,_v423);
      case "<>": return neqlExpType.apply(_v416,_v417,_v419,_v420,_v421,_v422,_v423);
      case "and": return andExpType.apply(_v416,_v417,_v419,_v420,_v421,_v422,_v423);
      case "andalso": return andExpType.apply(_v416,_v417,_v419,_v420,_v421,_v422,_v423);
      case "or": return orExpType.apply(_v416,_v417,_v419,_v420,_v421,_v422,_v423);
      case "orelse": return orExpType.apply(_v416,_v417,_v419,_v420,_v421,_v422,_v423);
      case ">": return compareExpType.apply(_v416,_v417,new ESLVal(">"),_v419,_v420,_v421,_v422,_v423);
      case ">=": return compareExpType.apply(_v416,_v417,new ESLVal(">="),_v419,_v420,_v421,_v422,_v423);
      case "<": return compareExpType.apply(_v416,_v417,new ESLVal("<"),_v419,_v420,_v421,_v422,_v423);
      case "<=": return compareExpType.apply(_v416,_v417,new ESLVal("<="),_v419,_v420,_v421,_v422,_v423);
      case "..": return dotDotExpType.apply(_v416,_v417,_v419,_v420,_v421,_v422,_v423);
      case "%": return percentExpType.apply(_v416,_v417,_v419,_v420,_v421,_v422,_v423);
      case "@": return atExpType.apply(_v416,_v417,_v419,_v420,_v421,_v422,_v423);
        default: {ESLVal _v424 = _v95;
          
          return error(new ESLVal("TypeError",_v416,new ESLVal("unknown operator: ").add(_v424)));
        }
      }
      }
    }
  });
  private static ESLVal andExpType = new ESLVal(new Function(new ESLVal("andExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v409 = $args[0];
  ESLVal _v410 = $args[1];
  ESLVal _v411 = $args[2];
  ESLVal _v412 = $args[3];
  ESLVal _v413 = $args[4];
  ESLVal _v414 = $args[5];
  ESLVal _v415 = $args[6];
  {ESLVal t1 = expType.apply(_v410,_v412,_v413,_v414,_v415);
        ESLVal t2 = expType.apply(_v411,_v412,_v413,_v414,_v415);
        
        if(isBoolType.apply(t1).and(isBoolType.apply(t2)).boolVal)
        return t1;
        else
          return error(new ESLVal("TypeError",_v409,new ESLVal("and expects boolean arguments: ").add(ppType.apply(t1,_v415).add(new ESLVal(" ").add(ppType.apply(t2,_v415))))));
      }
    }
  });
  private static ESLVal atExpType = new ESLVal(new Function(new ESLVal("atExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v402 = $args[0];
  ESLVal _v403 = $args[1];
  ESLVal _v404 = $args[2];
  ESLVal _v405 = $args[3];
  ESLVal _v406 = $args[4];
  ESLVal _v407 = $args[5];
  ESLVal _v408 = $args[6];
  {ESLVal t1 = expType.apply(_v403,_v405,_v406,_v407,_v408);
        ESLVal t2 = expType.apply(_v404,_v405,_v406,_v407,_v408);
        
        if(typeEqual.apply(t1,t2).boolVal)
        return t1;
        else
          return error(new ESLVal("TypeError",_v402,new ESLVal("@ expects arguments to be same type: ").add(ppType.apply(t1,_v408).add(new ESLVal(" ").add(ppType.apply(t2,_v408))))));
      }
    }
  });
  private static ESLVal dotDotExpType = new ESLVal(new Function(new ESLVal("dotDotExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v395 = $args[0];
  ESLVal _v396 = $args[1];
  ESLVal _v397 = $args[2];
  ESLVal _v398 = $args[3];
  ESLVal _v399 = $args[4];
  ESLVal _v400 = $args[5];
  ESLVal _v401 = $args[6];
  {ESLVal t1 = expType.apply(_v396,_v398,_v399,_v400,_v401);
        ESLVal t2 = expType.apply(_v397,_v398,_v399,_v400,_v401);
        
        if(isIntType.apply(t1).and(isIntType.apply(t2)).boolVal)
        return new ESLVal("ListType",_v395,new ESLVal("IntType",_v395));
        else
          return error(new ESLVal("TypeError",_v395,new ESLVal(".. expects integer arguments: ").add(ppType.apply(t1,_v401).add(new ESLVal(" ").add(ppType.apply(t2,_v401))))));
      }
    }
  });
  private static ESLVal percentExpType = new ESLVal(new Function(new ESLVal("percentExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v388 = $args[0];
  ESLVal _v389 = $args[1];
  ESLVal _v390 = $args[2];
  ESLVal _v391 = $args[3];
  ESLVal _v392 = $args[4];
  ESLVal _v393 = $args[5];
  ESLVal _v394 = $args[6];
  {ESLVal t1 = expType.apply(_v389,_v391,_v392,_v393,_v394);
        ESLVal t2 = expType.apply(_v390,_v391,_v392,_v393,_v394);
        
        if(isIntType.apply(t1).and(isIntType.apply(t2)).boolVal)
        return new ESLVal("IntType",_v388);
        else
          return error(new ESLVal("TypeError",_v388,new ESLVal("% expects integer arguments: ").add(ppType.apply(t1,_v394).add(new ESLVal(" ").add(ppType.apply(t2,_v394))))));
      }
    }
  });
  private static ESLVal compareExpType = new ESLVal(new Function(new ESLVal("compareExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v380 = $args[0];
  ESLVal _v381 = $args[1];
  ESLVal _v382 = $args[2];
  ESLVal _v383 = $args[3];
  ESLVal _v384 = $args[4];
  ESLVal _v385 = $args[5];
  ESLVal _v386 = $args[6];
  ESLVal _v387 = $args[7];
  {ESLVal t1 = expType.apply(_v381,_v384,_v385,_v386,_v387);
        ESLVal t2 = expType.apply(_v383,_v384,_v385,_v386,_v387);
        
        if(isNumType.apply(t1).and(isNumType.apply(t2)).boolVal)
        return new ESLVal("BoolType",_v380);
        else
          return error(new ESLVal("TypeError",_v380,_v382.add(new ESLVal(" expects numeric arguments: ").add(ppType.apply(t1,_v387).add(new ESLVal(" ").add(ppType.apply(t2,_v387)))))));
      }
    }
  });
  private static ESLVal orExpType = new ESLVal(new Function(new ESLVal("orExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v373 = $args[0];
  ESLVal _v374 = $args[1];
  ESLVal _v375 = $args[2];
  ESLVal _v376 = $args[3];
  ESLVal _v377 = $args[4];
  ESLVal _v378 = $args[5];
  ESLVal _v379 = $args[6];
  {ESLVal t1 = expType.apply(_v374,_v376,_v377,_v378,_v379);
        ESLVal t2 = expType.apply(_v375,_v376,_v377,_v378,_v379);
        
        if(isBoolType.apply(t1).and(isBoolType.apply(t2)).boolVal)
        return t1;
        else
          return error(new ESLVal("TypeError",_v373,new ESLVal("or expects boolean arguments: ").add(ppType.apply(t1,_v379).add(new ESLVal(" ").add(ppType.apply(t2,_v379))))));
      }
    }
  });
  private static ESLVal eqlExpType = new ESLVal(new Function(new ESLVal("eqlExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v366 = $args[0];
  ESLVal _v367 = $args[1];
  ESLVal _v368 = $args[2];
  ESLVal _v369 = $args[3];
  ESLVal _v370 = $args[4];
  ESLVal _v371 = $args[5];
  ESLVal _v372 = $args[6];
  {ESLVal t1 = expType.apply(_v367,_v369,_v370,_v371,_v372);
        ESLVal t2 = expType.apply(_v368,_v369,_v370,_v371,_v372);
        
        if(typeEqual.apply(t1,t2).boolVal)
        return new ESLVal("BoolType",_v366);
        else
          return error(new ESLVal("TypeError",_v366,new ESLVal("= expects types to agree: ").add(ppType.apply(t1,_v372).add(new ESLVal(" <> ").add(ppType.apply(t2,_v372))))));
      }
    }
  });
  private static ESLVal neqlExpType = new ESLVal(new Function(new ESLVal("neqlExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v359 = $args[0];
  ESLVal _v360 = $args[1];
  ESLVal _v361 = $args[2];
  ESLVal _v362 = $args[3];
  ESLVal _v363 = $args[4];
  ESLVal _v364 = $args[5];
  ESLVal _v365 = $args[6];
  {ESLVal t1 = expType.apply(_v360,_v362,_v363,_v364,_v365);
        ESLVal t2 = expType.apply(_v361,_v362,_v363,_v364,_v365);
        
        if(typeEqual.apply(t1,t2).boolVal)
        return new ESLVal("BoolType",_v359);
        else
          return error(new ESLVal("TypeError",_v359,new ESLVal("<> expects types to agree: ").add(ppType.apply(t1,_v365).add(new ESLVal(" <> ").add(ppType.apply(t2,_v365))))));
      }
    }
  });
  private static ESLVal consExpType = new ESLVal(new Function(new ESLVal("consExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v351 = $args[0];
  ESLVal _v352 = $args[1];
  ESLVal _v353 = $args[2];
  ESLVal _v354 = $args[3];
  ESLVal _v355 = $args[4];
  ESLVal _v356 = $args[5];
  ESLVal _v357 = $args[6];
  {ESLVal t1 = typeNF.apply(expType.apply(_v352,_v354,_v355,_v356,_v357),_v357);
        ESLVal t2 = typeNF.apply(expType.apply(_v353,_v354,_v355,_v356,_v357),_v357);
        
        {ESLVal _v96 = t2;
        ESLVal _v97 = t1;
        
        switch(_v96.termName) {
        case "ListType": {ESLVal $839 = _v96.termRef(0);
          ESLVal $838 = _v96.termRef(1);
          
          {ESLVal _v358 = $839;
          
          {ESLVal elementType = $838;
          
          {ESLVal headType = _v97;
          
          if(subType.apply(headType,elementType).boolVal)
          return t2;
          else
            return error(new ESLVal("TypeError",_v358,new ESLVal(": expects head type ").add(ppType.apply(headType,_v357).add(new ESLVal(" and element type ").add(ppType.apply(elementType,_v357).add(new ESLVal(" to agree")))))));
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(63286,63567)").add(ESLVal.list(_v96,_v97)));
      }
      }
      }
    }
  });
  private static ESLVal divExpType = new ESLVal(new Function(new ESLVal("divExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v338 = $args[0];
  ESLVal _v339 = $args[1];
  ESLVal _v340 = $args[2];
  ESLVal _v341 = $args[3];
  ESLVal _v342 = $args[4];
  ESLVal _v343 = $args[5];
  ESLVal _v344 = $args[6];
  {ESLVal t1 = expType.apply(_v339,_v341,_v342,_v343,_v344);
        ESLVal t2 = expType.apply(_v340,_v341,_v342,_v343,_v344);
        
        {ESLVal _v98 = t1;
        ESLVal _v99 = t2;
        
        switch(_v98.termName) {
        case "IntType": {ESLVal $842 = _v98.termRef(0);
          
          switch(_v99.termName) {
          case "IntType": {ESLVal $843 = _v99.termRef(0);
            
            {ESLVal l1 = $842;
            
            {ESLVal l2 = $843;
            
            return t1;
          }
          }
          }
          default: {ESLVal _v347 = _v98;
            
            {ESLVal _v348 = _v99;
            
            return error(new ESLVal("TypeError",_v338,new ESLVal("incomptible types for /: ").add(ppType.apply(_v347,_v344).add(new ESLVal(" and ").add(ppType.apply(_v348,_v344))))));
          }
          }
        }
        }
      case "FloatType": {ESLVal $840 = _v98.termRef(0);
          
          switch(_v99.termName) {
          case "FloatType": {ESLVal $841 = _v99.termRef(0);
            
            {ESLVal l1 = $840;
            
            {ESLVal l2 = $841;
            
            return t1;
          }
          }
          }
          default: {ESLVal _v345 = _v98;
            
            {ESLVal _v346 = _v99;
            
            return error(new ESLVal("TypeError",_v338,new ESLVal("incomptible types for /: ").add(ppType.apply(_v345,_v344).add(new ESLVal(" and ").add(ppType.apply(_v346,_v344))))));
          }
          }
        }
        }
        default: {ESLVal _v349 = _v98;
          
          {ESLVal _v350 = _v99;
          
          return error(new ESLVal("TypeError",_v338,new ESLVal("incomptible types for /: ").add(ppType.apply(_v349,_v344).add(new ESLVal(" and ").add(ppType.apply(_v350,_v344))))));
        }
        }
      }
      }
      }
    }
  });
  private static ESLVal mulExpType = new ESLVal(new Function(new ESLVal("mulExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v325 = $args[0];
  ESLVal _v326 = $args[1];
  ESLVal _v327 = $args[2];
  ESLVal _v328 = $args[3];
  ESLVal _v329 = $args[4];
  ESLVal _v330 = $args[5];
  ESLVal _v331 = $args[6];
  {ESLVal t1 = expType.apply(_v326,_v328,_v329,_v330,_v331);
        ESLVal t2 = expType.apply(_v327,_v328,_v329,_v330,_v331);
        
        {ESLVal _v100 = t1;
        ESLVal _v101 = t2;
        
        switch(_v100.termName) {
        case "IntType": {ESLVal $847 = _v100.termRef(0);
          
          switch(_v101.termName) {
          case "IntType": {ESLVal $849 = _v101.termRef(0);
            
            {ESLVal l1 = $847;
            
            {ESLVal l2 = $849;
            
            return t1;
          }
          }
          }
        case "FloatType": {ESLVal $848 = _v101.termRef(0);
            
            {ESLVal l1 = $847;
            
            {ESLVal l2 = $848;
            
            return t2;
          }
          }
          }
          default: {ESLVal _v334 = _v100;
            
            {ESLVal _v335 = _v101;
            
            return error(new ESLVal("TypeError",_v325,new ESLVal("incomptible types for *: ").add(ppType.apply(_v334,_v331).add(new ESLVal(" and ").add(ppType.apply(_v335,_v331))))));
          }
          }
        }
        }
      case "FloatType": {ESLVal $844 = _v100.termRef(0);
          
          switch(_v101.termName) {
          case "FloatType": {ESLVal $846 = _v101.termRef(0);
            
            {ESLVal l1 = $844;
            
            {ESLVal l2 = $846;
            
            return t1;
          }
          }
          }
        case "IntType": {ESLVal $845 = _v101.termRef(0);
            
            {ESLVal l1 = $844;
            
            {ESLVal l2 = $845;
            
            return t1;
          }
          }
          }
          default: {ESLVal _v332 = _v100;
            
            {ESLVal _v333 = _v101;
            
            return error(new ESLVal("TypeError",_v325,new ESLVal("incomptible types for *: ").add(ppType.apply(_v332,_v331).add(new ESLVal(" and ").add(ppType.apply(_v333,_v331))))));
          }
          }
        }
        }
        default: {ESLVal _v336 = _v100;
          
          {ESLVal _v337 = _v101;
          
          return error(new ESLVal("TypeError",_v325,new ESLVal("incomptible types for *: ").add(ppType.apply(_v336,_v331).add(new ESLVal(" and ").add(ppType.apply(_v337,_v331))))));
        }
        }
      }
      }
      }
    }
  });
  private static ESLVal subExpType = new ESLVal(new Function(new ESLVal("subExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v312 = $args[0];
  ESLVal _v313 = $args[1];
  ESLVal _v314 = $args[2];
  ESLVal _v315 = $args[3];
  ESLVal _v316 = $args[4];
  ESLVal _v317 = $args[5];
  ESLVal _v318 = $args[6];
  {ESLVal t1 = expType.apply(_v313,_v315,_v316,_v317,_v318);
        ESLVal t2 = expType.apply(_v314,_v315,_v316,_v317,_v318);
        
        {ESLVal _v102 = t1;
        ESLVal _v103 = t2;
        
        switch(_v102.termName) {
        case "IntType": {ESLVal $853 = _v102.termRef(0);
          
          switch(_v103.termName) {
          case "IntType": {ESLVal $855 = _v103.termRef(0);
            
            {ESLVal l1 = $853;
            
            {ESLVal l2 = $855;
            
            return t1;
          }
          }
          }
        case "FloatType": {ESLVal $854 = _v103.termRef(0);
            
            {ESLVal l1 = $853;
            
            {ESLVal l2 = $854;
            
            return t2;
          }
          }
          }
          default: {ESLVal _v321 = _v102;
            
            {ESLVal _v322 = _v103;
            
            return error(new ESLVal("TypeError",_v312,new ESLVal("incomptible types for -: ").add(ppType.apply(_v321,_v318).add(new ESLVal(" and ").add(ppType.apply(_v322,_v318))))));
          }
          }
        }
        }
      case "FloatType": {ESLVal $850 = _v102.termRef(0);
          
          switch(_v103.termName) {
          case "FloatType": {ESLVal $852 = _v103.termRef(0);
            
            {ESLVal l1 = $850;
            
            {ESLVal l2 = $852;
            
            return t1;
          }
          }
          }
        case "IntType": {ESLVal $851 = _v103.termRef(0);
            
            {ESLVal l1 = $850;
            
            {ESLVal l2 = $851;
            
            return t1;
          }
          }
          }
          default: {ESLVal _v319 = _v102;
            
            {ESLVal _v320 = _v103;
            
            return error(new ESLVal("TypeError",_v312,new ESLVal("incomptible types for -: ").add(ppType.apply(_v319,_v318).add(new ESLVal(" and ").add(ppType.apply(_v320,_v318))))));
          }
          }
        }
        }
        default: {ESLVal _v323 = _v102;
          
          {ESLVal _v324 = _v103;
          
          return error(new ESLVal("TypeError",_v312,new ESLVal("incomptible types for -: ").add(ppType.apply(_v323,_v318).add(new ESLVal(" and ").add(ppType.apply(_v324,_v318))))));
        }
        }
      }
      }
      }
    }
  });
  private static ESLVal plusExpType = new ESLVal(new Function(new ESLVal("plusExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v271 = $args[0];
  ESLVal _v272 = $args[1];
  ESLVal _v273 = $args[2];
  ESLVal _v274 = $args[3];
  ESLVal _v275 = $args[4];
  ESLVal _v276 = $args[5];
  ESLVal _v277 = $args[6];
  {ESLVal t1 = expType.apply(_v272,_v274,_v275,_v276,_v277);
        ESLVal t2 = expType.apply(_v273,_v274,_v275,_v276,_v277);
        
        {ESLVal _v104 = t1;
        ESLVal _v105 = t2;
        
        switch(_v104.termName) {
        case "StrType": {ESLVal $869 = _v104.termRef(0);
          
          {ESLVal _v306 = $869;
          
          {ESLVal _v307 = _v105;
          
          return t1;
        }
        }
        }
      case "IntType": {ESLVal $867 = _v104.termRef(0);
          
          switch(_v105.termName) {
          case "IntType": {ESLVal $868 = _v105.termRef(0);
            
            {ESLVal l1 = $867;
            
            {ESLVal l2 = $868;
            
            return t1;
          }
          }
          }
          default: switch(_v105.termName) {
            case "StrType": {ESLVal $856 = _v105.termRef(0);
              
              {ESLVal _v302 = _v104;
              
              {ESLVal _v303 = $856;
              
              return t2;
            }
            }
            }
            default: {ESLVal _v304 = _v104;
              
              {ESLVal _v305 = _v105;
              
              return error(new ESLVal("TypeError",_v271,new ESLVal("incomptible types for +: ").add(ppType.apply(_v304,_v277).add(new ESLVal(" and ").add(ppType.apply(_v305,_v277))))));
            }
            }
          }
        }
        }
      case "FloatType": {ESLVal $865 = _v104.termRef(0);
          
          switch(_v105.termName) {
          case "FloatType": {ESLVal $866 = _v105.termRef(0);
            
            {ESLVal l1 = $865;
            
            {ESLVal l2 = $866;
            
            return t1;
          }
          }
          }
          default: switch(_v105.termName) {
            case "StrType": {ESLVal $856 = _v105.termRef(0);
              
              {ESLVal _v298 = _v104;
              
              {ESLVal _v299 = $856;
              
              return t2;
            }
            }
            }
            default: {ESLVal _v300 = _v104;
              
              {ESLVal _v301 = _v105;
              
              return error(new ESLVal("TypeError",_v271,new ESLVal("incomptible types for +: ").add(ppType.apply(_v300,_v277).add(new ESLVal(" and ").add(ppType.apply(_v301,_v277))))));
            }
            }
          }
        }
        }
      case "ListType": {ESLVal $862 = _v104.termRef(0);
          ESLVal $861 = _v104.termRef(1);
          
          switch(_v105.termName) {
          case "ListType": {ESLVal $864 = _v105.termRef(0);
            ESLVal $863 = _v105.termRef(1);
            
            {ESLVal l1 = $862;
            
            {ESLVal _v288 = $861;
            
            {ESLVal l2 = $864;
            
            {ESLVal _v289 = $863;
            
            if(typeEqual.apply(_v288,_v289).boolVal)
            return new ESLVal("ListType",l1,_v288);
            else
              switch(_v105.termName) {
                case "StrType": {ESLVal $856 = _v105.termRef(0);
                  
                  {ESLVal _v290 = _v104;
                  
                  {ESLVal _v291 = $856;
                  
                  return _v289;
                }
                }
                }
                default: {ESLVal _v292 = _v104;
                  
                  {ESLVal _v293 = _v105;
                  
                  return error(new ESLVal("TypeError",_v271,new ESLVal("incomptible types for +: ").add(ppType.apply(_v292,_v277).add(new ESLVal(" and ").add(ppType.apply(_v293,_v277))))));
                }
                }
              }
          }
          }
          }
          }
          }
          default: switch(_v105.termName) {
            case "StrType": {ESLVal $856 = _v105.termRef(0);
              
              {ESLVal _v294 = _v104;
              
              {ESLVal _v295 = $856;
              
              return t2;
            }
            }
            }
            default: {ESLVal _v296 = _v104;
              
              {ESLVal _v297 = _v105;
              
              return error(new ESLVal("TypeError",_v271,new ESLVal("incomptible types for +: ").add(ppType.apply(_v296,_v277).add(new ESLVal(" and ").add(ppType.apply(_v297,_v277))))));
            }
            }
          }
        }
        }
      case "SetType": {ESLVal $858 = _v104.termRef(0);
          ESLVal $857 = _v104.termRef(1);
          
          switch(_v105.termName) {
          case "SetType": {ESLVal $860 = _v105.termRef(0);
            ESLVal $859 = _v105.termRef(1);
            
            {ESLVal l1 = $858;
            
            {ESLVal _v278 = $857;
            
            {ESLVal l2 = $860;
            
            {ESLVal _v279 = $859;
            
            if(typeEqual.apply(_v278,_v279).boolVal)
            return new ESLVal("SetType",l1,_v278);
            else
              switch(_v105.termName) {
                case "StrType": {ESLVal $856 = _v105.termRef(0);
                  
                  {ESLVal _v280 = _v104;
                  
                  {ESLVal _v281 = $856;
                  
                  return _v279;
                }
                }
                }
                default: {ESLVal _v282 = _v104;
                  
                  {ESLVal _v283 = _v105;
                  
                  return error(new ESLVal("TypeError",_v271,new ESLVal("incomptible types for +: ").add(ppType.apply(_v282,_v277).add(new ESLVal(" and ").add(ppType.apply(_v283,_v277))))));
                }
                }
              }
          }
          }
          }
          }
          }
          default: switch(_v105.termName) {
            case "StrType": {ESLVal $856 = _v105.termRef(0);
              
              {ESLVal _v284 = _v104;
              
              {ESLVal _v285 = $856;
              
              return t2;
            }
            }
            }
            default: {ESLVal _v286 = _v104;
              
              {ESLVal _v287 = _v105;
              
              return error(new ESLVal("TypeError",_v271,new ESLVal("incomptible types for +: ").add(ppType.apply(_v286,_v277).add(new ESLVal(" and ").add(ppType.apply(_v287,_v277))))));
            }
            }
          }
        }
        }
        default: switch(_v105.termName) {
          case "StrType": {ESLVal $856 = _v105.termRef(0);
            
            {ESLVal _v308 = _v104;
            
            {ESLVal _v309 = $856;
            
            return t2;
          }
          }
          }
          default: {ESLVal _v310 = _v104;
            
            {ESLVal _v311 = _v105;
            
            return error(new ESLVal("TypeError",_v271,new ESLVal("incomptible types for +: ").add(ppType.apply(_v310,_v277).add(new ESLVal(" and ").add(ppType.apply(_v311,_v277))))));
          }
          }
        }
      }
      }
      }
    }
  });
  private static ESLVal applyTypeExp = new ESLVal(new Function(new ESLVal("applyTypeExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v260 = $args[0];
  ESLVal _v261 = $args[1];
  ESLVal _v262 = $args[2];
  ESLVal _v263 = $args[3];
  ESLVal _v264 = $args[4];
  ESLVal _v265 = $args[5];
  ESLVal _v266 = $args[6];
  {ESLVal _v267 = substTypesEnv.apply(_v266,_v262);
        ESLVal _v268 = expType.apply(_v261,_v263,_v264,_v265,_v266);
        
        {ESLVal _v106 = _v268;
        
        switch(_v106.termName) {
        case "ForallType": {ESLVal $872 = _v106.termRef(0);
          ESLVal $871 = _v106.termRef(1);
          ESLVal $870 = _v106.termRef(2);
          
          {ESLVal l1 = $872;
          
          {ESLVal ns = $871;
          
          {ESLVal _v269 = $870;
          
          if(length.apply(ns).eql(length.apply(_v267)).boolVal)
          {ESLVal env = zipTypeEnv.apply(ns,_v267);
            
            return substTypeEnv.apply(env.add(_v264),_v269);
          }
          else
            return error(new ESLVal("TypeError",_v260,new ESLVal("universal type expects ").add(length.apply(ns).add(new ESLVal(" types, but supplied with ").add(length.apply(_v267))))));
        }
        }
        }
        }
        default: {ESLVal _v270 = _v106;
          
          return error(new ESLVal("TypeError",_v260,new ESLVal("expecting a universal type: ").add(_v270)));
        }
      }
      }
      }
    }
  });
  private static ESLVal expTypes = new ESLVal(new Function(new ESLVal("expTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v255 = $args[0];
  ESLVal _v256 = $args[1];
  ESLVal _v257 = $args[2];
  ESLVal _v258 = $args[3];
  ESLVal _v259 = $args[4];
  return map.apply(new ESLVal(new Function(new ESLVal("fun227"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal e = $args[0];
        return expType.apply(e,_v256,_v257,_v258,_v259);
          }
        }),_v255);
    }
  });
  private static ESLVal applyType = new ESLVal(new Function(new ESLVal("applyType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v248 = $args[0];
  ESLVal _v249 = $args[1];
  ESLVal _v250 = $args[2];
  ESLVal _v251 = $args[3];
  ESLVal _v252 = $args[4];
  ESLVal _v253 = $args[5];
  ESLVal _v254 = $args[6];
  {ESLVal _v107 = typeNF.apply(expType.apply(_v249,_v251,_v252,_v253,_v254),_v254);
        
        switch(_v107.termName) {
        case "FunType": {ESLVal $875 = _v107.termRef(0);
          ESLVal $874 = _v107.termRef(1);
          ESLVal $873 = _v107.termRef(2);
          
          {ESLVal l1 = $875;
          
          {ESLVal domain = $874;
          
          {ESLVal range = $873;
          
          {ESLVal supplied = expTypes.apply(_v250,_v251,_v252,_v253,_v254);
          
          if(length.apply(domain).eql(length.apply(supplied)).boolVal)
          if(subTypes.apply(supplied,domain).boolVal)
            return range;
            else
              return error(new ESLVal("TypeError",_v248,new ESLVal("supplied argument types ").add(ppTypes.apply(supplied,_v254).add(new ESLVal(" do not match function domain ").add(ppTypes.apply(domain,_v254))))));
          else
            return error(new ESLVal("TypeError",_v248,new ESLVal("expecting ").add(length.apply(domain).add(new ESLVal(" args, but supplied with ").add(length.apply(supplied))))));
        }
        }
        }
        }
        }
        default: {ESLVal t = _v107;
          
          return error(new ESLVal("TypeError",_v248,new ESLVal("unknown type for apply: ").add(ppType.apply(t,_v254))));
        }
      }
      }
    }
  });
  private static ESLVal ifType = new ESLVal(new Function(new ESLVal("ifType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v240 = $args[0];
  ESLVal _v241 = $args[1];
  ESLVal _v242 = $args[2];
  ESLVal _v243 = $args[3];
  ESLVal _v244 = $args[4];
  ESLVal _v245 = $args[5];
  ESLVal _v246 = $args[6];
  ESLVal _v247 = $args[7];
  {ESLVal testType = expType.apply(_v241,_v244,_v245,_v246,_v247);
        
        if(isBoolType.apply(testType).boolVal)
        {ESLVal conseqType = expType.apply(_v242,_v244,_v245,_v246,_v247);
          ESLVal altType = expType.apply(_v243,_v244,_v245,_v246,_v247);
          
          if(typeEqual.apply(conseqType,altType).boolVal)
          return conseqType;
          else
            return error(new ESLVal("TypeError",_v240,new ESLVal("conseq and alt types do not agree: ").add(ppType.apply(conseqType,_v247).add(new ESLVal(" ").add(ppType.apply(altType,_v247))))));
        }
        else
          return error(new ESLVal("if expects a bool ").add(ppType.apply(testType,_v247)));
      }
    }
  });
  private static ESLVal checkDecs = new ESLVal(new Function(new ESLVal("checkDecs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal ds = $args[0];
  {ESLVal _v108 = ds;
        
        if(_v108.isCons())
        {ESLVal $876 = _v108.head();
          ESLVal $877 = _v108.tail();
          
          {ESLVal d = $876;
          
          {ESLVal _v239 = $877;
          
          if(member.apply(decName.apply(d),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal d = $l0.head();
              $l0 = $l0.tail();
              $v.add(decName.apply(d));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(_v239)).boolVal)
          return error(new ESLVal("TypeError",decLoc.apply(d),new ESLVal(" duplicate argument ").add(decName.apply(d))));
          else
            return checkDecs.apply(_v239);
        }
        }
        }
      else if(_v108.isNil())
        return $null;
      else return error(new ESLVal("case error at Pos(68433,68666)").add(ESLVal.list(_v108)));
      }
    }
  });
  private static ESLVal funType = new ESLVal(new Function(new ESLVal("funType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v228 = $args[0];
  ESLVal _v229 = $args[1];
  ESLVal _v230 = $args[2];
  ESLVal _v231 = $args[3];
  ESLVal _v232 = $args[4];
  ESLVal _v233 = $args[5];
  ESLVal _v234 = $args[6];
  ESLVal _v235 = $args[7];
  ESLVal _v236 = $args[8];
  {checkDecs.apply(_v230);
      {ESLVal nType = expType.apply(_v229,_v233,_v234,_v235,_v236);
        
        if(isStrType.apply(nType).boolVal)
        {ESLVal declaredType = substTypeEnv.apply(_v236,_v231);
          
          return decTypes.apply(_v230,_v234,_v236,new ESLVal(new Function(new ESLVal("fun228"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v237 = $args[0];
          ESLVal _v238 = $args[1];
          {ESLVal actualRange = expType.apply(_v232,_v233,_v238,_v235,_v236);
                
                if(subType.apply(new ESLVal("FunType",_v228,_v237,actualRange),declaredType).boolVal)
                return new ESLVal("FunType",_v228,_v237,actualRange);
                else
                  return error(new ESLVal("TypeError",_v228,new ESLVal("function declared type ").add(ppType.apply(declaredType,_v236).add(new ESLVal(" but is ").add(ppType.apply(new ESLVal("FunType",_v228,_v237,actualRange),_v236))))));
              }
            }
          }));
        }
        else
          return error(new ESLVal("TypeError",_v228,new ESLVal("expecting a string for a function name: ").add(_v229)));
      }}
    }
  });
  private static ESLVal decTypes = new ESLVal(new Function(new ESLVal("decTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v221 = $args[0];
  ESLVal _v222 = $args[1];
  ESLVal _v223 = $args[2];
  ESLVal _v224 = $args[3];
  { LetRec letrec = new LetRec() {
        ESLVal processDecs = new ESLVal(new Function(new ESLVal("processDecs"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v225 = $args[0];
          ESLVal _v226 = $args[1];
          {ESLVal _v109 = _v225;
                
                if(_v109.isCons())
                {ESLVal $878 = _v109.head();
                  ESLVal $879 = _v109.tail();
                  
                  switch($878.termName) {
                  case "Dec": {ESLVal $883 = $878.termRef(0);
                    ESLVal $882 = $878.termRef(1);
                    ESLVal $881 = $878.termRef(2);
                    ESLVal $880 = $878.termRef(3);
                    
                    {ESLVal l = $883;
                    
                    {ESLVal n = $882;
                    
                    {ESLVal t = $881;
                    
                    {ESLVal st = $880;
                    
                    {ESLVal _v227 = $879;
                    
                    return processDecs.apply(_v227,_v226.cons(new ESLVal("Map",n,substTypeEnv.apply(_v223,t))));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(69859,70084)").add(ESLVal.list(_v109)));
                }
                }
              else if(_v109.isNil())
                return _v224.apply(reverse.apply(typeEnvRan.apply(_v226)),_v226.add(_v222));
              else return error(new ESLVal("case error at Pos(69859,70084)").add(ESLVal.list(_v109)));
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "processDecs": return processDecs;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal processDecs = letrec.get("processDecs");
      
        return processDecs.apply(_v221,$nil);}
      
    }
  });
  private static ESLVal termType = new ESLVal(new Function(new ESLVal("termType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v213 = $args[0];
  ESLVal _v214 = $args[1];
  ESLVal _v215 = $args[2];
  ESLVal _v216 = $args[3];
  ESLVal _v217 = $args[4];
  ESLVal _v218 = $args[5];
  ESLVal _v219 = $args[6];
  ESLVal _v220 = $args[7];
  {ESLVal t0 = lookupType.apply(_v214,_v219);
        
        if(t0.eql($null).boolVal)
        return error(new ESLVal("TypeError",_v213,new ESLVal("cannot find cnstr ").add(_v214)));
        else
          {ESLVal t = unfoldIf.apply(t0);
            
            return termTypeCheckUnion.apply(t,_v213,_v214,_v215,_v216,_v217,_v218,_v219,_v220);
          }
      }
    }
  });
  private static ESLVal termTypeCheckUnion = new ESLVal(new Function(new ESLVal("termTypeCheckUnion"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v202 = $args[0];
  ESLVal _v203 = $args[1];
  ESLVal _v204 = $args[2];
  ESLVal _v205 = $args[3];
  ESLVal _v206 = $args[4];
  ESLVal _v207 = $args[5];
  ESLVal _v208 = $args[6];
  ESLVal _v209 = $args[7];
  ESLVal _v210 = $args[8];
  if(_v202.eql($null).boolVal)
        return error(new ESLVal("TypeError",_v203,new ESLVal("cannot find constructor ").add(_v204)));
        else
          {ESLVal _v110 = _v202;
            
            switch(_v110.termName) {
            case "TypeFun": {ESLVal $888 = _v110.termRef(0);
              ESLVal $887 = _v110.termRef(1);
              ESLVal $886 = _v110.termRef(2);
              
              {ESLVal lf = $888;
              
              {ESLVal ns = $887;
              
              {ESLVal body = $886;
              
              if(length.apply(ns).eql(length.apply(_v205)).boolVal)
              {ESLVal args = map.apply(new ESLVal(new Function(new ESLVal("fun229"),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      ESLVal _v211 = $args[0];
                  return substTypeEnv.apply(_v210,_v211);
                    }
                  }),_v205);
                
                {ESLVal _v111 = substTypeEnv.apply(zipTypeEnv.apply(ns,args),body);
                
                switch(_v111.termName) {
                case "UnionType": {ESLVal $890 = _v111.termRef(0);
                  ESLVal $889 = _v111.termRef(1);
                  
                  {ESLVal l1 = $890;
                  
                  {ESLVal terms = $889;
                  
                  {ESLVal ts2 = findTermArgTypes.apply(_v204,terms);
                  
                  if(length.apply(_v206).eql(length.apply(ts2)).boolVal)
                  {checkTermArgTypes.apply(_v203,_v206,ts2,_v207,_v208,_v209,_v210);
                  return new ESLVal("UnionType",l1,terms);}
                  else
                    return error(new ESLVal("TypeError",_v203,_v204.add(new ESLVal(" expects ").add(length.apply(ts2).add(new ESLVal(" args, but you supplied ").add(length.apply(_v206)))))));
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(70957,71519)").add(ESLVal.list(_v111)));
              }
              }
              }
              else
                return error(new ESLVal("TypeError",_v203,new ESLVal("generic constructor ").add(_v204.add(new ESLVal(" expects ").add(length.apply(ns).add(new ESLVal(" type arguments, but received ").add(length.apply(_v205))))))));
            }
            }
            }
            }
          case "UnionType": {ESLVal $885 = _v110.termRef(0);
              ESLVal $884 = _v110.termRef(1);
              
              {ESLVal l1 = $885;
              
              {ESLVal terms = $884;
              
              {ESLVal ts2 = findTermArgTypes.apply(_v204,terms);
              
              if(length.apply(_v205).neql($zero).boolVal)
              return error(new ESLVal("TypeError",_v203,new ESLVal("generic application of non-generic constructior: ").add(_v204)));
              else
                if(length.apply(_v206).eql(length.apply(ts2)).boolVal)
                  {checkTermArgTypes.apply(_v203,_v206,ts2,_v207,_v208,_v209,_v210);
                  return _v202;}
                  else
                    return error(new ESLVal("TypeError",_v203,_v204.add(new ESLVal(" expects ").add(length.apply(ts2).add(new ESLVal(" args, but you supplied ").add(length.apply(_v206)))))));
            }
            }
            }
            }
            default: {ESLVal _v212 = _v110;
              
              return error(new ESLVal("TypeError",_v203,new ESLVal("expecting a union type for ").add(_v204.add(new ESLVal(" but got ").add(ppType.apply(_v212,_v210))))));
            }
          }
          }
    }
  });
  private static ESLVal unfoldIf = new ESLVal(new Function(new ESLVal("unfoldIf"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v112 = t;
        
        switch(_v112.termName) {
        case "RecType": {ESLVal $893 = _v112.termRef(0);
          ESLVal $892 = _v112.termRef(1);
          ESLVal $891 = _v112.termRef(2);
          
          {ESLVal l = $893;
          
          {ESLVal n = $892;
          
          {ESLVal _v200 = $891;
          
          return unfoldIf.apply(unfoldType.apply(l,n,_v200));
        }
        }
        }
        }
        default: {ESLVal _v201 = _v112;
          
          return _v201;
        }
      }
      }
    }
  });
  private static ESLVal findTermArgTypes = new ESLVal(new Function(new ESLVal("findTermArgTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal n = $args[0];
  ESLVal terms = $args[1];
  {ESLVal _v113 = terms;
        
        if(_v113.isCons())
        {ESLVal $894 = _v113.head();
          ESLVal $895 = _v113.tail();
          
          switch($894.termName) {
          case "TermType": {ESLVal $898 = $894.termRef(0);
            ESLVal $897 = $894.termRef(1);
            ESLVal $896 = $894.termRef(2);
            
            {ESLVal l = $898;
            
            {ESLVal nn = $897;
            
            {ESLVal ts = $896;
            
            {ESLVal _v198 = $895;
            
            if(nn.eql(n).boolVal)
            return ts;
            else
              {ESLVal t = $894;
                
                {ESLVal _v199 = $895;
                
                return findTermArgTypes.apply(n,_v199);
              }
              }
          }
          }
          }
          }
          }
          default: {ESLVal t = $894;
            
            {ESLVal ts = $895;
            
            return findTermArgTypes.apply(n,ts);
          }
          }
        }
        }
      else if(_v113.isNil())
        return error(new ESLVal("cannot find constructor ").add(n));
      else return error(new ESLVal("case error at Pos(72527,72727)").add(ESLVal.list(_v113)));
      }
    }
  });
  private static ESLVal checkTermArgTypes = new ESLVal(new Function(new ESLVal("checkTermArgTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v189 = $args[0];
  ESLVal _v190 = $args[1];
  ESLVal _v191 = $args[2];
  ESLVal _v192 = $args[3];
  ESLVal _v193 = $args[4];
  ESLVal _v194 = $args[5];
  ESLVal _v195 = $args[6];
  {ESLVal _v114 = _v190;
        ESLVal _v115 = _v191;
        
        if(_v114.isCons())
        {ESLVal $899 = _v114.head();
          ESLVal $900 = _v114.tail();
          
          if(_v115.isCons())
          {ESLVal $901 = _v115.head();
            ESLVal $902 = _v115.tail();
            
            {ESLVal e = $899;
            
            {ESLVal _v196 = $900;
            
            {ESLVal t = $901;
            
            {ESLVal _v197 = $902;
            
            {ESLVal tt = expType.apply(e,_v192,_v193,_v194,_v195);
            
            if(typeEqual.apply(t,tt).boolVal)
            return checkTermArgTypes.apply(_v189,_v196,_v197,_v192,_v193,_v194,_v195);
            else
              return error(new ESLVal("TypeError",_v189,new ESLVal("expected constructor arg type ").add(ppType.apply(t,_v195).add(new ESLVal(" but supplied ").add(ppType.apply(tt,_v195))))));
          }
          }
          }
          }
          }
          }
        else if(_v115.isNil())
          return error(new ESLVal("case error at Pos(72845,73267)").add(ESLVal.list(_v114,_v115)));
        else return error(new ESLVal("case error at Pos(72845,73267)").add(ESLVal.list(_v114,_v115)));
        }
      else if(_v114.isNil())
        if(_v115.isCons())
          {ESLVal $903 = _v115.head();
            ESLVal $904 = _v115.tail();
            
            return error(new ESLVal("case error at Pos(72845,73267)").add(ESLVal.list(_v114,_v115)));
          }
        else if(_v115.isNil())
          return $null;
        else return error(new ESLVal("case error at Pos(72845,73267)").add(ESLVal.list(_v114,_v115)));
      else return error(new ESLVal("case error at Pos(72845,73267)").add(ESLVal.list(_v114,_v115)));
      }
    }
  });
  private static ESLVal notType = new ESLVal(new Function(new ESLVal("notType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v182 = $args[0];
  ESLVal _v183 = $args[1];
  ESLVal _v184 = $args[2];
  ESLVal _v185 = $args[3];
  ESLVal _v186 = $args[4];
  ESLVal _v187 = $args[5];
  {ESLVal _v116 = expType.apply(_v183,_v184,_v185,_v186,_v187);
        
        switch(_v116.termName) {
        case "BoolType": {ESLVal $905 = _v116.termRef(0);
          
          {ESLVal _v188 = $905;
          
          return new ESLVal("BoolType",_v188);
        }
        }
        default: {ESLVal t = _v116;
          
          return error(new ESLVal("TypeError",_v182,new ESLVal("expecting a boolean: ").add(ppType.apply(t,_v187))));
        }
      }
      }
    }
  });
  private static ESLVal varType = new ESLVal(new Function(new ESLVal("varType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal n = $args[1];
  ESLVal valueEnv = $args[2];
  {ESLVal t = lookupType.apply(n,valueEnv);
        
        if(t.eql($null).boolVal)
        return error(new ESLVal("TypeError",l,new ESLVal("unbound variable ").add(n)));
        else
          {ESLVal _v117 = t;
            
            switch(_v117.termName) {
            case "TypeClosure": {ESLVal $906 = _v117.termRef(0);
              
              {ESLVal f = $906;
              
              return f.apply();
            }
            }
            default: {ESLVal _v181 = _v117;
              
              return _v181;
            }
          }
          }
      }
    }
  });
  private static ESLVal blockType = new ESLVal(new Function(new ESLVal("blockType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v175 = $args[0];
  ESLVal _v176 = $args[1];
  ESLVal _v177 = $args[2];
  ESLVal _v178 = $args[3];
  ESLVal _v179 = $args[4];
  ESLVal _v180 = $args[5];
  {ESLVal[] t = new ESLVal[]{new ESLVal("VoidType",_v175)};
        
        {{
        ESLVal _v118 = _v176;
        while(_v118.isCons()) {
          ESLVal e = _v118.headVal;
          t[0] = expType.apply(e,_v177,_v178,_v179,_v180);
          _v118 = _v118.tailVal;}
      }
      return t[0];}
      }
    }
  });
  private static ESLVal listType = new ESLVal(new Function(new ESLVal("listType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v169 = $args[0];
  ESLVal _v170 = $args[1];
  ESLVal _v171 = $args[2];
  ESLVal _v172 = $args[3];
  ESLVal _v173 = $args[4];
  ESLVal _v174 = $args[5];
  if(_v170.eql($nil).boolVal)
        return new ESLVal("ForallType",_v169,ESLVal.list(new ESLVal("T")),new ESLVal("ListType",_v169,new ESLVal("VarType",_v169,new ESLVal("T"))));
        else
          {ESLVal ts = map.apply(new ESLVal(new Function(new ESLVal("fun230"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal e = $args[0];
              return expType.apply(e,_v171,_v172,_v173,_v174);
                }
              }),_v170);
            
            if(allEqualTypes.apply(head.apply(ts),tail.apply(ts)).boolVal)
            return new ESLVal("ListType",_v169,head.apply(ts));
            else
              return error(new ESLVal("TypeError",_v169,new ESLVal("lists should have elements of the same type: ").add(_v170)));
          }
    }
  });
  private static ESLVal setType = new ESLVal(new Function(new ESLVal("setType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v163 = $args[0];
  ESLVal _v164 = $args[1];
  ESLVal _v165 = $args[2];
  ESLVal _v166 = $args[3];
  ESLVal _v167 = $args[4];
  ESLVal _v168 = $args[5];
  if(_v164.eql($nil).boolVal)
        return new ESLVal("ForallType",_v163,ESLVal.list(new ESLVal("T")),new ESLVal("SetType",_v163,new ESLVal("VarType",_v163,new ESLVal("T"))));
        else
          {ESLVal ts = map.apply(new ESLVal(new Function(new ESLVal("fun231"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal e = $args[0];
              return expType.apply(e,_v165,_v166,_v167,_v168);
                }
              }),_v164);
            
            if(allEqualTypes.apply(head.apply(ts),tail.apply(ts)).boolVal)
            return new ESLVal("SetType",_v163,head.apply(ts));
            else
              return error(new ESLVal("TypeError",_v163,new ESLVal("sets should have elements of the same type: ").add(_v164)));
          }
    }
  });
  private static ESLVal bagType = new ESLVal(new Function(new ESLVal("bagType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v157 = $args[0];
  ESLVal _v158 = $args[1];
  ESLVal _v159 = $args[2];
  ESLVal _v160 = $args[3];
  ESLVal _v161 = $args[4];
  ESLVal _v162 = $args[5];
  if(_v158.eql($nil).boolVal)
        return new ESLVal("ForallType",_v157,ESLVal.list(new ESLVal("T")),new ESLVal("BagType",_v157,new ESLVal("VarType",_v157,new ESLVal("T"))));
        else
          {ESLVal ts = map.apply(new ESLVal(new Function(new ESLVal("fun232"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal e = $args[0];
              return expType.apply(e,_v159,_v160,_v161,_v162);
                }
              }),_v158);
            
            if(allEqualTypes.apply(head.apply(ts),tail.apply(ts)).boolVal)
            return new ESLVal("BagType",_v157,head.apply(ts));
            else
              return error(new ESLVal("TypeError",_v157,new ESLVal("bags should have elements of the same type: ").add(_v158)));
          }
    }
  });
  private static ESLVal recTypes = new ESLVal(new Function(new ESLVal("recTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal env = $args[0];
  { LetRec letrec = new LetRec() {
        ESLVal fixEnv = new ESLVal(new Function(new ESLVal("fixEnv"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v156 = $args[0];
          {ESLVal[] e = new ESLVal[]{$null};
                
                {ESLVal fenv = new java.util.function.Function<ESLVal,ESLVal>() {
                    public ESLVal apply(ESLVal $l0) {
                      ESLVal $a = $nil;
                      java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                      while(!$l0.isNil()) { 
                        ESLVal t = $l0.head();
                        $l0 = $l0.tail();
                        ESLVal $l1 = typeFV.apply(t);
                  while(!$l1.isNil()) {
                    ESLVal n = $l1.head();
                    $l1 = $l1.tail();
                    $v.add(new ESLVal("Map",n,new ESLVal("TypeClosure",new ESLVal(new Function(new ESLVal("lookup: ").add(n),getSelf()) {
                      public ESLVal apply(ESLVal... $args) {
                        return lookupType.apply(n,e[0]);
                      }
                    }))));
                  }
                      }
                      for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                      return $a;
                    }}.apply(typeEnvRan.apply(_v156));
                
                {ESLVal env1 = substOnce.apply(_v156,fenv);
                
                {e[0] = env1;
              return env1;}
              }
              }
              }
            }
          });
        ESLVal introduceRecTypes = new ESLVal(new Function(new ESLVal("introduceRecTypes"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v155 = $args[0];
          {ESLVal _v119 = _v155;
                
                if(_v119.isCons())
                {ESLVal $907 = _v119.head();
                  ESLVal $908 = _v119.tail();
                  
                  switch($907.termName) {
                  case "Map": {ESLVal $910 = $907.termRef(0);
                    ESLVal $909 = $907.termRef(1);
                    
                    switch($909.termName) {
                    case "RecordType": {ESLVal $912 = $909.termRef(0);
                      ESLVal $911 = $909.termRef(1);
                      
                      {ESLVal n = $910;
                      
                      {ESLVal l = $912;
                      
                      {ESLVal fs = $911;
                      
                      {ESLVal e = $908;
                      
                      return introduceRecTypes.apply(e).cons(new ESLVal("Map",n,new ESLVal("RecordType",l,fs)));
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal n = $910;
                      
                      {ESLVal t = $909;
                      
                      {ESLVal e = $908;
                      
                      if(member.apply(n,typeFV.apply(t)).boolVal)
                      return introduceRecTypes.apply(e).cons(new ESLVal("Map",n,new ESLVal("RecType",p0,n,t)));
                      else
                        return introduceRecTypes.apply(e).cons(new ESLVal("Map",n,t));
                    }
                    }
                    }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(75816,76130)").add(ESLVal.list(_v119)));
                }
                }
              else if(_v119.isNil())
                return _v155;
              else return error(new ESLVal("case error at Pos(75816,76130)").add(ESLVal.list(_v119)));
              }
            }
          });
        ESLVal substOnce = new ESLVal(new Function(new ESLVal("substOnce"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v153 = $args[0];
          ESLVal _v154 = $args[1];
          {ESLVal map1 = new ESLVal(new Function(new ESLVal("map1"),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      ESLVal m = $args[0];
                  {ESLVal _v120 = m;
                        
                        switch(_v120.termName) {
                        case "Map": {ESLVal $914 = _v120.termRef(0);
                          ESLVal $913 = _v120.termRef(1);
                          
                          {ESLVal n = $914;
                          
                          {ESLVal t = $913;
                          
                          return new ESLVal("Map",n,substTypeEnv.apply(new java.util.function.Function<ESLVal,ESLVal>() {
                            public ESLVal apply(ESLVal $l0) {
                              ESLVal $a = $nil;
                              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                              while(!$l0.isNil()) { 
                                ESLVal n = $l0.head();
                                $l0 = $l0.tail();
                                $v.add(new ESLVal("Map",n,lookupType.apply(n,_v154)));
                              }
                              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                              return $a;
                            }}.apply(typeFV.apply(t)),t));
                        }
                        }
                        }
                        default: return error(new ESLVal("case error at Pos(76240,76371)").add(ESLVal.list(_v120)));
                      }
                      }
                    }
                  });
                
                return map.apply(map1,_v153);
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "fixEnv": return fixEnv;
            
            case "introduceRecTypes": return introduceRecTypes;
            
            case "substOnce": return substOnce;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal fixEnv = letrec.get("fixEnv");
      
      ESLVal introduceRecTypes = letrec.get("introduceRecTypes");
      
      ESLVal substOnce = letrec.get("substOnce");
      
        return fixEnv.apply(introduceRecTypes.apply(env));}
      
    }
  });
  private static ESLVal typeFV = new ESLVal(new Function(new ESLVal("typeFV"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  return removeDups.apply(varTypeNames.apply(typeFV1.apply(t,$nil)));
    }
  });
  private static ESLVal varTypeNames = new ESLVal(new Function(new ESLVal("varTypeNames"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal vs = $args[0];
  return map.apply(varTypeName,vs);
    }
  });
  private static ESLVal varTypeName = new ESLVal(new Function(new ESLVal("varTypeName"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v121 = t;
        
        switch(_v121.termName) {
        case "VarType": {ESLVal $916 = _v121.termRef(0);
          ESLVal $915 = _v121.termRef(1);
          
          {ESLVal l = $916;
          
          {ESLVal n = $915;
          
          return n;
        }
        }
        }
        default: {ESLVal x = _v121;
          
          return new ESLVal("<var>");
        }
      }
      }
    }
  });
  private static ESLVal tdecsFV1 = new ESLVal(new Function(new ESLVal("tdecsFV1"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal decs = $args[0];
  ESLVal fv = $args[1];
  {ESLVal _v122 = decs;
        
        if(_v122.isCons())
        {ESLVal $917 = _v122.head();
          ESLVal $918 = _v122.tail();
          
          {ESLVal d = $917;
          
          {ESLVal ds = $918;
          
          return tdecFV1.apply(d,tdecsFV1.apply(ds,fv));
        }
        }
        }
      else if(_v122.isNil())
        return fv;
      else return error(new ESLVal("case error at Pos(76757,76846)").add(ESLVal.list(_v122)));
      }
    }
  });
  private static ESLVal tdecFV1 = new ESLVal(new Function(new ESLVal("tdecFV1"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d = $args[0];
  ESLVal fv = $args[1];
  {ESLVal _v123 = d;
        
        switch(_v123.termName) {
        case "Dec": {ESLVal $922 = _v123.termRef(0);
          ESLVal $921 = _v123.termRef(1);
          ESLVal $920 = _v123.termRef(2);
          ESLVal $919 = _v123.termRef(3);
          
          {ESLVal l = $922;
          
          {ESLVal n = $921;
          
          {ESLVal t = $920;
          
          {ESLVal st = $919;
          
          return typeFV1.apply(t,fv);
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(76890,76969)").add(ESLVal.list(_v123)));
      }
      }
    }
  });
  private static ESLVal handlersFV1 = new ESLVal(new Function(new ESLVal("handlersFV1"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal handlers = $args[0];
  ESLVal fv = $args[1];
  {ESLVal _v124 = handlers;
        
        if(_v124.isCons())
        {ESLVal $923 = _v124.head();
          ESLVal $924 = _v124.tail();
          
          {ESLVal m = $923;
          
          {ESLVal hs = $924;
          
          return handlerFV1.apply(m,handlersFV1.apply(hs,fv));
        }
        }
        }
      else if(_v124.isNil())
        return fv;
      else return error(new ESLVal("case error at Pos(77027,77129)").add(ESLVal.list(_v124)));
      }
    }
  });
  private static ESLVal handlerFV1 = new ESLVal(new Function(new ESLVal("handlerFV1"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal m = $args[0];
  ESLVal fv = $args[1];
  {ESLVal _v125 = m;
        
        switch(_v125.termName) {
        case "MessageType": {ESLVal $926 = _v125.termRef(0);
          ESLVal $925 = _v125.termRef(1);
          
          {ESLVal l = $926;
          
          {ESLVal ts = $925;
          
          return typesFV1.apply(ts,fv);
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(77177,77253)").add(ESLVal.list(_v125)));
      }
      }
    }
  });
  private static ESLVal typesFV1 = new ESLVal(new Function(new ESLVal("typesFV1"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal ts = $args[0];
  ESLVal fv = $args[1];
  {ESLVal _v126 = ts;
        
        if(_v126.isCons())
        {ESLVal $927 = _v126.head();
          ESLVal $928 = _v126.tail();
          
          {ESLVal t = $927;
          
          {ESLVal _v152 = $928;
          
          return typeFV1.apply(t,typesFV1.apply(_v152,fv));
        }
        }
        }
      else if(_v126.isNil())
        return fv;
      else return error(new ESLVal("case error at Pos(77302,77389)").add(ESLVal.list(_v126)));
      }
    }
  });
  private static ESLVal typeFV1 = new ESLVal(new Function(new ESLVal("typeFV1"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  ESLVal fv = $args[1];
  {ESLVal _v127 = t;
        
        switch(_v127.termName) {
        case "ArrayType": {ESLVal $994 = _v127.termRef(0);
          ESLVal $993 = _v127.termRef(1);
          
          {ESLVal l = $994;
          
          {ESLVal _v151 = $993;
          
          return typeFV1.apply(_v151,fv);
        }
        }
        }
      case "ActType": {ESLVal $992 = _v127.termRef(0);
          ESLVal $991 = _v127.termRef(1);
          ESLVal $990 = _v127.termRef(2);
          
          {ESLVal l = $992;
          
          {ESLVal decs = $991;
          
          {ESLVal handlers = $990;
          
          return tdecsFV1.apply(decs,handlersFV1.apply(handlers,fv));
        }
        }
        }
        }
      case "ExtendedAct": {ESLVal $989 = _v127.termRef(0);
          ESLVal $988 = _v127.termRef(1);
          ESLVal $987 = _v127.termRef(2);
          ESLVal $986 = _v127.termRef(3);
          
          {ESLVal l = $989;
          
          {ESLVal parent = $988;
          
          {ESLVal decs = $987;
          
          {ESLVal handlers = $986;
          
          return tdecsFV1.apply(decs,handlersFV1.apply(handlers,typeFV1.apply(parent,fv)));
        }
        }
        }
        }
        }
      case "ApplyType": {ESLVal $985 = _v127.termRef(0);
          ESLVal $984 = _v127.termRef(1);
          ESLVal $983 = _v127.termRef(2);
          
          {ESLVal l = $985;
          
          {ESLVal n = $984;
          
          {ESLVal types = $983;
          
          return typesFV1.apply(types,fv.cons(new ESLVal("VarType",l,n)));
        }
        }
        }
        }
      case "ApplyTypeFun": {ESLVal $982 = _v127.termRef(0);
          ESLVal $981 = _v127.termRef(1);
          ESLVal $980 = _v127.termRef(2);
          
          {ESLVal l = $982;
          
          {ESLVal op = $981;
          
          {ESLVal args = $980;
          
          return typesFV1.apply(args,typeFV1.apply(op,fv));
        }
        }
        }
        }
      case "BoolType": {ESLVal $979 = _v127.termRef(0);
          
          {ESLVal l = $979;
          
          return fv;
        }
        }
      case "FieldType": {ESLVal $978 = _v127.termRef(0);
          ESLVal $977 = _v127.termRef(1);
          ESLVal $976 = _v127.termRef(2);
          
          {ESLVal l = $978;
          
          {ESLVal n = $977;
          
          {ESLVal _v150 = $976;
          
          return typeFV1.apply(_v150,fv);
        }
        }
        }
        }
      case "FloatType": {ESLVal $975 = _v127.termRef(0);
          
          {ESLVal l = $975;
          
          return fv;
        }
        }
      case "ForallType": {ESLVal $974 = _v127.termRef(0);
          ESLVal $973 = _v127.termRef(1);
          ESLVal $972 = _v127.termRef(2);
          
          {ESLVal l = $974;
          
          {ESLVal ns = $973;
          
          {ESLVal _v147 = $972;
          
          return filter.apply(new ESLVal(new Function(new ESLVal("fun233"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v148 = $args[0];
          {ESLVal _v131 = _v148;
                
                switch(_v131.termName) {
                case "VarType": {ESLVal $1004 = _v131.termRef(0);
                  ESLVal $1003 = _v131.termRef(1);
                  
                  {ESLVal _v149 = $1004;
                  
                  {ESLVal n = $1003;
                  
                  return member.apply(n,ns).not();
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(78228,78288)").add(ESLVal.list(_v131)));
              }
              }
            }
          }),typeFV1.apply(_v147,$nil)).add(fv);
        }
        }
        }
        }
      case "FunType": {ESLVal $971 = _v127.termRef(0);
          ESLVal $970 = _v127.termRef(1);
          ESLVal $969 = _v127.termRef(2);
          
          {ESLVal l = $971;
          
          {ESLVal d = $970;
          
          {ESLVal r = $969;
          
          return typesFV1.apply(d,typeFV1.apply(r,fv));
        }
        }
        }
        }
      case "IntType": {ESLVal $968 = _v127.termRef(0);
          
          {ESLVal l = $968;
          
          return fv;
        }
        }
      case "ListType": {ESLVal $967 = _v127.termRef(0);
          ESLVal $966 = _v127.termRef(1);
          
          {ESLVal l = $967;
          
          {ESLVal _v146 = $966;
          
          return typeFV1.apply(_v146,fv);
        }
        }
        }
      case "BagType": {ESLVal $965 = _v127.termRef(0);
          ESLVal $964 = _v127.termRef(1);
          
          {ESLVal l = $965;
          
          {ESLVal _v145 = $964;
          
          return typeFV1.apply(_v145,fv);
        }
        }
        }
      case "SetType": {ESLVal $963 = _v127.termRef(0);
          ESLVal $962 = _v127.termRef(1);
          
          {ESLVal l = $963;
          
          {ESLVal _v144 = $962;
          
          return typeFV1.apply(_v144,fv);
        }
        }
        }
      case "NullType": {ESLVal $961 = _v127.termRef(0);
          
          {ESLVal l = $961;
          
          return fv;
        }
        }
      case "ObserverType": {ESLVal $960 = _v127.termRef(0);
          ESLVal $959 = _v127.termRef(1);
          ESLVal $958 = _v127.termRef(2);
          
          {ESLVal l = $960;
          
          {ESLVal s = $959;
          
          {ESLVal m = $958;
          
          return typeFV1.apply(s,typeFV1.apply(m,fv));
        }
        }
        }
        }
      case "ObservedType": {ESLVal $957 = _v127.termRef(0);
          ESLVal $956 = _v127.termRef(1);
          ESLVal $955 = _v127.termRef(2);
          
          {ESLVal l = $957;
          
          {ESLVal s = $956;
          
          {ESLVal m = $955;
          
          return typeFV1.apply(s,typeFV1.apply(m,fv));
        }
        }
        }
        }
      case "RecordType": {ESLVal $954 = _v127.termRef(0);
          ESLVal $953 = _v127.termRef(1);
          
          {ESLVal l = $954;
          
          {ESLVal fs = $953;
          
          return typesFV1.apply(new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v130 = $qualArg;
                
                switch(_v130.termName) {
                case "Dec": {ESLVal $1002 = _v130.termRef(0);
                  ESLVal $1001 = _v130.termRef(1);
                  ESLVal $1000 = _v130.termRef(2);
                  ESLVal $999 = _v130.termRef(3);
                  
                  {ESLVal _v142 = $1002;
                  
                  {ESLVal n = $1001;
                  
                  {ESLVal _v143 = $1000;
                  
                  {ESLVal dt = $999;
                  
                  return ESLVal.list(ESLVal.list(_v143));
                }
                }
                }
                }
                }
                default: {ESLVal _0 = _v130;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten(),fv);
        }
        }
        }
      case "RecType": {ESLVal $952 = _v127.termRef(0);
          ESLVal $951 = _v127.termRef(1);
          ESLVal $950 = _v127.termRef(2);
          
          {ESLVal l = $952;
          
          {ESLVal a = $951;
          
          {ESLVal _v139 = $950;
          
          return filter.apply(new ESLVal(new Function(new ESLVal("fun234"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v140 = $args[0];
          {ESLVal _v129 = _v140;
                
                switch(_v129.termName) {
                case "VarType": {ESLVal $998 = _v129.termRef(0);
                  ESLVal $997 = _v129.termRef(1);
                  
                  {ESLVal _v141 = $998;
                  
                  {ESLVal n = $997;
                  
                  return n.eql(a).not();
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(78869,78917)").add(ESLVal.list(_v129)));
              }
              }
            }
          }),typeFV1.apply(_v139,$nil)).add(fv);
        }
        }
        }
        }
      case "StrType": {ESLVal $949 = _v127.termRef(0);
          
          {ESLVal l = $949;
          
          return fv;
        }
        }
      case "TableType": {ESLVal $948 = _v127.termRef(0);
          ESLVal $947 = _v127.termRef(1);
          ESLVal $946 = _v127.termRef(2);
          
          {ESLVal l = $948;
          
          {ESLVal k = $947;
          
          {ESLVal v = $946;
          
          return typeFV1.apply(k,typeFV1.apply(v,fv));
        }
        }
        }
        }
      case "TypeClosure": {ESLVal $945 = _v127.termRef(0);
          
          {ESLVal f = $945;
          
          return $nil;
        }
        }
      case "TermType": {ESLVal $944 = _v127.termRef(0);
          ESLVal $943 = _v127.termRef(1);
          ESLVal $942 = _v127.termRef(2);
          
          {ESLVal l = $944;
          
          {ESLVal n = $943;
          
          {ESLVal ts = $942;
          
          return typesFV1.apply(ts,fv);
        }
        }
        }
        }
      case "TypeFun": {ESLVal $941 = _v127.termRef(0);
          ESLVal $940 = _v127.termRef(1);
          ESLVal $939 = _v127.termRef(2);
          
          {ESLVal l = $941;
          
          {ESLVal ns = $940;
          
          {ESLVal _v136 = $939;
          
          return filter.apply(new ESLVal(new Function(new ESLVal("fun235"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v137 = $args[0];
          {ESLVal _v128 = _v137;
                
                switch(_v128.termName) {
                case "VarType": {ESLVal $996 = _v128.termRef(0);
                  ESLVal $995 = _v128.termRef(1);
                  
                  {ESLVal _v138 = $996;
                  
                  {ESLVal n = $995;
                  
                  return member.apply(n,ns).not();
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(79213,79273)").add(ESLVal.list(_v128)));
              }
              }
            }
          }),typeFV1.apply(_v136,$nil)).add(fv);
        }
        }
        }
        }
      case "UnfoldType": {ESLVal $938 = _v127.termRef(0);
          ESLVal $937 = _v127.termRef(1);
          
          {ESLVal l = $938;
          
          {ESLVal _v135 = $937;
          
          return typeFV1.apply(_v135,fv);
        }
        }
        }
      case "UnionType": {ESLVal $936 = _v127.termRef(0);
          ESLVal $935 = _v127.termRef(1);
          
          {ESLVal l = $936;
          
          {ESLVal ts = $935;
          
          return typesFV1.apply(ts,fv);
        }
        }
        }
      case "VarType": {ESLVal $934 = _v127.termRef(0);
          ESLVal $933 = _v127.termRef(1);
          
          {ESLVal l = $934;
          
          {ESLVal n = $933;
          
          return fv.cons(t);
        }
        }
        }
      case "VoidType": {ESLVal $932 = _v127.termRef(0);
          
          {ESLVal l = $932;
          
          return fv;
        }
        }
      case "UnionRef": {ESLVal $931 = _v127.termRef(0);
          ESLVal $930 = _v127.termRef(1);
          ESLVal $929 = _v127.termRef(2);
          
          {ESLVal l = $931;
          
          {ESLVal _v134 = $930;
          
          {ESLVal n = $929;
          
          return typeFV1.apply(_v134,fv);
        }
        }
        }
        }
        default: {ESLVal x = _v127;
          
          return error(x);
        }
      }
      }
    }
  });
  public static ESLVal main = new ESLVal(new Function(new ESLVal("main"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      return new ESLVal(new BehaviourAdapter(false,getSelf(),new ESLVal("main")) {
          
          public ESLVal handle(ESLVal $m) {{ESLVal _v133 = $m;
            
            return error(new ESLVal("case error at Pos(0,0)").add(ESLVal.list(_v133)));
          }}
          public ESLVal get(String name) {
            switch(name) {
              
              default: throw new Error("ref illegal " + self + "." + name);
            }
          }
        public void handleTime(ESLVal $t) {
          {}
        }
        public ESLVal init() {
            return ((Supplier<ESLVal>)() -> { 
                {new Function(new ESLVal("try"),getSelf()) {
                  public ESLVal apply(ESLVal... args) { 
                    try { 
                      return typeCheckModule.apply(new ESLVal("esl/compiler/test1.esl"));
                    } catch(ESLError $exception) {
                      ESLVal $x = $exception.value;
                      {ESLVal _v132 = $x;
                  
                  {ESLVal message = _v132;
                  
                  return print.apply(new ESLVal("Type Error: ").add(message));
                }
                }
                    }
                  }
                }.apply();
                print.apply(new ESLVal("DONE"));
                return stopAll.apply();}
              }).get();
          }
        });
    }
  });
public static void main(String[] args) {
    newActor(main,new ESLVal(new Actor())); 
  }
}