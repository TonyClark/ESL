package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
// import static esl.Lists.*;
import static esl.compiler.Types.*;
import static esl.compiler.PpExp.*;
import java.util.function.Supplier;
public class Cases {
  public static ESLVal getSelf() { return $null; }
  private static ESLVal newVar() {
    
    {varCounter = varCounter.add($one);
    return new ESLVal("$").add(varCounter);}
  }
  private static ESLVal newVar = new ESLVal(new Function(new ESLVal("newVar"),null) { public ESLVal apply(ESLVal... args) { return newVar(); }});
  private static ESLVal translateArms(ESLVal as) {
    
    {ESLVal _v1861 = as;
      
      if(_v1861.isCons())
      {ESLVal $3570 = _v1861.head();
        ESLVal $3571 = _v1861.tail();
        
        switch($3570.termName) {
        case "BArm": {ESLVal $3575 = $3570.termRef(0);
          ESLVal $3574 = $3570.termRef(1);
          ESLVal $3573 = $3570.termRef(2);
          ESLVal $3572 = $3570.termRef(3);
          
          {ESLVal l = $3575;
          
          {ESLVal ps = $3574;
          
          {ESLVal g = $3573;
          
          {ESLVal e = $3572;
          
          {ESLVal _v1927 = $3571;
          
          return translateArms(_v1927).cons(new ESLVal("LArm",l,ps,$nil,g,e));
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(1889,2030)").add(ESLVal.list(_v1861)));
      }
      }
    else if(_v1861.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(1889,2030)").add(ESLVal.list(_v1861)));
    }
  }
  private static ESLVal translateArms = new ESLVal(new Function(new ESLVal("translateArms"),null) { public ESLVal apply(ESLVal... args) { return translateArms(args[0]); }});
  private static ESLVal newVars(ESLVal n) {
    
    if(n.eql($zero).boolVal)
      return ESLVal.list();
      else
        return newVars(n.sub($one)).cons(newVar());
  }
  private static ESLVal newVars = new ESLVal(new Function(new ESLVal("newVars"),null) { public ESLVal apply(ESLVal... args) { return newVars(args[0]); }});
  public static ESLVal translateCases(ESLVal exp) {
    
    {ESLVal _v1862 = exp;
      
      switch(_v1862.termName) {
      case "Module": {ESLVal $3697 = _v1862.termRef(0);
        ESLVal $3696 = _v1862.termRef(1);
        ESLVal $3695 = _v1862.termRef(2);
        ESLVal $3694 = _v1862.termRef(3);
        ESLVal $3693 = _v1862.termRef(4);
        ESLVal $3692 = _v1862.termRef(5);
        ESLVal $3691 = _v1862.termRef(6);
        
        {ESLVal path = $3697;
        
        {ESLVal name = $3696;
        
        {ESLVal exports = $3695;
        
        {ESLVal imports = $3694;
        
        {ESLVal x = $3693;
        
        {ESLVal y = $3692;
        
        {ESLVal defs = $3691;
        
        return new ESLVal("Module",path,name,exports,imports,x,y,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal d = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateDef(d));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(mergeFunDefs.apply(defs)));
      }
      }
      }
      }
      }
      }
      }
      }
    case "FunExp": {ESLVal $3690 = _v1862.termRef(0);
        ESLVal $3689 = _v1862.termRef(1);
        ESLVal $3688 = _v1862.termRef(2);
        ESLVal $3687 = _v1862.termRef(3);
        ESLVal $3686 = _v1862.termRef(4);
        
        {ESLVal l = $3690;
        
        {ESLVal n = $3689;
        
        {ESLVal args = $3688;
        
        {ESLVal t = $3687;
        
        {ESLVal e = $3686;
        
        return new ESLVal("FunExp",l,n,args,t,translateCases(e));
      }
      }
      }
      }
      }
      }
    case "StrExp": {ESLVal $3685 = _v1862.termRef(0);
        ESLVal $3684 = _v1862.termRef(1);
        
        {ESLVal l = $3685;
        
        {ESLVal v = $3684;
        
        return exp;
      }
      }
      }
    case "IntExp": {ESLVal $3683 = _v1862.termRef(0);
        ESLVal $3682 = _v1862.termRef(1);
        
        {ESLVal l = $3683;
        
        {ESLVal v = $3682;
        
        return exp;
      }
      }
      }
    case "BoolExp": {ESLVal $3681 = _v1862.termRef(0);
        ESLVal $3680 = _v1862.termRef(1);
        
        {ESLVal l = $3681;
        
        {ESLVal v = $3680;
        
        return exp;
      }
      }
      }
    case "BagExp": {ESLVal $3679 = _v1862.termRef(0);
        ESLVal $3678 = _v1862.termRef(1);
        
        {ESLVal l = $3679;
        
        {ESLVal es = $3678;
        
        return new ESLVal("BagExp",l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateCases(e));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(es));
      }
      }
      }
    case "NullExp": {ESLVal $3677 = _v1862.termRef(0);
        
        {ESLVal l = $3677;
        
        return exp;
      }
      }
    case "FloatExp": {ESLVal $3676 = _v1862.termRef(0);
        ESLVal $3675 = _v1862.termRef(1);
        
        {ESLVal l = $3676;
        
        {ESLVal f = $3675;
        
        return exp;
      }
      }
      }
    case "Term": {ESLVal $3674 = _v1862.termRef(0);
        ESLVal $3673 = _v1862.termRef(1);
        ESLVal $3672 = _v1862.termRef(2);
        ESLVal $3671 = _v1862.termRef(3);
        
        {ESLVal l = $3674;
        
        {ESLVal n = $3673;
        
        {ESLVal ts = $3672;
        
        {ESLVal es = $3671;
        
        return new ESLVal("Term",l,n,ts,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateCases(e));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(es));
      }
      }
      }
      }
      }
    case "List": {ESLVal $3670 = _v1862.termRef(0);
        ESLVal $3669 = _v1862.termRef(1);
        
        {ESLVal l = $3670;
        
        {ESLVal es = $3669;
        
        return new ESLVal("List",l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateCases(e));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(es));
      }
      }
      }
    case "Block": {ESLVal $3668 = _v1862.termRef(0);
        ESLVal $3667 = _v1862.termRef(1);
        
        {ESLVal l = $3668;
        
        {ESLVal es = $3667;
        
        return new ESLVal("Block",l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateCases(e));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(es));
      }
      }
      }
    case "Apply": {ESLVal $3666 = _v1862.termRef(0);
        ESLVal $3665 = _v1862.termRef(1);
        ESLVal $3664 = _v1862.termRef(2);
        
        {ESLVal l = $3666;
        
        {ESLVal op = $3665;
        
        {ESLVal args = $3664;
        
        return new ESLVal("Apply",l,translateCases(op),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateCases(e));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(args));
      }
      }
      }
      }
    case "ApplyTypeExp": {ESLVal $3663 = _v1862.termRef(0);
        ESLVal $3662 = _v1862.termRef(1);
        ESLVal $3661 = _v1862.termRef(2);
        
        {ESLVal l = $3663;
        
        {ESLVal op = $3662;
        
        {ESLVal args = $3661;
        
        return new ESLVal("ApplyTypeExp",l,translateCases(op),args);
      }
      }
      }
      }
    case "Case": {ESLVal $3660 = _v1862.termRef(0);
        ESLVal $3659 = _v1862.termRef(1);
        ESLVal $3658 = _v1862.termRef(2);
        ESLVal $3657 = _v1862.termRef(3);
        
        {ESLVal l = $3660;
        
        {ESLVal ds = $3659;
        
        {ESLVal es = $3658;
        
        {ESLVal as = $3657;
        
        return compileCase(l,es,translateArms(as),new ESLVal("CaseError",l,new ESLVal("List",l,es)));
      }
      }
      }
      }
      }
    case "BinExp": {ESLVal $3656 = _v1862.termRef(0);
        ESLVal $3655 = _v1862.termRef(1);
        ESLVal $3654 = _v1862.termRef(2);
        ESLVal $3653 = _v1862.termRef(3);
        
        {ESLVal l = $3656;
        
        {ESLVal e1 = $3655;
        
        {ESLVal op = $3654;
        
        {ESLVal e2 = $3653;
        
        return new ESLVal("BinExp",l,translateCases(e1),op,translateCases(e2));
      }
      }
      }
      }
      }
    case "For": {ESLVal $3652 = _v1862.termRef(0);
        ESLVal $3651 = _v1862.termRef(1);
        ESLVal $3650 = _v1862.termRef(2);
        ESLVal $3649 = _v1862.termRef(3);
        
        {ESLVal l = $3652;
        
        {ESLVal p = $3651;
        
        {ESLVal e1 = $3650;
        
        {ESLVal e2 = $3649;
        
        return new ESLVal("For",l,p,translateCases(e1),translateCases(e2));
      }
      }
      }
      }
      }
    case "Throw": {ESLVal $3648 = _v1862.termRef(0);
        ESLVal $3647 = _v1862.termRef(1);
        ESLVal $3646 = _v1862.termRef(2);
        
        {ESLVal l = $3648;
        
        {ESLVal t = $3647;
        
        {ESLVal e = $3646;
        
        return new ESLVal("Throw",l,t,translateCases(e));
      }
      }
      }
      }
    case "Try": {ESLVal $3645 = _v1862.termRef(0);
        ESLVal $3644 = _v1862.termRef(1);
        ESLVal $3643 = _v1862.termRef(2);
        
        {ESLVal l = $3645;
        
        {ESLVal e = $3644;
        
        {ESLVal as = $3643;
        
        return new ESLVal("Try",l,translateCases(e),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal a = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateArm(a));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(as));
      }
      }
      }
      }
    case "ActExp": {ESLVal $3642 = _v1862.termRef(0);
        ESLVal $3641 = _v1862.termRef(1);
        ESLVal $3640 = _v1862.termRef(2);
        ESLVal $3639 = _v1862.termRef(3);
        ESLVal $3638 = _v1862.termRef(4);
        ESLVal $3637 = _v1862.termRef(5);
        ESLVal $3636 = _v1862.termRef(6);
        ESLVal $3635 = _v1862.termRef(7);
        
        {ESLVal l = $3642;
        
        {ESLVal n = $3641;
        
        {ESLVal args = $3640;
        
        {ESLVal x = $3639;
        
        {ESLVal spec = $3638;
        
        {ESLVal locals = $3637;
        
        {ESLVal init = $3636;
        
        {ESLVal handlers = $3635;
        
        return new ESLVal("ActExp",l,n,args,x,spec,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateDef(b));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(locals),translateCases(init),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal h = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateArm(h));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(handlers));
      }
      }
      }
      }
      }
      }
      }
      }
      }
    case "If": {ESLVal $3634 = _v1862.termRef(0);
        ESLVal $3633 = _v1862.termRef(1);
        ESLVal $3632 = _v1862.termRef(2);
        ESLVal $3631 = _v1862.termRef(3);
        
        {ESLVal l = $3634;
        
        {ESLVal e1 = $3633;
        
        {ESLVal e2 = $3632;
        
        {ESLVal e3 = $3631;
        
        return new ESLVal("If",l,translateCases(e1),translateCases(e2),translateCases(e3));
      }
      }
      }
      }
      }
    case "Self": {ESLVal $3630 = _v1862.termRef(0);
        
        {ESLVal l = $3630;
        
        return exp;
      }
      }
    case "Update": {ESLVal $3629 = _v1862.termRef(0);
        ESLVal $3628 = _v1862.termRef(1);
        ESLVal $3627 = _v1862.termRef(2);
        
        {ESLVal l = $3629;
        
        {ESLVal n = $3628;
        
        {ESLVal e = $3627;
        
        return new ESLVal("Update",l,n,translateCases(e));
      }
      }
      }
      }
    case "Ref": {ESLVal $3626 = _v1862.termRef(0);
        ESLVal $3625 = _v1862.termRef(1);
        ESLVal $3624 = _v1862.termRef(2);
        
        {ESLVal l = $3626;
        
        {ESLVal e = $3625;
        
        {ESLVal n = $3624;
        
        return new ESLVal("Ref",l,translateCases(e),n);
      }
      }
      }
      }
    case "Var": {ESLVal $3623 = _v1862.termRef(0);
        ESLVal $3622 = _v1862.termRef(1);
        
        {ESLVal l = $3623;
        
        {ESLVal n = $3622;
        
        return exp;
      }
      }
      }
    case "Send": {ESLVal $3621 = _v1862.termRef(0);
        ESLVal $3620 = _v1862.termRef(1);
        ESLVal $3619 = _v1862.termRef(2);
        
        {ESLVal l = $3621;
        
        {ESLVal target = $3620;
        
        {ESLVal message = $3619;
        
        return new ESLVal("Send",l,translateCases(target),translateCases(message));
      }
      }
      }
      }
    case "SendTimeSuper": {ESLVal $3618 = _v1862.termRef(0);
        
        {ESLVal l = $3618;
        
        return new ESLVal("SendTimeSuper",l);
      }
      }
    case "SendSuper": {ESLVal $3617 = _v1862.termRef(0);
        ESLVal $3616 = _v1862.termRef(1);
        
        {ESLVal l = $3617;
        
        {ESLVal e = $3616;
        
        return new ESLVal("SendSuper",l,translateCases(e));
      }
      }
      }
    case "SetExp": {ESLVal $3615 = _v1862.termRef(0);
        ESLVal $3614 = _v1862.termRef(1);
        
        {ESLVal l = $3615;
        
        {ESLVal es = $3614;
        
        return new ESLVal("SetExp",l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateCases(e));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(es));
      }
      }
      }
    case "Cmp": {ESLVal $3613 = _v1862.termRef(0);
        ESLVal $3612 = _v1862.termRef(1);
        ESLVal $3611 = _v1862.termRef(2);
        
        {ESLVal l = $3613;
        
        {ESLVal e = $3612;
        
        {ESLVal qs = $3611;
        
        return new ESLVal("Cmp",l,translateCases(e),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal q = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateQual(q));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(qs));
      }
      }
      }
      }
    case "New": {ESLVal $3610 = _v1862.termRef(0);
        ESLVal $3609 = _v1862.termRef(1);
        ESLVal $3608 = _v1862.termRef(2);
        
        {ESLVal l = $3610;
        
        {ESLVal b = $3609;
        
        {ESLVal args = $3608;
        
        return new ESLVal("New",l,translateCases(b),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateCases(e));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(args));
      }
      }
      }
      }
    case "NewJava": {ESLVal $3607 = _v1862.termRef(0);
        ESLVal $3606 = _v1862.termRef(1);
        ESLVal $3605 = _v1862.termRef(2);
        ESLVal $3604 = _v1862.termRef(3);
        
        {ESLVal l = $3607;
        
        {ESLVal className = $3606;
        
        {ESLVal t = $3605;
        
        {ESLVal args = $3604;
        
        return new ESLVal("NewJava",l,className,t,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateCases(e));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(args));
      }
      }
      }
      }
      }
    case "Let": {ESLVal $3603 = _v1862.termRef(0);
        ESLVal $3602 = _v1862.termRef(1);
        ESLVal $3601 = _v1862.termRef(2);
        
        {ESLVal l = $3603;
        
        {ESLVal bs = $3602;
        
        {ESLVal e = $3601;
        
        return new ESLVal("Let",l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateDef(b));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(bs),translateCases(e));
      }
      }
      }
      }
    case "Letrec": {ESLVal $3600 = _v1862.termRef(0);
        ESLVal $3599 = _v1862.termRef(1);
        ESLVal $3598 = _v1862.termRef(2);
        
        {ESLVal l = $3600;
        
        {ESLVal bs = $3599;
        
        {ESLVal e = $3598;
        
        return new ESLVal("Letrec",l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateDef(b));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(bs),translateCases(e));
      }
      }
      }
      }
    case "Grab": {ESLVal $3597 = _v1862.termRef(0);
        ESLVal $3596 = _v1862.termRef(1);
        ESLVal $3595 = _v1862.termRef(2);
        
        {ESLVal l = $3597;
        
        {ESLVal rs = $3596;
        
        {ESLVal e = $3595;
        
        return new ESLVal("Grab",l,rs,translateCases(e));
      }
      }
      }
      }
    case "PLet": {ESLVal $3594 = _v1862.termRef(0);
        ESLVal $3593 = _v1862.termRef(1);
        ESLVal $3592 = _v1862.termRef(2);
        
        {ESLVal l = $3594;
        
        {ESLVal bs = $3593;
        
        {ESLVal e = $3592;
        
        return new ESLVal("PLet",l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateDef(b));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(bs),translateCases(e));
      }
      }
      }
      }
    case "Probably": {ESLVal $3591 = _v1862.termRef(0);
        ESLVal $3590 = _v1862.termRef(1);
        ESLVal $3589 = _v1862.termRef(2);
        ESLVal $3588 = _v1862.termRef(3);
        ESLVal $3587 = _v1862.termRef(4);
        
        {ESLVal l = $3591;
        
        {ESLVal p = $3590;
        
        {ESLVal t = $3589;
        
        {ESLVal e1 = $3588;
        
        {ESLVal e2 = $3587;
        
        return new ESLVal("Probably",l,translateCases(p),t,translateCases(e1),translateCases(e2));
      }
      }
      }
      }
      }
      }
    case "Not": {ESLVal $3586 = _v1862.termRef(0);
        ESLVal $3585 = _v1862.termRef(1);
        
        {ESLVal l = $3586;
        
        {ESLVal e = $3585;
        
        return new ESLVal("Not",l,translateCases(e));
      }
      }
      }
    case "Fold": {ESLVal $3584 = _v1862.termRef(0);
        ESLVal $3583 = _v1862.termRef(1);
        ESLVal $3582 = _v1862.termRef(2);
        
        {ESLVal l = $3584;
        
        {ESLVal t = $3583;
        
        {ESLVal e = $3582;
        
        return new ESLVal("Fold",l,t,translateCases(e));
      }
      }
      }
      }
    case "Unfold": {ESLVal $3581 = _v1862.termRef(0);
        ESLVal $3580 = _v1862.termRef(1);
        ESLVal $3579 = _v1862.termRef(2);
        
        {ESLVal l = $3581;
        
        {ESLVal t = $3580;
        
        {ESLVal e = $3579;
        
        return new ESLVal("Unfold",l,t,translateCases(e));
      }
      }
      }
      }
    case "Now": {ESLVal $3578 = _v1862.termRef(0);
        
        {ESLVal l = $3578;
        
        return exp;
      }
      }
    case "Become": {ESLVal $3577 = _v1862.termRef(0);
        ESLVal $3576 = _v1862.termRef(1);
        
        {ESLVal l = $3577;
        
        {ESLVal e = $3576;
        
        return new ESLVal("Become",l,translateCases(e));
      }
      }
      }
      default: {ESLVal x = _v1862;
        
        return error(exp);
      }
    }
    }
  }
  public static ESLVal translateCases = new ESLVal(new Function(new ESLVal("translateCases"),null) { public ESLVal apply(ESLVal... args) { return translateCases(args[0]); }});
  private static ESLVal armPatterns(ESLVal arm) {
    
    {ESLVal _v1863 = arm;
      
      switch(_v1863.termName) {
      case "LArm": {ESLVal $3702 = _v1863.termRef(0);
        ESLVal $3701 = _v1863.termRef(1);
        ESLVal $3700 = _v1863.termRef(2);
        ESLVal $3699 = _v1863.termRef(3);
        ESLVal $3698 = _v1863.termRef(4);
        
        {ESLVal l = $3702;
        
        {ESLVal ps = $3701;
        
        {ESLVal bs = $3700;
        
        {ESLVal g = $3699;
        
        {ESLVal e = $3698;
        
        return ps;
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(8442,8522)").add(ESLVal.list(_v1863)));
    }
    }
  }
  private static ESLVal armPatterns = new ESLVal(new Function(new ESLVal("armPatterns"),null) { public ESLVal apply(ESLVal... args) { return armPatterns(args[0]); }});
  private static ESLVal armBody(ESLVal arm) {
    
    {ESLVal _v1864 = arm;
      
      switch(_v1864.termName) {
      case "LArm": {ESLVal $3707 = _v1864.termRef(0);
        ESLVal $3706 = _v1864.termRef(1);
        ESLVal $3705 = _v1864.termRef(2);
        ESLVal $3704 = _v1864.termRef(3);
        ESLVal $3703 = _v1864.termRef(4);
        
        {ESLVal l = $3707;
        
        {ESLVal ps = $3706;
        
        {ESLVal bs = $3705;
        
        {ESLVal g = $3704;
        
        {ESLVal e = $3703;
        
        return e;
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(8551,8630)").add(ESLVal.list(_v1864)));
    }
    }
  }
  private static ESLVal armBody = new ESLVal(new Function(new ESLVal("armBody"),null) { public ESLVal apply(ESLVal... args) { return armBody(args[0]); }});
  private static ESLVal armGuard(ESLVal arm) {
    
    {ESLVal _v1865 = arm;
      
      switch(_v1865.termName) {
      case "LArm": {ESLVal $3712 = _v1865.termRef(0);
        ESLVal $3711 = _v1865.termRef(1);
        ESLVal $3710 = _v1865.termRef(2);
        ESLVal $3709 = _v1865.termRef(3);
        ESLVal $3708 = _v1865.termRef(4);
        
        {ESLVal l = $3712;
        
        {ESLVal ps = $3711;
        
        {ESLVal bs = $3710;
        
        {ESLVal g = $3709;
        
        {ESLVal e = $3708;
        
        return g;
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(8660,8739)").add(ESLVal.list(_v1865)));
    }
    }
  }
  private static ESLVal armGuard = new ESLVal(new Function(new ESLVal("armGuard"),null) { public ESLVal apply(ESLVal... args) { return armGuard(args[0]); }});
  private static ESLVal setArmBody(ESLVal arm,ESLVal e) {
    
    {ESLVal _v1866 = arm;
      
      switch(_v1866.termName) {
      case "LArm": {ESLVal $3717 = _v1866.termRef(0);
        ESLVal $3716 = _v1866.termRef(1);
        ESLVal $3715 = _v1866.termRef(2);
        ESLVal $3714 = _v1866.termRef(3);
        ESLVal $3713 = _v1866.termRef(4);
        
        {ESLVal l = $3717;
        
        {ESLVal ps = $3716;
        
        {ESLVal bs = $3715;
        
        {ESLVal g = $3714;
        
        {ESLVal old = $3713;
        
        return new ESLVal("LArm",l,ps,bs,g,e);
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(8778,8875)").add(ESLVal.list(_v1866)));
    }
    }
  }
  private static ESLVal setArmBody = new ESLVal(new Function(new ESLVal("setArmBody"),null) { public ESLVal apply(ESLVal... args) { return setArmBody(args[0],args[1]); }});
  private static ESLVal setArmPatterns(ESLVal arm,ESLVal ps) {
    
    {ESLVal _v1867 = arm;
      
      switch(_v1867.termName) {
      case "LArm": {ESLVal $3722 = _v1867.termRef(0);
        ESLVal $3721 = _v1867.termRef(1);
        ESLVal $3720 = _v1867.termRef(2);
        ESLVal $3719 = _v1867.termRef(3);
        ESLVal $3718 = _v1867.termRef(4);
        
        {ESLVal l = $3722;
        
        {ESLVal old = $3721;
        
        {ESLVal bs = $3720;
        
        {ESLVal g = $3719;
        
        {ESLVal e = $3718;
        
        return new ESLVal("LArm",l,ps,bs,g,e);
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(8925,9022)").add(ESLVal.list(_v1867)));
    }
    }
  }
  private static ESLVal setArmPatterns = new ESLVal(new Function(new ESLVal("setArmPatterns"),null) { public ESLVal apply(ESLVal... args) { return setArmPatterns(args[0],args[1]); }});
  private static ESLVal addArmBindings(ESLVal arm,ESLVal newBS) {
    
    {ESLVal _v1868 = arm;
      
      switch(_v1868.termName) {
      case "LArm": {ESLVal $3727 = _v1868.termRef(0);
        ESLVal $3726 = _v1868.termRef(1);
        ESLVal $3725 = _v1868.termRef(2);
        ESLVal $3724 = _v1868.termRef(3);
        ESLVal $3723 = _v1868.termRef(4);
        
        {ESLVal l = $3727;
        
        {ESLVal ps = $3726;
        
        {ESLVal bs = $3725;
        
        {ESLVal g = $3724;
        
        {ESLVal e = $3723;
        
        return new ESLVal("LArm",l,ps,bs.add(ESLVal.list(newBS)),g,e);
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(9073,9178)").add(ESLVal.list(_v1868)));
    }
    }
  }
  private static ESLVal addArmBindings = new ESLVal(new Function(new ESLVal("addArmBindings"),null) { public ESLVal apply(ESLVal... args) { return addArmBindings(args[0],args[1]); }});
  private static ESLVal isPVar(ESLVal p) {
    
    {ESLVal _v1869 = p;
      
      switch(_v1869.termName) {
      case "PVar": {ESLVal $3730 = _v1869.termRef(0);
        ESLVal $3729 = _v1869.termRef(1);
        ESLVal $3728 = _v1869.termRef(2);
        
        {ESLVal l = $3730;
        
        {ESLVal n = $3729;
        
        {ESLVal t = $3728;
        
        return $true;
      }
      }
      }
      }
      default: {ESLVal _v1926 = _v1869;
        
        return $false;
      }
    }
    }
  }
  private static ESLVal isPVar = new ESLVal(new Function(new ESLVal("isPVar"),null) { public ESLVal apply(ESLVal... args) { return isPVar(args[0]); }});
  private static ESLVal isPInt(ESLVal p) {
    
    {ESLVal _v1870 = p;
      
      switch(_v1870.termName) {
      case "PInt": {ESLVal $3732 = _v1870.termRef(0);
        ESLVal $3731 = _v1870.termRef(1);
        
        {ESLVal l = $3732;
        
        {ESLVal n = $3731;
        
        return $true;
      }
      }
      }
      default: {ESLVal _v1925 = _v1870;
        
        return $false;
      }
    }
    }
  }
  private static ESLVal isPInt = new ESLVal(new Function(new ESLVal("isPInt"),null) { public ESLVal apply(ESLVal... args) { return isPInt(args[0]); }});
  private static ESLVal isPStr(ESLVal p) {
    
    {ESLVal _v1871 = p;
      
      switch(_v1871.termName) {
      case "PStr": {ESLVal $3734 = _v1871.termRef(0);
        ESLVal $3733 = _v1871.termRef(1);
        
        {ESLVal l = $3734;
        
        {ESLVal n = $3733;
        
        return $true;
      }
      }
      }
      default: {ESLVal _v1924 = _v1871;
        
        return $false;
      }
    }
    }
  }
  private static ESLVal isPStr = new ESLVal(new Function(new ESLVal("isPStr"),null) { public ESLVal apply(ESLVal... args) { return isPStr(args[0]); }});
  private static ESLVal isPBool(ESLVal p) {
    
    {ESLVal _v1872 = p;
      
      switch(_v1872.termName) {
      case "PBool": {ESLVal $3736 = _v1872.termRef(0);
        ESLVal $3735 = _v1872.termRef(1);
        
        {ESLVal l = $3736;
        
        {ESLVal b = $3735;
        
        return $true;
      }
      }
      }
      default: {ESLVal _v1923 = _v1872;
        
        return $false;
      }
    }
    }
  }
  private static ESLVal isPBool = new ESLVal(new Function(new ESLVal("isPBool"),null) { public ESLVal apply(ESLVal... args) { return isPBool(args[0]); }});
  private static ESLVal isPTerm(ESLVal p) {
    
    {ESLVal _v1873 = p;
      
      switch(_v1873.termName) {
      case "PTerm": {ESLVal $3740 = _v1873.termRef(0);
        ESLVal $3739 = _v1873.termRef(1);
        ESLVal $3738 = _v1873.termRef(2);
        ESLVal $3737 = _v1873.termRef(3);
        
        {ESLVal l = $3740;
        
        {ESLVal n = $3739;
        
        {ESLVal ts = $3738;
        
        {ESLVal ps = $3737;
        
        return $true;
      }
      }
      }
      }
      }
      default: {ESLVal _v1922 = _v1873;
        
        return $false;
      }
    }
    }
  }
  private static ESLVal isPTerm = new ESLVal(new Function(new ESLVal("isPTerm"),null) { public ESLVal apply(ESLVal... args) { return isPTerm(args[0]); }});
  private static ESLVal isPCons(ESLVal p) {
    
    {ESLVal _v1874 = p;
      
      switch(_v1874.termName) {
      case "PCons": {ESLVal $3743 = _v1874.termRef(0);
        ESLVal $3742 = _v1874.termRef(1);
        ESLVal $3741 = _v1874.termRef(2);
        
        {ESLVal l = $3743;
        
        {ESLVal h = $3742;
        
        {ESLVal t = $3741;
        
        return $true;
      }
      }
      }
      }
      default: {ESLVal _v1921 = _v1874;
        
        return $false;
      }
    }
    }
  }
  private static ESLVal isPCons = new ESLVal(new Function(new ESLVal("isPCons"),null) { public ESLVal apply(ESLVal... args) { return isPCons(args[0]); }});
  private static ESLVal isPNil(ESLVal p) {
    
    {ESLVal _v1875 = p;
      
      switch(_v1875.termName) {
      case "PNil": {ESLVal $3748 = _v1875.termRef(0);
        
        {ESLVal l = $3748;
        
        return $true;
      }
      }
    case "PApplyType": {ESLVal $3746 = _v1875.termRef(0);
        ESLVal $3745 = _v1875.termRef(1);
        ESLVal $3744 = _v1875.termRef(2);
        
        switch($3745.termName) {
        case "PNil": {ESLVal $3747 = $3745.termRef(0);
          
          {ESLVal l1 = $3746;
          
          {ESLVal l2 = $3747;
          
          {ESLVal ts = $3744;
          
          return $true;
        }
        }
        }
        }
        default: {ESLVal _v1919 = _v1875;
          
          return $false;
        }
      }
      }
      default: {ESLVal _v1920 = _v1875;
        
        return $false;
      }
    }
    }
  }
  private static ESLVal isPNil = new ESLVal(new Function(new ESLVal("isPNil"),null) { public ESLVal apply(ESLVal... args) { return isPNil(args[0]); }});
  private static ESLVal isPList(ESLVal p) {
    
    return isPCons(p).or(isPNil(p));
  }
  private static ESLVal isPList = new ESLVal(new Function(new ESLVal("isPList"),null) { public ESLVal apply(ESLVal... args) { return isPList(args[0]); }});
  private static ESLVal isPNonDetList(ESLVal p) {
    
    return isPAdd(p);
  }
  private static ESLVal isPNonDetList = new ESLVal(new Function(new ESLVal("isPNonDetList"),null) { public ESLVal apply(ESLVal... args) { return isPNonDetList(args[0]); }});
  private static ESLVal isPSetCons(ESLVal p) {
    
    {ESLVal _v1876 = p;
      
      switch(_v1876.termName) {
      case "PSetCons": {ESLVal $3751 = _v1876.termRef(0);
        ESLVal $3750 = _v1876.termRef(1);
        ESLVal $3749 = _v1876.termRef(2);
        
        {ESLVal l = $3751;
        
        {ESLVal p1 = $3750;
        
        {ESLVal p2 = $3749;
        
        return $true;
      }
      }
      }
      }
      default: {ESLVal _v1918 = _v1876;
        
        return $false;
      }
    }
    }
  }
  private static ESLVal isPSetCons = new ESLVal(new Function(new ESLVal("isPSetCons"),null) { public ESLVal apply(ESLVal... args) { return isPSetCons(args[0]); }});
  private static ESLVal isPEmptySet(ESLVal p) {
    
    {ESLVal _v1877 = p;
      
      switch(_v1877.termName) {
      case "PEmptySet": {ESLVal $3752 = _v1877.termRef(0);
        
        {ESLVal l = $3752;
        
        return $true;
      }
      }
      default: {ESLVal _v1917 = _v1877;
        
        return $false;
      }
    }
    }
  }
  private static ESLVal isPEmptySet = new ESLVal(new Function(new ESLVal("isPEmptySet"),null) { public ESLVal apply(ESLVal... args) { return isPEmptySet(args[0]); }});
  private static ESLVal isPAdd(ESLVal p) {
    
    {ESLVal _v1878 = p;
      
      switch(_v1878.termName) {
      case "PAdd": {ESLVal $3755 = _v1878.termRef(0);
        ESLVal $3754 = _v1878.termRef(1);
        ESLVal $3753 = _v1878.termRef(2);
        
        {ESLVal l = $3755;
        
        {ESLVal p1 = $3754;
        
        {ESLVal p2 = $3753;
        
        return $true;
      }
      }
      }
      }
      default: {ESLVal _v1916 = _v1878;
        
        return $false;
      }
    }
    }
  }
  private static ESLVal isPAdd = new ESLVal(new Function(new ESLVal("isPAdd"),null) { public ESLVal apply(ESLVal... args) { return isPAdd(args[0]); }});
  private static ESLVal isPSet(ESLVal p) {
    
    return isPSetCons(p).or(isPEmptySet(p));
  }
  private static ESLVal isPSet = new ESLVal(new Function(new ESLVal("isPSet"),null) { public ESLVal apply(ESLVal... args) { return isPSet(args[0]); }});
  private static ESLVal pTermName(ESLVal p) {
    
    {ESLVal _v1879 = p;
      
      switch(_v1879.termName) {
      case "PTerm": {ESLVal $3759 = _v1879.termRef(0);
        ESLVal $3758 = _v1879.termRef(1);
        ESLVal $3757 = _v1879.termRef(2);
        ESLVal $3756 = _v1879.termRef(3);
        
        {ESLVal l = $3759;
        
        {ESLVal n = $3758;
        
        {ESLVal ts = $3757;
        
        {ESLVal ps = $3756;
        
        return n;
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(10558,10626)").add(ESLVal.list(_v1879)));
    }
    }
  }
  private static ESLVal pTermName = new ESLVal(new Function(new ESLVal("pTermName"),null) { public ESLVal apply(ESLVal... args) { return pTermName(args[0]); }});
  private static ESLVal pTermArgs(ESLVal p) {
    
    {ESLVal _v1880 = p;
      
      switch(_v1880.termName) {
      case "PTerm": {ESLVal $3763 = _v1880.termRef(0);
        ESLVal $3762 = _v1880.termRef(1);
        ESLVal $3761 = _v1880.termRef(2);
        ESLVal $3760 = _v1880.termRef(3);
        
        {ESLVal l = $3763;
        
        {ESLVal n = $3762;
        
        {ESLVal ts = $3761;
        
        {ESLVal ps = $3760;
        
        return ps;
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(10666,10735)").add(ESLVal.list(_v1880)));
    }
    }
  }
  private static ESLVal pTermArgs = new ESLVal(new Function(new ESLVal("pTermArgs"),null) { public ESLVal apply(ESLVal... args) { return pTermArgs(args[0]); }});
  private static ESLVal pVarName(ESLVal p) {
    
    {ESLVal _v1881 = p;
      
      switch(_v1881.termName) {
      case "PVar": {ESLVal $3766 = _v1881.termRef(0);
        ESLVal $3765 = _v1881.termRef(1);
        ESLVal $3764 = _v1881.termRef(2);
        
        {ESLVal l = $3766;
        
        {ESLVal n = $3765;
        
        {ESLVal t = $3764;
        
        return n;
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(10768,10818)").add(ESLVal.list(_v1881)));
    }
    }
  }
  private static ESLVal pVarName = new ESLVal(new Function(new ESLVal("pVarName"),null) { public ESLVal apply(ESLVal... args) { return pVarName(args[0]); }});
  private static ESLVal pConsHead(ESLVal p) {
    
    {ESLVal _v1882 = p;
      
      switch(_v1882.termName) {
      case "PCons": {ESLVal $3769 = _v1882.termRef(0);
        ESLVal $3768 = _v1882.termRef(1);
        ESLVal $3767 = _v1882.termRef(2);
        
        {ESLVal l = $3769;
        
        {ESLVal h = $3768;
        
        {ESLVal t = $3767;
        
        return h;
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(10856,10914)").add(ESLVal.list(_v1882)));
    }
    }
  }
  private static ESLVal pConsHead = new ESLVal(new Function(new ESLVal("pConsHead"),null) { public ESLVal apply(ESLVal... args) { return pConsHead(args[0]); }});
  private static ESLVal pConsTail(ESLVal p) {
    
    {ESLVal _v1883 = p;
      
      switch(_v1883.termName) {
      case "PCons": {ESLVal $3772 = _v1883.termRef(0);
        ESLVal $3771 = _v1883.termRef(1);
        ESLVal $3770 = _v1883.termRef(2);
        
        {ESLVal l = $3772;
        
        {ESLVal h = $3771;
        
        {ESLVal t = $3770;
        
        return t;
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(10952,11010)").add(ESLVal.list(_v1883)));
    }
    }
  }
  private static ESLVal pConsTail = new ESLVal(new Function(new ESLVal("pConsTail"),null) { public ESLVal apply(ESLVal... args) { return pConsTail(args[0]); }});
  private static ESLVal pSetConsHead(ESLVal p) {
    
    {ESLVal _v1884 = p;
      
      switch(_v1884.termName) {
      case "PSetCons": {ESLVal $3775 = _v1884.termRef(0);
        ESLVal $3774 = _v1884.termRef(1);
        ESLVal $3773 = _v1884.termRef(2);
        
        {ESLVal l = $3775;
        
        {ESLVal h = $3774;
        
        {ESLVal t = $3773;
        
        return h;
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(11051,11112)").add(ESLVal.list(_v1884)));
    }
    }
  }
  private static ESLVal pSetConsHead = new ESLVal(new Function(new ESLVal("pSetConsHead"),null) { public ESLVal apply(ESLVal... args) { return pSetConsHead(args[0]); }});
  private static ESLVal pSetConsTail(ESLVal p) {
    
    {ESLVal _v1885 = p;
      
      switch(_v1885.termName) {
      case "PSetCons": {ESLVal $3778 = _v1885.termRef(0);
        ESLVal $3777 = _v1885.termRef(1);
        ESLVal $3776 = _v1885.termRef(2);
        
        {ESLVal l = $3778;
        
        {ESLVal h = $3777;
        
        {ESLVal t = $3776;
        
        return t;
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(11153,11214)").add(ESLVal.list(_v1885)));
    }
    }
  }
  private static ESLVal pSetConsTail = new ESLVal(new Function(new ESLVal("pSetConsTail"),null) { public ESLVal apply(ESLVal... args) { return pSetConsTail(args[0]); }});
  private static ESLVal pAddLeft(ESLVal p) {
    
    {ESLVal _v1886 = p;
      
      switch(_v1886.termName) {
      case "PAdd": {ESLVal $3781 = _v1886.termRef(0);
        ESLVal $3780 = _v1886.termRef(1);
        ESLVal $3779 = _v1886.termRef(2);
        
        {ESLVal l = $3781;
        
        {ESLVal left = $3780;
        
        {ESLVal right = $3779;
        
        return left;
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(11250,11317)").add(ESLVal.list(_v1886)));
    }
    }
  }
  private static ESLVal pAddLeft = new ESLVal(new Function(new ESLVal("pAddLeft"),null) { public ESLVal apply(ESLVal... args) { return pAddLeft(args[0]); }});
  private static ESLVal pAddRight(ESLVal p) {
    
    {ESLVal _v1887 = p;
      
      switch(_v1887.termName) {
      case "PAdd": {ESLVal $3784 = _v1887.termRef(0);
        ESLVal $3783 = _v1887.termRef(1);
        ESLVal $3782 = _v1887.termRef(2);
        
        {ESLVal l = $3784;
        
        {ESLVal left = $3783;
        
        {ESLVal right = $3782;
        
        return right;
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(11354,11422)").add(ESLVal.list(_v1887)));
    }
    }
  }
  private static ESLVal pAddRight = new ESLVal(new Function(new ESLVal("pAddRight"),null) { public ESLVal apply(ESLVal... args) { return pAddRight(args[0]); }});
  private static ESLVal pIntValue(ESLVal p) {
    
    {ESLVal _v1888 = p;
      
      switch(_v1888.termName) {
      case "PInt": {ESLVal $3786 = _v1888.termRef(0);
        ESLVal $3785 = _v1888.termRef(1);
        
        {ESLVal l = $3786;
        
        {ESLVal n = $3785;
        
        return n;
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(11456,11498)").add(ESLVal.list(_v1888)));
    }
    }
  }
  private static ESLVal pIntValue = new ESLVal(new Function(new ESLVal("pIntValue"),null) { public ESLVal apply(ESLVal... args) { return pIntValue(args[0]); }});
  private static ESLVal pStrValue(ESLVal p) {
    
    {ESLVal _v1889 = p;
      
      switch(_v1889.termName) {
      case "PStr": {ESLVal $3788 = _v1889.termRef(0);
        ESLVal $3787 = _v1889.termRef(1);
        
        {ESLVal l = $3788;
        
        {ESLVal n = $3787;
        
        return n;
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(11532,11574)").add(ESLVal.list(_v1889)));
    }
    }
  }
  private static ESLVal pStrValue = new ESLVal(new Function(new ESLVal("pStrValue"),null) { public ESLVal apply(ESLVal... args) { return pStrValue(args[0]); }});
  private static ESLVal pBoolValue(ESLVal p) {
    
    {ESLVal _v1890 = p;
      
      switch(_v1890.termName) {
      case "PBool": {ESLVal $3790 = _v1890.termRef(0);
        ESLVal $3789 = _v1890.termRef(1);
        
        {ESLVal l = $3790;
        
        {ESLVal b = $3789;
        
        return b;
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(11610,11655)").add(ESLVal.list(_v1890)));
    }
    }
  }
  private static ESLVal pBoolValue = new ESLVal(new Function(new ESLVal("pBoolValue"),null) { public ESLVal apply(ESLVal... args) { return pBoolValue(args[0]); }});
  private static ESLVal isEmptyPatterns(ESLVal arms) {
    
    return forall.apply(new ESLVal(new Function(new ESLVal("fun419"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return length.apply(armPatterns(a)).eql($zero);
        }
      }),arms);
  }
  private static ESLVal isEmptyPatterns = new ESLVal(new Function(new ESLVal("isEmptyPatterns"),null) { public ESLVal apply(ESLVal... args) { return isEmptyPatterns(args[0]); }});
  private static ESLVal isFirstColumnVars(ESLVal arms) {
    
    return forall.apply(new ESLVal(new Function(new ESLVal("fun420"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPVar(head.apply(armPatterns(a)));
        }
      }),arms);
  }
  private static ESLVal isFirstColumnVars = new ESLVal(new Function(new ESLVal("isFirstColumnVars"),null) { public ESLVal apply(ESLVal... args) { return isFirstColumnVars(args[0]); }});
  private static ESLVal isFirstColumnInts(ESLVal arms) {
    
    return forall.apply(new ESLVal(new Function(new ESLVal("fun421"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPInt(head.apply(armPatterns(a)));
        }
      }),arms);
  }
  private static ESLVal isFirstColumnInts = new ESLVal(new Function(new ESLVal("isFirstColumnInts"),null) { public ESLVal apply(ESLVal... args) { return isFirstColumnInts(args[0]); }});
  private static ESLVal isFirstColumnStrs(ESLVal arms) {
    
    return forall.apply(new ESLVal(new Function(new ESLVal("fun422"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPStr(head.apply(armPatterns(a)));
        }
      }),arms);
  }
  private static ESLVal isFirstColumnStrs = new ESLVal(new Function(new ESLVal("isFirstColumnStrs"),null) { public ESLVal apply(ESLVal... args) { return isFirstColumnStrs(args[0]); }});
  private static ESLVal isFirstColumnBools(ESLVal arms) {
    
    return forall.apply(new ESLVal(new Function(new ESLVal("fun423"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPBool(head.apply(armPatterns(a)));
        }
      }),arms);
  }
  private static ESLVal isFirstColumnBools = new ESLVal(new Function(new ESLVal("isFirstColumnBools"),null) { public ESLVal apply(ESLVal... args) { return isFirstColumnBools(args[0]); }});
  private static ESLVal isFirstColumnCnstrs(ESLVal arms) {
    
    return forall.apply(new ESLVal(new Function(new ESLVal("fun424"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPTerm(head.apply(armPatterns(a)));
        }
      }),arms);
  }
  private static ESLVal isFirstColumnCnstrs = new ESLVal(new Function(new ESLVal("isFirstColumnCnstrs"),null) { public ESLVal apply(ESLVal... args) { return isFirstColumnCnstrs(args[0]); }});
  private static ESLVal isFirstColumnSets(ESLVal arms) {
    
    return forall.apply(new ESLVal(new Function(new ESLVal("fun425"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPSet(head.apply(armPatterns(a)));
        }
      }),arms);
  }
  private static ESLVal isFirstColumnSets = new ESLVal(new Function(new ESLVal("isFirstColumnSets"),null) { public ESLVal apply(ESLVal... args) { return isFirstColumnSets(args[0]); }});
  private static ESLVal isFirstColumnNonDetLists(ESLVal arms) {
    
    return forall.apply(new ESLVal(new Function(new ESLVal("fun426"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPNonDetList(head.apply(armPatterns(a)));
        }
      }),arms);
  }
  private static ESLVal isFirstColumnNonDetLists = new ESLVal(new Function(new ESLVal("isFirstColumnNonDetLists"),null) { public ESLVal apply(ESLVal... args) { return isFirstColumnNonDetLists(args[0]); }});
  private static ESLVal isFirstColumnLists(ESLVal arms) {
    
    {ESLVal isList = new ESLVal(new Function(new ESLVal("isList"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPCons(head.apply(armPatterns(a))).or(isPNil(head.apply(armPatterns(a))));
          }
        });
      
      return forall.apply(isList,arms);
    }
  }
  private static ESLVal isFirstColumnLists = new ESLVal(new Function(new ESLVal("isFirstColumnLists"),null) { public ESLVal apply(ESLVal... args) { return isFirstColumnLists(args[0]); }});
  private static ESLVal dropPattern(ESLVal arm) {
    
    return setArmPatterns(arm,tail.apply(armPatterns(arm)));
  }
  private static ESLVal dropPattern = new ESLVal(new Function(new ESLVal("dropPattern"),null) { public ESLVal apply(ESLVal... args) { return dropPattern(args[0]); }});
  private static ESLVal firstVarNames(ESLVal arms) {
    
    return map.apply(new ESLVal(new Function(new ESLVal("fun427"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return pVarName(head.apply(armPatterns(a)));
        }
      }),arms);
  }
  private static ESLVal firstVarNames = new ESLVal(new Function(new ESLVal("firstVarNames"),null) { public ESLVal apply(ESLVal... args) { return firstVarNames(args[0]); }});
  private static ESLVal sharedCnstr(ESLVal arms) {
    
    return pTermName(head.apply(armPatterns(head.apply(arms))));
  }
  private static ESLVal sharedCnstr = new ESLVal(new Function(new ESLVal("sharedCnstr"),null) { public ESLVal apply(ESLVal... args) { return sharedCnstr(args[0]); }});
  private static ESLVal sharedInt(ESLVal arms) {
    
    return pIntValue(head.apply(armPatterns(head.apply(arms))));
  }
  private static ESLVal sharedInt = new ESLVal(new Function(new ESLVal("sharedInt"),null) { public ESLVal apply(ESLVal... args) { return sharedInt(args[0]); }});
  private static ESLVal sharedStr(ESLVal arms) {
    
    return pStrValue(head.apply(armPatterns(head.apply(arms))));
  }
  private static ESLVal sharedStr = new ESLVal(new Function(new ESLVal("sharedStr"),null) { public ESLVal apply(ESLVal... args) { return sharedStr(args[0]); }});
  private static ESLVal sharedBool(ESLVal arms) {
    
    return pBoolValue(head.apply(armPatterns(head.apply(arms))));
  }
  private static ESLVal sharedBool = new ESLVal(new Function(new ESLVal("sharedBool"),null) { public ESLVal apply(ESLVal... args) { return sharedBool(args[0]); }});
  private static ESLVal bindVarsBody(ESLVal e,ESLVal vNames) {
    
    return new ESLVal(new Function(new ESLVal("fun428"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal arms = $args[0];
      { LetRec letrec = new LetRec() {
            ESLVal bind = new ESLVal(new Function(new ESLVal("bind"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal _v1910 = $args[0];
              ESLVal _v1911 = $args[1];
              {ESLVal _v1891 = _v1910;
                    ESLVal _v1892 = _v1911;
                    
                    if(_v1891.isCons())
                    {ESLVal $3791 = _v1891.head();
                      ESLVal $3792 = _v1891.tail();
                      
                      if(_v1892.isCons())
                      {ESLVal $3793 = _v1892.head();
                        ESLVal $3794 = _v1892.tail();
                        
                        {ESLVal a = $3791;
                        
                        {ESLVal _v1912 = $3792;
                        
                        {ESLVal v = $3793;
                        
                        {ESLVal _v1913 = $3794;
                        
                        {ESLVal _v1893 = e;
                        
                        switch(_v1893.termName) {
                        case "Var": {ESLVal $3798 = _v1893.termRef(0);
                          ESLVal $3797 = _v1893.termRef(1);
                          
                          {ESLVal l = $3798;
                          
                          {ESLVal n = $3797;
                          
                          if(n.eql(v).boolVal)
                          return bind.apply(_v1912,_v1913).cons(a);
                          else
                            {ESLVal _v1914 = _v1893;
                              
                              return bind.apply(_v1912,_v1913).cons(addArmBindings(a,ESLVal.list(new ESLVal("Binding",loc0,v,voidType,voidType,_v1914))));
                            }
                        }
                        }
                        }
                        default: {ESLVal _v1915 = _v1893;
                          
                          return bind.apply(_v1912,_v1913).cons(addArmBindings(a,ESLVal.list(new ESLVal("Binding",loc0,v,voidType,voidType,_v1915))));
                        }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                    else if(_v1892.isNil())
                      return error(new ESLVal("case error at Pos(13825,14135)").add(ESLVal.list(_v1891,_v1892)));
                    else return error(new ESLVal("case error at Pos(13825,14135)").add(ESLVal.list(_v1891,_v1892)));
                    }
                  else if(_v1891.isNil())
                    if(_v1892.isCons())
                      {ESLVal $3795 = _v1892.head();
                        ESLVal $3796 = _v1892.tail();
                        
                        return error(new ESLVal("case error at Pos(13825,14135)").add(ESLVal.list(_v1891,_v1892)));
                      }
                    else if(_v1892.isNil())
                      return $nil;
                    else return error(new ESLVal("case error at Pos(13825,14135)").add(ESLVal.list(_v1891,_v1892)));
                  else return error(new ESLVal("case error at Pos(13825,14135)").add(ESLVal.list(_v1891,_v1892)));
                  }
                }
              });
            
            public ESLVal get(String name) {
              switch(name) {
                case "bind": return bind;
                
                default: throw new Error("cannot find letrec binding");
              }
              }
            };
          ESLVal bind = letrec.get("bind");
          
            return bind.apply(arms,vNames);}
          
        }
      });
  }
  private static ESLVal bindVarsBody = new ESLVal(new Function(new ESLVal("bindVarsBody"),null) { public ESLVal apply(ESLVal... args) { return bindVarsBody(args[0],args[1]); }});
  private static ESLVal bindVars(ESLVal e,ESLVal arms) {
    
    return bindVarsBody(e,firstVarNames(arms)).apply(map.apply(dropPattern,arms));
  }
  private static ESLVal bindVars = new ESLVal(new Function(new ESLVal("bindVars"),null) { public ESLVal apply(ESLVal... args) { return bindVars(args[0],args[1]); }});
  private static ESLVal cnstrArms(ESLVal c,ESLVal arms) {
    
    return filter.apply(new ESLVal(new Function(new ESLVal("fun429"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return pTermName(head.apply(armPatterns(a))).eql(c);
        }
      }),arms);
  }
  private static ESLVal cnstrArms = new ESLVal(new Function(new ESLVal("cnstrArms"),null) { public ESLVal apply(ESLVal... args) { return cnstrArms(args[0],args[1]); }});
  private static ESLVal intArms(ESLVal n,ESLVal arms) {
    
    return filter.apply(new ESLVal(new Function(new ESLVal("fun430"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return pIntValue(head.apply(armPatterns(a))).eql(n);
        }
      }),arms);
  }
  private static ESLVal intArms = new ESLVal(new Function(new ESLVal("intArms"),null) { public ESLVal apply(ESLVal... args) { return intArms(args[0],args[1]); }});
  private static ESLVal strArms(ESLVal s,ESLVal arms) {
    
    return filter.apply(new ESLVal(new Function(new ESLVal("fun431"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return pStrValue(head.apply(armPatterns(a))).eql(s);
        }
      }),arms);
  }
  private static ESLVal strArms = new ESLVal(new Function(new ESLVal("strArms"),null) { public ESLVal apply(ESLVal... args) { return strArms(args[0],args[1]); }});
  private static ESLVal boolArms(ESLVal b,ESLVal arms) {
    
    return filter.apply(new ESLVal(new Function(new ESLVal("fun432"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return pBoolValue(head.apply(armPatterns(a))).eql(b);
        }
      }),arms);
  }
  private static ESLVal boolArms = new ESLVal(new Function(new ESLVal("boolArms"),null) { public ESLVal apply(ESLVal... args) { return boolArms(args[0],args[1]); }});
  private static ESLVal fieldBindings(ESLVal e,ESLVal names) {
    
    return new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal n = $l0.head();
            $l0 = $l0.tail();
            $v.add(new ESLVal("Binding",loc0,n,voidType,voidType,new ESLVal("TermRef",e,indexOf.apply(n,names))));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(names);
  }
  private static ESLVal fieldBindings = new ESLVal(new Function(new ESLVal("fieldBindings"),null) { public ESLVal apply(ESLVal... args) { return fieldBindings(args[0],args[1]); }});
  private static ESLVal explodeCnstr(ESLVal a) {
    
    return setArmPatterns(a,pTermArgs(head.apply(armPatterns(a))).add(tail.apply(armPatterns(a))));
  }
  private static ESLVal explodeCnstr = new ESLVal(new Function(new ESLVal("explodeCnstr"),null) { public ESLVal apply(ESLVal... args) { return explodeCnstr(args[0]); }});
  private static ESLVal explodeCons(ESLVal a) {
    
    return setArmPatterns(a,ESLVal.list(pConsHead(head.apply(armPatterns(a))),pConsTail(head.apply(armPatterns(a)))).add(tail.apply(armPatterns(a))));
  }
  private static ESLVal explodeCons = new ESLVal(new Function(new ESLVal("explodeCons"),null) { public ESLVal apply(ESLVal... args) { return explodeCons(args[0]); }});
  private static ESLVal explodeSetCons(ESLVal a) {
    
    return setArmPatterns(a,ESLVal.list(pSetConsHead(head.apply(armPatterns(a))),pSetConsTail(head.apply(armPatterns(a)))).add(tail.apply(armPatterns(a))));
  }
  private static ESLVal explodeSetCons = new ESLVal(new Function(new ESLVal("explodeSetCons"),null) { public ESLVal apply(ESLVal... args) { return explodeSetCons(args[0]); }});
  private static ESLVal explodeAdd(ESLVal a) {
    
    return setArmPatterns(a,ESLVal.list(pAddLeft(head.apply(armPatterns(a))),pAddRight(head.apply(armPatterns(a)))).add(tail.apply(armPatterns(a))));
  }
  private static ESLVal explodeAdd = new ESLVal(new Function(new ESLVal("explodeAdd"),null) { public ESLVal apply(ESLVal... args) { return explodeAdd(args[0]); }});
  private static ESLVal cnstrArm(ESLVal l,ESLVal e,ESLVal es,ESLVal arms,ESLVal alt) {
    
    {ESLVal names = newVars(length.apply(pTermArgs(head.apply(armPatterns(head.apply(arms))))));
      
      return new ESLVal("Let",loc0,fieldBindings(e,names),compileCase(l,new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal n = $l0.head();
            $l0 = $l0.tail();
            $v.add(new ESLVal("Var",loc0,n));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(names).add(es),new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal a = $l0.head();
            $l0 = $l0.tail();
            $v.add(explodeCnstr(a));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(arms),alt));
    }
  }
  private static ESLVal cnstrArm = new ESLVal(new Function(new ESLVal("cnstrArm"),null) { public ESLVal apply(ESLVal... args) { return cnstrArm(args[0],args[1],args[2],args[3],args[4]); }});
  private static ESLVal processCnstrs(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    {ESLVal cnstrs = removeDups.apply(map.apply(pTermName,map.apply(head,map.apply(armPatterns,arms))));
      
      {ESLVal armss = map.apply(new ESLVal(new Function(new ESLVal("fun433"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal c = $args[0];
        return cnstrArms(c,arms);
          }
        }),cnstrs);
      
      return new ESLVal("CaseTerm",l,head.apply(es),createTArms(l,armss,es,alt),alt);
    }
    }
  }
  private static ESLVal processCnstrs = new ESLVal(new Function(new ESLVal("processCnstrs"),null) { public ESLVal apply(ESLVal... args) { return processCnstrs(args[0],args[1],args[2],args[3]); }});
  private static ESLVal createTArms(ESLVal l,ESLVal armss,ESLVal es,ESLVal alt) {
    
    {ESLVal _v1894 = armss;
      
      if(_v1894.isCons())
      {ESLVal $3799 = _v1894.head();
        ESLVal $3800 = _v1894.tail();
        
        {ESLVal as = $3799;
        
        {ESLVal _v1909 = $3800;
        
        return createTArms(l,_v1909,es,alt).cons(new ESLVal("TArm",sharedCnstr(as),cnstrArm(l,head.apply(es),tail.apply(es),as,alt)));
      }
      }
      }
    else if(_v1894.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(16496,16676)").add(ESLVal.list(_v1894)));
    }
  }
  private static ESLVal createTArms = new ESLVal(new Function(new ESLVal("createTArms"),null) { public ESLVal apply(ESLVal... args) { return createTArms(args[0],args[1],args[2],args[3]); }});
  private static ESLVal processConsArms(ESLVal loc,ESLVal es,ESLVal arms,ESLVal alt) {
    
    {ESLVal l = head.apply(es);
      ESLVal hn = newVar();
      ESLVal tn = newVar();
      
      {ESLVal hp = new ESLVal("PVar",loc0,hn,voidType);
      ESLVal tp = new ESLVal("PVar",loc0,tn,voidType);
      ESLVal hv = new ESLVal("Var",loc0,hn);
      ESLVal tv = new ESLVal("Var",loc0,tn);
      
      return new ESLVal("Let",loc0,ESLVal.list(new ESLVal("Binding",loc0,hn,voidType,voidType,new ESLVal("Head",l)),new ESLVal("Binding",loc0,tn,voidType,voidType,new ESLVal("Tail",l))),compileCase(loc,ESLVal.list(hv,tv).add(tail.apply(es)),new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal a = $l0.head();
            $l0 = $l0.tail();
            $v.add(explodeCons(a));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(arms),alt));
    }
    }
  }
  private static ESLVal processConsArms = new ESLVal(new Function(new ESLVal("processConsArms"),null) { public ESLVal apply(ESLVal... args) { return processConsArms(args[0],args[1],args[2],args[3]); }});
  private static ESLVal processLists(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    {ESLVal consArms = filter.apply(new ESLVal(new Function(new ESLVal("fun434"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPCons(head.apply(armPatterns(a)));
          }
        }),arms);
      ESLVal nilArms = map.apply(dropPattern,filter.apply(new ESLVal(new Function(new ESLVal("fun435"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPNil(head.apply(armPatterns(a)));
          }
        }),arms));
      
      return new ESLVal("CaseList",l,head.apply(es),processConsArms(l,es,consArms,alt),compileCase(l,tail.apply(es),nilArms,alt),alt);
    }
  }
  private static ESLVal processLists = new ESLVal(new Function(new ESLVal("processLists"),null) { public ESLVal apply(ESLVal... args) { return processLists(args[0],args[1],args[2],args[3]); }});
  private static ESLVal processSetArms(ESLVal l,ESLVal es,ESLVal arm) {
    
    {ESLVal _v1895 = head.apply(armPatterns(arm));
      
      switch(_v1895.termName) {
      case "PEmptySet": {ESLVal $3807 = _v1895.termRef(0);
        
        {ESLVal pl = $3807;
        
        {ESLVal fail = newVar();
        
        return new ESLVal("Term",l,new ESLVal("$empty"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("emptyset")),ESLVal.list(new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase(l,es,ESLVal.list(dropPattern(arm)),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
      }
      }
      }
    case "PSetCons": {ESLVal $3806 = _v1895.termRef(0);
        ESLVal $3805 = _v1895.termRef(1);
        ESLVal $3804 = _v1895.termRef(2);
        
        {ESLVal pl = $3806;
        
        {ESLVal p1 = $3805;
        
        {ESLVal p2 = $3804;
        
        {ESLVal fail = newVar();
        ESLVal element = newVar();
        ESLVal rest = newVar();
        
        return new ESLVal("Term",l,new ESLVal("$cons"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("setcons")),ESLVal.list(new ESLVal("Dec",l,element,$null,$null),new ESLVal("Dec",l,rest,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase(l,ESLVal.list(new ESLVal("Var",l,element),new ESLVal("Var",l,rest)).add(es),ESLVal.list(explodeSetCons(arm)),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
      }
      }
      }
      }
      }
    case "PAdd": {ESLVal $3803 = _v1895.termRef(0);
        ESLVal $3802 = _v1895.termRef(1);
        ESLVal $3801 = _v1895.termRef(2);
        
        {ESLVal pl = $3803;
        
        {ESLVal p1 = $3802;
        
        {ESLVal p2 = $3801;
        
        {ESLVal fail = newVar();
        ESLVal left = newVar();
        ESLVal right = newVar();
        
        return new ESLVal("Term",l,new ESLVal("$add"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("setadd")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,right)).add(es),ESLVal.list(explodeAdd(arm)),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(17621,18742)").add(ESLVal.list(_v1895)));
    }
    }
  }
  private static ESLVal processSetArms = new ESLVal(new Function(new ESLVal("processSetArms"),null) { public ESLVal apply(ESLVal... args) { return processSetArms(args[0],args[1],args[2]); }});
  private static ESLVal processNonDetListArms(ESLVal l,ESLVal es,ESLVal arm) {
    
    {ESLVal _v1896 = head.apply(armPatterns(arm));
      
      switch(_v1896.termName) {
      case "PNil": {ESLVal $3836 = _v1896.termRef(0);
        
        {ESLVal pl = $3836;
        
        {ESLVal fail = newVar();
        
        return new ESLVal("Term",l,new ESLVal("$empty"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("nil")),ESLVal.list(new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase(l,es,ESLVal.list(dropPattern(arm)),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
      }
      }
      }
    case "PCons": {ESLVal $3835 = _v1896.termRef(0);
        ESLVal $3834 = _v1896.termRef(1);
        ESLVal $3833 = _v1896.termRef(2);
        
        {ESLVal pl = $3835;
        
        {ESLVal p1 = $3834;
        
        {ESLVal p2 = $3833;
        
        {ESLVal fail = newVar();
        ESLVal element = newVar();
        ESLVal rest = newVar();
        
        return new ESLVal("Term",l,new ESLVal("$cons"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("cons")),ESLVal.list(new ESLVal("Dec",l,element,$null,$null),new ESLVal("Dec",l,rest,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase(l,ESLVal.list(new ESLVal("Var",l,element),new ESLVal("Var",l,rest)).add(es),ESLVal.list(explodeCons(arm)),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
      }
      }
      }
      }
      }
    case "PAdd": {ESLVal $3810 = _v1896.termRef(0);
        ESLVal $3809 = _v1896.termRef(1);
        ESLVal $3808 = _v1896.termRef(2);
        
        switch($3809.termName) {
        case "PCons": {ESLVal $3831 = $3809.termRef(0);
          ESLVal $3830 = $3809.termRef(1);
          ESLVal $3829 = $3809.termRef(2);
          
          switch($3829.termName) {
          case "PNil": {ESLVal $3832 = $3829.termRef(0);
            
            {ESLVal l1 = $3810;
            
            {ESLVal l2 = $3831;
            
            {ESLVal p1 = $3830;
            
            {ESLVal l3 = $3832;
            
            {ESLVal p2 = $3808;
            
            {ESLVal fail = newVar();
            ESLVal left = newVar();
            ESLVal right = newVar();
            ESLVal newArm = setArmPatterns(arm,ESLVal.list(p1,p2).add(tail.apply(armPatterns(arm))));
            
            return new ESLVal("Term",l,new ESLVal("$selectLeft"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
          }
          }
          }
          }
          }
          }
          }
          default: switch($3808.termName) {
            case "PCons": {ESLVal $3820 = $3808.termRef(0);
              ESLVal $3819 = $3808.termRef(1);
              ESLVal $3818 = $3808.termRef(2);
              
              switch($3818.termName) {
              case "PNil": {ESLVal $3821 = $3818.termRef(0);
                
                {ESLVal l1 = $3810;
                
                {ESLVal p1 = $3809;
                
                {ESLVal l2 = $3820;
                
                {ESLVal p2 = $3819;
                
                {ESLVal l3 = $3821;
                
                {ESLVal fail = newVar();
                ESLVal left = newVar();
                ESLVal right = newVar();
                ESLVal newArm = setArmPatterns(arm,ESLVal.list(p1,p2).add(tail.apply(armPatterns(arm))));
                
                return new ESLVal("Term",l,new ESLVal("$selectRight"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
              }
              }
              }
              }
              }
              }
              }
              default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1896)));
            }
            }
          case "PAdd": {ESLVal $3813 = $3808.termRef(0);
              ESLVal $3812 = $3808.termRef(1);
              ESLVal $3811 = $3808.termRef(2);
              
              switch($3812.termName) {
              case "PCons": {ESLVal $3816 = $3812.termRef(0);
                ESLVal $3815 = $3812.termRef(1);
                ESLVal $3814 = $3812.termRef(2);
                
                switch($3814.termName) {
                case "PNil": {ESLVal $3817 = $3814.termRef(0);
                  
                  {ESLVal l1 = $3810;
                  
                  {ESLVal p1 = $3809;
                  
                  {ESLVal l2 = $3813;
                  
                  {ESLVal l3 = $3816;
                  
                  {ESLVal p2 = $3815;
                  
                  {ESLVal l4 = $3817;
                  
                  {ESLVal p3 = $3811;
                  
                  {ESLVal fail = newVar();
                  ESLVal left = newVar();
                  ESLVal mid = newVar();
                  ESLVal right = newVar();
                  ESLVal newArm = setArmPatterns(arm,ESLVal.list(p1,p2,p3).add(tail.apply(armPatterns(arm))));
                  
                  return new ESLVal("Term",l,new ESLVal("$selectMid"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,mid,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,mid),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
                }
                }
                }
                }
                }
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1896)));
              }
              }
              default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1896)));
            }
            }
            default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1896)));
          }
        }
        }
      case "PAdd": {ESLVal $3824 = $3809.termRef(0);
          ESLVal $3823 = $3809.termRef(1);
          ESLVal $3822 = $3809.termRef(2);
          
          switch($3822.termName) {
          case "PCons": {ESLVal $3827 = $3822.termRef(0);
            ESLVal $3826 = $3822.termRef(1);
            ESLVal $3825 = $3822.termRef(2);
            
            switch($3825.termName) {
            case "PNil": {ESLVal $3828 = $3825.termRef(0);
              
              {ESLVal l1 = $3810;
              
              {ESLVal l2 = $3824;
              
              {ESLVal p1 = $3823;
              
              {ESLVal l3 = $3827;
              
              {ESLVal p2 = $3826;
              
              {ESLVal l4 = $3828;
              
              {ESLVal p3 = $3808;
              
              {ESLVal fail = newVar();
              ESLVal left = newVar();
              ESLVal mid = newVar();
              ESLVal right = newVar();
              ESLVal newArm = setArmPatterns(arm,ESLVal.list(p1,p2,p3).add(armPatterns(arm)));
              
              return new ESLVal("Term",l,new ESLVal("$selectMid"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,mid,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,mid),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
            }
            }
            }
            }
            }
            }
            }
            }
            }
            default: switch($3808.termName) {
              case "PCons": {ESLVal $3820 = $3808.termRef(0);
                ESLVal $3819 = $3808.termRef(1);
                ESLVal $3818 = $3808.termRef(2);
                
                switch($3818.termName) {
                case "PNil": {ESLVal $3821 = $3818.termRef(0);
                  
                  {ESLVal l1 = $3810;
                  
                  {ESLVal p1 = $3809;
                  
                  {ESLVal l2 = $3820;
                  
                  {ESLVal p2 = $3819;
                  
                  {ESLVal l3 = $3821;
                  
                  {ESLVal fail = newVar();
                  ESLVal left = newVar();
                  ESLVal right = newVar();
                  ESLVal newArm = setArmPatterns(arm,ESLVal.list(p1,p2).add(tail.apply(armPatterns(arm))));
                  
                  return new ESLVal("Term",l,new ESLVal("$selectRight"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
                }
                }
                }
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1896)));
              }
              }
            case "PAdd": {ESLVal $3813 = $3808.termRef(0);
                ESLVal $3812 = $3808.termRef(1);
                ESLVal $3811 = $3808.termRef(2);
                
                switch($3812.termName) {
                case "PCons": {ESLVal $3816 = $3812.termRef(0);
                  ESLVal $3815 = $3812.termRef(1);
                  ESLVal $3814 = $3812.termRef(2);
                  
                  switch($3814.termName) {
                  case "PNil": {ESLVal $3817 = $3814.termRef(0);
                    
                    {ESLVal l1 = $3810;
                    
                    {ESLVal p1 = $3809;
                    
                    {ESLVal l2 = $3813;
                    
                    {ESLVal l3 = $3816;
                    
                    {ESLVal p2 = $3815;
                    
                    {ESLVal l4 = $3817;
                    
                    {ESLVal p3 = $3811;
                    
                    {ESLVal fail = newVar();
                    ESLVal left = newVar();
                    ESLVal mid = newVar();
                    ESLVal right = newVar();
                    ESLVal newArm = setArmPatterns(arm,ESLVal.list(p1,p2,p3).add(tail.apply(armPatterns(arm))));
                    
                    return new ESLVal("Term",l,new ESLVal("$selectMid"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,mid,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,mid),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1896)));
                }
                }
                default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1896)));
              }
              }
              default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1896)));
            }
          }
          }
          default: switch($3808.termName) {
            case "PCons": {ESLVal $3820 = $3808.termRef(0);
              ESLVal $3819 = $3808.termRef(1);
              ESLVal $3818 = $3808.termRef(2);
              
              switch($3818.termName) {
              case "PNil": {ESLVal $3821 = $3818.termRef(0);
                
                {ESLVal l1 = $3810;
                
                {ESLVal p1 = $3809;
                
                {ESLVal l2 = $3820;
                
                {ESLVal p2 = $3819;
                
                {ESLVal l3 = $3821;
                
                {ESLVal fail = newVar();
                ESLVal left = newVar();
                ESLVal right = newVar();
                ESLVal newArm = setArmPatterns(arm,ESLVal.list(p1,p2).add(tail.apply(armPatterns(arm))));
                
                return new ESLVal("Term",l,new ESLVal("$selectRight"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
              }
              }
              }
              }
              }
              }
              }
              default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1896)));
            }
            }
          case "PAdd": {ESLVal $3813 = $3808.termRef(0);
              ESLVal $3812 = $3808.termRef(1);
              ESLVal $3811 = $3808.termRef(2);
              
              switch($3812.termName) {
              case "PCons": {ESLVal $3816 = $3812.termRef(0);
                ESLVal $3815 = $3812.termRef(1);
                ESLVal $3814 = $3812.termRef(2);
                
                switch($3814.termName) {
                case "PNil": {ESLVal $3817 = $3814.termRef(0);
                  
                  {ESLVal l1 = $3810;
                  
                  {ESLVal p1 = $3809;
                  
                  {ESLVal l2 = $3813;
                  
                  {ESLVal l3 = $3816;
                  
                  {ESLVal p2 = $3815;
                  
                  {ESLVal l4 = $3817;
                  
                  {ESLVal p3 = $3811;
                  
                  {ESLVal fail = newVar();
                  ESLVal left = newVar();
                  ESLVal mid = newVar();
                  ESLVal right = newVar();
                  ESLVal newArm = setArmPatterns(arm,ESLVal.list(p1,p2,p3).add(tail.apply(armPatterns(arm))));
                  
                  return new ESLVal("Term",l,new ESLVal("$selectMid"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,mid,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,mid),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
                }
                }
                }
                }
                }
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1896)));
              }
              }
              default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1896)));
            }
            }
            default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1896)));
          }
        }
        }
        default: switch($3808.termName) {
          case "PCons": {ESLVal $3820 = $3808.termRef(0);
            ESLVal $3819 = $3808.termRef(1);
            ESLVal $3818 = $3808.termRef(2);
            
            switch($3818.termName) {
            case "PNil": {ESLVal $3821 = $3818.termRef(0);
              
              {ESLVal l1 = $3810;
              
              {ESLVal p1 = $3809;
              
              {ESLVal l2 = $3820;
              
              {ESLVal p2 = $3819;
              
              {ESLVal l3 = $3821;
              
              {ESLVal fail = newVar();
              ESLVal left = newVar();
              ESLVal right = newVar();
              ESLVal newArm = setArmPatterns(arm,ESLVal.list(p1,p2).add(tail.apply(armPatterns(arm))));
              
              return new ESLVal("Term",l,new ESLVal("$selectRight"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
            }
            }
            }
            }
            }
            }
            }
            default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1896)));
          }
          }
        case "PAdd": {ESLVal $3813 = $3808.termRef(0);
            ESLVal $3812 = $3808.termRef(1);
            ESLVal $3811 = $3808.termRef(2);
            
            switch($3812.termName) {
            case "PCons": {ESLVal $3816 = $3812.termRef(0);
              ESLVal $3815 = $3812.termRef(1);
              ESLVal $3814 = $3812.termRef(2);
              
              switch($3814.termName) {
              case "PNil": {ESLVal $3817 = $3814.termRef(0);
                
                {ESLVal l1 = $3810;
                
                {ESLVal p1 = $3809;
                
                {ESLVal l2 = $3813;
                
                {ESLVal l3 = $3816;
                
                {ESLVal p2 = $3815;
                
                {ESLVal l4 = $3817;
                
                {ESLVal p3 = $3811;
                
                {ESLVal fail = newVar();
                ESLVal left = newVar();
                ESLVal mid = newVar();
                ESLVal right = newVar();
                ESLVal newArm = setArmPatterns(arm,ESLVal.list(p1,p2,p3).add(tail.apply(armPatterns(arm))));
                
                return new ESLVal("Term",l,new ESLVal("$selectMid"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,mid,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,mid),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
              }
              }
              }
              }
              }
              }
              }
              }
              }
              default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1896)));
            }
            }
            default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1896)));
          }
          }
          default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1896)));
        }
      }
      }
      default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1896)));
    }
    }
  }
  private static ESLVal processNonDetListArms = new ESLVal(new Function(new ESLVal("processNonDetListArms"),null) { public ESLVal apply(ESLVal... args) { return processNonDetListArms(args[0],args[1],args[2]); }});
  private static ESLVal processInts(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    {ESLVal ints = removeDups.apply(map.apply(pIntValue,map.apply(head,map.apply(armPatterns,arms))));
      
      {ESLVal armss = map.apply(new ESLVal(new Function(new ESLVal("fun436"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal c = $args[0];
        return intArms(c,arms);
          }
        }),ints);
      
      return new ESLVal("CaseInt",l,head.apply(es),new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal as = $l0.head();
            $l0 = $l0.tail();
            $v.add(new ESLVal("IArm",sharedInt(as),compileCase(l,tail.apply(es),new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal a = $l0.head();
            $l0 = $l0.tail();
            $v.add(dropPattern(a));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(as),alt)));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(armss),alt);
    }
    }
  }
  private static ESLVal processInts = new ESLVal(new Function(new ESLVal("processInts"),null) { public ESLVal apply(ESLVal... args) { return processInts(args[0],args[1],args[2],args[3]); }});
  private static ESLVal processStrs(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    {ESLVal strs = removeDups.apply(map.apply(pStrValue,map.apply(head,map.apply(armPatterns,arms))));
      
      {ESLVal armss = map.apply(new ESLVal(new Function(new ESLVal("fun437"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal c = $args[0];
        return strArms(c,arms);
          }
        }),strs);
      
      return new ESLVal("CaseStr",l,head.apply(es),new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal as = $l0.head();
            $l0 = $l0.tail();
            $v.add(new ESLVal("SArm",sharedStr(as),compileCase(l,tail.apply(es),new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal a = $l0.head();
            $l0 = $l0.tail();
            $v.add(dropPattern(a));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(as),alt)));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(armss),alt);
    }
    }
  }
  private static ESLVal processStrs = new ESLVal(new Function(new ESLVal("processStrs"),null) { public ESLVal apply(ESLVal... args) { return processStrs(args[0],args[1],args[2],args[3]); }});
  private static ESLVal processBools(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    {ESLVal bools = removeDups.apply(map.apply(pBoolValue,map.apply(head,map.apply(armPatterns,arms))));
      
      {ESLVal armss = map.apply(new ESLVal(new Function(new ESLVal("fun438"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal c = $args[0];
        return boolArms(c,arms);
          }
        }),bools);
      
      return new ESLVal("CaseBool",l,head.apply(es),new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal as = $l0.head();
            $l0 = $l0.tail();
            $v.add(new ESLVal("BoolArm",sharedBool(as),compileCase(l,tail.apply(es),new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal a = $l0.head();
            $l0 = $l0.tail();
            $v.add(dropPattern(a));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(as),alt)));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(armss),alt);
    }
    }
  }
  private static ESLVal processBools = new ESLVal(new Function(new ESLVal("processBools"),null) { public ESLVal apply(ESLVal... args) { return processBools(args[0],args[1],args[2],args[3]); }});
  private static ESLVal processSets(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    {ESLVal f = new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("setFail")),ESLVal.list(),$null,alt);
      
      return new ESLVal("CaseSet",l,head.apply(es),new ESLVal("List",l,new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal a = $l0.head();
            $l0 = $l0.tail();
            $v.add(processSetArms(l,tail.apply(es),a));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(arms)),f);
    }
  }
  private static ESLVal processSets = new ESLVal(new Function(new ESLVal("processSets"),null) { public ESLVal apply(ESLVal... args) { return processSets(args[0],args[1],args[2],args[3]); }});
  private static ESLVal processNonDetLists(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    {print.apply(new ESLVal("process nondet lists ").add(es.add(new ESLVal(" ").add(arms))));
    {ESLVal f = new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("listFail")),ESLVal.list(),$null,alt);
      
      return new ESLVal("CaseAdd",l,head.apply(es),new ESLVal("List",l,new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal a = $l0.head();
            $l0 = $l0.tail();
            $v.add(processNonDetListArms(l,tail.apply(es),a));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(arms)),f);
    }}
  }
  private static ESLVal processNonDetLists = new ESLVal(new Function(new ESLVal("processNonDetLists"),null) { public ESLVal apply(ESLVal... args) { return processNonDetLists(args[0],args[1],args[2],args[3]); }});
  private static ESLVal splitTerms(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    return compileCase(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun439"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPTerm(head.apply(armPatterns(a)));
        }
      }),arms),compileCase(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun440"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPTerm(head.apply(armPatterns(a)));
        }
      }),arms),alt));
  }
  private static ESLVal splitTerms = new ESLVal(new Function(new ESLVal("splitTerms"),null) { public ESLVal apply(ESLVal... args) { return splitTerms(args[0],args[1],args[2],args[3]); }});
  private static ESLVal splitLists(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    return compileCase(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun441"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPList(head.apply(armPatterns(a)));
        }
      }),arms),compileCase(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun442"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPList(head.apply(armPatterns(a)));
        }
      }),arms),alt));
  }
  private static ESLVal splitLists = new ESLVal(new Function(new ESLVal("splitLists"),null) { public ESLVal apply(ESLVal... args) { return splitLists(args[0],args[1],args[2],args[3]); }});
  private static ESLVal splitAdd(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    return compileCase(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun443"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPAdd(head.apply(armPatterns(a)));
        }
      }),arms),compileCase(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun444"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPAdd(head.apply(armPatterns(a)));
        }
      }),arms),alt));
  }
  private static ESLVal splitAdd = new ESLVal(new Function(new ESLVal("splitAdd"),null) { public ESLVal apply(ESLVal... args) { return splitAdd(args[0],args[1],args[2],args[3]); }});
  private static ESLVal splitSets(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    return compileCase(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun445"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPSet(head.apply(armPatterns(a)));
        }
      }),arms),compileCase(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun446"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPSet(head.apply(armPatterns(a)));
        }
      }),arms),alt));
  }
  private static ESLVal splitSets = new ESLVal(new Function(new ESLVal("splitSets"),null) { public ESLVal apply(ESLVal... args) { return splitSets(args[0],args[1],args[2],args[3]); }});
  private static ESLVal splitInts(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    return compileCase(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun447"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPInt(head.apply(armPatterns(a)));
        }
      }),arms),compileCase(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun448"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPInt(head.apply(armPatterns(a)));
        }
      }),arms),alt));
  }
  private static ESLVal splitInts = new ESLVal(new Function(new ESLVal("splitInts"),null) { public ESLVal apply(ESLVal... args) { return splitInts(args[0],args[1],args[2],args[3]); }});
  private static ESLVal splitStrs(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    return compileCase(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun449"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPStr(head.apply(armPatterns(a)));
        }
      }),arms),compileCase(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun450"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPStr(head.apply(armPatterns(a)));
        }
      }),arms),alt));
  }
  private static ESLVal splitStrs = new ESLVal(new Function(new ESLVal("splitStrs"),null) { public ESLVal apply(ESLVal... args) { return splitStrs(args[0],args[1],args[2],args[3]); }});
  private static ESLVal splitBools(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    return compileCase(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun451"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPBool(head.apply(armPatterns(a)));
        }
      }),arms),compileCase(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun452"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPBool(head.apply(armPatterns(a)));
        }
      }),arms),alt));
  }
  private static ESLVal splitBools = new ESLVal(new Function(new ESLVal("splitBools"),null) { public ESLVal apply(ESLVal... args) { return splitBools(args[0],args[1],args[2],args[3]); }});
  private static ESLVal splitVars(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    return compileCase(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun453"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPVar(head.apply(armPatterns(a)));
        }
      }),arms),compileCase(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun454"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPVar(head.apply(armPatterns(a)));
        }
      }),arms),alt));
  }
  private static ESLVal splitVars = new ESLVal(new Function(new ESLVal("splitVars"),null) { public ESLVal apply(ESLVal... args) { return splitVars(args[0],args[1],args[2],args[3]); }});
  private static ESLVal splitCase(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    {ESLVal firstPatterns = map.apply(head,map.apply(armPatterns,arms));
      
      {ESLVal nonVarPatterns = filter.apply(new ESLVal(new Function(new ESLVal("fun455"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal p = $args[0];
        return isPVar(p).not();
          }
        }),firstPatterns);
      
      if(isPTerm(head.apply(nonVarPatterns)).boolVal)
      return splitTerms(l,es,arms,alt);
      else
        if(isPList(head.apply(nonVarPatterns)).boolVal)
          return splitLists(l,es,arms,alt);
          else
            if(isPSet(head.apply(nonVarPatterns)).boolVal)
              return splitSets(l,es,arms,alt);
              else
                if(isPInt(head.apply(nonVarPatterns)).boolVal)
                  return splitInts(l,es,arms,alt);
                  else
                    if(isPStr(head.apply(nonVarPatterns)).boolVal)
                      return splitStrs(l,es,arms,alt);
                      else
                        if(isPBool(head.apply(nonVarPatterns)).boolVal)
                          return splitBools(l,es,arms,alt);
                          else
                            if(isPVar(head.apply(firstPatterns)).boolVal)
                              return splitVars(l,es,arms,alt);
                              else
                                if(isPAdd(head.apply(firstPatterns)).boolVal)
                                  return splitAdd(l,es,arms,alt);
                                  else
                                    return error(new ESLVal("unknown split case: ").add(arms));
    }
    }
  }
  private static ESLVal splitCase = new ESLVal(new Function(new ESLVal("splitCase"),null) { public ESLVal apply(ESLVal... args) { return splitCase(args[0],args[1],args[2],args[3]); }});
  private static ESLVal compileCase(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    if(arms.eql($nil).boolVal)
      return alt;
      else
        if(isEmptyPatterns(arms).boolVal)
          return foldArms(l,arms,alt);
          else
            if(isFirstColumnVars(arms).boolVal)
              return compileCase(l,tail.apply(es),bindVars(head.apply(es),arms),alt);
              else
                if(isFirstColumnCnstrs(arms).boolVal)
                  return processCnstrs(l,es,arms,alt);
                  else
                    if(isFirstColumnLists(arms).boolVal)
                      return processLists(l,es,arms,alt);
                      else
                        if(isFirstColumnInts(arms).boolVal)
                          return processInts(l,es,arms,alt);
                          else
                            if(isFirstColumnBools(arms).boolVal)
                              return processBools(l,es,arms,alt);
                              else
                                if(isFirstColumnStrs(arms).boolVal)
                                  return processStrs(l,es,arms,alt);
                                  else
                                    if(isFirstColumnSets(arms).boolVal)
                                      return processSets(l,es,arms,alt);
                                      else
                                        if(isFirstColumnNonDetLists(arms).boolVal)
                                          return processNonDetLists(l,es,arms,alt);
                                          else
                                            return splitCase(l,es,arms,alt);
  }
  private static ESLVal compileCase = new ESLVal(new Function(new ESLVal("compileCase"),null) { public ESLVal apply(ESLVal... args) { return compileCase(args[0],args[1],args[2],args[3]); }});
  private static ESLVal foldArms(ESLVal l,ESLVal arms,ESLVal alt) {
    
    {ESLVal _v1897 = arms;
      
      if(_v1897.isCons())
      {ESLVal $3837 = _v1897.head();
        ESLVal $3838 = _v1897.tail();
        
        switch($3837.termName) {
        case "LArm": {ESLVal $3843 = $3837.termRef(0);
          ESLVal $3842 = $3837.termRef(1);
          ESLVal $3841 = $3837.termRef(2);
          ESLVal $3840 = $3837.termRef(3);
          ESLVal $3839 = $3837.termRef(4);
          
          if($3842.isCons())
          {ESLVal $3844 = $3842.head();
            ESLVal $3845 = $3842.tail();
            
            return error(new ESLVal("case error at Pos(27421,27577)").add(ESLVal.list(_v1897)));
          }
        else if($3842.isNil())
          {ESLVal al = $3843;
            
            {ESLVal bs = $3841;
            
            {ESLVal g = $3840;
            
            {ESLVal e = $3839;
            
            {ESLVal _v1908 = $3838;
            
            return foldArm(al,bs,g,e,foldArms(l,_v1908,alt));
          }
          }
          }
          }
          }
        else return error(new ESLVal("case error at Pos(27421,27577)").add(ESLVal.list(_v1897)));
        }
        default: return error(new ESLVal("case error at Pos(27421,27577)").add(ESLVal.list(_v1897)));
      }
      }
    else if(_v1897.isNil())
      return alt;
    else return error(new ESLVal("case error at Pos(27421,27577)").add(ESLVal.list(_v1897)));
    }
  }
  private static ESLVal foldArms = new ESLVal(new Function(new ESLVal("foldArms"),null) { public ESLVal apply(ESLVal... args) { return foldArms(args[0],args[1],args[2]); }});
  private static ESLVal foldArm(ESLVal l,ESLVal bss,ESLVal g,ESLVal e,ESLVal alt) {
    
    {ESLVal _v1898 = bss;
      
      if(_v1898.isCons())
      {ESLVal $3846 = _v1898.head();
        ESLVal $3847 = _v1898.tail();
        
        {ESLVal bs = $3846;
        
        {ESLVal _v1905 = $3847;
        
        return new ESLVal("Let",l,bs,foldArm(l,_v1905,g,e,alt));
      }
      }
      }
    else if(_v1898.isNil())
      {ESLVal _v1899 = g;
        
        switch(_v1899.termName) {
        case "BoolExp": {ESLVal $3849 = _v1899.termRef(0);
          ESLVal $3848 = _v1899.termRef(1);
          
          switch($3848.boolVal ? 1 : 0) {
          case 1: {ESLVal bl = $3849;
            
            return e;
          }
          default: {ESLVal _v1906 = _v1899;
            
            return new ESLVal("If",l,_v1906,e,alt);
          }
        }
        }
        default: {ESLVal _v1907 = _v1899;
          
          return new ESLVal("If",l,_v1907,e,alt);
        }
      }
      }
    else return error(new ESLVal("case error at Pos(27642,27842)").add(ESLVal.list(_v1898)));
    }
  }
  private static ESLVal foldArm = new ESLVal(new Function(new ESLVal("foldArm"),null) { public ESLVal apply(ESLVal... args) { return foldArm(args[0],args[1],args[2],args[3],args[4]); }});
  private static ESLVal translateQual(ESLVal q) {
    
    {ESLVal _v1900 = q;
      
      switch(_v1900.termName) {
      case "BQual": {ESLVal $3854 = _v1900.termRef(0);
        ESLVal $3853 = _v1900.termRef(1);
        ESLVal $3852 = _v1900.termRef(2);
        
        {ESLVal l = $3854;
        
        {ESLVal p = $3853;
        
        {ESLVal e = $3852;
        
        return new ESLVal("BQual",l,p,translateCases(e));
      }
      }
      }
      }
    case "PQual": {ESLVal $3851 = _v1900.termRef(0);
        ESLVal $3850 = _v1900.termRef(1);
        
        {ESLVal l = $3851;
        
        {ESLVal p = $3850;
        
        return new ESLVal("PQual",l,translateCases(p));
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(27894,28031)").add(ESLVal.list(_v1900)));
    }
    }
  }
  private static ESLVal translateQual = new ESLVal(new Function(new ESLVal("translateQual"),null) { public ESLVal apply(ESLVal... args) { return translateQual(args[0]); }});
  private static ESLVal translateArm(ESLVal a) {
    
    {ESLVal _v1901 = a;
      
      switch(_v1901.termName) {
      case "LArm": {ESLVal $3859 = _v1901.termRef(0);
        ESLVal $3858 = _v1901.termRef(1);
        ESLVal $3857 = _v1901.termRef(2);
        ESLVal $3856 = _v1901.termRef(3);
        ESLVal $3855 = _v1901.termRef(4);
        
        {ESLVal l = $3859;
        
        {ESLVal ps = $3858;
        
        {ESLVal bs = $3857;
        
        {ESLVal guard = $3856;
        
        {ESLVal e = $3855;
        
        return new ESLVal("LArm",l,ps,bs,translateCases(guard),translateCases(e));
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(28070,28203)").add(ESLVal.list(_v1901)));
    }
    }
  }
  private static ESLVal translateArm = new ESLVal(new Function(new ESLVal("translateArm"),null) { public ESLVal apply(ESLVal... args) { return translateArm(args[0]); }});
  private static ESLVal translateDef(ESLVal b) {
    
    {ESLVal _v1902 = b;
      
      switch(_v1902.termName) {
      case "Binding": {ESLVal $3883 = _v1902.termRef(0);
        ESLVal $3882 = _v1902.termRef(1);
        ESLVal $3881 = _v1902.termRef(2);
        ESLVal $3880 = _v1902.termRef(3);
        ESLVal $3879 = _v1902.termRef(4);
        
        {ESLVal l = $3883;
        
        {ESLVal name = $3882;
        
        {ESLVal t = $3881;
        
        {ESLVal st = $3880;
        
        {ESLVal value = $3879;
        
        return new ESLVal("Binding",l,name,t,st,translateCases(value));
      }
      }
      }
      }
      }
      }
    case "TypeBind": {ESLVal $3878 = _v1902.termRef(0);
        ESLVal $3877 = _v1902.termRef(1);
        ESLVal $3876 = _v1902.termRef(2);
        ESLVal $3875 = _v1902.termRef(3);
        
        {ESLVal l = $3878;
        
        {ESLVal name = $3877;
        
        {ESLVal t = $3876;
        
        {ESLVal ignore = $3875;
        
        return b;
      }
      }
      }
      }
      }
    case "DataBind": {ESLVal $3874 = _v1902.termRef(0);
        ESLVal $3873 = _v1902.termRef(1);
        ESLVal $3872 = _v1902.termRef(2);
        ESLVal $3871 = _v1902.termRef(3);
        
        {ESLVal l = $3874;
        
        {ESLVal name = $3873;
        
        {ESLVal t = $3872;
        
        {ESLVal ignore = $3871;
        
        return b;
      }
      }
      }
      }
      }
    case "FunBind": {ESLVal $3870 = _v1902.termRef(0);
        ESLVal $3869 = _v1902.termRef(1);
        ESLVal $3868 = _v1902.termRef(2);
        ESLVal $3867 = _v1902.termRef(3);
        ESLVal $3866 = _v1902.termRef(4);
        ESLVal $3865 = _v1902.termRef(5);
        ESLVal $3864 = _v1902.termRef(6);
        
        {ESLVal l = $3870;
        
        {ESLVal n = $3869;
        
        {ESLVal args = $3868;
        
        {ESLVal t = $3867;
        
        {ESLVal st = $3866;
        
        {ESLVal body = $3865;
        
        {ESLVal guard = $3864;
        
        return new ESLVal("FunBind",l,n,args,t,st,translateCases(body),translateCases(guard));
      }
      }
      }
      }
      }
      }
      }
      }
    case "CnstrBind": {ESLVal $3863 = _v1902.termRef(0);
        ESLVal $3862 = _v1902.termRef(1);
        ESLVal $3861 = _v1902.termRef(2);
        ESLVal $3860 = _v1902.termRef(3);
        
        {ESLVal l = $3863;
        
        {ESLVal name = $3862;
        
        {ESLVal t = $3861;
        
        {ESLVal ignore = $3860;
        
        return b;
      }
      }
      }
      }
      }
      default: {ESLVal x = _v1902;
        
        return error(x);
      }
    }
    }
  }
  private static ESLVal translateDef = new ESLVal(new Function(new ESLVal("translateDef"),null) { public ESLVal apply(ESLVal... args) { return translateDef(args[0]); }});
  private static ESLVal pterm(ESLVal n,ESLVal ps) {
    
    return new ESLVal("PTerm",loc0,n,$nil,ps);
  }
  private static ESLVal pterm = new ESLVal(new Function(new ESLVal("pterm"),null) { public ESLVal apply(ESLVal... args) { return pterm(args[0],args[1]); }});
  private static ESLVal pvar(ESLVal n) {
    
    return new ESLVal("PVar",loc0,n,voidType);
  }
  private static ESLVal pvar = new ESLVal(new Function(new ESLVal("pvar"),null) { public ESLVal apply(ESLVal... args) { return pvar(args[0]); }});
  private static ESLVal var(ESLVal n) {
    
    return new ESLVal("Var",loc0,n);
  }
  private static ESLVal var = new ESLVal(new Function(new ESLVal("var"),null) { public ESLVal apply(ESLVal... args) { return var(args[0]); }});
  private static ESLVal pcons(ESLVal h,ESLVal t) {
    
    return new ESLVal("PCons",loc0,h,t);
  }
  private static ESLVal pcons = new ESLVal(new Function(new ESLVal("pcons"),null) { public ESLVal apply(ESLVal... args) { return pcons(args[0],args[1]); }});
private static ESLVal loc0 = new ESLVal("Pos",$zero,$zero);
  private static ESLVal voidType = new ESLVal("VoidType",loc0);
  private static ESLVal varCounter = $zero;
  private static ESLVal case0 = new ESLVal("Case",new ESLVal("Pos",$zero,$zero),$nil,ESLVal.list(new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("x")),new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("y"))),ESLVal.list(new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PVar",loc0,new ESLVal("xx"),voidType),new ESLVal("PVar",loc0,new ESLVal("yy"),voidType)),new ESLVal("BoolExp",loc0,$true),new ESLVal("Var",loc0,new ESLVal("OK")))));
  private static ESLVal case1 = new ESLVal("Case",new ESLVal("Pos",$zero,$zero),$nil,ESLVal.list(new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("x")),new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("y"))),ESLVal.list(new ESLVal("BArm",loc0,ESLVal.list(pterm(new ESLVal("A"),ESLVal.list(pterm(new ESLVal("B"),ESLVal.list(pvar(new ESLVal("v0")))),pvar(new ESLVal("v1")),pvar(new ESLVal("v2")))),pterm(new ESLVal("C"),ESLVal.list())),new ESLVal("BoolExp",loc0,$true),new ESLVal("Var",loc0,new ESLVal("OK1"))),new ESLVal("BArm",loc0,ESLVal.list(pvar(new ESLVal("v0")),pterm(new ESLVal("C"),ESLVal.list())),new ESLVal("BoolExp",loc0,$true),new ESLVal("Var",loc0,new ESLVal("OK2")))));
  private static ESLVal case2 = new ESLVal("Case",loc0,$nil,ESLVal.list(var(new ESLVal("l"))),ESLVal.list(new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PNil",loc0)),var(new ESLVal("g1")),var(new ESLVal("M1"))),new ESLVal("BArm",loc0,ESLVal.list(pcons(pterm(new ESLVal("One"),ESLVal.list()),pvar(new ESLVal("rest1")))),var(new ESLVal("g1")),var(new ESLVal("M1"))),new ESLVal("BArm",loc0,ESLVal.list(pcons(pterm(new ESLVal("Succ"),ESLVal.list(pterm(new ESLVal("One"),ESLVal.list()))),pvar(new ESLVal("rest2")))),var(new ESLVal("g2")),var(new ESLVal("M2"))),new ESLVal("BArm",loc0,ESLVal.list(pcons(pterm(new ESLVal("Infinity"),ESLVal.list()),new ESLVal("PNil",loc0))),var(new ESLVal("g3")),var(new ESLVal("M3")))));
  private static ESLVal case3 = new ESLVal("Case",loc0,$nil,ESLVal.list(var(new ESLVal("x")),var(new ESLVal("y"))),ESLVal.list(new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PInt",loc0,$zero),new ESLVal("PInt",loc0,$one)),var(new ESLVal("g1")),var(new ESLVal("M1"))),new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PInt",loc0,$one),new ESLVal("PInt",loc0,$zero)),var(new ESLVal("g2")),var(new ESLVal("M2"))),new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PInt",loc0,$zero),pvar(new ESLVal("x"))),var(new ESLVal("g3")),var(new ESLVal("M3"))),new ESLVal("BArm",loc0,ESLVal.list(pvar(new ESLVal("x")),new ESLVal("PInt",loc0,$one)),var(new ESLVal("g4")),var(new ESLVal("M4")))));
  private static ESLVal case4 = new ESLVal("Case",loc0,$nil,ESLVal.list(var(new ESLVal("x")),var(new ESLVal("y"))),ESLVal.list(new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PStr",loc0,new ESLVal("one")),new ESLVal("PInt",loc0,$one)),var(new ESLVal("g1")),var(new ESLVal("M1"))),new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PStr",loc0,new ESLVal("one")),new ESLVal("PInt",loc0,$zero)),var(new ESLVal("g2")),var(new ESLVal("M2"))),new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PStr",loc0,new ESLVal("two")),pvar(new ESLVal("x"))),var(new ESLVal("g3")),var(new ESLVal("M3"))),new ESLVal("BArm",loc0,ESLVal.list(pvar(new ESLVal("x")),new ESLVal("PInt",loc0,$one)),var(new ESLVal("g4")),var(new ESLVal("M4")))));
  private static ESLVal case5 = new ESLVal("Case",loc0,$nil,ESLVal.list(var(new ESLVal("x")),var(new ESLVal("y"))),ESLVal.list(new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PStr",loc0,new ESLVal("one")),new ESLVal("PInt",loc0,$one)),var(new ESLVal("g1")),var(new ESLVal("M1"))),new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PStr",loc0,new ESLVal("one")),new ESLVal("PInt",loc0,$zero)),var(new ESLVal("g2")),var(new ESLVal("M2"))),new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PStr",loc0,new ESLVal("two")),pvar(new ESLVal("x"))),var(new ESLVal("g3")),var(new ESLVal("M3"))),new ESLVal("BArm",loc0,ESLVal.list(pvar(new ESLVal("x")),new ESLVal("PInt",loc0,$one)),var(new ESLVal("g4")),var(new ESLVal("M4"))),new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PBool",loc0,$true),new ESLVal("PInt",loc0,$one)),var(new ESLVal("g4")),var(new ESLVal("M4")))));
  private static ESLVal case6 = new ESLVal("Case",loc0,$nil,ESLVal.list(var(new ESLVal("x"))),ESLVal.list(new ESLVal("BArm",loc0,ESLVal.list(pterm(new ESLVal("A"),ESLVal.list(new ESLVal("PInt",loc0,$one)))),var(new ESLVal("g1")),var(new ESLVal("M1")))));
  public static ESLVal main = new ESLVal(new Function(new ESLVal("main"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      return new ESLVal(new BehaviourAdapter(true,getSelf(),new ESLVal("main")) {
          
          public ESLVal handle(ESLVal $m) {{ESLVal _v1904 = $m;
            
            return error(new ESLVal("case error at Pos(0,0)").add(ESLVal.list(_v1904)));
          }}
          public ESLVal get(String name) {
            switch(name) {
              
              default: throw new Error("ref illegal " + self + "." + name);
            }
          }
        public void handleTime(ESLVal $t) {
          {ESLVal n = $t;
            
            if($true.boolVal)
            {new Function(new ESLVal("try"),getSelf()) {
              public ESLVal apply(ESLVal... args) { 
                try { 
                  return ((Supplier<ESLVal>)() -> { 
                  {print.apply(ppExp.apply($zero,translateCases(case0)));
                  print.apply(ppExp.apply($zero,translateCases(case1)));
                  print.apply(ppExp.apply($zero,translateCases(case2)));
                  print.apply(ppExp.apply($zero,translateCases(case3)));
                  print.apply(ppExp.apply($zero,translateCases(case4)));
                  print.apply(ppExp.apply($zero,translateCases(case5)));
                  return print.apply(ppExp.apply($zero,translateCases(case6)));}
                }).get();
                } catch(ESLError $exception) {
                  ESLVal $x = $exception.value;
                  {ESLVal _v1903 = $x;
              
              {ESLVal x = _v1903;
              
              return print.apply(x);
            }
            }
                }
              }
            }.apply();
            stopAll.apply();}
            else
              {}
          }
        }
        public ESLVal init() {
            return $null;
          }
        });
    }
  });
public static void main(String[] args) {
    newActor(main,new ESLVal(new Actor())); 
  }
}