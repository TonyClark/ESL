package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
// import static esl.Lists.*;
import static esl.compiler.Types.*;
import java.util.function.Supplier;
public class MethodTransform {
  public static ESLVal getSelf() { return $null; }
  public static ESLVal addMethodCalls(ESLVal module) {
    
    {ESLVal _v1928 = module;
      
      switch(_v1928.termName) {
      case "JModule": {ESLVal $3888 = _v1928.termRef(0);
        ESLVal $3887 = _v1928.termRef(1);
        ESLVal $3886 = _v1928.termRef(2);
        ESLVal $3885 = _v1928.termRef(3);
        ESLVal $3884 = _v1928.termRef(4);
        
        {ESLVal name = $3888;
        
        {ESLVal imports = $3887;
        
        {ESLVal exports = $3886;
        
        {ESLVal methods = $3885;
        
        {ESLVal fields = $3884;
        
        {ESLVal methodNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1929 = $qualArg;
                
                switch(_v1929.termName) {
                case "JMethod": {ESLVal $3891 = _v1929.termRef(0);
                  ESLVal $3890 = _v1929.termRef(1);
                  ESLVal $3889 = _v1929.termRef(2);
                  
                  {ESLVal n = $3891;
                  
                  {ESLVal args = $3890;
                  
                  {ESLVal body = $3889;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1929;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(methods).flatten().flatten();
        
        {ESLVal newMethods = new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal m = $l0.head();
                $l0 = $l0.tail();
                $v.add(walkJMethodDef(m,methodNames));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(methods);
        ESLVal newFields = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1930 = $qualArg;
                
                switch(_v1930.termName) {
                case "JField": {ESLVal $3894 = _v1930.termRef(0);
                  ESLVal $3893 = _v1930.termRef(1);
                  ESLVal $3892 = _v1930.termRef(2);
                  
                  {ESLVal n = $3894;
                  
                  {ESLVal t = $3893;
                  
                  {ESLVal e = $3892;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,walkJExp(e,methodNames))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1930;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fields).flatten().flatten();
        
        return new ESLVal("JModule",name,imports,exports,newMethods,newFields);
      }
      }
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(1166,1561)").add(ESLVal.list(_v1928)));
    }
    }
  }
  public static ESLVal addMethodCalls = new ESLVal(new Function(new ESLVal("addMethodCalls"),null) { public ESLVal apply(ESLVal... args) { return addMethodCalls(args[0]); }});
  private static ESLVal walkJMethodDef(ESLVal method,ESLVal methodNames) {
    
    {ESLVal _v1931 = method;
      
      switch(_v1931.termName) {
      case "JMethod": {ESLVal $3897 = _v1931.termRef(0);
        ESLVal $3896 = _v1931.termRef(1);
        ESLVal $3895 = _v1931.termRef(2);
        
        {ESLVal n = $3897;
        
        {ESLVal args = $3896;
        
        {ESLVal body = $3895;
        
        {ESLVal argNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1932 = $qualArg;
                
                switch(_v1932.termName) {
                case "JDec": {ESLVal $3899 = _v1932.termRef(0);
                  ESLVal $3898 = _v1932.termRef(1);
                  
                  {ESLVal _v1954 = $3899;
                  
                  {ESLVal t = $3898;
                  
                  return ESLVal.list(ESLVal.list(_v1954));
                }
                }
                }
                default: {ESLVal _0 = _v1932;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(args).flatten().flatten();
        
        {ESLVal _v1955 = removeAll.apply(argNames,methodNames);
        
        return new ESLVal("JMethod",n,args,walkJCommand(body,_v1955));
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(1633,1862)").add(ESLVal.list(_v1931)));
    }
    }
  }
  private static ESLVal walkJMethodDef = new ESLVal(new Function(new ESLVal("walkJMethodDef"),null) { public ESLVal apply(ESLVal... args) { return walkJMethodDef(args[0],args[1]); }});
  private static ESLVal walkJExp(ESLVal x,ESLVal methodNames) {
    
    {ESLVal _v1933 = x;
      
      switch(_v1933.termName) {
      case "JApply": {ESLVal $3976 = _v1933.termRef(0);
        ESLVal $3975 = _v1933.termRef(1);
        
        switch($3976.termName) {
        case "JVar": {ESLVal $3978 = $3976.termRef(0);
          ESLVal $3977 = $3976.termRef(1);
          
          {ESLVal n = $3978;
          
          {ESLVal t = $3977;
          
          {ESLVal args = $3975;
          
          if(member.apply(n,methodNames).boolVal)
          return new ESLVal("JMethodCall",n,new java.util.function.Function<ESLVal,ESLVal>() {
              public ESLVal apply(ESLVal $l0) {
                ESLVal $a = $nil;
                java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                while(!$l0.isNil()) { 
                  ESLVal e = $l0.head();
                  $l0 = $l0.tail();
                  $v.add(walkJExp(e,methodNames));
                }
                for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                return $a;
              }}.apply(args));
          else
            {ESLVal op = $3976;
              
              {ESLVal _v1953 = $3975;
              
              return new ESLVal("JApply",walkJExp(op,methodNames),new java.util.function.Function<ESLVal,ESLVal>() {
                public ESLVal apply(ESLVal $l0) {
                  ESLVal $a = $nil;
                  java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                  while(!$l0.isNil()) { 
                    ESLVal e = $l0.head();
                    $l0 = $l0.tail();
                    $v.add(walkJExp(e,methodNames));
                  }
                  for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                  return $a;
                }}.apply(_v1953));
            }
            }
        }
        }
        }
        }
        default: {ESLVal op = $3976;
          
          {ESLVal args = $3975;
          
          return new ESLVal("JApply",walkJExp(op,methodNames),new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal e = $l0.head();
                $l0 = $l0.tail();
                $v.add(walkJExp(e,methodNames));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(args));
        }
        }
      }
      }
    case "JArrayRef": {ESLVal $3974 = _v1933.termRef(0);
        ESLVal $3973 = _v1933.termRef(1);
        
        {ESLVal array = $3974;
        
        {ESLVal index = $3973;
        
        return new ESLVal("JArrayRef",walkJExp(array,methodNames),walkJExp(index,methodNames));
      }
      }
      }
    case "JArrayUpdate": {ESLVal $3972 = _v1933.termRef(0);
        ESLVal $3971 = _v1933.termRef(1);
        ESLVal $3970 = _v1933.termRef(2);
        
        {ESLVal array = $3972;
        
        {ESLVal index = $3971;
        
        {ESLVal value = $3970;
        
        return new ESLVal("JArrayUpdate",walkJExp(array,methodNames),walkJExp(index,methodNames),walkJExp(value,methodNames));
      }
      }
      }
      }
    case "JBag": {ESLVal $3969 = _v1933.termRef(0);
        ESLVal $3968 = _v1933.termRef(1);
        
        {ESLVal t = $3969;
        
        {ESLVal values = $3968;
        
        return new ESLVal("JBag",t,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal v = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJExp(v,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(values));
      }
      }
      }
    case "JBecome": {ESLVal $3967 = _v1933.termRef(0);
        ESLVal $3966 = _v1933.termRef(1);
        
        {ESLVal behaviour = $3967;
        
        {ESLVal args = $3966;
        
        return new ESLVal("JBecome",walkJExp(behaviour,methodNames),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal arg = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJExp(arg,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(args));
      }
      }
      }
    case "JBehaviour": {ESLVal $3965 = _v1933.termRef(0);
        ESLVal $3964 = _v1933.termRef(1);
        ESLVal $3963 = _v1933.termRef(2);
        ESLVal $3962 = _v1933.termRef(3);
        ESLVal $3961 = _v1933.termRef(4);
        ESLVal $3960 = _v1933.termRef(5);
        
        {ESLVal exports = $3965;
        
        {ESLVal fields = $3964;
        
        {ESLVal methods = $3963;
        
        {ESLVal parent = $3962;
        
        {ESLVal init = $3961;
        
        {ESLVal handler = $3960;
        
        {ESLVal fieldNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1936 = $qualArg;
                
                switch(_v1936.termName) {
                case "JField": {ESLVal $3986 = _v1936.termRef(0);
                  ESLVal $3985 = _v1936.termRef(1);
                  ESLVal $3984 = _v1936.termRef(2);
                  
                  {ESLVal n = $3986;
                  
                  {ESLVal t = $3985;
                  
                  {ESLVal v = $3984;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1936;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fields).flatten().flatten();
        
        {ESLVal _v1952 = removeAll.apply(fieldNames,methodNames);
        
        return new ESLVal("JBehaviour",exports,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal f = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJFieldDef(f,_v1952));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(fields),methods,walkJExp(parent,_v1952),walkJExp(init,_v1952),walkJCommand(handler,_v1952));
      }
      }
      }
      }
      }
      }
      }
      }
      }
    case "JBinExp": {ESLVal $3959 = _v1933.termRef(0);
        ESLVal $3958 = _v1933.termRef(1);
        ESLVal $3957 = _v1933.termRef(2);
        
        {ESLVal e1 = $3959;
        
        {ESLVal op = $3958;
        
        {ESLVal e2 = $3957;
        
        return new ESLVal("JBinExp",walkJExp(e1,methodNames),op,walkJExp(e2,methodNames));
      }
      }
      }
      }
    case "JCmpExp": {ESLVal $3956 = _v1933.termRef(0);
        
        {ESLVal cmp = $3956;
        
        return new ESLVal("JCmpExp",walkJCmp(cmp,methodNames));
      }
      }
    case "JCommandExp": {ESLVal $3955 = _v1933.termRef(0);
        ESLVal $3954 = _v1933.termRef(1);
        
        {ESLVal c = $3955;
        
        {ESLVal t = $3954;
        
        return new ESLVal("JCommandExp",walkJCommand(c,methodNames),t);
      }
      }
      }
    case "JConstExp": {ESLVal $3953 = _v1933.termRef(0);
        
        {ESLVal c = $3953;
        
        return new ESLVal("JConstExp",c);
      }
      }
    case "JError": {ESLVal $3952 = _v1933.termRef(0);
        
        {ESLVal e = $3952;
        
        return new ESLVal("JError",walkJExp(e,methodNames));
      }
      }
    case "JExtendedBehaviour": {ESLVal $3951 = _v1933.termRef(0);
        ESLVal $3950 = _v1933.termRef(1);
        ESLVal $3949 = _v1933.termRef(2);
        ESLVal $3948 = _v1933.termRef(3);
        ESLVal $3947 = _v1933.termRef(4);
        ESLVal $3946 = _v1933.termRef(5);
        ESLVal $3945 = _v1933.termRef(6);
        
        {ESLVal exports = $3951;
        
        {ESLVal parent = $3950;
        
        {ESLVal fields = $3949;
        
        {ESLVal methods = $3948;
        
        {ESLVal init = $3947;
        
        {ESLVal handler = $3946;
        
        {ESLVal time = $3945;
        
        {ESLVal fieldNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1935 = $qualArg;
                
                switch(_v1935.termName) {
                case "JField": {ESLVal $3983 = _v1935.termRef(0);
                  ESLVal $3982 = _v1935.termRef(1);
                  ESLVal $3981 = _v1935.termRef(2);
                  
                  {ESLVal n = $3983;
                  
                  {ESLVal t = $3982;
                  
                  {ESLVal v = $3981;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1935;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fields).flatten().flatten();
        
        {ESLVal _v1951 = removeAll.apply(fieldNames,methodNames);
        
        return new ESLVal("JExtendedBehaviour",exports,walkJExp(parent,_v1951),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal f = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJFieldDef(f,_v1951));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(fields),methods,walkJExp(init,_v1951),walkJExp(handler,_v1951),walkJCommand(time,_v1951));
      }
      }
      }
      }
      }
      }
      }
      }
      }
      }
    case "JFlatten": {ESLVal $3944 = _v1933.termRef(0);
        
        {ESLVal e = $3944;
        
        return new ESLVal("JFlatten",walkJExp(e,methodNames));
      }
      }
    case "JFun": {ESLVal $3943 = _v1933.termRef(0);
        ESLVal $3942 = _v1933.termRef(1);
        ESLVal $3941 = _v1933.termRef(2);
        ESLVal $3940 = _v1933.termRef(3);
        
        {ESLVal name = $3943;
        
        {ESLVal args = $3942;
        
        {ESLVal t = $3941;
        
        {ESLVal body = $3940;
        
        {ESLVal argNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1934 = $qualArg;
                
                switch(_v1934.termName) {
                case "JDec": {ESLVal $3980 = _v1934.termRef(0);
                  ESLVal $3979 = _v1934.termRef(1);
                  
                  {ESLVal n = $3980;
                  
                  {ESLVal _v1949 = $3979;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                default: {ESLVal _0 = _v1934;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(args).flatten().flatten();
        
        {ESLVal _v1950 = removeAll.apply(argNames,methodNames);
        
        {print.apply(new ESLVal("fun ").add(name.add(new ESLVal(" methodNames = ").add(_v1950))));
      return new ESLVal("JFun",walkJExp(name,_v1950),args,t,walkJCommand(body,_v1950));}
      }
      }
      }
      }
      }
      }
      }
    case "JGrab": {ESLVal $3939 = _v1933.termRef(0);
        ESLVal $3938 = _v1933.termRef(1);
        
        {ESLVal es = $3939;
        
        {ESLVal body = $3938;
        
        return new ESLVal("JGrab",new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJExp(e,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(es),walkJExp(body,methodNames));
      }
      }
      }
    case "JHead": {ESLVal $3937 = _v1933.termRef(0);
        
        {ESLVal e = $3937;
        
        return new ESLVal("JHead",walkJExp(e,methodNames));
      }
      }
    case "JIfExp": {ESLVal $3936 = _v1933.termRef(0);
        ESLVal $3935 = _v1933.termRef(1);
        ESLVal $3934 = _v1933.termRef(2);
        
        {ESLVal e1 = $3936;
        
        {ESLVal e2 = $3935;
        
        {ESLVal e3 = $3934;
        
        return new ESLVal("JIfExp",walkJExp(e1,methodNames),walkJExp(e2,methodNames),walkJExp(e3,methodNames));
      }
      }
      }
      }
    case "JList": {ESLVal $3933 = _v1933.termRef(0);
        ESLVal $3932 = _v1933.termRef(1);
        
        {ESLVal t = $3933;
        
        {ESLVal es = $3932;
        
        return new ESLVal("JList",t,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJExp(e,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(es));
      }
      }
      }
    case "JMapFun": {ESLVal $3931 = _v1933.termRef(0);
        ESLVal $3930 = _v1933.termRef(1);
        
        {ESLVal f = $3931;
        
        {ESLVal e = $3930;
        
        return new ESLVal("JMapFun",walkJExp(f,methodNames),walkJExp(e,methodNames));
      }
      }
      }
    case "JNew": {ESLVal $3929 = _v1933.termRef(0);
        ESLVal $3928 = _v1933.termRef(1);
        
        {ESLVal b = $3929;
        
        {ESLVal args = $3928;
        
        return new ESLVal("JNew",walkJExp(b,methodNames),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal arg = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJExp(arg,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(args));
      }
      }
      }
    case "JNewArray": {ESLVal $3927 = _v1933.termRef(0);
        
        {ESLVal e = $3927;
        
        return new ESLVal("JNewArray",walkJExp(e,methodNames));
      }
      }
    case "JNewJava": {ESLVal $3926 = _v1933.termRef(0);
        ESLVal $3925 = _v1933.termRef(1);
        
        {ESLVal path = $3926;
        
        {ESLVal args = $3925;
        
        return new ESLVal("JNewJava",path,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJExp(e,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(args));
      }
      }
      }
    case "JNewTable": {
        return new ESLVal("JNewTable",new ESLVal[]{});
      }
    case "JNil": {ESLVal $3924 = _v1933.termRef(0);
        
        {ESLVal t = $3924;
        
        return new ESLVal("JNil",t);
      }
      }
    case "JNot": {ESLVal $3923 = _v1933.termRef(0);
        
        {ESLVal e = $3923;
        
        return new ESLVal("JNot",walkJExp(e,methodNames));
      }
      }
    case "JNow": {
        return new ESLVal("JNow",new ESLVal[]{});
      }
    case "JNull": {
        return new ESLVal("JNull",new ESLVal[]{});
      }
    case "JProbably": {ESLVal $3922 = _v1933.termRef(0);
        ESLVal $3921 = _v1933.termRef(1);
        ESLVal $3920 = _v1933.termRef(2);
        
        {ESLVal e1 = $3922;
        
        {ESLVal e2 = $3921;
        
        {ESLVal e3 = $3920;
        
        return new ESLVal("JProbably",walkJExp(e1,methodNames),walkJExp(e2,methodNames),walkJExp(e3,methodNames));
      }
      }
      }
      }
    case "JRecord": {ESLVal $3919 = _v1933.termRef(0);
        
        {ESLVal fields = $3919;
        
        return new ESLVal("JRecord",new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal f = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJFieldDef(f,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(fields));
      }
      }
    case "JRef": {ESLVal $3918 = _v1933.termRef(0);
        ESLVal $3917 = _v1933.termRef(1);
        
        {ESLVal e = $3918;
        
        {ESLVal name = $3917;
        
        return new ESLVal("JRef",walkJExp(e,methodNames),name);
      }
      }
      }
    case "JRefSuper": {ESLVal $3916 = _v1933.termRef(0);
        
        {ESLVal name = $3916;
        
        return new ESLVal("JRefSuper",name);
      }
      }
    case "JSelf": {
        return new ESLVal("JSelf",new ESLVal[]{});
      }
    case "JSend": {ESLVal $3915 = _v1933.termRef(0);
        ESLVal $3914 = _v1933.termRef(1);
        ESLVal $3913 = _v1933.termRef(2);
        
        {ESLVal e = $3915;
        
        {ESLVal name = $3914;
        
        {ESLVal args = $3913;
        
        return new ESLVal("JSend",walkJExp(e,methodNames),name,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJExp(e,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(args));
      }
      }
      }
      }
    case "JSendSuper": {ESLVal $3912 = _v1933.termRef(0);
        
        {ESLVal e = $3912;
        
        return new ESLVal("JSendSuper",walkJExp(e,methodNames));
      }
      }
    case "JSendTimeSuper": {
        return new ESLVal("JSendTimeSuper",new ESLVal[]{});
      }
    case "JSet": {ESLVal $3911 = _v1933.termRef(0);
        ESLVal $3910 = _v1933.termRef(1);
        
        {ESLVal t = $3911;
        
        {ESLVal values = $3910;
        
        return new ESLVal("JSet",t,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJExp(e,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(values));
      }
      }
      }
    case "JTail": {ESLVal $3909 = _v1933.termRef(0);
        
        {ESLVal e = $3909;
        
        return new ESLVal("JTail",walkJExp(e,methodNames));
      }
      }
    case "JTerm": {ESLVal $3908 = _v1933.termRef(0);
        ESLVal $3907 = _v1933.termRef(1);
        
        {ESLVal name = $3908;
        
        {ESLVal values = $3907;
        
        return new ESLVal("JTerm",name,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJExp(e,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(values));
      }
      }
      }
    case "JTermRef": {ESLVal $3906 = _v1933.termRef(0);
        ESLVal $3905 = _v1933.termRef(1);
        
        {ESLVal e = $3906;
        
        {ESLVal i = $3905;
        
        return new ESLVal("JTermRef",walkJExp(e,methodNames),i);
      }
      }
      }
    case "JTry": {ESLVal $3904 = _v1933.termRef(0);
        ESLVal $3903 = _v1933.termRef(1);
        ESLVal $3902 = _v1933.termRef(2);
        
        {ESLVal e = $3904;
        
        {ESLVal n = $3903;
        
        {ESLVal c = $3902;
        
        return new ESLVal("JTry",walkJExp(e,methodNames),n,walkJCommand(c,methodNames));
      }
      }
      }
      }
    case "JVar": {ESLVal $3901 = _v1933.termRef(0);
        ESLVal $3900 = _v1933.termRef(1);
        
        {ESLVal name = $3901;
        
        {ESLVal t = $3900;
        
        return new ESLVal("JVar",name,t);
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(1913,5668)").add(ESLVal.list(_v1933)));
    }
    }
  }
  private static ESLVal walkJExp = new ESLVal(new Function(new ESLVal("walkJExp"),null) { public ESLVal apply(ESLVal... args) { return walkJExp(args[0],args[1]); }});
  private static ESLVal walkJFieldDef(ESLVal x,ESLVal methodNames) {
    
    {ESLVal _v1937 = x;
      
      switch(_v1937.termName) {
      case "JField": {ESLVal $3989 = _v1937.termRef(0);
        ESLVal $3988 = _v1937.termRef(1);
        ESLVal $3987 = _v1937.termRef(2);
        
        {ESLVal name = $3989;
        
        {ESLVal t = $3988;
        
        {ESLVal value = $3987;
        
        return new ESLVal("JField",name,t,walkJExp(value,methodNames));
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(5736,5820)").add(ESLVal.list(_v1937)));
    }
    }
  }
  private static ESLVal walkJFieldDef = new ESLVal(new Function(new ESLVal("walkJFieldDef"),null) { public ESLVal apply(ESLVal... args) { return walkJFieldDef(args[0],args[1]); }});
  private static ESLVal walkJCommand(ESLVal x,ESLVal methodNames) {
    
    {ESLVal _v1938 = x;
      
      switch(_v1938.termName) {
      case "JBlock": {ESLVal $4030 = _v1938.termRef(0);
        
        {ESLVal commands = $4030;
        
        return new ESLVal("JBlock",new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal c = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJCommand(c,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(commands));
      }
      }
    case "JCaseBool": {ESLVal $4029 = _v1938.termRef(0);
        ESLVal $4028 = _v1938.termRef(1);
        ESLVal $4027 = _v1938.termRef(2);
        
        {ESLVal e = $4029;
        
        {ESLVal boolArms = $4028;
        
        {ESLVal alt = $4027;
        
        return new ESLVal("JCaseBool",walkJExp(e,methodNames),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal a = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJBoolArm(a,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(boolArms),walkJCommand(alt,methodNames));
      }
      }
      }
      }
    case "JCaseInt": {ESLVal $4026 = _v1938.termRef(0);
        ESLVal $4025 = _v1938.termRef(1);
        ESLVal $4024 = _v1938.termRef(2);
        
        {ESLVal e = $4026;
        
        {ESLVal intArms = $4025;
        
        {ESLVal alt = $4024;
        
        return new ESLVal("JCaseInt",walkJExp(e,methodNames),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal a = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJIntArm(a,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(intArms),walkJCommand(alt,methodNames));
      }
      }
      }
      }
    case "JCaseList": {ESLVal $4023 = _v1938.termRef(0);
        ESLVal $4022 = _v1938.termRef(1);
        ESLVal $4021 = _v1938.termRef(2);
        ESLVal $4020 = _v1938.termRef(3);
        
        {ESLVal e = $4023;
        
        {ESLVal head = $4022;
        
        {ESLVal tail = $4021;
        
        {ESLVal alt = $4020;
        
        return new ESLVal("JCaseList",walkJExp(e,methodNames),walkJCommand(head,methodNames),walkJCommand(tail,methodNames),walkJCommand(alt,methodNames));
      }
      }
      }
      }
      }
    case "JCaseStr": {ESLVal $4019 = _v1938.termRef(0);
        ESLVal $4018 = _v1938.termRef(1);
        ESLVal $4017 = _v1938.termRef(2);
        
        {ESLVal e = $4019;
        
        {ESLVal strArms = $4018;
        
        {ESLVal alt = $4017;
        
        return new ESLVal("JCaseStr",walkJExp(e,methodNames),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal a = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJStrArm(a,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(strArms),walkJCommand(alt,methodNames));
      }
      }
      }
      }
    case "JCaseTerm": {ESLVal $4016 = _v1938.termRef(0);
        ESLVal $4015 = _v1938.termRef(1);
        ESLVal $4014 = _v1938.termRef(2);
        
        {ESLVal e = $4016;
        
        {ESLVal termArms = $4015;
        
        {ESLVal alt = $4014;
        
        return new ESLVal("JCaseTerm",walkJExp(e,methodNames),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal a = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJTermArm(a,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(termArms),walkJCommand(alt,methodNames));
      }
      }
      }
      }
    case "JFor": {ESLVal $4013 = _v1938.termRef(0);
        ESLVal $4012 = _v1938.termRef(1);
        ESLVal $4011 = _v1938.termRef(2);
        ESLVal $4010 = _v1938.termRef(3);
        
        {ESLVal n1 = $4013;
        
        {ESLVal n2 = $4012;
        
        {ESLVal e = $4011;
        
        {ESLVal c = $4010;
        
        return new ESLVal("JFor",n1,n2,walkJExp(e,methodNames),walkJCommand(c,methodNames));
      }
      }
      }
      }
      }
    case "JIfCommand": {ESLVal $4009 = _v1938.termRef(0);
        ESLVal $4008 = _v1938.termRef(1);
        ESLVal $4007 = _v1938.termRef(2);
        
        {ESLVal e = $4009;
        
        {ESLVal c1 = $4008;
        
        {ESLVal c2 = $4007;
        
        return new ESLVal("JIfCommand",walkJExp(e,methodNames),walkJCommand(c1,methodNames),walkJCommand(c2,methodNames));
      }
      }
      }
      }
    case "JLet": {ESLVal $4006 = _v1938.termRef(0);
        ESLVal $4005 = _v1938.termRef(1);
        
        {ESLVal fields = $4006;
        
        {ESLVal body = $4005;
        
        {ESLVal fieldNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1941 = $qualArg;
                
                switch(_v1941.termName) {
                case "JField": {ESLVal $4039 = _v1941.termRef(0);
                  ESLVal $4038 = _v1941.termRef(1);
                  ESLVal $4037 = _v1941.termRef(2);
                  
                  {ESLVal n = $4039;
                  
                  {ESLVal t = $4038;
                  
                  {ESLVal v = $4037;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1941;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fields).flatten().flatten();
        
        {ESLVal methodNames2 = removeAll.apply(fieldNames,methodNames);
        
        return new ESLVal("JLet",new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal f = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJFieldDef(f,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(fields),walkJCommand(body,methodNames2));
      }
      }
      }
      }
      }
    case "JLetRec": {ESLVal $4004 = _v1938.termRef(0);
        ESLVal $4003 = _v1938.termRef(1);
        
        {ESLVal fields = $4004;
        
        {ESLVal body = $4003;
        
        {ESLVal fieldNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1940 = $qualArg;
                
                switch(_v1940.termName) {
                case "JField": {ESLVal $4036 = _v1940.termRef(0);
                  ESLVal $4035 = _v1940.termRef(1);
                  ESLVal $4034 = _v1940.termRef(2);
                  
                  {ESLVal n = $4036;
                  
                  {ESLVal t = $4035;
                  
                  {ESLVal v = $4034;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1940;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fields).flatten().flatten();
        
        {ESLVal _v1948 = removeAll.apply(fieldNames,methodNames);
        
        return new ESLVal("JLetRec",new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal f = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJFieldDef(f,_v1948));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(fields),walkJCommand(body,_v1948));
      }
      }
      }
      }
      }
    case "JPLet": {ESLVal $4002 = _v1938.termRef(0);
        ESLVal $4001 = _v1938.termRef(1);
        
        {ESLVal fields = $4002;
        
        {ESLVal body = $4001;
        
        {ESLVal fieldNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1939 = $qualArg;
                
                switch(_v1939.termName) {
                case "JField": {ESLVal $4033 = _v1939.termRef(0);
                  ESLVal $4032 = _v1939.termRef(1);
                  ESLVal $4031 = _v1939.termRef(2);
                  
                  {ESLVal n = $4033;
                  
                  {ESLVal t = $4032;
                  
                  {ESLVal v = $4031;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1939;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fields).flatten().flatten();
        
        {ESLVal methodNames2 = removeAll.apply(fieldNames,methodNames);
        
        return new ESLVal("JPLet",new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal f = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJFieldDef(f,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(fields),walkJCommand(body,methodNames2));
      }
      }
      }
      }
      }
    case "JReturn": {ESLVal $4000 = _v1938.termRef(0);
        
        {ESLVal e = $4000;
        
        return new ESLVal("JReturn",walkJExp(e,methodNames));
      }
      }
    case "JStatement": {ESLVal $3999 = _v1938.termRef(0);
        
        {ESLVal e = $3999;
        
        return new ESLVal("JStatement",walkJExp(e,methodNames));
      }
      }
    case "JSwitch": {ESLVal $3998 = _v1938.termRef(0);
        ESLVal $3997 = _v1938.termRef(1);
        ESLVal $3996 = _v1938.termRef(2);
        
        {ESLVal e = $3998;
        
        {ESLVal cases = $3997;
        
        {ESLVal command = $3996;
        
        return new ESLVal("JSwitch",walkJExp(e,methodNames),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal c = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJCase(c,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(cases),walkJCommand(command,methodNames));
      }
      }
      }
      }
    case "JSwitchList": {ESLVal $3995 = _v1938.termRef(0);
        ESLVal $3994 = _v1938.termRef(1);
        ESLVal $3993 = _v1938.termRef(2);
        ESLVal $3992 = _v1938.termRef(3);
        
        {ESLVal e = $3995;
        
        {ESLVal c1 = $3994;
        
        {ESLVal c2 = $3993;
        
        {ESLVal c3 = $3992;
        
        return new ESLVal("JSwitchList",walkJExp(e,methodNames),walkJCommand(c1,methodNames),walkJCommand(c2,methodNames),walkJCommand(c3,methodNames));
      }
      }
      }
      }
      }
    case "JUpdate": {ESLVal $3991 = _v1938.termRef(0);
        ESLVal $3990 = _v1938.termRef(1);
        
        {ESLVal n = $3991;
        
        {ESLVal e = $3990;
        
        return new ESLVal("JUpdate",n,walkJExp(e,methodNames));
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(5885,8175)").add(ESLVal.list(_v1938)));
    }
    }
  }
  private static ESLVal walkJCommand = new ESLVal(new Function(new ESLVal("walkJCommand"),null) { public ESLVal apply(ESLVal... args) { return walkJCommand(args[0],args[1]); }});
  private static ESLVal walkJBoolArm(ESLVal x,ESLVal methodNames) {
    
    {ESLVal _v1942 = x;
      
      switch(_v1942.termName) {
      case "JBArm": {ESLVal $4041 = _v1942.termRef(0);
        ESLVal $4040 = _v1942.termRef(1);
        
        {ESLVal b = $4041;
        
        {ESLVal command = $4040;
        
        return new ESLVal("JBArm",b,walkJCommand(command,methodNames));
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(8240,8320)").add(ESLVal.list(_v1942)));
    }
    }
  }
  private static ESLVal walkJBoolArm = new ESLVal(new Function(new ESLVal("walkJBoolArm"),null) { public ESLVal apply(ESLVal... args) { return walkJBoolArm(args[0],args[1]); }});
  private static ESLVal walkJIntArm(ESLVal x,ESLVal methodNames) {
    
    {ESLVal _v1943 = x;
      
      switch(_v1943.termName) {
      case "JIArm": {ESLVal $4043 = _v1943.termRef(0);
        ESLVal $4042 = _v1943.termRef(1);
        
        {ESLVal i = $4043;
        
        {ESLVal command = $4042;
        
        return new ESLVal("JIArm",i,walkJCommand(command,methodNames));
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(8382,8462)").add(ESLVal.list(_v1943)));
    }
    }
  }
  private static ESLVal walkJIntArm = new ESLVal(new Function(new ESLVal("walkJIntArm"),null) { public ESLVal apply(ESLVal... args) { return walkJIntArm(args[0],args[1]); }});
  private static ESLVal walkJStrArm(ESLVal x,ESLVal methodNames) {
    
    {ESLVal _v1944 = x;
      
      switch(_v1944.termName) {
      case "JSArm": {ESLVal $4045 = _v1944.termRef(0);
        ESLVal $4044 = _v1944.termRef(1);
        
        {ESLVal s = $4045;
        
        {ESLVal command = $4044;
        
        return new ESLVal("JSArm",s,walkJCommand(command,methodNames));
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(8524,8604)").add(ESLVal.list(_v1944)));
    }
    }
  }
  private static ESLVal walkJStrArm = new ESLVal(new Function(new ESLVal("walkJStrArm"),null) { public ESLVal apply(ESLVal... args) { return walkJStrArm(args[0],args[1]); }});
  private static ESLVal walkJTermArm(ESLVal x,ESLVal methodNames) {
    
    {ESLVal _v1945 = x;
      
      switch(_v1945.termName) {
      case "JTArm": {ESLVal $4048 = _v1945.termRef(0);
        ESLVal $4047 = _v1945.termRef(1);
        ESLVal $4046 = _v1945.termRef(2);
        
        {ESLVal name = $4048;
        
        {ESLVal index = $4047;
        
        {ESLVal command = $4046;
        
        return new ESLVal("JTArm",name,index,walkJCommand(command,methodNames));
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(8669,8767)").add(ESLVal.list(_v1945)));
    }
    }
  }
  private static ESLVal walkJTermArm = new ESLVal(new Function(new ESLVal("walkJTermArm"),null) { public ESLVal apply(ESLVal... args) { return walkJTermArm(args[0],args[1]); }});
  private static ESLVal walkJCase(ESLVal x,ESLVal methodNames) {
    
    {ESLVal _v1946 = x;
      
      switch(_v1946.termName) {
      case "JCaseOf": {ESLVal $4050 = _v1946.termRef(0);
        ESLVal $4049 = _v1946.termRef(1);
        
        {ESLVal k = $4050;
        
        {ESLVal command = $4049;
        
        return new ESLVal("JCaseOf",k,walkJCommand(command,methodNames));
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(8823,8907)").add(ESLVal.list(_v1946)));
    }
    }
  }
  private static ESLVal walkJCase = new ESLVal(new Function(new ESLVal("walkJCase"),null) { public ESLVal apply(ESLVal... args) { return walkJCase(args[0],args[1]); }});
  private static ESLVal walkJCmp(ESLVal x,ESLVal methodNames) {
    
    {ESLVal _v1947 = x;
      
      switch(_v1947.termName) {
      case "JCmpList": {ESLVal $4059 = _v1947.termRef(0);
        
        {ESLVal e = $4059;
        
        return new ESLVal("JCmpList",walkJExp(e,methodNames));
      }
      }
    case "JCmpOuter": {ESLVal $4058 = _v1947.termRef(0);
        ESLVal $4057 = _v1947.termRef(1);
        ESLVal $4056 = _v1947.termRef(2);
        
        {ESLVal n = $4058;
        
        {ESLVal e = $4057;
        
        {ESLVal c = $4056;
        
        return new ESLVal("JCmpOuter",n,walkJExp(e,remove.apply(n,methodNames)),walkJCmp(c,remove.apply(n,methodNames)));
      }
      }
      }
      }
    case "JCmpIf": {ESLVal $4055 = _v1947.termRef(0);
        ESLVal $4054 = _v1947.termRef(1);
        
        {ESLVal e = $4055;
        
        {ESLVal c = $4054;
        
        return new ESLVal("JCmpIf",walkJExp(e,methodNames),walkJCmp(c,methodNames));
      }
      }
      }
    case "JCmpBind": {ESLVal $4053 = _v1947.termRef(0);
        ESLVal $4052 = _v1947.termRef(1);
        ESLVal $4051 = _v1947.termRef(2);
        
        {ESLVal n = $4053;
        
        {ESLVal e = $4052;
        
        {ESLVal c = $4051;
        
        return new ESLVal("JCmpBind",n,walkJExp(e,remove.apply(n,methodNames)),walkJCmp(c,remove.apply(n,methodNames)));
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(8960,9332)").add(ESLVal.list(_v1947)));
    }
    }
  }
  private static ESLVal walkJCmp = new ESLVal(new Function(new ESLVal("walkJCmp"),null) { public ESLVal apply(ESLVal... args) { return walkJCmp(args[0],args[1]); }});

public static void main(String[] args) {
  }
}