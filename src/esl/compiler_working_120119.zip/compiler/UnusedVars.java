package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
// import static esl.Lists.*;
import static esl.compiler.Types.*;
import static esl.Displays.*;
import static esl.compiler.FV.*;
import java.util.function.Supplier;
public class UnusedVars {
  public static ESLVal getSelf() { return $null; }
  private static ESLVal resetWarnings() {
    
    return setWarnings(ESLVal.list());
  }
  private static ESLVal resetWarnings = new ESLVal(new Function(new ESLVal("resetWarnings"),null) { public ESLVal apply(ESLVal... args) { return resetWarnings(); }});
  private static ESLVal getWarnings() {
    
    return edb.ref("getProperty").apply(new ESLVal("$WARNINGS"));
  }
  private static ESLVal getWarnings = new ESLVal(new Function(new ESLVal("getWarnings"),null) { public ESLVal apply(ESLVal... args) { return getWarnings(); }});
  private static ESLVal setWarnings(ESLVal warnings) {
    
    return edb.ref("setProperty").apply(new ESLVal("$WARNINGS"),warnings);
  }
  private static ESLVal setWarnings = new ESLVal(new Function(new ESLVal("setWarnings"),null) { public ESLVal apply(ESLVal... args) { return setWarnings(args[0]); }});
  private static ESLVal addWarning(ESLVal l,ESLVal message) {
    
    return setWarnings(getWarnings().cons(new ESLVal("Warning",l,message)));
  }
  private static ESLVal addWarning = new ESLVal(new Function(new ESLVal("addWarning"),null) { public ESLVal apply(ESLVal... args) { return addWarning(args[0],args[1]); }});
  public static ESLVal checkUnusedVars(ESLVal module) {
    
    {resetWarnings();
    return walkAST(module);}
  }
  public static ESLVal checkUnusedVars = new ESLVal(new Function(new ESLVal("checkUnusedVars"),null) { public ESLVal apply(ESLVal... args) { return checkUnusedVars(args[0]); }});
  private static ESLVal walkArm(ESLVal x) {
    
    {ESLVal _v1646 = x;
      
      switch(_v1646.termName) {
      case "BArm": {ESLVal $2561 = _v1646.termRef(0);
        ESLVal $2560 = _v1646.termRef(1);
        ESLVal $2559 = _v1646.termRef(2);
        ESLVal $2558 = _v1646.termRef(3);
        
        {ESLVal v0 = $2561;
        
        {ESLVal v1 = $2560;
        
        {ESLVal v2 = $2559;
        
        {ESLVal v3 = $2558;
        
        {{
        ESLVal _v1647 = v1;
        while(_v1647.isCons()) {
          ESLVal p = _v1647.headVal;
          walkPattern(p);
          _v1647 = _v1647.tailVal;}
      }
      walkAST(v2);
      return walkAST(v3);}
      }
      }
      }
      }
      }
    case "LArm": {ESLVal $2557 = _v1646.termRef(0);
        ESLVal $2556 = _v1646.termRef(1);
        ESLVal $2555 = _v1646.termRef(2);
        ESLVal $2554 = _v1646.termRef(3);
        ESLVal $2553 = _v1646.termRef(4);
        
        {ESLVal v0 = $2557;
        
        {ESLVal v1 = $2556;
        
        {ESLVal v2 = $2555;
        
        {ESLVal v3 = $2554;
        
        {ESLVal v4 = $2553;
        
        return $null;
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(1844,2058)").add(ESLVal.list(_v1646)));
    }
    }
  }
  private static ESLVal walkArm = new ESLVal(new Function(new ESLVal("walkArm"),null) { public ESLVal apply(ESLVal... args) { return walkArm(args[0]); }});
  private static ESLVal walkPattern(ESLVal x) {
    
    {ESLVal _v1648 = x;
      
      switch(_v1648.termName) {
      case "PAdd": {ESLVal $2593 = _v1648.termRef(0);
        ESLVal $2592 = _v1648.termRef(1);
        ESLVal $2591 = _v1648.termRef(2);
        
        {ESLVal v0 = $2593;
        
        {ESLVal v1 = $2592;
        
        {ESLVal v2 = $2591;
        
        {walkPattern(v1);
      return walkPattern(v2);}
      }
      }
      }
      }
    case "PApplyType": {ESLVal $2590 = _v1648.termRef(0);
        ESLVal $2589 = _v1648.termRef(1);
        ESLVal $2588 = _v1648.termRef(2);
        
        {ESLVal v0 = $2590;
        
        {ESLVal v1 = $2589;
        
        {ESLVal v2 = $2588;
        
        return walkPattern(v1);
      }
      }
      }
      }
    case "PBagCons": {ESLVal $2587 = _v1648.termRef(0);
        ESLVal $2586 = _v1648.termRef(1);
        ESLVal $2585 = _v1648.termRef(2);
        
        {ESLVal v0 = $2587;
        
        {ESLVal v1 = $2586;
        
        {ESLVal v2 = $2585;
        
        {walkPattern(v1);
      return walkPattern(v2);}
      }
      }
      }
      }
    case "PBool": {ESLVal $2584 = _v1648.termRef(0);
        ESLVal $2583 = _v1648.termRef(1);
        
        {ESLVal v0 = $2584;
        
        {ESLVal v1 = $2583;
        
        return $null;
      }
      }
      }
    case "PCons": {ESLVal $2582 = _v1648.termRef(0);
        ESLVal $2581 = _v1648.termRef(1);
        ESLVal $2580 = _v1648.termRef(2);
        
        {ESLVal v0 = $2582;
        
        {ESLVal v1 = $2581;
        
        {ESLVal v2 = $2580;
        
        {walkPattern(v1);
      return walkPattern(v2);}
      }
      }
      }
      }
    case "PEmptyBag": {ESLVal $2579 = _v1648.termRef(0);
        
        {ESLVal v0 = $2579;
        
        return $null;
      }
      }
    case "PEmptySet": {ESLVal $2578 = _v1648.termRef(0);
        
        {ESLVal v0 = $2578;
        
        return $null;
      }
      }
    case "PInt": {ESLVal $2577 = _v1648.termRef(0);
        ESLVal $2576 = _v1648.termRef(1);
        
        {ESLVal v0 = $2577;
        
        {ESLVal v1 = $2576;
        
        return $null;
      }
      }
      }
    case "PNil": {ESLVal $2575 = _v1648.termRef(0);
        
        {ESLVal v0 = $2575;
        
        return $null;
      }
      }
    case "PNull": {ESLVal $2574 = _v1648.termRef(0);
        
        {ESLVal v0 = $2574;
        
        return $null;
      }
      }
    case "PSetCons": {ESLVal $2573 = _v1648.termRef(0);
        ESLVal $2572 = _v1648.termRef(1);
        ESLVal $2571 = _v1648.termRef(2);
        
        {ESLVal v0 = $2573;
        
        {ESLVal v1 = $2572;
        
        {ESLVal v2 = $2571;
        
        {walkPattern(v1);
      return walkPattern(v2);}
      }
      }
      }
      }
    case "PStr": {ESLVal $2570 = _v1648.termRef(0);
        ESLVal $2569 = _v1648.termRef(1);
        
        {ESLVal v0 = $2570;
        
        {ESLVal v1 = $2569;
        
        return $null;
      }
      }
      }
    case "PTerm": {ESLVal $2568 = _v1648.termRef(0);
        ESLVal $2567 = _v1648.termRef(1);
        ESLVal $2566 = _v1648.termRef(2);
        ESLVal $2565 = _v1648.termRef(3);
        
        {ESLVal v0 = $2568;
        
        {ESLVal v1 = $2567;
        
        {ESLVal v2 = $2566;
        
        {ESLVal v3 = $2565;
        
        {{
        ESLVal _v1649 = v3;
        while(_v1649.isCons()) {
          ESLVal p = _v1649.headVal;
          walkPattern(p);
          _v1649 = _v1649.tailVal;}
      }
      return $null;}
      }
      }
      }
      }
      }
    case "PVar": {ESLVal $2564 = _v1648.termRef(0);
        ESLVal $2563 = _v1648.termRef(1);
        ESLVal $2562 = _v1648.termRef(2);
        
        {ESLVal v0 = $2564;
        
        {ESLVal v1 = $2563;
        
        {ESLVal v2 = $2562;
        
        return $null;
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(2102,2946)").add(ESLVal.list(_v1648)));
    }
    }
  }
  private static ESLVal walkPattern = new ESLVal(new Function(new ESLVal("walkPattern"),null) { public ESLVal apply(ESLVal... args) { return walkPattern(args[0]); }});
  private static ESLVal walkTDec(ESLVal d) {
    
    {ESLVal _v1650 = d;
      
      switch(_v1650.termName) {
      case "Dec": {ESLVal $2597 = _v1650.termRef(0);
        ESLVal $2596 = _v1650.termRef(1);
        ESLVal $2595 = _v1650.termRef(2);
        ESLVal $2594 = _v1650.termRef(3);
        
        {ESLVal v0 = $2597;
        
        {ESLVal v1 = $2596;
        
        {ESLVal v2 = $2595;
        
        {ESLVal v3 = $2594;
        
        return $null;
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(2978,3044)").add(ESLVal.list(_v1650)));
    }
    }
  }
  private static ESLVal walkTDec = new ESLVal(new Function(new ESLVal("walkTDec"),null) { public ESLVal apply(ESLVal... args) { return walkTDec(args[0]); }});
  private static ESLVal walkTBind(ESLVal b) {
    
    {ESLVal _v1651 = b;
      
      switch(_v1651.termName) {
      case "TypeBind": {ESLVal $2623 = _v1651.termRef(0);
        ESLVal $2622 = _v1651.termRef(1);
        ESLVal $2621 = _v1651.termRef(2);
        ESLVal $2620 = _v1651.termRef(3);
        
        {ESLVal v0 = $2623;
        
        {ESLVal v1 = $2622;
        
        {ESLVal v2 = $2621;
        
        {ESLVal v3 = $2620;
        
        return $null;
      }
      }
      }
      }
      }
    case "CnstrBind": {ESLVal $2619 = _v1651.termRef(0);
        ESLVal $2618 = _v1651.termRef(1);
        ESLVal $2617 = _v1651.termRef(2);
        ESLVal $2616 = _v1651.termRef(3);
        
        {ESLVal v0 = $2619;
        
        {ESLVal v1 = $2618;
        
        {ESLVal v2 = $2617;
        
        {ESLVal v3 = $2616;
        
        return $null;
      }
      }
      }
      }
      }
    case "FunBind": {ESLVal $2615 = _v1651.termRef(0);
        ESLVal $2614 = _v1651.termRef(1);
        ESLVal $2613 = _v1651.termRef(2);
        ESLVal $2612 = _v1651.termRef(3);
        ESLVal $2611 = _v1651.termRef(4);
        ESLVal $2610 = _v1651.termRef(5);
        ESLVal $2609 = _v1651.termRef(6);
        
        {ESLVal l = $2615;
        
        {ESLVal name = $2614;
        
        {ESLVal args = $2613;
        
        {ESLVal t = $2612;
        
        {ESLVal dt = $2611;
        
        {ESLVal body = $2610;
        
        {ESLVal guard = $2609;
        
        {{ESLVal usedNames = freeVars.apply(body).add(freeVars.apply(guard));
        
        {
        ESLVal _v1652 = args;
        while(_v1652.isCons()) {
          ESLVal arg = _v1652.headVal;
          {
            ESLVal _v1653 = patternNames.apply(arg);
            while(_v1653.isCons()) {
              ESLVal n = _v1653.headVal;
              if(member.apply(n,usedNames).not().boolVal)
                addWarning(patternLoc.apply(arg),n.add(new ESLVal(" is not used in the function body.")));
                else
                  {}
              _v1653 = _v1653.tailVal;}
          }
          _v1652 = _v1652.tailVal;}
      }
      }
      walkAST(body);
      return walkAST(guard);}
      }
      }
      }
      }
      }
      }
      }
      }
    case "FunBinds": {ESLVal $2608 = _v1651.termRef(0);
        ESLVal $2607 = _v1651.termRef(1);
        
        {ESLVal v0 = $2608;
        
        {ESLVal v1 = $2607;
        
        return $null;
      }
      }
      }
    case "Binding": {ESLVal $2606 = _v1651.termRef(0);
        ESLVal $2605 = _v1651.termRef(1);
        ESLVal $2604 = _v1651.termRef(2);
        ESLVal $2603 = _v1651.termRef(3);
        ESLVal $2602 = _v1651.termRef(4);
        
        {ESLVal v0 = $2606;
        
        {ESLVal v1 = $2605;
        
        {ESLVal v2 = $2604;
        
        {ESLVal v3 = $2603;
        
        {ESLVal v4 = $2602;
        
        return walkAST(v4);
      }
      }
      }
      }
      }
      }
    case "DataBind": {ESLVal $2601 = _v1651.termRef(0);
        ESLVal $2600 = _v1651.termRef(1);
        ESLVal $2599 = _v1651.termRef(2);
        ESLVal $2598 = _v1651.termRef(3);
        
        {ESLVal v0 = $2601;
        
        {ESLVal v1 = $2600;
        
        {ESLVal v2 = $2599;
        
        {ESLVal v3 = $2598;
        
        return $null;
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(3079,3847)").add(ESLVal.list(_v1651)));
    }
    }
  }
  private static ESLVal walkTBind = new ESLVal(new Function(new ESLVal("walkTBind"),null) { public ESLVal apply(ESLVal... args) { return walkTBind(args[0]); }});
  private static ESLVal walkQualifier(ESLVal x) {
    
    {ESLVal _v1654 = x;
      
      switch(_v1654.termName) {
      case "BQual": {ESLVal $2628 = _v1654.termRef(0);
        ESLVal $2627 = _v1654.termRef(1);
        ESLVal $2626 = _v1654.termRef(2);
        
        {ESLVal v0 = $2628;
        
        {ESLVal v1 = $2627;
        
        {ESLVal v2 = $2626;
        
        {walkPattern(v1);
      return walkAST(v2);}
      }
      }
      }
      }
    case "PQual": {ESLVal $2625 = _v1654.termRef(0);
        ESLVal $2624 = _v1654.termRef(1);
        
        {ESLVal v0 = $2625;
        
        {ESLVal v1 = $2624;
        
        return walkAST(v1);
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(3896,4057)").add(ESLVal.list(_v1654)));
    }
    }
  }
  private static ESLVal walkQualifier = new ESLVal(new Function(new ESLVal("walkQualifier"),null) { public ESLVal apply(ESLVal... args) { return walkQualifier(args[0]); }});
  private static ESLVal walkDRef(ESLVal x) {
    
    {ESLVal _v1655 = x;
      
      switch(_v1655.termName) {
      case "VarDynamicRef": {ESLVal $2633 = _v1655.termRef(0);
        ESLVal $2632 = _v1655.termRef(1);
        
        {ESLVal v0 = $2633;
        
        {ESLVal v1 = $2632;
        
        return walkAST(v1);
      }
      }
      }
    case "ActorDynamicRef": {ESLVal $2631 = _v1655.termRef(0);
        ESLVal $2630 = _v1655.termRef(1);
        ESLVal $2629 = _v1655.termRef(2);
        
        {ESLVal v0 = $2631;
        
        {ESLVal v1 = $2630;
        
        {ESLVal v2 = $2629;
        
        return walkAST(v1);
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(4091,4215)").add(ESLVal.list(_v1655)));
    }
    }
  }
  private static ESLVal walkDRef = new ESLVal(new Function(new ESLVal("walkDRef"),null) { public ESLVal apply(ESLVal... args) { return walkDRef(args[0]); }});
  private static ESLVal walkAST(ESLVal x) {
    
    {ESLVal _v1656 = x;
      
      switch(_v1656.termName) {
      case "ActExp": {ESLVal $2778 = _v1656.termRef(0);
        ESLVal $2777 = _v1656.termRef(1);
        ESLVal $2776 = _v1656.termRef(2);
        ESLVal $2775 = _v1656.termRef(3);
        ESLVal $2774 = _v1656.termRef(4);
        ESLVal $2773 = _v1656.termRef(5);
        ESLVal $2772 = _v1656.termRef(6);
        ESLVal $2771 = _v1656.termRef(7);
        
        {ESLVal v0 = $2778;
        
        {ESLVal v1 = $2777;
        
        {ESLVal v2 = $2776;
        
        {ESLVal v3 = $2775;
        
        {ESLVal v4 = $2774;
        
        {ESLVal v5 = $2773;
        
        {ESLVal v6 = $2772;
        
        {ESLVal v7 = $2771;
        
        {{
        ESLVal _v1678 = v2;
        while(_v1678.isCons()) {
          ESLVal d = _v1678.headVal;
          walkTDec(d);
          _v1678 = _v1678.tailVal;}
      }
      {
        ESLVal _v1679 = v5;
        while(_v1679.isCons()) {
          ESLVal b = _v1679.headVal;
          walkTBind(b);
          _v1679 = _v1679.tailVal;}
      }
      walkAST(v6);
      {{
        ESLVal _v1680 = v7;
        while(_v1680.isCons()) {
          ESLVal a = _v1680.headVal;
          walkArm(a);
          _v1680 = _v1680.tailVal;}
      }
      return $null;}}
      }
      }
      }
      }
      }
      }
      }
      }
      }
    case "Apply": {ESLVal $2770 = _v1656.termRef(0);
        ESLVal $2769 = _v1656.termRef(1);
        ESLVal $2768 = _v1656.termRef(2);
        
        {ESLVal v0 = $2770;
        
        {ESLVal v1 = $2769;
        
        {ESLVal v2 = $2768;
        
        {walkAST(v1);
      {{
        ESLVal _v1677 = v2;
        while(_v1677.isCons()) {
          ESLVal e = _v1677.headVal;
          walkAST(e);
          _v1677 = _v1677.tailVal;}
      }
      return $null;}}
      }
      }
      }
      }
    case "ApplyTypeExp": {ESLVal $2767 = _v1656.termRef(0);
        ESLVal $2766 = _v1656.termRef(1);
        ESLVal $2765 = _v1656.termRef(2);
        
        {ESLVal v0 = $2767;
        
        {ESLVal v1 = $2766;
        
        {ESLVal v2 = $2765;
        
        return walkAST(v1);
      }
      }
      }
      }
    case "ArrayRef": {ESLVal $2764 = _v1656.termRef(0);
        ESLVal $2763 = _v1656.termRef(1);
        ESLVal $2762 = _v1656.termRef(2);
        
        {ESLVal v0 = $2764;
        
        {ESLVal v1 = $2763;
        
        {ESLVal v2 = $2762;
        
        {walkAST(v1);
      return walkAST(v2);}
      }
      }
      }
      }
    case "ArrayUpdate": {ESLVal $2761 = _v1656.termRef(0);
        ESLVal $2760 = _v1656.termRef(1);
        ESLVal $2759 = _v1656.termRef(2);
        ESLVal $2758 = _v1656.termRef(3);
        
        {ESLVal v0 = $2761;
        
        {ESLVal v1 = $2760;
        
        {ESLVal v2 = $2759;
        
        {ESLVal v3 = $2758;
        
        {walkAST(v1);
      walkAST(v2);
      return walkAST(v3);}
      }
      }
      }
      }
      }
    case "BagExp": {ESLVal $2757 = _v1656.termRef(0);
        ESLVal $2756 = _v1656.termRef(1);
        
        {ESLVal v0 = $2757;
        
        {ESLVal v1 = $2756;
        
        {{
        ESLVal _v1676 = v1;
        while(_v1676.isCons()) {
          ESLVal e = _v1676.headVal;
          walkAST(e);
          _v1676 = _v1676.tailVal;}
      }
      return $null;}
      }
      }
      }
    case "Become": {ESLVal $2755 = _v1656.termRef(0);
        ESLVal $2754 = _v1656.termRef(1);
        
        {ESLVal v0 = $2755;
        
        {ESLVal v1 = $2754;
        
        return walkAST(v1);
      }
      }
      }
    case "BinExp": {ESLVal $2753 = _v1656.termRef(0);
        ESLVal $2752 = _v1656.termRef(1);
        ESLVal $2751 = _v1656.termRef(2);
        ESLVal $2750 = _v1656.termRef(3);
        
        {ESLVal v0 = $2753;
        
        {ESLVal v1 = $2752;
        
        {ESLVal v2 = $2751;
        
        {ESLVal v3 = $2750;
        
        {walkAST(v1);
      return walkAST(v3);}
      }
      }
      }
      }
      }
    case "Block": {ESLVal $2749 = _v1656.termRef(0);
        ESLVal $2748 = _v1656.termRef(1);
        
        {ESLVal v0 = $2749;
        
        {ESLVal v1 = $2748;
        
        {{
        ESLVal _v1675 = v1;
        while(_v1675.isCons()) {
          ESLVal e = _v1675.headVal;
          walkAST(e);
          _v1675 = _v1675.tailVal;}
      }
      return $null;}
      }
      }
      }
    case "BoolExp": {ESLVal $2747 = _v1656.termRef(0);
        ESLVal $2746 = _v1656.termRef(1);
        
        {ESLVal v0 = $2747;
        
        {ESLVal v1 = $2746;
        
        return $null;
      }
      }
      }
    case "Case": {ESLVal $2745 = _v1656.termRef(0);
        ESLVal $2744 = _v1656.termRef(1);
        ESLVal $2743 = _v1656.termRef(2);
        ESLVal $2742 = _v1656.termRef(3);
        
        {ESLVal v0 = $2745;
        
        {ESLVal v1 = $2744;
        
        {ESLVal v2 = $2743;
        
        {ESLVal v3 = $2742;
        
        {{
        ESLVal _v1672 = v1;
        while(_v1672.isCons()) {
          ESLVal d = _v1672.headVal;
          walkTDec(d);
          _v1672 = _v1672.tailVal;}
      }
      {
        ESLVal _v1673 = v2;
        while(_v1673.isCons()) {
          ESLVal e = _v1673.headVal;
          walkAST(e);
          _v1673 = _v1673.tailVal;}
      }
      {{
        ESLVal _v1674 = v3;
        while(_v1674.isCons()) {
          ESLVal a = _v1674.headVal;
          walkArm(a);
          _v1674 = _v1674.tailVal;}
      }
      return $null;}}
      }
      }
      }
      }
      }
    case "Cmp": {ESLVal $2741 = _v1656.termRef(0);
        ESLVal $2740 = _v1656.termRef(1);
        ESLVal $2739 = _v1656.termRef(2);
        
        {ESLVal v0 = $2741;
        
        {ESLVal v1 = $2740;
        
        {ESLVal v2 = $2739;
        
        {walkAST(v1);
      {{
        ESLVal _v1671 = v2;
        while(_v1671.isCons()) {
          ESLVal q = _v1671.headVal;
          walkQualifier(q);
          _v1671 = _v1671.tailVal;}
      }
      return $null;}}
      }
      }
      }
      }
    case "Cons": {ESLVal $2738 = _v1656.termRef(0);
        ESLVal $2737 = _v1656.termRef(1);
        
        {ESLVal v0 = $2738;
        
        {ESLVal v1 = $2737;
        
        {walkAST(v0);
      return walkAST(v1);}
      }
      }
      }
    case "For": {ESLVal $2736 = _v1656.termRef(0);
        ESLVal $2735 = _v1656.termRef(1);
        ESLVal $2734 = _v1656.termRef(2);
        ESLVal $2733 = _v1656.termRef(3);
        
        {ESLVal v0 = $2736;
        
        {ESLVal v1 = $2735;
        
        {ESLVal v2 = $2734;
        
        {ESLVal v3 = $2733;
        
        {walkPattern(v1);
      walkAST(v2);
      return walkAST(v3);}
      }
      }
      }
      }
      }
    case "FunExp": {ESLVal $2732 = _v1656.termRef(0);
        ESLVal $2731 = _v1656.termRef(1);
        ESLVal $2730 = _v1656.termRef(2);
        ESLVal $2729 = _v1656.termRef(3);
        ESLVal $2728 = _v1656.termRef(4);
        
        {ESLVal l = $2732;
        
        {ESLVal name = $2731;
        
        {ESLVal args = $2730;
        
        {ESLVal t = $2729;
        
        {ESLVal body = $2728;
        
        {ESLVal usedNames = freeVars.apply(body);
        
        {{
        ESLVal _v1670 = args;
        while(_v1670.isCons()) {
          ESLVal d = _v1670.headVal;
          {if(member.apply(decName.apply(d),usedNames).not().boolVal)
            addWarning(decLoc.apply(d),decName.apply(d).add(new ESLVal(" is not used in the function body.")));
            else
              {}
          walkTDec(d);}
          _v1670 = _v1670.tailVal;}
      }
      walkAST(name);
      return walkAST(body);}
      }
      }
      }
      }
      }
      }
      }
    case "Grab": {ESLVal $2727 = _v1656.termRef(0);
        ESLVal $2726 = _v1656.termRef(1);
        ESLVal $2725 = _v1656.termRef(2);
        
        {ESLVal v0 = $2727;
        
        {ESLVal v1 = $2726;
        
        {ESLVal v2 = $2725;
        
        {{
        ESLVal _v1669 = v1;
        while(_v1669.isCons()) {
          ESLVal d = _v1669.headVal;
          walkDRef(d);
          _v1669 = _v1669.tailVal;}
      }
      return walkAST(v2);}
      }
      }
      }
      }
    case "If": {ESLVal $2724 = _v1656.termRef(0);
        ESLVal $2723 = _v1656.termRef(1);
        ESLVal $2722 = _v1656.termRef(2);
        ESLVal $2721 = _v1656.termRef(3);
        
        {ESLVal v0 = $2724;
        
        {ESLVal v1 = $2723;
        
        {ESLVal v2 = $2722;
        
        {ESLVal v3 = $2721;
        
        {walkAST(v1);
      walkAST(v2);
      return walkAST(v3);}
      }
      }
      }
      }
      }
    case "IntExp": {ESLVal $2720 = _v1656.termRef(0);
        ESLVal $2719 = _v1656.termRef(1);
        
        {ESLVal v0 = $2720;
        
        {ESLVal v1 = $2719;
        
        return $null;
      }
      }
      }
    case "FloatExp": {ESLVal $2718 = _v1656.termRef(0);
        ESLVal $2717 = _v1656.termRef(1);
        
        {ESLVal v0 = $2718;
        
        {ESLVal v1 = $2717;
        
        return $null;
      }
      }
      }
    case "Fold": {ESLVal $2716 = _v1656.termRef(0);
        ESLVal $2715 = _v1656.termRef(1);
        ESLVal $2714 = _v1656.termRef(2);
        
        {ESLVal v0 = $2716;
        
        {ESLVal v1 = $2715;
        
        {ESLVal v2 = $2714;
        
        return walkAST(v2);
      }
      }
      }
      }
    case "Head": {ESLVal $2713 = _v1656.termRef(0);
        
        {ESLVal v0 = $2713;
        
        return walkAST(v0);
      }
      }
    case "Let": {ESLVal $2712 = _v1656.termRef(0);
        ESLVal $2711 = _v1656.termRef(1);
        ESLVal $2710 = _v1656.termRef(2);
        
        {ESLVal l = $2712;
        
        {ESLVal bindings = $2711;
        
        {ESLVal body = $2710;
        
        {ESLVal usedNames = freeVars.apply(body);
        
        {{
        ESLVal _v1668 = bindings;
        while(_v1668.isCons()) {
          ESLVal b = _v1668.headVal;
          {if(member.apply(bindingName.apply(b),usedNames).not().boolVal)
            addWarning(bindingLoc.apply(b),bindingName.apply(b).add(new ESLVal(" is not used in the let body.")));
            else
              {}
          walkTBind(b);}
          _v1668 = _v1668.tailVal;}
      }
      return walkAST(body);}
      }
      }
      }
      }
      }
    case "Letrec": {ESLVal $2709 = _v1656.termRef(0);
        ESLVal $2708 = _v1656.termRef(1);
        ESLVal $2707 = _v1656.termRef(2);
        
        {ESLVal l = $2709;
        
        {ESLVal bindings = $2708;
        
        {ESLVal body = $2707;
        
        {ESLVal usedNames = freeVars.apply(body).add(new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal b = $l0.head();
                $l0 = $l0.tail();
                ESLVal $l1 = bindingFV.apply(b);
          while(!$l1.isNil()) {
            ESLVal n = $l1.head();
            $l1 = $l1.tail();
            $v.add(n);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(bindings));
        
        {{
        ESLVal _v1667 = bindings;
        while(_v1667.isCons()) {
          ESLVal b = _v1667.headVal;
          {if(member.apply(bindingName.apply(b),usedNames).not().boolVal)
            addWarning(bindingLoc.apply(b),bindingName.apply(b).add(new ESLVal(" is not used in the letrec body.")));
            else
              {}
          walkTBind(b);}
          _v1667 = _v1667.tailVal;}
      }
      return walkAST(body);}
      }
      }
      }
      }
      }
    case "List": {ESLVal $2706 = _v1656.termRef(0);
        ESLVal $2705 = _v1656.termRef(1);
        
        {ESLVal v0 = $2706;
        
        {ESLVal v1 = $2705;
        
        {{
        ESLVal _v1666 = v1;
        while(_v1666.isCons()) {
          ESLVal e = _v1666.headVal;
          walkAST(e);
          _v1666 = _v1666.tailVal;}
      }
      return $null;}
      }
      }
      }
    case "Module": {ESLVal $2704 = _v1656.termRef(0);
        ESLVal $2703 = _v1656.termRef(1);
        ESLVal $2702 = _v1656.termRef(2);
        ESLVal $2701 = _v1656.termRef(3);
        ESLVal $2700 = _v1656.termRef(4);
        ESLVal $2699 = _v1656.termRef(5);
        ESLVal $2698 = _v1656.termRef(6);
        
        {ESLVal path = $2704;
        
        {ESLVal name = $2703;
        
        {ESLVal exports = $2702;
        
        {ESLVal imports = $2701;
        
        {ESLVal v4 = $2700;
        
        {ESLVal v5 = $2699;
        
        {ESLVal defs = $2698;
        
        {ESLVal usedNames = new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal b = $l0.head();
                $l0 = $l0.tail();
                ESLVal $l1 = bindingFV.apply(b);
          while(!$l1.isNil()) {
            ESLVal n = $l1.head();
            $l1 = $l1.tail();
            $v.add(n);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(defs).add(exports);
        
        {{
        ESLVal _v1664 = defs;
        while(_v1664.isCons()) {
          ESLVal b = _v1664.headVal;
          if(isBinding.apply(b).or(isFunBind.apply(b)).boolVal)
            if(member.apply(bindingName.apply(b),usedNames).not().boolVal)
              addWarning(bindingLoc.apply(b),bindingName.apply(b).add(new ESLVal(" is not used or exported.")));
              else
                {}
            else
              {}
          _v1664 = _v1664.tailVal;}
      }
      {{
        ESLVal _v1665 = defs;
        while(_v1665.isCons()) {
          ESLVal b = _v1665.headVal;
          walkTBind(b);
          _v1665 = _v1665.tailVal;}
      }
      return $null;}}
      }
      }
      }
      }
      }
      }
      }
      }
      }
    case "New": {ESLVal $2697 = _v1656.termRef(0);
        ESLVal $2696 = _v1656.termRef(1);
        ESLVal $2695 = _v1656.termRef(2);
        
        {ESLVal v0 = $2697;
        
        {ESLVal v1 = $2696;
        
        {ESLVal v2 = $2695;
        
        {walkAST(v1);
      {{
        ESLVal _v1663 = v2;
        while(_v1663.isCons()) {
          ESLVal e = _v1663.headVal;
          walkAST(e);
          _v1663 = _v1663.tailVal;}
      }
      return $null;}}
      }
      }
      }
      }
    case "NewArray": {ESLVal $2694 = _v1656.termRef(0);
        ESLVal $2693 = _v1656.termRef(1);
        ESLVal $2692 = _v1656.termRef(2);
        
        {ESLVal v0 = $2694;
        
        {ESLVal v1 = $2693;
        
        {ESLVal v2 = $2692;
        
        return walkAST(v2);
      }
      }
      }
      }
    case "NewJava": {ESLVal $2691 = _v1656.termRef(0);
        ESLVal $2690 = _v1656.termRef(1);
        ESLVal $2689 = _v1656.termRef(2);
        ESLVal $2688 = _v1656.termRef(3);
        
        {ESLVal v0 = $2691;
        
        {ESLVal v1 = $2690;
        
        {ESLVal v2 = $2689;
        
        {ESLVal v3 = $2688;
        
        {{
        ESLVal _v1662 = v3;
        while(_v1662.isCons()) {
          ESLVal e = _v1662.headVal;
          walkAST(e);
          _v1662 = _v1662.tailVal;}
      }
      return $null;}
      }
      }
      }
      }
      }
    case "NewTable": {ESLVal $2687 = _v1656.termRef(0);
        ESLVal $2686 = _v1656.termRef(1);
        ESLVal $2685 = _v1656.termRef(2);
        
        {ESLVal v0 = $2687;
        
        {ESLVal v1 = $2686;
        
        {ESLVal v2 = $2685;
        
        return $null;
      }
      }
      }
      }
    case "Not": {ESLVal $2684 = _v1656.termRef(0);
        ESLVal $2683 = _v1656.termRef(1);
        
        {ESLVal v0 = $2684;
        
        {ESLVal v1 = $2683;
        
        return walkAST(v1);
      }
      }
      }
    case "Now": {ESLVal $2682 = _v1656.termRef(0);
        
        {ESLVal v0 = $2682;
        
        return $null;
      }
      }
    case "NullExp": {ESLVal $2681 = _v1656.termRef(0);
        
        {ESLVal v0 = $2681;
        
        return $null;
      }
      }
    case "PLet": {ESLVal $2680 = _v1656.termRef(0);
        ESLVal $2679 = _v1656.termRef(1);
        ESLVal $2678 = _v1656.termRef(2);
        
        {ESLVal v0 = $2680;
        
        {ESLVal v1 = $2679;
        
        {ESLVal v2 = $2678;
        
        {{
        ESLVal _v1661 = v1;
        while(_v1661.isCons()) {
          ESLVal b = _v1661.headVal;
          walkTBind(b);
          _v1661 = _v1661.tailVal;}
      }
      return walkAST(v2);}
      }
      }
      }
      }
    case "Probably": {ESLVal $2677 = _v1656.termRef(0);
        ESLVal $2676 = _v1656.termRef(1);
        ESLVal $2675 = _v1656.termRef(2);
        ESLVal $2674 = _v1656.termRef(3);
        ESLVal $2673 = _v1656.termRef(4);
        
        {ESLVal v0 = $2677;
        
        {ESLVal v1 = $2676;
        
        {ESLVal v2 = $2675;
        
        {ESLVal v3 = $2674;
        
        {ESLVal v4 = $2673;
        
        {walkAST(v1);
      walkAST(v3);
      return walkAST(v4);}
      }
      }
      }
      }
      }
      }
    case "Record": {ESLVal $2672 = _v1656.termRef(0);
        ESLVal $2671 = _v1656.termRef(1);
        
        {ESLVal v0 = $2672;
        
        {ESLVal v1 = $2671;
        
        {{
        ESLVal _v1660 = v1;
        while(_v1660.isCons()) {
          ESLVal b = _v1660.headVal;
          walkTBind(b);
          _v1660 = _v1660.tailVal;}
      }
      return $null;}
      }
      }
      }
    case "RefSuper": {ESLVal $2670 = _v1656.termRef(0);
        ESLVal $2669 = _v1656.termRef(1);
        
        {ESLVal v0 = $2670;
        
        {ESLVal v1 = $2669;
        
        return $null;
      }
      }
      }
    case "Ref": {ESLVal $2668 = _v1656.termRef(0);
        ESLVal $2667 = _v1656.termRef(1);
        ESLVal $2666 = _v1656.termRef(2);
        
        {ESLVal v0 = $2668;
        
        {ESLVal v1 = $2667;
        
        {ESLVal v2 = $2666;
        
        return walkAST(v1);
      }
      }
      }
      }
    case "Self": {ESLVal $2665 = _v1656.termRef(0);
        
        {ESLVal v0 = $2665;
        
        return $null;
      }
      }
    case "Send": {ESLVal $2664 = _v1656.termRef(0);
        ESLVal $2663 = _v1656.termRef(1);
        ESLVal $2662 = _v1656.termRef(2);
        
        {ESLVal v0 = $2664;
        
        {ESLVal v1 = $2663;
        
        {ESLVal v2 = $2662;
        
        {walkAST(v1);
      return walkAST(v2);}
      }
      }
      }
      }
    case "SendSuper": {ESLVal $2661 = _v1656.termRef(0);
        ESLVal $2660 = _v1656.termRef(1);
        
        {ESLVal v0 = $2661;
        
        {ESLVal v1 = $2660;
        
        return walkAST(v1);
      }
      }
      }
    case "SendTimeSuper": {ESLVal $2659 = _v1656.termRef(0);
        
        {ESLVal v0 = $2659;
        
        return $null;
      }
      }
    case "SetExp": {ESLVal $2658 = _v1656.termRef(0);
        ESLVal $2657 = _v1656.termRef(1);
        
        {ESLVal v0 = $2658;
        
        {ESLVal v1 = $2657;
        
        {{
        ESLVal _v1659 = v1;
        while(_v1659.isCons()) {
          ESLVal e = _v1659.headVal;
          walkAST(e);
          _v1659 = _v1659.tailVal;}
      }
      return $null;}
      }
      }
      }
    case "StrExp": {ESLVal $2656 = _v1656.termRef(0);
        ESLVal $2655 = _v1656.termRef(1);
        
        {ESLVal v0 = $2656;
        
        {ESLVal v1 = $2655;
        
        return $null;
      }
      }
      }
    case "Tail": {ESLVal $2654 = _v1656.termRef(0);
        
        {ESLVal v0 = $2654;
        
        return walkAST(v0);
      }
      }
    case "Term": {ESLVal $2653 = _v1656.termRef(0);
        ESLVal $2652 = _v1656.termRef(1);
        ESLVal $2651 = _v1656.termRef(2);
        ESLVal $2650 = _v1656.termRef(3);
        
        {ESLVal v0 = $2653;
        
        {ESLVal v1 = $2652;
        
        {ESLVal v2 = $2651;
        
        {ESLVal v3 = $2650;
        
        {{
        ESLVal _v1658 = v3;
        while(_v1658.isCons()) {
          ESLVal termArg = _v1658.headVal;
          walkAST(termArg);
          _v1658 = _v1658.tailVal;}
      }
      return $null;}
      }
      }
      }
      }
      }
    case "TermRef": {ESLVal $2649 = _v1656.termRef(0);
        ESLVal $2648 = _v1656.termRef(1);
        
        {ESLVal v0 = $2649;
        
        {ESLVal v1 = $2648;
        
        return walkAST(v0);
      }
      }
      }
    case "Throw": {ESLVal $2647 = _v1656.termRef(0);
        ESLVal $2646 = _v1656.termRef(1);
        ESLVal $2645 = _v1656.termRef(2);
        
        {ESLVal v0 = $2647;
        
        {ESLVal v1 = $2646;
        
        {ESLVal v2 = $2645;
        
        return walkAST(v2);
      }
      }
      }
      }
    case "Try": {ESLVal $2644 = _v1656.termRef(0);
        ESLVal $2643 = _v1656.termRef(1);
        ESLVal $2642 = _v1656.termRef(2);
        
        {ESLVal v0 = $2644;
        
        {ESLVal v1 = $2643;
        
        {ESLVal v2 = $2642;
        
        {walkAST(v1);
      {{
        ESLVal _v1657 = v2;
        while(_v1657.isCons()) {
          ESLVal a = _v1657.headVal;
          walkArm(a);
          _v1657 = _v1657.tailVal;}
      }
      return $null;}}
      }
      }
      }
      }
    case "Update": {ESLVal $2641 = _v1656.termRef(0);
        ESLVal $2640 = _v1656.termRef(1);
        ESLVal $2639 = _v1656.termRef(2);
        
        {ESLVal v0 = $2641;
        
        {ESLVal v1 = $2640;
        
        {ESLVal v2 = $2639;
        
        return walkAST(v2);
      }
      }
      }
      }
    case "Unfold": {ESLVal $2638 = _v1656.termRef(0);
        ESLVal $2637 = _v1656.termRef(1);
        ESLVal $2636 = _v1656.termRef(2);
        
        {ESLVal v0 = $2638;
        
        {ESLVal v1 = $2637;
        
        {ESLVal v2 = $2636;
        
        return walkAST(v2);
      }
      }
      }
      }
    case "Var": {ESLVal $2635 = _v1656.termRef(0);
        ESLVal $2634 = _v1656.termRef(1);
        
        {ESLVal v0 = $2635;
        
        {ESLVal v1 = $2634;
        
        return $null;
      }
      }
      }
      default: {ESLVal _v1681 = _v1656;
        
        return print.apply(new ESLVal("unknown expression: ").add(_v1681));
      }
    }
    }
  }
  private static ESLVal walkAST = new ESLVal(new Function(new ESLVal("walkAST"),null) { public ESLVal apply(ESLVal... args) { return walkAST(args[0]); }});

public static void main(String[] args) {
  }
}