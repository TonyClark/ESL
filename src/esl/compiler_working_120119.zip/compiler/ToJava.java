package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
import static esl.Tables.*;
// import static esl.Lists.*;
import static esl.compiler.Cases.*;
import static esl.compiler.Types.*;
import static esl.compiler.Typeinfo.*;
import java.util.function.Supplier;
public class ToJava {
  public static ESLVal getSelf() { return $null; }
  private static ESLVal defToField(ESLVal d) {
    
    {ESLVal _v1693 = d;
      
      switch(_v1693.termName) {
      case "Binding": {ESLVal $2991 = _v1693.termRef(0);
        ESLVal $2990 = _v1693.termRef(1);
        ESLVal $2989 = _v1693.termRef(2);
        ESLVal $2988 = _v1693.termRef(3);
        ESLVal $2987 = _v1693.termRef(4);
        
        {ESLVal l = $2991;
        
        {ESLVal n = $2990;
        
        {ESLVal t = $2989;
        
        {ESLVal st = $2988;
        
        {ESLVal e = $2987;
        
        return new ESLVal("JField",n,$null,expToJExp(e));
      }
      }
      }
      }
      }
      }
    case "FunBind": {ESLVal $2984 = _v1693.termRef(0);
        ESLVal $2983 = _v1693.termRef(1);
        ESLVal $2982 = _v1693.termRef(2);
        ESLVal $2981 = _v1693.termRef(3);
        ESLVal $2980 = _v1693.termRef(4);
        ESLVal $2979 = _v1693.termRef(5);
        ESLVal $2978 = _v1693.termRef(6);
        
        switch($2978.termName) {
        case "BoolExp": {ESLVal $2986 = $2978.termRef(0);
          ESLVal $2985 = $2978.termRef(1);
          
          switch($2985.boolVal ? 1 : 0) {
          case 1: {ESLVal l = $2984;
            
            {ESLVal n = $2983;
            
            {ESLVal args = $2982;
            
            {ESLVal t = $2981;
            
            {ESLVal st = $2980;
            
            {ESLVal e = $2979;
            
            {ESLVal bl = $2986;
            
            {ESLVal formals = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v1694 = $qualArg;
                    
                    switch(_v1694.termName) {
                    case "PVar": {ESLVal $2994 = _v1694.termRef(0);
                      ESLVal $2993 = _v1694.termRef(1);
                      ESLVal $2992 = _v1694.termRef(2);
                      
                      {ESLVal _v1852 = $2994;
                      
                      {ESLVal _v1853 = $2993;
                      
                      {ESLVal _v1854 = $2992;
                      
                      return ESLVal.list(ESLVal.list(new ESLVal("Dec",_v1852,_v1853,_v1854,st)));
                    }
                    }
                    }
                    }
                    default: {ESLVal _0 = _v1694;
                      
                      return ESLVal.list();
                    }
                  }
                  }
                }
              }).map(args).flatten().flatten();
            
            return new ESLVal("JField",n,$null,expToJExp(new ESLVal("FunExp",l,new ESLVal("StrExp",l,n),formals,t,e)));
          }
          }
          }
          }
          }
          }
          }
          }
          default: {ESLVal l = $2984;
            
            {ESLVal n = $2983;
            
            {ESLVal args = $2982;
            
            {ESLVal t = $2981;
            
            {ESLVal st = $2980;
            
            {ESLVal e = $2979;
            
            {ESLVal g = $2978;
            
            {ESLVal formals = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v1695 = $qualArg;
                    
                    switch(_v1695.termName) {
                    case "PVar": {ESLVal $2997 = _v1695.termRef(0);
                      ESLVal $2996 = _v1695.termRef(1);
                      ESLVal $2995 = _v1695.termRef(2);
                      
                      {ESLVal _v1855 = $2997;
                      
                      {ESLVal _v1856 = $2996;
                      
                      {ESLVal _v1857 = $2995;
                      
                      return ESLVal.list(ESLVal.list(new ESLVal("Dec",_v1855,_v1856,_v1857,st)));
                    }
                    }
                    }
                    }
                    default: {ESLVal _0 = _v1695;
                      
                      return ESLVal.list();
                    }
                  }
                  }
                }
              }).map(args).flatten().flatten();
            
            return new ESLVal("JField",n,$null,expToJExp(new ESLVal("FunExp",l,new ESLVal("StrExp",l,n),formals,t,new ESLVal("If",l,g,e,new ESLVal("Throw",l,t,new ESLVal("StrExp",l,new ESLVal("guard failed for ").add(n)))))));
          }
          }
          }
          }
          }
          }
          }
          }
        }
        }
        default: {ESLVal l = $2984;
          
          {ESLVal n = $2983;
          
          {ESLVal args = $2982;
          
          {ESLVal t = $2981;
          
          {ESLVal st = $2980;
          
          {ESLVal e = $2979;
          
          {ESLVal g = $2978;
          
          {ESLVal formals = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v1696 = $qualArg;
                  
                  switch(_v1696.termName) {
                  case "PVar": {ESLVal $3000 = _v1696.termRef(0);
                    ESLVal $2999 = _v1696.termRef(1);
                    ESLVal $2998 = _v1696.termRef(2);
                    
                    {ESLVal _v1858 = $3000;
                    
                    {ESLVal _v1859 = $2999;
                    
                    {ESLVal _v1860 = $2998;
                    
                    return ESLVal.list(ESLVal.list(new ESLVal("Dec",_v1858,_v1859,_v1860,st)));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v1696;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(args).flatten().flatten();
          
          return new ESLVal("JField",n,$null,expToJExp(new ESLVal("FunExp",l,new ESLVal("StrExp",l,n),formals,t,new ESLVal("If",l,g,e,new ESLVal("Throw",l,t,new ESLVal("StrExp",l,new ESLVal("guard failed for ").add(n)))))));
        }
        }
        }
        }
        }
        }
        }
        }
      }
      }
      default: return error(new ESLVal("case error at Pos(1507,2160)").add(ESLVal.list(_v1693)));
    }
    }
  }
  private static ESLVal defToField = new ESLVal(new Function(new ESLVal("defToField"),null) { public ESLVal apply(ESLVal... args) { return defToField(args[0]); }});
  private static ESLVal defToMethod(ESLVal d) {
    
    {ESLVal _v1697 = d;
      
      switch(_v1697.termName) {
      case "FunBind": {ESLVal $3007 = _v1697.termRef(0);
        ESLVal $3006 = _v1697.termRef(1);
        ESLVal $3005 = _v1697.termRef(2);
        ESLVal $3004 = _v1697.termRef(3);
        ESLVal $3003 = _v1697.termRef(4);
        ESLVal $3002 = _v1697.termRef(5);
        ESLVal $3001 = _v1697.termRef(6);
        
        {ESLVal l = $3007;
        
        {ESLVal n = $3006;
        
        {ESLVal args = $3005;
        
        {ESLVal t = $3004;
        
        {ESLVal st = $3003;
        
        {ESLVal body = $3002;
        
        {ESLVal guard = $3001;
        
        {ESLVal formals = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1698 = $qualArg;
                
                switch(_v1698.termName) {
                case "PVar": {ESLVal $3010 = _v1698.termRef(0);
                  ESLVal $3009 = _v1698.termRef(1);
                  ESLVal $3008 = _v1698.termRef(2);
                  
                  {ESLVal _v1848 = $3010;
                  
                  {ESLVal _v1849 = $3009;
                  
                  {ESLVal _v1850 = $3008;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JDec",_v1849,$null)));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1698;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(args).flatten().flatten();
        
        return new ESLVal("JMethod",n,formals,expToJCommand(body,$true));
      }
      }
      }
      }
      }
      }
      }
      }
      }
      default: {ESLVal _v1851 = _v1697;
        
        return error(new ESLVal("cannot transform definition ").add(_v1851.add(new ESLVal(" to a method"))));
      }
    }
    }
  }
  private static ESLVal defToMethod = new ESLVal(new Function(new ESLVal("defToMethod"),null) { public ESLVal apply(ESLVal... args) { return defToMethod(args[0]); }});
  private static ESLVal decToJDec(ESLVal d) {
    
    {ESLVal _v1699 = d;
      
      switch(_v1699.termName) {
      case "Dec": {ESLVal $3014 = _v1699.termRef(0);
        ESLVal $3013 = _v1699.termRef(1);
        ESLVal $3012 = _v1699.termRef(2);
        ESLVal $3011 = _v1699.termRef(3);
        
        {ESLVal l = $3014;
        
        {ESLVal n = $3013;
        
        {ESLVal t = $3012;
        
        {ESLVal st = $3011;
        
        return new ESLVal("JDec",n,$null);
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(2538,2614)").add(ESLVal.list(_v1699)));
    }
    }
  }
  private static ESLVal decToJDec = new ESLVal(new Function(new ESLVal("decToJDec"),null) { public ESLVal apply(ESLVal... args) { return decToJDec(args[0]); }});
  private static ESLVal expsToJCommands(ESLVal cs,ESLVal isLast) {
    
    {ESLVal _v1700 = cs;
      
      if(_v1700.isCons())
      {ESLVal $3015 = _v1700.head();
        ESLVal $3016 = _v1700.tail();
        
        if($3016.isCons())
        {ESLVal $3017 = $3016.head();
          ESLVal $3018 = $3016.tail();
          
          {ESLVal c = $3015;
          
          {ESLVal _v1846 = $3016;
          
          return expsToJCommands(_v1846,isLast).cons(expToJCommand(c,$false));
        }
        }
        }
      else if($3016.isNil())
        {ESLVal c = $3015;
          
          return ESLVal.list(expToJCommand(c,isLast));
        }
      else {ESLVal c = $3015;
          
          {ESLVal _v1847 = $3016;
          
          return expsToJCommands(_v1847,isLast).cons(expToJCommand(c,$false));
        }
        }
      }
    else if(_v1700.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(2673,2833)").add(ESLVal.list(_v1700)));
    }
  }
  private static ESLVal expsToJCommands = new ESLVal(new Function(new ESLVal("expsToJCommands"),null) { public ESLVal apply(ESLVal... args) { return expsToJCommands(args[0],args[1]); }});
  private static ESLVal expToJCommand(ESLVal c,ESLVal isLast) {
    
    {ESLVal _v1701 = c;
      
      switch(_v1701.termName) {
      case "Block": {ESLVal $3064 = _v1701.termRef(0);
        ESLVal $3063 = _v1701.termRef(1);
        
        if($3063.isCons())
        {ESLVal $3065 = $3063.head();
          ESLVal $3066 = $3063.tail();
          
          if($3066.isCons())
          {ESLVal $3067 = $3066.head();
            ESLVal $3068 = $3066.tail();
            
            {ESLVal l = $3064;
            
            {ESLVal es = $3063;
            
            return new ESLVal("JBlock",new java.util.function.Function<ESLVal,ESLVal>() {
              public ESLVal apply(ESLVal $l0) {
                ESLVal $a = $nil;
                java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                while(!$l0.isNil()) { 
                  ESLVal e = $l0.head();
                  $l0 = $l0.tail();
                  $v.add(expToJCommand(e,$false));
                }
                for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                return $a;
              }}.apply(butlast.apply(es)).add(ESLVal.list(expToJCommand(last.apply(es),isLast))));
          }
          }
          }
        else if($3066.isNil())
          {ESLVal l = $3064;
            
            {ESLVal e = $3065;
            
            return expToJCommand(e,isLast);
          }
          }
        else {ESLVal l = $3064;
            
            {ESLVal es = $3063;
            
            return new ESLVal("JBlock",new java.util.function.Function<ESLVal,ESLVal>() {
              public ESLVal apply(ESLVal $l0) {
                ESLVal $a = $nil;
                java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                while(!$l0.isNil()) { 
                  ESLVal e = $l0.head();
                  $l0 = $l0.tail();
                  $v.add(expToJCommand(e,$false));
                }
                for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                return $a;
              }}.apply(butlast.apply(es)).add(ESLVal.list(expToJCommand(last.apply(es),isLast))));
          }
          }
        }
      else if($3063.isNil())
        {ESLVal l = $3064;
          
          if(isLast.boolVal)
          return new ESLVal("JReturn",new ESLVal("JNull",new ESLVal[]{}));
          else
            {ESLVal _v1844 = $3064;
              
              return new ESLVal("JBlock",$nil);
            }
        }
      else {ESLVal l = $3064;
          
          {ESLVal es = $3063;
          
          return new ESLVal("JBlock",new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal e = $l0.head();
                $l0 = $l0.tail();
                $v.add(expToJCommand(e,$false));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(butlast.apply(es)).add(ESLVal.list(expToJCommand(last.apply(es),isLast))));
        }
        }
      }
    case "Update": {ESLVal $3062 = _v1701.termRef(0);
        ESLVal $3061 = _v1701.termRef(1);
        ESLVal $3060 = _v1701.termRef(2);
        
        {ESLVal l = $3062;
        
        {ESLVal n = $3061;
        
        {ESLVal e = $3060;
        
        if(isLast.boolVal)
        return new ESLVal("JBlock",ESLVal.list(new ESLVal("JUpdate",n,expToJExp(e)),new ESLVal("JReturn",new ESLVal("JNull",new ESLVal[]{}))));
        else
          {ESLVal _v1841 = $3062;
            
            {ESLVal _v1842 = $3061;
            
            {ESLVal _v1843 = $3060;
            
            return new ESLVal("JUpdate",_v1842,expToJExp(_v1843));
          }
          }
          }
      }
      }
      }
      }
    case "If": {ESLVal $3059 = _v1701.termRef(0);
        ESLVal $3058 = _v1701.termRef(1);
        ESLVal $3057 = _v1701.termRef(2);
        ESLVal $3056 = _v1701.termRef(3);
        
        {ESLVal l = $3059;
        
        {ESLVal e1 = $3058;
        
        {ESLVal e2 = $3057;
        
        {ESLVal e3 = $3056;
        
        return new ESLVal("JIfCommand",expToJExp(e1),expToJCommand(e2,isLast),expToJCommand(e3,isLast));
      }
      }
      }
      }
      }
    case "CaseList": {ESLVal $3055 = _v1701.termRef(0);
        ESLVal $3054 = _v1701.termRef(1);
        ESLVal $3053 = _v1701.termRef(2);
        ESLVal $3052 = _v1701.termRef(3);
        ESLVal $3051 = _v1701.termRef(4);
        
        {ESLVal l = $3055;
        
        {ESLVal e = $3054;
        
        {ESLVal cons = $3053;
        
        {ESLVal nil = $3052;
        
        {ESLVal alt = $3051;
        
        return new ESLVal("JCaseList",expToJExp(e),expToJCommand(cons,isLast),expToJCommand(nil,isLast),expToJCommand(alt,isLast));
      }
      }
      }
      }
      }
      }
    case "CaseTerm": {ESLVal $3050 = _v1701.termRef(0);
        ESLVal $3049 = _v1701.termRef(1);
        ESLVal $3048 = _v1701.termRef(2);
        ESLVal $3047 = _v1701.termRef(3);
        
        {ESLVal l = $3050;
        
        {ESLVal e = $3049;
        
        {ESLVal arms = $3048;
        
        {ESLVal alt = $3047;
        
        return new ESLVal("JCaseTerm",expToJExp(e),termArmsToJTermArms(arms,isLast),expToJCommand(alt,isLast));
      }
      }
      }
      }
      }
    case "CaseInt": {ESLVal $3046 = _v1701.termRef(0);
        ESLVal $3045 = _v1701.termRef(1);
        ESLVal $3044 = _v1701.termRef(2);
        ESLVal $3043 = _v1701.termRef(3);
        
        {ESLVal l = $3046;
        
        {ESLVal e = $3045;
        
        {ESLVal arms = $3044;
        
        {ESLVal alt = $3043;
        
        return new ESLVal("JCaseInt",expToJExp(e),intArmsToJIntArms(arms,isLast),expToJCommand(alt,isLast));
      }
      }
      }
      }
      }
    case "CaseStr": {ESLVal $3042 = _v1701.termRef(0);
        ESLVal $3041 = _v1701.termRef(1);
        ESLVal $3040 = _v1701.termRef(2);
        ESLVal $3039 = _v1701.termRef(3);
        
        {ESLVal l = $3042;
        
        {ESLVal e = $3041;
        
        {ESLVal arms = $3040;
        
        {ESLVal alt = $3039;
        
        return new ESLVal("JCaseStr",expToJExp(e),strArmsToJStrArms(arms,isLast),expToJCommand(alt,isLast));
      }
      }
      }
      }
      }
    case "CaseBool": {ESLVal $3038 = _v1701.termRef(0);
        ESLVal $3037 = _v1701.termRef(1);
        ESLVal $3036 = _v1701.termRef(2);
        ESLVal $3035 = _v1701.termRef(3);
        
        {ESLVal l = $3038;
        
        {ESLVal e = $3037;
        
        {ESLVal arms = $3036;
        
        {ESLVal alt = $3035;
        
        return new ESLVal("JCaseBool",expToJExp(e),boolArmsToJBoolArms(arms,isLast),expToJCommand(alt,isLast));
      }
      }
      }
      }
      }
    case "Let": {ESLVal $3034 = _v1701.termRef(0);
        ESLVal $3033 = _v1701.termRef(1);
        ESLVal $3032 = _v1701.termRef(2);
        
        {ESLVal l = $3034;
        
        {ESLVal bs = $3033;
        
        {ESLVal e = $3032;
        
        return new ESLVal("JLet",new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              $v.add(defToField(b));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(bs),expToJCommand(e,isLast));
      }
      }
      }
      }
    case "Letrec": {ESLVal $3031 = _v1701.termRef(0);
        ESLVal $3030 = _v1701.termRef(1);
        ESLVal $3029 = _v1701.termRef(2);
        
        {ESLVal l = $3031;
        
        {ESLVal bs = $3030;
        
        {ESLVal e = $3029;
        
        return new ESLVal("JLetRec",new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              $v.add(defToField(b));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(bs),expToJCommand(e,$true));
      }
      }
      }
      }
    case "For": {ESLVal $3025 = _v1701.termRef(0);
        ESLVal $3024 = _v1701.termRef(1);
        ESLVal $3023 = _v1701.termRef(2);
        ESLVal $3022 = _v1701.termRef(3);
        
        switch($3024.termName) {
        case "PVar": {ESLVal $3028 = $3024.termRef(0);
          ESLVal $3027 = $3024.termRef(1);
          ESLVal $3026 = $3024.termRef(2);
          
          {ESLVal l1 = $3025;
          
          {ESLVal l2 = $3028;
          
          {ESLVal n = $3027;
          
          {ESLVal t = $3026;
          
          {ESLVal e = $3023;
          
          {ESLVal b = $3022;
          
          if(isLast.boolVal)
          return new ESLVal("JBlock",ESLVal.list(new ESLVal("JFor",newName(),n,expToJExp(e),expToJCommand(b,$false)),new ESLVal("JReturn",new ESLVal("JNull",new ESLVal[]{}))));
          else
            {ESLVal _v1835 = $3025;
              
              {ESLVal _v1836 = $3028;
              
              {ESLVal _v1837 = $3027;
              
              {ESLVal _v1838 = $3026;
              
              {ESLVal _v1839 = $3023;
              
              {ESLVal _v1840 = $3022;
              
              return new ESLVal("JFor",newName(),_v1837,expToJExp(_v1839),expToJCommand(_v1840,$false));
            }
            }
            }
            }
            }
            }
        }
        }
        }
        }
        }
        }
        }
        default: {ESLVal l = $3025;
          
          {ESLVal p = $3024;
          
          {ESLVal e = $3023;
          
          {ESLVal b = $3022;
          
          {ESLVal opName = newName();
          ESLVal varName = newName();
          
          return expToJCommand(new ESLVal("For",l,new ESLVal("PVar",l,varName,$null),e,new ESLVal("Let",l,ESLVal.list(new ESLVal("Binding",l,opName,$null,$null,new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("forp")),ESLVal.list(),$null,new ESLVal("Case",l,$nil,ESLVal.list(new ESLVal("Var",l,varName)),ESLVal.list(new ESLVal("BArm",l,ESLVal.list(p),new ESLVal("BoolExp",l,$true),b),new ESLVal("BArm",l,ESLVal.list(new ESLVal("PVar",l,new ESLVal("$$$"),$null)),new ESLVal("BoolExp",l,$true),new ESLVal("Block",l,ESLVal.list()))))))),new ESLVal("Apply",l,new ESLVal("Var",l,opName),ESLVal.list()))),isLast);
        }
        }
        }
        }
        }
      }
      }
    case "PLet": {ESLVal $3021 = _v1701.termRef(0);
        ESLVal $3020 = _v1701.termRef(1);
        ESLVal $3019 = _v1701.termRef(2);
        
        {ESLVal l = $3021;
        
        {ESLVal bs = $3020;
        
        {ESLVal e = $3019;
        
        return new ESLVal("JPLet",new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              $v.add(defToField(b));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(bs),expToJCommand(e,isLast));
      }
      }
      }
      }
      default: {ESLVal e = _v1701;
        
        if(isLast.boolVal)
        return new ESLVal("JReturn",expToJExp(e));
        else
          {ESLVal _v1845 = _v1701;
            
            return new ESLVal("JStatement",expToJExp(_v1845));
          }
      }
    }
    }
  }
  private static ESLVal expToJCommand = new ESLVal(new Function(new ESLVal("expToJCommand"),null) { public ESLVal apply(ESLVal... args) { return expToJCommand(args[0],args[1]); }});
  private static ESLVal expsToJExps(ESLVal es) {
    
    return map.apply(new ESLVal(new Function(new ESLVal("fun413"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal e = $args[0];
      return expToJExp(e);
        }
      }),es);
  }
  private static ESLVal expsToJExps = new ESLVal(new Function(new ESLVal("expsToJExps"),null) { public ESLVal apply(ESLVal... args) { return expsToJExps(args[0]); }});
  private static ESLVal termArmsToJTermArms(ESLVal arms,ESLVal isLast) {
    
    {ESLVal _v1702 = arms;
      
      if(_v1702.isCons())
      {ESLVal $3069 = _v1702.head();
        ESLVal $3070 = _v1702.tail();
        
        switch($3069.termName) {
        case "TArm": {ESLVal $3072 = $3069.termRef(0);
          ESLVal $3071 = $3069.termRef(1);
          
          {ESLVal n = $3072;
          
          {ESLVal e = $3071;
          
          {ESLVal _v1834 = $3070;
          
          return termArmsToJTermArms(_v1834,isLast).cons(new ESLVal("JTArm",n,$zero,expToJCommand(e,isLast)));
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(6168,6337)").add(ESLVal.list(_v1702)));
      }
      }
    else if(_v1702.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(6168,6337)").add(ESLVal.list(_v1702)));
    }
  }
  private static ESLVal termArmsToJTermArms = new ESLVal(new Function(new ESLVal("termArmsToJTermArms"),null) { public ESLVal apply(ESLVal... args) { return termArmsToJTermArms(args[0],args[1]); }});
  private static ESLVal intArmsToJIntArms(ESLVal arms,ESLVal isLast) {
    
    {ESLVal _v1703 = arms;
      
      if(_v1703.isCons())
      {ESLVal $3073 = _v1703.head();
        ESLVal $3074 = _v1703.tail();
        
        switch($3073.termName) {
        case "IArm": {ESLVal $3076 = $3073.termRef(0);
          ESLVal $3075 = $3073.termRef(1);
          
          {ESLVal n = $3076;
          
          {ESLVal e = $3075;
          
          {ESLVal _v1833 = $3074;
          
          return intArmsToJIntArms(_v1833,isLast).cons(new ESLVal("JIArm",n,expToJCommand(e,isLast)));
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(6406,6570)").add(ESLVal.list(_v1703)));
      }
      }
    else if(_v1703.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(6406,6570)").add(ESLVal.list(_v1703)));
    }
  }
  private static ESLVal intArmsToJIntArms = new ESLVal(new Function(new ESLVal("intArmsToJIntArms"),null) { public ESLVal apply(ESLVal... args) { return intArmsToJIntArms(args[0],args[1]); }});
  private static ESLVal strArmsToJStrArms(ESLVal arms,ESLVal isLast) {
    
    {ESLVal _v1704 = arms;
      
      if(_v1704.isCons())
      {ESLVal $3077 = _v1704.head();
        ESLVal $3078 = _v1704.tail();
        
        switch($3077.termName) {
        case "SArm": {ESLVal $3080 = $3077.termRef(0);
          ESLVal $3079 = $3077.termRef(1);
          
          {ESLVal s = $3080;
          
          {ESLVal e = $3079;
          
          {ESLVal _v1832 = $3078;
          
          return strArmsToJStrArms(_v1832,isLast).cons(new ESLVal("JSArm",s,expToJCommand(e,isLast)));
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(6639,6803)").add(ESLVal.list(_v1704)));
      }
      }
    else if(_v1704.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(6639,6803)").add(ESLVal.list(_v1704)));
    }
  }
  private static ESLVal strArmsToJStrArms = new ESLVal(new Function(new ESLVal("strArmsToJStrArms"),null) { public ESLVal apply(ESLVal... args) { return strArmsToJStrArms(args[0],args[1]); }});
  private static ESLVal boolArmsToJBoolArms(ESLVal arms,ESLVal isLast) {
    
    {ESLVal _v1705 = arms;
      
      if(_v1705.isCons())
      {ESLVal $3081 = _v1705.head();
        ESLVal $3082 = _v1705.tail();
        
        switch($3081.termName) {
        case "BoolArm": {ESLVal $3084 = $3081.termRef(0);
          ESLVal $3083 = $3081.termRef(1);
          
          {ESLVal b = $3084;
          
          {ESLVal e = $3083;
          
          {ESLVal _v1831 = $3082;
          
          return boolArmsToJBoolArms(_v1831,isLast).cons(new ESLVal("JBArm",b,expToJCommand(e,isLast)));
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(6878,7051)").add(ESLVal.list(_v1705)));
      }
      }
    else if(_v1705.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(6878,7051)").add(ESLVal.list(_v1705)));
    }
  }
  private static ESLVal boolArmsToJBoolArms = new ESLVal(new Function(new ESLVal("boolArmsToJBoolArms"),null) { public ESLVal apply(ESLVal... args) { return boolArmsToJBoolArms(args[0],args[1]); }});
  private static ESLVal opToJOp(ESLVal op) {
    
    {ESLVal _v1706 = op;
      
      switch(_v1706.strVal) {
      case "@": return new ESLVal("at");
    case "+": return new ESLVal("add");
    case "-": return new ESLVal("sub");
    case "*": return new ESLVal("mul");
    case "/": return new ESLVal("div");
    case "%": return new ESLVal("mod");
    case ">": return new ESLVal("gre");
    case ">=": return new ESLVal("greql");
    case "<": return new ESLVal("less");
    case "<=": return new ESLVal("lesseql");
    case "=": return new ESLVal("eql");
    case "<>": return new ESLVal("neql");
    case ":": return new ESLVal("cons");
    case "..": return new ESLVal("to");
    case "or": return new ESLVal("or");
    case "and": return new ESLVal("and");
    case "andalso": return new ESLVal("andalso");
    case "orelse": return new ESLVal("orelse");
      default: return error(new ESLVal("case error at Pos(7079,7448)").add(ESLVal.list(_v1706)));
    }
    }
  }
  private static ESLVal opToJOp = new ESLVal(new Function(new ESLVal("opToJOp"),null) { public ESLVal apply(ESLVal... args) { return opToJOp(args[0]); }});
  private static ESLVal caseToJExp(ESLVal l,ESLVal es,ESLVal arms) {
    
    {ESLVal bindings = new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(new ESLVal("Binding",l,newName(),$null,$null,e));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(es);
      
      {ESLVal names = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v1707 = $qualArg;
              
              switch(_v1707.termName) {
              case "Binding": {ESLVal $3089 = _v1707.termRef(0);
                ESLVal $3088 = _v1707.termRef(1);
                ESLVal $3087 = _v1707.termRef(2);
                ESLVal $3086 = _v1707.termRef(3);
                ESLVal $3085 = _v1707.termRef(4);
                
                {ESLVal _v1830 = $3089;
                
                {ESLVal n = $3088;
                
                {ESLVal dt = $3087;
                
                {ESLVal t = $3086;
                
                {ESLVal e = $3085;
                
                return ESLVal.list(ESLVal.list(n));
              }
              }
              }
              }
              }
              }
              default: {ESLVal _0 = _v1707;
                
                return ESLVal.list();
              }
            }
            }
          }
        }).map(bindings).flatten().flatten();
      
      return expToJExp(new ESLVal("Let",l,bindings,translateCases.apply(new ESLVal("Case",l,ESLVal.list(),new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal n = $l0.head();
            $l0 = $l0.tail();
            $v.add(new ESLVal("Var",l,n));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(names),arms))));
    }
    }
  }
  private static ESLVal caseToJExp = new ESLVal(new Function(new ESLVal("caseToJExp"),null) { public ESLVal apply(ESLVal... args) { return caseToJExp(args[0],args[1],args[2]); }});
  private static ESLVal expToJExp(ESLVal e) {
    
    {ESLVal _v1708 = e;
      
      switch(_v1708.termName) {
      case "Apply": {ESLVal $3274 = _v1708.termRef(0);
        ESLVal $3273 = _v1708.termRef(1);
        ESLVal $3272 = _v1708.termRef(2);
        
        {ESLVal l = $3274;
        
        {ESLVal op = $3273;
        
        {ESLVal args = $3272;
        
        return new ESLVal("JApply",expToJExp(op),expsToJExps(args));
      }
      }
      }
      }
    case "ArrayUpdate": {ESLVal $3271 = _v1708.termRef(0);
        ESLVal $3270 = _v1708.termRef(1);
        ESLVal $3269 = _v1708.termRef(2);
        ESLVal $3268 = _v1708.termRef(3);
        
        {ESLVal l = $3271;
        
        {ESLVal a = $3270;
        
        {ESLVal i = $3269;
        
        {ESLVal v = $3268;
        
        return new ESLVal("JArrayUpdate",expToJExp(a),expToJExp(i),expToJExp(v));
      }
      }
      }
      }
      }
    case "ArrayRef": {ESLVal $3267 = _v1708.termRef(0);
        ESLVal $3266 = _v1708.termRef(1);
        ESLVal $3265 = _v1708.termRef(2);
        
        {ESLVal l = $3267;
        
        {ESLVal a = $3266;
        
        {ESLVal i = $3265;
        
        return new ESLVal("JArrayRef",expToJExp(a),expToJExp(i));
      }
      }
      }
      }
    case "IntExp": {ESLVal $3264 = _v1708.termRef(0);
        ESLVal $3263 = _v1708.termRef(1);
        
        {ESLVal l = $3264;
        
        {ESLVal n = $3263;
        
        return new ESLVal("JConstExp",new ESLVal("JConstInt",n));
      }
      }
      }
    case "StrExp": {ESLVal $3262 = _v1708.termRef(0);
        ESLVal $3261 = _v1708.termRef(1);
        
        {ESLVal l = $3262;
        
        {ESLVal s = $3261;
        
        return new ESLVal("JConstExp",new ESLVal("JConstStr",s));
      }
      }
      }
    case "BoolExp": {ESLVal $3260 = _v1708.termRef(0);
        ESLVal $3259 = _v1708.termRef(1);
        
        {ESLVal l = $3260;
        
        {ESLVal b = $3259;
        
        return new ESLVal("JConstExp",new ESLVal("JConstBool",b));
      }
      }
      }
    case "FloatExp": {ESLVal $3258 = _v1708.termRef(0);
        ESLVal $3257 = _v1708.termRef(1);
        
        {ESLVal l = $3258;
        
        {ESLVal f = $3257;
        
        return new ESLVal("JConstExp",new ESLVal("JConstDouble",f));
      }
      }
      }
    case "ApplyTypeExp": {ESLVal $3243 = _v1708.termRef(0);
        ESLVal $3242 = _v1708.termRef(1);
        ESLVal $3241 = _v1708.termRef(2);
        
        switch($3242.termName) {
        case "List": {ESLVal $3250 = $3242.termRef(0);
          ESLVal $3249 = $3242.termRef(1);
          
          if($3249.isCons())
          {ESLVal $3251 = $3249.head();
            ESLVal $3252 = $3249.tail();
            
            {ESLVal l = $3243;
            
            {ESLVal _v1823 = $3242;
            
            {ESLVal ts = $3241;
            
            return expToJExp(_v1823);
          }
          }
          }
          }
        else if($3249.isNil())
          if($3241.isCons())
            {ESLVal $3253 = $3241.head();
              ESLVal $3254 = $3241.tail();
              
              if($3254.isCons())
              {ESLVal $3255 = $3254.head();
                ESLVal $3256 = $3254.tail();
                
                {ESLVal l = $3243;
                
                {ESLVal _v1824 = $3242;
                
                {ESLVal ts = $3241;
                
                return expToJExp(_v1824);
              }
              }
              }
              }
            else if($3254.isNil())
              {ESLVal l1 = $3243;
                
                {ESLVal l2 = $3250;
                
                {ESLVal t = $3253;
                
                return new ESLVal("JNil",$null);
              }
              }
              }
            else {ESLVal l = $3243;
                
                {ESLVal _v1825 = $3242;
                
                {ESLVal ts = $3241;
                
                return expToJExp(_v1825);
              }
              }
              }
            }
          else if($3241.isNil())
            {ESLVal l = $3243;
              
              {ESLVal _v1826 = $3242;
              
              {ESLVal ts = $3241;
              
              return expToJExp(_v1826);
            }
            }
            }
          else {ESLVal l = $3243;
              
              {ESLVal _v1827 = $3242;
              
              {ESLVal ts = $3241;
              
              return expToJExp(_v1827);
            }
            }
            }
        else {ESLVal l = $3243;
            
            {ESLVal _v1828 = $3242;
            
            {ESLVal ts = $3241;
            
            return expToJExp(_v1828);
          }
          }
          }
        }
      case "NullExp": {ESLVal $3244 = $3242.termRef(0);
          
          if($3241.isCons())
          {ESLVal $3245 = $3241.head();
            ESLVal $3246 = $3241.tail();
            
            if($3246.isCons())
            {ESLVal $3247 = $3246.head();
              ESLVal $3248 = $3246.tail();
              
              {ESLVal l = $3243;
              
              {ESLVal _v1819 = $3242;
              
              {ESLVal ts = $3241;
              
              return expToJExp(_v1819);
            }
            }
            }
            }
          else if($3246.isNil())
            {ESLVal l1 = $3243;
              
              {ESLVal l2 = $3244;
              
              {ESLVal t = $3245;
              
              return new ESLVal("JNull",new ESLVal[]{});
            }
            }
            }
          else {ESLVal l = $3243;
              
              {ESLVal _v1820 = $3242;
              
              {ESLVal ts = $3241;
              
              return expToJExp(_v1820);
            }
            }
            }
          }
        else if($3241.isNil())
          {ESLVal l = $3243;
            
            {ESLVal _v1821 = $3242;
            
            {ESLVal ts = $3241;
            
            return expToJExp(_v1821);
          }
          }
          }
        else {ESLVal l = $3243;
            
            {ESLVal _v1822 = $3242;
            
            {ESLVal ts = $3241;
            
            return expToJExp(_v1822);
          }
          }
          }
        }
        default: {ESLVal l = $3243;
          
          {ESLVal _v1829 = $3242;
          
          {ESLVal ts = $3241;
          
          return expToJExp(_v1829);
        }
        }
        }
      }
      }
    case "List": {ESLVal $3240 = _v1708.termRef(0);
        ESLVal $3239 = _v1708.termRef(1);
        
        {ESLVal l = $3240;
        
        {ESLVal es = $3239;
        
        return new ESLVal("JList",$null,expsToJExps(es));
      }
      }
      }
    case "SetExp": {ESLVal $3238 = _v1708.termRef(0);
        ESLVal $3237 = _v1708.termRef(1);
        
        {ESLVal l = $3238;
        
        {ESLVal es = $3237;
        
        return new ESLVal("JSet",$null,expsToJExps(es));
      }
      }
      }
    case "BagExp": {ESLVal $3236 = _v1708.termRef(0);
        ESLVal $3235 = _v1708.termRef(1);
        
        {ESLVal l = $3236;
        
        {ESLVal es = $3235;
        
        return new ESLVal("JBag",$null,expsToJExps(es));
      }
      }
      }
    case "Term": {ESLVal $3234 = _v1708.termRef(0);
        ESLVal $3233 = _v1708.termRef(1);
        ESLVal $3232 = _v1708.termRef(2);
        ESLVal $3231 = _v1708.termRef(3);
        
        {ESLVal l = $3234;
        
        {ESLVal n = $3233;
        
        {ESLVal ts = $3232;
        
        {ESLVal es = $3231;
        
        return new ESLVal("JTerm",n,expsToJExps(es));
      }
      }
      }
      }
      }
    case "Case": {ESLVal $3230 = _v1708.termRef(0);
        ESLVal $3229 = _v1708.termRef(1);
        ESLVal $3228 = _v1708.termRef(2);
        ESLVal $3227 = _v1708.termRef(3);
        
        {ESLVal l = $3230;
        
        {ESLVal ds = $3229;
        
        {ESLVal es = $3228;
        
        {ESLVal arms = $3227;
        
        return caseToJExp(l,es,arms);
      }
      }
      }
      }
      }
    case "CaseAdd": {ESLVal $3226 = _v1708.termRef(0);
        ESLVal $3225 = _v1708.termRef(1);
        ESLVal $3224 = _v1708.termRef(2);
        ESLVal $3223 = _v1708.termRef(3);
        
        {ESLVal l = $3226;
        
        {ESLVal s = $3225;
        
        {ESLVal handler = $3224;
        
        {ESLVal fail = $3223;
        
        return expToJExp(new ESLVal("Apply",l,new ESLVal("Var",l,new ESLVal("$ndCase")),ESLVal.list(s,handler,fail)));
      }
      }
      }
      }
      }
    case "CaseList": {ESLVal $3222 = _v1708.termRef(0);
        ESLVal $3221 = _v1708.termRef(1);
        ESLVal $3220 = _v1708.termRef(2);
        ESLVal $3219 = _v1708.termRef(3);
        ESLVal $3218 = _v1708.termRef(4);
        
        {ESLVal l = $3222;
        
        {ESLVal list = $3221;
        
        {ESLVal cons = $3220;
        
        {ESLVal nil = $3219;
        
        {ESLVal alt = $3218;
        
        return new ESLVal("JCommandExp",expToJCommand(e,$true),$null);
      }
      }
      }
      }
      }
      }
    case "CaseTerm": {ESLVal $3217 = _v1708.termRef(0);
        ESLVal $3216 = _v1708.termRef(1);
        ESLVal $3215 = _v1708.termRef(2);
        ESLVal $3214 = _v1708.termRef(3);
        
        {ESLVal l = $3217;
        
        {ESLVal list = $3216;
        
        {ESLVal arms = $3215;
        
        {ESLVal alt = $3214;
        
        return new ESLVal("JCommandExp",expToJCommand(e,$true),$null);
      }
      }
      }
      }
      }
    case "CaseStr": {ESLVal $3213 = _v1708.termRef(0);
        ESLVal $3212 = _v1708.termRef(1);
        ESLVal $3211 = _v1708.termRef(2);
        ESLVal $3210 = _v1708.termRef(3);
        
        {ESLVal l = $3213;
        
        {ESLVal s = $3212;
        
        {ESLVal arms = $3211;
        
        {ESLVal alt = $3210;
        
        return new ESLVal("JCommandExp",expToJCommand(e,$true),$null);
      }
      }
      }
      }
      }
    case "CaseBool": {ESLVal $3209 = _v1708.termRef(0);
        ESLVal $3208 = _v1708.termRef(1);
        ESLVal $3207 = _v1708.termRef(2);
        ESLVal $3206 = _v1708.termRef(3);
        
        {ESLVal l = $3209;
        
        {ESLVal s = $3208;
        
        {ESLVal arms = $3207;
        
        {ESLVal alt = $3206;
        
        return new ESLVal("JCommandExp",expToJCommand(e,$true),$null);
      }
      }
      }
      }
      }
    case "CaseSet": {ESLVal $3205 = _v1708.termRef(0);
        ESLVal $3204 = _v1708.termRef(1);
        ESLVal $3203 = _v1708.termRef(2);
        ESLVal $3202 = _v1708.termRef(3);
        
        {ESLVal l = $3205;
        
        {ESLVal s = $3204;
        
        {ESLVal handler = $3203;
        
        {ESLVal fail = $3202;
        
        return expToJExp(new ESLVal("Apply",l,new ESLVal("Var",l,new ESLVal("$ndCase")),ESLVal.list(s,handler,fail)));
      }
      }
      }
      }
      }
    case "Head": {ESLVal $3201 = _v1708.termRef(0);
        
        {ESLVal _v1818 = $3201;
        
        return new ESLVal("JHead",expToJExp(_v1818));
      }
      }
    case "Tail": {ESLVal $3200 = _v1708.termRef(0);
        
        {ESLVal _v1817 = $3200;
        
        return new ESLVal("JTail",expToJExp(_v1817));
      }
      }
    case "CaseError": {ESLVal $3199 = _v1708.termRef(0);
        ESLVal $3198 = _v1708.termRef(1);
        
        {ESLVal l = $3199;
        
        {ESLVal _v1816 = $3198;
        
        return new ESLVal("JError",new ESLVal("JBinExp",new ESLVal("JConstExp",new ESLVal("JConstStr",new ESLVal("case error at ").add(l))),new ESLVal("add"),expToJExp(_v1816)));
      }
      }
      }
    case "NullExp": {ESLVal $3197 = _v1708.termRef(0);
        
        {ESLVal l = $3197;
        
        return new ESLVal("JNull",new ESLVal[]{});
      }
      }
    case "Var": {ESLVal $3196 = _v1708.termRef(0);
        ESLVal $3195 = _v1708.termRef(1);
        
        {ESLVal l = $3196;
        
        {ESLVal n = $3195;
        
        return new ESLVal("JVar",n,$null);
      }
      }
      }
    case "Let": {ESLVal $3194 = _v1708.termRef(0);
        ESLVal $3193 = _v1708.termRef(1);
        ESLVal $3192 = _v1708.termRef(2);
        
        {ESLVal l = $3194;
        
        {ESLVal bs = $3193;
        
        {ESLVal body = $3192;
        
        return new ESLVal("JCommandExp",expToJCommand(e,$true),$null);
      }
      }
      }
      }
    case "Letrec": {ESLVal $3191 = _v1708.termRef(0);
        ESLVal $3190 = _v1708.termRef(1);
        ESLVal $3189 = _v1708.termRef(2);
        
        {ESLVal l = $3191;
        
        {ESLVal bs = $3190;
        
        {ESLVal body = $3189;
        
        return new ESLVal("JCommandExp",expToJCommand(e,$true),$null);
      }
      }
      }
      }
    case "Throw": {ESLVal $3188 = _v1708.termRef(0);
        ESLVal $3187 = _v1708.termRef(1);
        ESLVal $3186 = _v1708.termRef(2);
        
        {ESLVal l = $3188;
        
        {ESLVal t = $3187;
        
        {ESLVal _v1815 = $3186;
        
        return new ESLVal("JError",expToJExp(_v1815));
      }
      }
      }
      }
    case "BinExp": {ESLVal $3185 = _v1708.termRef(0);
        ESLVal $3184 = _v1708.termRef(1);
        ESLVal $3183 = _v1708.termRef(2);
        ESLVal $3182 = _v1708.termRef(3);
        
        {ESLVal l = $3185;
        
        {ESLVal e1 = $3184;
        
        {ESLVal op = $3183;
        
        {ESLVal e2 = $3182;
        
        return new ESLVal("JBinExp",expToJExp(e1),opToJOp(op),expToJExp(e2));
      }
      }
      }
      }
      }
    case "Become": {ESLVal $3178 = _v1708.termRef(0);
        ESLVal $3177 = _v1708.termRef(1);
        
        switch($3177.termName) {
        case "Apply": {ESLVal $3181 = $3177.termRef(0);
          ESLVal $3180 = $3177.termRef(1);
          ESLVal $3179 = $3177.termRef(2);
          
          {ESLVal l = $3178;
          
          {ESLVal al = $3181;
          
          {ESLVal b = $3180;
          
          {ESLVal args = $3179;
          
          return new ESLVal("JBecome",expToJExp(b),expsToJExps(args));
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(7815,16591)").add(ESLVal.list(_v1708)));
      }
      }
    case "Block": {ESLVal $3172 = _v1708.termRef(0);
        ESLVal $3171 = _v1708.termRef(1);
        
        if($3171.isCons())
        {ESLVal $3173 = $3171.head();
          ESLVal $3174 = $3171.tail();
          
          if($3174.isCons())
          {ESLVal $3175 = $3174.head();
            ESLVal $3176 = $3174.tail();
            
            {ESLVal l = $3172;
            
            {ESLVal es = $3171;
            
            return new ESLVal("JCommandExp",new ESLVal("JBlock",expsToJCommands(es,$true)),$null);
          }
          }
          }
        else if($3174.isNil())
          {ESLVal l = $3172;
            
            {ESLVal _v1814 = $3173;
            
            return expToJExp(_v1814);
          }
          }
        else {ESLVal l = $3172;
            
            {ESLVal es = $3171;
            
            return new ESLVal("JCommandExp",new ESLVal("JBlock",expsToJCommands(es,$true)),$null);
          }
          }
        }
      else if($3171.isNil())
        {ESLVal l = $3172;
          
          return new ESLVal("JNull",new ESLVal[]{});
        }
      else {ESLVal l = $3172;
          
          {ESLVal es = $3171;
          
          return new ESLVal("JCommandExp",new ESLVal("JBlock",expsToJCommands(es,$true)),$null);
        }
        }
      }
    case "If": {ESLVal $3170 = _v1708.termRef(0);
        ESLVal $3169 = _v1708.termRef(1);
        ESLVal $3168 = _v1708.termRef(2);
        ESLVal $3167 = _v1708.termRef(3);
        
        {ESLVal l = $3170;
        
        {ESLVal e1 = $3169;
        
        {ESLVal e2 = $3168;
        
        {ESLVal e3 = $3167;
        
        return new ESLVal("JCommandExp",new ESLVal("JIfCommand",expToJExp(e1),expToJCommand(e2,$true),expToJCommand(e3,$true)),$null);
      }
      }
      }
      }
      }
    case "FunExp": {ESLVal $3166 = _v1708.termRef(0);
        ESLVal $3165 = _v1708.termRef(1);
        ESLVal $3164 = _v1708.termRef(2);
        ESLVal $3163 = _v1708.termRef(3);
        ESLVal $3162 = _v1708.termRef(4);
        
        {ESLVal l = $3166;
        
        {ESLVal n = $3165;
        
        {ESLVal args = $3164;
        
        {ESLVal t = $3163;
        
        {ESLVal body = $3162;
        
        return new ESLVal("JFun",expToJExp(n),map.apply(new ESLVal(new Function(new ESLVal("fun414"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal d = $args[0];
        return decToJDec(d);
          }
        }),args),new ESLVal("JFunType",new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal a = $l0.head();
              $l0 = $l0.tail();
              $v.add($null);
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(args),$null),expToJCommand(body,$true));
      }
      }
      }
      }
      }
      }
    case "TermRef": {ESLVal $3161 = _v1708.termRef(0);
        ESLVal $3160 = _v1708.termRef(1);
        
        {ESLVal _v1813 = $3161;
        
        {ESLVal i = $3160;
        
        return new ESLVal("JTermRef",expToJExp(_v1813),i);
      }
      }
      }
    case "Cmp": {ESLVal $3155 = _v1708.termRef(0);
        ESLVal $3154 = _v1708.termRef(1);
        ESLVal $3153 = _v1708.termRef(2);
        
        if($3153.isCons())
        {ESLVal $3156 = $3153.head();
          ESLVal $3157 = $3153.tail();
          
          switch($3156.termName) {
          case "PQual": {ESLVal $3159 = $3156.termRef(0);
            ESLVal $3158 = $3156.termRef(1);
            
            {ESLVal l = $3155;
            
            {ESLVal _v1800 = $3154;
            
            {ESLVal ql = $3159;
            
            {ESLVal p = $3158;
            
            {ESLVal qs = $3157;
            
            return expToJExp(new ESLVal("If",ql,p,new ESLVal("Cmp",l,_v1800,qs),new ESLVal("List",l,ESLVal.list())));
          }
          }
          }
          }
          }
          }
          default: {ESLVal l = $3155;
            
            {ESLVal _v1801 = $3154;
            
            {ESLVal qs = $3153;
            
            if(exists.apply(isBindingQualifier,qs).and(forall.apply(isSimpleQualifier,qs)).boolVal)
            return new ESLVal("JCmpExp",cmpToJCmp(_v1801,qs));
            else
              {ESLVal _v1802 = $3155;
                
                {ESLVal _v1803 = $3154;
                
                {ESLVal _v1804 = $3153;
                
                return cmpToJExp(_v1803,_v1804);
              }
              }
              }
          }
          }
          }
        }
        }
      else if($3153.isNil())
        {ESLVal l = $3155;
          
          {ESLVal _v1805 = $3154;
          
          {ESLVal qs = $3153;
          
          if(exists.apply(isBindingQualifier,qs).and(forall.apply(isSimpleQualifier,qs)).boolVal)
          return new ESLVal("JCmpExp",cmpToJCmp(_v1805,qs));
          else
            {ESLVal _v1806 = $3155;
              
              {ESLVal _v1807 = $3154;
              
              {ESLVal _v1808 = $3153;
              
              return cmpToJExp(_v1807,_v1808);
            }
            }
            }
        }
        }
        }
      else {ESLVal l = $3155;
          
          {ESLVal _v1809 = $3154;
          
          {ESLVal qs = $3153;
          
          if(exists.apply(isBindingQualifier,qs).and(forall.apply(isSimpleQualifier,qs)).boolVal)
          return new ESLVal("JCmpExp",cmpToJCmp(_v1809,qs));
          else
            {ESLVal _v1810 = $3155;
              
              {ESLVal _v1811 = $3154;
              
              {ESLVal _v1812 = $3153;
              
              return cmpToJExp(_v1811,_v1812);
            }
            }
            }
        }
        }
        }
      }
    case "Not": {ESLVal $3152 = _v1708.termRef(0);
        ESLVal $3151 = _v1708.termRef(1);
        
        {ESLVal l = $3152;
        
        {ESLVal _v1799 = $3151;
        
        return new ESLVal("JNot",expToJExp(_v1799));
      }
      }
      }
    case "New": {ESLVal $3150 = _v1708.termRef(0);
        ESLVal $3149 = _v1708.termRef(1);
        ESLVal $3148 = _v1708.termRef(2);
        
        {ESLVal l = $3150;
        
        {ESLVal b = $3149;
        
        {ESLVal args = $3148;
        
        return new ESLVal("JNew",expToJExp(b),expsToJExps(args));
      }
      }
      }
      }
    case "NewArray": {ESLVal $3147 = _v1708.termRef(0);
        ESLVal $3146 = _v1708.termRef(1);
        ESLVal $3145 = _v1708.termRef(2);
        
        {ESLVal l = $3147;
        
        {ESLVal t = $3146;
        
        {ESLVal i = $3145;
        
        return new ESLVal("JNewArray",expToJExp(i));
      }
      }
      }
      }
    case "NewJava": {ESLVal $3144 = _v1708.termRef(0);
        ESLVal $3143 = _v1708.termRef(1);
        ESLVal $3142 = _v1708.termRef(2);
        ESLVal $3141 = _v1708.termRef(3);
        
        {ESLVal l = $3144;
        
        {ESLVal n = $3143;
        
        {ESLVal t = $3142;
        
        {ESLVal args = $3141;
        
        return new ESLVal("JNewJava",n,expsToJExps(args));
      }
      }
      }
      }
      }
    case "NewTable": {ESLVal $3140 = _v1708.termRef(0);
        ESLVal $3139 = _v1708.termRef(1);
        ESLVal $3138 = _v1708.termRef(2);
        
        {ESLVal l = $3140;
        
        {ESLVal key = $3139;
        
        {ESLVal value = $3138;
        
        return new ESLVal("JNewTable",new ESLVal[]{});
      }
      }
      }
      }
    case "Record": {ESLVal $3137 = _v1708.termRef(0);
        ESLVal $3136 = _v1708.termRef(1);
        
        {ESLVal l = $3137;
        
        {ESLVal fs = $3136;
        
        return new ESLVal("JRecord",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v1709 = $qualArg;
              
              switch(_v1709.termName) {
              case "Binding": {ESLVal $3279 = _v1709.termRef(0);
                ESLVal $3278 = _v1709.termRef(1);
                ESLVal $3277 = _v1709.termRef(2);
                ESLVal $3276 = _v1709.termRef(3);
                ESLVal $3275 = _v1709.termRef(4);
                
                {ESLVal bl = $3279;
                
                {ESLVal n = $3278;
                
                {ESLVal t = $3277;
                
                {ESLVal dt = $3276;
                
                {ESLVal _v1798 = $3275;
                
                return ESLVal.list(ESLVal.list(new ESLVal("JField",n,$null,expToJExp(_v1798))));
              }
              }
              }
              }
              }
              }
              default: {ESLVal _0 = _v1709;
                
                return ESLVal.list();
              }
            }
            }
          }
        }).map(fs).flatten().flatten());
      }
      }
      }
    case "Send": {ESLVal $3131 = _v1708.termRef(0);
        ESLVal $3130 = _v1708.termRef(1);
        ESLVal $3129 = _v1708.termRef(2);
        
        switch($3129.termName) {
        case "Term": {ESLVal $3135 = $3129.termRef(0);
          ESLVal $3134 = $3129.termRef(1);
          ESLVal $3133 = $3129.termRef(2);
          ESLVal $3132 = $3129.termRef(3);
          
          {ESLVal l = $3131;
          
          {ESLVal a = $3130;
          
          {ESLVal lt = $3135;
          
          {ESLVal n = $3134;
          
          {ESLVal ts = $3133;
          
          {ESLVal es = $3132;
          
          return new ESLVal("JSend",expToJExp(a),n,expsToJExps(es));
        }
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(7815,16591)").add(ESLVal.list(_v1708)));
      }
      }
    case "SendTimeSuper": {ESLVal $3128 = _v1708.termRef(0);
        
        {ESLVal l = $3128;
        
        return new ESLVal("JSendTimeSuper",new ESLVal[]{});
      }
      }
    case "SendSuper": {ESLVal $3127 = _v1708.termRef(0);
        ESLVal $3126 = _v1708.termRef(1);
        
        {ESLVal l = $3127;
        
        {ESLVal _v1797 = $3126;
        
        return new ESLVal("JSendSuper",expToJExp(_v1797));
      }
      }
      }
    case "Self": {ESLVal $3125 = _v1708.termRef(0);
        
        {ESLVal l = $3125;
        
        return new ESLVal("JSelf",new ESLVal[]{});
      }
      }
    case "Fold": {ESLVal $3124 = _v1708.termRef(0);
        ESLVal $3123 = _v1708.termRef(1);
        ESLVal $3122 = _v1708.termRef(2);
        
        {ESLVal l = $3124;
        
        {ESLVal t = $3123;
        
        {ESLVal _v1796 = $3122;
        
        return expToJExp(_v1796);
      }
      }
      }
      }
    case "Now": {ESLVal $3121 = _v1708.termRef(0);
        
        {ESLVal l = $3121;
        
        return new ESLVal("JNow",new ESLVal[]{});
      }
      }
    case "Ref": {ESLVal $3120 = _v1708.termRef(0);
        ESLVal $3119 = _v1708.termRef(1);
        ESLVal $3118 = _v1708.termRef(2);
        
        {ESLVal l = $3120;
        
        {ESLVal _v1795 = $3119;
        
        {ESLVal n = $3118;
        
        return new ESLVal("JRef",expToJExp(_v1795),n);
      }
      }
      }
      }
    case "RefSuper": {ESLVal $3117 = _v1708.termRef(0);
        ESLVal $3116 = _v1708.termRef(1);
        
        {ESLVal l = $3117;
        
        {ESLVal n = $3116;
        
        return new ESLVal("JRefSuper",n);
      }
      }
      }
    case "For": {ESLVal $3115 = _v1708.termRef(0);
        ESLVal $3114 = _v1708.termRef(1);
        ESLVal $3113 = _v1708.termRef(2);
        ESLVal $3112 = _v1708.termRef(3);
        
        {ESLVal l1 = $3115;
        
        {ESLVal p = $3114;
        
        {ESLVal l2 = $3113;
        
        {ESLVal c = $3112;
        
        return new ESLVal("JCommandExp",expToJCommand(e,$true),$null);
      }
      }
      }
      }
      }
    case "Grab": {ESLVal $3111 = _v1708.termRef(0);
        ESLVal $3110 = _v1708.termRef(1);
        ESLVal $3109 = _v1708.termRef(2);
        
        {ESLVal l = $3111;
        
        {ESLVal refs = $3110;
        
        {ESLVal _v1794 = $3109;
        
        return new ESLVal("JGrab",refsToJExps(refs),expToJExp(_v1794));
      }
      }
      }
      }
    case "Update": {ESLVal $3108 = _v1708.termRef(0);
        ESLVal $3107 = _v1708.termRef(1);
        ESLVal $3106 = _v1708.termRef(2);
        
        {ESLVal l = $3108;
        
        {ESLVal n = $3107;
        
        {ESLVal v = $3106;
        
        return new ESLVal("JCommandExp",expToJCommand(e,$true),$null);
      }
      }
      }
      }
    case "Probably": {ESLVal $3105 = _v1708.termRef(0);
        ESLVal $3104 = _v1708.termRef(1);
        ESLVal $3103 = _v1708.termRef(2);
        ESLVal $3102 = _v1708.termRef(3);
        ESLVal $3101 = _v1708.termRef(4);
        
        {ESLVal l = $3105;
        
        {ESLVal _v1793 = $3104;
        
        {ESLVal t = $3103;
        
        {ESLVal e1 = $3102;
        
        {ESLVal e2 = $3101;
        
        return new ESLVal("JProbably",expToJExp(_v1793),expToJExp(e1),expToJExp(e2));
      }
      }
      }
      }
      }
      }
    case "Try": {ESLVal $3100 = _v1708.termRef(0);
        ESLVal $3099 = _v1708.termRef(1);
        ESLVal $3098 = _v1708.termRef(2);
        
        {ESLVal l = $3100;
        
        {ESLVal _v1792 = $3099;
        
        {ESLVal arms = $3098;
        
        return new ESLVal("JTry",expToJExp(_v1792),new ESLVal("$x"),expToJCommand(new ESLVal("Case",l,$nil,ESLVal.list(new ESLVal("Var",l,new ESLVal("$x"))),arms),$true));
      }
      }
      }
      }
    case "ActExp": {ESLVal $3097 = _v1708.termRef(0);
        ESLVal $3096 = _v1708.termRef(1);
        ESLVal $3095 = _v1708.termRef(2);
        ESLVal $3094 = _v1708.termRef(3);
        ESLVal $3093 = _v1708.termRef(4);
        ESLVal $3092 = _v1708.termRef(5);
        ESLVal $3091 = _v1708.termRef(6);
        ESLVal $3090 = _v1708.termRef(7);
        
        {ESLVal l = $3097;
        
        {ESLVal name = $3096;
        
        {ESLVal decs = $3095;
        
        {ESLVal exports = $3094;
        
        {ESLVal parent = $3093;
        
        {ESLVal defs = $3092;
        
        {ESLVal init = $3091;
        
        {ESLVal arms = $3090;
        
        return actToJava(name,decs,exports,parent,defs,init,arms);
      }
      }
      }
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(7815,16591)").add(ESLVal.list(_v1708)));
    }
    }
  }
  private static ESLVal expToJExp = new ESLVal(new Function(new ESLVal("expToJExp"),null) { public ESLVal apply(ESLVal... args) { return expToJExp(args[0]); }});
  private static ESLVal isSimpleQualifier(ESLVal q) {
    
    {ESLVal _v1710 = q;
      
      switch(_v1710.termName) {
      case "BQual": {ESLVal $3282 = _v1710.termRef(0);
        ESLVal $3281 = _v1710.termRef(1);
        ESLVal $3280 = _v1710.termRef(2);
        
        switch($3281.termName) {
        case "PVar": {ESLVal $3285 = $3281.termRef(0);
          ESLVal $3284 = $3281.termRef(1);
          ESLVal $3283 = $3281.termRef(2);
          
          {ESLVal l = $3282;
          
          {ESLVal vl = $3285;
          
          {ESLVal n = $3284;
          
          {ESLVal t = $3283;
          
          {ESLVal e = $3280;
          
          return $true;
        }
        }
        }
        }
        }
        }
        default: {ESLVal l = $3282;
          
          {ESLVal p = $3281;
          
          {ESLVal e = $3280;
          
          return $false;
        }
        }
        }
      }
      }
      default: {ESLVal _v1791 = _v1710;
        
        return $true;
      }
    }
    }
  }
  private static ESLVal isSimpleQualifier = new ESLVal(new Function(new ESLVal("isSimpleQualifier"),null) { public ESLVal apply(ESLVal... args) { return isSimpleQualifier(args[0]); }});
  private static ESLVal isBindingQualifier(ESLVal q) {
    
    {ESLVal _v1711 = q;
      
      switch(_v1711.termName) {
      case "BQual": {ESLVal $3288 = _v1711.termRef(0);
        ESLVal $3287 = _v1711.termRef(1);
        ESLVal $3286 = _v1711.termRef(2);
        
        {ESLVal l = $3288;
        
        {ESLVal p = $3287;
        
        {ESLVal e = $3286;
        
        return $true;
      }
      }
      }
      }
      default: {ESLVal _v1790 = _v1711;
        
        return $false;
      }
    }
    }
  }
  private static ESLVal isBindingQualifier = new ESLVal(new Function(new ESLVal("isBindingQualifier"),null) { public ESLVal apply(ESLVal... args) { return isBindingQualifier(args[0]); }});
  private static ESLVal cmpToJCmp(ESLVal e,ESLVal qs) {
    
    { LetRec letrec = new LetRec() {
      ESLVal inner = new ESLVal(new Function(new ESLVal("inner"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1785 = $args[0];
        {ESLVal _v1712 = _v1785;
              
              if(_v1712.isCons())
              {ESLVal $3289 = _v1712.head();
                ESLVal $3290 = _v1712.tail();
                
                switch($3289.termName) {
                case "BQual": {ESLVal $3295 = $3289.termRef(0);
                  ESLVal $3294 = $3289.termRef(1);
                  ESLVal $3293 = $3289.termRef(2);
                  
                  switch($3294.termName) {
                  case "PVar": {ESLVal $3298 = $3294.termRef(0);
                    ESLVal $3297 = $3294.termRef(1);
                    ESLVal $3296 = $3294.termRef(2);
                    
                    {ESLVal l = $3295;
                    
                    {ESLVal vl = $3298;
                    
                    {ESLVal n = $3297;
                    
                    {ESLVal t = $3296;
                    
                    {ESLVal listExp = $3293;
                    
                    {ESLVal _v1787 = $3290;
                    
                    return new ESLVal("JCmpBind",n,expToJExp(listExp),inner.apply(_v1787));
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(16996,17194)").add(ESLVal.list(_v1712)));
                }
                }
              case "PQual": {ESLVal $3292 = $3289.termRef(0);
                  ESLVal $3291 = $3289.termRef(1);
                  
                  {ESLVal l = $3292;
                  
                  {ESLVal p = $3291;
                  
                  {ESLVal _v1786 = $3290;
                  
                  return new ESLVal("JCmpIf",expToJExp(p),inner.apply(_v1786));
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(16996,17194)").add(ESLVal.list(_v1712)));
              }
              }
            else if(_v1712.isNil())
              return new ESLVal("JCmpList",expToJExp(e));
            else return error(new ESLVal("case error at Pos(16996,17194)").add(ESLVal.list(_v1712)));
            }
          }
        });
      
      public ESLVal get(String name) {
        switch(name) {
          case "inner": return inner;
          
          default: throw new Error("cannot find letrec binding");
        }
        }
      };
    ESLVal inner = letrec.get("inner");
    
      {ESLVal _v1713 = qs;
      
      if(_v1713.isCons())
      {ESLVal $3299 = _v1713.head();
        ESLVal $3300 = _v1713.tail();
        
        switch($3299.termName) {
        case "BQual": {ESLVal $3305 = $3299.termRef(0);
          ESLVal $3304 = $3299.termRef(1);
          ESLVal $3303 = $3299.termRef(2);
          
          switch($3304.termName) {
          case "PVar": {ESLVal $3308 = $3304.termRef(0);
            ESLVal $3307 = $3304.termRef(1);
            ESLVal $3306 = $3304.termRef(2);
            
            {ESLVal l = $3305;
            
            {ESLVal vl = $3308;
            
            {ESLVal n = $3307;
            
            {ESLVal t = $3306;
            
            {ESLVal listExp = $3303;
            
            {ESLVal _v1789 = $3300;
            
            return new ESLVal("JCmpOuter",n,expToJExp(listExp),inner.apply(_v1789));
          }
          }
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(17206,17403)").add(ESLVal.list(_v1713)));
        }
        }
      case "PQual": {ESLVal $3302 = $3299.termRef(0);
          ESLVal $3301 = $3299.termRef(1);
          
          {ESLVal l = $3302;
          
          {ESLVal p = $3301;
          
          {ESLVal _v1788 = $3300;
          
          return new ESLVal("JCmpIf",expToJExp(p),cmpToJCmp(e,_v1788));
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(17206,17403)").add(ESLVal.list(_v1713)));
      }
      }
    else if(_v1713.isNil())
      return new ESLVal("JCmpList",expToJExp(e));
    else return error(new ESLVal("case error at Pos(17206,17403)").add(ESLVal.list(_v1713)));
    }}
    
  }
  private static ESLVal cmpToJCmp = new ESLVal(new Function(new ESLVal("cmpToJCmp"),null) { public ESLVal apply(ESLVal... args) { return cmpToJCmp(args[0],args[1]); }});
  private static ESLVal refsToJExps(ESLVal refs) {
    
    {ESLVal _v1714 = refs;
      
      if(_v1714.isCons())
      {ESLVal $3309 = _v1714.head();
        ESLVal $3310 = _v1714.tail();
        
        switch($3309.termName) {
        case "VarDynamicRef": {ESLVal $3315 = $3309.termRef(0);
          ESLVal $3314 = $3309.termRef(1);
          
          switch($3314.termName) {
          case "Var": {ESLVal $3317 = $3314.termRef(0);
            ESLVal $3316 = $3314.termRef(1);
            
            {ESLVal l = $3315;
            
            {ESLVal vl = $3317;
            
            {ESLVal n = $3316;
            
            {ESLVal _v1784 = $3310;
            
            return refsToJExps(_v1784).cons(new ESLVal("JVar",n,$null));
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(17450,17691)").add(ESLVal.list(_v1714)));
        }
        }
      case "ActorDynamicRef": {ESLVal $3313 = $3309.termRef(0);
          ESLVal $3312 = $3309.termRef(1);
          ESLVal $3311 = $3309.termRef(2);
          
          {ESLVal l = $3313;
          
          {ESLVal e = $3312;
          
          {ESLVal n = $3311;
          
          {ESLVal _v1783 = $3310;
          
          return refsToJExps(_v1783).cons(new ESLVal("JRef",expToJExp(e),n));
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(17450,17691)").add(ESLVal.list(_v1714)));
      }
      }
    else if(_v1714.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(17450,17691)").add(ESLVal.list(_v1714)));
    }
  }
  private static ESLVal refsToJExps = new ESLVal(new Function(new ESLVal("refsToJExps"),null) { public ESLVal apply(ESLVal... args) { return refsToJExps(args[0]); }});
  private static ESLVal actToJava(ESLVal name,ESLVal decs,ESLVal exports,ESLVal parent,ESLVal defs,ESLVal init,ESLVal arms) {
    
    if(parent.eql($null).boolVal)
      return simpleActToJava(name,decs,exports,defs,init,arms);
      else
        return extendedActToJava(name,decs,exports,parent,defs,init,arms);
  }
  private static ESLVal actToJava = new ESLVal(new Function(new ESLVal("actToJava"),null) { public ESLVal apply(ESLVal... args) { return actToJava(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal wrapListeners(ESLVal exports,ESLVal body) {
    
    {ESLVal p0 = new ESLVal("Pos",$zero,$zero);
      ESLVal t0 = $null;
      
      if(member.apply(new ESLVal("observeState"),exports).boolVal)
      return new ESLVal("Block",p0,ESLVal.list(body,new ESLVal("Let",p0,ESLVal.list(new ESLVal("Binding",p0,new ESLVal("$s"),t0,t0,new ESLVal("Apply",p0,new ESLVal("Var",p0,new ESLVal("observeState")),ESLVal.list()))),new ESLVal("For",p0,new ESLVal("PVar",p0,new ESLVal("$o"),t0),new ESLVal("Var",p0,new ESLVal("$observers")),new ESLVal("Case",p0,ESLVal.list(),ESLVal.list(new ESLVal("Apply",p0,new ESLVal("Var",p0,new ESLVal("observeMessage")),ESLVal.list(new ESLVal("Var",p0,new ESLVal("$m"))))),ESLVal.list(new ESLVal("BArm",p0,ESLVal.list(new ESLVal("PTerm",p0,new ESLVal("Something"),ESLVal.list(),ESLVal.list(new ESLVal("PVar",p0,new ESLVal("$x"),$null)))),new ESLVal("BoolExp",p0,$true),new ESLVal("Send",p0,new ESLVal("Var",p0,new ESLVal("$o")),new ESLVal("Term",p0,new ESLVal("Transition"),ESLVal.list(),ESLVal.list(new ESLVal("Self",p0),new ESLVal("Now",p0),new ESLVal("Var",p0,new ESLVal("$x")),new ESLVal("Var",p0,new ESLVal("$s")))))),new ESLVal("BArm",p0,ESLVal.list(new ESLVal("PTerm",p0,new ESLVal("Nothing"),ESLVal.list(),ESLVal.list())),new ESLVal("BoolExp",p0,$true),new ESLVal("Block",p0,ESLVal.list()))))))));
      else
        return body;
    }
  }
  private static ESLVal wrapListeners = new ESLVal(new Function(new ESLVal("wrapListeners"),null) { public ESLVal apply(ESLVal... args) { return wrapListeners(args[0],args[1]); }});
  private static ESLVal simpleActToJava(ESLVal name,ESLVal decs,ESLVal exports,ESLVal defs,ESLVal init,ESLVal arms) {
    
    {ESLVal timeArms = select.apply(isTimeArm,arms);
      
      {ESLVal nonTimeArms = reject.apply(isTimeArm,arms);
      
      {ESLVal timeCommand = ((Supplier<ESLVal>)() -> { 
          if(timeArms.eql(ESLVal.list()).boolVal)
            return new ESLVal("JBlock",ESLVal.list());
            else
              return timeArmsToJCommand(timeArms);
        }).get();
      
      {ESLVal observers = ((Supplier<ESLVal>)() -> { 
          if(member.apply(new ESLVal("observeState"),exports).boolVal)
            return ESLVal.list(new ESLVal("JField",new ESLVal("$observers"),$null,new ESLVal("JList",$null,ESLVal.list())));
            else
              return ESLVal.list();
        }).get();
      
      {ESLVal addObserver = ((Supplier<ESLVal>)() -> { 
          if(member.apply(new ESLVal("observeState"),exports).boolVal)
            return ESLVal.list(addObserverJField);
            else
              return ESLVal.list();
        }).get();
      
      {ESLVal xAdd = ((Supplier<ESLVal>)() -> { 
          if(member.apply(new ESLVal("observeState"),exports).boolVal)
            return ESLVal.list(new ESLVal("addObserver"));
            else
              return ESLVal.list();
        }).get();
      
      {ESLVal f = new ESLVal("FunExp",new ESLVal("Pos",$zero,$zero),name,ESLVal.list(new ESLVal("Dec",new ESLVal("Pos",$zero,$zero),new ESLVal("$m"),$null,$null)),new ESLVal("VoidType",new ESLVal("Pos",$zero,$zero)),wrapListeners(exports,new ESLVal("Case",new ESLVal("Pos",$zero,$zero),$nil,ESLVal.list(new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("$m"))),nonTimeArms)));
      
      return new ESLVal("JBehaviour",exports.add(xAdd),new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal b = $l0.head();
            $l0 = $l0.tail();
            $v.add(defToField(b));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(defs).add(observers.add(addObserver)),ESLVal.list(),expToJExp(init),expToJExp(f),timeCommand);
    }
    }
    }
    }
    }
    }
    }
  }
  private static ESLVal simpleActToJava = new ESLVal(new Function(new ESLVal("simpleActToJava"),null) { public ESLVal apply(ESLVal... args) { return simpleActToJava(args[0],args[1],args[2],args[3],args[4],args[5]); }});
  private static ESLVal extendedActToJava(ESLVal name,ESLVal decs,ESLVal exports,ESLVal parent,ESLVal defs,ESLVal init,ESLVal arms) {
    
    {ESLVal p0 = new ESLVal("Pos",$zero,$zero);
      
      {ESLVal timeSuper = new ESLVal("BArm",p0,ESLVal.list(new ESLVal("PTerm",p0,new ESLVal("Time"),ESLVal.list(),ESLVal.list(new ESLVal("PVar",p0,new ESLVal("$"),$null)))),new ESLVal("BoolExp",p0,$true),new ESLVal("SendTimeSuper",p0));
      
      {ESLVal timeArms = select.apply(isTimeArm,arms).add(ESLVal.list(timeSuper));
      
      {ESLVal messageSuper = new ESLVal("BArm",p0,ESLVal.list(new ESLVal("PVar",p0,new ESLVal("$m"),$null)),new ESLVal("BoolExp",p0,$true),new ESLVal("Block",p0,ESLVal.list(new ESLVal("SendSuper",p0,new ESLVal("Var",p0,new ESLVal("$m"))),new ESLVal("NullExp",p0))));
      
      {ESLVal nonTimeArms = reject.apply(isTimeArm,arms).add(ESLVal.list(messageSuper));
      
      {ESLVal timeCommand = ((Supplier<ESLVal>)() -> { 
          if(timeArms.eql(ESLVal.list()).boolVal)
            return new ESLVal("JBlock",ESLVal.list());
            else
              return timeArmsToJCommand(timeArms);
        }).get();
      
      {ESLVal f = new ESLVal("FunExp",new ESLVal("Pos",$zero,$zero),name,ESLVal.list(new ESLVal("Dec",new ESLVal("Pos",$zero,$zero),new ESLVal("$m"),$null,$null)),new ESLVal("VoidType",new ESLVal("Pos",$zero,$zero)),wrapListeners(exports,new ESLVal("Case",new ESLVal("Pos",$zero,$zero),$nil,ESLVal.list(new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("$m"))),nonTimeArms)));
      
      return new ESLVal("JExtendedBehaviour",exports,expToJExp(parent),new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal b = $l0.head();
            $l0 = $l0.tail();
            $v.add(defToField(b));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(defs),ESLVal.list(),expToJExp(init),expToJExp(f),timeCommand);
    }
    }
    }
    }
    }
    }
    }
  }
  private static ESLVal extendedActToJava = new ESLVal(new Function(new ESLVal("extendedActToJava"),null) { public ESLVal apply(ESLVal... args) { return extendedActToJava(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal isTimeArm(ESLVal a) {
    
    {ESLVal _v1715 = a;
      
      switch(_v1715.termName) {
      case "BArm": {ESLVal $3321 = _v1715.termRef(0);
        ESLVal $3320 = _v1715.termRef(1);
        ESLVal $3319 = _v1715.termRef(2);
        ESLVal $3318 = _v1715.termRef(3);
        
        if($3320.isCons())
        {ESLVal $3322 = $3320.head();
          ESLVal $3323 = $3320.tail();
          
          switch($3322.termName) {
          case "PTerm": {ESLVal $3327 = $3322.termRef(0);
            ESLVal $3326 = $3322.termRef(1);
            ESLVal $3325 = $3322.termRef(2);
            ESLVal $3324 = $3322.termRef(3);
            
            switch($3326.strVal) {
            case "Time": if($3323.isCons())
              {ESLVal $3328 = $3323.head();
                ESLVal $3329 = $3323.tail();
                
                {ESLVal _v1776 = _v1715;
                
                return $false;
              }
              }
            else if($3323.isNil())
              {ESLVal l = $3321;
                
                {ESLVal pl = $3327;
                
                {ESLVal ts = $3325;
                
                {ESLVal ps = $3324;
                
                {ESLVal g = $3319;
                
                {ESLVal e = $3318;
                
                return $true;
              }
              }
              }
              }
              }
              }
            else {ESLVal _v1777 = _v1715;
                
                return $false;
              }
            default: {ESLVal _v1778 = _v1715;
              
              return $false;
            }
          }
          }
          default: {ESLVal _v1779 = _v1715;
            
            return $false;
          }
        }
        }
      else if($3320.isNil())
        {ESLVal _v1780 = _v1715;
          
          return $false;
        }
      else {ESLVal _v1781 = _v1715;
          
          return $false;
        }
      }
      default: {ESLVal _v1782 = _v1715;
        
        return $false;
      }
    }
    }
  }
  private static ESLVal isTimeArm = new ESLVal(new Function(new ESLVal("isTimeArm"),null) { public ESLVal apply(ESLVal... args) { return isTimeArm(args[0]); }});
  private static ESLVal timeArmsToJCommand(ESLVal arms) {
    
    {ESLVal _v1716 = arms;
      
      if(_v1716.isCons())
      {ESLVal $3330 = _v1716.head();
        ESLVal $3331 = _v1716.tail();
        
        switch($3330.termName) {
        case "BArm": {ESLVal $3335 = $3330.termRef(0);
          ESLVal $3334 = $3330.termRef(1);
          ESLVal $3333 = $3330.termRef(2);
          ESLVal $3332 = $3330.termRef(3);
          
          if($3334.isCons())
          {ESLVal $3336 = $3334.head();
            ESLVal $3337 = $3334.tail();
            
            switch($3336.termName) {
            case "PTerm": {ESLVal $3341 = $3336.termRef(0);
              ESLVal $3340 = $3336.termRef(1);
              ESLVal $3339 = $3336.termRef(2);
              ESLVal $3338 = $3336.termRef(3);
              
              switch($3340.strVal) {
              case "Time": if($3339.isCons())
                {ESLVal $3342 = $3339.head();
                  ESLVal $3343 = $3339.tail();
                  
                  return error(new ESLVal("case error at Pos(21310,21840)").add(ESLVal.list(_v1716)));
                }
              else if($3339.isNil())
                if($3338.isCons())
                  {ESLVal $3344 = $3338.head();
                    ESLVal $3345 = $3338.tail();
                    
                    switch($3344.termName) {
                    case "PVar": {ESLVal $3356 = $3344.termRef(0);
                      ESLVal $3355 = $3344.termRef(1);
                      ESLVal $3354 = $3344.termRef(2);
                      
                      if($3345.isCons())
                      {ESLVal $3357 = $3345.head();
                        ESLVal $3358 = $3345.tail();
                        
                        return error(new ESLVal("case error at Pos(21310,21840)").add(ESLVal.list(_v1716)));
                      }
                    else if($3345.isNil())
                      if($3337.isCons())
                        {ESLVal $3359 = $3337.head();
                          ESLVal $3360 = $3337.tail();
                          
                          return error(new ESLVal("case error at Pos(21310,21840)").add(ESLVal.list(_v1716)));
                        }
                      else if($3337.isNil())
                        {ESLVal l = $3335;
                          
                          {ESLVal tl = $3341;
                          
                          {ESLVal vl = $3356;
                          
                          {ESLVal n = $3355;
                          
                          {ESLVal t = $3354;
                          
                          {ESLVal g = $3333;
                          
                          {ESLVal e = $3332;
                          
                          {ESLVal _v1775 = $3331;
                          
                          return new ESLVal("JLet",ESLVal.list(new ESLVal("JField",n,$null,new ESLVal("JVar",new ESLVal("$t"),$null))),new ESLVal("JIfCommand",expToJExp(g),expToJCommand(e,$false),timeArmsToJCommand(_v1775)));
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                      else return error(new ESLVal("case error at Pos(21310,21840)").add(ESLVal.list(_v1716)));
                    else return error(new ESLVal("case error at Pos(21310,21840)").add(ESLVal.list(_v1716)));
                    }
                  case "PInt": {ESLVal $3347 = $3344.termRef(0);
                      ESLVal $3346 = $3344.termRef(1);
                      
                      if($3345.isCons())
                      {ESLVal $3348 = $3345.head();
                        ESLVal $3349 = $3345.tail();
                        
                        return error(new ESLVal("case error at Pos(21310,21840)").add(ESLVal.list(_v1716)));
                      }
                    else if($3345.isNil())
                      if($3337.isCons())
                        {ESLVal $3350 = $3337.head();
                          ESLVal $3351 = $3337.tail();
                          
                          return error(new ESLVal("case error at Pos(21310,21840)").add(ESLVal.list(_v1716)));
                        }
                      else if($3337.isNil())
                        switch($3333.termName) {
                          case "BoolExp": {ESLVal $3353 = $3333.termRef(0);
                            ESLVal $3352 = $3333.termRef(1);
                            
                            switch($3352.boolVal ? 1 : 0) {
                            case 1: {ESLVal l = $3335;
                              
                              {ESLVal tl = $3341;
                              
                              {ESLVal vl = $3347;
                              
                              {ESLVal n = $3346;
                              
                              {ESLVal bl = $3353;
                              
                              {ESLVal e = $3332;
                              
                              {ESLVal _v1774 = $3331;
                              
                              return new ESLVal("JIfCommand",new ESLVal("JBinExp",new ESLVal("JVar",new ESLVal("$t"),$null),new ESLVal("eq"),new ESLVal("JConstExp",new ESLVal("JConstInt",n))),expToJCommand(e,$false),timeArmsToJCommand(_v1774));
                            }
                            }
                            }
                            }
                            }
                            }
                            }
                            default: return error(new ESLVal("case error at Pos(21310,21840)").add(ESLVal.list(_v1716)));
                          }
                          }
                          default: return error(new ESLVal("case error at Pos(21310,21840)").add(ESLVal.list(_v1716)));
                        }
                      else return error(new ESLVal("case error at Pos(21310,21840)").add(ESLVal.list(_v1716)));
                    else return error(new ESLVal("case error at Pos(21310,21840)").add(ESLVal.list(_v1716)));
                    }
                    default: return error(new ESLVal("case error at Pos(21310,21840)").add(ESLVal.list(_v1716)));
                  }
                  }
                else if($3338.isNil())
                  return error(new ESLVal("case error at Pos(21310,21840)").add(ESLVal.list(_v1716)));
                else return error(new ESLVal("case error at Pos(21310,21840)").add(ESLVal.list(_v1716)));
              else return error(new ESLVal("case error at Pos(21310,21840)").add(ESLVal.list(_v1716)));
              default: return error(new ESLVal("case error at Pos(21310,21840)").add(ESLVal.list(_v1716)));
            }
            }
            default: return error(new ESLVal("case error at Pos(21310,21840)").add(ESLVal.list(_v1716)));
          }
          }
        else if($3334.isNil())
          return error(new ESLVal("case error at Pos(21310,21840)").add(ESLVal.list(_v1716)));
        else return error(new ESLVal("case error at Pos(21310,21840)").add(ESLVal.list(_v1716)));
        }
        default: return error(new ESLVal("case error at Pos(21310,21840)").add(ESLVal.list(_v1716)));
      }
      }
    else if(_v1716.isNil())
      return new ESLVal("JBlock",ESLVal.list());
    else return error(new ESLVal("case error at Pos(21310,21840)").add(ESLVal.list(_v1716)));
    }
  }
  private static ESLVal timeArmsToJCommand = new ESLVal(new Function(new ESLVal("timeArmsToJCommand"),null) { public ESLVal apply(ESLVal... args) { return timeArmsToJCommand(args[0]); }});
  private static ESLVal cmpToJExp(ESLVal e,ESLVal qs) {
    
    {ESLVal _v1717 = qs;
      
      if(_v1717.isCons())
      {ESLVal $3361 = _v1717.head();
        ESLVal $3362 = _v1717.tail();
        
        switch($3361.termName) {
        case "BQual": {ESLVal $3367 = $3361.termRef(0);
          ESLVal $3366 = $3361.termRef(1);
          ESLVal $3365 = $3361.termRef(2);
          
          {ESLVal l = $3367;
          
          {ESLVal p = $3366;
          
          {ESLVal v = $3365;
          
          {ESLVal _v1773 = $3362;
          
          {ESLVal f = new ESLVal("FunExp",new ESLVal("Pos",$zero,$zero),new ESLVal("StrExp",new ESLVal("Pos",$zero,$zero),new ESLVal("qual")),ESLVal.list(new ESLVal("Dec",new ESLVal("Pos",$zero,$zero),new ESLVal("$qualArg"),$null,$null)),$null,new ESLVal("Case",new ESLVal("Pos",$zero,$zero),ESLVal.list(),ESLVal.list(new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("$qualArg"))),ESLVal.list(new ESLVal("BArm",new ESLVal("Pos",$zero,$zero),ESLVal.list(p),new ESLVal("BoolExp",new ESLVal("Pos",$zero,$zero),$true),new ESLVal("List",new ESLVal("Pos",$zero,$zero),ESLVal.list(new ESLVal("Cmp",new ESLVal("Pos",$zero,$zero),e,_v1773)))),new ESLVal("BArm",new ESLVal("Pos",$zero,$zero),ESLVal.list(new ESLVal("PVar",new ESLVal("Pos",$zero,$zero),new ESLVal("_0"),$null)),new ESLVal("BoolExp",new ESLVal("Pos",$zero,$zero),$true),new ESLVal("List",new ESLVal("Pos",$zero,$zero),$nil)))));
          
          return new ESLVal("JFlatten",new ESLVal("JFlatten",new ESLVal("JMapFun",expToJExp(f),expToJExp(v))));
        }
        }
        }
        }
        }
        }
      case "PQual": {ESLVal $3364 = $3361.termRef(0);
          ESLVal $3363 = $3361.termRef(1);
          
          {ESLVal l = $3364;
          
          {ESLVal p = $3363;
          
          {ESLVal _v1772 = $3362;
          
          return new ESLVal("JIfExp",expToJExp(p),cmpToJExp(e,_v1772),new ESLVal("JNil",$null));
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(21887,22555)").add(ESLVal.list(_v1717)));
      }
      }
    else if(_v1717.isNil())
      return new ESLVal("JList",$null,ESLVal.list(expToJExp(e)));
    else return error(new ESLVal("case error at Pos(21887,22555)").add(ESLVal.list(_v1717)));
    }
  }
  private static ESLVal cmpToJExp = new ESLVal(new Function(new ESLVal("cmpToJExp"),null) { public ESLVal apply(ESLVal... args) { return cmpToJExp(args[0],args[1]); }});
  public static ESLVal moduleToJava(ESLVal module) {
    
    {ESLVal _v1718 = module;
      
      switch(_v1718.termName) {
      case "Module": {ESLVal $3374 = _v1718.termRef(0);
        ESLVal $3373 = _v1718.termRef(1);
        ESLVal $3372 = _v1718.termRef(2);
        ESLVal $3371 = _v1718.termRef(3);
        ESLVal $3370 = _v1718.termRef(4);
        ESLVal $3369 = _v1718.termRef(5);
        ESLVal $3368 = _v1718.termRef(6);
        
        {ESLVal path = $3374;
        
        {ESLVal name = $3373;
        
        {ESLVal exports = $3372;
        
        {ESLVal imports = $3371;
        
        {ESLVal x = $3370;
        
        {ESLVal y = $3369;
        
        {ESLVal defs = $3368;
        
        {ESLVal _v1771 = expandFunDefs.apply(mergeFunDefs.apply(defs));
        
        {ESLVal methods = new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal m = $l0.head();
                $l0 = $l0.tail();
                if(isFunBind.apply(m).boolVal) {$v.add(m);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(_v1771);
        ESLVal fields = new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal f = $l0.head();
                $l0 = $l0.tail();
                if(isBinding.apply(f).boolVal) {$v.add(f);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(_v1771);
        
        return renameJVarsModule(new ESLVal("JModule",name,exports,imports,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal m = $l0.head();
              $l0 = $l0.tail();
              $v.add(defToMethod(m));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(methods),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal d = $l0.head();
              $l0 = $l0.tail();
              $v.add(defToField(d));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(fields)));
      }
      }
      }
      }
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(22593,23055)").add(ESLVal.list(_v1718)));
    }
    }
  }
  public static ESLVal moduleToJava = new ESLVal(new Function(new ESLVal("moduleToJava"),null) { public ESLVal apply(ESLVal... args) { return moduleToJava(args[0]); }});
  private static ESLVal renameJVarsModule(ESLVal m) {
    
    {ESLVal _v1719 = m;
      
      switch(_v1719.termName) {
      case "JModule": {ESLVal $3379 = _v1719.termRef(0);
        ESLVal $3378 = _v1719.termRef(1);
        ESLVal $3377 = _v1719.termRef(2);
        ESLVal $3376 = _v1719.termRef(3);
        ESLVal $3375 = _v1719.termRef(4);
        
        {ESLVal name = $3379;
        
        {ESLVal exports = $3378;
        
        {ESLVal imports = $3377;
        
        {ESLVal ms = $3376;
        
        {ESLVal fs = $3375;
        
        {ESLVal fieldNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1720 = $qualArg;
                
                switch(_v1720.termName) {
                case "JField": {ESLVal $3382 = _v1720.termRef(0);
                  ESLVal $3381 = _v1720.termRef(1);
                  ESLVal $3380 = _v1720.termRef(2);
                  
                  {ESLVal n = $3382;
                  
                  {ESLVal t = $3381;
                  
                  {ESLVal e = $3380;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1720;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten();
        
        {ESLVal newFields = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1721 = $qualArg;
                
                switch(_v1721.termName) {
                case "JField": {ESLVal $3385 = _v1721.termRef(0);
                  ESLVal $3384 = _v1721.termRef(1);
                  ESLVal $3383 = _v1721.termRef(2);
                  
                  {ESLVal n = $3385;
                  
                  {ESLVal t = $3384;
                  
                  {ESLVal e = $3383;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp(e,fieldNames,emptyTable))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1721;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten();
        ESLVal newMethods = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1722 = $qualArg;
                
                switch(_v1722.termName) {
                case "JMethod": {ESLVal $3388 = _v1722.termRef(0);
                  ESLVal $3387 = _v1722.termRef(1);
                  ESLVal $3386 = _v1722.termRef(2);
                  
                  {ESLVal n = $3388;
                  
                  {ESLVal args = $3387;
                  
                  {ESLVal body = $3386;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JMethod",n,args,renameJVarsCommand(body,fieldNames.add(new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      ESLVal _v1769 = $args[0];
                  {ESLVal _v1723 = _v1769;
                        
                        switch(_v1723.termName) {
                        case "JDec": {ESLVal $3390 = _v1723.termRef(0);
                          ESLVal $3389 = _v1723.termRef(1);
                          
                          {ESLVal _v1770 = $3390;
                          
                          {ESLVal t = $3389;
                          
                          return ESLVal.list(ESLVal.list(_v1770));
                        }
                        }
                        }
                        default: {ESLVal _0 = _v1723;
                          
                          return ESLVal.list();
                        }
                      }
                      }
                    }
                  }).map(args).flatten().flatten()),emptyTable))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1722;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(ms).flatten().flatten();
        
        return new ESLVal("JModule",name,exports,imports,newMethods,newFields);
      }
      }
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(23095,23648)").add(ESLVal.list(_v1719)));
    }
    }
  }
  private static ESLVal renameJVarsModule = new ESLVal(new Function(new ESLVal("renameJVarsModule"),null) { public ESLVal apply(ESLVal... args) { return renameJVarsModule(args[0]); }});
  private static ESLVal renameJVarsExp(ESLVal e,ESLVal vars,ESLVal env) {
    
    {ESLVal _v1724 = e;
      
      switch(_v1724.termName) {
      case "JFun": {ESLVal $3472 = _v1724.termRef(0);
        ESLVal $3471 = _v1724.termRef(1);
        ESLVal $3470 = _v1724.termRef(2);
        ESLVal $3469 = _v1724.termRef(3);
        
        {ESLVal v0 = $3472;
        
        {ESLVal v1 = $3471;
        
        {ESLVal v2 = $3470;
        
        {ESLVal v3 = $3469;
        
        {ESLVal boundNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1728 = $qualArg;
                
                switch(_v1728.termName) {
                case "JDec": {ESLVal $3483 = _v1728.termRef(0);
                  ESLVal $3482 = _v1728.termRef(1);
                  
                  {ESLVal n = $3483;
                  
                  {ESLVal t = $3482;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                default: {ESLVal _0 = _v1728;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(v1).flatten().flatten();
        
        if(exists.apply(new ESLVal(new Function(new ESLVal("fun415"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal n = $args[0];
      return member.apply(n,boundNames);
        }
      }),vars).boolVal)
        {ESLVal newNames = new java.util.function.Function<ESLVal,ESLVal>() {
              public ESLVal apply(ESLVal $l0) {
                ESLVal $a = $nil;
                java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                while(!$l0.isNil()) { 
                  ESLVal n = $l0.head();
                  $l0 = $l0.tail();
                  $v.add(newName());
                }
                for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                return $a;
              }}.apply(boundNames);
          
          {ESLVal env1 = addEntries.apply(boundNames,newNames,env);
          
          return new ESLVal("JFun",v0,new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal n = $l0.head();
                $l0 = $l0.tail();
                $v.add(new ESLVal("JDec",n,$null));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(newNames),v2,renameJVarsCommand(v3,boundNames.add(vars),env1));
        }
        }
        else
          return new ESLVal("JFun",v0,v1,v2,renameJVarsCommand(v3,boundNames.add(vars),env));
      }
      }
      }
      }
      }
      }
    case "JApply": {ESLVal $3468 = _v1724.termRef(0);
        ESLVal $3467 = _v1724.termRef(1);
        
        {ESLVal v0 = $3468;
        
        {ESLVal v1 = $3467;
        
        return new ESLVal("JApply",renameJVarsExp(v0,vars,env),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal v = $l0.head();
              $l0 = $l0.tail();
              $v.add(renameJVarsExp(v,vars,env));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1));
      }
      }
      }
    case "JArrayRef": {ESLVal $3466 = _v1724.termRef(0);
        ESLVal $3465 = _v1724.termRef(1);
        
        {ESLVal a = $3466;
        
        {ESLVal i = $3465;
        
        return new ESLVal("JArrayRef",renameJVarsExp(a,vars,env),renameJVarsExp(i,vars,env));
      }
      }
      }
    case "JArrayUpdate": {ESLVal $3464 = _v1724.termRef(0);
        ESLVal $3463 = _v1724.termRef(1);
        ESLVal $3462 = _v1724.termRef(2);
        
        {ESLVal a = $3464;
        
        {ESLVal i = $3463;
        
        {ESLVal v = $3462;
        
        return new ESLVal("JArrayUpdate",renameJVarsExp(a,vars,env),renameJVarsExp(i,vars,env),renameJVarsExp(v,vars,env));
      }
      }
      }
      }
    case "JBecome": {ESLVal $3461 = _v1724.termRef(0);
        ESLVal $3460 = _v1724.termRef(1);
        
        {ESLVal _v1768 = $3461;
        
        {ESLVal es = $3460;
        
        return new ESLVal("JBecome",renameJVarsExp(_v1768,vars,env),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal v = $l0.head();
              $l0 = $l0.tail();
              $v.add(renameJVarsExp(v,vars,env));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(es));
      }
      }
      }
    case "JBinExp": {ESLVal $3459 = _v1724.termRef(0);
        ESLVal $3458 = _v1724.termRef(1);
        ESLVal $3457 = _v1724.termRef(2);
        
        {ESLVal v0 = $3459;
        
        {ESLVal v1 = $3458;
        
        {ESLVal v2 = $3457;
        
        return new ESLVal("JBinExp",renameJVarsExp(v0,vars,env),v1,renameJVarsExp(v2,vars,env));
      }
      }
      }
      }
    case "JCommandExp": {ESLVal $3456 = _v1724.termRef(0);
        ESLVal $3455 = _v1724.termRef(1);
        
        {ESLVal v0 = $3456;
        
        {ESLVal v1 = $3455;
        
        return new ESLVal("JCommandExp",renameJVarsCommand(v0,vars,env),v1);
      }
      }
      }
    case "JIfExp": {ESLVal $3454 = _v1724.termRef(0);
        ESLVal $3453 = _v1724.termRef(1);
        ESLVal $3452 = _v1724.termRef(2);
        
        {ESLVal v0 = $3454;
        
        {ESLVal v1 = $3453;
        
        {ESLVal v2 = $3452;
        
        return new ESLVal("JIfExp",renameJVarsExp(v0,vars,env),renameJVarsExp(v1,vars,env),renameJVarsExp(v2,vars,env));
      }
      }
      }
      }
    case "JConstExp": {ESLVal $3451 = _v1724.termRef(0);
        
        {ESLVal v0 = $3451;
        
        return e;
      }
      }
    case "JTerm": {ESLVal $3450 = _v1724.termRef(0);
        ESLVal $3449 = _v1724.termRef(1);
        
        {ESLVal v0 = $3450;
        
        {ESLVal v1 = $3449;
        
        return new ESLVal("JTerm",v0,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal v = $l0.head();
              $l0 = $l0.tail();
              $v.add(renameJVarsExp(v,vars,env));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1));
      }
      }
      }
    case "JTermRef": {ESLVal $3448 = _v1724.termRef(0);
        ESLVal $3447 = _v1724.termRef(1);
        
        {ESLVal v0 = $3448;
        
        {ESLVal v1 = $3447;
        
        return new ESLVal("JTermRef",renameJVarsExp(v0,vars,env),v1);
      }
      }
      }
    case "JList": {ESLVal $3446 = _v1724.termRef(0);
        ESLVal $3445 = _v1724.termRef(1);
        
        {ESLVal v0 = $3446;
        
        {ESLVal v1 = $3445;
        
        return new ESLVal("JList",v0,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal v = $l0.head();
              $l0 = $l0.tail();
              $v.add(renameJVarsExp(v,vars,env));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1));
      }
      }
      }
    case "JSet": {ESLVal $3444 = _v1724.termRef(0);
        ESLVal $3443 = _v1724.termRef(1);
        
        {ESLVal v0 = $3444;
        
        {ESLVal v1 = $3443;
        
        return new ESLVal("JSet",v0,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal v = $l0.head();
              $l0 = $l0.tail();
              $v.add(renameJVarsExp(v,vars,env));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1));
      }
      }
      }
    case "JBag": {ESLVal $3442 = _v1724.termRef(0);
        ESLVal $3441 = _v1724.termRef(1);
        
        {ESLVal v0 = $3442;
        
        {ESLVal v1 = $3441;
        
        return new ESLVal("JBag",v0,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal v = $l0.head();
              $l0 = $l0.tail();
              $v.add(renameJVarsExp(v,vars,env));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1));
      }
      }
      }
    case "JNil": {ESLVal $3440 = _v1724.termRef(0);
        
        {ESLVal v0 = $3440;
        
        return e;
      }
      }
    case "JNow": {
        return e;
      }
    case "JVar": {ESLVal $3439 = _v1724.termRef(0);
        ESLVal $3438 = _v1724.termRef(1);
        
        {ESLVal v0 = $3439;
        
        {ESLVal v1 = $3438;
        
        if(hasEntry.apply(v0,env).boolVal)
        return new ESLVal("JVar",lookup.apply(v0,env),v1);
        else
          return e;
      }
      }
      }
    case "JNull": {
        return e;
      }
    case "JError": {ESLVal $3437 = _v1724.termRef(0);
        
        {ESLVal v0 = $3437;
        
        return new ESLVal("JError",renameJVarsExp(v0,vars,env));
      }
      }
    case "JHead": {ESLVal $3436 = _v1724.termRef(0);
        
        {ESLVal v0 = $3436;
        
        return new ESLVal("JHead",renameJVarsExp(v0,vars,env));
      }
      }
    case "JTail": {ESLVal $3435 = _v1724.termRef(0);
        
        {ESLVal v0 = $3435;
        
        return new ESLVal("JTail",renameJVarsExp(v0,vars,env));
      }
      }
    case "JCastp": {ESLVal $3434 = _v1724.termRef(0);
        ESLVal $3433 = _v1724.termRef(1);
        ESLVal $3432 = _v1724.termRef(2);
        
        {ESLVal v0 = $3434;
        
        {ESLVal v1 = $3433;
        
        {ESLVal v2 = $3432;
        
        return new ESLVal("JCastp",v0,v1,renameJVarsExp(v2,vars,env));
      }
      }
      }
      }
    case "JCast": {ESLVal $3431 = _v1724.termRef(0);
        ESLVal $3430 = _v1724.termRef(1);
        
        {ESLVal v0 = $3431;
        
        {ESLVal v1 = $3430;
        
        return new ESLVal("JCast",v0,renameJVarsExp(v1,vars,env));
      }
      }
      }
    case "JCmpExp": {ESLVal $3429 = _v1724.termRef(0);
        
        {ESLVal cmp = $3429;
        
        return new ESLVal("JCmpExp",renameJVarsCmp(cmp,vars,env));
      }
      }
    case "JNot": {ESLVal $3428 = _v1724.termRef(0);
        
        {ESLVal _v1767 = $3428;
        
        return new ESLVal("JNot",renameJVarsExp(_v1767,vars,env));
      }
      }
    case "JNew": {ESLVal $3427 = _v1724.termRef(0);
        ESLVal $3426 = _v1724.termRef(1);
        
        {ESLVal b = $3427;
        
        {ESLVal args = $3426;
        
        return new ESLVal("JNew",renameJVarsExp(b,vars,env),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal a = $l0.head();
              $l0 = $l0.tail();
              $v.add(renameJVarsExp(a,vars,env));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(args));
      }
      }
      }
    case "JNewArray": {ESLVal $3425 = _v1724.termRef(0);
        
        {ESLVal b = $3425;
        
        return new ESLVal("JNewArray",renameJVarsExp(b,vars,env));
      }
      }
    case "JNewJava": {ESLVal $3424 = _v1724.termRef(0);
        ESLVal $3423 = _v1724.termRef(1);
        
        {ESLVal n = $3424;
        
        {ESLVal args = $3423;
        
        return new ESLVal("JNewJava",n,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal a = $l0.head();
              $l0 = $l0.tail();
              $v.add(renameJVarsExp(a,vars,env));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(args));
      }
      }
      }
    case "JNewTable": {
        return new ESLVal("JNewTable",new ESLVal[]{});
      }
    case "JMapFun": {ESLVal $3422 = _v1724.termRef(0);
        ESLVal $3421 = _v1724.termRef(1);
        
        {ESLVal f = $3422;
        
        {ESLVal l = $3421;
        
        return new ESLVal("JMapFun",renameJVarsExp(f,vars,env),renameJVarsExp(l,vars,env));
      }
      }
      }
    case "JRecord": {ESLVal $3420 = _v1724.termRef(0);
        
        {ESLVal fs = $3420;
        
        return new ESLVal("JRecord",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v1727 = $qualArg;
              
              switch(_v1727.termName) {
              case "JField": {ESLVal $3481 = _v1727.termRef(0);
                ESLVal $3480 = _v1727.termRef(1);
                ESLVal $3479 = _v1727.termRef(2);
                
                {ESLVal n = $3481;
                
                {ESLVal t = $3480;
                
                {ESLVal _v1766 = $3479;
                
                return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp(_v1766,vars,env))));
              }
              }
              }
              }
              default: {ESLVal _0 = _v1727;
                
                return ESLVal.list();
              }
            }
            }
          }
        }).map(fs).flatten().flatten());
      }
      }
    case "JFlatten": {ESLVal $3419 = _v1724.termRef(0);
        
        {ESLVal _v1765 = $3419;
        
        return new ESLVal("JFlatten",renameJVarsExp(_v1765,vars,env));
      }
      }
    case "JSend": {ESLVal $3418 = _v1724.termRef(0);
        ESLVal $3417 = _v1724.termRef(1);
        ESLVal $3416 = _v1724.termRef(2);
        
        {ESLVal _v1764 = $3418;
        
        {ESLVal n = $3417;
        
        {ESLVal es = $3416;
        
        return new ESLVal("JSend",renameJVarsExp(_v1764,vars,env),n,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(renameJVarsExp(e,vars,env));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(es));
      }
      }
      }
      }
    case "JSendSuper": {ESLVal $3415 = _v1724.termRef(0);
        
        {ESLVal _v1763 = $3415;
        
        return new ESLVal("JSendSuper",renameJVarsExp(_v1763,vars,env));
      }
      }
    case "JSendTimeSuper": {
        return new ESLVal("JSendTimeSuper",new ESLVal[]{});
      }
    case "JSelf": {
        return new ESLVal("JSelf",new ESLVal[]{});
      }
    case "JRef": {ESLVal $3414 = _v1724.termRef(0);
        ESLVal $3413 = _v1724.termRef(1);
        
        {ESLVal _v1762 = $3414;
        
        {ESLVal n = $3413;
        
        return new ESLVal("JRef",renameJVarsExp(_v1762,vars,env),n);
      }
      }
      }
    case "JRefSuper": {ESLVal $3412 = _v1724.termRef(0);
        
        {ESLVal n = $3412;
        
        return new ESLVal("JRefSuper",n);
      }
      }
    case "JBehaviour": {ESLVal $3411 = _v1724.termRef(0);
        ESLVal $3410 = _v1724.termRef(1);
        ESLVal $3409 = _v1724.termRef(2);
        ESLVal $3408 = _v1724.termRef(3);
        ESLVal $3407 = _v1724.termRef(4);
        ESLVal $3406 = _v1724.termRef(5);
        
        {ESLVal es = $3411;
        
        {ESLVal fs = $3410;
        
        {ESLVal methods = $3409;
        
        {ESLVal init = $3408;
        
        {ESLVal handler = $3407;
        
        {ESLVal time = $3406;
        
        return new ESLVal("JBehaviour",es,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v1726 = $qualArg;
              
              switch(_v1726.termName) {
              case "JField": {ESLVal $3478 = _v1726.termRef(0);
                ESLVal $3477 = _v1726.termRef(1);
                ESLVal $3476 = _v1726.termRef(2);
                
                {ESLVal n = $3478;
                
                {ESLVal t = $3477;
                
                {ESLVal _v1761 = $3476;
                
                return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp(_v1761,vars,env))));
              }
              }
              }
              }
              default: {ESLVal _0 = _v1726;
                
                return ESLVal.list();
              }
            }
            }
          }
        }).map(fs).flatten().flatten(),methods,renameJVarsExp(init,vars,env),renameJVarsExp(handler,vars,env),renameJVarsCommand(time,vars,env));
      }
      }
      }
      }
      }
      }
      }
    case "JExtendedBehaviour": {ESLVal $3405 = _v1724.termRef(0);
        ESLVal $3404 = _v1724.termRef(1);
        ESLVal $3403 = _v1724.termRef(2);
        ESLVal $3402 = _v1724.termRef(3);
        ESLVal $3401 = _v1724.termRef(4);
        ESLVal $3400 = _v1724.termRef(5);
        ESLVal $3399 = _v1724.termRef(6);
        
        {ESLVal es = $3405;
        
        {ESLVal parent = $3404;
        
        {ESLVal fs = $3403;
        
        {ESLVal methods = $3402;
        
        {ESLVal init = $3401;
        
        {ESLVal handler = $3400;
        
        {ESLVal time = $3399;
        
        return new ESLVal("JExtendedBehaviour",es,renameJVarsExp(parent,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v1725 = $qualArg;
              
              switch(_v1725.termName) {
              case "JField": {ESLVal $3475 = _v1725.termRef(0);
                ESLVal $3474 = _v1725.termRef(1);
                ESLVal $3473 = _v1725.termRef(2);
                
                {ESLVal n = $3475;
                
                {ESLVal t = $3474;
                
                {ESLVal _v1760 = $3473;
                
                return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp(_v1760,vars,env))));
              }
              }
              }
              }
              default: {ESLVal _0 = _v1725;
                
                return ESLVal.list();
              }
            }
            }
          }
        }).map(fs).flatten().flatten(),methods,renameJVarsExp(init,vars,env),renameJVarsExp(handler,vars,env),renameJVarsCommand(time,vars,env));
      }
      }
      }
      }
      }
      }
      }
      }
    case "JTry": {ESLVal $3398 = _v1724.termRef(0);
        ESLVal $3397 = _v1724.termRef(1);
        ESLVal $3396 = _v1724.termRef(2);
        
        {ESLVal _v1759 = $3398;
        
        {ESLVal n = $3397;
        
        {ESLVal c = $3396;
        
        return new ESLVal("JTry",renameJVarsExp(_v1759,vars,env),n,renameJVarsCommand(c,vars,env));
      }
      }
      }
      }
    case "JProbably": {ESLVal $3395 = _v1724.termRef(0);
        ESLVal $3394 = _v1724.termRef(1);
        ESLVal $3393 = _v1724.termRef(2);
        
        {ESLVal _v1758 = $3395;
        
        {ESLVal e1 = $3394;
        
        {ESLVal e2 = $3393;
        
        return new ESLVal("JProbably",renameJVarsExp(_v1758,vars,env),renameJVarsExp(e1,vars,env),renameJVarsExp(e2,vars,env));
      }
      }
      }
      }
    case "JGrab": {ESLVal $3392 = _v1724.termRef(0);
        ESLVal $3391 = _v1724.termRef(1);
        
        {ESLVal es = $3392;
        
        {ESLVal c = $3391;
        
        return new ESLVal("JGrab",new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(renameJVarsExp(e,vars,env));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(es),renameJVarsExp(c,vars,env));
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(23718,28394)").add(ESLVal.list(_v1724)));
    }
    }
  }
  private static ESLVal renameJVarsExp = new ESLVal(new Function(new ESLVal("renameJVarsExp"),null) { public ESLVal apply(ESLVal... args) { return renameJVarsExp(args[0],args[1],args[2]); }});
  private static ESLVal renameJVarsCmp(ESLVal c,ESLVal vars,ESLVal env) {
    
    {ESLVal _v1729 = c;
      
      switch(_v1729.termName) {
      case "JCmpList": {ESLVal $3492 = _v1729.termRef(0);
        
        {ESLVal e = $3492;
        
        return new ESLVal("JCmpList",renameJVarsExp(e,vars,env));
      }
      }
    case "JCmpOuter": {ESLVal $3491 = _v1729.termRef(0);
        ESLVal $3490 = _v1729.termRef(1);
        ESLVal $3489 = _v1729.termRef(2);
        
        {ESLVal n = $3491;
        
        {ESLVal e = $3490;
        
        {ESLVal _v1755 = $3489;
        
        {ESLVal _v1756 = remove.apply(n,vars);
        ESLVal _v1757 = addEntry.apply(n,n,env);
        
        return new ESLVal("JCmpOuter",n,renameJVarsExp(e,_v1756,_v1757),renameJVarsCmp(_v1755,_v1756,_v1757));
      }
      }
      }
      }
      }
    case "JCmpBind": {ESLVal $3488 = _v1729.termRef(0);
        ESLVal $3487 = _v1729.termRef(1);
        ESLVal $3486 = _v1729.termRef(2);
        
        {ESLVal n = $3488;
        
        {ESLVal e = $3487;
        
        {ESLVal _v1752 = $3486;
        
        {ESLVal _v1753 = remove.apply(n,vars);
        ESLVal _v1754 = addEntry.apply(n,n,env);
        
        return new ESLVal("JCmpBind",n,renameJVarsExp(e,_v1753,_v1754),renameJVarsCmp(_v1752,_v1753,_v1754));
      }
      }
      }
      }
      }
    case "JCmpIf": {ESLVal $3485 = _v1729.termRef(0);
        ESLVal $3484 = _v1729.termRef(1);
        
        {ESLVal e = $3485;
        
        {ESLVal _v1751 = $3484;
        
        return new ESLVal("JCmpIf",renameJVarsExp(e,vars,env),renameJVarsCmp(_v1751,vars,env));
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(28469,29050)").add(ESLVal.list(_v1729)));
    }
    }
  }
  private static ESLVal renameJVarsCmp = new ESLVal(new Function(new ESLVal("renameJVarsCmp"),null) { public ESLVal apply(ESLVal... args) { return renameJVarsCmp(args[0],args[1],args[2]); }});
  private static ESLVal newName() {
    
    {nameCount = nameCount.add($one);
    return new ESLVal("_v").add(nameCount);}
  }
  private static ESLVal newName = new ESLVal(new Function(new ESLVal("newName"),null) { public ESLVal apply(ESLVal... args) { return newName(); }});
  private static ESLVal renameJVarsCommand(ESLVal c,ESLVal vars,ESLVal env) {
    
    {ESLVal _v1730 = c;
      
      switch(_v1730.termName) {
      case "JBlock": {ESLVal $3533 = _v1730.termRef(0);
        
        {ESLVal v0 = $3533;
        
        return new ESLVal("JBlock",new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal c = $l0.head();
              $l0 = $l0.tail();
              $v.add(renameJVarsCommand(c,vars,env));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v0));
      }
      }
    case "JReturn": {ESLVal $3532 = _v1730.termRef(0);
        
        {ESLVal v0 = $3532;
        
        return new ESLVal("JReturn",renameJVarsExp(v0,vars,env));
      }
      }
    case "JSwitch": {ESLVal $3531 = _v1730.termRef(0);
        ESLVal $3530 = _v1730.termRef(1);
        ESLVal $3529 = _v1730.termRef(2);
        
        {ESLVal v0 = $3531;
        
        {ESLVal v1 = $3530;
        
        {ESLVal v2 = $3529;
        
        return error(new ESLVal("jswitch should not occur"));
      }
      }
      }
      }
    case "JSwitchList": {ESLVal $3528 = _v1730.termRef(0);
        ESLVal $3527 = _v1730.termRef(1);
        ESLVal $3526 = _v1730.termRef(2);
        ESLVal $3525 = _v1730.termRef(3);
        
        {ESLVal v0 = $3528;
        
        {ESLVal v1 = $3527;
        
        {ESLVal v2 = $3526;
        
        {ESLVal v3 = $3525;
        
        return new ESLVal("JSwitchList",renameJVarsExp(v0,vars,env),renameJVarsCommand(v1,vars,env),renameJVarsCommand(v2,vars,env),renameJVarsCommand(v3,vars,env));
      }
      }
      }
      }
      }
    case "JIfCommand": {ESLVal $3524 = _v1730.termRef(0);
        ESLVal $3523 = _v1730.termRef(1);
        ESLVal $3522 = _v1730.termRef(2);
        
        {ESLVal v0 = $3524;
        
        {ESLVal v1 = $3523;
        
        {ESLVal v2 = $3522;
        
        return new ESLVal("JIfCommand",renameJVarsExp(v0,vars,env),renameJVarsCommand(v1,vars,env),renameJVarsCommand(v2,vars,env));
      }
      }
      }
      }
    case "JCaseList": {ESLVal $3521 = _v1730.termRef(0);
        ESLVal $3520 = _v1730.termRef(1);
        ESLVal $3519 = _v1730.termRef(2);
        ESLVal $3518 = _v1730.termRef(3);
        
        {ESLVal v0 = $3521;
        
        {ESLVal v1 = $3520;
        
        {ESLVal v2 = $3519;
        
        {ESLVal v3 = $3518;
        
        return new ESLVal("JCaseList",renameJVarsExp(v0,vars,env),renameJVarsCommand(v1,vars,env),renameJVarsCommand(v2,vars,env),renameJVarsCommand(v3,vars,env));
      }
      }
      }
      }
      }
    case "JCaseInt": {ESLVal $3517 = _v1730.termRef(0);
        ESLVal $3516 = _v1730.termRef(1);
        ESLVal $3515 = _v1730.termRef(2);
        
        {ESLVal e = $3517;
        
        {ESLVal arms = $3516;
        
        {ESLVal alt = $3515;
        
        return new ESLVal("JCaseInt",renameJVarsExp(e,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v1743 = $qualArg;
              
              switch(_v1743.termName) {
              case "JIArm": {ESLVal $3569 = _v1743.termRef(0);
                ESLVal $3568 = _v1743.termRef(1);
                
                {ESLVal n = $3569;
                
                {ESLVal _v1750 = $3568;
                
                return ESLVal.list(ESLVal.list(new ESLVal("JIArm",n,renameJVarsCommand(_v1750,vars,env))));
              }
              }
              }
              default: {ESLVal _0 = _v1743;
                
                return ESLVal.list();
              }
            }
            }
          }
        }).map(arms).flatten().flatten(),renameJVarsCommand(alt,vars,env));
      }
      }
      }
      }
    case "JCaseStr": {ESLVal $3514 = _v1730.termRef(0);
        ESLVal $3513 = _v1730.termRef(1);
        ESLVal $3512 = _v1730.termRef(2);
        
        {ESLVal e = $3514;
        
        {ESLVal arms = $3513;
        
        {ESLVal alt = $3512;
        
        return new ESLVal("JCaseStr",renameJVarsExp(e,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v1742 = $qualArg;
              
              switch(_v1742.termName) {
              case "JSArm": {ESLVal $3567 = _v1742.termRef(0);
                ESLVal $3566 = _v1742.termRef(1);
                
                {ESLVal s = $3567;
                
                {ESLVal _v1749 = $3566;
                
                return ESLVal.list(ESLVal.list(new ESLVal("JSArm",s,renameJVarsCommand(_v1749,vars,env))));
              }
              }
              }
              default: {ESLVal _0 = _v1742;
                
                return ESLVal.list();
              }
            }
            }
          }
        }).map(arms).flatten().flatten(),renameJVarsCommand(alt,vars,env));
      }
      }
      }
      }
    case "JCaseBool": {ESLVal $3511 = _v1730.termRef(0);
        ESLVal $3510 = _v1730.termRef(1);
        ESLVal $3509 = _v1730.termRef(2);
        
        {ESLVal e = $3511;
        
        {ESLVal arms = $3510;
        
        {ESLVal alt = $3509;
        
        return new ESLVal("JCaseBool",renameJVarsExp(e,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v1741 = $qualArg;
              
              switch(_v1741.termName) {
              case "JBArm": {ESLVal $3565 = _v1741.termRef(0);
                ESLVal $3564 = _v1741.termRef(1);
                
                {ESLVal b = $3565;
                
                {ESLVal _v1748 = $3564;
                
                return ESLVal.list(ESLVal.list(new ESLVal("JBArm",b,renameJVarsCommand(_v1748,vars,env))));
              }
              }
              }
              default: {ESLVal _0 = _v1741;
                
                return ESLVal.list();
              }
            }
            }
          }
        }).map(arms).flatten().flatten(),renameJVarsCommand(alt,vars,env));
      }
      }
      }
      }
    case "JCaseTerm": {ESLVal $3508 = _v1730.termRef(0);
        ESLVal $3507 = _v1730.termRef(1);
        ESLVal $3506 = _v1730.termRef(2);
        
        {ESLVal e = $3508;
        
        {ESLVal arms = $3507;
        
        {ESLVal alt = $3506;
        
        return new ESLVal("JCaseTerm",renameJVarsExp(e,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v1740 = $qualArg;
              
              switch(_v1740.termName) {
              case "JTArm": {ESLVal $3563 = _v1740.termRef(0);
                ESLVal $3562 = _v1740.termRef(1);
                ESLVal $3561 = _v1740.termRef(2);
                
                {ESLVal n = $3563;
                
                {ESLVal i = $3562;
                
                {ESLVal _v1747 = $3561;
                
                return ESLVal.list(ESLVal.list(new ESLVal("JTArm",n,i,renameJVarsCommand(_v1747,vars,env))));
              }
              }
              }
              }
              default: {ESLVal _0 = _v1740;
                
                return ESLVal.list();
              }
            }
            }
          }
        }).map(arms).flatten().flatten(),renameJVarsCommand(alt,vars,env));
      }
      }
      }
      }
    case "JLet": {ESLVal $3505 = _v1730.termRef(0);
        ESLVal $3504 = _v1730.termRef(1);
        
        {ESLVal v0 = $3505;
        
        {ESLVal v1 = $3504;
        
        {ESLVal boundNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1737 = $qualArg;
                
                switch(_v1737.termName) {
                case "JField": {ESLVal $3554 = _v1737.termRef(0);
                  ESLVal $3553 = _v1737.termRef(1);
                  ESLVal $3552 = _v1737.termRef(2);
                  
                  {ESLVal n = $3554;
                  
                  {ESLVal t = $3553;
                  
                  {ESLVal e = $3552;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1737;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(v0).flatten().flatten();
        
        if(exists.apply(new ESLVal(new Function(new ESLVal("fun416"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal n = $args[0];
      return member.apply(n,vars);
        }
      }),boundNames).boolVal)
        {ESLVal newNames = new java.util.function.Function<ESLVal,ESLVal>() {
              public ESLVal apply(ESLVal $l0) {
                ESLVal $a = $nil;
                java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                while(!$l0.isNil()) { 
                  ESLVal n = $l0.head();
                  $l0 = $l0.tail();
                  $v.add(newName());
                }
                for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                return $a;
              }}.apply(boundNames);
          
          {ESLVal env1 = addEntries.apply(boundNames,newNames,env);
          
          return new ESLVal("JLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1738 = $qualArg;
                
                switch(_v1738.termName) {
                case "JField": {ESLVal $3557 = _v1738.termRef(0);
                  ESLVal $3556 = _v1738.termRef(1);
                  ESLVal $3555 = _v1738.termRef(2);
                  
                  {ESLVal n = $3557;
                  
                  {ESLVal t = $3556;
                  
                  {ESLVal e = $3555;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",lookup.apply(n,env1),t,renameJVarsExp(e,vars,env))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1738;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(v0).flatten().flatten(),renameJVarsCommand(v1,boundNames.add(vars),env1));
        }
        }
        else
          return new ESLVal("JLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v1739 = $qualArg;
                  
                  switch(_v1739.termName) {
                  case "JField": {ESLVal $3560 = _v1739.termRef(0);
                    ESLVal $3559 = _v1739.termRef(1);
                    ESLVal $3558 = _v1739.termRef(2);
                    
                    {ESLVal n = $3560;
                    
                    {ESLVal t = $3559;
                    
                    {ESLVal e = $3558;
                    
                    return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp(e,vars,env))));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v1739;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten(),renameJVarsCommand(v1,boundNames.add(vars),env));
      }
      }
      }
      }
    case "JPLet": {ESLVal $3503 = _v1730.termRef(0);
        ESLVal $3502 = _v1730.termRef(1);
        
        {ESLVal v0 = $3503;
        
        {ESLVal v1 = $3502;
        
        {ESLVal boundNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1734 = $qualArg;
                
                switch(_v1734.termName) {
                case "JField": {ESLVal $3545 = _v1734.termRef(0);
                  ESLVal $3544 = _v1734.termRef(1);
                  ESLVal $3543 = _v1734.termRef(2);
                  
                  {ESLVal n = $3545;
                  
                  {ESLVal t = $3544;
                  
                  {ESLVal e = $3543;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1734;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(v0).flatten().flatten();
        
        if(exists.apply(new ESLVal(new Function(new ESLVal("fun417"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal n = $args[0];
      return member.apply(n,vars);
        }
      }),boundNames).boolVal)
        {ESLVal newNames = new java.util.function.Function<ESLVal,ESLVal>() {
              public ESLVal apply(ESLVal $l0) {
                ESLVal $a = $nil;
                java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                while(!$l0.isNil()) { 
                  ESLVal n = $l0.head();
                  $l0 = $l0.tail();
                  $v.add(newName());
                }
                for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                return $a;
              }}.apply(boundNames);
          
          {ESLVal env1 = addEntries.apply(boundNames,newNames,env);
          
          return new ESLVal("JPLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1735 = $qualArg;
                
                switch(_v1735.termName) {
                case "JField": {ESLVal $3548 = _v1735.termRef(0);
                  ESLVal $3547 = _v1735.termRef(1);
                  ESLVal $3546 = _v1735.termRef(2);
                  
                  {ESLVal n = $3548;
                  
                  {ESLVal t = $3547;
                  
                  {ESLVal e = $3546;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",lookup.apply(n,env1),t,renameJVarsExp(e,vars,env))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1735;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(v0).flatten().flatten(),renameJVarsCommand(v1,boundNames.add(vars),env1));
        }
        }
        else
          return new ESLVal("JPLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v1736 = $qualArg;
                  
                  switch(_v1736.termName) {
                  case "JField": {ESLVal $3551 = _v1736.termRef(0);
                    ESLVal $3550 = _v1736.termRef(1);
                    ESLVal $3549 = _v1736.termRef(2);
                    
                    {ESLVal n = $3551;
                    
                    {ESLVal t = $3550;
                    
                    {ESLVal e = $3549;
                    
                    return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp(e,vars,env))));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v1736;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten(),renameJVarsCommand(v1,boundNames.add(vars),env));
      }
      }
      }
      }
    case "JLetRec": {ESLVal $3501 = _v1730.termRef(0);
        ESLVal $3500 = _v1730.termRef(1);
        
        {ESLVal v0 = $3501;
        
        {ESLVal v1 = $3500;
        
        {ESLVal boundNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1731 = $qualArg;
                
                switch(_v1731.termName) {
                case "JField": {ESLVal $3536 = _v1731.termRef(0);
                  ESLVal $3535 = _v1731.termRef(1);
                  ESLVal $3534 = _v1731.termRef(2);
                  
                  {ESLVal n = $3536;
                  
                  {ESLVal t = $3535;
                  
                  {ESLVal e = $3534;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1731;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(v0).flatten().flatten();
        
        if(exists.apply(new ESLVal(new Function(new ESLVal("fun418"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal n = $args[0];
      return member.apply(n,vars);
        }
      }),boundNames).boolVal)
        {ESLVal newNames = new java.util.function.Function<ESLVal,ESLVal>() {
              public ESLVal apply(ESLVal $l0) {
                ESLVal $a = $nil;
                java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                while(!$l0.isNil()) { 
                  ESLVal n = $l0.head();
                  $l0 = $l0.tail();
                  $v.add(newName());
                }
                for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                return $a;
              }}.apply(boundNames);
          
          {ESLVal _v1746 = addEntries.apply(boundNames,newNames,env);
          
          return new ESLVal("JLetRec",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1732 = $qualArg;
                
                switch(_v1732.termName) {
                case "JField": {ESLVal $3539 = _v1732.termRef(0);
                  ESLVal $3538 = _v1732.termRef(1);
                  ESLVal $3537 = _v1732.termRef(2);
                  
                  {ESLVal n = $3539;
                  
                  {ESLVal t = $3538;
                  
                  {ESLVal e = $3537;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",lookup.apply(n,_v1746),t,renameJVarsExp(e,vars,_v1746))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1732;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(v0).flatten().flatten(),renameJVarsCommand(v1,boundNames.add(vars),_v1746));
        }
        }
        else
          return new ESLVal("JLetRec",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v1733 = $qualArg;
                  
                  switch(_v1733.termName) {
                  case "JField": {ESLVal $3542 = _v1733.termRef(0);
                    ESLVal $3541 = _v1733.termRef(1);
                    ESLVal $3540 = _v1733.termRef(2);
                    
                    {ESLVal n = $3542;
                    
                    {ESLVal t = $3541;
                    
                    {ESLVal e = $3540;
                    
                    return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp(e,vars,env))));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v1733;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten(),renameJVarsCommand(v1,boundNames.add(vars),env));
      }
      }
      }
      }
    case "JStatement": {ESLVal $3499 = _v1730.termRef(0);
        
        {ESLVal e = $3499;
        
        return new ESLVal("JStatement",renameJVarsExp(e,vars,env));
      }
      }
    case "JUpdate": {ESLVal $3498 = _v1730.termRef(0);
        ESLVal $3497 = _v1730.termRef(1);
        
        {ESLVal name = $3498;
        
        {ESLVal value = $3497;
        
        if(hasEntry.apply(name,env).boolVal)
        return new ESLVal("JUpdate",lookup.apply(name,env),renameJVarsExp(value,vars,env));
        else
          {ESLVal v0 = $3498;
            
            {ESLVal v1 = $3497;
            
            return new ESLVal("JUpdate",v0,renameJVarsExp(v1,vars,env));
          }
          }
      }
      }
      }
    case "JFor": {ESLVal $3496 = _v1730.termRef(0);
        ESLVal $3495 = _v1730.termRef(1);
        ESLVal $3494 = _v1730.termRef(2);
        ESLVal $3493 = _v1730.termRef(3);
        
        {ESLVal l = $3496;
        
        {ESLVal n = $3495;
        
        {ESLVal e = $3494;
        
        {ESLVal _v1745 = $3493;
        
        return new ESLVal("JFor",l,n,renameJVarsExp(e,vars,env),renameJVarsCommand(_v1745,vars,env));
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(29288,33696)").add(ESLVal.list(_v1730)));
    }
    }
  }
  private static ESLVal renameJVarsCommand = new ESLVal(new Function(new ESLVal("renameJVarsCommand"),null) { public ESLVal apply(ESLVal... args) { return renameJVarsCommand(args[0],args[1],args[2]); }});
private static ESLVal addObserverJField = new ESLVal("JField",new ESLVal("addObserver"),$null,new ESLVal("JFun",new ESLVal("JConstExp",new ESLVal("JConstStr",new ESLVal("addObserver"))),ESLVal.list(new ESLVal("JDec",new ESLVal("o"),$null)),$null,new ESLVal("JBlock",ESLVal.list(new ESLVal("JUpdate",new ESLVal("$observers"),new ESLVal("JBinExp",new ESLVal("JVar",new ESLVal("o"),$null),new ESLVal("cons"),new ESLVal("JVar",new ESLVal("$observers"),$null))),new ESLVal("JReturn",new ESLVal("JSend",new ESLVal("JVar",new ESLVal("o"),$null),new ESLVal("Start"),ESLVal.list(new ESLVal("JSelf",new ESLVal[]{}),new ESLVal("JNow",new ESLVal[]{}),new ESLVal("JApply",new ESLVal("JVar",new ESLVal("observeState"),$null),ESLVal.list()))))))));
  private static ESLVal nameCount = $zero;
  public static ESLVal main = new ESLVal(new Function(new ESLVal("main"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      return new ESLVal(new BehaviourAdapter(true,getSelf(),new ESLVal("main")) {
          
          public ESLVal handle(ESLVal $m) {{ESLVal _v1744 = $m;
            
            return error(new ESLVal("case error at Pos(0,0)").add(ESLVal.list(_v1744)));
          }}
          public ESLVal get(String name) {
            switch(name) {
              
              default: throw new Error("ref illegal " + self + "." + name);
            }
          }
        public void handleTime(ESLVal $t) {
          {ESLVal n = $t;
            
            if($true.boolVal)
            {print.apply(new ESLVal("").add(emptyTable));
            stopAll.apply();}
            else
              {}
          }
        }
        public ESLVal init() {
            return $null;
          }
        });
    }
  });
public static void main(String[] args) {
    newActor(main,new ESLVal(new Actor())); 
  }
}