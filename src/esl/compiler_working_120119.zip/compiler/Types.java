package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
// import static esl.Lists.*;
import java.util.function.Supplier;
public class Types {
  public static ESLVal getSelf() { return $null; }
  public static ESLVal locStart(ESLVal l) {
    
    {ESLVal _v205 = l;
      
      switch(_v205.termName) {
      case "Pos": {ESLVal $596 = _v205.termRef(0);
        ESLVal $595 = _v205.termRef(1);
        
        {ESLVal start = $596;
        
        {ESLVal end = $595;
        
        return start;
      }
      }
      }
    case "TypedLoc": {ESLVal $594 = _v205.termRef(0);
        ESLVal $593 = _v205.termRef(1);
        ESLVal $592 = _v205.termRef(2);
        
        {ESLVal t = $594;
        
        {ESLVal start = $593;
        
        {ESLVal end = $592;
        
        return start;
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(5964,6048)").add(ESLVal.list(_v205)));
    }
    }
  }
  public static ESLVal locStart = new ESLVal(new Function(new ESLVal("locStart"),null) { public ESLVal apply(ESLVal... args) { return locStart(args[0]); }});
  public static ESLVal locEnd(ESLVal l) {
    
    {ESLVal _v206 = l;
      
      switch(_v206.termName) {
      case "Pos": {ESLVal $601 = _v206.termRef(0);
        ESLVal $600 = _v206.termRef(1);
        
        {ESLVal start = $601;
        
        {ESLVal end = $600;
        
        return end;
      }
      }
      }
    case "TypedLoc": {ESLVal $599 = _v206.termRef(0);
        ESLVal $598 = _v206.termRef(1);
        ESLVal $597 = _v206.termRef(2);
        
        {ESLVal t = $599;
        
        {ESLVal start = $598;
        
        {ESLVal end = $597;
        
        return end;
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(6075,6155)").add(ESLVal.list(_v206)));
    }
    }
  }
  public static ESLVal locEnd = new ESLVal(new Function(new ESLVal("locEnd"),null) { public ESLVal apply(ESLVal... args) { return locEnd(args[0]); }});
  public static ESLVal decName(ESLVal d) {
    
    {ESLVal _v207 = d;
      
      switch(_v207.termName) {
      case "Dec": {ESLVal $605 = _v207.termRef(0);
        ESLVal $604 = _v207.termRef(1);
        ESLVal $603 = _v207.termRef(2);
        ESLVal $602 = _v207.termRef(3);
        
        {ESLVal l = $605;
        
        {ESLVal n = $604;
        
        {ESLVal t = $603;
        
        {ESLVal dt = $602;
        
        return n;
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(6477,6599)").add(ESLVal.list(_v207)));
    }
    }
  }
  public static ESLVal decName = new ESLVal(new Function(new ESLVal("decName"),null) { public ESLVal apply(ESLVal... args) { return decName(args[0]); }});
  public static ESLVal decLoc(ESLVal d) {
    
    {ESLVal _v208 = d;
      
      switch(_v208.termName) {
      case "Dec": {ESLVal $609 = _v208.termRef(0);
        ESLVal $608 = _v208.termRef(1);
        ESLVal $607 = _v208.termRef(2);
        ESLVal $606 = _v208.termRef(3);
        
        {ESLVal l = $609;
        
        {ESLVal n = $608;
        
        {ESLVal t = $607;
        
        {ESLVal dt = $606;
        
        return l;
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(6703,6761)").add(ESLVal.list(_v208)));
    }
    }
  }
  public static ESLVal decLoc = new ESLVal(new Function(new ESLVal("decLoc"),null) { public ESLVal apply(ESLVal... args) { return decLoc(args[0]); }});
  public static ESLVal decType(ESLVal d) {
    
    {ESLVal _v209 = d;
      
      switch(_v209.termName) {
      case "Dec": {ESLVal $613 = _v209.termRef(0);
        ESLVal $612 = _v209.termRef(1);
        ESLVal $611 = _v209.termRef(2);
        ESLVal $610 = _v209.termRef(3);
        
        {ESLVal l = $613;
        
        {ESLVal n = $612;
        
        {ESLVal t = $611;
        
        {ESLVal dt = $610;
        
        return t;
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(6861,6919)").add(ESLVal.list(_v209)));
    }
    }
  }
  public static ESLVal decType = new ESLVal(new Function(new ESLVal("decType"),null) { public ESLVal apply(ESLVal... args) { return decType(args[0]); }});
  public static ESLVal isStrType(ESLVal t) {
    
    {ESLVal _v210 = t;
      
      switch(_v210.termName) {
      case "StrType": {ESLVal $614 = _v210.termRef(0);
        
        {ESLVal l = $614;
        
        return $true;
      }
      }
      default: {ESLVal _v1008 = _v210;
        
        return $false;
      }
    }
    }
  }
  public static ESLVal isStrType = new ESLVal(new Function(new ESLVal("isStrType"),null) { public ESLVal apply(ESLVal... args) { return isStrType(args[0]); }});
  public static ESLVal isIntType(ESLVal t) {
    
    {ESLVal _v211 = t;
      
      switch(_v211.termName) {
      case "IntType": {ESLVal $615 = _v211.termRef(0);
        
        {ESLVal l = $615;
        
        return $true;
      }
      }
      default: {ESLVal _v1007 = _v211;
        
        return $false;
      }
    }
    }
  }
  public static ESLVal isIntType = new ESLVal(new Function(new ESLVal("isIntType"),null) { public ESLVal apply(ESLVal... args) { return isIntType(args[0]); }});
  public static ESLVal isNumType(ESLVal t) {
    
    {ESLVal _v212 = t;
      
      switch(_v212.termName) {
      case "IntType": {ESLVal $617 = _v212.termRef(0);
        
        {ESLVal l = $617;
        
        return $true;
      }
      }
    case "FloatType": {ESLVal $616 = _v212.termRef(0);
        
        {ESLVal l = $616;
        
        return $true;
      }
      }
      default: {ESLVal _v1006 = _v212;
        
        return $false;
      }
    }
    }
  }
  public static ESLVal isNumType = new ESLVal(new Function(new ESLVal("isNumType"),null) { public ESLVal apply(ESLVal... args) { return isNumType(args[0]); }});
  public static ESLVal isBoolType(ESLVal t) {
    
    {ESLVal _v213 = t;
      
      switch(_v213.termName) {
      case "BoolType": {ESLVal $618 = _v213.termRef(0);
        
        {ESLVal l = $618;
        
        return $true;
      }
      }
      default: {ESLVal _v1005 = _v213;
        
        return $false;
      }
    }
    }
  }
  public static ESLVal isBoolType = new ESLVal(new Function(new ESLVal("isBoolType"),null) { public ESLVal apply(ESLVal... args) { return isBoolType(args[0]); }});
  public static ESLVal isFloatType(ESLVal t) {
    
    {ESLVal _v214 = t;
      
      switch(_v214.termName) {
      case "FloatType": {ESLVal $619 = _v214.termRef(0);
        
        {ESLVal l = $619;
        
        return $true;
      }
      }
      default: {ESLVal _v1004 = _v214;
        
        return $false;
      }
    }
    }
  }
  public static ESLVal isFloatType = new ESLVal(new Function(new ESLVal("isFloatType"),null) { public ESLVal apply(ESLVal... args) { return isFloatType(args[0]); }});
  public static ESLVal typeEqual(ESLVal t1,ESLVal t2) {
    
    {ESLVal b = typeEqual1(t1,t2);
      
      return b;
    }
  }
  public static ESLVal typeEqual = new ESLVal(new Function(new ESLVal("typeEqual"),null) { public ESLVal apply(ESLVal... args) { return typeEqual(args[0],args[1]); }});
  public static ESLVal typeEqual1(ESLVal t1,ESLVal t2) {
    
    if(t1.eql(t2).boolVal)
      return $true;
      else
        {ESLVal _v215 = t1;
          ESLVal _v216 = t2;
          
          switch(_v215.termName) {
          case "ArrayType": {ESLVal $789 = _v215.termRef(0);
            ESLVal $788 = _v215.termRef(1);
            
            switch(_v216.termName) {
            case "ArrayType": {ESLVal $791 = _v216.termRef(0);
              ESLVal $790 = _v216.termRef(1);
              
              {ESLVal l1 = $789;
              
              {ESLVal _v968 = $788;
              
              {ESLVal l2 = $791;
              
              {ESLVal _v969 = $790;
              
              return typeEqual(_v968,_v969);
            }
            }
            }
            }
            }
            default: switch(_v216.termName) {
              case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                ESLVal $646 = _v216.termRef(1);
                ESLVal $645 = _v216.termRef(2);
                
                {ESLVal _v984 = _v215;
                
                {ESLVal l = $647;
                
                {ESLVal op = $646;
                
                {ESLVal args = $645;
                
                return typeEqual(_v984,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                ESLVal $643 = _v216.termRef(1);
                ESLVal $642 = _v216.termRef(2);
                ESLVal $641 = _v216.termRef(3);
                
                {ESLVal _v982 = _v215;
                
                {ESLVal l2 = $644;
                
                {ESLVal _v983 = $643;
                
                {ESLVal ds2 = $642;
                
                {ESLVal ms2 = $641;
                
                return typeEqual(_v982,flattenAct(l2,_v983,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $640 = _v216.termRef(0);
                
                {ESLVal t = _v215;
                
                {ESLVal l1 = $640;
                
                return $true;
              }
              }
              }
            case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                ESLVal $636 = _v216.termRef(1);
                ESLVal $635 = _v216.termRef(2);
                
                switch($635.termName) {
                case "UnionType": {ESLVal $639 = $635.termRef(0);
                  ESLVal $638 = $635.termRef(1);
                  
                  {ESLVal _v979 = _v215;
                  
                  {ESLVal l = $637;
                  
                  {ESLVal state = $636;
                  
                  {ESLVal ul = $639;
                  
                  {ESLVal terms = $638;
                  
                  return typeEqual(_v979,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v980 = _v215;
                  
                  {ESLVal _v981 = _v216;
                  
                  return $false;
                }
                }
              }
              }
            case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                ESLVal $631 = _v216.termRef(1);
                ESLVal $630 = _v216.termRef(2);
                
                switch($630.termName) {
                case "UnionType": {ESLVal $634 = $630.termRef(0);
                  ESLVal $633 = $630.termRef(1);
                  
                  {ESLVal _v976 = _v215;
                  
                  {ESLVal l = $632;
                  
                  {ESLVal state = $631;
                  
                  {ESLVal ul = $634;
                  
                  {ESLVal terms = $633;
                  
                  return typeEqual(_v976,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v977 = _v215;
                  
                  {ESLVal _v978 = _v216;
                  
                  return $false;
                }
                }
              }
              }
            case "TermType": {ESLVal $629 = _v216.termRef(0);
                ESLVal $628 = _v216.termRef(1);
                ESLVal $627 = _v216.termRef(2);
                
                {ESLVal _v975 = _v215;
                
                {ESLVal l2 = $629;
                
                {ESLVal n2 = $628;
                
                {ESLVal args2 = $627;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                
                {ESLVal _v974 = _v215;
                
                {ESLVal f = $626;
                
                return typeEqual(_v974,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $625 = _v216.termRef(0);
                ESLVal $624 = _v216.termRef(1);
                ESLVal $623 = _v216.termRef(2);
                
                {ESLVal _v972 = _v215;
                
                {ESLVal l2 = $625;
                
                {ESLVal n2 = $624;
                
                {ESLVal _v973 = $623;
                
                return typeEqual(_v972,substType(new ESLVal("RecType",l2,n2,_v973),n2,_v973));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $622 = _v216.termRef(0);
                ESLVal $621 = _v216.termRef(1);
                ESLVal $620 = _v216.termRef(2);
                
                {ESLVal _v970 = _v215;
                
                {ESLVal l1 = $622;
                
                {ESLVal ns2 = $621;
                
                {ESLVal _v971 = $620;
                
                return typeEqual(_v970,_v971);
              }
              }
              }
              }
              }
              default: {ESLVal _v985 = _v215;
                
                {ESLVal _v986 = _v216;
                
                return $false;
              }
              }
            }
          }
          }
        case "ActType": {ESLVal $784 = _v215.termRef(0);
            ESLVal $783 = _v215.termRef(1);
            ESLVal $782 = _v215.termRef(2);
            
            switch(_v216.termName) {
            case "ActType": {ESLVal $787 = _v216.termRef(0);
              ESLVal $786 = _v216.termRef(1);
              ESLVal $785 = _v216.termRef(2);
              
              {ESLVal l1 = $784;
              
              {ESLVal exports1 = $783;
              
              {ESLVal handlers1 = $782;
              
              {ESLVal l2 = $787;
              
              {ESLVal exports2 = $786;
              
              {ESLVal handlers2 = $785;
              
              return actEqual(exports1,exports2,handlers1,handlers2);
            }
            }
            }
            }
            }
            }
            }
            default: switch(_v216.termName) {
              case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                ESLVal $646 = _v216.termRef(1);
                ESLVal $645 = _v216.termRef(2);
                
                {ESLVal _v965 = _v215;
                
                {ESLVal l = $647;
                
                {ESLVal op = $646;
                
                {ESLVal args = $645;
                
                return typeEqual(_v965,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                ESLVal $643 = _v216.termRef(1);
                ESLVal $642 = _v216.termRef(2);
                ESLVal $641 = _v216.termRef(3);
                
                {ESLVal _v963 = _v215;
                
                {ESLVal l2 = $644;
                
                {ESLVal _v964 = $643;
                
                {ESLVal ds2 = $642;
                
                {ESLVal ms2 = $641;
                
                return typeEqual(_v963,flattenAct(l2,_v964,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $640 = _v216.termRef(0);
                
                {ESLVal t = _v215;
                
                {ESLVal l1 = $640;
                
                return $true;
              }
              }
              }
            case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                ESLVal $636 = _v216.termRef(1);
                ESLVal $635 = _v216.termRef(2);
                
                switch($635.termName) {
                case "UnionType": {ESLVal $639 = $635.termRef(0);
                  ESLVal $638 = $635.termRef(1);
                  
                  {ESLVal _v960 = _v215;
                  
                  {ESLVal l = $637;
                  
                  {ESLVal state = $636;
                  
                  {ESLVal ul = $639;
                  
                  {ESLVal terms = $638;
                  
                  return typeEqual(_v960,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v961 = _v215;
                  
                  {ESLVal _v962 = _v216;
                  
                  return $false;
                }
                }
              }
              }
            case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                ESLVal $631 = _v216.termRef(1);
                ESLVal $630 = _v216.termRef(2);
                
                switch($630.termName) {
                case "UnionType": {ESLVal $634 = $630.termRef(0);
                  ESLVal $633 = $630.termRef(1);
                  
                  {ESLVal _v957 = _v215;
                  
                  {ESLVal l = $632;
                  
                  {ESLVal state = $631;
                  
                  {ESLVal ul = $634;
                  
                  {ESLVal terms = $633;
                  
                  return typeEqual(_v957,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v958 = _v215;
                  
                  {ESLVal _v959 = _v216;
                  
                  return $false;
                }
                }
              }
              }
            case "TermType": {ESLVal $629 = _v216.termRef(0);
                ESLVal $628 = _v216.termRef(1);
                ESLVal $627 = _v216.termRef(2);
                
                {ESLVal _v956 = _v215;
                
                {ESLVal l2 = $629;
                
                {ESLVal n2 = $628;
                
                {ESLVal args2 = $627;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                
                {ESLVal _v955 = _v215;
                
                {ESLVal f = $626;
                
                return typeEqual(_v955,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $625 = _v216.termRef(0);
                ESLVal $624 = _v216.termRef(1);
                ESLVal $623 = _v216.termRef(2);
                
                {ESLVal _v953 = _v215;
                
                {ESLVal l2 = $625;
                
                {ESLVal n2 = $624;
                
                {ESLVal _v954 = $623;
                
                return typeEqual(_v953,substType(new ESLVal("RecType",l2,n2,_v954),n2,_v954));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $622 = _v216.termRef(0);
                ESLVal $621 = _v216.termRef(1);
                ESLVal $620 = _v216.termRef(2);
                
                {ESLVal _v951 = _v215;
                
                {ESLVal l1 = $622;
                
                {ESLVal ns2 = $621;
                
                {ESLVal _v952 = $620;
                
                return typeEqual(_v951,_v952);
              }
              }
              }
              }
              }
              default: {ESLVal _v966 = _v215;
                
                {ESLVal _v967 = _v216;
                
                return $false;
              }
              }
            }
          }
          }
        case "ApplyTypeFun": {ESLVal $778 = _v215.termRef(0);
            ESLVal $777 = _v215.termRef(1);
            ESLVal $776 = _v215.termRef(2);
            
            switch(_v216.termName) {
            case "ApplyTypeFun": {ESLVal $781 = _v216.termRef(0);
              ESLVal $780 = _v216.termRef(1);
              ESLVal $779 = _v216.termRef(2);
              
              {ESLVal l1 = $778;
              
              {ESLVal op1 = $777;
              
              {ESLVal args1 = $776;
              
              {ESLVal l2 = $781;
              
              {ESLVal op2 = $780;
              
              {ESLVal args2 = $779;
              
              return typeEqual(op1,op2).and(typesEqual(args1,args2));
            }
            }
            }
            }
            }
            }
            }
            default: {ESLVal l = $778;
              
              {ESLVal op = $777;
              
              {ESLVal args = $776;
              
              {ESLVal _v950 = _v216;
              
              return typeEqual(applyTypeFun(l,forceType(op),args),_v950);
            }
            }
            }
            }
          }
          }
        case "ExtendedAct": {ESLVal $775 = _v215.termRef(0);
            ESLVal $774 = _v215.termRef(1);
            ESLVal $773 = _v215.termRef(2);
            ESLVal $772 = _v215.termRef(3);
            
            {ESLVal l1 = $775;
            
            {ESLVal _v948 = $774;
            
            {ESLVal ds1 = $773;
            
            {ESLVal ms1 = $772;
            
            {ESLVal _v949 = _v216;
            
            return typeEqual(flattenAct(l1,_v948,ds1,ms1),_v949);
          }
          }
          }
          }
          }
          }
        case "BoolType": {ESLVal $770 = _v215.termRef(0);
            
            switch(_v216.termName) {
            case "BoolType": {ESLVal $771 = _v216.termRef(0);
              
              {ESLVal l1 = $770;
              
              {ESLVal l2 = $771;
              
              return $true;
            }
            }
            }
            default: switch(_v216.termName) {
              case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                ESLVal $646 = _v216.termRef(1);
                ESLVal $645 = _v216.termRef(2);
                
                {ESLVal _v945 = _v215;
                
                {ESLVal l = $647;
                
                {ESLVal op = $646;
                
                {ESLVal args = $645;
                
                return typeEqual(_v945,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                ESLVal $643 = _v216.termRef(1);
                ESLVal $642 = _v216.termRef(2);
                ESLVal $641 = _v216.termRef(3);
                
                {ESLVal _v943 = _v215;
                
                {ESLVal l2 = $644;
                
                {ESLVal _v944 = $643;
                
                {ESLVal ds2 = $642;
                
                {ESLVal ms2 = $641;
                
                return typeEqual(_v943,flattenAct(l2,_v944,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $640 = _v216.termRef(0);
                
                {ESLVal t = _v215;
                
                {ESLVal l1 = $640;
                
                return $true;
              }
              }
              }
            case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                ESLVal $636 = _v216.termRef(1);
                ESLVal $635 = _v216.termRef(2);
                
                switch($635.termName) {
                case "UnionType": {ESLVal $639 = $635.termRef(0);
                  ESLVal $638 = $635.termRef(1);
                  
                  {ESLVal _v940 = _v215;
                  
                  {ESLVal l = $637;
                  
                  {ESLVal state = $636;
                  
                  {ESLVal ul = $639;
                  
                  {ESLVal terms = $638;
                  
                  return typeEqual(_v940,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v941 = _v215;
                  
                  {ESLVal _v942 = _v216;
                  
                  return $false;
                }
                }
              }
              }
            case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                ESLVal $631 = _v216.termRef(1);
                ESLVal $630 = _v216.termRef(2);
                
                switch($630.termName) {
                case "UnionType": {ESLVal $634 = $630.termRef(0);
                  ESLVal $633 = $630.termRef(1);
                  
                  {ESLVal _v937 = _v215;
                  
                  {ESLVal l = $632;
                  
                  {ESLVal state = $631;
                  
                  {ESLVal ul = $634;
                  
                  {ESLVal terms = $633;
                  
                  return typeEqual(_v937,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v938 = _v215;
                  
                  {ESLVal _v939 = _v216;
                  
                  return $false;
                }
                }
              }
              }
            case "TermType": {ESLVal $629 = _v216.termRef(0);
                ESLVal $628 = _v216.termRef(1);
                ESLVal $627 = _v216.termRef(2);
                
                {ESLVal _v936 = _v215;
                
                {ESLVal l2 = $629;
                
                {ESLVal n2 = $628;
                
                {ESLVal args2 = $627;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                
                {ESLVal _v935 = _v215;
                
                {ESLVal f = $626;
                
                return typeEqual(_v935,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $625 = _v216.termRef(0);
                ESLVal $624 = _v216.termRef(1);
                ESLVal $623 = _v216.termRef(2);
                
                {ESLVal _v933 = _v215;
                
                {ESLVal l2 = $625;
                
                {ESLVal n2 = $624;
                
                {ESLVal _v934 = $623;
                
                return typeEqual(_v933,substType(new ESLVal("RecType",l2,n2,_v934),n2,_v934));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $622 = _v216.termRef(0);
                ESLVal $621 = _v216.termRef(1);
                ESLVal $620 = _v216.termRef(2);
                
                {ESLVal _v931 = _v215;
                
                {ESLVal l1 = $622;
                
                {ESLVal ns2 = $621;
                
                {ESLVal _v932 = $620;
                
                return typeEqual(_v931,_v932);
              }
              }
              }
              }
              }
              default: {ESLVal _v946 = _v215;
                
                {ESLVal _v947 = _v216;
                
                return $false;
              }
              }
            }
          }
          }
        case "FloatType": {ESLVal $768 = _v215.termRef(0);
            
            switch(_v216.termName) {
            case "FloatType": {ESLVal $769 = _v216.termRef(0);
              
              {ESLVal l1 = $768;
              
              {ESLVal l2 = $769;
              
              return $true;
            }
            }
            }
            default: switch(_v216.termName) {
              case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                ESLVal $646 = _v216.termRef(1);
                ESLVal $645 = _v216.termRef(2);
                
                {ESLVal _v928 = _v215;
                
                {ESLVal l = $647;
                
                {ESLVal op = $646;
                
                {ESLVal args = $645;
                
                return typeEqual(_v928,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                ESLVal $643 = _v216.termRef(1);
                ESLVal $642 = _v216.termRef(2);
                ESLVal $641 = _v216.termRef(3);
                
                {ESLVal _v926 = _v215;
                
                {ESLVal l2 = $644;
                
                {ESLVal _v927 = $643;
                
                {ESLVal ds2 = $642;
                
                {ESLVal ms2 = $641;
                
                return typeEqual(_v926,flattenAct(l2,_v927,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $640 = _v216.termRef(0);
                
                {ESLVal t = _v215;
                
                {ESLVal l1 = $640;
                
                return $true;
              }
              }
              }
            case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                ESLVal $636 = _v216.termRef(1);
                ESLVal $635 = _v216.termRef(2);
                
                switch($635.termName) {
                case "UnionType": {ESLVal $639 = $635.termRef(0);
                  ESLVal $638 = $635.termRef(1);
                  
                  {ESLVal _v923 = _v215;
                  
                  {ESLVal l = $637;
                  
                  {ESLVal state = $636;
                  
                  {ESLVal ul = $639;
                  
                  {ESLVal terms = $638;
                  
                  return typeEqual(_v923,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v924 = _v215;
                  
                  {ESLVal _v925 = _v216;
                  
                  return $false;
                }
                }
              }
              }
            case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                ESLVal $631 = _v216.termRef(1);
                ESLVal $630 = _v216.termRef(2);
                
                switch($630.termName) {
                case "UnionType": {ESLVal $634 = $630.termRef(0);
                  ESLVal $633 = $630.termRef(1);
                  
                  {ESLVal _v920 = _v215;
                  
                  {ESLVal l = $632;
                  
                  {ESLVal state = $631;
                  
                  {ESLVal ul = $634;
                  
                  {ESLVal terms = $633;
                  
                  return typeEqual(_v920,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v921 = _v215;
                  
                  {ESLVal _v922 = _v216;
                  
                  return $false;
                }
                }
              }
              }
            case "TermType": {ESLVal $629 = _v216.termRef(0);
                ESLVal $628 = _v216.termRef(1);
                ESLVal $627 = _v216.termRef(2);
                
                {ESLVal _v919 = _v215;
                
                {ESLVal l2 = $629;
                
                {ESLVal n2 = $628;
                
                {ESLVal args2 = $627;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                
                {ESLVal _v918 = _v215;
                
                {ESLVal f = $626;
                
                return typeEqual(_v918,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $625 = _v216.termRef(0);
                ESLVal $624 = _v216.termRef(1);
                ESLVal $623 = _v216.termRef(2);
                
                {ESLVal _v916 = _v215;
                
                {ESLVal l2 = $625;
                
                {ESLVal n2 = $624;
                
                {ESLVal _v917 = $623;
                
                return typeEqual(_v916,substType(new ESLVal("RecType",l2,n2,_v917),n2,_v917));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $622 = _v216.termRef(0);
                ESLVal $621 = _v216.termRef(1);
                ESLVal $620 = _v216.termRef(2);
                
                {ESLVal _v914 = _v215;
                
                {ESLVal l1 = $622;
                
                {ESLVal ns2 = $621;
                
                {ESLVal _v915 = $620;
                
                return typeEqual(_v914,_v915);
              }
              }
              }
              }
              }
              default: {ESLVal _v929 = _v215;
                
                {ESLVal _v930 = _v216;
                
                return $false;
              }
              }
            }
          }
          }
        case "IntType": {ESLVal $766 = _v215.termRef(0);
            
            switch(_v216.termName) {
            case "IntType": {ESLVal $767 = _v216.termRef(0);
              
              {ESLVal l1 = $766;
              
              {ESLVal l2 = $767;
              
              return $true;
            }
            }
            }
            default: switch(_v216.termName) {
              case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                ESLVal $646 = _v216.termRef(1);
                ESLVal $645 = _v216.termRef(2);
                
                {ESLVal _v911 = _v215;
                
                {ESLVal l = $647;
                
                {ESLVal op = $646;
                
                {ESLVal args = $645;
                
                return typeEqual(_v911,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                ESLVal $643 = _v216.termRef(1);
                ESLVal $642 = _v216.termRef(2);
                ESLVal $641 = _v216.termRef(3);
                
                {ESLVal _v909 = _v215;
                
                {ESLVal l2 = $644;
                
                {ESLVal _v910 = $643;
                
                {ESLVal ds2 = $642;
                
                {ESLVal ms2 = $641;
                
                return typeEqual(_v909,flattenAct(l2,_v910,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $640 = _v216.termRef(0);
                
                {ESLVal t = _v215;
                
                {ESLVal l1 = $640;
                
                return $true;
              }
              }
              }
            case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                ESLVal $636 = _v216.termRef(1);
                ESLVal $635 = _v216.termRef(2);
                
                switch($635.termName) {
                case "UnionType": {ESLVal $639 = $635.termRef(0);
                  ESLVal $638 = $635.termRef(1);
                  
                  {ESLVal _v906 = _v215;
                  
                  {ESLVal l = $637;
                  
                  {ESLVal state = $636;
                  
                  {ESLVal ul = $639;
                  
                  {ESLVal terms = $638;
                  
                  return typeEqual(_v906,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v907 = _v215;
                  
                  {ESLVal _v908 = _v216;
                  
                  return $false;
                }
                }
              }
              }
            case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                ESLVal $631 = _v216.termRef(1);
                ESLVal $630 = _v216.termRef(2);
                
                switch($630.termName) {
                case "UnionType": {ESLVal $634 = $630.termRef(0);
                  ESLVal $633 = $630.termRef(1);
                  
                  {ESLVal _v903 = _v215;
                  
                  {ESLVal l = $632;
                  
                  {ESLVal state = $631;
                  
                  {ESLVal ul = $634;
                  
                  {ESLVal terms = $633;
                  
                  return typeEqual(_v903,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v904 = _v215;
                  
                  {ESLVal _v905 = _v216;
                  
                  return $false;
                }
                }
              }
              }
            case "TermType": {ESLVal $629 = _v216.termRef(0);
                ESLVal $628 = _v216.termRef(1);
                ESLVal $627 = _v216.termRef(2);
                
                {ESLVal _v902 = _v215;
                
                {ESLVal l2 = $629;
                
                {ESLVal n2 = $628;
                
                {ESLVal args2 = $627;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                
                {ESLVal _v901 = _v215;
                
                {ESLVal f = $626;
                
                return typeEqual(_v901,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $625 = _v216.termRef(0);
                ESLVal $624 = _v216.termRef(1);
                ESLVal $623 = _v216.termRef(2);
                
                {ESLVal _v899 = _v215;
                
                {ESLVal l2 = $625;
                
                {ESLVal n2 = $624;
                
                {ESLVal _v900 = $623;
                
                return typeEqual(_v899,substType(new ESLVal("RecType",l2,n2,_v900),n2,_v900));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $622 = _v216.termRef(0);
                ESLVal $621 = _v216.termRef(1);
                ESLVal $620 = _v216.termRef(2);
                
                {ESLVal _v897 = _v215;
                
                {ESLVal l1 = $622;
                
                {ESLVal ns2 = $621;
                
                {ESLVal _v898 = $620;
                
                return typeEqual(_v897,_v898);
              }
              }
              }
              }
              }
              default: {ESLVal _v912 = _v215;
                
                {ESLVal _v913 = _v216;
                
                return $false;
              }
              }
            }
          }
          }
        case "ListType": {ESLVal $752 = _v215.termRef(0);
            ESLVal $751 = _v215.termRef(1);
            
            switch(_v216.termName) {
            case "ListType": {ESLVal $765 = _v216.termRef(0);
              ESLVal $764 = _v216.termRef(1);
              
              {ESLVal l1 = $752;
              
              {ESLVal _v878 = $751;
              
              {ESLVal l2 = $765;
              
              {ESLVal _v879 = $764;
              
              return typeEqual(_v878,_v879);
            }
            }
            }
            }
            }
          case "ForallType": {ESLVal $755 = _v216.termRef(0);
              ESLVal $754 = _v216.termRef(1);
              ESLVal $753 = _v216.termRef(2);
              
              if($754.isCons())
              {ESLVal $756 = $754.head();
                ESLVal $757 = $754.tail();
                
                if($757.isCons())
                {ESLVal $758 = $757.head();
                  ESLVal $759 = $757.tail();
                  
                  switch(_v216.termName) {
                  case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                    ESLVal $646 = _v216.termRef(1);
                    ESLVal $645 = _v216.termRef(2);
                    
                    {ESLVal _v767 = _v215;
                    
                    {ESLVal l = $647;
                    
                    {ESLVal op = $646;
                    
                    {ESLVal args = $645;
                    
                    return typeEqual(_v767,applyTypeFun(l,forceType(op),args));
                  }
                  }
                  }
                  }
                  }
                case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                    ESLVal $643 = _v216.termRef(1);
                    ESLVal $642 = _v216.termRef(2);
                    ESLVal $641 = _v216.termRef(3);
                    
                    {ESLVal _v765 = _v215;
                    
                    {ESLVal l2 = $644;
                    
                    {ESLVal _v766 = $643;
                    
                    {ESLVal ds2 = $642;
                    
                    {ESLVal ms2 = $641;
                    
                    return typeEqual(_v765,flattenAct(l2,_v766,ds2,ms2));
                  }
                  }
                  }
                  }
                  }
                  }
                case "VoidType": {ESLVal $640 = _v216.termRef(0);
                    
                    {ESLVal t = _v215;
                    
                    {ESLVal l1 = $640;
                    
                    return $true;
                  }
                  }
                  }
                case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                    ESLVal $636 = _v216.termRef(1);
                    ESLVal $635 = _v216.termRef(2);
                    
                    switch($635.termName) {
                    case "UnionType": {ESLVal $639 = $635.termRef(0);
                      ESLVal $638 = $635.termRef(1);
                      
                      {ESLVal _v762 = _v215;
                      
                      {ESLVal l = $637;
                      
                      {ESLVal state = $636;
                      
                      {ESLVal ul = $639;
                      
                      {ESLVal terms = $638;
                      
                      return typeEqual(_v762,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                    }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal _v763 = _v215;
                      
                      {ESLVal _v764 = _v216;
                      
                      return $false;
                    }
                    }
                  }
                  }
                case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                    ESLVal $631 = _v216.termRef(1);
                    ESLVal $630 = _v216.termRef(2);
                    
                    switch($630.termName) {
                    case "UnionType": {ESLVal $634 = $630.termRef(0);
                      ESLVal $633 = $630.termRef(1);
                      
                      {ESLVal _v759 = _v215;
                      
                      {ESLVal l = $632;
                      
                      {ESLVal state = $631;
                      
                      {ESLVal ul = $634;
                      
                      {ESLVal terms = $633;
                      
                      return typeEqual(_v759,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                    }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal _v760 = _v215;
                      
                      {ESLVal _v761 = _v216;
                      
                      return $false;
                    }
                    }
                  }
                  }
                case "TermType": {ESLVal $629 = _v216.termRef(0);
                    ESLVal $628 = _v216.termRef(1);
                    ESLVal $627 = _v216.termRef(2);
                    
                    {ESLVal _v758 = _v215;
                    
                    {ESLVal l2 = $629;
                    
                    {ESLVal n2 = $628;
                    
                    {ESLVal args2 = $627;
                    
                    return $false;
                  }
                  }
                  }
                  }
                  }
                case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                    
                    {ESLVal _v757 = _v215;
                    
                    {ESLVal f = $626;
                    
                    return typeEqual(_v757,f.apply());
                  }
                  }
                  }
                case "RecType": {ESLVal $625 = _v216.termRef(0);
                    ESLVal $624 = _v216.termRef(1);
                    ESLVal $623 = _v216.termRef(2);
                    
                    {ESLVal _v755 = _v215;
                    
                    {ESLVal l2 = $625;
                    
                    {ESLVal n2 = $624;
                    
                    {ESLVal _v756 = $623;
                    
                    return typeEqual(_v755,substType(new ESLVal("RecType",l2,n2,_v756),n2,_v756));
                  }
                  }
                  }
                  }
                  }
                case "ForallType": {ESLVal $622 = _v216.termRef(0);
                    ESLVal $621 = _v216.termRef(1);
                    ESLVal $620 = _v216.termRef(2);
                    
                    {ESLVal _v753 = _v215;
                    
                    {ESLVal l1 = $622;
                    
                    {ESLVal ns2 = $621;
                    
                    {ESLVal _v754 = $620;
                    
                    return typeEqual(_v753,_v754);
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v768 = _v215;
                    
                    {ESLVal _v769 = _v216;
                    
                    return $false;
                  }
                  }
                }
                }
              else if($757.isNil())
                switch($753.termName) {
                  case "ListType": {ESLVal $761 = $753.termRef(0);
                    ESLVal $760 = $753.termRef(1);
                    
                    switch($760.termName) {
                    case "VarType": {ESLVal $763 = $760.termRef(0);
                      ESLVal $762 = $760.termRef(1);
                      
                      {ESLVal l1 = $752;
                      
                      {ESLVal _v770 = $751;
                      
                      {ESLVal l2 = $755;
                      
                      {ESLVal v1 = $756;
                      
                      {ESLVal l3 = $761;
                      
                      {ESLVal l4 = $763;
                      
                      {ESLVal v2 = $762;
                      
                      if(v1.eql(v2).boolVal)
                      return $true;
                      else
                        switch(_v216.termName) {
                          case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                            ESLVal $646 = _v216.termRef(1);
                            ESLVal $645 = _v216.termRef(2);
                            
                            {ESLVal _v790 = _v215;
                            
                            {ESLVal l = $647;
                            
                            {ESLVal op = $646;
                            
                            {ESLVal args = $645;
                            
                            return typeEqual(_v790,applyTypeFun(l,forceType(op),args));
                          }
                          }
                          }
                          }
                          }
                        case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                            ESLVal $643 = _v216.termRef(1);
                            ESLVal $642 = _v216.termRef(2);
                            ESLVal $641 = _v216.termRef(3);
                            
                            {ESLVal _v787 = _v215;
                            
                            {ESLVal _v788 = $644;
                            
                            {ESLVal _v789 = $643;
                            
                            {ESLVal ds2 = $642;
                            
                            {ESLVal ms2 = $641;
                            
                            return typeEqual(_v787,flattenAct(_v788,_v789,ds2,ms2));
                          }
                          }
                          }
                          }
                          }
                          }
                        case "VoidType": {ESLVal $640 = _v216.termRef(0);
                            
                            {ESLVal t = _v215;
                            
                            {ESLVal _v786 = $640;
                            
                            return $true;
                          }
                          }
                          }
                        case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                            ESLVal $636 = _v216.termRef(1);
                            ESLVal $635 = _v216.termRef(2);
                            
                            switch($635.termName) {
                            case "UnionType": {ESLVal $639 = $635.termRef(0);
                              ESLVal $638 = $635.termRef(1);
                              
                              {ESLVal _v783 = _v215;
                              
                              {ESLVal l = $637;
                              
                              {ESLVal state = $636;
                              
                              {ESLVal ul = $639;
                              
                              {ESLVal terms = $638;
                              
                              return typeEqual(_v783,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                            }
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v784 = _v215;
                              
                              {ESLVal _v785 = _v216;
                              
                              return $false;
                            }
                            }
                          }
                          }
                        case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                            ESLVal $631 = _v216.termRef(1);
                            ESLVal $630 = _v216.termRef(2);
                            
                            switch($630.termName) {
                            case "UnionType": {ESLVal $634 = $630.termRef(0);
                              ESLVal $633 = $630.termRef(1);
                              
                              {ESLVal _v780 = _v215;
                              
                              {ESLVal l = $632;
                              
                              {ESLVal state = $631;
                              
                              {ESLVal ul = $634;
                              
                              {ESLVal terms = $633;
                              
                              return typeEqual(_v780,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                            }
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v781 = _v215;
                              
                              {ESLVal _v782 = _v216;
                              
                              return $false;
                            }
                            }
                          }
                          }
                        case "TermType": {ESLVal $629 = _v216.termRef(0);
                            ESLVal $628 = _v216.termRef(1);
                            ESLVal $627 = _v216.termRef(2);
                            
                            {ESLVal _v778 = _v215;
                            
                            {ESLVal _v779 = $629;
                            
                            {ESLVal n2 = $628;
                            
                            {ESLVal args2 = $627;
                            
                            return $false;
                          }
                          }
                          }
                          }
                          }
                        case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                            
                            {ESLVal _v777 = _v215;
                            
                            {ESLVal f = $626;
                            
                            return typeEqual(_v777,f.apply());
                          }
                          }
                          }
                        case "RecType": {ESLVal $625 = _v216.termRef(0);
                            ESLVal $624 = _v216.termRef(1);
                            ESLVal $623 = _v216.termRef(2);
                            
                            {ESLVal _v774 = _v215;
                            
                            {ESLVal _v775 = $625;
                            
                            {ESLVal n2 = $624;
                            
                            {ESLVal _v776 = $623;
                            
                            return typeEqual(_v774,substType(new ESLVal("RecType",_v775,n2,_v776),n2,_v776));
                          }
                          }
                          }
                          }
                          }
                        case "ForallType": {ESLVal $622 = _v216.termRef(0);
                            ESLVal $621 = _v216.termRef(1);
                            ESLVal $620 = _v216.termRef(2);
                            
                            {ESLVal _v771 = _v215;
                            
                            {ESLVal _v772 = $622;
                            
                            {ESLVal ns2 = $621;
                            
                            {ESLVal _v773 = $620;
                            
                            return typeEqual(_v771,_v773);
                          }
                          }
                          }
                          }
                          }
                          default: {ESLVal _v791 = _v215;
                            
                            {ESLVal _v792 = _v216;
                            
                            return $false;
                          }
                          }
                        }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: switch(_v216.termName) {
                      case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                        ESLVal $646 = _v216.termRef(1);
                        ESLVal $645 = _v216.termRef(2);
                        
                        {ESLVal _v807 = _v215;
                        
                        {ESLVal l = $647;
                        
                        {ESLVal op = $646;
                        
                        {ESLVal args = $645;
                        
                        return typeEqual(_v807,applyTypeFun(l,forceType(op),args));
                      }
                      }
                      }
                      }
                      }
                    case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                        ESLVal $643 = _v216.termRef(1);
                        ESLVal $642 = _v216.termRef(2);
                        ESLVal $641 = _v216.termRef(3);
                        
                        {ESLVal _v805 = _v215;
                        
                        {ESLVal l2 = $644;
                        
                        {ESLVal _v806 = $643;
                        
                        {ESLVal ds2 = $642;
                        
                        {ESLVal ms2 = $641;
                        
                        return typeEqual(_v805,flattenAct(l2,_v806,ds2,ms2));
                      }
                      }
                      }
                      }
                      }
                      }
                    case "VoidType": {ESLVal $640 = _v216.termRef(0);
                        
                        {ESLVal t = _v215;
                        
                        {ESLVal l1 = $640;
                        
                        return $true;
                      }
                      }
                      }
                    case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                        ESLVal $636 = _v216.termRef(1);
                        ESLVal $635 = _v216.termRef(2);
                        
                        switch($635.termName) {
                        case "UnionType": {ESLVal $639 = $635.termRef(0);
                          ESLVal $638 = $635.termRef(1);
                          
                          {ESLVal _v802 = _v215;
                          
                          {ESLVal l = $637;
                          
                          {ESLVal state = $636;
                          
                          {ESLVal ul = $639;
                          
                          {ESLVal terms = $638;
                          
                          return typeEqual(_v802,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                        }
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal _v803 = _v215;
                          
                          {ESLVal _v804 = _v216;
                          
                          return $false;
                        }
                        }
                      }
                      }
                    case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                        ESLVal $631 = _v216.termRef(1);
                        ESLVal $630 = _v216.termRef(2);
                        
                        switch($630.termName) {
                        case "UnionType": {ESLVal $634 = $630.termRef(0);
                          ESLVal $633 = $630.termRef(1);
                          
                          {ESLVal _v799 = _v215;
                          
                          {ESLVal l = $632;
                          
                          {ESLVal state = $631;
                          
                          {ESLVal ul = $634;
                          
                          {ESLVal terms = $633;
                          
                          return typeEqual(_v799,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                        }
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal _v800 = _v215;
                          
                          {ESLVal _v801 = _v216;
                          
                          return $false;
                        }
                        }
                      }
                      }
                    case "TermType": {ESLVal $629 = _v216.termRef(0);
                        ESLVal $628 = _v216.termRef(1);
                        ESLVal $627 = _v216.termRef(2);
                        
                        {ESLVal _v798 = _v215;
                        
                        {ESLVal l2 = $629;
                        
                        {ESLVal n2 = $628;
                        
                        {ESLVal args2 = $627;
                        
                        return $false;
                      }
                      }
                      }
                      }
                      }
                    case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                        
                        {ESLVal _v797 = _v215;
                        
                        {ESLVal f = $626;
                        
                        return typeEqual(_v797,f.apply());
                      }
                      }
                      }
                    case "RecType": {ESLVal $625 = _v216.termRef(0);
                        ESLVal $624 = _v216.termRef(1);
                        ESLVal $623 = _v216.termRef(2);
                        
                        {ESLVal _v795 = _v215;
                        
                        {ESLVal l2 = $625;
                        
                        {ESLVal n2 = $624;
                        
                        {ESLVal _v796 = $623;
                        
                        return typeEqual(_v795,substType(new ESLVal("RecType",l2,n2,_v796),n2,_v796));
                      }
                      }
                      }
                      }
                      }
                    case "ForallType": {ESLVal $622 = _v216.termRef(0);
                        ESLVal $621 = _v216.termRef(1);
                        ESLVal $620 = _v216.termRef(2);
                        
                        {ESLVal _v793 = _v215;
                        
                        {ESLVal l1 = $622;
                        
                        {ESLVal ns2 = $621;
                        
                        {ESLVal _v794 = $620;
                        
                        return typeEqual(_v793,_v794);
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal _v808 = _v215;
                        
                        {ESLVal _v809 = _v216;
                        
                        return $false;
                      }
                      }
                    }
                  }
                  }
                  default: switch(_v216.termName) {
                    case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                      ESLVal $646 = _v216.termRef(1);
                      ESLVal $645 = _v216.termRef(2);
                      
                      {ESLVal _v824 = _v215;
                      
                      {ESLVal l = $647;
                      
                      {ESLVal op = $646;
                      
                      {ESLVal args = $645;
                      
                      return typeEqual(_v824,applyTypeFun(l,forceType(op),args));
                    }
                    }
                    }
                    }
                    }
                  case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                      ESLVal $643 = _v216.termRef(1);
                      ESLVal $642 = _v216.termRef(2);
                      ESLVal $641 = _v216.termRef(3);
                      
                      {ESLVal _v822 = _v215;
                      
                      {ESLVal l2 = $644;
                      
                      {ESLVal _v823 = $643;
                      
                      {ESLVal ds2 = $642;
                      
                      {ESLVal ms2 = $641;
                      
                      return typeEqual(_v822,flattenAct(l2,_v823,ds2,ms2));
                    }
                    }
                    }
                    }
                    }
                    }
                  case "VoidType": {ESLVal $640 = _v216.termRef(0);
                      
                      {ESLVal t = _v215;
                      
                      {ESLVal l1 = $640;
                      
                      return $true;
                    }
                    }
                    }
                  case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                      ESLVal $636 = _v216.termRef(1);
                      ESLVal $635 = _v216.termRef(2);
                      
                      switch($635.termName) {
                      case "UnionType": {ESLVal $639 = $635.termRef(0);
                        ESLVal $638 = $635.termRef(1);
                        
                        {ESLVal _v819 = _v215;
                        
                        {ESLVal l = $637;
                        
                        {ESLVal state = $636;
                        
                        {ESLVal ul = $639;
                        
                        {ESLVal terms = $638;
                        
                        return typeEqual(_v819,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                      }
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal _v820 = _v215;
                        
                        {ESLVal _v821 = _v216;
                        
                        return $false;
                      }
                      }
                    }
                    }
                  case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                      ESLVal $631 = _v216.termRef(1);
                      ESLVal $630 = _v216.termRef(2);
                      
                      switch($630.termName) {
                      case "UnionType": {ESLVal $634 = $630.termRef(0);
                        ESLVal $633 = $630.termRef(1);
                        
                        {ESLVal _v816 = _v215;
                        
                        {ESLVal l = $632;
                        
                        {ESLVal state = $631;
                        
                        {ESLVal ul = $634;
                        
                        {ESLVal terms = $633;
                        
                        return typeEqual(_v816,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                      }
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal _v817 = _v215;
                        
                        {ESLVal _v818 = _v216;
                        
                        return $false;
                      }
                      }
                    }
                    }
                  case "TermType": {ESLVal $629 = _v216.termRef(0);
                      ESLVal $628 = _v216.termRef(1);
                      ESLVal $627 = _v216.termRef(2);
                      
                      {ESLVal _v815 = _v215;
                      
                      {ESLVal l2 = $629;
                      
                      {ESLVal n2 = $628;
                      
                      {ESLVal args2 = $627;
                      
                      return $false;
                    }
                    }
                    }
                    }
                    }
                  case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                      
                      {ESLVal _v814 = _v215;
                      
                      {ESLVal f = $626;
                      
                      return typeEqual(_v814,f.apply());
                    }
                    }
                    }
                  case "RecType": {ESLVal $625 = _v216.termRef(0);
                      ESLVal $624 = _v216.termRef(1);
                      ESLVal $623 = _v216.termRef(2);
                      
                      {ESLVal _v812 = _v215;
                      
                      {ESLVal l2 = $625;
                      
                      {ESLVal n2 = $624;
                      
                      {ESLVal _v813 = $623;
                      
                      return typeEqual(_v812,substType(new ESLVal("RecType",l2,n2,_v813),n2,_v813));
                    }
                    }
                    }
                    }
                    }
                  case "ForallType": {ESLVal $622 = _v216.termRef(0);
                      ESLVal $621 = _v216.termRef(1);
                      ESLVal $620 = _v216.termRef(2);
                      
                      {ESLVal _v810 = _v215;
                      
                      {ESLVal l1 = $622;
                      
                      {ESLVal ns2 = $621;
                      
                      {ESLVal _v811 = $620;
                      
                      return typeEqual(_v810,_v811);
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal _v825 = _v215;
                      
                      {ESLVal _v826 = _v216;
                      
                      return $false;
                    }
                    }
                  }
                }
              else switch(_v216.termName) {
                  case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                    ESLVal $646 = _v216.termRef(1);
                    ESLVal $645 = _v216.termRef(2);
                    
                    {ESLVal _v841 = _v215;
                    
                    {ESLVal l = $647;
                    
                    {ESLVal op = $646;
                    
                    {ESLVal args = $645;
                    
                    return typeEqual(_v841,applyTypeFun(l,forceType(op),args));
                  }
                  }
                  }
                  }
                  }
                case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                    ESLVal $643 = _v216.termRef(1);
                    ESLVal $642 = _v216.termRef(2);
                    ESLVal $641 = _v216.termRef(3);
                    
                    {ESLVal _v839 = _v215;
                    
                    {ESLVal l2 = $644;
                    
                    {ESLVal _v840 = $643;
                    
                    {ESLVal ds2 = $642;
                    
                    {ESLVal ms2 = $641;
                    
                    return typeEqual(_v839,flattenAct(l2,_v840,ds2,ms2));
                  }
                  }
                  }
                  }
                  }
                  }
                case "VoidType": {ESLVal $640 = _v216.termRef(0);
                    
                    {ESLVal t = _v215;
                    
                    {ESLVal l1 = $640;
                    
                    return $true;
                  }
                  }
                  }
                case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                    ESLVal $636 = _v216.termRef(1);
                    ESLVal $635 = _v216.termRef(2);
                    
                    switch($635.termName) {
                    case "UnionType": {ESLVal $639 = $635.termRef(0);
                      ESLVal $638 = $635.termRef(1);
                      
                      {ESLVal _v836 = _v215;
                      
                      {ESLVal l = $637;
                      
                      {ESLVal state = $636;
                      
                      {ESLVal ul = $639;
                      
                      {ESLVal terms = $638;
                      
                      return typeEqual(_v836,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                    }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal _v837 = _v215;
                      
                      {ESLVal _v838 = _v216;
                      
                      return $false;
                    }
                    }
                  }
                  }
                case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                    ESLVal $631 = _v216.termRef(1);
                    ESLVal $630 = _v216.termRef(2);
                    
                    switch($630.termName) {
                    case "UnionType": {ESLVal $634 = $630.termRef(0);
                      ESLVal $633 = $630.termRef(1);
                      
                      {ESLVal _v833 = _v215;
                      
                      {ESLVal l = $632;
                      
                      {ESLVal state = $631;
                      
                      {ESLVal ul = $634;
                      
                      {ESLVal terms = $633;
                      
                      return typeEqual(_v833,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                    }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal _v834 = _v215;
                      
                      {ESLVal _v835 = _v216;
                      
                      return $false;
                    }
                    }
                  }
                  }
                case "TermType": {ESLVal $629 = _v216.termRef(0);
                    ESLVal $628 = _v216.termRef(1);
                    ESLVal $627 = _v216.termRef(2);
                    
                    {ESLVal _v832 = _v215;
                    
                    {ESLVal l2 = $629;
                    
                    {ESLVal n2 = $628;
                    
                    {ESLVal args2 = $627;
                    
                    return $false;
                  }
                  }
                  }
                  }
                  }
                case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                    
                    {ESLVal _v831 = _v215;
                    
                    {ESLVal f = $626;
                    
                    return typeEqual(_v831,f.apply());
                  }
                  }
                  }
                case "RecType": {ESLVal $625 = _v216.termRef(0);
                    ESLVal $624 = _v216.termRef(1);
                    ESLVal $623 = _v216.termRef(2);
                    
                    {ESLVal _v829 = _v215;
                    
                    {ESLVal l2 = $625;
                    
                    {ESLVal n2 = $624;
                    
                    {ESLVal _v830 = $623;
                    
                    return typeEqual(_v829,substType(new ESLVal("RecType",l2,n2,_v830),n2,_v830));
                  }
                  }
                  }
                  }
                  }
                case "ForallType": {ESLVal $622 = _v216.termRef(0);
                    ESLVal $621 = _v216.termRef(1);
                    ESLVal $620 = _v216.termRef(2);
                    
                    {ESLVal _v827 = _v215;
                    
                    {ESLVal l1 = $622;
                    
                    {ESLVal ns2 = $621;
                    
                    {ESLVal _v828 = $620;
                    
                    return typeEqual(_v827,_v828);
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v842 = _v215;
                    
                    {ESLVal _v843 = _v216;
                    
                    return $false;
                  }
                  }
                }
              }
            else if($754.isNil())
              switch(_v216.termName) {
                case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                  ESLVal $646 = _v216.termRef(1);
                  ESLVal $645 = _v216.termRef(2);
                  
                  {ESLVal _v858 = _v215;
                  
                  {ESLVal l = $647;
                  
                  {ESLVal op = $646;
                  
                  {ESLVal args = $645;
                  
                  return typeEqual(_v858,applyTypeFun(l,forceType(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                  ESLVal $643 = _v216.termRef(1);
                  ESLVal $642 = _v216.termRef(2);
                  ESLVal $641 = _v216.termRef(3);
                  
                  {ESLVal _v856 = _v215;
                  
                  {ESLVal l2 = $644;
                  
                  {ESLVal _v857 = $643;
                  
                  {ESLVal ds2 = $642;
                  
                  {ESLVal ms2 = $641;
                  
                  return typeEqual(_v856,flattenAct(l2,_v857,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $640 = _v216.termRef(0);
                  
                  {ESLVal t = _v215;
                  
                  {ESLVal l1 = $640;
                  
                  return $true;
                }
                }
                }
              case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                  ESLVal $636 = _v216.termRef(1);
                  ESLVal $635 = _v216.termRef(2);
                  
                  switch($635.termName) {
                  case "UnionType": {ESLVal $639 = $635.termRef(0);
                    ESLVal $638 = $635.termRef(1);
                    
                    {ESLVal _v853 = _v215;
                    
                    {ESLVal l = $637;
                    
                    {ESLVal state = $636;
                    
                    {ESLVal ul = $639;
                    
                    {ESLVal terms = $638;
                    
                    return typeEqual(_v853,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v854 = _v215;
                    
                    {ESLVal _v855 = _v216;
                    
                    return $false;
                  }
                  }
                }
                }
              case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                  ESLVal $631 = _v216.termRef(1);
                  ESLVal $630 = _v216.termRef(2);
                  
                  switch($630.termName) {
                  case "UnionType": {ESLVal $634 = $630.termRef(0);
                    ESLVal $633 = $630.termRef(1);
                    
                    {ESLVal _v850 = _v215;
                    
                    {ESLVal l = $632;
                    
                    {ESLVal state = $631;
                    
                    {ESLVal ul = $634;
                    
                    {ESLVal terms = $633;
                    
                    return typeEqual(_v850,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v851 = _v215;
                    
                    {ESLVal _v852 = _v216;
                    
                    return $false;
                  }
                  }
                }
                }
              case "TermType": {ESLVal $629 = _v216.termRef(0);
                  ESLVal $628 = _v216.termRef(1);
                  ESLVal $627 = _v216.termRef(2);
                  
                  {ESLVal _v849 = _v215;
                  
                  {ESLVal l2 = $629;
                  
                  {ESLVal n2 = $628;
                  
                  {ESLVal args2 = $627;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                  
                  {ESLVal _v848 = _v215;
                  
                  {ESLVal f = $626;
                  
                  return typeEqual(_v848,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $625 = _v216.termRef(0);
                  ESLVal $624 = _v216.termRef(1);
                  ESLVal $623 = _v216.termRef(2);
                  
                  {ESLVal _v846 = _v215;
                  
                  {ESLVal l2 = $625;
                  
                  {ESLVal n2 = $624;
                  
                  {ESLVal _v847 = $623;
                  
                  return typeEqual(_v846,substType(new ESLVal("RecType",l2,n2,_v847),n2,_v847));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $622 = _v216.termRef(0);
                  ESLVal $621 = _v216.termRef(1);
                  ESLVal $620 = _v216.termRef(2);
                  
                  {ESLVal _v844 = _v215;
                  
                  {ESLVal l1 = $622;
                  
                  {ESLVal ns2 = $621;
                  
                  {ESLVal _v845 = $620;
                  
                  return typeEqual(_v844,_v845);
                }
                }
                }
                }
                }
                default: {ESLVal _v859 = _v215;
                  
                  {ESLVal _v860 = _v216;
                  
                  return $false;
                }
                }
              }
            else switch(_v216.termName) {
                case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                  ESLVal $646 = _v216.termRef(1);
                  ESLVal $645 = _v216.termRef(2);
                  
                  {ESLVal _v875 = _v215;
                  
                  {ESLVal l = $647;
                  
                  {ESLVal op = $646;
                  
                  {ESLVal args = $645;
                  
                  return typeEqual(_v875,applyTypeFun(l,forceType(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                  ESLVal $643 = _v216.termRef(1);
                  ESLVal $642 = _v216.termRef(2);
                  ESLVal $641 = _v216.termRef(3);
                  
                  {ESLVal _v873 = _v215;
                  
                  {ESLVal l2 = $644;
                  
                  {ESLVal _v874 = $643;
                  
                  {ESLVal ds2 = $642;
                  
                  {ESLVal ms2 = $641;
                  
                  return typeEqual(_v873,flattenAct(l2,_v874,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $640 = _v216.termRef(0);
                  
                  {ESLVal t = _v215;
                  
                  {ESLVal l1 = $640;
                  
                  return $true;
                }
                }
                }
              case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                  ESLVal $636 = _v216.termRef(1);
                  ESLVal $635 = _v216.termRef(2);
                  
                  switch($635.termName) {
                  case "UnionType": {ESLVal $639 = $635.termRef(0);
                    ESLVal $638 = $635.termRef(1);
                    
                    {ESLVal _v870 = _v215;
                    
                    {ESLVal l = $637;
                    
                    {ESLVal state = $636;
                    
                    {ESLVal ul = $639;
                    
                    {ESLVal terms = $638;
                    
                    return typeEqual(_v870,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v871 = _v215;
                    
                    {ESLVal _v872 = _v216;
                    
                    return $false;
                  }
                  }
                }
                }
              case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                  ESLVal $631 = _v216.termRef(1);
                  ESLVal $630 = _v216.termRef(2);
                  
                  switch($630.termName) {
                  case "UnionType": {ESLVal $634 = $630.termRef(0);
                    ESLVal $633 = $630.termRef(1);
                    
                    {ESLVal _v867 = _v215;
                    
                    {ESLVal l = $632;
                    
                    {ESLVal state = $631;
                    
                    {ESLVal ul = $634;
                    
                    {ESLVal terms = $633;
                    
                    return typeEqual(_v867,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v868 = _v215;
                    
                    {ESLVal _v869 = _v216;
                    
                    return $false;
                  }
                  }
                }
                }
              case "TermType": {ESLVal $629 = _v216.termRef(0);
                  ESLVal $628 = _v216.termRef(1);
                  ESLVal $627 = _v216.termRef(2);
                  
                  {ESLVal _v866 = _v215;
                  
                  {ESLVal l2 = $629;
                  
                  {ESLVal n2 = $628;
                  
                  {ESLVal args2 = $627;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                  
                  {ESLVal _v865 = _v215;
                  
                  {ESLVal f = $626;
                  
                  return typeEqual(_v865,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $625 = _v216.termRef(0);
                  ESLVal $624 = _v216.termRef(1);
                  ESLVal $623 = _v216.termRef(2);
                  
                  {ESLVal _v863 = _v215;
                  
                  {ESLVal l2 = $625;
                  
                  {ESLVal n2 = $624;
                  
                  {ESLVal _v864 = $623;
                  
                  return typeEqual(_v863,substType(new ESLVal("RecType",l2,n2,_v864),n2,_v864));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $622 = _v216.termRef(0);
                  ESLVal $621 = _v216.termRef(1);
                  ESLVal $620 = _v216.termRef(2);
                  
                  {ESLVal _v861 = _v215;
                  
                  {ESLVal l1 = $622;
                  
                  {ESLVal ns2 = $621;
                  
                  {ESLVal _v862 = $620;
                  
                  return typeEqual(_v861,_v862);
                }
                }
                }
                }
                }
                default: {ESLVal _v876 = _v215;
                  
                  {ESLVal _v877 = _v216;
                  
                  return $false;
                }
                }
              }
            }
            default: switch(_v216.termName) {
              case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                ESLVal $646 = _v216.termRef(1);
                ESLVal $645 = _v216.termRef(2);
                
                {ESLVal _v894 = _v215;
                
                {ESLVal l = $647;
                
                {ESLVal op = $646;
                
                {ESLVal args = $645;
                
                return typeEqual(_v894,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                ESLVal $643 = _v216.termRef(1);
                ESLVal $642 = _v216.termRef(2);
                ESLVal $641 = _v216.termRef(3);
                
                {ESLVal _v892 = _v215;
                
                {ESLVal l2 = $644;
                
                {ESLVal _v893 = $643;
                
                {ESLVal ds2 = $642;
                
                {ESLVal ms2 = $641;
                
                return typeEqual(_v892,flattenAct(l2,_v893,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $640 = _v216.termRef(0);
                
                {ESLVal t = _v215;
                
                {ESLVal l1 = $640;
                
                return $true;
              }
              }
              }
            case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                ESLVal $636 = _v216.termRef(1);
                ESLVal $635 = _v216.termRef(2);
                
                switch($635.termName) {
                case "UnionType": {ESLVal $639 = $635.termRef(0);
                  ESLVal $638 = $635.termRef(1);
                  
                  {ESLVal _v889 = _v215;
                  
                  {ESLVal l = $637;
                  
                  {ESLVal state = $636;
                  
                  {ESLVal ul = $639;
                  
                  {ESLVal terms = $638;
                  
                  return typeEqual(_v889,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v890 = _v215;
                  
                  {ESLVal _v891 = _v216;
                  
                  return $false;
                }
                }
              }
              }
            case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                ESLVal $631 = _v216.termRef(1);
                ESLVal $630 = _v216.termRef(2);
                
                switch($630.termName) {
                case "UnionType": {ESLVal $634 = $630.termRef(0);
                  ESLVal $633 = $630.termRef(1);
                  
                  {ESLVal _v886 = _v215;
                  
                  {ESLVal l = $632;
                  
                  {ESLVal state = $631;
                  
                  {ESLVal ul = $634;
                  
                  {ESLVal terms = $633;
                  
                  return typeEqual(_v886,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v887 = _v215;
                  
                  {ESLVal _v888 = _v216;
                  
                  return $false;
                }
                }
              }
              }
            case "TermType": {ESLVal $629 = _v216.termRef(0);
                ESLVal $628 = _v216.termRef(1);
                ESLVal $627 = _v216.termRef(2);
                
                {ESLVal _v885 = _v215;
                
                {ESLVal l2 = $629;
                
                {ESLVal n2 = $628;
                
                {ESLVal args2 = $627;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                
                {ESLVal _v884 = _v215;
                
                {ESLVal f = $626;
                
                return typeEqual(_v884,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $625 = _v216.termRef(0);
                ESLVal $624 = _v216.termRef(1);
                ESLVal $623 = _v216.termRef(2);
                
                {ESLVal _v882 = _v215;
                
                {ESLVal l2 = $625;
                
                {ESLVal n2 = $624;
                
                {ESLVal _v883 = $623;
                
                return typeEqual(_v882,substType(new ESLVal("RecType",l2,n2,_v883),n2,_v883));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $622 = _v216.termRef(0);
                ESLVal $621 = _v216.termRef(1);
                ESLVal $620 = _v216.termRef(2);
                
                {ESLVal _v880 = _v215;
                
                {ESLVal l1 = $622;
                
                {ESLVal ns2 = $621;
                
                {ESLVal _v881 = $620;
                
                return typeEqual(_v880,_v881);
              }
              }
              }
              }
              }
              default: {ESLVal _v895 = _v215;
                
                {ESLVal _v896 = _v216;
                
                return $false;
              }
              }
            }
          }
          }
        case "BagType": {ESLVal $748 = _v215.termRef(0);
            ESLVal $747 = _v215.termRef(1);
            
            switch(_v216.termName) {
            case "BagType": {ESLVal $750 = _v216.termRef(0);
              ESLVal $749 = _v216.termRef(1);
              
              {ESLVal l1 = $748;
              
              {ESLVal _v734 = $747;
              
              {ESLVal l2 = $750;
              
              {ESLVal _v735 = $749;
              
              return typeEqual(_v734,_v735);
            }
            }
            }
            }
            }
            default: switch(_v216.termName) {
              case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                ESLVal $646 = _v216.termRef(1);
                ESLVal $645 = _v216.termRef(2);
                
                {ESLVal _v750 = _v215;
                
                {ESLVal l = $647;
                
                {ESLVal op = $646;
                
                {ESLVal args = $645;
                
                return typeEqual(_v750,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                ESLVal $643 = _v216.termRef(1);
                ESLVal $642 = _v216.termRef(2);
                ESLVal $641 = _v216.termRef(3);
                
                {ESLVal _v748 = _v215;
                
                {ESLVal l2 = $644;
                
                {ESLVal _v749 = $643;
                
                {ESLVal ds2 = $642;
                
                {ESLVal ms2 = $641;
                
                return typeEqual(_v748,flattenAct(l2,_v749,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $640 = _v216.termRef(0);
                
                {ESLVal t = _v215;
                
                {ESLVal l1 = $640;
                
                return $true;
              }
              }
              }
            case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                ESLVal $636 = _v216.termRef(1);
                ESLVal $635 = _v216.termRef(2);
                
                switch($635.termName) {
                case "UnionType": {ESLVal $639 = $635.termRef(0);
                  ESLVal $638 = $635.termRef(1);
                  
                  {ESLVal _v745 = _v215;
                  
                  {ESLVal l = $637;
                  
                  {ESLVal state = $636;
                  
                  {ESLVal ul = $639;
                  
                  {ESLVal terms = $638;
                  
                  return typeEqual(_v745,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v746 = _v215;
                  
                  {ESLVal _v747 = _v216;
                  
                  return $false;
                }
                }
              }
              }
            case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                ESLVal $631 = _v216.termRef(1);
                ESLVal $630 = _v216.termRef(2);
                
                switch($630.termName) {
                case "UnionType": {ESLVal $634 = $630.termRef(0);
                  ESLVal $633 = $630.termRef(1);
                  
                  {ESLVal _v742 = _v215;
                  
                  {ESLVal l = $632;
                  
                  {ESLVal state = $631;
                  
                  {ESLVal ul = $634;
                  
                  {ESLVal terms = $633;
                  
                  return typeEqual(_v742,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v743 = _v215;
                  
                  {ESLVal _v744 = _v216;
                  
                  return $false;
                }
                }
              }
              }
            case "TermType": {ESLVal $629 = _v216.termRef(0);
                ESLVal $628 = _v216.termRef(1);
                ESLVal $627 = _v216.termRef(2);
                
                {ESLVal _v741 = _v215;
                
                {ESLVal l2 = $629;
                
                {ESLVal n2 = $628;
                
                {ESLVal args2 = $627;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                
                {ESLVal _v740 = _v215;
                
                {ESLVal f = $626;
                
                return typeEqual(_v740,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $625 = _v216.termRef(0);
                ESLVal $624 = _v216.termRef(1);
                ESLVal $623 = _v216.termRef(2);
                
                {ESLVal _v738 = _v215;
                
                {ESLVal l2 = $625;
                
                {ESLVal n2 = $624;
                
                {ESLVal _v739 = $623;
                
                return typeEqual(_v738,substType(new ESLVal("RecType",l2,n2,_v739),n2,_v739));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $622 = _v216.termRef(0);
                ESLVal $621 = _v216.termRef(1);
                ESLVal $620 = _v216.termRef(2);
                
                {ESLVal _v736 = _v215;
                
                {ESLVal l1 = $622;
                
                {ESLVal ns2 = $621;
                
                {ESLVal _v737 = $620;
                
                return typeEqual(_v736,_v737);
              }
              }
              }
              }
              }
              default: {ESLVal _v751 = _v215;
                
                {ESLVal _v752 = _v216;
                
                return $false;
              }
              }
            }
          }
          }
        case "SetType": {ESLVal $733 = _v215.termRef(0);
            ESLVal $732 = _v215.termRef(1);
            
            switch(_v216.termName) {
            case "SetType": {ESLVal $746 = _v216.termRef(0);
              ESLVal $745 = _v216.termRef(1);
              
              {ESLVal l1 = $733;
              
              {ESLVal _v715 = $732;
              
              {ESLVal l2 = $746;
              
              {ESLVal _v716 = $745;
              
              return typeEqual(_v715,_v716);
            }
            }
            }
            }
            }
          case "ForallType": {ESLVal $736 = _v216.termRef(0);
              ESLVal $735 = _v216.termRef(1);
              ESLVal $734 = _v216.termRef(2);
              
              if($735.isCons())
              {ESLVal $737 = $735.head();
                ESLVal $738 = $735.tail();
                
                if($738.isCons())
                {ESLVal $739 = $738.head();
                  ESLVal $740 = $738.tail();
                  
                  switch(_v216.termName) {
                  case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                    ESLVal $646 = _v216.termRef(1);
                    ESLVal $645 = _v216.termRef(2);
                    
                    {ESLVal _v604 = _v215;
                    
                    {ESLVal l = $647;
                    
                    {ESLVal op = $646;
                    
                    {ESLVal args = $645;
                    
                    return typeEqual(_v604,applyTypeFun(l,forceType(op),args));
                  }
                  }
                  }
                  }
                  }
                case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                    ESLVal $643 = _v216.termRef(1);
                    ESLVal $642 = _v216.termRef(2);
                    ESLVal $641 = _v216.termRef(3);
                    
                    {ESLVal _v602 = _v215;
                    
                    {ESLVal l2 = $644;
                    
                    {ESLVal _v603 = $643;
                    
                    {ESLVal ds2 = $642;
                    
                    {ESLVal ms2 = $641;
                    
                    return typeEqual(_v602,flattenAct(l2,_v603,ds2,ms2));
                  }
                  }
                  }
                  }
                  }
                  }
                case "VoidType": {ESLVal $640 = _v216.termRef(0);
                    
                    {ESLVal t = _v215;
                    
                    {ESLVal l1 = $640;
                    
                    return $true;
                  }
                  }
                  }
                case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                    ESLVal $636 = _v216.termRef(1);
                    ESLVal $635 = _v216.termRef(2);
                    
                    switch($635.termName) {
                    case "UnionType": {ESLVal $639 = $635.termRef(0);
                      ESLVal $638 = $635.termRef(1);
                      
                      {ESLVal _v599 = _v215;
                      
                      {ESLVal l = $637;
                      
                      {ESLVal state = $636;
                      
                      {ESLVal ul = $639;
                      
                      {ESLVal terms = $638;
                      
                      return typeEqual(_v599,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                    }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal _v600 = _v215;
                      
                      {ESLVal _v601 = _v216;
                      
                      return $false;
                    }
                    }
                  }
                  }
                case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                    ESLVal $631 = _v216.termRef(1);
                    ESLVal $630 = _v216.termRef(2);
                    
                    switch($630.termName) {
                    case "UnionType": {ESLVal $634 = $630.termRef(0);
                      ESLVal $633 = $630.termRef(1);
                      
                      {ESLVal _v596 = _v215;
                      
                      {ESLVal l = $632;
                      
                      {ESLVal state = $631;
                      
                      {ESLVal ul = $634;
                      
                      {ESLVal terms = $633;
                      
                      return typeEqual(_v596,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                    }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal _v597 = _v215;
                      
                      {ESLVal _v598 = _v216;
                      
                      return $false;
                    }
                    }
                  }
                  }
                case "TermType": {ESLVal $629 = _v216.termRef(0);
                    ESLVal $628 = _v216.termRef(1);
                    ESLVal $627 = _v216.termRef(2);
                    
                    {ESLVal _v595 = _v215;
                    
                    {ESLVal l2 = $629;
                    
                    {ESLVal n2 = $628;
                    
                    {ESLVal args2 = $627;
                    
                    return $false;
                  }
                  }
                  }
                  }
                  }
                case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                    
                    {ESLVal _v594 = _v215;
                    
                    {ESLVal f = $626;
                    
                    return typeEqual(_v594,f.apply());
                  }
                  }
                  }
                case "RecType": {ESLVal $625 = _v216.termRef(0);
                    ESLVal $624 = _v216.termRef(1);
                    ESLVal $623 = _v216.termRef(2);
                    
                    {ESLVal _v592 = _v215;
                    
                    {ESLVal l2 = $625;
                    
                    {ESLVal n2 = $624;
                    
                    {ESLVal _v593 = $623;
                    
                    return typeEqual(_v592,substType(new ESLVal("RecType",l2,n2,_v593),n2,_v593));
                  }
                  }
                  }
                  }
                  }
                case "ForallType": {ESLVal $622 = _v216.termRef(0);
                    ESLVal $621 = _v216.termRef(1);
                    ESLVal $620 = _v216.termRef(2);
                    
                    {ESLVal _v590 = _v215;
                    
                    {ESLVal l1 = $622;
                    
                    {ESLVal ns2 = $621;
                    
                    {ESLVal _v591 = $620;
                    
                    return typeEqual(_v590,_v591);
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v605 = _v215;
                    
                    {ESLVal _v606 = _v216;
                    
                    return $false;
                  }
                  }
                }
                }
              else if($738.isNil())
                switch($734.termName) {
                  case "SetType": {ESLVal $742 = $734.termRef(0);
                    ESLVal $741 = $734.termRef(1);
                    
                    switch($741.termName) {
                    case "VarType": {ESLVal $744 = $741.termRef(0);
                      ESLVal $743 = $741.termRef(1);
                      
                      {ESLVal l1 = $733;
                      
                      {ESLVal _v607 = $732;
                      
                      {ESLVal l2 = $736;
                      
                      {ESLVal v1 = $737;
                      
                      {ESLVal l3 = $742;
                      
                      {ESLVal l4 = $744;
                      
                      {ESLVal v2 = $743;
                      
                      if(v1.eql(v2).boolVal)
                      return $true;
                      else
                        switch(_v216.termName) {
                          case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                            ESLVal $646 = _v216.termRef(1);
                            ESLVal $645 = _v216.termRef(2);
                            
                            {ESLVal _v627 = _v215;
                            
                            {ESLVal l = $647;
                            
                            {ESLVal op = $646;
                            
                            {ESLVal args = $645;
                            
                            return typeEqual(_v627,applyTypeFun(l,forceType(op),args));
                          }
                          }
                          }
                          }
                          }
                        case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                            ESLVal $643 = _v216.termRef(1);
                            ESLVal $642 = _v216.termRef(2);
                            ESLVal $641 = _v216.termRef(3);
                            
                            {ESLVal _v624 = _v215;
                            
                            {ESLVal _v625 = $644;
                            
                            {ESLVal _v626 = $643;
                            
                            {ESLVal ds2 = $642;
                            
                            {ESLVal ms2 = $641;
                            
                            return typeEqual(_v624,flattenAct(_v625,_v626,ds2,ms2));
                          }
                          }
                          }
                          }
                          }
                          }
                        case "VoidType": {ESLVal $640 = _v216.termRef(0);
                            
                            {ESLVal t = _v215;
                            
                            {ESLVal _v623 = $640;
                            
                            return $true;
                          }
                          }
                          }
                        case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                            ESLVal $636 = _v216.termRef(1);
                            ESLVal $635 = _v216.termRef(2);
                            
                            switch($635.termName) {
                            case "UnionType": {ESLVal $639 = $635.termRef(0);
                              ESLVal $638 = $635.termRef(1);
                              
                              {ESLVal _v620 = _v215;
                              
                              {ESLVal l = $637;
                              
                              {ESLVal state = $636;
                              
                              {ESLVal ul = $639;
                              
                              {ESLVal terms = $638;
                              
                              return typeEqual(_v620,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                            }
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v621 = _v215;
                              
                              {ESLVal _v622 = _v216;
                              
                              return $false;
                            }
                            }
                          }
                          }
                        case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                            ESLVal $631 = _v216.termRef(1);
                            ESLVal $630 = _v216.termRef(2);
                            
                            switch($630.termName) {
                            case "UnionType": {ESLVal $634 = $630.termRef(0);
                              ESLVal $633 = $630.termRef(1);
                              
                              {ESLVal _v617 = _v215;
                              
                              {ESLVal l = $632;
                              
                              {ESLVal state = $631;
                              
                              {ESLVal ul = $634;
                              
                              {ESLVal terms = $633;
                              
                              return typeEqual(_v617,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                            }
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v618 = _v215;
                              
                              {ESLVal _v619 = _v216;
                              
                              return $false;
                            }
                            }
                          }
                          }
                        case "TermType": {ESLVal $629 = _v216.termRef(0);
                            ESLVal $628 = _v216.termRef(1);
                            ESLVal $627 = _v216.termRef(2);
                            
                            {ESLVal _v615 = _v215;
                            
                            {ESLVal _v616 = $629;
                            
                            {ESLVal n2 = $628;
                            
                            {ESLVal args2 = $627;
                            
                            return $false;
                          }
                          }
                          }
                          }
                          }
                        case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                            
                            {ESLVal _v614 = _v215;
                            
                            {ESLVal f = $626;
                            
                            return typeEqual(_v614,f.apply());
                          }
                          }
                          }
                        case "RecType": {ESLVal $625 = _v216.termRef(0);
                            ESLVal $624 = _v216.termRef(1);
                            ESLVal $623 = _v216.termRef(2);
                            
                            {ESLVal _v611 = _v215;
                            
                            {ESLVal _v612 = $625;
                            
                            {ESLVal n2 = $624;
                            
                            {ESLVal _v613 = $623;
                            
                            return typeEqual(_v611,substType(new ESLVal("RecType",_v612,n2,_v613),n2,_v613));
                          }
                          }
                          }
                          }
                          }
                        case "ForallType": {ESLVal $622 = _v216.termRef(0);
                            ESLVal $621 = _v216.termRef(1);
                            ESLVal $620 = _v216.termRef(2);
                            
                            {ESLVal _v608 = _v215;
                            
                            {ESLVal _v609 = $622;
                            
                            {ESLVal ns2 = $621;
                            
                            {ESLVal _v610 = $620;
                            
                            return typeEqual(_v608,_v610);
                          }
                          }
                          }
                          }
                          }
                          default: {ESLVal _v628 = _v215;
                            
                            {ESLVal _v629 = _v216;
                            
                            return $false;
                          }
                          }
                        }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: switch(_v216.termName) {
                      case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                        ESLVal $646 = _v216.termRef(1);
                        ESLVal $645 = _v216.termRef(2);
                        
                        {ESLVal _v644 = _v215;
                        
                        {ESLVal l = $647;
                        
                        {ESLVal op = $646;
                        
                        {ESLVal args = $645;
                        
                        return typeEqual(_v644,applyTypeFun(l,forceType(op),args));
                      }
                      }
                      }
                      }
                      }
                    case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                        ESLVal $643 = _v216.termRef(1);
                        ESLVal $642 = _v216.termRef(2);
                        ESLVal $641 = _v216.termRef(3);
                        
                        {ESLVal _v642 = _v215;
                        
                        {ESLVal l2 = $644;
                        
                        {ESLVal _v643 = $643;
                        
                        {ESLVal ds2 = $642;
                        
                        {ESLVal ms2 = $641;
                        
                        return typeEqual(_v642,flattenAct(l2,_v643,ds2,ms2));
                      }
                      }
                      }
                      }
                      }
                      }
                    case "VoidType": {ESLVal $640 = _v216.termRef(0);
                        
                        {ESLVal t = _v215;
                        
                        {ESLVal l1 = $640;
                        
                        return $true;
                      }
                      }
                      }
                    case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                        ESLVal $636 = _v216.termRef(1);
                        ESLVal $635 = _v216.termRef(2);
                        
                        switch($635.termName) {
                        case "UnionType": {ESLVal $639 = $635.termRef(0);
                          ESLVal $638 = $635.termRef(1);
                          
                          {ESLVal _v639 = _v215;
                          
                          {ESLVal l = $637;
                          
                          {ESLVal state = $636;
                          
                          {ESLVal ul = $639;
                          
                          {ESLVal terms = $638;
                          
                          return typeEqual(_v639,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                        }
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal _v640 = _v215;
                          
                          {ESLVal _v641 = _v216;
                          
                          return $false;
                        }
                        }
                      }
                      }
                    case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                        ESLVal $631 = _v216.termRef(1);
                        ESLVal $630 = _v216.termRef(2);
                        
                        switch($630.termName) {
                        case "UnionType": {ESLVal $634 = $630.termRef(0);
                          ESLVal $633 = $630.termRef(1);
                          
                          {ESLVal _v636 = _v215;
                          
                          {ESLVal l = $632;
                          
                          {ESLVal state = $631;
                          
                          {ESLVal ul = $634;
                          
                          {ESLVal terms = $633;
                          
                          return typeEqual(_v636,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                        }
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal _v637 = _v215;
                          
                          {ESLVal _v638 = _v216;
                          
                          return $false;
                        }
                        }
                      }
                      }
                    case "TermType": {ESLVal $629 = _v216.termRef(0);
                        ESLVal $628 = _v216.termRef(1);
                        ESLVal $627 = _v216.termRef(2);
                        
                        {ESLVal _v635 = _v215;
                        
                        {ESLVal l2 = $629;
                        
                        {ESLVal n2 = $628;
                        
                        {ESLVal args2 = $627;
                        
                        return $false;
                      }
                      }
                      }
                      }
                      }
                    case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                        
                        {ESLVal _v634 = _v215;
                        
                        {ESLVal f = $626;
                        
                        return typeEqual(_v634,f.apply());
                      }
                      }
                      }
                    case "RecType": {ESLVal $625 = _v216.termRef(0);
                        ESLVal $624 = _v216.termRef(1);
                        ESLVal $623 = _v216.termRef(2);
                        
                        {ESLVal _v632 = _v215;
                        
                        {ESLVal l2 = $625;
                        
                        {ESLVal n2 = $624;
                        
                        {ESLVal _v633 = $623;
                        
                        return typeEqual(_v632,substType(new ESLVal("RecType",l2,n2,_v633),n2,_v633));
                      }
                      }
                      }
                      }
                      }
                    case "ForallType": {ESLVal $622 = _v216.termRef(0);
                        ESLVal $621 = _v216.termRef(1);
                        ESLVal $620 = _v216.termRef(2);
                        
                        {ESLVal _v630 = _v215;
                        
                        {ESLVal l1 = $622;
                        
                        {ESLVal ns2 = $621;
                        
                        {ESLVal _v631 = $620;
                        
                        return typeEqual(_v630,_v631);
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal _v645 = _v215;
                        
                        {ESLVal _v646 = _v216;
                        
                        return $false;
                      }
                      }
                    }
                  }
                  }
                  default: switch(_v216.termName) {
                    case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                      ESLVal $646 = _v216.termRef(1);
                      ESLVal $645 = _v216.termRef(2);
                      
                      {ESLVal _v661 = _v215;
                      
                      {ESLVal l = $647;
                      
                      {ESLVal op = $646;
                      
                      {ESLVal args = $645;
                      
                      return typeEqual(_v661,applyTypeFun(l,forceType(op),args));
                    }
                    }
                    }
                    }
                    }
                  case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                      ESLVal $643 = _v216.termRef(1);
                      ESLVal $642 = _v216.termRef(2);
                      ESLVal $641 = _v216.termRef(3);
                      
                      {ESLVal _v659 = _v215;
                      
                      {ESLVal l2 = $644;
                      
                      {ESLVal _v660 = $643;
                      
                      {ESLVal ds2 = $642;
                      
                      {ESLVal ms2 = $641;
                      
                      return typeEqual(_v659,flattenAct(l2,_v660,ds2,ms2));
                    }
                    }
                    }
                    }
                    }
                    }
                  case "VoidType": {ESLVal $640 = _v216.termRef(0);
                      
                      {ESLVal t = _v215;
                      
                      {ESLVal l1 = $640;
                      
                      return $true;
                    }
                    }
                    }
                  case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                      ESLVal $636 = _v216.termRef(1);
                      ESLVal $635 = _v216.termRef(2);
                      
                      switch($635.termName) {
                      case "UnionType": {ESLVal $639 = $635.termRef(0);
                        ESLVal $638 = $635.termRef(1);
                        
                        {ESLVal _v656 = _v215;
                        
                        {ESLVal l = $637;
                        
                        {ESLVal state = $636;
                        
                        {ESLVal ul = $639;
                        
                        {ESLVal terms = $638;
                        
                        return typeEqual(_v656,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                      }
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal _v657 = _v215;
                        
                        {ESLVal _v658 = _v216;
                        
                        return $false;
                      }
                      }
                    }
                    }
                  case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                      ESLVal $631 = _v216.termRef(1);
                      ESLVal $630 = _v216.termRef(2);
                      
                      switch($630.termName) {
                      case "UnionType": {ESLVal $634 = $630.termRef(0);
                        ESLVal $633 = $630.termRef(1);
                        
                        {ESLVal _v653 = _v215;
                        
                        {ESLVal l = $632;
                        
                        {ESLVal state = $631;
                        
                        {ESLVal ul = $634;
                        
                        {ESLVal terms = $633;
                        
                        return typeEqual(_v653,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                      }
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal _v654 = _v215;
                        
                        {ESLVal _v655 = _v216;
                        
                        return $false;
                      }
                      }
                    }
                    }
                  case "TermType": {ESLVal $629 = _v216.termRef(0);
                      ESLVal $628 = _v216.termRef(1);
                      ESLVal $627 = _v216.termRef(2);
                      
                      {ESLVal _v652 = _v215;
                      
                      {ESLVal l2 = $629;
                      
                      {ESLVal n2 = $628;
                      
                      {ESLVal args2 = $627;
                      
                      return $false;
                    }
                    }
                    }
                    }
                    }
                  case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                      
                      {ESLVal _v651 = _v215;
                      
                      {ESLVal f = $626;
                      
                      return typeEqual(_v651,f.apply());
                    }
                    }
                    }
                  case "RecType": {ESLVal $625 = _v216.termRef(0);
                      ESLVal $624 = _v216.termRef(1);
                      ESLVal $623 = _v216.termRef(2);
                      
                      {ESLVal _v649 = _v215;
                      
                      {ESLVal l2 = $625;
                      
                      {ESLVal n2 = $624;
                      
                      {ESLVal _v650 = $623;
                      
                      return typeEqual(_v649,substType(new ESLVal("RecType",l2,n2,_v650),n2,_v650));
                    }
                    }
                    }
                    }
                    }
                  case "ForallType": {ESLVal $622 = _v216.termRef(0);
                      ESLVal $621 = _v216.termRef(1);
                      ESLVal $620 = _v216.termRef(2);
                      
                      {ESLVal _v647 = _v215;
                      
                      {ESLVal l1 = $622;
                      
                      {ESLVal ns2 = $621;
                      
                      {ESLVal _v648 = $620;
                      
                      return typeEqual(_v647,_v648);
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal _v662 = _v215;
                      
                      {ESLVal _v663 = _v216;
                      
                      return $false;
                    }
                    }
                  }
                }
              else switch(_v216.termName) {
                  case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                    ESLVal $646 = _v216.termRef(1);
                    ESLVal $645 = _v216.termRef(2);
                    
                    {ESLVal _v678 = _v215;
                    
                    {ESLVal l = $647;
                    
                    {ESLVal op = $646;
                    
                    {ESLVal args = $645;
                    
                    return typeEqual(_v678,applyTypeFun(l,forceType(op),args));
                  }
                  }
                  }
                  }
                  }
                case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                    ESLVal $643 = _v216.termRef(1);
                    ESLVal $642 = _v216.termRef(2);
                    ESLVal $641 = _v216.termRef(3);
                    
                    {ESLVal _v676 = _v215;
                    
                    {ESLVal l2 = $644;
                    
                    {ESLVal _v677 = $643;
                    
                    {ESLVal ds2 = $642;
                    
                    {ESLVal ms2 = $641;
                    
                    return typeEqual(_v676,flattenAct(l2,_v677,ds2,ms2));
                  }
                  }
                  }
                  }
                  }
                  }
                case "VoidType": {ESLVal $640 = _v216.termRef(0);
                    
                    {ESLVal t = _v215;
                    
                    {ESLVal l1 = $640;
                    
                    return $true;
                  }
                  }
                  }
                case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                    ESLVal $636 = _v216.termRef(1);
                    ESLVal $635 = _v216.termRef(2);
                    
                    switch($635.termName) {
                    case "UnionType": {ESLVal $639 = $635.termRef(0);
                      ESLVal $638 = $635.termRef(1);
                      
                      {ESLVal _v673 = _v215;
                      
                      {ESLVal l = $637;
                      
                      {ESLVal state = $636;
                      
                      {ESLVal ul = $639;
                      
                      {ESLVal terms = $638;
                      
                      return typeEqual(_v673,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                    }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal _v674 = _v215;
                      
                      {ESLVal _v675 = _v216;
                      
                      return $false;
                    }
                    }
                  }
                  }
                case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                    ESLVal $631 = _v216.termRef(1);
                    ESLVal $630 = _v216.termRef(2);
                    
                    switch($630.termName) {
                    case "UnionType": {ESLVal $634 = $630.termRef(0);
                      ESLVal $633 = $630.termRef(1);
                      
                      {ESLVal _v670 = _v215;
                      
                      {ESLVal l = $632;
                      
                      {ESLVal state = $631;
                      
                      {ESLVal ul = $634;
                      
                      {ESLVal terms = $633;
                      
                      return typeEqual(_v670,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                    }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal _v671 = _v215;
                      
                      {ESLVal _v672 = _v216;
                      
                      return $false;
                    }
                    }
                  }
                  }
                case "TermType": {ESLVal $629 = _v216.termRef(0);
                    ESLVal $628 = _v216.termRef(1);
                    ESLVal $627 = _v216.termRef(2);
                    
                    {ESLVal _v669 = _v215;
                    
                    {ESLVal l2 = $629;
                    
                    {ESLVal n2 = $628;
                    
                    {ESLVal args2 = $627;
                    
                    return $false;
                  }
                  }
                  }
                  }
                  }
                case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                    
                    {ESLVal _v668 = _v215;
                    
                    {ESLVal f = $626;
                    
                    return typeEqual(_v668,f.apply());
                  }
                  }
                  }
                case "RecType": {ESLVal $625 = _v216.termRef(0);
                    ESLVal $624 = _v216.termRef(1);
                    ESLVal $623 = _v216.termRef(2);
                    
                    {ESLVal _v666 = _v215;
                    
                    {ESLVal l2 = $625;
                    
                    {ESLVal n2 = $624;
                    
                    {ESLVal _v667 = $623;
                    
                    return typeEqual(_v666,substType(new ESLVal("RecType",l2,n2,_v667),n2,_v667));
                  }
                  }
                  }
                  }
                  }
                case "ForallType": {ESLVal $622 = _v216.termRef(0);
                    ESLVal $621 = _v216.termRef(1);
                    ESLVal $620 = _v216.termRef(2);
                    
                    {ESLVal _v664 = _v215;
                    
                    {ESLVal l1 = $622;
                    
                    {ESLVal ns2 = $621;
                    
                    {ESLVal _v665 = $620;
                    
                    return typeEqual(_v664,_v665);
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v679 = _v215;
                    
                    {ESLVal _v680 = _v216;
                    
                    return $false;
                  }
                  }
                }
              }
            else if($735.isNil())
              switch(_v216.termName) {
                case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                  ESLVal $646 = _v216.termRef(1);
                  ESLVal $645 = _v216.termRef(2);
                  
                  {ESLVal _v695 = _v215;
                  
                  {ESLVal l = $647;
                  
                  {ESLVal op = $646;
                  
                  {ESLVal args = $645;
                  
                  return typeEqual(_v695,applyTypeFun(l,forceType(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                  ESLVal $643 = _v216.termRef(1);
                  ESLVal $642 = _v216.termRef(2);
                  ESLVal $641 = _v216.termRef(3);
                  
                  {ESLVal _v693 = _v215;
                  
                  {ESLVal l2 = $644;
                  
                  {ESLVal _v694 = $643;
                  
                  {ESLVal ds2 = $642;
                  
                  {ESLVal ms2 = $641;
                  
                  return typeEqual(_v693,flattenAct(l2,_v694,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $640 = _v216.termRef(0);
                  
                  {ESLVal t = _v215;
                  
                  {ESLVal l1 = $640;
                  
                  return $true;
                }
                }
                }
              case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                  ESLVal $636 = _v216.termRef(1);
                  ESLVal $635 = _v216.termRef(2);
                  
                  switch($635.termName) {
                  case "UnionType": {ESLVal $639 = $635.termRef(0);
                    ESLVal $638 = $635.termRef(1);
                    
                    {ESLVal _v690 = _v215;
                    
                    {ESLVal l = $637;
                    
                    {ESLVal state = $636;
                    
                    {ESLVal ul = $639;
                    
                    {ESLVal terms = $638;
                    
                    return typeEqual(_v690,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v691 = _v215;
                    
                    {ESLVal _v692 = _v216;
                    
                    return $false;
                  }
                  }
                }
                }
              case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                  ESLVal $631 = _v216.termRef(1);
                  ESLVal $630 = _v216.termRef(2);
                  
                  switch($630.termName) {
                  case "UnionType": {ESLVal $634 = $630.termRef(0);
                    ESLVal $633 = $630.termRef(1);
                    
                    {ESLVal _v687 = _v215;
                    
                    {ESLVal l = $632;
                    
                    {ESLVal state = $631;
                    
                    {ESLVal ul = $634;
                    
                    {ESLVal terms = $633;
                    
                    return typeEqual(_v687,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v688 = _v215;
                    
                    {ESLVal _v689 = _v216;
                    
                    return $false;
                  }
                  }
                }
                }
              case "TermType": {ESLVal $629 = _v216.termRef(0);
                  ESLVal $628 = _v216.termRef(1);
                  ESLVal $627 = _v216.termRef(2);
                  
                  {ESLVal _v686 = _v215;
                  
                  {ESLVal l2 = $629;
                  
                  {ESLVal n2 = $628;
                  
                  {ESLVal args2 = $627;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                  
                  {ESLVal _v685 = _v215;
                  
                  {ESLVal f = $626;
                  
                  return typeEqual(_v685,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $625 = _v216.termRef(0);
                  ESLVal $624 = _v216.termRef(1);
                  ESLVal $623 = _v216.termRef(2);
                  
                  {ESLVal _v683 = _v215;
                  
                  {ESLVal l2 = $625;
                  
                  {ESLVal n2 = $624;
                  
                  {ESLVal _v684 = $623;
                  
                  return typeEqual(_v683,substType(new ESLVal("RecType",l2,n2,_v684),n2,_v684));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $622 = _v216.termRef(0);
                  ESLVal $621 = _v216.termRef(1);
                  ESLVal $620 = _v216.termRef(2);
                  
                  {ESLVal _v681 = _v215;
                  
                  {ESLVal l1 = $622;
                  
                  {ESLVal ns2 = $621;
                  
                  {ESLVal _v682 = $620;
                  
                  return typeEqual(_v681,_v682);
                }
                }
                }
                }
                }
                default: {ESLVal _v696 = _v215;
                  
                  {ESLVal _v697 = _v216;
                  
                  return $false;
                }
                }
              }
            else switch(_v216.termName) {
                case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                  ESLVal $646 = _v216.termRef(1);
                  ESLVal $645 = _v216.termRef(2);
                  
                  {ESLVal _v712 = _v215;
                  
                  {ESLVal l = $647;
                  
                  {ESLVal op = $646;
                  
                  {ESLVal args = $645;
                  
                  return typeEqual(_v712,applyTypeFun(l,forceType(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                  ESLVal $643 = _v216.termRef(1);
                  ESLVal $642 = _v216.termRef(2);
                  ESLVal $641 = _v216.termRef(3);
                  
                  {ESLVal _v710 = _v215;
                  
                  {ESLVal l2 = $644;
                  
                  {ESLVal _v711 = $643;
                  
                  {ESLVal ds2 = $642;
                  
                  {ESLVal ms2 = $641;
                  
                  return typeEqual(_v710,flattenAct(l2,_v711,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $640 = _v216.termRef(0);
                  
                  {ESLVal t = _v215;
                  
                  {ESLVal l1 = $640;
                  
                  return $true;
                }
                }
                }
              case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                  ESLVal $636 = _v216.termRef(1);
                  ESLVal $635 = _v216.termRef(2);
                  
                  switch($635.termName) {
                  case "UnionType": {ESLVal $639 = $635.termRef(0);
                    ESLVal $638 = $635.termRef(1);
                    
                    {ESLVal _v707 = _v215;
                    
                    {ESLVal l = $637;
                    
                    {ESLVal state = $636;
                    
                    {ESLVal ul = $639;
                    
                    {ESLVal terms = $638;
                    
                    return typeEqual(_v707,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v708 = _v215;
                    
                    {ESLVal _v709 = _v216;
                    
                    return $false;
                  }
                  }
                }
                }
              case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                  ESLVal $631 = _v216.termRef(1);
                  ESLVal $630 = _v216.termRef(2);
                  
                  switch($630.termName) {
                  case "UnionType": {ESLVal $634 = $630.termRef(0);
                    ESLVal $633 = $630.termRef(1);
                    
                    {ESLVal _v704 = _v215;
                    
                    {ESLVal l = $632;
                    
                    {ESLVal state = $631;
                    
                    {ESLVal ul = $634;
                    
                    {ESLVal terms = $633;
                    
                    return typeEqual(_v704,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v705 = _v215;
                    
                    {ESLVal _v706 = _v216;
                    
                    return $false;
                  }
                  }
                }
                }
              case "TermType": {ESLVal $629 = _v216.termRef(0);
                  ESLVal $628 = _v216.termRef(1);
                  ESLVal $627 = _v216.termRef(2);
                  
                  {ESLVal _v703 = _v215;
                  
                  {ESLVal l2 = $629;
                  
                  {ESLVal n2 = $628;
                  
                  {ESLVal args2 = $627;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                  
                  {ESLVal _v702 = _v215;
                  
                  {ESLVal f = $626;
                  
                  return typeEqual(_v702,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $625 = _v216.termRef(0);
                  ESLVal $624 = _v216.termRef(1);
                  ESLVal $623 = _v216.termRef(2);
                  
                  {ESLVal _v700 = _v215;
                  
                  {ESLVal l2 = $625;
                  
                  {ESLVal n2 = $624;
                  
                  {ESLVal _v701 = $623;
                  
                  return typeEqual(_v700,substType(new ESLVal("RecType",l2,n2,_v701),n2,_v701));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $622 = _v216.termRef(0);
                  ESLVal $621 = _v216.termRef(1);
                  ESLVal $620 = _v216.termRef(2);
                  
                  {ESLVal _v698 = _v215;
                  
                  {ESLVal l1 = $622;
                  
                  {ESLVal ns2 = $621;
                  
                  {ESLVal _v699 = $620;
                  
                  return typeEqual(_v698,_v699);
                }
                }
                }
                }
                }
                default: {ESLVal _v713 = _v215;
                  
                  {ESLVal _v714 = _v216;
                  
                  return $false;
                }
                }
              }
            }
            default: switch(_v216.termName) {
              case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                ESLVal $646 = _v216.termRef(1);
                ESLVal $645 = _v216.termRef(2);
                
                {ESLVal _v731 = _v215;
                
                {ESLVal l = $647;
                
                {ESLVal op = $646;
                
                {ESLVal args = $645;
                
                return typeEqual(_v731,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                ESLVal $643 = _v216.termRef(1);
                ESLVal $642 = _v216.termRef(2);
                ESLVal $641 = _v216.termRef(3);
                
                {ESLVal _v729 = _v215;
                
                {ESLVal l2 = $644;
                
                {ESLVal _v730 = $643;
                
                {ESLVal ds2 = $642;
                
                {ESLVal ms2 = $641;
                
                return typeEqual(_v729,flattenAct(l2,_v730,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $640 = _v216.termRef(0);
                
                {ESLVal t = _v215;
                
                {ESLVal l1 = $640;
                
                return $true;
              }
              }
              }
            case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                ESLVal $636 = _v216.termRef(1);
                ESLVal $635 = _v216.termRef(2);
                
                switch($635.termName) {
                case "UnionType": {ESLVal $639 = $635.termRef(0);
                  ESLVal $638 = $635.termRef(1);
                  
                  {ESLVal _v726 = _v215;
                  
                  {ESLVal l = $637;
                  
                  {ESLVal state = $636;
                  
                  {ESLVal ul = $639;
                  
                  {ESLVal terms = $638;
                  
                  return typeEqual(_v726,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v727 = _v215;
                  
                  {ESLVal _v728 = _v216;
                  
                  return $false;
                }
                }
              }
              }
            case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                ESLVal $631 = _v216.termRef(1);
                ESLVal $630 = _v216.termRef(2);
                
                switch($630.termName) {
                case "UnionType": {ESLVal $634 = $630.termRef(0);
                  ESLVal $633 = $630.termRef(1);
                  
                  {ESLVal _v723 = _v215;
                  
                  {ESLVal l = $632;
                  
                  {ESLVal state = $631;
                  
                  {ESLVal ul = $634;
                  
                  {ESLVal terms = $633;
                  
                  return typeEqual(_v723,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v724 = _v215;
                  
                  {ESLVal _v725 = _v216;
                  
                  return $false;
                }
                }
              }
              }
            case "TermType": {ESLVal $629 = _v216.termRef(0);
                ESLVal $628 = _v216.termRef(1);
                ESLVal $627 = _v216.termRef(2);
                
                {ESLVal _v722 = _v215;
                
                {ESLVal l2 = $629;
                
                {ESLVal n2 = $628;
                
                {ESLVal args2 = $627;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                
                {ESLVal _v721 = _v215;
                
                {ESLVal f = $626;
                
                return typeEqual(_v721,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $625 = _v216.termRef(0);
                ESLVal $624 = _v216.termRef(1);
                ESLVal $623 = _v216.termRef(2);
                
                {ESLVal _v719 = _v215;
                
                {ESLVal l2 = $625;
                
                {ESLVal n2 = $624;
                
                {ESLVal _v720 = $623;
                
                return typeEqual(_v719,substType(new ESLVal("RecType",l2,n2,_v720),n2,_v720));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $622 = _v216.termRef(0);
                ESLVal $621 = _v216.termRef(1);
                ESLVal $620 = _v216.termRef(2);
                
                {ESLVal _v717 = _v215;
                
                {ESLVal l1 = $622;
                
                {ESLVal ns2 = $621;
                
                {ESLVal _v718 = $620;
                
                return typeEqual(_v717,_v718);
              }
              }
              }
              }
              }
              default: {ESLVal _v732 = _v215;
                
                {ESLVal _v733 = _v216;
                
                return $false;
              }
              }
            }
          }
          }
        case "StrType": {ESLVal $730 = _v215.termRef(0);
            
            switch(_v216.termName) {
            case "StrType": {ESLVal $731 = _v216.termRef(0);
              
              {ESLVal l1 = $730;
              
              {ESLVal l2 = $731;
              
              return $true;
            }
            }
            }
            default: switch(_v216.termName) {
              case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                ESLVal $646 = _v216.termRef(1);
                ESLVal $645 = _v216.termRef(2);
                
                {ESLVal _v587 = _v215;
                
                {ESLVal l = $647;
                
                {ESLVal op = $646;
                
                {ESLVal args = $645;
                
                return typeEqual(_v587,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                ESLVal $643 = _v216.termRef(1);
                ESLVal $642 = _v216.termRef(2);
                ESLVal $641 = _v216.termRef(3);
                
                {ESLVal _v585 = _v215;
                
                {ESLVal l2 = $644;
                
                {ESLVal _v586 = $643;
                
                {ESLVal ds2 = $642;
                
                {ESLVal ms2 = $641;
                
                return typeEqual(_v585,flattenAct(l2,_v586,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $640 = _v216.termRef(0);
                
                {ESLVal t = _v215;
                
                {ESLVal l1 = $640;
                
                return $true;
              }
              }
              }
            case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                ESLVal $636 = _v216.termRef(1);
                ESLVal $635 = _v216.termRef(2);
                
                switch($635.termName) {
                case "UnionType": {ESLVal $639 = $635.termRef(0);
                  ESLVal $638 = $635.termRef(1);
                  
                  {ESLVal _v582 = _v215;
                  
                  {ESLVal l = $637;
                  
                  {ESLVal state = $636;
                  
                  {ESLVal ul = $639;
                  
                  {ESLVal terms = $638;
                  
                  return typeEqual(_v582,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v583 = _v215;
                  
                  {ESLVal _v584 = _v216;
                  
                  return $false;
                }
                }
              }
              }
            case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                ESLVal $631 = _v216.termRef(1);
                ESLVal $630 = _v216.termRef(2);
                
                switch($630.termName) {
                case "UnionType": {ESLVal $634 = $630.termRef(0);
                  ESLVal $633 = $630.termRef(1);
                  
                  {ESLVal _v579 = _v215;
                  
                  {ESLVal l = $632;
                  
                  {ESLVal state = $631;
                  
                  {ESLVal ul = $634;
                  
                  {ESLVal terms = $633;
                  
                  return typeEqual(_v579,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v580 = _v215;
                  
                  {ESLVal _v581 = _v216;
                  
                  return $false;
                }
                }
              }
              }
            case "TermType": {ESLVal $629 = _v216.termRef(0);
                ESLVal $628 = _v216.termRef(1);
                ESLVal $627 = _v216.termRef(2);
                
                {ESLVal _v578 = _v215;
                
                {ESLVal l2 = $629;
                
                {ESLVal n2 = $628;
                
                {ESLVal args2 = $627;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                
                {ESLVal _v577 = _v215;
                
                {ESLVal f = $626;
                
                return typeEqual(_v577,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $625 = _v216.termRef(0);
                ESLVal $624 = _v216.termRef(1);
                ESLVal $623 = _v216.termRef(2);
                
                {ESLVal _v575 = _v215;
                
                {ESLVal l2 = $625;
                
                {ESLVal n2 = $624;
                
                {ESLVal _v576 = $623;
                
                return typeEqual(_v575,substType(new ESLVal("RecType",l2,n2,_v576),n2,_v576));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $622 = _v216.termRef(0);
                ESLVal $621 = _v216.termRef(1);
                ESLVal $620 = _v216.termRef(2);
                
                {ESLVal _v573 = _v215;
                
                {ESLVal l1 = $622;
                
                {ESLVal ns2 = $621;
                
                {ESLVal _v574 = $620;
                
                return typeEqual(_v573,_v574);
              }
              }
              }
              }
              }
              default: {ESLVal _v588 = _v215;
                
                {ESLVal _v589 = _v216;
                
                return $false;
              }
              }
            }
          }
          }
        case "VoidType": {ESLVal $729 = _v215.termRef(0);
            
            {ESLVal l1 = $729;
            
            {ESLVal t = _v216;
            
            return $true;
          }
          }
          }
        case "FieldType": {ESLVal $725 = _v215.termRef(0);
            ESLVal $724 = _v215.termRef(1);
            ESLVal $723 = _v215.termRef(2);
            
            switch(_v216.termName) {
            case "FieldType": {ESLVal $728 = _v216.termRef(0);
              ESLVal $727 = _v216.termRef(1);
              ESLVal $726 = _v216.termRef(2);
              
              {ESLVal l1 = $725;
              
              {ESLVal n1 = $724;
              
              {ESLVal _v554 = $723;
              
              {ESLVal l2 = $728;
              
              {ESLVal n2 = $727;
              
              {ESLVal _v555 = $726;
              
              return n1.eql(n2).and(typeEqual(_v554,_v555));
            }
            }
            }
            }
            }
            }
            }
            default: switch(_v216.termName) {
              case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                ESLVal $646 = _v216.termRef(1);
                ESLVal $645 = _v216.termRef(2);
                
                {ESLVal _v570 = _v215;
                
                {ESLVal l = $647;
                
                {ESLVal op = $646;
                
                {ESLVal args = $645;
                
                return typeEqual(_v570,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                ESLVal $643 = _v216.termRef(1);
                ESLVal $642 = _v216.termRef(2);
                ESLVal $641 = _v216.termRef(3);
                
                {ESLVal _v568 = _v215;
                
                {ESLVal l2 = $644;
                
                {ESLVal _v569 = $643;
                
                {ESLVal ds2 = $642;
                
                {ESLVal ms2 = $641;
                
                return typeEqual(_v568,flattenAct(l2,_v569,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $640 = _v216.termRef(0);
                
                {ESLVal t = _v215;
                
                {ESLVal l1 = $640;
                
                return $true;
              }
              }
              }
            case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                ESLVal $636 = _v216.termRef(1);
                ESLVal $635 = _v216.termRef(2);
                
                switch($635.termName) {
                case "UnionType": {ESLVal $639 = $635.termRef(0);
                  ESLVal $638 = $635.termRef(1);
                  
                  {ESLVal _v565 = _v215;
                  
                  {ESLVal l = $637;
                  
                  {ESLVal state = $636;
                  
                  {ESLVal ul = $639;
                  
                  {ESLVal terms = $638;
                  
                  return typeEqual(_v565,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v566 = _v215;
                  
                  {ESLVal _v567 = _v216;
                  
                  return $false;
                }
                }
              }
              }
            case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                ESLVal $631 = _v216.termRef(1);
                ESLVal $630 = _v216.termRef(2);
                
                switch($630.termName) {
                case "UnionType": {ESLVal $634 = $630.termRef(0);
                  ESLVal $633 = $630.termRef(1);
                  
                  {ESLVal _v562 = _v215;
                  
                  {ESLVal l = $632;
                  
                  {ESLVal state = $631;
                  
                  {ESLVal ul = $634;
                  
                  {ESLVal terms = $633;
                  
                  return typeEqual(_v562,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v563 = _v215;
                  
                  {ESLVal _v564 = _v216;
                  
                  return $false;
                }
                }
              }
              }
            case "TermType": {ESLVal $629 = _v216.termRef(0);
                ESLVal $628 = _v216.termRef(1);
                ESLVal $627 = _v216.termRef(2);
                
                {ESLVal _v561 = _v215;
                
                {ESLVal l2 = $629;
                
                {ESLVal n2 = $628;
                
                {ESLVal args2 = $627;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                
                {ESLVal _v560 = _v215;
                
                {ESLVal f = $626;
                
                return typeEqual(_v560,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $625 = _v216.termRef(0);
                ESLVal $624 = _v216.termRef(1);
                ESLVal $623 = _v216.termRef(2);
                
                {ESLVal _v558 = _v215;
                
                {ESLVal l2 = $625;
                
                {ESLVal n2 = $624;
                
                {ESLVal _v559 = $623;
                
                return typeEqual(_v558,substType(new ESLVal("RecType",l2,n2,_v559),n2,_v559));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $622 = _v216.termRef(0);
                ESLVal $621 = _v216.termRef(1);
                ESLVal $620 = _v216.termRef(2);
                
                {ESLVal _v556 = _v215;
                
                {ESLVal l1 = $622;
                
                {ESLVal ns2 = $621;
                
                {ESLVal _v557 = $620;
                
                return typeEqual(_v556,_v557);
              }
              }
              }
              }
              }
              default: {ESLVal _v571 = _v215;
                
                {ESLVal _v572 = _v216;
                
                return $false;
              }
              }
            }
          }
          }
        case "ObservedType": {ESLVal $717 = _v215.termRef(0);
            ESLVal $716 = _v215.termRef(1);
            ESLVal $715 = _v215.termRef(2);
            
            switch($715.termName) {
            case "UnionType": {ESLVal $722 = $715.termRef(0);
              ESLVal $721 = $715.termRef(1);
              
              {ESLVal l = $717;
              
              {ESLVal state = $716;
              
              {ESLVal ul = $722;
              
              {ESLVal terms = $721;
              
              {ESLVal _v536 = _v216;
              
              return typeEqual(expandObservedType(l,state,new ESLVal("UnionType",ul,terms)),_v536);
            }
            }
            }
            }
            }
            }
            default: switch(_v216.termName) {
              case "ObservedType": {ESLVal $720 = _v216.termRef(0);
                ESLVal $719 = _v216.termRef(1);
                ESLVal $718 = _v216.termRef(2);
                
                {ESLVal l1 = $717;
                
                {ESLVal s1 = $716;
                
                {ESLVal m1 = $715;
                
                {ESLVal l2 = $720;
                
                {ESLVal s2 = $719;
                
                {ESLVal m2 = $718;
                
                return typeEqual(s1,s2).and(typeEqual(m1,m2));
              }
              }
              }
              }
              }
              }
              }
              default: switch(_v216.termName) {
                case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                  ESLVal $646 = _v216.termRef(1);
                  ESLVal $645 = _v216.termRef(2);
                  
                  {ESLVal _v551 = _v215;
                  
                  {ESLVal l = $647;
                  
                  {ESLVal op = $646;
                  
                  {ESLVal args = $645;
                  
                  return typeEqual(_v551,applyTypeFun(l,forceType(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                  ESLVal $643 = _v216.termRef(1);
                  ESLVal $642 = _v216.termRef(2);
                  ESLVal $641 = _v216.termRef(3);
                  
                  {ESLVal _v549 = _v215;
                  
                  {ESLVal l2 = $644;
                  
                  {ESLVal _v550 = $643;
                  
                  {ESLVal ds2 = $642;
                  
                  {ESLVal ms2 = $641;
                  
                  return typeEqual(_v549,flattenAct(l2,_v550,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $640 = _v216.termRef(0);
                  
                  {ESLVal t = _v215;
                  
                  {ESLVal l1 = $640;
                  
                  return $true;
                }
                }
                }
              case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                  ESLVal $636 = _v216.termRef(1);
                  ESLVal $635 = _v216.termRef(2);
                  
                  switch($635.termName) {
                  case "UnionType": {ESLVal $639 = $635.termRef(0);
                    ESLVal $638 = $635.termRef(1);
                    
                    {ESLVal _v546 = _v215;
                    
                    {ESLVal l = $637;
                    
                    {ESLVal state = $636;
                    
                    {ESLVal ul = $639;
                    
                    {ESLVal terms = $638;
                    
                    return typeEqual(_v546,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v547 = _v215;
                    
                    {ESLVal _v548 = _v216;
                    
                    return $false;
                  }
                  }
                }
                }
              case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                  ESLVal $631 = _v216.termRef(1);
                  ESLVal $630 = _v216.termRef(2);
                  
                  switch($630.termName) {
                  case "UnionType": {ESLVal $634 = $630.termRef(0);
                    ESLVal $633 = $630.termRef(1);
                    
                    {ESLVal _v543 = _v215;
                    
                    {ESLVal l = $632;
                    
                    {ESLVal state = $631;
                    
                    {ESLVal ul = $634;
                    
                    {ESLVal terms = $633;
                    
                    return typeEqual(_v543,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v544 = _v215;
                    
                    {ESLVal _v545 = _v216;
                    
                    return $false;
                  }
                  }
                }
                }
              case "TermType": {ESLVal $629 = _v216.termRef(0);
                  ESLVal $628 = _v216.termRef(1);
                  ESLVal $627 = _v216.termRef(2);
                  
                  {ESLVal _v542 = _v215;
                  
                  {ESLVal l2 = $629;
                  
                  {ESLVal n2 = $628;
                  
                  {ESLVal args2 = $627;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                  
                  {ESLVal _v541 = _v215;
                  
                  {ESLVal f = $626;
                  
                  return typeEqual(_v541,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $625 = _v216.termRef(0);
                  ESLVal $624 = _v216.termRef(1);
                  ESLVal $623 = _v216.termRef(2);
                  
                  {ESLVal _v539 = _v215;
                  
                  {ESLVal l2 = $625;
                  
                  {ESLVal n2 = $624;
                  
                  {ESLVal _v540 = $623;
                  
                  return typeEqual(_v539,substType(new ESLVal("RecType",l2,n2,_v540),n2,_v540));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $622 = _v216.termRef(0);
                  ESLVal $621 = _v216.termRef(1);
                  ESLVal $620 = _v216.termRef(2);
                  
                  {ESLVal _v537 = _v215;
                  
                  {ESLVal l1 = $622;
                  
                  {ESLVal ns2 = $621;
                  
                  {ESLVal _v538 = $620;
                  
                  return typeEqual(_v537,_v538);
                }
                }
                }
                }
                }
                default: {ESLVal _v552 = _v215;
                  
                  {ESLVal _v553 = _v216;
                  
                  return $false;
                }
                }
              }
            }
          }
          }
        case "ObserverType": {ESLVal $709 = _v215.termRef(0);
            ESLVal $708 = _v215.termRef(1);
            ESLVal $707 = _v215.termRef(2);
            
            switch($707.termName) {
            case "UnionType": {ESLVal $714 = $707.termRef(0);
              ESLVal $713 = $707.termRef(1);
              
              {ESLVal l = $709;
              
              {ESLVal state = $708;
              
              {ESLVal ul = $714;
              
              {ESLVal terms = $713;
              
              {ESLVal _v518 = _v216;
              
              return typeEqual(expandObserverType(l,state,new ESLVal("UnionType",ul,terms)),_v518);
            }
            }
            }
            }
            }
            }
            default: switch(_v216.termName) {
              case "ObserverType": {ESLVal $712 = _v216.termRef(0);
                ESLVal $711 = _v216.termRef(1);
                ESLVal $710 = _v216.termRef(2);
                
                {ESLVal l1 = $709;
                
                {ESLVal state1 = $708;
                
                {ESLVal messages1 = $707;
                
                {ESLVal l2 = $712;
                
                {ESLVal state2 = $711;
                
                {ESLVal messages2 = $710;
                
                return typeEqual(state1,state2).and(typeEqual(messages1,messages2));
              }
              }
              }
              }
              }
              }
              }
              default: switch(_v216.termName) {
                case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                  ESLVal $646 = _v216.termRef(1);
                  ESLVal $645 = _v216.termRef(2);
                  
                  {ESLVal _v533 = _v215;
                  
                  {ESLVal l = $647;
                  
                  {ESLVal op = $646;
                  
                  {ESLVal args = $645;
                  
                  return typeEqual(_v533,applyTypeFun(l,forceType(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                  ESLVal $643 = _v216.termRef(1);
                  ESLVal $642 = _v216.termRef(2);
                  ESLVal $641 = _v216.termRef(3);
                  
                  {ESLVal _v531 = _v215;
                  
                  {ESLVal l2 = $644;
                  
                  {ESLVal _v532 = $643;
                  
                  {ESLVal ds2 = $642;
                  
                  {ESLVal ms2 = $641;
                  
                  return typeEqual(_v531,flattenAct(l2,_v532,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $640 = _v216.termRef(0);
                  
                  {ESLVal t = _v215;
                  
                  {ESLVal l1 = $640;
                  
                  return $true;
                }
                }
                }
              case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                  ESLVal $636 = _v216.termRef(1);
                  ESLVal $635 = _v216.termRef(2);
                  
                  switch($635.termName) {
                  case "UnionType": {ESLVal $639 = $635.termRef(0);
                    ESLVal $638 = $635.termRef(1);
                    
                    {ESLVal _v528 = _v215;
                    
                    {ESLVal l = $637;
                    
                    {ESLVal state = $636;
                    
                    {ESLVal ul = $639;
                    
                    {ESLVal terms = $638;
                    
                    return typeEqual(_v528,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v529 = _v215;
                    
                    {ESLVal _v530 = _v216;
                    
                    return $false;
                  }
                  }
                }
                }
              case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                  ESLVal $631 = _v216.termRef(1);
                  ESLVal $630 = _v216.termRef(2);
                  
                  switch($630.termName) {
                  case "UnionType": {ESLVal $634 = $630.termRef(0);
                    ESLVal $633 = $630.termRef(1);
                    
                    {ESLVal _v525 = _v215;
                    
                    {ESLVal l = $632;
                    
                    {ESLVal state = $631;
                    
                    {ESLVal ul = $634;
                    
                    {ESLVal terms = $633;
                    
                    return typeEqual(_v525,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v526 = _v215;
                    
                    {ESLVal _v527 = _v216;
                    
                    return $false;
                  }
                  }
                }
                }
              case "TermType": {ESLVal $629 = _v216.termRef(0);
                  ESLVal $628 = _v216.termRef(1);
                  ESLVal $627 = _v216.termRef(2);
                  
                  {ESLVal _v524 = _v215;
                  
                  {ESLVal l2 = $629;
                  
                  {ESLVal n2 = $628;
                  
                  {ESLVal args2 = $627;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                  
                  {ESLVal _v523 = _v215;
                  
                  {ESLVal f = $626;
                  
                  return typeEqual(_v523,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $625 = _v216.termRef(0);
                  ESLVal $624 = _v216.termRef(1);
                  ESLVal $623 = _v216.termRef(2);
                  
                  {ESLVal _v521 = _v215;
                  
                  {ESLVal l2 = $625;
                  
                  {ESLVal n2 = $624;
                  
                  {ESLVal _v522 = $623;
                  
                  return typeEqual(_v521,substType(new ESLVal("RecType",l2,n2,_v522),n2,_v522));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $622 = _v216.termRef(0);
                  ESLVal $621 = _v216.termRef(1);
                  ESLVal $620 = _v216.termRef(2);
                  
                  {ESLVal _v519 = _v215;
                  
                  {ESLVal l1 = $622;
                  
                  {ESLVal ns2 = $621;
                  
                  {ESLVal _v520 = $620;
                  
                  return typeEqual(_v519,_v520);
                }
                }
                }
                }
                }
                default: {ESLVal _v534 = _v215;
                  
                  {ESLVal _v535 = _v216;
                  
                  return $false;
                }
                }
              }
            }
          }
          }
        case "TableType": {ESLVal $703 = _v215.termRef(0);
            ESLVal $702 = _v215.termRef(1);
            ESLVal $701 = _v215.termRef(2);
            
            switch(_v216.termName) {
            case "TableType": {ESLVal $706 = _v216.termRef(0);
              ESLVal $705 = _v216.termRef(1);
              ESLVal $704 = _v216.termRef(2);
              
              {ESLVal l1 = $703;
              
              {ESLVal k1 = $702;
              
              {ESLVal v1 = $701;
              
              {ESLVal l2 = $706;
              
              {ESLVal k2 = $705;
              
              {ESLVal v2 = $704;
              
              return typeEqual(k1,k2).and(typeEqual(v1,v2));
            }
            }
            }
            }
            }
            }
            }
            default: switch(_v216.termName) {
              case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                ESLVal $646 = _v216.termRef(1);
                ESLVal $645 = _v216.termRef(2);
                
                {ESLVal _v515 = _v215;
                
                {ESLVal l = $647;
                
                {ESLVal op = $646;
                
                {ESLVal args = $645;
                
                return typeEqual(_v515,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                ESLVal $643 = _v216.termRef(1);
                ESLVal $642 = _v216.termRef(2);
                ESLVal $641 = _v216.termRef(3);
                
                {ESLVal _v513 = _v215;
                
                {ESLVal l2 = $644;
                
                {ESLVal _v514 = $643;
                
                {ESLVal ds2 = $642;
                
                {ESLVal ms2 = $641;
                
                return typeEqual(_v513,flattenAct(l2,_v514,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $640 = _v216.termRef(0);
                
                {ESLVal t = _v215;
                
                {ESLVal l1 = $640;
                
                return $true;
              }
              }
              }
            case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                ESLVal $636 = _v216.termRef(1);
                ESLVal $635 = _v216.termRef(2);
                
                switch($635.termName) {
                case "UnionType": {ESLVal $639 = $635.termRef(0);
                  ESLVal $638 = $635.termRef(1);
                  
                  {ESLVal _v510 = _v215;
                  
                  {ESLVal l = $637;
                  
                  {ESLVal state = $636;
                  
                  {ESLVal ul = $639;
                  
                  {ESLVal terms = $638;
                  
                  return typeEqual(_v510,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v511 = _v215;
                  
                  {ESLVal _v512 = _v216;
                  
                  return $false;
                }
                }
              }
              }
            case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                ESLVal $631 = _v216.termRef(1);
                ESLVal $630 = _v216.termRef(2);
                
                switch($630.termName) {
                case "UnionType": {ESLVal $634 = $630.termRef(0);
                  ESLVal $633 = $630.termRef(1);
                  
                  {ESLVal _v507 = _v215;
                  
                  {ESLVal l = $632;
                  
                  {ESLVal state = $631;
                  
                  {ESLVal ul = $634;
                  
                  {ESLVal terms = $633;
                  
                  return typeEqual(_v507,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v508 = _v215;
                  
                  {ESLVal _v509 = _v216;
                  
                  return $false;
                }
                }
              }
              }
            case "TermType": {ESLVal $629 = _v216.termRef(0);
                ESLVal $628 = _v216.termRef(1);
                ESLVal $627 = _v216.termRef(2);
                
                {ESLVal _v506 = _v215;
                
                {ESLVal l2 = $629;
                
                {ESLVal n2 = $628;
                
                {ESLVal args2 = $627;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                
                {ESLVal _v505 = _v215;
                
                {ESLVal f = $626;
                
                return typeEqual(_v505,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $625 = _v216.termRef(0);
                ESLVal $624 = _v216.termRef(1);
                ESLVal $623 = _v216.termRef(2);
                
                {ESLVal _v503 = _v215;
                
                {ESLVal l2 = $625;
                
                {ESLVal n2 = $624;
                
                {ESLVal _v504 = $623;
                
                return typeEqual(_v503,substType(new ESLVal("RecType",l2,n2,_v504),n2,_v504));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $622 = _v216.termRef(0);
                ESLVal $621 = _v216.termRef(1);
                ESLVal $620 = _v216.termRef(2);
                
                {ESLVal _v501 = _v215;
                
                {ESLVal l1 = $622;
                
                {ESLVal ns2 = $621;
                
                {ESLVal _v502 = $620;
                
                return typeEqual(_v501,_v502);
              }
              }
              }
              }
              }
              default: {ESLVal _v516 = _v215;
                
                {ESLVal _v517 = _v216;
                
                return $false;
              }
              }
            }
          }
          }
        case "TermType": {ESLVal $697 = _v215.termRef(0);
            ESLVal $696 = _v215.termRef(1);
            ESLVal $695 = _v215.termRef(2);
            
            switch(_v216.termName) {
            case "TermType": {ESLVal $700 = _v216.termRef(0);
              ESLVal $699 = _v216.termRef(1);
              ESLVal $698 = _v216.termRef(2);
              
              {ESLVal l1 = $697;
              
              {ESLVal n1 = $696;
              
              {ESLVal args1 = $695;
              
              {ESLVal l2 = $700;
              
              {ESLVal n2 = $699;
              
              {ESLVal args2 = $698;
              
              if(n1.eql(n2).boolVal)
              return typesEqual(args1,args2);
              else
                return $false;
            }
            }
            }
            }
            }
            }
            }
            default: {ESLVal l1 = $697;
              
              {ESLVal n1 = $696;
              
              {ESLVal args1 = $695;
              
              {ESLVal _v500 = _v216;
              
              return $false;
            }
            }
            }
            }
          }
          }
        case "FunType": {ESLVal $691 = _v215.termRef(0);
            ESLVal $690 = _v215.termRef(1);
            ESLVal $689 = _v215.termRef(2);
            
            switch(_v216.termName) {
            case "FunType": {ESLVal $694 = _v216.termRef(0);
              ESLVal $693 = _v216.termRef(1);
              ESLVal $692 = _v216.termRef(2);
              
              {ESLVal l1 = $691;
              
              {ESLVal d1 = $690;
              
              {ESLVal r1 = $689;
              
              {ESLVal l2 = $694;
              
              {ESLVal d2 = $693;
              
              {ESLVal r2 = $692;
              
              return typeEqual(r1,r2).and(typesEqual(d1,d2));
            }
            }
            }
            }
            }
            }
            }
            default: switch(_v216.termName) {
              case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                ESLVal $646 = _v216.termRef(1);
                ESLVal $645 = _v216.termRef(2);
                
                {ESLVal _v497 = _v215;
                
                {ESLVal l = $647;
                
                {ESLVal op = $646;
                
                {ESLVal args = $645;
                
                return typeEqual(_v497,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                ESLVal $643 = _v216.termRef(1);
                ESLVal $642 = _v216.termRef(2);
                ESLVal $641 = _v216.termRef(3);
                
                {ESLVal _v495 = _v215;
                
                {ESLVal l2 = $644;
                
                {ESLVal _v496 = $643;
                
                {ESLVal ds2 = $642;
                
                {ESLVal ms2 = $641;
                
                return typeEqual(_v495,flattenAct(l2,_v496,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $640 = _v216.termRef(0);
                
                {ESLVal t = _v215;
                
                {ESLVal l1 = $640;
                
                return $true;
              }
              }
              }
            case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                ESLVal $636 = _v216.termRef(1);
                ESLVal $635 = _v216.termRef(2);
                
                switch($635.termName) {
                case "UnionType": {ESLVal $639 = $635.termRef(0);
                  ESLVal $638 = $635.termRef(1);
                  
                  {ESLVal _v492 = _v215;
                  
                  {ESLVal l = $637;
                  
                  {ESLVal state = $636;
                  
                  {ESLVal ul = $639;
                  
                  {ESLVal terms = $638;
                  
                  return typeEqual(_v492,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v493 = _v215;
                  
                  {ESLVal _v494 = _v216;
                  
                  return $false;
                }
                }
              }
              }
            case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                ESLVal $631 = _v216.termRef(1);
                ESLVal $630 = _v216.termRef(2);
                
                switch($630.termName) {
                case "UnionType": {ESLVal $634 = $630.termRef(0);
                  ESLVal $633 = $630.termRef(1);
                  
                  {ESLVal _v489 = _v215;
                  
                  {ESLVal l = $632;
                  
                  {ESLVal state = $631;
                  
                  {ESLVal ul = $634;
                  
                  {ESLVal terms = $633;
                  
                  return typeEqual(_v489,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v490 = _v215;
                  
                  {ESLVal _v491 = _v216;
                  
                  return $false;
                }
                }
              }
              }
            case "TermType": {ESLVal $629 = _v216.termRef(0);
                ESLVal $628 = _v216.termRef(1);
                ESLVal $627 = _v216.termRef(2);
                
                {ESLVal _v488 = _v215;
                
                {ESLVal l2 = $629;
                
                {ESLVal n2 = $628;
                
                {ESLVal args2 = $627;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                
                {ESLVal _v487 = _v215;
                
                {ESLVal f = $626;
                
                return typeEqual(_v487,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $625 = _v216.termRef(0);
                ESLVal $624 = _v216.termRef(1);
                ESLVal $623 = _v216.termRef(2);
                
                {ESLVal _v485 = _v215;
                
                {ESLVal l2 = $625;
                
                {ESLVal n2 = $624;
                
                {ESLVal _v486 = $623;
                
                return typeEqual(_v485,substType(new ESLVal("RecType",l2,n2,_v486),n2,_v486));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $622 = _v216.termRef(0);
                ESLVal $621 = _v216.termRef(1);
                ESLVal $620 = _v216.termRef(2);
                
                {ESLVal _v483 = _v215;
                
                {ESLVal l1 = $622;
                
                {ESLVal ns2 = $621;
                
                {ESLVal _v484 = $620;
                
                return typeEqual(_v483,_v484);
              }
              }
              }
              }
              }
              default: {ESLVal _v498 = _v215;
                
                {ESLVal _v499 = _v216;
                
                return $false;
              }
              }
            }
          }
          }
        case "TypeClosure": {ESLVal $688 = _v215.termRef(0);
            
            {ESLVal f = $688;
            
            {ESLVal _v482 = _v216;
            
            return typeEqual(f.apply(),_v482);
          }
          }
          }
        case "RecordType": {ESLVal $685 = _v215.termRef(0);
            ESLVal $684 = _v215.termRef(1);
            
            switch(_v216.termName) {
            case "RecordType": {ESLVal $687 = _v216.termRef(0);
              ESLVal $686 = _v216.termRef(1);
              
              {ESLVal l1 = $685;
              
              {ESLVal fs1 = $684;
              
              {ESLVal l2 = $687;
              
              {ESLVal fs2 = $686;
              
              return recordTypeEqual(fs1,fs2);
            }
            }
            }
            }
            }
            default: switch(_v216.termName) {
              case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                ESLVal $646 = _v216.termRef(1);
                ESLVal $645 = _v216.termRef(2);
                
                {ESLVal _v479 = _v215;
                
                {ESLVal l = $647;
                
                {ESLVal op = $646;
                
                {ESLVal args = $645;
                
                return typeEqual(_v479,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                ESLVal $643 = _v216.termRef(1);
                ESLVal $642 = _v216.termRef(2);
                ESLVal $641 = _v216.termRef(3);
                
                {ESLVal _v477 = _v215;
                
                {ESLVal l2 = $644;
                
                {ESLVal _v478 = $643;
                
                {ESLVal ds2 = $642;
                
                {ESLVal ms2 = $641;
                
                return typeEqual(_v477,flattenAct(l2,_v478,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $640 = _v216.termRef(0);
                
                {ESLVal t = _v215;
                
                {ESLVal l1 = $640;
                
                return $true;
              }
              }
              }
            case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                ESLVal $636 = _v216.termRef(1);
                ESLVal $635 = _v216.termRef(2);
                
                switch($635.termName) {
                case "UnionType": {ESLVal $639 = $635.termRef(0);
                  ESLVal $638 = $635.termRef(1);
                  
                  {ESLVal _v474 = _v215;
                  
                  {ESLVal l = $637;
                  
                  {ESLVal state = $636;
                  
                  {ESLVal ul = $639;
                  
                  {ESLVal terms = $638;
                  
                  return typeEqual(_v474,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v475 = _v215;
                  
                  {ESLVal _v476 = _v216;
                  
                  return $false;
                }
                }
              }
              }
            case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                ESLVal $631 = _v216.termRef(1);
                ESLVal $630 = _v216.termRef(2);
                
                switch($630.termName) {
                case "UnionType": {ESLVal $634 = $630.termRef(0);
                  ESLVal $633 = $630.termRef(1);
                  
                  {ESLVal _v471 = _v215;
                  
                  {ESLVal l = $632;
                  
                  {ESLVal state = $631;
                  
                  {ESLVal ul = $634;
                  
                  {ESLVal terms = $633;
                  
                  return typeEqual(_v471,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v472 = _v215;
                  
                  {ESLVal _v473 = _v216;
                  
                  return $false;
                }
                }
              }
              }
            case "TermType": {ESLVal $629 = _v216.termRef(0);
                ESLVal $628 = _v216.termRef(1);
                ESLVal $627 = _v216.termRef(2);
                
                {ESLVal _v470 = _v215;
                
                {ESLVal l2 = $629;
                
                {ESLVal n2 = $628;
                
                {ESLVal args2 = $627;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                
                {ESLVal _v469 = _v215;
                
                {ESLVal f = $626;
                
                return typeEqual(_v469,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $625 = _v216.termRef(0);
                ESLVal $624 = _v216.termRef(1);
                ESLVal $623 = _v216.termRef(2);
                
                {ESLVal _v467 = _v215;
                
                {ESLVal l2 = $625;
                
                {ESLVal n2 = $624;
                
                {ESLVal _v468 = $623;
                
                return typeEqual(_v467,substType(new ESLVal("RecType",l2,n2,_v468),n2,_v468));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $622 = _v216.termRef(0);
                ESLVal $621 = _v216.termRef(1);
                ESLVal $620 = _v216.termRef(2);
                
                {ESLVal _v465 = _v215;
                
                {ESLVal l1 = $622;
                
                {ESLVal ns2 = $621;
                
                {ESLVal _v466 = $620;
                
                return typeEqual(_v465,_v466);
              }
              }
              }
              }
              }
              default: {ESLVal _v480 = _v215;
                
                {ESLVal _v481 = _v216;
                
                return $false;
              }
              }
            }
          }
          }
        case "RecType": {ESLVal $680 = _v215.termRef(0);
            ESLVal $679 = _v215.termRef(1);
            ESLVal $678 = _v215.termRef(2);
            
            switch(_v216.termName) {
            case "RecType": {ESLVal $683 = _v216.termRef(0);
              ESLVal $682 = _v216.termRef(1);
              ESLVal $681 = _v216.termRef(2);
              
              {ESLVal l1 = $680;
              
              {ESLVal n1 = $679;
              
              {ESLVal _v457 = $678;
              
              {ESLVal l2 = $683;
              
              {ESLVal n2 = $682;
              
              {ESLVal _v458 = $681;
              
              if(n1.eql(n2).boolVal)
              return typeEqual(_v457,_v458);
              else
                {ESLVal _v459 = $680;
                  
                  {ESLVal _v460 = $679;
                  
                  {ESLVal _v461 = $678;
                  
                  {ESLVal _v462 = _v216;
                  
                  return typeEqual(substType(new ESLVal("RecType",_v459,_v460,_v461),_v460,_v461),_v462);
                }
                }
                }
                }
            }
            }
            }
            }
            }
            }
            }
            default: {ESLVal l1 = $680;
              
              {ESLVal n1 = $679;
              
              {ESLVal _v463 = $678;
              
              {ESLVal _v464 = _v216;
              
              return typeEqual(substType(new ESLVal("RecType",l1,n1,_v463),n1,_v463),_v464);
            }
            }
            }
            }
          }
          }
        case "UnionType": {ESLVal $675 = _v215.termRef(0);
            ESLVal $674 = _v215.termRef(1);
            
            switch(_v216.termName) {
            case "UnionType": {ESLVal $677 = _v216.termRef(0);
              ESLVal $676 = _v216.termRef(1);
              
              {ESLVal l1 = $675;
              
              {ESLVal terms1 = $674;
              
              {ESLVal l2 = $677;
              
              {ESLVal terms2 = $676;
              
              return typeSetEqual(terms1,terms2);
            }
            }
            }
            }
            }
            default: switch(_v216.termName) {
              case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                ESLVal $646 = _v216.termRef(1);
                ESLVal $645 = _v216.termRef(2);
                
                {ESLVal _v454 = _v215;
                
                {ESLVal l = $647;
                
                {ESLVal op = $646;
                
                {ESLVal args = $645;
                
                return typeEqual(_v454,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                ESLVal $643 = _v216.termRef(1);
                ESLVal $642 = _v216.termRef(2);
                ESLVal $641 = _v216.termRef(3);
                
                {ESLVal _v452 = _v215;
                
                {ESLVal l2 = $644;
                
                {ESLVal _v453 = $643;
                
                {ESLVal ds2 = $642;
                
                {ESLVal ms2 = $641;
                
                return typeEqual(_v452,flattenAct(l2,_v453,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $640 = _v216.termRef(0);
                
                {ESLVal t = _v215;
                
                {ESLVal l1 = $640;
                
                return $true;
              }
              }
              }
            case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                ESLVal $636 = _v216.termRef(1);
                ESLVal $635 = _v216.termRef(2);
                
                switch($635.termName) {
                case "UnionType": {ESLVal $639 = $635.termRef(0);
                  ESLVal $638 = $635.termRef(1);
                  
                  {ESLVal _v449 = _v215;
                  
                  {ESLVal l = $637;
                  
                  {ESLVal state = $636;
                  
                  {ESLVal ul = $639;
                  
                  {ESLVal terms = $638;
                  
                  return typeEqual(_v449,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v450 = _v215;
                  
                  {ESLVal _v451 = _v216;
                  
                  return $false;
                }
                }
              }
              }
            case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                ESLVal $631 = _v216.termRef(1);
                ESLVal $630 = _v216.termRef(2);
                
                switch($630.termName) {
                case "UnionType": {ESLVal $634 = $630.termRef(0);
                  ESLVal $633 = $630.termRef(1);
                  
                  {ESLVal _v446 = _v215;
                  
                  {ESLVal l = $632;
                  
                  {ESLVal state = $631;
                  
                  {ESLVal ul = $634;
                  
                  {ESLVal terms = $633;
                  
                  return typeEqual(_v446,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v447 = _v215;
                  
                  {ESLVal _v448 = _v216;
                  
                  return $false;
                }
                }
              }
              }
            case "TermType": {ESLVal $629 = _v216.termRef(0);
                ESLVal $628 = _v216.termRef(1);
                ESLVal $627 = _v216.termRef(2);
                
                {ESLVal _v445 = _v215;
                
                {ESLVal l2 = $629;
                
                {ESLVal n2 = $628;
                
                {ESLVal args2 = $627;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                
                {ESLVal _v444 = _v215;
                
                {ESLVal f = $626;
                
                return typeEqual(_v444,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $625 = _v216.termRef(0);
                ESLVal $624 = _v216.termRef(1);
                ESLVal $623 = _v216.termRef(2);
                
                {ESLVal _v442 = _v215;
                
                {ESLVal l2 = $625;
                
                {ESLVal n2 = $624;
                
                {ESLVal _v443 = $623;
                
                return typeEqual(_v442,substType(new ESLVal("RecType",l2,n2,_v443),n2,_v443));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $622 = _v216.termRef(0);
                ESLVal $621 = _v216.termRef(1);
                ESLVal $620 = _v216.termRef(2);
                
                {ESLVal _v440 = _v215;
                
                {ESLVal l1 = $622;
                
                {ESLVal ns2 = $621;
                
                {ESLVal _v441 = $620;
                
                return typeEqual(_v440,_v441);
              }
              }
              }
              }
              }
              default: {ESLVal _v455 = _v215;
                
                {ESLVal _v456 = _v216;
                
                return $false;
              }
              }
            }
          }
          }
        case "VarType": {ESLVal $671 = _v215.termRef(0);
            ESLVal $670 = _v215.termRef(1);
            
            switch(_v216.termName) {
            case "VarType": {ESLVal $673 = _v216.termRef(0);
              ESLVal $672 = _v216.termRef(1);
              
              {ESLVal l1 = $671;
              
              {ESLVal n1 = $670;
              
              {ESLVal l2 = $673;
              
              {ESLVal n2 = $672;
              
              return n1.eql(n2);
            }
            }
            }
            }
            }
            default: switch(_v216.termName) {
              case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
                ESLVal $646 = _v216.termRef(1);
                ESLVal $645 = _v216.termRef(2);
                
                {ESLVal _v437 = _v215;
                
                {ESLVal l = $647;
                
                {ESLVal op = $646;
                
                {ESLVal args = $645;
                
                return typeEqual(_v437,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
                ESLVal $643 = _v216.termRef(1);
                ESLVal $642 = _v216.termRef(2);
                ESLVal $641 = _v216.termRef(3);
                
                {ESLVal _v435 = _v215;
                
                {ESLVal l2 = $644;
                
                {ESLVal _v436 = $643;
                
                {ESLVal ds2 = $642;
                
                {ESLVal ms2 = $641;
                
                return typeEqual(_v435,flattenAct(l2,_v436,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $640 = _v216.termRef(0);
                
                {ESLVal t = _v215;
                
                {ESLVal l1 = $640;
                
                return $true;
              }
              }
              }
            case "ObservedType": {ESLVal $637 = _v216.termRef(0);
                ESLVal $636 = _v216.termRef(1);
                ESLVal $635 = _v216.termRef(2);
                
                switch($635.termName) {
                case "UnionType": {ESLVal $639 = $635.termRef(0);
                  ESLVal $638 = $635.termRef(1);
                  
                  {ESLVal _v432 = _v215;
                  
                  {ESLVal l = $637;
                  
                  {ESLVal state = $636;
                  
                  {ESLVal ul = $639;
                  
                  {ESLVal terms = $638;
                  
                  return typeEqual(_v432,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v433 = _v215;
                  
                  {ESLVal _v434 = _v216;
                  
                  return $false;
                }
                }
              }
              }
            case "ObserverType": {ESLVal $632 = _v216.termRef(0);
                ESLVal $631 = _v216.termRef(1);
                ESLVal $630 = _v216.termRef(2);
                
                switch($630.termName) {
                case "UnionType": {ESLVal $634 = $630.termRef(0);
                  ESLVal $633 = $630.termRef(1);
                  
                  {ESLVal _v429 = _v215;
                  
                  {ESLVal l = $632;
                  
                  {ESLVal state = $631;
                  
                  {ESLVal ul = $634;
                  
                  {ESLVal terms = $633;
                  
                  return typeEqual(_v429,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v430 = _v215;
                  
                  {ESLVal _v431 = _v216;
                  
                  return $false;
                }
                }
              }
              }
            case "TermType": {ESLVal $629 = _v216.termRef(0);
                ESLVal $628 = _v216.termRef(1);
                ESLVal $627 = _v216.termRef(2);
                
                {ESLVal _v428 = _v215;
                
                {ESLVal l2 = $629;
                
                {ESLVal n2 = $628;
                
                {ESLVal args2 = $627;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
                
                {ESLVal _v427 = _v215;
                
                {ESLVal f = $626;
                
                return typeEqual(_v427,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $625 = _v216.termRef(0);
                ESLVal $624 = _v216.termRef(1);
                ESLVal $623 = _v216.termRef(2);
                
                {ESLVal _v425 = _v215;
                
                {ESLVal l2 = $625;
                
                {ESLVal n2 = $624;
                
                {ESLVal _v426 = $623;
                
                return typeEqual(_v425,substType(new ESLVal("RecType",l2,n2,_v426),n2,_v426));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $622 = _v216.termRef(0);
                ESLVal $621 = _v216.termRef(1);
                ESLVal $620 = _v216.termRef(2);
                
                {ESLVal _v423 = _v215;
                
                {ESLVal l1 = $622;
                
                {ESLVal ns2 = $621;
                
                {ESLVal _v424 = $620;
                
                return typeEqual(_v423,_v424);
              }
              }
              }
              }
              }
              default: {ESLVal _v438 = _v215;
                
                {ESLVal _v439 = _v216;
                
                return $false;
              }
              }
            }
          }
          }
        case "ForallType": {ESLVal $650 = _v215.termRef(0);
            ESLVal $649 = _v215.termRef(1);
            ESLVal $648 = _v215.termRef(2);
            
            if($649.isCons())
            {ESLVal $654 = $649.head();
              ESLVal $655 = $649.tail();
              
              if($655.isCons())
              {ESLVal $656 = $655.head();
                ESLVal $657 = $655.tail();
                
                switch(_v216.termName) {
                case "ForallType": {ESLVal $653 = _v216.termRef(0);
                  ESLVal $652 = _v216.termRef(1);
                  ESLVal $651 = _v216.termRef(2);
                  
                  {ESLVal l1 = $650;
                  
                  {ESLVal ns1 = $649;
                  
                  {ESLVal _v371 = $648;
                  
                  {ESLVal l2 = $653;
                  
                  {ESLVal ns2 = $652;
                  
                  {ESLVal _v372 = $651;
                  
                  return ns1.eql(ns2).and(typeEqual(_v371,_v372));
                }
                }
                }
                }
                }
                }
                }
                default: {ESLVal l1 = $650;
                  
                  {ESLVal ns1 = $649;
                  
                  {ESLVal _v373 = $648;
                  
                  {ESLVal _v374 = _v216;
                  
                  return typeEqual(_v373,_v374);
                }
                }
                }
                }
              }
              }
            else if($655.isNil())
              switch($648.termName) {
                case "ListType": {ESLVal $665 = $648.termRef(0);
                  ESLVal $664 = $648.termRef(1);
                  
                  switch($664.termName) {
                  case "VarType": {ESLVal $667 = $664.termRef(0);
                    ESLVal $666 = $664.termRef(1);
                    
                    switch(_v216.termName) {
                    case "ListType": {ESLVal $669 = _v216.termRef(0);
                      ESLVal $668 = _v216.termRef(1);
                      
                      {ESLVal l2 = $650;
                      
                      {ESLVal v1 = $654;
                      
                      {ESLVal l3 = $665;
                      
                      {ESLVal l4 = $667;
                      
                      {ESLVal v2 = $666;
                      
                      {ESLVal l1 = $669;
                      
                      {ESLVal _v391 = $668;
                      
                      if(v1.eql(v2).boolVal)
                      return $true;
                      else
                        switch(_v216.termName) {
                          case "ForallType": {ESLVal $653 = _v216.termRef(0);
                            ESLVal $652 = _v216.termRef(1);
                            ESLVal $651 = _v216.termRef(2);
                            
                            {ESLVal _v392 = $650;
                            
                            {ESLVal ns1 = $649;
                            
                            {ESLVal _v393 = $648;
                            
                            {ESLVal _v394 = $653;
                            
                            {ESLVal ns2 = $652;
                            
                            {ESLVal _v395 = $651;
                            
                            return ns1.eql(ns2).and(typeEqual(_v393,_v395));
                          }
                          }
                          }
                          }
                          }
                          }
                          }
                          default: {ESLVal _v396 = $650;
                            
                            {ESLVal ns1 = $649;
                            
                            {ESLVal _v397 = $648;
                            
                            {ESLVal _v398 = _v216;
                            
                            return typeEqual(_v397,_v398);
                          }
                          }
                          }
                          }
                        }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: switch(_v216.termName) {
                      case "ForallType": {ESLVal $653 = _v216.termRef(0);
                        ESLVal $652 = _v216.termRef(1);
                        ESLVal $651 = _v216.termRef(2);
                        
                        {ESLVal l1 = $650;
                        
                        {ESLVal ns1 = $649;
                        
                        {ESLVal _v399 = $648;
                        
                        {ESLVal l2 = $653;
                        
                        {ESLVal ns2 = $652;
                        
                        {ESLVal _v400 = $651;
                        
                        return ns1.eql(ns2).and(typeEqual(_v399,_v400));
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal l1 = $650;
                        
                        {ESLVal ns1 = $649;
                        
                        {ESLVal _v401 = $648;
                        
                        {ESLVal _v402 = _v216;
                        
                        return typeEqual(_v401,_v402);
                      }
                      }
                      }
                      }
                    }
                  }
                  }
                  default: switch(_v216.termName) {
                    case "ForallType": {ESLVal $653 = _v216.termRef(0);
                      ESLVal $652 = _v216.termRef(1);
                      ESLVal $651 = _v216.termRef(2);
                      
                      {ESLVal l1 = $650;
                      
                      {ESLVal ns1 = $649;
                      
                      {ESLVal _v403 = $648;
                      
                      {ESLVal l2 = $653;
                      
                      {ESLVal ns2 = $652;
                      
                      {ESLVal _v404 = $651;
                      
                      return ns1.eql(ns2).and(typeEqual(_v403,_v404));
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal l1 = $650;
                      
                      {ESLVal ns1 = $649;
                      
                      {ESLVal _v405 = $648;
                      
                      {ESLVal _v406 = _v216;
                      
                      return typeEqual(_v405,_v406);
                    }
                    }
                    }
                    }
                  }
                }
                }
              case "SetType": {ESLVal $659 = $648.termRef(0);
                  ESLVal $658 = $648.termRef(1);
                  
                  switch($658.termName) {
                  case "VarType": {ESLVal $661 = $658.termRef(0);
                    ESLVal $660 = $658.termRef(1);
                    
                    switch(_v216.termName) {
                    case "SetType": {ESLVal $663 = _v216.termRef(0);
                      ESLVal $662 = _v216.termRef(1);
                      
                      {ESLVal l2 = $650;
                      
                      {ESLVal v1 = $654;
                      
                      {ESLVal l3 = $659;
                      
                      {ESLVal l4 = $661;
                      
                      {ESLVal v2 = $660;
                      
                      {ESLVal l1 = $663;
                      
                      {ESLVal _v375 = $662;
                      
                      if(v1.eql(v2).boolVal)
                      return $true;
                      else
                        switch(_v216.termName) {
                          case "ForallType": {ESLVal $653 = _v216.termRef(0);
                            ESLVal $652 = _v216.termRef(1);
                            ESLVal $651 = _v216.termRef(2);
                            
                            {ESLVal _v376 = $650;
                            
                            {ESLVal ns1 = $649;
                            
                            {ESLVal _v377 = $648;
                            
                            {ESLVal _v378 = $653;
                            
                            {ESLVal ns2 = $652;
                            
                            {ESLVal _v379 = $651;
                            
                            return ns1.eql(ns2).and(typeEqual(_v377,_v379));
                          }
                          }
                          }
                          }
                          }
                          }
                          }
                          default: {ESLVal _v380 = $650;
                            
                            {ESLVal ns1 = $649;
                            
                            {ESLVal _v381 = $648;
                            
                            {ESLVal _v382 = _v216;
                            
                            return typeEqual(_v381,_v382);
                          }
                          }
                          }
                          }
                        }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: switch(_v216.termName) {
                      case "ForallType": {ESLVal $653 = _v216.termRef(0);
                        ESLVal $652 = _v216.termRef(1);
                        ESLVal $651 = _v216.termRef(2);
                        
                        {ESLVal l1 = $650;
                        
                        {ESLVal ns1 = $649;
                        
                        {ESLVal _v383 = $648;
                        
                        {ESLVal l2 = $653;
                        
                        {ESLVal ns2 = $652;
                        
                        {ESLVal _v384 = $651;
                        
                        return ns1.eql(ns2).and(typeEqual(_v383,_v384));
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal l1 = $650;
                        
                        {ESLVal ns1 = $649;
                        
                        {ESLVal _v385 = $648;
                        
                        {ESLVal _v386 = _v216;
                        
                        return typeEqual(_v385,_v386);
                      }
                      }
                      }
                      }
                    }
                  }
                  }
                  default: switch(_v216.termName) {
                    case "ForallType": {ESLVal $653 = _v216.termRef(0);
                      ESLVal $652 = _v216.termRef(1);
                      ESLVal $651 = _v216.termRef(2);
                      
                      {ESLVal l1 = $650;
                      
                      {ESLVal ns1 = $649;
                      
                      {ESLVal _v387 = $648;
                      
                      {ESLVal l2 = $653;
                      
                      {ESLVal ns2 = $652;
                      
                      {ESLVal _v388 = $651;
                      
                      return ns1.eql(ns2).and(typeEqual(_v387,_v388));
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal l1 = $650;
                      
                      {ESLVal ns1 = $649;
                      
                      {ESLVal _v389 = $648;
                      
                      {ESLVal _v390 = _v216;
                      
                      return typeEqual(_v389,_v390);
                    }
                    }
                    }
                    }
                  }
                }
                }
                default: switch(_v216.termName) {
                  case "ForallType": {ESLVal $653 = _v216.termRef(0);
                    ESLVal $652 = _v216.termRef(1);
                    ESLVal $651 = _v216.termRef(2);
                    
                    {ESLVal l1 = $650;
                    
                    {ESLVal ns1 = $649;
                    
                    {ESLVal _v407 = $648;
                    
                    {ESLVal l2 = $653;
                    
                    {ESLVal ns2 = $652;
                    
                    {ESLVal _v408 = $651;
                    
                    return ns1.eql(ns2).and(typeEqual(_v407,_v408));
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal l1 = $650;
                    
                    {ESLVal ns1 = $649;
                    
                    {ESLVal _v409 = $648;
                    
                    {ESLVal _v410 = _v216;
                    
                    return typeEqual(_v409,_v410);
                  }
                  }
                  }
                  }
                }
              }
            else switch(_v216.termName) {
                case "ForallType": {ESLVal $653 = _v216.termRef(0);
                  ESLVal $652 = _v216.termRef(1);
                  ESLVal $651 = _v216.termRef(2);
                  
                  {ESLVal l1 = $650;
                  
                  {ESLVal ns1 = $649;
                  
                  {ESLVal _v411 = $648;
                  
                  {ESLVal l2 = $653;
                  
                  {ESLVal ns2 = $652;
                  
                  {ESLVal _v412 = $651;
                  
                  return ns1.eql(ns2).and(typeEqual(_v411,_v412));
                }
                }
                }
                }
                }
                }
                }
                default: {ESLVal l1 = $650;
                  
                  {ESLVal ns1 = $649;
                  
                  {ESLVal _v413 = $648;
                  
                  {ESLVal _v414 = _v216;
                  
                  return typeEqual(_v413,_v414);
                }
                }
                }
                }
              }
            }
          else if($649.isNil())
            switch(_v216.termName) {
              case "ForallType": {ESLVal $653 = _v216.termRef(0);
                ESLVal $652 = _v216.termRef(1);
                ESLVal $651 = _v216.termRef(2);
                
                {ESLVal l1 = $650;
                
                {ESLVal ns1 = $649;
                
                {ESLVal _v415 = $648;
                
                {ESLVal l2 = $653;
                
                {ESLVal ns2 = $652;
                
                {ESLVal _v416 = $651;
                
                return ns1.eql(ns2).and(typeEqual(_v415,_v416));
              }
              }
              }
              }
              }
              }
              }
              default: {ESLVal l1 = $650;
                
                {ESLVal ns1 = $649;
                
                {ESLVal _v417 = $648;
                
                {ESLVal _v418 = _v216;
                
                return typeEqual(_v417,_v418);
              }
              }
              }
              }
            }
          else switch(_v216.termName) {
              case "ForallType": {ESLVal $653 = _v216.termRef(0);
                ESLVal $652 = _v216.termRef(1);
                ESLVal $651 = _v216.termRef(2);
                
                {ESLVal l1 = $650;
                
                {ESLVal ns1 = $649;
                
                {ESLVal _v419 = $648;
                
                {ESLVal l2 = $653;
                
                {ESLVal ns2 = $652;
                
                {ESLVal _v420 = $651;
                
                return ns1.eql(ns2).and(typeEqual(_v419,_v420));
              }
              }
              }
              }
              }
              }
              }
              default: {ESLVal l1 = $650;
                
                {ESLVal ns1 = $649;
                
                {ESLVal _v421 = $648;
                
                {ESLVal _v422 = _v216;
                
                return typeEqual(_v421,_v422);
              }
              }
              }
              }
            }
          }
          default: switch(_v216.termName) {
            case "ApplyTypeFun": {ESLVal $647 = _v216.termRef(0);
              ESLVal $646 = _v216.termRef(1);
              ESLVal $645 = _v216.termRef(2);
              
              {ESLVal _v1001 = _v215;
              
              {ESLVal l = $647;
              
              {ESLVal op = $646;
              
              {ESLVal args = $645;
              
              return typeEqual(_v1001,applyTypeFun(l,forceType(op),args));
            }
            }
            }
            }
            }
          case "ExtendedAct": {ESLVal $644 = _v216.termRef(0);
              ESLVal $643 = _v216.termRef(1);
              ESLVal $642 = _v216.termRef(2);
              ESLVal $641 = _v216.termRef(3);
              
              {ESLVal _v999 = _v215;
              
              {ESLVal l2 = $644;
              
              {ESLVal _v1000 = $643;
              
              {ESLVal ds2 = $642;
              
              {ESLVal ms2 = $641;
              
              return typeEqual(_v999,flattenAct(l2,_v1000,ds2,ms2));
            }
            }
            }
            }
            }
            }
          case "VoidType": {ESLVal $640 = _v216.termRef(0);
              
              {ESLVal t = _v215;
              
              {ESLVal l1 = $640;
              
              return $true;
            }
            }
            }
          case "ObservedType": {ESLVal $637 = _v216.termRef(0);
              ESLVal $636 = _v216.termRef(1);
              ESLVal $635 = _v216.termRef(2);
              
              switch($635.termName) {
              case "UnionType": {ESLVal $639 = $635.termRef(0);
                ESLVal $638 = $635.termRef(1);
                
                {ESLVal _v996 = _v215;
                
                {ESLVal l = $637;
                
                {ESLVal state = $636;
                
                {ESLVal ul = $639;
                
                {ESLVal terms = $638;
                
                return typeEqual(_v996,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
              }
              }
              }
              }
              }
              }
              default: {ESLVal _v997 = _v215;
                
                {ESLVal _v998 = _v216;
                
                return $false;
              }
              }
            }
            }
          case "ObserverType": {ESLVal $632 = _v216.termRef(0);
              ESLVal $631 = _v216.termRef(1);
              ESLVal $630 = _v216.termRef(2);
              
              switch($630.termName) {
              case "UnionType": {ESLVal $634 = $630.termRef(0);
                ESLVal $633 = $630.termRef(1);
                
                {ESLVal _v993 = _v215;
                
                {ESLVal l = $632;
                
                {ESLVal state = $631;
                
                {ESLVal ul = $634;
                
                {ESLVal terms = $633;
                
                return typeEqual(_v993,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
              }
              }
              }
              }
              }
              }
              default: {ESLVal _v994 = _v215;
                
                {ESLVal _v995 = _v216;
                
                return $false;
              }
              }
            }
            }
          case "TermType": {ESLVal $629 = _v216.termRef(0);
              ESLVal $628 = _v216.termRef(1);
              ESLVal $627 = _v216.termRef(2);
              
              {ESLVal _v992 = _v215;
              
              {ESLVal l2 = $629;
              
              {ESLVal n2 = $628;
              
              {ESLVal args2 = $627;
              
              return $false;
            }
            }
            }
            }
            }
          case "TypeClosure": {ESLVal $626 = _v216.termRef(0);
              
              {ESLVal _v991 = _v215;
              
              {ESLVal f = $626;
              
              return typeEqual(_v991,f.apply());
            }
            }
            }
          case "RecType": {ESLVal $625 = _v216.termRef(0);
              ESLVal $624 = _v216.termRef(1);
              ESLVal $623 = _v216.termRef(2);
              
              {ESLVal _v989 = _v215;
              
              {ESLVal l2 = $625;
              
              {ESLVal n2 = $624;
              
              {ESLVal _v990 = $623;
              
              return typeEqual(_v989,substType(new ESLVal("RecType",l2,n2,_v990),n2,_v990));
            }
            }
            }
            }
            }
          case "ForallType": {ESLVal $622 = _v216.termRef(0);
              ESLVal $621 = _v216.termRef(1);
              ESLVal $620 = _v216.termRef(2);
              
              {ESLVal _v987 = _v215;
              
              {ESLVal l1 = $622;
              
              {ESLVal ns2 = $621;
              
              {ESLVal _v988 = $620;
              
              return typeEqual(_v987,_v988);
            }
            }
            }
            }
            }
            default: {ESLVal _v1002 = _v215;
              
              {ESLVal _v1003 = _v216;
              
              return $false;
            }
            }
          }
        }
        }
  }
  public static ESLVal typeEqual1 = new ESLVal(new Function(new ESLVal("typeEqual1"),null) { public ESLVal apply(ESLVal... args) { return typeEqual1(args[0],args[1]); }});
  public static ESLVal subType(ESLVal sub,ESLVal parent) {
    
    if(sub.eql(parent).boolVal)
      return $true;
      else
        {ESLVal _v217 = sub;
          ESLVal _v218 = parent;
          
          switch(_v217.termName) {
          case "ActType": {ESLVal $910 = _v217.termRef(0);
            ESLVal $909 = _v217.termRef(1);
            ESLVal $908 = _v217.termRef(2);
            
            switch(_v218.termName) {
            case "ActType": {ESLVal $913 = _v218.termRef(0);
              ESLVal $912 = _v218.termRef(1);
              ESLVal $911 = _v218.termRef(2);
              
              {ESLVal l1 = $910;
              
              {ESLVal exports1 = $909;
              
              {ESLVal handlers1 = $908;
              
              {ESLVal l2 = $913;
              
              {ESLVal exports2 = $912;
              
              {ESLVal handlers2 = $911;
              
              return actSubType(exports1,exports2,handlers1,handlers2);
            }
            }
            }
            }
            }
            }
            }
            default: switch(_v218.termName) {
              case "ApplyTypeFun": {ESLVal $813 = _v218.termRef(0);
                ESLVal $812 = _v218.termRef(1);
                ESLVal $811 = _v218.termRef(2);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l = $813;
                
                {ESLVal op = $812;
                
                {ESLVal args = $811;
                
                return subType(t1,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $810 = _v218.termRef(0);
                ESLVal $809 = _v218.termRef(1);
                ESLVal $808 = _v218.termRef(2);
                ESLVal $807 = _v218.termRef(3);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l2 = $810;
                
                {ESLVal t2 = $809;
                
                {ESLVal ds2 = $808;
                
                {ESLVal ms2 = $807;
                
                return subType(t1,flattenAct(l2,t2,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $806 = _v218.termRef(0);
                
                {ESLVal t1 = _v217;
                
                {ESLVal f = $806;
                
                return subType(t1,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $805 = _v218.termRef(0);
                ESLVal $804 = _v218.termRef(1);
                ESLVal $803 = _v218.termRef(2);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l2 = $805;
                
                {ESLVal n2 = $804;
                
                {ESLVal t2 = $803;
                
                return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $802 = _v218.termRef(0);
                ESLVal $801 = _v218.termRef(1);
                ESLVal $800 = _v218.termRef(2);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l1 = $802;
                
                {ESLVal ns2 = $801;
                
                {ESLVal t2 = $800;
                
                return subType(t1,t2);
              }
              }
              }
              }
              }
            case "ObservedType": {ESLVal $798 = _v218.termRef(0);
                ESLVal $797 = _v218.termRef(1);
                ESLVal $796 = _v218.termRef(2);
                
                switch($796.termName) {
                case "TypeClosure": {ESLVal $799 = $796.termRef(0);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l = $798;
                  
                  {ESLVal state = $797;
                  
                  {ESLVal f = $799;
                  
                  return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v217;
                  
                  {ESLVal l = $798;
                  
                  {ESLVal state = $797;
                  
                  {ESLVal messages = $796;
                  
                  return subType(t1,expandObservedType(l,state,messages));
                }
                }
                }
                }
              }
              }
            case "ObserverType": {ESLVal $794 = _v218.termRef(0);
                ESLVal $793 = _v218.termRef(1);
                ESLVal $792 = _v218.termRef(2);
                
                switch($792.termName) {
                case "TypeClosure": {ESLVal $795 = $792.termRef(0);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l = $794;
                  
                  {ESLVal state = $793;
                  
                  {ESLVal f = $795;
                  
                  return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v217;
                  
                  {ESLVal l = $794;
                  
                  {ESLVal state = $793;
                  
                  {ESLVal messages = $792;
                  
                  return subType(t1,expandObserverType(l,state,messages));
                }
                }
                }
                }
              }
              }
              default: {ESLVal t1 = _v217;
                
                {ESLVal t2 = _v218;
                
                return typeEqual(t1,t2);
              }
              }
            }
          }
          }
        case "ApplyTypeFun": {ESLVal $907 = _v217.termRef(0);
            ESLVal $906 = _v217.termRef(1);
            ESLVal $905 = _v217.termRef(2);
            
            {ESLVal l = $907;
            
            {ESLVal op = $906;
            
            {ESLVal args = $905;
            
            {ESLVal t2 = _v218;
            
            return subType(applyTypeFun(l,forceType(op),args),t2);
          }
          }
          }
          }
          }
        case "ExtendedAct": {ESLVal $904 = _v217.termRef(0);
            ESLVal $903 = _v217.termRef(1);
            ESLVal $902 = _v217.termRef(2);
            ESLVal $901 = _v217.termRef(3);
            
            {ESLVal l1 = $904;
            
            {ESLVal t1 = $903;
            
            {ESLVal ds1 = $902;
            
            {ESLVal ms1 = $901;
            
            {ESLVal t2 = _v218;
            
            return subType(flattenAct(l1,t1,ds1,ms1),t2);
          }
          }
          }
          }
          }
          }
        case "ListType": {ESLVal $887 = _v217.termRef(0);
            ESLVal $886 = _v217.termRef(1);
            
            switch(_v218.termName) {
            case "ListType": {ESLVal $900 = _v218.termRef(0);
              ESLVal $899 = _v218.termRef(1);
              
              {ESLVal l1 = $887;
              
              {ESLVal t1 = $886;
              
              {ESLVal l2 = $900;
              
              {ESLVal t2 = $899;
              
              return subType(t1,t2);
            }
            }
            }
            }
            }
          case "ForallType": {ESLVal $890 = _v218.termRef(0);
              ESLVal $889 = _v218.termRef(1);
              ESLVal $888 = _v218.termRef(2);
              
              if($889.isCons())
              {ESLVal $891 = $889.head();
                ESLVal $892 = $889.tail();
                
                if($892.isCons())
                {ESLVal $893 = $892.head();
                  ESLVal $894 = $892.tail();
                  
                  switch(_v218.termName) {
                  case "ApplyTypeFun": {ESLVal $813 = _v218.termRef(0);
                    ESLVal $812 = _v218.termRef(1);
                    ESLVal $811 = _v218.termRef(2);
                    
                    {ESLVal t1 = _v217;
                    
                    {ESLVal l = $813;
                    
                    {ESLVal op = $812;
                    
                    {ESLVal args = $811;
                    
                    return subType(t1,applyTypeFun(l,forceType(op),args));
                  }
                  }
                  }
                  }
                  }
                case "ExtendedAct": {ESLVal $810 = _v218.termRef(0);
                    ESLVal $809 = _v218.termRef(1);
                    ESLVal $808 = _v218.termRef(2);
                    ESLVal $807 = _v218.termRef(3);
                    
                    {ESLVal t1 = _v217;
                    
                    {ESLVal l2 = $810;
                    
                    {ESLVal t2 = $809;
                    
                    {ESLVal ds2 = $808;
                    
                    {ESLVal ms2 = $807;
                    
                    return subType(t1,flattenAct(l2,t2,ds2,ms2));
                  }
                  }
                  }
                  }
                  }
                  }
                case "TypeClosure": {ESLVal $806 = _v218.termRef(0);
                    
                    {ESLVal t1 = _v217;
                    
                    {ESLVal f = $806;
                    
                    return subType(t1,f.apply());
                  }
                  }
                  }
                case "RecType": {ESLVal $805 = _v218.termRef(0);
                    ESLVal $804 = _v218.termRef(1);
                    ESLVal $803 = _v218.termRef(2);
                    
                    {ESLVal t1 = _v217;
                    
                    {ESLVal l2 = $805;
                    
                    {ESLVal n2 = $804;
                    
                    {ESLVal t2 = $803;
                    
                    return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
                  }
                  }
                  }
                  }
                  }
                case "ForallType": {ESLVal $802 = _v218.termRef(0);
                    ESLVal $801 = _v218.termRef(1);
                    ESLVal $800 = _v218.termRef(2);
                    
                    {ESLVal t1 = _v217;
                    
                    {ESLVal l1 = $802;
                    
                    {ESLVal ns2 = $801;
                    
                    {ESLVal t2 = $800;
                    
                    return subType(t1,t2);
                  }
                  }
                  }
                  }
                  }
                case "ObservedType": {ESLVal $798 = _v218.termRef(0);
                    ESLVal $797 = _v218.termRef(1);
                    ESLVal $796 = _v218.termRef(2);
                    
                    switch($796.termName) {
                    case "TypeClosure": {ESLVal $799 = $796.termRef(0);
                      
                      {ESLVal t1 = _v217;
                      
                      {ESLVal l = $798;
                      
                      {ESLVal state = $797;
                      
                      {ESLVal f = $799;
                      
                      return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal t1 = _v217;
                      
                      {ESLVal l = $798;
                      
                      {ESLVal state = $797;
                      
                      {ESLVal messages = $796;
                      
                      return subType(t1,expandObservedType(l,state,messages));
                    }
                    }
                    }
                    }
                  }
                  }
                case "ObserverType": {ESLVal $794 = _v218.termRef(0);
                    ESLVal $793 = _v218.termRef(1);
                    ESLVal $792 = _v218.termRef(2);
                    
                    switch($792.termName) {
                    case "TypeClosure": {ESLVal $795 = $792.termRef(0);
                      
                      {ESLVal t1 = _v217;
                      
                      {ESLVal l = $794;
                      
                      {ESLVal state = $793;
                      
                      {ESLVal f = $795;
                      
                      return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal t1 = _v217;
                      
                      {ESLVal l = $794;
                      
                      {ESLVal state = $793;
                      
                      {ESLVal messages = $792;
                      
                      return subType(t1,expandObserverType(l,state,messages));
                    }
                    }
                    }
                    }
                  }
                  }
                  default: {ESLVal t1 = _v217;
                    
                    {ESLVal t2 = _v218;
                    
                    return typeEqual(t1,t2);
                  }
                  }
                }
                }
              else if($892.isNil())
                switch($888.termName) {
                  case "ListType": {ESLVal $896 = $888.termRef(0);
                    ESLVal $895 = $888.termRef(1);
                    
                    switch($895.termName) {
                    case "VarType": {ESLVal $898 = $895.termRef(0);
                      ESLVal $897 = $895.termRef(1);
                      
                      {ESLVal l1 = $887;
                      
                      {ESLVal t1 = $886;
                      
                      {ESLVal l2 = $890;
                      
                      {ESLVal v1 = $891;
                      
                      {ESLVal l3 = $896;
                      
                      {ESLVal l4 = $898;
                      
                      {ESLVal v2 = $897;
                      
                      if(v1.eql(v2).boolVal)
                      return $true;
                      else
                        switch(_v218.termName) {
                          case "ApplyTypeFun": {ESLVal $813 = _v218.termRef(0);
                            ESLVal $812 = _v218.termRef(1);
                            ESLVal $811 = _v218.termRef(2);
                            
                            {ESLVal _v369 = _v217;
                            
                            {ESLVal l = $813;
                            
                            {ESLVal op = $812;
                            
                            {ESLVal args = $811;
                            
                            return subType(_v369,applyTypeFun(l,forceType(op),args));
                          }
                          }
                          }
                          }
                          }
                        case "ExtendedAct": {ESLVal $810 = _v218.termRef(0);
                            ESLVal $809 = _v218.termRef(1);
                            ESLVal $808 = _v218.termRef(2);
                            ESLVal $807 = _v218.termRef(3);
                            
                            {ESLVal _v367 = _v217;
                            
                            {ESLVal _v368 = $810;
                            
                            {ESLVal t2 = $809;
                            
                            {ESLVal ds2 = $808;
                            
                            {ESLVal ms2 = $807;
                            
                            return subType(_v367,flattenAct(_v368,t2,ds2,ms2));
                          }
                          }
                          }
                          }
                          }
                          }
                        case "TypeClosure": {ESLVal $806 = _v218.termRef(0);
                            
                            {ESLVal _v366 = _v217;
                            
                            {ESLVal f = $806;
                            
                            return subType(_v366,f.apply());
                          }
                          }
                          }
                        case "RecType": {ESLVal $805 = _v218.termRef(0);
                            ESLVal $804 = _v218.termRef(1);
                            ESLVal $803 = _v218.termRef(2);
                            
                            {ESLVal _v364 = _v217;
                            
                            {ESLVal _v365 = $805;
                            
                            {ESLVal n2 = $804;
                            
                            {ESLVal t2 = $803;
                            
                            return subType(_v364,substType(new ESLVal("RecType",_v365,n2,t2),n2,t2));
                          }
                          }
                          }
                          }
                          }
                        case "ForallType": {ESLVal $802 = _v218.termRef(0);
                            ESLVal $801 = _v218.termRef(1);
                            ESLVal $800 = _v218.termRef(2);
                            
                            {ESLVal _v362 = _v217;
                            
                            {ESLVal _v363 = $802;
                            
                            {ESLVal ns2 = $801;
                            
                            {ESLVal t2 = $800;
                            
                            return subType(_v362,t2);
                          }
                          }
                          }
                          }
                          }
                        case "ObservedType": {ESLVal $798 = _v218.termRef(0);
                            ESLVal $797 = _v218.termRef(1);
                            ESLVal $796 = _v218.termRef(2);
                            
                            switch($796.termName) {
                            case "TypeClosure": {ESLVal $799 = $796.termRef(0);
                              
                              {ESLVal _v360 = _v217;
                              
                              {ESLVal l = $798;
                              
                              {ESLVal state = $797;
                              
                              {ESLVal f = $799;
                              
                              return subType(_v360,new ESLVal("ObservedType",l,state,f.apply()));
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v361 = _v217;
                              
                              {ESLVal l = $798;
                              
                              {ESLVal state = $797;
                              
                              {ESLVal messages = $796;
                              
                              return subType(_v361,expandObservedType(l,state,messages));
                            }
                            }
                            }
                            }
                          }
                          }
                        case "ObserverType": {ESLVal $794 = _v218.termRef(0);
                            ESLVal $793 = _v218.termRef(1);
                            ESLVal $792 = _v218.termRef(2);
                            
                            switch($792.termName) {
                            case "TypeClosure": {ESLVal $795 = $792.termRef(0);
                              
                              {ESLVal _v358 = _v217;
                              
                              {ESLVal l = $794;
                              
                              {ESLVal state = $793;
                              
                              {ESLVal f = $795;
                              
                              return subType(_v358,new ESLVal("ObserverType",l,state,f.apply()));
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v359 = _v217;
                              
                              {ESLVal l = $794;
                              
                              {ESLVal state = $793;
                              
                              {ESLVal messages = $792;
                              
                              return subType(_v359,expandObserverType(l,state,messages));
                            }
                            }
                            }
                            }
                          }
                          }
                          default: {ESLVal _v370 = _v217;
                            
                            {ESLVal t2 = _v218;
                            
                            return typeEqual(_v370,t2);
                          }
                          }
                        }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: switch(_v218.termName) {
                      case "ApplyTypeFun": {ESLVal $813 = _v218.termRef(0);
                        ESLVal $812 = _v218.termRef(1);
                        ESLVal $811 = _v218.termRef(2);
                        
                        {ESLVal t1 = _v217;
                        
                        {ESLVal l = $813;
                        
                        {ESLVal op = $812;
                        
                        {ESLVal args = $811;
                        
                        return subType(t1,applyTypeFun(l,forceType(op),args));
                      }
                      }
                      }
                      }
                      }
                    case "ExtendedAct": {ESLVal $810 = _v218.termRef(0);
                        ESLVal $809 = _v218.termRef(1);
                        ESLVal $808 = _v218.termRef(2);
                        ESLVal $807 = _v218.termRef(3);
                        
                        {ESLVal t1 = _v217;
                        
                        {ESLVal l2 = $810;
                        
                        {ESLVal t2 = $809;
                        
                        {ESLVal ds2 = $808;
                        
                        {ESLVal ms2 = $807;
                        
                        return subType(t1,flattenAct(l2,t2,ds2,ms2));
                      }
                      }
                      }
                      }
                      }
                      }
                    case "TypeClosure": {ESLVal $806 = _v218.termRef(0);
                        
                        {ESLVal t1 = _v217;
                        
                        {ESLVal f = $806;
                        
                        return subType(t1,f.apply());
                      }
                      }
                      }
                    case "RecType": {ESLVal $805 = _v218.termRef(0);
                        ESLVal $804 = _v218.termRef(1);
                        ESLVal $803 = _v218.termRef(2);
                        
                        {ESLVal t1 = _v217;
                        
                        {ESLVal l2 = $805;
                        
                        {ESLVal n2 = $804;
                        
                        {ESLVal t2 = $803;
                        
                        return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
                      }
                      }
                      }
                      }
                      }
                    case "ForallType": {ESLVal $802 = _v218.termRef(0);
                        ESLVal $801 = _v218.termRef(1);
                        ESLVal $800 = _v218.termRef(2);
                        
                        {ESLVal t1 = _v217;
                        
                        {ESLVal l1 = $802;
                        
                        {ESLVal ns2 = $801;
                        
                        {ESLVal t2 = $800;
                        
                        return subType(t1,t2);
                      }
                      }
                      }
                      }
                      }
                    case "ObservedType": {ESLVal $798 = _v218.termRef(0);
                        ESLVal $797 = _v218.termRef(1);
                        ESLVal $796 = _v218.termRef(2);
                        
                        switch($796.termName) {
                        case "TypeClosure": {ESLVal $799 = $796.termRef(0);
                          
                          {ESLVal t1 = _v217;
                          
                          {ESLVal l = $798;
                          
                          {ESLVal state = $797;
                          
                          {ESLVal f = $799;
                          
                          return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal t1 = _v217;
                          
                          {ESLVal l = $798;
                          
                          {ESLVal state = $797;
                          
                          {ESLVal messages = $796;
                          
                          return subType(t1,expandObservedType(l,state,messages));
                        }
                        }
                        }
                        }
                      }
                      }
                    case "ObserverType": {ESLVal $794 = _v218.termRef(0);
                        ESLVal $793 = _v218.termRef(1);
                        ESLVal $792 = _v218.termRef(2);
                        
                        switch($792.termName) {
                        case "TypeClosure": {ESLVal $795 = $792.termRef(0);
                          
                          {ESLVal t1 = _v217;
                          
                          {ESLVal l = $794;
                          
                          {ESLVal state = $793;
                          
                          {ESLVal f = $795;
                          
                          return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal t1 = _v217;
                          
                          {ESLVal l = $794;
                          
                          {ESLVal state = $793;
                          
                          {ESLVal messages = $792;
                          
                          return subType(t1,expandObserverType(l,state,messages));
                        }
                        }
                        }
                        }
                      }
                      }
                      default: {ESLVal t1 = _v217;
                        
                        {ESLVal t2 = _v218;
                        
                        return typeEqual(t1,t2);
                      }
                      }
                    }
                  }
                  }
                  default: switch(_v218.termName) {
                    case "ApplyTypeFun": {ESLVal $813 = _v218.termRef(0);
                      ESLVal $812 = _v218.termRef(1);
                      ESLVal $811 = _v218.termRef(2);
                      
                      {ESLVal t1 = _v217;
                      
                      {ESLVal l = $813;
                      
                      {ESLVal op = $812;
                      
                      {ESLVal args = $811;
                      
                      return subType(t1,applyTypeFun(l,forceType(op),args));
                    }
                    }
                    }
                    }
                    }
                  case "ExtendedAct": {ESLVal $810 = _v218.termRef(0);
                      ESLVal $809 = _v218.termRef(1);
                      ESLVal $808 = _v218.termRef(2);
                      ESLVal $807 = _v218.termRef(3);
                      
                      {ESLVal t1 = _v217;
                      
                      {ESLVal l2 = $810;
                      
                      {ESLVal t2 = $809;
                      
                      {ESLVal ds2 = $808;
                      
                      {ESLVal ms2 = $807;
                      
                      return subType(t1,flattenAct(l2,t2,ds2,ms2));
                    }
                    }
                    }
                    }
                    }
                    }
                  case "TypeClosure": {ESLVal $806 = _v218.termRef(0);
                      
                      {ESLVal t1 = _v217;
                      
                      {ESLVal f = $806;
                      
                      return subType(t1,f.apply());
                    }
                    }
                    }
                  case "RecType": {ESLVal $805 = _v218.termRef(0);
                      ESLVal $804 = _v218.termRef(1);
                      ESLVal $803 = _v218.termRef(2);
                      
                      {ESLVal t1 = _v217;
                      
                      {ESLVal l2 = $805;
                      
                      {ESLVal n2 = $804;
                      
                      {ESLVal t2 = $803;
                      
                      return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
                    }
                    }
                    }
                    }
                    }
                  case "ForallType": {ESLVal $802 = _v218.termRef(0);
                      ESLVal $801 = _v218.termRef(1);
                      ESLVal $800 = _v218.termRef(2);
                      
                      {ESLVal t1 = _v217;
                      
                      {ESLVal l1 = $802;
                      
                      {ESLVal ns2 = $801;
                      
                      {ESLVal t2 = $800;
                      
                      return subType(t1,t2);
                    }
                    }
                    }
                    }
                    }
                  case "ObservedType": {ESLVal $798 = _v218.termRef(0);
                      ESLVal $797 = _v218.termRef(1);
                      ESLVal $796 = _v218.termRef(2);
                      
                      switch($796.termName) {
                      case "TypeClosure": {ESLVal $799 = $796.termRef(0);
                        
                        {ESLVal t1 = _v217;
                        
                        {ESLVal l = $798;
                        
                        {ESLVal state = $797;
                        
                        {ESLVal f = $799;
                        
                        return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal t1 = _v217;
                        
                        {ESLVal l = $798;
                        
                        {ESLVal state = $797;
                        
                        {ESLVal messages = $796;
                        
                        return subType(t1,expandObservedType(l,state,messages));
                      }
                      }
                      }
                      }
                    }
                    }
                  case "ObserverType": {ESLVal $794 = _v218.termRef(0);
                      ESLVal $793 = _v218.termRef(1);
                      ESLVal $792 = _v218.termRef(2);
                      
                      switch($792.termName) {
                      case "TypeClosure": {ESLVal $795 = $792.termRef(0);
                        
                        {ESLVal t1 = _v217;
                        
                        {ESLVal l = $794;
                        
                        {ESLVal state = $793;
                        
                        {ESLVal f = $795;
                        
                        return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal t1 = _v217;
                        
                        {ESLVal l = $794;
                        
                        {ESLVal state = $793;
                        
                        {ESLVal messages = $792;
                        
                        return subType(t1,expandObserverType(l,state,messages));
                      }
                      }
                      }
                      }
                    }
                    }
                    default: {ESLVal t1 = _v217;
                      
                      {ESLVal t2 = _v218;
                      
                      return typeEqual(t1,t2);
                    }
                    }
                  }
                }
              else switch(_v218.termName) {
                  case "ApplyTypeFun": {ESLVal $813 = _v218.termRef(0);
                    ESLVal $812 = _v218.termRef(1);
                    ESLVal $811 = _v218.termRef(2);
                    
                    {ESLVal t1 = _v217;
                    
                    {ESLVal l = $813;
                    
                    {ESLVal op = $812;
                    
                    {ESLVal args = $811;
                    
                    return subType(t1,applyTypeFun(l,forceType(op),args));
                  }
                  }
                  }
                  }
                  }
                case "ExtendedAct": {ESLVal $810 = _v218.termRef(0);
                    ESLVal $809 = _v218.termRef(1);
                    ESLVal $808 = _v218.termRef(2);
                    ESLVal $807 = _v218.termRef(3);
                    
                    {ESLVal t1 = _v217;
                    
                    {ESLVal l2 = $810;
                    
                    {ESLVal t2 = $809;
                    
                    {ESLVal ds2 = $808;
                    
                    {ESLVal ms2 = $807;
                    
                    return subType(t1,flattenAct(l2,t2,ds2,ms2));
                  }
                  }
                  }
                  }
                  }
                  }
                case "TypeClosure": {ESLVal $806 = _v218.termRef(0);
                    
                    {ESLVal t1 = _v217;
                    
                    {ESLVal f = $806;
                    
                    return subType(t1,f.apply());
                  }
                  }
                  }
                case "RecType": {ESLVal $805 = _v218.termRef(0);
                    ESLVal $804 = _v218.termRef(1);
                    ESLVal $803 = _v218.termRef(2);
                    
                    {ESLVal t1 = _v217;
                    
                    {ESLVal l2 = $805;
                    
                    {ESLVal n2 = $804;
                    
                    {ESLVal t2 = $803;
                    
                    return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
                  }
                  }
                  }
                  }
                  }
                case "ForallType": {ESLVal $802 = _v218.termRef(0);
                    ESLVal $801 = _v218.termRef(1);
                    ESLVal $800 = _v218.termRef(2);
                    
                    {ESLVal t1 = _v217;
                    
                    {ESLVal l1 = $802;
                    
                    {ESLVal ns2 = $801;
                    
                    {ESLVal t2 = $800;
                    
                    return subType(t1,t2);
                  }
                  }
                  }
                  }
                  }
                case "ObservedType": {ESLVal $798 = _v218.termRef(0);
                    ESLVal $797 = _v218.termRef(1);
                    ESLVal $796 = _v218.termRef(2);
                    
                    switch($796.termName) {
                    case "TypeClosure": {ESLVal $799 = $796.termRef(0);
                      
                      {ESLVal t1 = _v217;
                      
                      {ESLVal l = $798;
                      
                      {ESLVal state = $797;
                      
                      {ESLVal f = $799;
                      
                      return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal t1 = _v217;
                      
                      {ESLVal l = $798;
                      
                      {ESLVal state = $797;
                      
                      {ESLVal messages = $796;
                      
                      return subType(t1,expandObservedType(l,state,messages));
                    }
                    }
                    }
                    }
                  }
                  }
                case "ObserverType": {ESLVal $794 = _v218.termRef(0);
                    ESLVal $793 = _v218.termRef(1);
                    ESLVal $792 = _v218.termRef(2);
                    
                    switch($792.termName) {
                    case "TypeClosure": {ESLVal $795 = $792.termRef(0);
                      
                      {ESLVal t1 = _v217;
                      
                      {ESLVal l = $794;
                      
                      {ESLVal state = $793;
                      
                      {ESLVal f = $795;
                      
                      return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal t1 = _v217;
                      
                      {ESLVal l = $794;
                      
                      {ESLVal state = $793;
                      
                      {ESLVal messages = $792;
                      
                      return subType(t1,expandObserverType(l,state,messages));
                    }
                    }
                    }
                    }
                  }
                  }
                  default: {ESLVal t1 = _v217;
                    
                    {ESLVal t2 = _v218;
                    
                    return typeEqual(t1,t2);
                  }
                  }
                }
              }
            else if($889.isNil())
              switch(_v218.termName) {
                case "ApplyTypeFun": {ESLVal $813 = _v218.termRef(0);
                  ESLVal $812 = _v218.termRef(1);
                  ESLVal $811 = _v218.termRef(2);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l = $813;
                  
                  {ESLVal op = $812;
                  
                  {ESLVal args = $811;
                  
                  return subType(t1,applyTypeFun(l,forceType(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $810 = _v218.termRef(0);
                  ESLVal $809 = _v218.termRef(1);
                  ESLVal $808 = _v218.termRef(2);
                  ESLVal $807 = _v218.termRef(3);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l2 = $810;
                  
                  {ESLVal t2 = $809;
                  
                  {ESLVal ds2 = $808;
                  
                  {ESLVal ms2 = $807;
                  
                  return subType(t1,flattenAct(l2,t2,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $806 = _v218.termRef(0);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal f = $806;
                  
                  return subType(t1,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $805 = _v218.termRef(0);
                  ESLVal $804 = _v218.termRef(1);
                  ESLVal $803 = _v218.termRef(2);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l2 = $805;
                  
                  {ESLVal n2 = $804;
                  
                  {ESLVal t2 = $803;
                  
                  return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $802 = _v218.termRef(0);
                  ESLVal $801 = _v218.termRef(1);
                  ESLVal $800 = _v218.termRef(2);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l1 = $802;
                  
                  {ESLVal ns2 = $801;
                  
                  {ESLVal t2 = $800;
                  
                  return subType(t1,t2);
                }
                }
                }
                }
                }
              case "ObservedType": {ESLVal $798 = _v218.termRef(0);
                  ESLVal $797 = _v218.termRef(1);
                  ESLVal $796 = _v218.termRef(2);
                  
                  switch($796.termName) {
                  case "TypeClosure": {ESLVal $799 = $796.termRef(0);
                    
                    {ESLVal t1 = _v217;
                    
                    {ESLVal l = $798;
                    
                    {ESLVal state = $797;
                    
                    {ESLVal f = $799;
                    
                    return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal t1 = _v217;
                    
                    {ESLVal l = $798;
                    
                    {ESLVal state = $797;
                    
                    {ESLVal messages = $796;
                    
                    return subType(t1,expandObservedType(l,state,messages));
                  }
                  }
                  }
                  }
                }
                }
              case "ObserverType": {ESLVal $794 = _v218.termRef(0);
                  ESLVal $793 = _v218.termRef(1);
                  ESLVal $792 = _v218.termRef(2);
                  
                  switch($792.termName) {
                  case "TypeClosure": {ESLVal $795 = $792.termRef(0);
                    
                    {ESLVal t1 = _v217;
                    
                    {ESLVal l = $794;
                    
                    {ESLVal state = $793;
                    
                    {ESLVal f = $795;
                    
                    return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal t1 = _v217;
                    
                    {ESLVal l = $794;
                    
                    {ESLVal state = $793;
                    
                    {ESLVal messages = $792;
                    
                    return subType(t1,expandObserverType(l,state,messages));
                  }
                  }
                  }
                  }
                }
                }
                default: {ESLVal t1 = _v217;
                  
                  {ESLVal t2 = _v218;
                  
                  return typeEqual(t1,t2);
                }
                }
              }
            else switch(_v218.termName) {
                case "ApplyTypeFun": {ESLVal $813 = _v218.termRef(0);
                  ESLVal $812 = _v218.termRef(1);
                  ESLVal $811 = _v218.termRef(2);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l = $813;
                  
                  {ESLVal op = $812;
                  
                  {ESLVal args = $811;
                  
                  return subType(t1,applyTypeFun(l,forceType(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $810 = _v218.termRef(0);
                  ESLVal $809 = _v218.termRef(1);
                  ESLVal $808 = _v218.termRef(2);
                  ESLVal $807 = _v218.termRef(3);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l2 = $810;
                  
                  {ESLVal t2 = $809;
                  
                  {ESLVal ds2 = $808;
                  
                  {ESLVal ms2 = $807;
                  
                  return subType(t1,flattenAct(l2,t2,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $806 = _v218.termRef(0);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal f = $806;
                  
                  return subType(t1,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $805 = _v218.termRef(0);
                  ESLVal $804 = _v218.termRef(1);
                  ESLVal $803 = _v218.termRef(2);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l2 = $805;
                  
                  {ESLVal n2 = $804;
                  
                  {ESLVal t2 = $803;
                  
                  return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $802 = _v218.termRef(0);
                  ESLVal $801 = _v218.termRef(1);
                  ESLVal $800 = _v218.termRef(2);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l1 = $802;
                  
                  {ESLVal ns2 = $801;
                  
                  {ESLVal t2 = $800;
                  
                  return subType(t1,t2);
                }
                }
                }
                }
                }
              case "ObservedType": {ESLVal $798 = _v218.termRef(0);
                  ESLVal $797 = _v218.termRef(1);
                  ESLVal $796 = _v218.termRef(2);
                  
                  switch($796.termName) {
                  case "TypeClosure": {ESLVal $799 = $796.termRef(0);
                    
                    {ESLVal t1 = _v217;
                    
                    {ESLVal l = $798;
                    
                    {ESLVal state = $797;
                    
                    {ESLVal f = $799;
                    
                    return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal t1 = _v217;
                    
                    {ESLVal l = $798;
                    
                    {ESLVal state = $797;
                    
                    {ESLVal messages = $796;
                    
                    return subType(t1,expandObservedType(l,state,messages));
                  }
                  }
                  }
                  }
                }
                }
              case "ObserverType": {ESLVal $794 = _v218.termRef(0);
                  ESLVal $793 = _v218.termRef(1);
                  ESLVal $792 = _v218.termRef(2);
                  
                  switch($792.termName) {
                  case "TypeClosure": {ESLVal $795 = $792.termRef(0);
                    
                    {ESLVal t1 = _v217;
                    
                    {ESLVal l = $794;
                    
                    {ESLVal state = $793;
                    
                    {ESLVal f = $795;
                    
                    return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal t1 = _v217;
                    
                    {ESLVal l = $794;
                    
                    {ESLVal state = $793;
                    
                    {ESLVal messages = $792;
                    
                    return subType(t1,expandObserverType(l,state,messages));
                  }
                  }
                  }
                  }
                }
                }
                default: {ESLVal t1 = _v217;
                  
                  {ESLVal t2 = _v218;
                  
                  return typeEqual(t1,t2);
                }
                }
              }
            }
            default: switch(_v218.termName) {
              case "ApplyTypeFun": {ESLVal $813 = _v218.termRef(0);
                ESLVal $812 = _v218.termRef(1);
                ESLVal $811 = _v218.termRef(2);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l = $813;
                
                {ESLVal op = $812;
                
                {ESLVal args = $811;
                
                return subType(t1,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $810 = _v218.termRef(0);
                ESLVal $809 = _v218.termRef(1);
                ESLVal $808 = _v218.termRef(2);
                ESLVal $807 = _v218.termRef(3);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l2 = $810;
                
                {ESLVal t2 = $809;
                
                {ESLVal ds2 = $808;
                
                {ESLVal ms2 = $807;
                
                return subType(t1,flattenAct(l2,t2,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $806 = _v218.termRef(0);
                
                {ESLVal t1 = _v217;
                
                {ESLVal f = $806;
                
                return subType(t1,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $805 = _v218.termRef(0);
                ESLVal $804 = _v218.termRef(1);
                ESLVal $803 = _v218.termRef(2);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l2 = $805;
                
                {ESLVal n2 = $804;
                
                {ESLVal t2 = $803;
                
                return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $802 = _v218.termRef(0);
                ESLVal $801 = _v218.termRef(1);
                ESLVal $800 = _v218.termRef(2);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l1 = $802;
                
                {ESLVal ns2 = $801;
                
                {ESLVal t2 = $800;
                
                return subType(t1,t2);
              }
              }
              }
              }
              }
            case "ObservedType": {ESLVal $798 = _v218.termRef(0);
                ESLVal $797 = _v218.termRef(1);
                ESLVal $796 = _v218.termRef(2);
                
                switch($796.termName) {
                case "TypeClosure": {ESLVal $799 = $796.termRef(0);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l = $798;
                  
                  {ESLVal state = $797;
                  
                  {ESLVal f = $799;
                  
                  return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v217;
                  
                  {ESLVal l = $798;
                  
                  {ESLVal state = $797;
                  
                  {ESLVal messages = $796;
                  
                  return subType(t1,expandObservedType(l,state,messages));
                }
                }
                }
                }
              }
              }
            case "ObserverType": {ESLVal $794 = _v218.termRef(0);
                ESLVal $793 = _v218.termRef(1);
                ESLVal $792 = _v218.termRef(2);
                
                switch($792.termName) {
                case "TypeClosure": {ESLVal $795 = $792.termRef(0);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l = $794;
                  
                  {ESLVal state = $793;
                  
                  {ESLVal f = $795;
                  
                  return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v217;
                  
                  {ESLVal l = $794;
                  
                  {ESLVal state = $793;
                  
                  {ESLVal messages = $792;
                  
                  return subType(t1,expandObserverType(l,state,messages));
                }
                }
                }
                }
              }
              }
              default: {ESLVal t1 = _v217;
                
                {ESLVal t2 = _v218;
                
                return typeEqual(t1,t2);
              }
              }
            }
          }
          }
        case "BagType": {ESLVal $883 = _v217.termRef(0);
            ESLVal $882 = _v217.termRef(1);
            
            switch(_v218.termName) {
            case "BagType": {ESLVal $885 = _v218.termRef(0);
              ESLVal $884 = _v218.termRef(1);
              
              {ESLVal l1 = $883;
              
              {ESLVal t1 = $882;
              
              {ESLVal l2 = $885;
              
              {ESLVal t2 = $884;
              
              return subType(t1,t2);
            }
            }
            }
            }
            }
            default: switch(_v218.termName) {
              case "ApplyTypeFun": {ESLVal $813 = _v218.termRef(0);
                ESLVal $812 = _v218.termRef(1);
                ESLVal $811 = _v218.termRef(2);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l = $813;
                
                {ESLVal op = $812;
                
                {ESLVal args = $811;
                
                return subType(t1,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $810 = _v218.termRef(0);
                ESLVal $809 = _v218.termRef(1);
                ESLVal $808 = _v218.termRef(2);
                ESLVal $807 = _v218.termRef(3);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l2 = $810;
                
                {ESLVal t2 = $809;
                
                {ESLVal ds2 = $808;
                
                {ESLVal ms2 = $807;
                
                return subType(t1,flattenAct(l2,t2,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $806 = _v218.termRef(0);
                
                {ESLVal t1 = _v217;
                
                {ESLVal f = $806;
                
                return subType(t1,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $805 = _v218.termRef(0);
                ESLVal $804 = _v218.termRef(1);
                ESLVal $803 = _v218.termRef(2);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l2 = $805;
                
                {ESLVal n2 = $804;
                
                {ESLVal t2 = $803;
                
                return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $802 = _v218.termRef(0);
                ESLVal $801 = _v218.termRef(1);
                ESLVal $800 = _v218.termRef(2);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l1 = $802;
                
                {ESLVal ns2 = $801;
                
                {ESLVal t2 = $800;
                
                return subType(t1,t2);
              }
              }
              }
              }
              }
            case "ObservedType": {ESLVal $798 = _v218.termRef(0);
                ESLVal $797 = _v218.termRef(1);
                ESLVal $796 = _v218.termRef(2);
                
                switch($796.termName) {
                case "TypeClosure": {ESLVal $799 = $796.termRef(0);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l = $798;
                  
                  {ESLVal state = $797;
                  
                  {ESLVal f = $799;
                  
                  return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v217;
                  
                  {ESLVal l = $798;
                  
                  {ESLVal state = $797;
                  
                  {ESLVal messages = $796;
                  
                  return subType(t1,expandObservedType(l,state,messages));
                }
                }
                }
                }
              }
              }
            case "ObserverType": {ESLVal $794 = _v218.termRef(0);
                ESLVal $793 = _v218.termRef(1);
                ESLVal $792 = _v218.termRef(2);
                
                switch($792.termName) {
                case "TypeClosure": {ESLVal $795 = $792.termRef(0);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l = $794;
                  
                  {ESLVal state = $793;
                  
                  {ESLVal f = $795;
                  
                  return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v217;
                  
                  {ESLVal l = $794;
                  
                  {ESLVal state = $793;
                  
                  {ESLVal messages = $792;
                  
                  return subType(t1,expandObserverType(l,state,messages));
                }
                }
                }
                }
              }
              }
              default: {ESLVal t1 = _v217;
                
                {ESLVal t2 = _v218;
                
                return typeEqual(t1,t2);
              }
              }
            }
          }
          }
        case "SetType": {ESLVal $868 = _v217.termRef(0);
            ESLVal $867 = _v217.termRef(1);
            
            switch(_v218.termName) {
            case "SetType": {ESLVal $881 = _v218.termRef(0);
              ESLVal $880 = _v218.termRef(1);
              
              {ESLVal l1 = $868;
              
              {ESLVal t1 = $867;
              
              {ESLVal l2 = $881;
              
              {ESLVal t2 = $880;
              
              return subType(t1,t2);
            }
            }
            }
            }
            }
          case "ForallType": {ESLVal $871 = _v218.termRef(0);
              ESLVal $870 = _v218.termRef(1);
              ESLVal $869 = _v218.termRef(2);
              
              if($870.isCons())
              {ESLVal $872 = $870.head();
                ESLVal $873 = $870.tail();
                
                if($873.isCons())
                {ESLVal $874 = $873.head();
                  ESLVal $875 = $873.tail();
                  
                  switch(_v218.termName) {
                  case "ApplyTypeFun": {ESLVal $813 = _v218.termRef(0);
                    ESLVal $812 = _v218.termRef(1);
                    ESLVal $811 = _v218.termRef(2);
                    
                    {ESLVal t1 = _v217;
                    
                    {ESLVal l = $813;
                    
                    {ESLVal op = $812;
                    
                    {ESLVal args = $811;
                    
                    return subType(t1,applyTypeFun(l,forceType(op),args));
                  }
                  }
                  }
                  }
                  }
                case "ExtendedAct": {ESLVal $810 = _v218.termRef(0);
                    ESLVal $809 = _v218.termRef(1);
                    ESLVal $808 = _v218.termRef(2);
                    ESLVal $807 = _v218.termRef(3);
                    
                    {ESLVal t1 = _v217;
                    
                    {ESLVal l2 = $810;
                    
                    {ESLVal t2 = $809;
                    
                    {ESLVal ds2 = $808;
                    
                    {ESLVal ms2 = $807;
                    
                    return subType(t1,flattenAct(l2,t2,ds2,ms2));
                  }
                  }
                  }
                  }
                  }
                  }
                case "TypeClosure": {ESLVal $806 = _v218.termRef(0);
                    
                    {ESLVal t1 = _v217;
                    
                    {ESLVal f = $806;
                    
                    return subType(t1,f.apply());
                  }
                  }
                  }
                case "RecType": {ESLVal $805 = _v218.termRef(0);
                    ESLVal $804 = _v218.termRef(1);
                    ESLVal $803 = _v218.termRef(2);
                    
                    {ESLVal t1 = _v217;
                    
                    {ESLVal l2 = $805;
                    
                    {ESLVal n2 = $804;
                    
                    {ESLVal t2 = $803;
                    
                    return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
                  }
                  }
                  }
                  }
                  }
                case "ForallType": {ESLVal $802 = _v218.termRef(0);
                    ESLVal $801 = _v218.termRef(1);
                    ESLVal $800 = _v218.termRef(2);
                    
                    {ESLVal t1 = _v217;
                    
                    {ESLVal l1 = $802;
                    
                    {ESLVal ns2 = $801;
                    
                    {ESLVal t2 = $800;
                    
                    return subType(t1,t2);
                  }
                  }
                  }
                  }
                  }
                case "ObservedType": {ESLVal $798 = _v218.termRef(0);
                    ESLVal $797 = _v218.termRef(1);
                    ESLVal $796 = _v218.termRef(2);
                    
                    switch($796.termName) {
                    case "TypeClosure": {ESLVal $799 = $796.termRef(0);
                      
                      {ESLVal t1 = _v217;
                      
                      {ESLVal l = $798;
                      
                      {ESLVal state = $797;
                      
                      {ESLVal f = $799;
                      
                      return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal t1 = _v217;
                      
                      {ESLVal l = $798;
                      
                      {ESLVal state = $797;
                      
                      {ESLVal messages = $796;
                      
                      return subType(t1,expandObservedType(l,state,messages));
                    }
                    }
                    }
                    }
                  }
                  }
                case "ObserverType": {ESLVal $794 = _v218.termRef(0);
                    ESLVal $793 = _v218.termRef(1);
                    ESLVal $792 = _v218.termRef(2);
                    
                    switch($792.termName) {
                    case "TypeClosure": {ESLVal $795 = $792.termRef(0);
                      
                      {ESLVal t1 = _v217;
                      
                      {ESLVal l = $794;
                      
                      {ESLVal state = $793;
                      
                      {ESLVal f = $795;
                      
                      return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal t1 = _v217;
                      
                      {ESLVal l = $794;
                      
                      {ESLVal state = $793;
                      
                      {ESLVal messages = $792;
                      
                      return subType(t1,expandObserverType(l,state,messages));
                    }
                    }
                    }
                    }
                  }
                  }
                  default: {ESLVal t1 = _v217;
                    
                    {ESLVal t2 = _v218;
                    
                    return typeEqual(t1,t2);
                  }
                  }
                }
                }
              else if($873.isNil())
                switch($869.termName) {
                  case "SetType": {ESLVal $877 = $869.termRef(0);
                    ESLVal $876 = $869.termRef(1);
                    
                    switch($876.termName) {
                    case "VarType": {ESLVal $879 = $876.termRef(0);
                      ESLVal $878 = $876.termRef(1);
                      
                      {ESLVal l1 = $868;
                      
                      {ESLVal t1 = $867;
                      
                      {ESLVal l2 = $871;
                      
                      {ESLVal v1 = $872;
                      
                      {ESLVal l3 = $877;
                      
                      {ESLVal l4 = $879;
                      
                      {ESLVal v2 = $878;
                      
                      if(v1.eql(v2).boolVal)
                      return $true;
                      else
                        switch(_v218.termName) {
                          case "ApplyTypeFun": {ESLVal $813 = _v218.termRef(0);
                            ESLVal $812 = _v218.termRef(1);
                            ESLVal $811 = _v218.termRef(2);
                            
                            {ESLVal _v356 = _v217;
                            
                            {ESLVal l = $813;
                            
                            {ESLVal op = $812;
                            
                            {ESLVal args = $811;
                            
                            return subType(_v356,applyTypeFun(l,forceType(op),args));
                          }
                          }
                          }
                          }
                          }
                        case "ExtendedAct": {ESLVal $810 = _v218.termRef(0);
                            ESLVal $809 = _v218.termRef(1);
                            ESLVal $808 = _v218.termRef(2);
                            ESLVal $807 = _v218.termRef(3);
                            
                            {ESLVal _v354 = _v217;
                            
                            {ESLVal _v355 = $810;
                            
                            {ESLVal t2 = $809;
                            
                            {ESLVal ds2 = $808;
                            
                            {ESLVal ms2 = $807;
                            
                            return subType(_v354,flattenAct(_v355,t2,ds2,ms2));
                          }
                          }
                          }
                          }
                          }
                          }
                        case "TypeClosure": {ESLVal $806 = _v218.termRef(0);
                            
                            {ESLVal _v353 = _v217;
                            
                            {ESLVal f = $806;
                            
                            return subType(_v353,f.apply());
                          }
                          }
                          }
                        case "RecType": {ESLVal $805 = _v218.termRef(0);
                            ESLVal $804 = _v218.termRef(1);
                            ESLVal $803 = _v218.termRef(2);
                            
                            {ESLVal _v351 = _v217;
                            
                            {ESLVal _v352 = $805;
                            
                            {ESLVal n2 = $804;
                            
                            {ESLVal t2 = $803;
                            
                            return subType(_v351,substType(new ESLVal("RecType",_v352,n2,t2),n2,t2));
                          }
                          }
                          }
                          }
                          }
                        case "ForallType": {ESLVal $802 = _v218.termRef(0);
                            ESLVal $801 = _v218.termRef(1);
                            ESLVal $800 = _v218.termRef(2);
                            
                            {ESLVal _v349 = _v217;
                            
                            {ESLVal _v350 = $802;
                            
                            {ESLVal ns2 = $801;
                            
                            {ESLVal t2 = $800;
                            
                            return subType(_v349,t2);
                          }
                          }
                          }
                          }
                          }
                        case "ObservedType": {ESLVal $798 = _v218.termRef(0);
                            ESLVal $797 = _v218.termRef(1);
                            ESLVal $796 = _v218.termRef(2);
                            
                            switch($796.termName) {
                            case "TypeClosure": {ESLVal $799 = $796.termRef(0);
                              
                              {ESLVal _v347 = _v217;
                              
                              {ESLVal l = $798;
                              
                              {ESLVal state = $797;
                              
                              {ESLVal f = $799;
                              
                              return subType(_v347,new ESLVal("ObservedType",l,state,f.apply()));
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v348 = _v217;
                              
                              {ESLVal l = $798;
                              
                              {ESLVal state = $797;
                              
                              {ESLVal messages = $796;
                              
                              return subType(_v348,expandObservedType(l,state,messages));
                            }
                            }
                            }
                            }
                          }
                          }
                        case "ObserverType": {ESLVal $794 = _v218.termRef(0);
                            ESLVal $793 = _v218.termRef(1);
                            ESLVal $792 = _v218.termRef(2);
                            
                            switch($792.termName) {
                            case "TypeClosure": {ESLVal $795 = $792.termRef(0);
                              
                              {ESLVal _v345 = _v217;
                              
                              {ESLVal l = $794;
                              
                              {ESLVal state = $793;
                              
                              {ESLVal f = $795;
                              
                              return subType(_v345,new ESLVal("ObserverType",l,state,f.apply()));
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v346 = _v217;
                              
                              {ESLVal l = $794;
                              
                              {ESLVal state = $793;
                              
                              {ESLVal messages = $792;
                              
                              return subType(_v346,expandObserverType(l,state,messages));
                            }
                            }
                            }
                            }
                          }
                          }
                          default: {ESLVal _v357 = _v217;
                            
                            {ESLVal t2 = _v218;
                            
                            return typeEqual(_v357,t2);
                          }
                          }
                        }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: switch(_v218.termName) {
                      case "ApplyTypeFun": {ESLVal $813 = _v218.termRef(0);
                        ESLVal $812 = _v218.termRef(1);
                        ESLVal $811 = _v218.termRef(2);
                        
                        {ESLVal t1 = _v217;
                        
                        {ESLVal l = $813;
                        
                        {ESLVal op = $812;
                        
                        {ESLVal args = $811;
                        
                        return subType(t1,applyTypeFun(l,forceType(op),args));
                      }
                      }
                      }
                      }
                      }
                    case "ExtendedAct": {ESLVal $810 = _v218.termRef(0);
                        ESLVal $809 = _v218.termRef(1);
                        ESLVal $808 = _v218.termRef(2);
                        ESLVal $807 = _v218.termRef(3);
                        
                        {ESLVal t1 = _v217;
                        
                        {ESLVal l2 = $810;
                        
                        {ESLVal t2 = $809;
                        
                        {ESLVal ds2 = $808;
                        
                        {ESLVal ms2 = $807;
                        
                        return subType(t1,flattenAct(l2,t2,ds2,ms2));
                      }
                      }
                      }
                      }
                      }
                      }
                    case "TypeClosure": {ESLVal $806 = _v218.termRef(0);
                        
                        {ESLVal t1 = _v217;
                        
                        {ESLVal f = $806;
                        
                        return subType(t1,f.apply());
                      }
                      }
                      }
                    case "RecType": {ESLVal $805 = _v218.termRef(0);
                        ESLVal $804 = _v218.termRef(1);
                        ESLVal $803 = _v218.termRef(2);
                        
                        {ESLVal t1 = _v217;
                        
                        {ESLVal l2 = $805;
                        
                        {ESLVal n2 = $804;
                        
                        {ESLVal t2 = $803;
                        
                        return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
                      }
                      }
                      }
                      }
                      }
                    case "ForallType": {ESLVal $802 = _v218.termRef(0);
                        ESLVal $801 = _v218.termRef(1);
                        ESLVal $800 = _v218.termRef(2);
                        
                        {ESLVal t1 = _v217;
                        
                        {ESLVal l1 = $802;
                        
                        {ESLVal ns2 = $801;
                        
                        {ESLVal t2 = $800;
                        
                        return subType(t1,t2);
                      }
                      }
                      }
                      }
                      }
                    case "ObservedType": {ESLVal $798 = _v218.termRef(0);
                        ESLVal $797 = _v218.termRef(1);
                        ESLVal $796 = _v218.termRef(2);
                        
                        switch($796.termName) {
                        case "TypeClosure": {ESLVal $799 = $796.termRef(0);
                          
                          {ESLVal t1 = _v217;
                          
                          {ESLVal l = $798;
                          
                          {ESLVal state = $797;
                          
                          {ESLVal f = $799;
                          
                          return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal t1 = _v217;
                          
                          {ESLVal l = $798;
                          
                          {ESLVal state = $797;
                          
                          {ESLVal messages = $796;
                          
                          return subType(t1,expandObservedType(l,state,messages));
                        }
                        }
                        }
                        }
                      }
                      }
                    case "ObserverType": {ESLVal $794 = _v218.termRef(0);
                        ESLVal $793 = _v218.termRef(1);
                        ESLVal $792 = _v218.termRef(2);
                        
                        switch($792.termName) {
                        case "TypeClosure": {ESLVal $795 = $792.termRef(0);
                          
                          {ESLVal t1 = _v217;
                          
                          {ESLVal l = $794;
                          
                          {ESLVal state = $793;
                          
                          {ESLVal f = $795;
                          
                          return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal t1 = _v217;
                          
                          {ESLVal l = $794;
                          
                          {ESLVal state = $793;
                          
                          {ESLVal messages = $792;
                          
                          return subType(t1,expandObserverType(l,state,messages));
                        }
                        }
                        }
                        }
                      }
                      }
                      default: {ESLVal t1 = _v217;
                        
                        {ESLVal t2 = _v218;
                        
                        return typeEqual(t1,t2);
                      }
                      }
                    }
                  }
                  }
                  default: switch(_v218.termName) {
                    case "ApplyTypeFun": {ESLVal $813 = _v218.termRef(0);
                      ESLVal $812 = _v218.termRef(1);
                      ESLVal $811 = _v218.termRef(2);
                      
                      {ESLVal t1 = _v217;
                      
                      {ESLVal l = $813;
                      
                      {ESLVal op = $812;
                      
                      {ESLVal args = $811;
                      
                      return subType(t1,applyTypeFun(l,forceType(op),args));
                    }
                    }
                    }
                    }
                    }
                  case "ExtendedAct": {ESLVal $810 = _v218.termRef(0);
                      ESLVal $809 = _v218.termRef(1);
                      ESLVal $808 = _v218.termRef(2);
                      ESLVal $807 = _v218.termRef(3);
                      
                      {ESLVal t1 = _v217;
                      
                      {ESLVal l2 = $810;
                      
                      {ESLVal t2 = $809;
                      
                      {ESLVal ds2 = $808;
                      
                      {ESLVal ms2 = $807;
                      
                      return subType(t1,flattenAct(l2,t2,ds2,ms2));
                    }
                    }
                    }
                    }
                    }
                    }
                  case "TypeClosure": {ESLVal $806 = _v218.termRef(0);
                      
                      {ESLVal t1 = _v217;
                      
                      {ESLVal f = $806;
                      
                      return subType(t1,f.apply());
                    }
                    }
                    }
                  case "RecType": {ESLVal $805 = _v218.termRef(0);
                      ESLVal $804 = _v218.termRef(1);
                      ESLVal $803 = _v218.termRef(2);
                      
                      {ESLVal t1 = _v217;
                      
                      {ESLVal l2 = $805;
                      
                      {ESLVal n2 = $804;
                      
                      {ESLVal t2 = $803;
                      
                      return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
                    }
                    }
                    }
                    }
                    }
                  case "ForallType": {ESLVal $802 = _v218.termRef(0);
                      ESLVal $801 = _v218.termRef(1);
                      ESLVal $800 = _v218.termRef(2);
                      
                      {ESLVal t1 = _v217;
                      
                      {ESLVal l1 = $802;
                      
                      {ESLVal ns2 = $801;
                      
                      {ESLVal t2 = $800;
                      
                      return subType(t1,t2);
                    }
                    }
                    }
                    }
                    }
                  case "ObservedType": {ESLVal $798 = _v218.termRef(0);
                      ESLVal $797 = _v218.termRef(1);
                      ESLVal $796 = _v218.termRef(2);
                      
                      switch($796.termName) {
                      case "TypeClosure": {ESLVal $799 = $796.termRef(0);
                        
                        {ESLVal t1 = _v217;
                        
                        {ESLVal l = $798;
                        
                        {ESLVal state = $797;
                        
                        {ESLVal f = $799;
                        
                        return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal t1 = _v217;
                        
                        {ESLVal l = $798;
                        
                        {ESLVal state = $797;
                        
                        {ESLVal messages = $796;
                        
                        return subType(t1,expandObservedType(l,state,messages));
                      }
                      }
                      }
                      }
                    }
                    }
                  case "ObserverType": {ESLVal $794 = _v218.termRef(0);
                      ESLVal $793 = _v218.termRef(1);
                      ESLVal $792 = _v218.termRef(2);
                      
                      switch($792.termName) {
                      case "TypeClosure": {ESLVal $795 = $792.termRef(0);
                        
                        {ESLVal t1 = _v217;
                        
                        {ESLVal l = $794;
                        
                        {ESLVal state = $793;
                        
                        {ESLVal f = $795;
                        
                        return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal t1 = _v217;
                        
                        {ESLVal l = $794;
                        
                        {ESLVal state = $793;
                        
                        {ESLVal messages = $792;
                        
                        return subType(t1,expandObserverType(l,state,messages));
                      }
                      }
                      }
                      }
                    }
                    }
                    default: {ESLVal t1 = _v217;
                      
                      {ESLVal t2 = _v218;
                      
                      return typeEqual(t1,t2);
                    }
                    }
                  }
                }
              else switch(_v218.termName) {
                  case "ApplyTypeFun": {ESLVal $813 = _v218.termRef(0);
                    ESLVal $812 = _v218.termRef(1);
                    ESLVal $811 = _v218.termRef(2);
                    
                    {ESLVal t1 = _v217;
                    
                    {ESLVal l = $813;
                    
                    {ESLVal op = $812;
                    
                    {ESLVal args = $811;
                    
                    return subType(t1,applyTypeFun(l,forceType(op),args));
                  }
                  }
                  }
                  }
                  }
                case "ExtendedAct": {ESLVal $810 = _v218.termRef(0);
                    ESLVal $809 = _v218.termRef(1);
                    ESLVal $808 = _v218.termRef(2);
                    ESLVal $807 = _v218.termRef(3);
                    
                    {ESLVal t1 = _v217;
                    
                    {ESLVal l2 = $810;
                    
                    {ESLVal t2 = $809;
                    
                    {ESLVal ds2 = $808;
                    
                    {ESLVal ms2 = $807;
                    
                    return subType(t1,flattenAct(l2,t2,ds2,ms2));
                  }
                  }
                  }
                  }
                  }
                  }
                case "TypeClosure": {ESLVal $806 = _v218.termRef(0);
                    
                    {ESLVal t1 = _v217;
                    
                    {ESLVal f = $806;
                    
                    return subType(t1,f.apply());
                  }
                  }
                  }
                case "RecType": {ESLVal $805 = _v218.termRef(0);
                    ESLVal $804 = _v218.termRef(1);
                    ESLVal $803 = _v218.termRef(2);
                    
                    {ESLVal t1 = _v217;
                    
                    {ESLVal l2 = $805;
                    
                    {ESLVal n2 = $804;
                    
                    {ESLVal t2 = $803;
                    
                    return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
                  }
                  }
                  }
                  }
                  }
                case "ForallType": {ESLVal $802 = _v218.termRef(0);
                    ESLVal $801 = _v218.termRef(1);
                    ESLVal $800 = _v218.termRef(2);
                    
                    {ESLVal t1 = _v217;
                    
                    {ESLVal l1 = $802;
                    
                    {ESLVal ns2 = $801;
                    
                    {ESLVal t2 = $800;
                    
                    return subType(t1,t2);
                  }
                  }
                  }
                  }
                  }
                case "ObservedType": {ESLVal $798 = _v218.termRef(0);
                    ESLVal $797 = _v218.termRef(1);
                    ESLVal $796 = _v218.termRef(2);
                    
                    switch($796.termName) {
                    case "TypeClosure": {ESLVal $799 = $796.termRef(0);
                      
                      {ESLVal t1 = _v217;
                      
                      {ESLVal l = $798;
                      
                      {ESLVal state = $797;
                      
                      {ESLVal f = $799;
                      
                      return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal t1 = _v217;
                      
                      {ESLVal l = $798;
                      
                      {ESLVal state = $797;
                      
                      {ESLVal messages = $796;
                      
                      return subType(t1,expandObservedType(l,state,messages));
                    }
                    }
                    }
                    }
                  }
                  }
                case "ObserverType": {ESLVal $794 = _v218.termRef(0);
                    ESLVal $793 = _v218.termRef(1);
                    ESLVal $792 = _v218.termRef(2);
                    
                    switch($792.termName) {
                    case "TypeClosure": {ESLVal $795 = $792.termRef(0);
                      
                      {ESLVal t1 = _v217;
                      
                      {ESLVal l = $794;
                      
                      {ESLVal state = $793;
                      
                      {ESLVal f = $795;
                      
                      return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal t1 = _v217;
                      
                      {ESLVal l = $794;
                      
                      {ESLVal state = $793;
                      
                      {ESLVal messages = $792;
                      
                      return subType(t1,expandObserverType(l,state,messages));
                    }
                    }
                    }
                    }
                  }
                  }
                  default: {ESLVal t1 = _v217;
                    
                    {ESLVal t2 = _v218;
                    
                    return typeEqual(t1,t2);
                  }
                  }
                }
              }
            else if($870.isNil())
              switch(_v218.termName) {
                case "ApplyTypeFun": {ESLVal $813 = _v218.termRef(0);
                  ESLVal $812 = _v218.termRef(1);
                  ESLVal $811 = _v218.termRef(2);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l = $813;
                  
                  {ESLVal op = $812;
                  
                  {ESLVal args = $811;
                  
                  return subType(t1,applyTypeFun(l,forceType(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $810 = _v218.termRef(0);
                  ESLVal $809 = _v218.termRef(1);
                  ESLVal $808 = _v218.termRef(2);
                  ESLVal $807 = _v218.termRef(3);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l2 = $810;
                  
                  {ESLVal t2 = $809;
                  
                  {ESLVal ds2 = $808;
                  
                  {ESLVal ms2 = $807;
                  
                  return subType(t1,flattenAct(l2,t2,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $806 = _v218.termRef(0);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal f = $806;
                  
                  return subType(t1,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $805 = _v218.termRef(0);
                  ESLVal $804 = _v218.termRef(1);
                  ESLVal $803 = _v218.termRef(2);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l2 = $805;
                  
                  {ESLVal n2 = $804;
                  
                  {ESLVal t2 = $803;
                  
                  return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $802 = _v218.termRef(0);
                  ESLVal $801 = _v218.termRef(1);
                  ESLVal $800 = _v218.termRef(2);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l1 = $802;
                  
                  {ESLVal ns2 = $801;
                  
                  {ESLVal t2 = $800;
                  
                  return subType(t1,t2);
                }
                }
                }
                }
                }
              case "ObservedType": {ESLVal $798 = _v218.termRef(0);
                  ESLVal $797 = _v218.termRef(1);
                  ESLVal $796 = _v218.termRef(2);
                  
                  switch($796.termName) {
                  case "TypeClosure": {ESLVal $799 = $796.termRef(0);
                    
                    {ESLVal t1 = _v217;
                    
                    {ESLVal l = $798;
                    
                    {ESLVal state = $797;
                    
                    {ESLVal f = $799;
                    
                    return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal t1 = _v217;
                    
                    {ESLVal l = $798;
                    
                    {ESLVal state = $797;
                    
                    {ESLVal messages = $796;
                    
                    return subType(t1,expandObservedType(l,state,messages));
                  }
                  }
                  }
                  }
                }
                }
              case "ObserverType": {ESLVal $794 = _v218.termRef(0);
                  ESLVal $793 = _v218.termRef(1);
                  ESLVal $792 = _v218.termRef(2);
                  
                  switch($792.termName) {
                  case "TypeClosure": {ESLVal $795 = $792.termRef(0);
                    
                    {ESLVal t1 = _v217;
                    
                    {ESLVal l = $794;
                    
                    {ESLVal state = $793;
                    
                    {ESLVal f = $795;
                    
                    return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal t1 = _v217;
                    
                    {ESLVal l = $794;
                    
                    {ESLVal state = $793;
                    
                    {ESLVal messages = $792;
                    
                    return subType(t1,expandObserverType(l,state,messages));
                  }
                  }
                  }
                  }
                }
                }
                default: {ESLVal t1 = _v217;
                  
                  {ESLVal t2 = _v218;
                  
                  return typeEqual(t1,t2);
                }
                }
              }
            else switch(_v218.termName) {
                case "ApplyTypeFun": {ESLVal $813 = _v218.termRef(0);
                  ESLVal $812 = _v218.termRef(1);
                  ESLVal $811 = _v218.termRef(2);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l = $813;
                  
                  {ESLVal op = $812;
                  
                  {ESLVal args = $811;
                  
                  return subType(t1,applyTypeFun(l,forceType(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $810 = _v218.termRef(0);
                  ESLVal $809 = _v218.termRef(1);
                  ESLVal $808 = _v218.termRef(2);
                  ESLVal $807 = _v218.termRef(3);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l2 = $810;
                  
                  {ESLVal t2 = $809;
                  
                  {ESLVal ds2 = $808;
                  
                  {ESLVal ms2 = $807;
                  
                  return subType(t1,flattenAct(l2,t2,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $806 = _v218.termRef(0);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal f = $806;
                  
                  return subType(t1,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $805 = _v218.termRef(0);
                  ESLVal $804 = _v218.termRef(1);
                  ESLVal $803 = _v218.termRef(2);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l2 = $805;
                  
                  {ESLVal n2 = $804;
                  
                  {ESLVal t2 = $803;
                  
                  return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $802 = _v218.termRef(0);
                  ESLVal $801 = _v218.termRef(1);
                  ESLVal $800 = _v218.termRef(2);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l1 = $802;
                  
                  {ESLVal ns2 = $801;
                  
                  {ESLVal t2 = $800;
                  
                  return subType(t1,t2);
                }
                }
                }
                }
                }
              case "ObservedType": {ESLVal $798 = _v218.termRef(0);
                  ESLVal $797 = _v218.termRef(1);
                  ESLVal $796 = _v218.termRef(2);
                  
                  switch($796.termName) {
                  case "TypeClosure": {ESLVal $799 = $796.termRef(0);
                    
                    {ESLVal t1 = _v217;
                    
                    {ESLVal l = $798;
                    
                    {ESLVal state = $797;
                    
                    {ESLVal f = $799;
                    
                    return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal t1 = _v217;
                    
                    {ESLVal l = $798;
                    
                    {ESLVal state = $797;
                    
                    {ESLVal messages = $796;
                    
                    return subType(t1,expandObservedType(l,state,messages));
                  }
                  }
                  }
                  }
                }
                }
              case "ObserverType": {ESLVal $794 = _v218.termRef(0);
                  ESLVal $793 = _v218.termRef(1);
                  ESLVal $792 = _v218.termRef(2);
                  
                  switch($792.termName) {
                  case "TypeClosure": {ESLVal $795 = $792.termRef(0);
                    
                    {ESLVal t1 = _v217;
                    
                    {ESLVal l = $794;
                    
                    {ESLVal state = $793;
                    
                    {ESLVal f = $795;
                    
                    return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal t1 = _v217;
                    
                    {ESLVal l = $794;
                    
                    {ESLVal state = $793;
                    
                    {ESLVal messages = $792;
                    
                    return subType(t1,expandObserverType(l,state,messages));
                  }
                  }
                  }
                  }
                }
                }
                default: {ESLVal t1 = _v217;
                  
                  {ESLVal t2 = _v218;
                  
                  return typeEqual(t1,t2);
                }
                }
              }
            }
            default: switch(_v218.termName) {
              case "ApplyTypeFun": {ESLVal $813 = _v218.termRef(0);
                ESLVal $812 = _v218.termRef(1);
                ESLVal $811 = _v218.termRef(2);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l = $813;
                
                {ESLVal op = $812;
                
                {ESLVal args = $811;
                
                return subType(t1,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $810 = _v218.termRef(0);
                ESLVal $809 = _v218.termRef(1);
                ESLVal $808 = _v218.termRef(2);
                ESLVal $807 = _v218.termRef(3);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l2 = $810;
                
                {ESLVal t2 = $809;
                
                {ESLVal ds2 = $808;
                
                {ESLVal ms2 = $807;
                
                return subType(t1,flattenAct(l2,t2,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $806 = _v218.termRef(0);
                
                {ESLVal t1 = _v217;
                
                {ESLVal f = $806;
                
                return subType(t1,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $805 = _v218.termRef(0);
                ESLVal $804 = _v218.termRef(1);
                ESLVal $803 = _v218.termRef(2);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l2 = $805;
                
                {ESLVal n2 = $804;
                
                {ESLVal t2 = $803;
                
                return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $802 = _v218.termRef(0);
                ESLVal $801 = _v218.termRef(1);
                ESLVal $800 = _v218.termRef(2);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l1 = $802;
                
                {ESLVal ns2 = $801;
                
                {ESLVal t2 = $800;
                
                return subType(t1,t2);
              }
              }
              }
              }
              }
            case "ObservedType": {ESLVal $798 = _v218.termRef(0);
                ESLVal $797 = _v218.termRef(1);
                ESLVal $796 = _v218.termRef(2);
                
                switch($796.termName) {
                case "TypeClosure": {ESLVal $799 = $796.termRef(0);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l = $798;
                  
                  {ESLVal state = $797;
                  
                  {ESLVal f = $799;
                  
                  return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v217;
                  
                  {ESLVal l = $798;
                  
                  {ESLVal state = $797;
                  
                  {ESLVal messages = $796;
                  
                  return subType(t1,expandObservedType(l,state,messages));
                }
                }
                }
                }
              }
              }
            case "ObserverType": {ESLVal $794 = _v218.termRef(0);
                ESLVal $793 = _v218.termRef(1);
                ESLVal $792 = _v218.termRef(2);
                
                switch($792.termName) {
                case "TypeClosure": {ESLVal $795 = $792.termRef(0);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l = $794;
                  
                  {ESLVal state = $793;
                  
                  {ESLVal f = $795;
                  
                  return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v217;
                  
                  {ESLVal l = $794;
                  
                  {ESLVal state = $793;
                  
                  {ESLVal messages = $792;
                  
                  return subType(t1,expandObserverType(l,state,messages));
                }
                }
                }
                }
              }
              }
              default: {ESLVal t1 = _v217;
                
                {ESLVal t2 = _v218;
                
                return typeEqual(t1,t2);
              }
              }
            }
          }
          }
        case "TermType": {ESLVal $863 = _v217.termRef(0);
            ESLVal $862 = _v217.termRef(1);
            ESLVal $861 = _v217.termRef(2);
            
            switch(_v218.termName) {
            case "TermType": {ESLVal $866 = _v218.termRef(0);
              ESLVal $865 = _v218.termRef(1);
              ESLVal $864 = _v218.termRef(2);
              
              {ESLVal l1 = $863;
              
              {ESLVal n1 = $862;
              
              {ESLVal args1 = $861;
              
              {ESLVal l2 = $866;
              
              {ESLVal n2 = $865;
              
              {ESLVal args2 = $864;
              
              if(n1.eql(n2).boolVal)
              return subTypes(args1,args2);
              else
                return $false;
            }
            }
            }
            }
            }
            }
            }
            default: switch(_v218.termName) {
              case "ApplyTypeFun": {ESLVal $813 = _v218.termRef(0);
                ESLVal $812 = _v218.termRef(1);
                ESLVal $811 = _v218.termRef(2);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l = $813;
                
                {ESLVal op = $812;
                
                {ESLVal args = $811;
                
                return subType(t1,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $810 = _v218.termRef(0);
                ESLVal $809 = _v218.termRef(1);
                ESLVal $808 = _v218.termRef(2);
                ESLVal $807 = _v218.termRef(3);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l2 = $810;
                
                {ESLVal t2 = $809;
                
                {ESLVal ds2 = $808;
                
                {ESLVal ms2 = $807;
                
                return subType(t1,flattenAct(l2,t2,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $806 = _v218.termRef(0);
                
                {ESLVal t1 = _v217;
                
                {ESLVal f = $806;
                
                return subType(t1,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $805 = _v218.termRef(0);
                ESLVal $804 = _v218.termRef(1);
                ESLVal $803 = _v218.termRef(2);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l2 = $805;
                
                {ESLVal n2 = $804;
                
                {ESLVal t2 = $803;
                
                return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $802 = _v218.termRef(0);
                ESLVal $801 = _v218.termRef(1);
                ESLVal $800 = _v218.termRef(2);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l1 = $802;
                
                {ESLVal ns2 = $801;
                
                {ESLVal t2 = $800;
                
                return subType(t1,t2);
              }
              }
              }
              }
              }
            case "ObservedType": {ESLVal $798 = _v218.termRef(0);
                ESLVal $797 = _v218.termRef(1);
                ESLVal $796 = _v218.termRef(2);
                
                switch($796.termName) {
                case "TypeClosure": {ESLVal $799 = $796.termRef(0);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l = $798;
                  
                  {ESLVal state = $797;
                  
                  {ESLVal f = $799;
                  
                  return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v217;
                  
                  {ESLVal l = $798;
                  
                  {ESLVal state = $797;
                  
                  {ESLVal messages = $796;
                  
                  return subType(t1,expandObservedType(l,state,messages));
                }
                }
                }
                }
              }
              }
            case "ObserverType": {ESLVal $794 = _v218.termRef(0);
                ESLVal $793 = _v218.termRef(1);
                ESLVal $792 = _v218.termRef(2);
                
                switch($792.termName) {
                case "TypeClosure": {ESLVal $795 = $792.termRef(0);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l = $794;
                  
                  {ESLVal state = $793;
                  
                  {ESLVal f = $795;
                  
                  return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v217;
                  
                  {ESLVal l = $794;
                  
                  {ESLVal state = $793;
                  
                  {ESLVal messages = $792;
                  
                  return subType(t1,expandObserverType(l,state,messages));
                }
                }
                }
                }
              }
              }
              default: {ESLVal t1 = _v217;
                
                {ESLVal t2 = _v218;
                
                return typeEqual(t1,t2);
              }
              }
            }
          }
          }
        case "FunType": {ESLVal $857 = _v217.termRef(0);
            ESLVal $856 = _v217.termRef(1);
            ESLVal $855 = _v217.termRef(2);
            
            switch(_v218.termName) {
            case "FunType": {ESLVal $860 = _v218.termRef(0);
              ESLVal $859 = _v218.termRef(1);
              ESLVal $858 = _v218.termRef(2);
              
              {ESLVal l1 = $857;
              
              {ESLVal d1 = $856;
              
              {ESLVal r1 = $855;
              
              {ESLVal l2 = $860;
              
              {ESLVal d2 = $859;
              
              {ESLVal r2 = $858;
              
              return subType(r1,r2).and(subTypes(d2,d1));
            }
            }
            }
            }
            }
            }
            }
            default: switch(_v218.termName) {
              case "ApplyTypeFun": {ESLVal $813 = _v218.termRef(0);
                ESLVal $812 = _v218.termRef(1);
                ESLVal $811 = _v218.termRef(2);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l = $813;
                
                {ESLVal op = $812;
                
                {ESLVal args = $811;
                
                return subType(t1,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $810 = _v218.termRef(0);
                ESLVal $809 = _v218.termRef(1);
                ESLVal $808 = _v218.termRef(2);
                ESLVal $807 = _v218.termRef(3);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l2 = $810;
                
                {ESLVal t2 = $809;
                
                {ESLVal ds2 = $808;
                
                {ESLVal ms2 = $807;
                
                return subType(t1,flattenAct(l2,t2,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $806 = _v218.termRef(0);
                
                {ESLVal t1 = _v217;
                
                {ESLVal f = $806;
                
                return subType(t1,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $805 = _v218.termRef(0);
                ESLVal $804 = _v218.termRef(1);
                ESLVal $803 = _v218.termRef(2);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l2 = $805;
                
                {ESLVal n2 = $804;
                
                {ESLVal t2 = $803;
                
                return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $802 = _v218.termRef(0);
                ESLVal $801 = _v218.termRef(1);
                ESLVal $800 = _v218.termRef(2);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l1 = $802;
                
                {ESLVal ns2 = $801;
                
                {ESLVal t2 = $800;
                
                return subType(t1,t2);
              }
              }
              }
              }
              }
            case "ObservedType": {ESLVal $798 = _v218.termRef(0);
                ESLVal $797 = _v218.termRef(1);
                ESLVal $796 = _v218.termRef(2);
                
                switch($796.termName) {
                case "TypeClosure": {ESLVal $799 = $796.termRef(0);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l = $798;
                  
                  {ESLVal state = $797;
                  
                  {ESLVal f = $799;
                  
                  return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v217;
                  
                  {ESLVal l = $798;
                  
                  {ESLVal state = $797;
                  
                  {ESLVal messages = $796;
                  
                  return subType(t1,expandObservedType(l,state,messages));
                }
                }
                }
                }
              }
              }
            case "ObserverType": {ESLVal $794 = _v218.termRef(0);
                ESLVal $793 = _v218.termRef(1);
                ESLVal $792 = _v218.termRef(2);
                
                switch($792.termName) {
                case "TypeClosure": {ESLVal $795 = $792.termRef(0);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l = $794;
                  
                  {ESLVal state = $793;
                  
                  {ESLVal f = $795;
                  
                  return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v217;
                  
                  {ESLVal l = $794;
                  
                  {ESLVal state = $793;
                  
                  {ESLVal messages = $792;
                  
                  return subType(t1,expandObserverType(l,state,messages));
                }
                }
                }
                }
              }
              }
              default: {ESLVal t1 = _v217;
                
                {ESLVal t2 = _v218;
                
                return typeEqual(t1,t2);
              }
              }
            }
          }
          }
        case "TypeClosure": {ESLVal $854 = _v217.termRef(0);
            
            {ESLVal f = $854;
            
            {ESLVal t2 = _v218;
            
            return subType(f.apply(),t2);
          }
          }
          }
        case "RecordType": {ESLVal $851 = _v217.termRef(0);
            ESLVal $850 = _v217.termRef(1);
            
            switch(_v218.termName) {
            case "RecordType": {ESLVal $853 = _v218.termRef(0);
              ESLVal $852 = _v218.termRef(1);
              
              {ESLVal l1 = $851;
              
              {ESLVal fs1 = $850;
              
              {ESLVal l2 = $853;
              
              {ESLVal fs2 = $852;
              
              return recordSubType(fs1,fs2);
            }
            }
            }
            }
            }
            default: switch(_v218.termName) {
              case "ApplyTypeFun": {ESLVal $813 = _v218.termRef(0);
                ESLVal $812 = _v218.termRef(1);
                ESLVal $811 = _v218.termRef(2);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l = $813;
                
                {ESLVal op = $812;
                
                {ESLVal args = $811;
                
                return subType(t1,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $810 = _v218.termRef(0);
                ESLVal $809 = _v218.termRef(1);
                ESLVal $808 = _v218.termRef(2);
                ESLVal $807 = _v218.termRef(3);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l2 = $810;
                
                {ESLVal t2 = $809;
                
                {ESLVal ds2 = $808;
                
                {ESLVal ms2 = $807;
                
                return subType(t1,flattenAct(l2,t2,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $806 = _v218.termRef(0);
                
                {ESLVal t1 = _v217;
                
                {ESLVal f = $806;
                
                return subType(t1,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $805 = _v218.termRef(0);
                ESLVal $804 = _v218.termRef(1);
                ESLVal $803 = _v218.termRef(2);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l2 = $805;
                
                {ESLVal n2 = $804;
                
                {ESLVal t2 = $803;
                
                return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $802 = _v218.termRef(0);
                ESLVal $801 = _v218.termRef(1);
                ESLVal $800 = _v218.termRef(2);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l1 = $802;
                
                {ESLVal ns2 = $801;
                
                {ESLVal t2 = $800;
                
                return subType(t1,t2);
              }
              }
              }
              }
              }
            case "ObservedType": {ESLVal $798 = _v218.termRef(0);
                ESLVal $797 = _v218.termRef(1);
                ESLVal $796 = _v218.termRef(2);
                
                switch($796.termName) {
                case "TypeClosure": {ESLVal $799 = $796.termRef(0);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l = $798;
                  
                  {ESLVal state = $797;
                  
                  {ESLVal f = $799;
                  
                  return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v217;
                  
                  {ESLVal l = $798;
                  
                  {ESLVal state = $797;
                  
                  {ESLVal messages = $796;
                  
                  return subType(t1,expandObservedType(l,state,messages));
                }
                }
                }
                }
              }
              }
            case "ObserverType": {ESLVal $794 = _v218.termRef(0);
                ESLVal $793 = _v218.termRef(1);
                ESLVal $792 = _v218.termRef(2);
                
                switch($792.termName) {
                case "TypeClosure": {ESLVal $795 = $792.termRef(0);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l = $794;
                  
                  {ESLVal state = $793;
                  
                  {ESLVal f = $795;
                  
                  return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v217;
                  
                  {ESLVal l = $794;
                  
                  {ESLVal state = $793;
                  
                  {ESLVal messages = $792;
                  
                  return subType(t1,expandObserverType(l,state,messages));
                }
                }
                }
                }
              }
              }
              default: {ESLVal t1 = _v217;
                
                {ESLVal t2 = _v218;
                
                return typeEqual(t1,t2);
              }
              }
            }
          }
          }
        case "RecType": {ESLVal $846 = _v217.termRef(0);
            ESLVal $845 = _v217.termRef(1);
            ESLVal $844 = _v217.termRef(2);
            
            switch(_v218.termName) {
            case "RecType": {ESLVal $849 = _v218.termRef(0);
              ESLVal $848 = _v218.termRef(1);
              ESLVal $847 = _v218.termRef(2);
              
              {ESLVal l1 = $846;
              
              {ESLVal n1 = $845;
              
              {ESLVal t1 = $844;
              
              {ESLVal l2 = $849;
              
              {ESLVal n2 = $848;
              
              {ESLVal t2 = $847;
              
              if(n1.eql(n2).boolVal)
              return subType(t1,t2);
              else
                {ESLVal _v341 = $846;
                  
                  {ESLVal _v342 = $845;
                  
                  {ESLVal _v343 = $844;
                  
                  {ESLVal _v344 = _v218;
                  
                  return subType(substType(new ESLVal("RecType",_v341,_v342,_v343),_v342,_v343),_v344);
                }
                }
                }
                }
            }
            }
            }
            }
            }
            }
            }
            default: {ESLVal l1 = $846;
              
              {ESLVal n1 = $845;
              
              {ESLVal t1 = $844;
              
              {ESLVal t2 = _v218;
              
              return subType(substType(new ESLVal("RecType",l1,n1,t1),n1,t1),t2);
            }
            }
            }
            }
          }
          }
        case "UnionType": {ESLVal $841 = _v217.termRef(0);
            ESLVal $840 = _v217.termRef(1);
            
            switch(_v218.termName) {
            case "UnionType": {ESLVal $843 = _v218.termRef(0);
              ESLVal $842 = _v218.termRef(1);
              
              {ESLVal l1 = $841;
              
              {ESLVal terms1 = $840;
              
              {ESLVal l2 = $843;
              
              {ESLVal terms2 = $842;
              
              return subTypes(terms1,terms2);
            }
            }
            }
            }
            }
            default: switch(_v218.termName) {
              case "ApplyTypeFun": {ESLVal $813 = _v218.termRef(0);
                ESLVal $812 = _v218.termRef(1);
                ESLVal $811 = _v218.termRef(2);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l = $813;
                
                {ESLVal op = $812;
                
                {ESLVal args = $811;
                
                return subType(t1,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $810 = _v218.termRef(0);
                ESLVal $809 = _v218.termRef(1);
                ESLVal $808 = _v218.termRef(2);
                ESLVal $807 = _v218.termRef(3);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l2 = $810;
                
                {ESLVal t2 = $809;
                
                {ESLVal ds2 = $808;
                
                {ESLVal ms2 = $807;
                
                return subType(t1,flattenAct(l2,t2,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $806 = _v218.termRef(0);
                
                {ESLVal t1 = _v217;
                
                {ESLVal f = $806;
                
                return subType(t1,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $805 = _v218.termRef(0);
                ESLVal $804 = _v218.termRef(1);
                ESLVal $803 = _v218.termRef(2);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l2 = $805;
                
                {ESLVal n2 = $804;
                
                {ESLVal t2 = $803;
                
                return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $802 = _v218.termRef(0);
                ESLVal $801 = _v218.termRef(1);
                ESLVal $800 = _v218.termRef(2);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l1 = $802;
                
                {ESLVal ns2 = $801;
                
                {ESLVal t2 = $800;
                
                return subType(t1,t2);
              }
              }
              }
              }
              }
            case "ObservedType": {ESLVal $798 = _v218.termRef(0);
                ESLVal $797 = _v218.termRef(1);
                ESLVal $796 = _v218.termRef(2);
                
                switch($796.termName) {
                case "TypeClosure": {ESLVal $799 = $796.termRef(0);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l = $798;
                  
                  {ESLVal state = $797;
                  
                  {ESLVal f = $799;
                  
                  return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v217;
                  
                  {ESLVal l = $798;
                  
                  {ESLVal state = $797;
                  
                  {ESLVal messages = $796;
                  
                  return subType(t1,expandObservedType(l,state,messages));
                }
                }
                }
                }
              }
              }
            case "ObserverType": {ESLVal $794 = _v218.termRef(0);
                ESLVal $793 = _v218.termRef(1);
                ESLVal $792 = _v218.termRef(2);
                
                switch($792.termName) {
                case "TypeClosure": {ESLVal $795 = $792.termRef(0);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l = $794;
                  
                  {ESLVal state = $793;
                  
                  {ESLVal f = $795;
                  
                  return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v217;
                  
                  {ESLVal l = $794;
                  
                  {ESLVal state = $793;
                  
                  {ESLVal messages = $792;
                  
                  return subType(t1,expandObserverType(l,state,messages));
                }
                }
                }
                }
              }
              }
              default: {ESLVal t1 = _v217;
                
                {ESLVal t2 = _v218;
                
                return typeEqual(t1,t2);
              }
              }
            }
          }
          }
        case "VarType": {ESLVal $837 = _v217.termRef(0);
            ESLVal $836 = _v217.termRef(1);
            
            switch(_v218.termName) {
            case "VarType": {ESLVal $839 = _v218.termRef(0);
              ESLVal $838 = _v218.termRef(1);
              
              {ESLVal l1 = $837;
              
              {ESLVal n1 = $836;
              
              {ESLVal l2 = $839;
              
              {ESLVal n2 = $838;
              
              return n1.eql(n2);
            }
            }
            }
            }
            }
            default: switch(_v218.termName) {
              case "ApplyTypeFun": {ESLVal $813 = _v218.termRef(0);
                ESLVal $812 = _v218.termRef(1);
                ESLVal $811 = _v218.termRef(2);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l = $813;
                
                {ESLVal op = $812;
                
                {ESLVal args = $811;
                
                return subType(t1,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $810 = _v218.termRef(0);
                ESLVal $809 = _v218.termRef(1);
                ESLVal $808 = _v218.termRef(2);
                ESLVal $807 = _v218.termRef(3);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l2 = $810;
                
                {ESLVal t2 = $809;
                
                {ESLVal ds2 = $808;
                
                {ESLVal ms2 = $807;
                
                return subType(t1,flattenAct(l2,t2,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $806 = _v218.termRef(0);
                
                {ESLVal t1 = _v217;
                
                {ESLVal f = $806;
                
                return subType(t1,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $805 = _v218.termRef(0);
                ESLVal $804 = _v218.termRef(1);
                ESLVal $803 = _v218.termRef(2);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l2 = $805;
                
                {ESLVal n2 = $804;
                
                {ESLVal t2 = $803;
                
                return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $802 = _v218.termRef(0);
                ESLVal $801 = _v218.termRef(1);
                ESLVal $800 = _v218.termRef(2);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l1 = $802;
                
                {ESLVal ns2 = $801;
                
                {ESLVal t2 = $800;
                
                return subType(t1,t2);
              }
              }
              }
              }
              }
            case "ObservedType": {ESLVal $798 = _v218.termRef(0);
                ESLVal $797 = _v218.termRef(1);
                ESLVal $796 = _v218.termRef(2);
                
                switch($796.termName) {
                case "TypeClosure": {ESLVal $799 = $796.termRef(0);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l = $798;
                  
                  {ESLVal state = $797;
                  
                  {ESLVal f = $799;
                  
                  return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v217;
                  
                  {ESLVal l = $798;
                  
                  {ESLVal state = $797;
                  
                  {ESLVal messages = $796;
                  
                  return subType(t1,expandObservedType(l,state,messages));
                }
                }
                }
                }
              }
              }
            case "ObserverType": {ESLVal $794 = _v218.termRef(0);
                ESLVal $793 = _v218.termRef(1);
                ESLVal $792 = _v218.termRef(2);
                
                switch($792.termName) {
                case "TypeClosure": {ESLVal $795 = $792.termRef(0);
                  
                  {ESLVal t1 = _v217;
                  
                  {ESLVal l = $794;
                  
                  {ESLVal state = $793;
                  
                  {ESLVal f = $795;
                  
                  return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v217;
                  
                  {ESLVal l = $794;
                  
                  {ESLVal state = $793;
                  
                  {ESLVal messages = $792;
                  
                  return subType(t1,expandObserverType(l,state,messages));
                }
                }
                }
                }
              }
              }
              default: {ESLVal t1 = _v217;
                
                {ESLVal t2 = _v218;
                
                return typeEqual(t1,t2);
              }
              }
            }
          }
          }
        case "ForallType": {ESLVal $816 = _v217.termRef(0);
            ESLVal $815 = _v217.termRef(1);
            ESLVal $814 = _v217.termRef(2);
            
            if($815.isCons())
            {ESLVal $820 = $815.head();
              ESLVal $821 = $815.tail();
              
              if($821.isCons())
              {ESLVal $822 = $821.head();
                ESLVal $823 = $821.tail();
                
                switch(_v218.termName) {
                case "ForallType": {ESLVal $819 = _v218.termRef(0);
                  ESLVal $818 = _v218.termRef(1);
                  ESLVal $817 = _v218.termRef(2);
                  
                  {ESLVal l1 = $816;
                  
                  {ESLVal ns1 = $815;
                  
                  {ESLVal t1 = $814;
                  
                  {ESLVal l2 = $819;
                  
                  {ESLVal ns2 = $818;
                  
                  {ESLVal t2 = $817;
                  
                  return ns1.eql(ns2).and(subType(t1,t2));
                }
                }
                }
                }
                }
                }
                }
                default: {ESLVal l1 = $816;
                  
                  {ESLVal ns1 = $815;
                  
                  {ESLVal t1 = $814;
                  
                  {ESLVal t2 = _v218;
                  
                  return subType(t1,t2);
                }
                }
                }
                }
              }
              }
            else if($821.isNil())
              switch($814.termName) {
                case "ListType": {ESLVal $831 = $814.termRef(0);
                  ESLVal $830 = $814.termRef(1);
                  
                  switch($830.termName) {
                  case "VarType": {ESLVal $833 = $830.termRef(0);
                    ESLVal $832 = $830.termRef(1);
                    
                    switch(_v218.termName) {
                    case "ListType": {ESLVal $835 = _v218.termRef(0);
                      ESLVal $834 = _v218.termRef(1);
                      
                      {ESLVal l2 = $816;
                      
                      {ESLVal v1 = $820;
                      
                      {ESLVal l3 = $831;
                      
                      {ESLVal l4 = $833;
                      
                      {ESLVal v2 = $832;
                      
                      {ESLVal l1 = $835;
                      
                      {ESLVal t1 = $834;
                      
                      if(v1.eql(v2).boolVal)
                      return $true;
                      else
                        switch(_v218.termName) {
                          case "ForallType": {ESLVal $819 = _v218.termRef(0);
                            ESLVal $818 = _v218.termRef(1);
                            ESLVal $817 = _v218.termRef(2);
                            
                            {ESLVal _v336 = $816;
                            
                            {ESLVal ns1 = $815;
                            
                            {ESLVal _v337 = $814;
                            
                            {ESLVal _v338 = $819;
                            
                            {ESLVal ns2 = $818;
                            
                            {ESLVal t2 = $817;
                            
                            return ns1.eql(ns2).and(subType(_v337,t2));
                          }
                          }
                          }
                          }
                          }
                          }
                          }
                          default: {ESLVal _v339 = $816;
                            
                            {ESLVal ns1 = $815;
                            
                            {ESLVal _v340 = $814;
                            
                            {ESLVal t2 = _v218;
                            
                            return subType(_v340,t2);
                          }
                          }
                          }
                          }
                        }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: switch(_v218.termName) {
                      case "ForallType": {ESLVal $819 = _v218.termRef(0);
                        ESLVal $818 = _v218.termRef(1);
                        ESLVal $817 = _v218.termRef(2);
                        
                        {ESLVal l1 = $816;
                        
                        {ESLVal ns1 = $815;
                        
                        {ESLVal t1 = $814;
                        
                        {ESLVal l2 = $819;
                        
                        {ESLVal ns2 = $818;
                        
                        {ESLVal t2 = $817;
                        
                        return ns1.eql(ns2).and(subType(t1,t2));
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal l1 = $816;
                        
                        {ESLVal ns1 = $815;
                        
                        {ESLVal t1 = $814;
                        
                        {ESLVal t2 = _v218;
                        
                        return subType(t1,t2);
                      }
                      }
                      }
                      }
                    }
                  }
                  }
                  default: switch(_v218.termName) {
                    case "ForallType": {ESLVal $819 = _v218.termRef(0);
                      ESLVal $818 = _v218.termRef(1);
                      ESLVal $817 = _v218.termRef(2);
                      
                      {ESLVal l1 = $816;
                      
                      {ESLVal ns1 = $815;
                      
                      {ESLVal t1 = $814;
                      
                      {ESLVal l2 = $819;
                      
                      {ESLVal ns2 = $818;
                      
                      {ESLVal t2 = $817;
                      
                      return ns1.eql(ns2).and(subType(t1,t2));
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal l1 = $816;
                      
                      {ESLVal ns1 = $815;
                      
                      {ESLVal t1 = $814;
                      
                      {ESLVal t2 = _v218;
                      
                      return subType(t1,t2);
                    }
                    }
                    }
                    }
                  }
                }
                }
              case "SetType": {ESLVal $825 = $814.termRef(0);
                  ESLVal $824 = $814.termRef(1);
                  
                  switch($824.termName) {
                  case "VarType": {ESLVal $827 = $824.termRef(0);
                    ESLVal $826 = $824.termRef(1);
                    
                    switch(_v218.termName) {
                    case "SetType": {ESLVal $829 = _v218.termRef(0);
                      ESLVal $828 = _v218.termRef(1);
                      
                      {ESLVal l2 = $816;
                      
                      {ESLVal v1 = $820;
                      
                      {ESLVal l3 = $825;
                      
                      {ESLVal l4 = $827;
                      
                      {ESLVal v2 = $826;
                      
                      {ESLVal l1 = $829;
                      
                      {ESLVal t1 = $828;
                      
                      if(v1.eql(v2).boolVal)
                      return $true;
                      else
                        switch(_v218.termName) {
                          case "ForallType": {ESLVal $819 = _v218.termRef(0);
                            ESLVal $818 = _v218.termRef(1);
                            ESLVal $817 = _v218.termRef(2);
                            
                            {ESLVal _v331 = $816;
                            
                            {ESLVal ns1 = $815;
                            
                            {ESLVal _v332 = $814;
                            
                            {ESLVal _v333 = $819;
                            
                            {ESLVal ns2 = $818;
                            
                            {ESLVal t2 = $817;
                            
                            return ns1.eql(ns2).and(subType(_v332,t2));
                          }
                          }
                          }
                          }
                          }
                          }
                          }
                          default: {ESLVal _v334 = $816;
                            
                            {ESLVal ns1 = $815;
                            
                            {ESLVal _v335 = $814;
                            
                            {ESLVal t2 = _v218;
                            
                            return subType(_v335,t2);
                          }
                          }
                          }
                          }
                        }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: switch(_v218.termName) {
                      case "ForallType": {ESLVal $819 = _v218.termRef(0);
                        ESLVal $818 = _v218.termRef(1);
                        ESLVal $817 = _v218.termRef(2);
                        
                        {ESLVal l1 = $816;
                        
                        {ESLVal ns1 = $815;
                        
                        {ESLVal t1 = $814;
                        
                        {ESLVal l2 = $819;
                        
                        {ESLVal ns2 = $818;
                        
                        {ESLVal t2 = $817;
                        
                        return ns1.eql(ns2).and(subType(t1,t2));
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal l1 = $816;
                        
                        {ESLVal ns1 = $815;
                        
                        {ESLVal t1 = $814;
                        
                        {ESLVal t2 = _v218;
                        
                        return subType(t1,t2);
                      }
                      }
                      }
                      }
                    }
                  }
                  }
                  default: switch(_v218.termName) {
                    case "ForallType": {ESLVal $819 = _v218.termRef(0);
                      ESLVal $818 = _v218.termRef(1);
                      ESLVal $817 = _v218.termRef(2);
                      
                      {ESLVal l1 = $816;
                      
                      {ESLVal ns1 = $815;
                      
                      {ESLVal t1 = $814;
                      
                      {ESLVal l2 = $819;
                      
                      {ESLVal ns2 = $818;
                      
                      {ESLVal t2 = $817;
                      
                      return ns1.eql(ns2).and(subType(t1,t2));
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal l1 = $816;
                      
                      {ESLVal ns1 = $815;
                      
                      {ESLVal t1 = $814;
                      
                      {ESLVal t2 = _v218;
                      
                      return subType(t1,t2);
                    }
                    }
                    }
                    }
                  }
                }
                }
                default: switch(_v218.termName) {
                  case "ForallType": {ESLVal $819 = _v218.termRef(0);
                    ESLVal $818 = _v218.termRef(1);
                    ESLVal $817 = _v218.termRef(2);
                    
                    {ESLVal l1 = $816;
                    
                    {ESLVal ns1 = $815;
                    
                    {ESLVal t1 = $814;
                    
                    {ESLVal l2 = $819;
                    
                    {ESLVal ns2 = $818;
                    
                    {ESLVal t2 = $817;
                    
                    return ns1.eql(ns2).and(subType(t1,t2));
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal l1 = $816;
                    
                    {ESLVal ns1 = $815;
                    
                    {ESLVal t1 = $814;
                    
                    {ESLVal t2 = _v218;
                    
                    return subType(t1,t2);
                  }
                  }
                  }
                  }
                }
              }
            else switch(_v218.termName) {
                case "ForallType": {ESLVal $819 = _v218.termRef(0);
                  ESLVal $818 = _v218.termRef(1);
                  ESLVal $817 = _v218.termRef(2);
                  
                  {ESLVal l1 = $816;
                  
                  {ESLVal ns1 = $815;
                  
                  {ESLVal t1 = $814;
                  
                  {ESLVal l2 = $819;
                  
                  {ESLVal ns2 = $818;
                  
                  {ESLVal t2 = $817;
                  
                  return ns1.eql(ns2).and(subType(t1,t2));
                }
                }
                }
                }
                }
                }
                }
                default: {ESLVal l1 = $816;
                  
                  {ESLVal ns1 = $815;
                  
                  {ESLVal t1 = $814;
                  
                  {ESLVal t2 = _v218;
                  
                  return subType(t1,t2);
                }
                }
                }
                }
              }
            }
          else if($815.isNil())
            switch(_v218.termName) {
              case "ForallType": {ESLVal $819 = _v218.termRef(0);
                ESLVal $818 = _v218.termRef(1);
                ESLVal $817 = _v218.termRef(2);
                
                {ESLVal l1 = $816;
                
                {ESLVal ns1 = $815;
                
                {ESLVal t1 = $814;
                
                {ESLVal l2 = $819;
                
                {ESLVal ns2 = $818;
                
                {ESLVal t2 = $817;
                
                return ns1.eql(ns2).and(subType(t1,t2));
              }
              }
              }
              }
              }
              }
              }
              default: {ESLVal l1 = $816;
                
                {ESLVal ns1 = $815;
                
                {ESLVal t1 = $814;
                
                {ESLVal t2 = _v218;
                
                return subType(t1,t2);
              }
              }
              }
              }
            }
          else switch(_v218.termName) {
              case "ForallType": {ESLVal $819 = _v218.termRef(0);
                ESLVal $818 = _v218.termRef(1);
                ESLVal $817 = _v218.termRef(2);
                
                {ESLVal l1 = $816;
                
                {ESLVal ns1 = $815;
                
                {ESLVal t1 = $814;
                
                {ESLVal l2 = $819;
                
                {ESLVal ns2 = $818;
                
                {ESLVal t2 = $817;
                
                return ns1.eql(ns2).and(subType(t1,t2));
              }
              }
              }
              }
              }
              }
              }
              default: {ESLVal l1 = $816;
                
                {ESLVal ns1 = $815;
                
                {ESLVal t1 = $814;
                
                {ESLVal t2 = _v218;
                
                return subType(t1,t2);
              }
              }
              }
              }
            }
          }
          default: switch(_v218.termName) {
            case "ApplyTypeFun": {ESLVal $813 = _v218.termRef(0);
              ESLVal $812 = _v218.termRef(1);
              ESLVal $811 = _v218.termRef(2);
              
              {ESLVal t1 = _v217;
              
              {ESLVal l = $813;
              
              {ESLVal op = $812;
              
              {ESLVal args = $811;
              
              return subType(t1,applyTypeFun(l,forceType(op),args));
            }
            }
            }
            }
            }
          case "ExtendedAct": {ESLVal $810 = _v218.termRef(0);
              ESLVal $809 = _v218.termRef(1);
              ESLVal $808 = _v218.termRef(2);
              ESLVal $807 = _v218.termRef(3);
              
              {ESLVal t1 = _v217;
              
              {ESLVal l2 = $810;
              
              {ESLVal t2 = $809;
              
              {ESLVal ds2 = $808;
              
              {ESLVal ms2 = $807;
              
              return subType(t1,flattenAct(l2,t2,ds2,ms2));
            }
            }
            }
            }
            }
            }
          case "TypeClosure": {ESLVal $806 = _v218.termRef(0);
              
              {ESLVal t1 = _v217;
              
              {ESLVal f = $806;
              
              return subType(t1,f.apply());
            }
            }
            }
          case "RecType": {ESLVal $805 = _v218.termRef(0);
              ESLVal $804 = _v218.termRef(1);
              ESLVal $803 = _v218.termRef(2);
              
              {ESLVal t1 = _v217;
              
              {ESLVal l2 = $805;
              
              {ESLVal n2 = $804;
              
              {ESLVal t2 = $803;
              
              return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
            }
            }
            }
            }
            }
          case "ForallType": {ESLVal $802 = _v218.termRef(0);
              ESLVal $801 = _v218.termRef(1);
              ESLVal $800 = _v218.termRef(2);
              
              {ESLVal t1 = _v217;
              
              {ESLVal l1 = $802;
              
              {ESLVal ns2 = $801;
              
              {ESLVal t2 = $800;
              
              return subType(t1,t2);
            }
            }
            }
            }
            }
          case "ObservedType": {ESLVal $798 = _v218.termRef(0);
              ESLVal $797 = _v218.termRef(1);
              ESLVal $796 = _v218.termRef(2);
              
              switch($796.termName) {
              case "TypeClosure": {ESLVal $799 = $796.termRef(0);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l = $798;
                
                {ESLVal state = $797;
                
                {ESLVal f = $799;
                
                return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
              }
              }
              }
              }
              }
              default: {ESLVal t1 = _v217;
                
                {ESLVal l = $798;
                
                {ESLVal state = $797;
                
                {ESLVal messages = $796;
                
                return subType(t1,expandObservedType(l,state,messages));
              }
              }
              }
              }
            }
            }
          case "ObserverType": {ESLVal $794 = _v218.termRef(0);
              ESLVal $793 = _v218.termRef(1);
              ESLVal $792 = _v218.termRef(2);
              
              switch($792.termName) {
              case "TypeClosure": {ESLVal $795 = $792.termRef(0);
                
                {ESLVal t1 = _v217;
                
                {ESLVal l = $794;
                
                {ESLVal state = $793;
                
                {ESLVal f = $795;
                
                return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
              }
              }
              }
              }
              }
              default: {ESLVal t1 = _v217;
                
                {ESLVal l = $794;
                
                {ESLVal state = $793;
                
                {ESLVal messages = $792;
                
                return subType(t1,expandObserverType(l,state,messages));
              }
              }
              }
              }
            }
            }
            default: {ESLVal t1 = _v217;
              
              {ESLVal t2 = _v218;
              
              return typeEqual(t1,t2);
            }
            }
          }
        }
        }
  }
  public static ESLVal subType = new ESLVal(new Function(new ESLVal("subType"),null) { public ESLVal apply(ESLVal... args) { return subType(args[0],args[1]); }});
  public static ESLVal expandObserverType(ESLVal l1,ESLVal state,ESLVal messages) {
    
    return new ESLVal("ActType",l1,ESLVal.list(),ESLVal.list(new ESLVal("MessageType",l1,ESLVal.list(new ESLVal("TermType",l1,new ESLVal("Start"),ESLVal.list(expandObservedType(l1,state,messages),new ESLVal("IntType",l1),state)))),new ESLVal("MessageType",l1,ESLVal.list(new ESLVal("TermType",l1,new ESLVal("Transition"),ESLVal.list(expandObservedType(l1,state,messages),new ESLVal("IntType",l1),messages,state))))));
  }
  public static ESLVal expandObserverType = new ESLVal(new Function(new ESLVal("expandObserverType"),null) { public ESLVal apply(ESLVal... args) { return expandObserverType(args[0],args[1],args[2]); }});
  public static ESLVal maybe(ESLVal t) {
    
    return new ESLVal("UnionType",new ESLVal("Pos",$zero,$zero),ESLVal.list(new ESLVal("TermType",new ESLVal("Pos",$zero,$zero),new ESLVal("Exactly"),ESLVal.list(t)),new ESLVal("TermType",new ESLVal("Pos",$zero,$zero),new ESLVal("Nothing"),ESLVal.list())));
  }
  public static ESLVal maybe = new ESLVal(new Function(new ESLVal("maybe"),null) { public ESLVal apply(ESLVal... args) { return maybe(args[0]); }});
  public static ESLVal expandObservedType(ESLVal l,ESLVal state,ESLVal messages) {
    
    return new ESLVal("ActType",l,ESLVal.list(new ESLVal("Dec",l,new ESLVal("observeState"),new ESLVal("FunType",l,ESLVal.list(),state),new ESLVal("FunType",l,ESLVal.list(),state)),new ESLVal("Dec",l,new ESLVal("observeMessage"),new ESLVal("FunType",l,ESLVal.list(new ESLVal("UnionType",l,ESLVal.list())),maybe(messages)),new ESLVal("FunType",l,ESLVal.list(new ESLVal("UnionType",l,ESLVal.list())),maybe(messages)))),ESLVal.list());
  }
  public static ESLVal expandObservedType = new ESLVal(new Function(new ESLVal("expandObservedType"),null) { public ESLVal apply(ESLVal... args) { return expandObservedType(args[0],args[1],args[2]); }});
  public static ESLVal flattenAct(ESLVal l1,ESLVal t,ESLVal ds1,ESLVal ms1) {
    
    {ESLVal _v219 = t;
      
      switch(_v219.termName) {
      case "ActType": {ESLVal $924 = _v219.termRef(0);
        ESLVal $923 = _v219.termRef(1);
        ESLVal $922 = _v219.termRef(2);
        
        {ESLVal l2 = $924;
        
        {ESLVal ds2 = $923;
        
        {ESLVal ms2 = $922;
        
        return new ESLVal("ActType",l1,ds1.add(ds2),ms1.add(ms2));
      }
      }
      }
      }
    case "ExtendedAct": {ESLVal $921 = _v219.termRef(0);
        ESLVal $920 = _v219.termRef(1);
        ESLVal $919 = _v219.termRef(2);
        ESLVal $918 = _v219.termRef(3);
        
        {ESLVal l2 = $921;
        
        {ESLVal _v329 = $920;
        
        {ESLVal ds2 = $919;
        
        {ESLVal ms2 = $918;
        
        return flattenAct(l1,flattenAct(l2,_v329,ds2,ms2),ds1,ms1);
      }
      }
      }
      }
      }
    case "TypeClosure": {ESLVal $917 = _v219.termRef(0);
        
        {ESLVal f = $917;
        
        return flattenAct(l1,f.apply(),ds1,ms1);
      }
      }
    case "RecType": {ESLVal $916 = _v219.termRef(0);
        ESLVal $915 = _v219.termRef(1);
        ESLVal $914 = _v219.termRef(2);
        
        {ESLVal l2 = $916;
        
        {ESLVal n = $915;
        
        {ESLVal b = $914;
        
        return flattenAct(l1,substType(t,n,b),ds1,ms1);
      }
      }
      }
      }
      default: {ESLVal _v330 = _v219;
        
        return error(new ESLVal("TypeError",l1,new ESLVal("unknown type for flatten ").add(_v330)));
      }
    }
    }
  }
  public static ESLVal flattenAct = new ESLVal(new Function(new ESLVal("flattenAct"),null) { public ESLVal apply(ESLVal... args) { return flattenAct(args[0],args[1],args[2],args[3]); }});
  public static ESLVal actEqual(ESLVal exports1,ESLVal exports2,ESLVal handlers1,ESLVal handlers2) {
    
    return forall.apply(new ESLVal(new Function(new ESLVal("fun325"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal d1 = $args[0];
      return exists.apply(new ESLVal(new Function(new ESLVal("fun326"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal d2 = $args[0];
            return equalDec(d1,d2);
              }
            }),exports2);
        }
      }),exports1).and(forall.apply(new ESLVal(new Function(new ESLVal("fun327"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal d1 = $args[0];
      return exists.apply(new ESLVal(new Function(new ESLVal("fun328"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal d2 = $args[0];
            return equalDec(d1,d2);
              }
            }),exports1);
        }
      }),exports2).and(forall.apply(new ESLVal(new Function(new ESLVal("fun329"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal m1 = $args[0];
      return exists.apply(new ESLVal(new Function(new ESLVal("fun330"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal m2 = $args[0];
            return equalMessage(m1,m2);
              }
            }),handlers2);
        }
      }),handlers1).and(forall.apply(new ESLVal(new Function(new ESLVal("fun331"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal m1 = $args[0];
      return exists.apply(new ESLVal(new Function(new ESLVal("fun332"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal m2 = $args[0];
            return equalMessage(m1,m2);
              }
            }),handlers1);
        }
      }),handlers2))));
  }
  public static ESLVal actEqual = new ESLVal(new Function(new ESLVal("actEqual"),null) { public ESLVal apply(ESLVal... args) { return actEqual(args[0],args[1],args[2],args[3]); }});
  public static ESLVal actSubType(ESLVal exports1,ESLVal exports2,ESLVal handlers1,ESLVal handlers2) {
    
    {ESLVal isObservedMessage = new ESLVal(new Function(new ESLVal("isObservedMessage"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal d = $args[0];
        {ESLVal _v220 = d;
              
              switch(_v220.termName) {
              case "Dec": {ESLVal $928 = _v220.termRef(0);
                ESLVal $927 = _v220.termRef(1);
                ESLVal $926 = _v220.termRef(2);
                ESLVal $925 = _v220.termRef(3);
                
                switch($927.strVal) {
                case "observeMessage": {ESLVal l = $928;
                  
                  {ESLVal t1 = $926;
                  
                  {ESLVal t2 = $925;
                  
                  return $true;
                }
                }
                }
                default: {ESLVal _v327 = _v220;
                  
                  return $false;
                }
              }
              }
              default: {ESLVal _v328 = _v220;
                
                return $false;
              }
            }
            }
          }
        });
      
      return forall.apply(new ESLVal(new Function(new ESLVal("fun333"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal d2 = $args[0];
      return exists.apply(new ESLVal(new Function(new ESLVal("fun334"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal d1 = $args[0];
            return decSubType(d1,d2);
              }
            }),reject.apply(isObservedMessage,exports1));
        }
      }),reject.apply(isObservedMessage,exports2)).and(forall.apply(new ESLVal(new Function(new ESLVal("fun335"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal m2 = $args[0];
      return exists.apply(new ESLVal(new Function(new ESLVal("fun336"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal m1 = $args[0];
            return messSubType(m1,m2);
              }
            }),handlers1);
        }
      }),handlers2));
    }
  }
  public static ESLVal actSubType = new ESLVal(new Function(new ESLVal("actSubType"),null) { public ESLVal apply(ESLVal... args) { return actSubType(args[0],args[1],args[2],args[3]); }});
  public static ESLVal equalDec(ESLVal d1,ESLVal d2) {
    
    {ESLVal _v221 = d1;
      ESLVal _v222 = d2;
      
      switch(_v221.termName) {
      case "Dec": {ESLVal $932 = _v221.termRef(0);
        ESLVal $931 = _v221.termRef(1);
        ESLVal $930 = _v221.termRef(2);
        ESLVal $929 = _v221.termRef(3);
        
        switch(_v222.termName) {
        case "Dec": {ESLVal $936 = _v222.termRef(0);
          ESLVal $935 = _v222.termRef(1);
          ESLVal $934 = _v222.termRef(2);
          ESLVal $933 = _v222.termRef(3);
          
          {ESLVal l1 = $932;
          
          {ESLVal n1 = $931;
          
          {ESLVal t1 = $930;
          
          {ESLVal st1 = $929;
          
          {ESLVal l2 = $936;
          
          {ESLVal n2 = $935;
          
          {ESLVal t2 = $934;
          
          {ESLVal st2 = $933;
          
          return n1.eql(n2).and(typeEqual(t1,t2));
        }
        }
        }
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(23123,23254)").add(ESLVal.list(_v221,_v222)));
      }
      }
      default: return error(new ESLVal("case error at Pos(23123,23254)").add(ESLVal.list(_v221,_v222)));
    }
    }
  }
  public static ESLVal equalDec = new ESLVal(new Function(new ESLVal("equalDec"),null) { public ESLVal apply(ESLVal... args) { return equalDec(args[0],args[1]); }});
  public static ESLVal decSubType(ESLVal d1,ESLVal d2) {
    
    {ESLVal _v223 = d1;
      ESLVal _v224 = d2;
      
      switch(_v223.termName) {
      case "Dec": {ESLVal $940 = _v223.termRef(0);
        ESLVal $939 = _v223.termRef(1);
        ESLVal $938 = _v223.termRef(2);
        ESLVal $937 = _v223.termRef(3);
        
        switch(_v224.termName) {
        case "Dec": {ESLVal $944 = _v224.termRef(0);
          ESLVal $943 = _v224.termRef(1);
          ESLVal $942 = _v224.termRef(2);
          ESLVal $941 = _v224.termRef(3);
          
          {ESLVal l1 = $940;
          
          {ESLVal n1 = $939;
          
          {ESLVal t1 = $938;
          
          {ESLVal st1 = $937;
          
          {ESLVal l2 = $944;
          
          {ESLVal n2 = $943;
          
          {ESLVal t2 = $942;
          
          {ESLVal st2 = $941;
          
          return n1.eql(n2).and(subType(t1,t2));
        }
        }
        }
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(23298,23428)").add(ESLVal.list(_v223,_v224)));
      }
      }
      default: return error(new ESLVal("case error at Pos(23298,23428)").add(ESLVal.list(_v223,_v224)));
    }
    }
  }
  public static ESLVal decSubType = new ESLVal(new Function(new ESLVal("decSubType"),null) { public ESLVal apply(ESLVal... args) { return decSubType(args[0],args[1]); }});
  public static ESLVal equalMessage(ESLVal m1,ESLVal m2) {
    
    {ESLVal _v225 = m1;
      ESLVal _v226 = m2;
      
      switch(_v225.termName) {
      case "MessageType": {ESLVal $946 = _v225.termRef(0);
        ESLVal $945 = _v225.termRef(1);
        
        switch(_v226.termName) {
        case "MessageType": {ESLVal $948 = _v226.termRef(0);
          ESLVal $947 = _v226.termRef(1);
          
          {ESLVal l1 = $946;
          
          {ESLVal ts1 = $945;
          
          {ESLVal l2 = $948;
          
          {ESLVal ts2 = $947;
          
          return typesEqual(ts1,ts2);
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(23474,23584)").add(ESLVal.list(_v225,_v226)));
      }
      }
      default: return error(new ESLVal("case error at Pos(23474,23584)").add(ESLVal.list(_v225,_v226)));
    }
    }
  }
  public static ESLVal equalMessage = new ESLVal(new Function(new ESLVal("equalMessage"),null) { public ESLVal apply(ESLVal... args) { return equalMessage(args[0],args[1]); }});
  public static ESLVal messSubType(ESLVal m1,ESLVal m2) {
    
    {ESLVal _v227 = m1;
      ESLVal _v228 = m2;
      
      switch(_v227.termName) {
      case "MessageType": {ESLVal $950 = _v227.termRef(0);
        ESLVal $949 = _v227.termRef(1);
        
        switch(_v228.termName) {
        case "MessageType": {ESLVal $952 = _v228.termRef(0);
          ESLVal $951 = _v228.termRef(1);
          
          {ESLVal l1 = $950;
          
          {ESLVal ts1 = $949;
          
          {ESLVal l2 = $952;
          
          {ESLVal ts2 = $951;
          
          return subTypes(ts1,ts2);
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(23629,23737)").add(ESLVal.list(_v227,_v228)));
      }
      }
      default: return error(new ESLVal("case error at Pos(23629,23737)").add(ESLVal.list(_v227,_v228)));
    }
    }
  }
  public static ESLVal messSubType = new ESLVal(new Function(new ESLVal("messSubType"),null) { public ESLVal apply(ESLVal... args) { return messSubType(args[0],args[1]); }});
  public static ESLVal recordTypeEqual(ESLVal fields1,ESLVal fields2) {
    
    return forall.apply(new ESLVal(new Function(new ESLVal("fun337"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal t1 = $args[0];
      return exists.apply(new ESLVal(new Function(new ESLVal("fun338"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal t2 = $args[0];
            return decName(t1).eql(decName(t2)).and(typeEqual(decType(t1),decType(t2)));
              }
            }),fields2);
        }
      }),fields1).and(forall.apply(new ESLVal(new Function(new ESLVal("fun339"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal t1 = $args[0];
      return exists.apply(new ESLVal(new Function(new ESLVal("fun340"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal t2 = $args[0];
            return decName(t1).eql(decName(t2)).and(typeEqual(decType(t1),decType(t2)));
              }
            }),fields1);
        }
      }),fields2));
  }
  public static ESLVal recordTypeEqual = new ESLVal(new Function(new ESLVal("recordTypeEqual"),null) { public ESLVal apply(ESLVal... args) { return recordTypeEqual(args[0],args[1]); }});
  public static ESLVal recordSubType(ESLVal fields1,ESLVal fields2) {
    
    return forall.apply(new ESLVal(new Function(new ESLVal("fun341"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal t2 = $args[0];
      return exists.apply(new ESLVal(new Function(new ESLVal("fun342"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal t1 = $args[0];
            return decName(t1).eql(decName(t2)).and(subType(decType(t1),decType(t2)));
              }
            }),fields1);
        }
      }),fields2);
  }
  public static ESLVal recordSubType = new ESLVal(new Function(new ESLVal("recordSubType"),null) { public ESLVal apply(ESLVal... args) { return recordSubType(args[0],args[1]); }});
  public static ESLVal applyTypeFun(ESLVal l,ESLVal op,ESLVal args) {
    
    {ESLVal _v229 = op;
      
      switch(_v229.termName) {
      case "RecType": {ESLVal $958 = _v229.termRef(0);
        ESLVal $957 = _v229.termRef(1);
        ESLVal $956 = _v229.termRef(2);
        
        {ESLVal lr = $958;
        
        {ESLVal n = $957;
        
        {ESLVal t = $956;
        
        return applyTypeFun(l,unfoldType(lr,n,t),args);
      }
      }
      }
      }
    case "TypeFun": {ESLVal $955 = _v229.termRef(0);
        ESLVal $954 = _v229.termRef(1);
        ESLVal $953 = _v229.termRef(2);
        
        {ESLVal _v325 = $955;
        
        {ESLVal names = $954;
        
        {ESLVal t = $953;
        
        if(length.apply(args).eql(length.apply(names)).boolVal)
        return substTypeEnv(zipTypeEnv(names,args),t);
        else
          return error(new ESLVal("TypeError",_v325,new ESLVal("type fun expects ").add(length.apply(names).add(new ESLVal(" args, but supplied with ").add(length.apply(args))))));
      }
      }
      }
      }
      default: {ESLVal _v326 = _v229;
        
        return error(new ESLVal("TypeError",l,new ESLVal("expecting a type function: ").add(_v326)));
      }
    }
    }
  }
  public static ESLVal applyTypeFun = new ESLVal(new Function(new ESLVal("applyTypeFun"),null) { public ESLVal apply(ESLVal... args) { return applyTypeFun(args[0],args[1],args[2]); }});
  public static ESLVal unfoldType(ESLVal l,ESLVal n,ESLVal t) {
    
    return substType(new ESLVal("RecType",l,n,t),n,t);
  }
  public static ESLVal unfoldType = new ESLVal(new Function(new ESLVal("unfoldType"),null) { public ESLVal apply(ESLVal... args) { return unfoldType(args[0],args[1],args[2]); }});
  public static ESLVal forceType(ESLVal t) {
    
    {ESLVal _v230 = t;
      
      switch(_v230.termName) {
      case "TypeClosure": {ESLVal $959 = _v230.termRef(0);
        
        {ESLVal f = $959;
        
        return forceType(f.apply());
      }
      }
      default: {ESLVal _v324 = _v230;
        
        return _v324;
      }
    }
    }
  }
  public static ESLVal forceType = new ESLVal(new Function(new ESLVal("forceType"),null) { public ESLVal apply(ESLVal... args) { return forceType(args[0]); }});
  public static ESLVal typesEqual(ESLVal ts1,ESLVal ts2) {
    
    {ESLVal _v231 = ts1;
      ESLVal _v232 = ts2;
      
      if(_v231.isCons())
      {ESLVal $962 = _v231.head();
        ESLVal $963 = _v231.tail();
        
        if(_v232.isCons())
        {ESLVal $964 = _v232.head();
          ESLVal $965 = _v232.tail();
          
          {ESLVal t1 = $962;
          
          {ESLVal _v317 = $963;
          
          {ESLVal t2 = $964;
          
          {ESLVal _v318 = $965;
          
          return typeEqual(t1,t2).and(typesEqual(_v317,_v318));
        }
        }
        }
        }
        }
      else if(_v232.isNil())
        if(_v232.isCons())
          {ESLVal $960 = _v232.head();
            ESLVal $961 = _v232.tail();
            
            return error(new ESLVal("case error at Pos(25043,25253)").add(ESLVal.list(_v231,_v232)));
          }
        else if(_v232.isNil())
          {ESLVal _v319 = _v231;
            
            return $false;
          }
        else return error(new ESLVal("case error at Pos(25043,25253)").add(ESLVal.list(_v231,_v232)));
      else if(_v232.isCons())
          {ESLVal $960 = _v232.head();
            ESLVal $961 = _v232.tail();
            
            return error(new ESLVal("case error at Pos(25043,25253)").add(ESLVal.list(_v231,_v232)));
          }
        else if(_v232.isNil())
          {ESLVal _v320 = _v231;
            
            return $false;
          }
        else return error(new ESLVal("case error at Pos(25043,25253)").add(ESLVal.list(_v231,_v232)));
      }
    else if(_v231.isNil())
      if(_v232.isCons())
        {ESLVal $966 = _v232.head();
          ESLVal $967 = _v232.tail();
          
          {ESLVal _v321 = _v232;
          
          return $false;
        }
        }
      else if(_v232.isNil())
        return $true;
      else {ESLVal _v322 = _v232;
          
          return $false;
        }
    else if(_v232.isCons())
        {ESLVal $960 = _v232.head();
          ESLVal $961 = _v232.tail();
          
          return error(new ESLVal("case error at Pos(25043,25253)").add(ESLVal.list(_v231,_v232)));
        }
      else if(_v232.isNil())
        {ESLVal _v323 = _v231;
          
          return $false;
        }
      else return error(new ESLVal("case error at Pos(25043,25253)").add(ESLVal.list(_v231,_v232)));
    }
  }
  public static ESLVal typesEqual = new ESLVal(new Function(new ESLVal("typesEqual"),null) { public ESLVal apply(ESLVal... args) { return typesEqual(args[0],args[1]); }});
  public static ESLVal subTypes(ESLVal ts1,ESLVal ts2) {
    
    {ESLVal _v233 = ts1;
      ESLVal _v234 = ts2;
      
      if(_v233.isCons())
      {ESLVal $970 = _v233.head();
        ESLVal $971 = _v233.tail();
        
        if(_v234.isCons())
        {ESLVal $972 = _v234.head();
          ESLVal $973 = _v234.tail();
          
          {ESLVal t1 = $970;
          
          {ESLVal _v310 = $971;
          
          {ESLVal t2 = $972;
          
          {ESLVal _v311 = $973;
          
          return subType(t1,t2).and(subTypes(_v310,_v311));
        }
        }
        }
        }
        }
      else if(_v234.isNil())
        if(_v234.isCons())
          {ESLVal $968 = _v234.head();
            ESLVal $969 = _v234.tail();
            
            return error(new ESLVal("case error at Pos(25299,25505)").add(ESLVal.list(_v233,_v234)));
          }
        else if(_v234.isNil())
          {ESLVal _v312 = _v233;
            
            return $false;
          }
        else return error(new ESLVal("case error at Pos(25299,25505)").add(ESLVal.list(_v233,_v234)));
      else if(_v234.isCons())
          {ESLVal $968 = _v234.head();
            ESLVal $969 = _v234.tail();
            
            return error(new ESLVal("case error at Pos(25299,25505)").add(ESLVal.list(_v233,_v234)));
          }
        else if(_v234.isNil())
          {ESLVal _v313 = _v233;
            
            return $false;
          }
        else return error(new ESLVal("case error at Pos(25299,25505)").add(ESLVal.list(_v233,_v234)));
      }
    else if(_v233.isNil())
      if(_v234.isCons())
        {ESLVal $974 = _v234.head();
          ESLVal $975 = _v234.tail();
          
          {ESLVal _v314 = _v234;
          
          return $false;
        }
        }
      else if(_v234.isNil())
        return $true;
      else {ESLVal _v315 = _v234;
          
          return $false;
        }
    else if(_v234.isCons())
        {ESLVal $968 = _v234.head();
          ESLVal $969 = _v234.tail();
          
          return error(new ESLVal("case error at Pos(25299,25505)").add(ESLVal.list(_v233,_v234)));
        }
      else if(_v234.isNil())
        {ESLVal _v316 = _v233;
          
          return $false;
        }
      else return error(new ESLVal("case error at Pos(25299,25505)").add(ESLVal.list(_v233,_v234)));
    }
  }
  public static ESLVal subTypes = new ESLVal(new Function(new ESLVal("subTypes"),null) { public ESLVal apply(ESLVal... args) { return subTypes(args[0],args[1]); }});
  public static ESLVal typeSetEqual(ESLVal types1,ESLVal types2) {
    
    return typeSubset(types1,types2).and(typeSubset(types2,types1));
  }
  public static ESLVal typeSetEqual = new ESLVal(new Function(new ESLVal("typeSetEqual"),null) { public ESLVal apply(ESLVal... args) { return typeSetEqual(args[0],args[1]); }});
  public static ESLVal typeSubset(ESLVal sub,ESLVal sup) {
    
    {ESLVal _v235 = sub;
      
      if(_v235.isCons())
      {ESLVal $976 = _v235.head();
        ESLVal $977 = _v235.tail();
        
        {ESLVal t = $976;
        
        {ESLVal _v309 = $977;
        
        return typeMember(t,sup).and(typeSubset(_v309,sup));
      }
      }
      }
    else if(_v235.isNil())
      return $true;
    else return error(new ESLVal("case error at Pos(25665,25771)").add(ESLVal.list(_v235)));
    }
  }
  public static ESLVal typeSubset = new ESLVal(new Function(new ESLVal("typeSubset"),null) { public ESLVal apply(ESLVal... args) { return typeSubset(args[0],args[1]); }});
  public static ESLVal typeMember(ESLVal t,ESLVal types) {
    
    {ESLVal _v236 = types;
      
      if(_v236.isCons())
      {ESLVal $978 = _v236.head();
        ESLVal $979 = _v236.tail();
        
        {ESLVal tt = $978;
        
        {ESLVal _v306 = $979;
        
        if(typeEqual(t,tt).boolVal)
        return $true;
        else
          {ESLVal _v307 = $978;
            
            {ESLVal _v308 = $979;
            
            return typeMember(t,_v308);
          }
          }
      }
      }
      }
    else if(_v236.isNil())
      return $false;
    else return error(new ESLVal("case error at Pos(25817,25964)").add(ESLVal.list(_v236)));
    }
  }
  public static ESLVal typeMember = new ESLVal(new Function(new ESLVal("typeMember"),null) { public ESLVal apply(ESLVal... args) { return typeMember(args[0],args[1]); }});
  public static ESLVal substTypes(ESLVal newType,ESLVal n,ESLVal oldTypes) {
    
    {ESLVal _v237 = oldTypes;
      
      if(_v237.isCons())
      {ESLVal $980 = _v237.head();
        ESLVal $981 = _v237.tail();
        
        {ESLVal t = $980;
        
        {ESLVal ts = $981;
        
        return substTypes(newType,n,ts).cons(substType(newType,n,t));
      }
      }
      }
    else if(_v237.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(26116,26236)").add(ESLVal.list(_v237)));
    }
  }
  public static ESLVal substTypes = new ESLVal(new Function(new ESLVal("substTypes"),null) { public ESLVal apply(ESLVal... args) { return substTypes(args[0],args[1],args[2]); }});
  public static ESLVal substType(ESLVal newType,ESLVal n,ESLVal oldType) {
    
    {ESLVal _v238 = oldType;
      
      switch(_v238.termName) {
      case "ApplyType": {ESLVal $1042 = _v238.termRef(0);
        ESLVal $1041 = _v238.termRef(1);
        ESLVal $1040 = _v238.termRef(2);
        
        {ESLVal l = $1042;
        
        {ESLVal m = $1041;
        
        {ESLVal types = $1040;
        
        if(m.eql(n).boolVal)
        return new ESLVal("ApplyTypeFun",l,newType,substTypes(newType,n,types));
        else
          return new ESLVal("ApplyType",l,m,substTypes(newType,n,types));
      }
      }
      }
      }
    case "ApplyTypeFun": {ESLVal $1039 = _v238.termRef(0);
        ESLVal $1038 = _v238.termRef(1);
        ESLVal $1037 = _v238.termRef(2);
        
        {ESLVal l = $1039;
        
        {ESLVal op = $1038;
        
        {ESLVal args = $1037;
        
        return new ESLVal("ApplyTypeFun",l,substType(newType,n,op),substTypes(newType,n,args));
      }
      }
      }
      }
    case "ActType": {ESLVal $1036 = _v238.termRef(0);
        ESLVal $1035 = _v238.termRef(1);
        ESLVal $1034 = _v238.termRef(2);
        
        {ESLVal l = $1036;
        
        {ESLVal decs = $1035;
        
        {ESLVal handlers = $1034;
        
        return new ESLVal("ActType",l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal d = $l0.head();
              $l0 = $l0.tail();
              $v.add(substDec(newType,n,d));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(decs),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal m = $l0.head();
              $l0 = $l0.tail();
              $v.add(substMType(newType,n,m));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(handlers));
      }
      }
      }
      }
    case "ArrayType": {ESLVal $1033 = _v238.termRef(0);
        ESLVal $1032 = _v238.termRef(1);
        
        {ESLVal l = $1033;
        
        {ESLVal t = $1032;
        
        return new ESLVal("ArrayType",l,substType(newType,n,t));
      }
      }
      }
    case "BoolType": {ESLVal $1031 = _v238.termRef(0);
        
        {ESLVal l = $1031;
        
        return oldType;
      }
      }
    case "ExtendedAct": {ESLVal $1030 = _v238.termRef(0);
        ESLVal $1029 = _v238.termRef(1);
        ESLVal $1028 = _v238.termRef(2);
        ESLVal $1027 = _v238.termRef(3);
        
        {ESLVal l = $1030;
        
        {ESLVal parent = $1029;
        
        {ESLVal decs = $1028;
        
        {ESLVal ms = $1027;
        
        return new ESLVal("ExtendedAct",l,substType(newType,n,parent),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal d = $l0.head();
              $l0 = $l0.tail();
              $v.add(substDec(newType,n,d));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(decs),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal m = $l0.head();
              $l0 = $l0.tail();
              $v.add(substMType(newType,n,m));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(ms));
      }
      }
      }
      }
      }
    case "FloatType": {ESLVal $1026 = _v238.termRef(0);
        
        {ESLVal l = $1026;
        
        return oldType;
      }
      }
    case "ForallType": {ESLVal $1025 = _v238.termRef(0);
        ESLVal $1024 = _v238.termRef(1);
        ESLVal $1023 = _v238.termRef(2);
        
        {ESLVal l = $1025;
        
        {ESLVal ns = $1024;
        
        {ESLVal t = $1023;
        
        if(member.apply(n,ns).boolVal)
        return oldType;
        else
          return new ESLVal("ForallType",l,ns,substType(newType,n,t));
      }
      }
      }
      }
    case "FunType": {ESLVal $1022 = _v238.termRef(0);
        ESLVal $1021 = _v238.termRef(1);
        ESLVal $1020 = _v238.termRef(2);
        
        {ESLVal l = $1022;
        
        {ESLVal d = $1021;
        
        {ESLVal r = $1020;
        
        return new ESLVal("FunType",l,substTypes(newType,n,d),substType(newType,n,r));
      }
      }
      }
      }
    case "IntType": {ESLVal $1019 = _v238.termRef(0);
        
        {ESLVal l = $1019;
        
        return oldType;
      }
      }
    case "ListType": {ESLVal $1018 = _v238.termRef(0);
        ESLVal $1017 = _v238.termRef(1);
        
        {ESLVal l = $1018;
        
        {ESLVal t = $1017;
        
        return new ESLVal("ListType",l,substType(newType,n,t));
      }
      }
      }
    case "NullType": {ESLVal $1016 = _v238.termRef(0);
        
        {ESLVal l = $1016;
        
        return oldType;
      }
      }
    case "ObserverType": {ESLVal $1015 = _v238.termRef(0);
        ESLVal $1014 = _v238.termRef(1);
        ESLVal $1013 = _v238.termRef(2);
        
        {ESLVal l = $1015;
        
        {ESLVal s = $1014;
        
        {ESLVal m = $1013;
        
        return new ESLVal("ObserverType",l,substType(newType,n,s),substType(newType,n,m));
      }
      }
      }
      }
    case "ObservedType": {ESLVal $1012 = _v238.termRef(0);
        ESLVal $1011 = _v238.termRef(1);
        ESLVal $1010 = _v238.termRef(2);
        
        {ESLVal l = $1012;
        
        {ESLVal s = $1011;
        
        {ESLVal m = $1010;
        
        return new ESLVal("ObservedType",l,substType(newType,n,s),substType(newType,n,m));
      }
      }
      }
      }
    case "RecordType": {ESLVal $1009 = _v238.termRef(0);
        ESLVal $1008 = _v238.termRef(1);
        
        {ESLVal l = $1009;
        
        {ESLVal fs = $1008;
        
        return new ESLVal("RecordType",l,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v239 = $qualArg;
              
              switch(_v239.termName) {
              case "Dec": {ESLVal $1046 = _v239.termRef(0);
                ESLVal $1045 = _v239.termRef(1);
                ESLVal $1044 = _v239.termRef(2);
                ESLVal $1043 = _v239.termRef(3);
                
                {ESLVal dl = $1046;
                
                {ESLVal _v305 = $1045;
                
                {ESLVal t = $1044;
                
                {ESLVal dt = $1043;
                
                return ESLVal.list(ESLVal.list(new ESLVal("Dec",dl,_v305,substType(newType,_v305,t),dt)));
              }
              }
              }
              }
              }
              default: {ESLVal _0 = _v239;
                
                return ESLVal.list();
              }
            }
            }
          }
        }).map(fs).flatten().flatten());
      }
      }
      }
    case "RecType": {ESLVal $1007 = _v238.termRef(0);
        ESLVal $1006 = _v238.termRef(1);
        ESLVal $1005 = _v238.termRef(2);
        
        {ESLVal l = $1007;
        
        {ESLVal a = $1006;
        
        {ESLVal t = $1005;
        
        if(n.eql(a).boolVal)
        return oldType;
        else
          return new ESLVal("RecType",l,a,substType(newType,n,t));
      }
      }
      }
      }
    case "SetType": {ESLVal $1004 = _v238.termRef(0);
        ESLVal $1003 = _v238.termRef(1);
        
        {ESLVal l = $1004;
        
        {ESLVal t = $1003;
        
        return new ESLVal("SetType",l,substType(newType,n,t));
      }
      }
      }
    case "StrType": {ESLVal $1002 = _v238.termRef(0);
        
        {ESLVal l = $1002;
        
        return oldType;
      }
      }
    case "TableType": {ESLVal $1001 = _v238.termRef(0);
        ESLVal $1000 = _v238.termRef(1);
        ESLVal $999 = _v238.termRef(2);
        
        {ESLVal l = $1001;
        
        {ESLVal k = $1000;
        
        {ESLVal v = $999;
        
        return new ESLVal("TableType",l,substType(newType,n,k),substType(newType,n,v));
      }
      }
      }
      }
    case "TermType": {ESLVal $998 = _v238.termRef(0);
        ESLVal $997 = _v238.termRef(1);
        ESLVal $996 = _v238.termRef(2);
        
        {ESLVal l = $998;
        
        {ESLVal f = $997;
        
        {ESLVal ts = $996;
        
        return new ESLVal("TermType",l,f,substTypes(newType,n,ts));
      }
      }
      }
      }
    case "TypeClosure": {ESLVal $995 = _v238.termRef(0);
        
        {ESLVal f = $995;
        
        return oldType;
      }
      }
    case "TypeFun": {ESLVal $994 = _v238.termRef(0);
        ESLVal $993 = _v238.termRef(1);
        ESLVal $992 = _v238.termRef(2);
        
        {ESLVal l = $994;
        
        {ESLVal ns = $993;
        
        {ESLVal t = $992;
        
        if(member.apply(n,ns).boolVal)
        return oldType;
        else
          return new ESLVal("TypeFun",l,ns,substType(newType,n,t));
      }
      }
      }
      }
    case "UnfoldType": {ESLVal $991 = _v238.termRef(0);
        ESLVal $990 = _v238.termRef(1);
        
        {ESLVal l = $991;
        
        {ESLVal t = $990;
        
        return new ESLVal("UnfoldType",l,substType(newType,n,t));
      }
      }
      }
    case "UnionType": {ESLVal $989 = _v238.termRef(0);
        ESLVal $988 = _v238.termRef(1);
        
        {ESLVal l = $989;
        
        {ESLVal ts = $988;
        
        return new ESLVal("UnionType",l,substTypes(newType,n,ts));
      }
      }
      }
    case "VarType": {ESLVal $987 = _v238.termRef(0);
        ESLVal $986 = _v238.termRef(1);
        
        {ESLVal l = $987;
        
        {ESLVal name = $986;
        
        if(name.eql(n).boolVal)
        return newType;
        else
          return oldType;
      }
      }
      }
    case "VoidType": {ESLVal $985 = _v238.termRef(0);
        
        {ESLVal l = $985;
        
        return oldType;
      }
      }
    case "UnionRef": {ESLVal $984 = _v238.termRef(0);
        ESLVal $983 = _v238.termRef(1);
        ESLVal $982 = _v238.termRef(2);
        
        {ESLVal l = $984;
        
        {ESLVal t = $983;
        
        {ESLVal name = $982;
        
        return new ESLVal("UnionRef",l,substType(newType,n,t),name);
      }
      }
      }
      }
      default: {ESLVal x = _v238;
        
        return error(x);
      }
    }
    }
  }
  public static ESLVal substType = new ESLVal(new Function(new ESLVal("substType"),null) { public ESLVal apply(ESLVal... args) { return substType(args[0],args[1],args[2]); }});
  public static ESLVal substTypesEnv(ESLVal env,ESLVal types) {
    
    {ESLVal _v240 = types;
      
      if(_v240.isCons())
      {ESLVal $1047 = _v240.head();
        ESLVal $1048 = _v240.tail();
        
        {ESLVal t = $1047;
        
        {ESLVal ts = $1048;
        
        return substTypesEnv(env,ts).cons(substTypeEnv(env,t));
      }
      }
      }
    else if(_v240.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(28932,29043)").add(ESLVal.list(_v240)));
    }
  }
  public static ESLVal substTypesEnv = new ESLVal(new Function(new ESLVal("substTypesEnv"),null) { public ESLVal apply(ESLVal... args) { return substTypesEnv(args[0],args[1]); }});
  public static ESLVal substTypeEnv(ESLVal env,ESLVal oldType) {
    
    {ESLVal _v241 = oldType;
      
      switch(_v241.termName) {
      case "ApplyType": {ESLVal $1118 = _v241.termRef(0);
        ESLVal $1117 = _v241.termRef(1);
        ESLVal $1116 = _v241.termRef(2);
        
        {ESLVal l = $1118;
        
        {ESLVal n = $1117;
        
        {ESLVal types = $1116;
        
        {ESLVal op = lookupType(n,env);
        
        if(op.eql($null).boolVal)
        return new ESLVal("ApplyType",l,n,substTypesEnv(env,types));
        else
          return new ESLVal("ApplyTypeFun",l,op,substTypesEnv(env,types));
      }
      }
      }
      }
      }
    case "ApplyTypeFun": {ESLVal $1115 = _v241.termRef(0);
        ESLVal $1114 = _v241.termRef(1);
        ESLVal $1113 = _v241.termRef(2);
        
        {ESLVal l = $1115;
        
        {ESLVal op = $1114;
        
        {ESLVal args = $1113;
        
        return new ESLVal("ApplyTypeFun",l,substTypeEnv(env,op),substTypesEnv(env,args));
      }
      }
      }
      }
    case "ActType": {ESLVal $1112 = _v241.termRef(0);
        ESLVal $1111 = _v241.termRef(1);
        ESLVal $1110 = _v241.termRef(2);
        
        {ESLVal l = $1112;
        
        {ESLVal decs = $1111;
        
        {ESLVal handlers = $1110;
        
        return new ESLVal("ActType",l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal d = $l0.head();
              $l0 = $l0.tail();
              $v.add(substDecEnv(env,d));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(decs),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal m = $l0.head();
              $l0 = $l0.tail();
              $v.add(substMTypeEnv(env,m));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(handlers));
      }
      }
      }
      }
    case "ExtendedAct": {ESLVal $1109 = _v241.termRef(0);
        ESLVal $1108 = _v241.termRef(1);
        ESLVal $1107 = _v241.termRef(2);
        ESLVal $1106 = _v241.termRef(3);
        
        {ESLVal l = $1109;
        
        {ESLVal parent = $1108;
        
        {ESLVal decs = $1107;
        
        {ESLVal handlers = $1106;
        
        return new ESLVal("ExtendedAct",l,substTypeEnv(env,parent),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal d = $l0.head();
              $l0 = $l0.tail();
              $v.add(substDecEnv(env,d));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(decs),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal m = $l0.head();
              $l0 = $l0.tail();
              $v.add(substMTypeEnv(env,m));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(handlers));
      }
      }
      }
      }
      }
    case "ArrayType": {ESLVal $1105 = _v241.termRef(0);
        ESLVal $1104 = _v241.termRef(1);
        
        {ESLVal l = $1105;
        
        {ESLVal t = $1104;
        
        return new ESLVal("ArrayType",l,substTypeEnv(env,t));
      }
      }
      }
    case "BoolType": {ESLVal $1103 = _v241.termRef(0);
        
        {ESLVal l = $1103;
        
        return oldType;
      }
      }
    case "FloatType": {ESLVal $1102 = _v241.termRef(0);
        
        {ESLVal l = $1102;
        
        return oldType;
      }
      }
    case "ForallType": {ESLVal $1101 = _v241.termRef(0);
        ESLVal $1100 = _v241.termRef(1);
        ESLVal $1099 = _v241.termRef(2);
        
        {ESLVal l = $1101;
        
        {ESLVal ns = $1100;
        
        {ESLVal t = $1099;
        
        return new ESLVal("ForallType",l,ns,substTypeEnv(removeFromDom(env,ns),t));
      }
      }
      }
      }
    case "FieldType": {ESLVal $1098 = _v241.termRef(0);
        ESLVal $1097 = _v241.termRef(1);
        ESLVal $1096 = _v241.termRef(2);
        
        {ESLVal l = $1098;
        
        {ESLVal n = $1097;
        
        {ESLVal t = $1096;
        
        return new ESLVal("FieldType",l,n,substTypeEnv(env,t));
      }
      }
      }
      }
    case "FunType": {ESLVal $1095 = _v241.termRef(0);
        ESLVal $1094 = _v241.termRef(1);
        ESLVal $1093 = _v241.termRef(2);
        
        {ESLVal l = $1095;
        
        {ESLVal d = $1094;
        
        {ESLVal r = $1093;
        
        return new ESLVal("FunType",l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal t = $l0.head();
              $l0 = $l0.tail();
              $v.add(substTypeEnv(env,t));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(d),substTypeEnv(env,r));
      }
      }
      }
      }
    case "TaggedFunType": {ESLVal $1092 = _v241.termRef(0);
        ESLVal $1091 = _v241.termRef(1);
        ESLVal $1090 = _v241.termRef(2);
        ESLVal $1089 = _v241.termRef(3);
        
        {ESLVal l = $1092;
        
        {ESLVal d = $1091;
        
        {ESLVal p = $1090;
        
        {ESLVal r = $1089;
        
        return new ESLVal("FunType",l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal t = $l0.head();
              $l0 = $l0.tail();
              $v.add(substTypeEnv(env,t));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(d),substTypeEnv(env,r));
      }
      }
      }
      }
      }
    case "IntType": {ESLVal $1088 = _v241.termRef(0);
        
        {ESLVal l = $1088;
        
        return oldType;
      }
      }
    case "ListType": {ESLVal $1087 = _v241.termRef(0);
        ESLVal $1086 = _v241.termRef(1);
        
        {ESLVal l = $1087;
        
        {ESLVal t = $1086;
        
        return new ESLVal("ListType",l,substTypeEnv(env,t));
      }
      }
      }
    case "SetType": {ESLVal $1085 = _v241.termRef(0);
        ESLVal $1084 = _v241.termRef(1);
        
        {ESLVal l = $1085;
        
        {ESLVal t = $1084;
        
        return new ESLVal("SetType",l,substTypeEnv(env,t));
      }
      }
      }
    case "BagType": {ESLVal $1083 = _v241.termRef(0);
        ESLVal $1082 = _v241.termRef(1);
        
        {ESLVal l = $1083;
        
        {ESLVal t = $1082;
        
        return new ESLVal("BagType",l,substTypeEnv(env,t));
      }
      }
      }
    case "NullType": {ESLVal $1081 = _v241.termRef(0);
        
        {ESLVal l = $1081;
        
        return oldType;
      }
      }
    case "ObserverType": {ESLVal $1080 = _v241.termRef(0);
        ESLVal $1079 = _v241.termRef(1);
        ESLVal $1078 = _v241.termRef(2);
        
        {ESLVal l = $1080;
        
        {ESLVal s = $1079;
        
        {ESLVal m = $1078;
        
        return new ESLVal("ObserverType",l,substTypeEnv(env,s),substTypeEnv(env,m));
      }
      }
      }
      }
    case "ObservedType": {ESLVal $1077 = _v241.termRef(0);
        ESLVal $1076 = _v241.termRef(1);
        ESLVal $1075 = _v241.termRef(2);
        
        {ESLVal l = $1077;
        
        {ESLVal s = $1076;
        
        {ESLVal m = $1075;
        
        return new ESLVal("ObservedType",l,substTypeEnv(env,s),substTypeEnv(env,m));
      }
      }
      }
      }
    case "RecType": {ESLVal $1074 = _v241.termRef(0);
        ESLVal $1073 = _v241.termRef(1);
        ESLVal $1072 = _v241.termRef(2);
        
        {ESLVal l = $1074;
        
        {ESLVal a = $1073;
        
        {ESLVal t = $1072;
        
        return new ESLVal("RecType",l,a,substTypeEnv(removeFromDom(env,ESLVal.list(a)),t));
      }
      }
      }
      }
    case "RecordType": {ESLVal $1071 = _v241.termRef(0);
        ESLVal $1070 = _v241.termRef(1);
        
        {ESLVal l = $1071;
        
        {ESLVal fs = $1070;
        
        return new ESLVal("RecordType",l,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v242 = $qualArg;
              
              switch(_v242.termName) {
              case "Dec": {ESLVal $1122 = _v242.termRef(0);
                ESLVal $1121 = _v242.termRef(1);
                ESLVal $1120 = _v242.termRef(2);
                ESLVal $1119 = _v242.termRef(3);
                
                {ESLVal dl = $1122;
                
                {ESLVal n = $1121;
                
                {ESLVal t = $1120;
                
                {ESLVal dt = $1119;
                
                return ESLVal.list(ESLVal.list(new ESLVal("Dec",dl,n,substTypeEnv(env,t),dt)));
              }
              }
              }
              }
              }
              default: {ESLVal _0 = _v242;
                
                return ESLVal.list();
              }
            }
            }
          }
        }).map(fs).flatten().flatten());
      }
      }
      }
    case "StrType": {ESLVal $1069 = _v241.termRef(0);
        
        {ESLVal l = $1069;
        
        return oldType;
      }
      }
    case "TableType": {ESLVal $1068 = _v241.termRef(0);
        ESLVal $1067 = _v241.termRef(1);
        ESLVal $1066 = _v241.termRef(2);
        
        {ESLVal l = $1068;
        
        {ESLVal k = $1067;
        
        {ESLVal v = $1066;
        
        return new ESLVal("TableType",l,substTypeEnv(env,k),substTypeEnv(env,v));
      }
      }
      }
      }
    case "TermType": {ESLVal $1065 = _v241.termRef(0);
        ESLVal $1064 = _v241.termRef(1);
        ESLVal $1063 = _v241.termRef(2);
        
        {ESLVal l = $1065;
        
        {ESLVal f = $1064;
        
        {ESLVal ts = $1063;
        
        return new ESLVal("TermType",l,f,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal t = $l0.head();
              $l0 = $l0.tail();
              $v.add(substTypeEnv(env,t));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(ts));
      }
      }
      }
      }
    case "TypeClosure": {ESLVal $1062 = _v241.termRef(0);
        
        {ESLVal f = $1062;
        
        return oldType;
      }
      }
    case "TypeFun": {ESLVal $1061 = _v241.termRef(0);
        ESLVal $1060 = _v241.termRef(1);
        ESLVal $1059 = _v241.termRef(2);
        
        {ESLVal l = $1061;
        
        {ESLVal ns = $1060;
        
        {ESLVal t = $1059;
        
        return new ESLVal("TypeFun",l,ns,substTypeEnv(removeFromDom(env,ns),t));
      }
      }
      }
      }
    case "UnfoldType": {ESLVal $1058 = _v241.termRef(0);
        ESLVal $1057 = _v241.termRef(1);
        
        {ESLVal l = $1058;
        
        {ESLVal t = $1057;
        
        return new ESLVal("UnfoldType",l,substTypeEnv(env,t));
      }
      }
      }
    case "UnionType": {ESLVal $1056 = _v241.termRef(0);
        ESLVal $1055 = _v241.termRef(1);
        
        {ESLVal l = $1056;
        
        {ESLVal ts = $1055;
        
        return new ESLVal("UnionType",l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal t = $l0.head();
              $l0 = $l0.tail();
              $v.add(substTypeEnv(env,t));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(ts));
      }
      }
      }
    case "VarType": {ESLVal $1054 = _v241.termRef(0);
        ESLVal $1053 = _v241.termRef(1);
        
        {ESLVal l = $1054;
        
        {ESLVal name = $1053;
        
        if(member.apply(name,typeEnvDom(env)).boolVal)
        return lookupType(name,env);
        else
          return oldType;
      }
      }
      }
    case "VoidType": {ESLVal $1052 = _v241.termRef(0);
        
        {ESLVal l = $1052;
        
        return oldType;
      }
      }
    case "UnionRef": {ESLVal $1051 = _v241.termRef(0);
        ESLVal $1050 = _v241.termRef(1);
        ESLVal $1049 = _v241.termRef(2);
        
        {ESLVal l = $1051;
        
        {ESLVal t = $1050;
        
        {ESLVal name = $1049;
        
        return new ESLVal("UnionRef",l,substTypeEnv(env,t),name);
      }
      }
      }
      }
      default: {ESLVal x = _v241;
        
        return error(new ESLVal("substTypeEnv: ").add(oldType));
      }
    }
    }
  }
  public static ESLVal substTypeEnv = new ESLVal(new Function(new ESLVal("substTypeEnv"),null) { public ESLVal apply(ESLVal... args) { return substTypeEnv(args[0],args[1]); }});
  public static ESLVal zipTypeEnv(ESLVal ns,ESLVal ts) {
    
    {ESLVal _v243 = ns;
      ESLVal _v244 = ts;
      
      if(_v243.isCons())
      {ESLVal $1123 = _v243.head();
        ESLVal $1124 = _v243.tail();
        
        if(_v244.isCons())
        {ESLVal $1125 = _v244.head();
          ESLVal $1126 = _v244.tail();
          
          {ESLVal n = $1123;
          
          {ESLVal _v303 = $1124;
          
          {ESLVal t = $1125;
          
          {ESLVal _v304 = $1126;
          
          return zipTypeEnv(_v303,_v304).cons(new ESLVal("Map",n,t));
        }
        }
        }
        }
        }
      else if(_v244.isNil())
        return error(new ESLVal("case error at Pos(31979,32100)").add(ESLVal.list(_v243,_v244)));
      else return error(new ESLVal("case error at Pos(31979,32100)").add(ESLVal.list(_v243,_v244)));
      }
    else if(_v243.isNil())
      if(_v244.isCons())
        {ESLVal $1127 = _v244.head();
          ESLVal $1128 = _v244.tail();
          
          return error(new ESLVal("case error at Pos(31979,32100)").add(ESLVal.list(_v243,_v244)));
        }
      else if(_v244.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(31979,32100)").add(ESLVal.list(_v243,_v244)));
    else return error(new ESLVal("case error at Pos(31979,32100)").add(ESLVal.list(_v243,_v244)));
    }
  }
  public static ESLVal zipTypeEnv = new ESLVal(new Function(new ESLVal("zipTypeEnv"),null) { public ESLVal apply(ESLVal... args) { return zipTypeEnv(args[0],args[1]); }});
  public static ESLVal lookupType(ESLVal name,ESLVal env) {
    
    {ESLVal _v245 = env;
      
      if(_v245.isCons())
      {ESLVal $1129 = _v245.head();
        ESLVal $1130 = _v245.tail();
        
        switch($1129.termName) {
        case "Map": {ESLVal $1132 = $1129.termRef(0);
          ESLVal $1131 = $1129.termRef(1);
          
          {ESLVal n = $1132;
          
          {ESLVal t = $1131;
          
          {ESLVal e = $1130;
          
          if(n.eql(name).boolVal)
          return t;
          else
            {ESLVal m = $1129;
              
              {ESLVal _v302 = $1130;
              
              return lookupType(name,_v302);
            }
            }
        }
        }
        }
        }
        default: {ESLVal m = $1129;
          
          {ESLVal e = $1130;
          
          return lookupType(name,e);
        }
        }
      }
      }
    else if(_v245.isNil())
      return $null;
    else return error(new ESLVal("case error at Pos(32146,32283)").add(ESLVal.list(_v245)));
    }
  }
  public static ESLVal lookupType = new ESLVal(new Function(new ESLVal("lookupType"),null) { public ESLVal apply(ESLVal... args) { return lookupType(args[0],args[1]); }});
  public static ESLVal typeEnvDom(ESLVal e) {
    
    {ESLVal _v246 = e;
      
      if(_v246.isCons())
      {ESLVal $1133 = _v246.head();
        ESLVal $1134 = _v246.tail();
        
        switch($1133.termName) {
        case "Map": {ESLVal $1136 = $1133.termRef(0);
          ESLVal $1135 = $1133.termRef(1);
          
          {ESLVal n = $1136;
          
          {ESLVal t = $1135;
          
          {ESLVal x = $1134;
          
          return typeEnvDom(x).cons(n);
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(32318,32407)").add(ESLVal.list(_v246)));
      }
      }
    else if(_v246.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(32318,32407)").add(ESLVal.list(_v246)));
    }
  }
  public static ESLVal typeEnvDom = new ESLVal(new Function(new ESLVal("typeEnvDom"),null) { public ESLVal apply(ESLVal... args) { return typeEnvDom(args[0]); }});
  public static ESLVal removeFromDom(ESLVal e,ESLVal ns) {
    
    {ESLVal _v247 = e;
      
      if(_v247.isCons())
      {ESLVal $1137 = _v247.head();
        ESLVal $1138 = _v247.tail();
        
        switch($1137.termName) {
        case "Map": {ESLVal $1140 = $1137.termRef(0);
          ESLVal $1139 = $1137.termRef(1);
          
          {ESLVal n = $1140;
          
          {ESLVal t = $1139;
          
          {ESLVal _v298 = $1138;
          
          if(member.apply(n,ns).boolVal)
          return removeFromDom(_v298,ns);
          else
            {ESLVal _v299 = $1140;
              
              {ESLVal _v300 = $1139;
              
              {ESLVal _v301 = $1138;
              
              return removeFromDom(_v301,ns).cons(new ESLVal("Map",_v299,_v300));
            }
            }
            }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(32454,32636)").add(ESLVal.list(_v247)));
      }
      }
    else if(_v247.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(32454,32636)").add(ESLVal.list(_v247)));
    }
  }
  public static ESLVal removeFromDom = new ESLVal(new Function(new ESLVal("removeFromDom"),null) { public ESLVal apply(ESLVal... args) { return removeFromDom(args[0],args[1]); }});
  public static ESLVal restrictTypeEnv(ESLVal e,ESLVal ns) {
    
    {ESLVal _v248 = e;
      
      if(_v248.isCons())
      {ESLVal $1141 = _v248.head();
        ESLVal $1142 = _v248.tail();
        
        switch($1141.termName) {
        case "Map": {ESLVal $1144 = $1141.termRef(0);
          ESLVal $1143 = $1141.termRef(1);
          
          {ESLVal n = $1144;
          
          {ESLVal t = $1143;
          
          {ESLVal _v294 = $1142;
          
          if(member.apply(n,ns).not().boolVal)
          return restrictTypeEnv(_v294,ns);
          else
            {ESLVal _v295 = $1144;
              
              {ESLVal _v296 = $1143;
              
              {ESLVal _v297 = $1142;
              
              return restrictTypeEnv(_v297,ns).cons(new ESLVal("Map",_v295,_v296));
            }
            }
            }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(32685,32876)").add(ESLVal.list(_v248)));
      }
      }
    else if(_v248.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(32685,32876)").add(ESLVal.list(_v248)));
    }
  }
  public static ESLVal restrictTypeEnv = new ESLVal(new Function(new ESLVal("restrictTypeEnv"),null) { public ESLVal apply(ESLVal... args) { return restrictTypeEnv(args[0],args[1]); }});
  public static ESLVal typeEnvRan(ESLVal e) {
    
    {ESLVal _v249 = e;
      
      if(_v249.isCons())
      {ESLVal $1145 = _v249.head();
        ESLVal $1146 = _v249.tail();
        
        switch($1145.termName) {
        case "Map": {ESLVal $1148 = $1145.termRef(0);
          ESLVal $1147 = $1145.termRef(1);
          
          {ESLVal n = $1148;
          
          {ESLVal t = $1147;
          
          {ESLVal x = $1146;
          
          return typeEnvRan(x).cons(t);
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(32912,33003)").add(ESLVal.list(_v249)));
      }
      }
    else if(_v249.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(32912,33003)").add(ESLVal.list(_v249)));
    }
  }
  public static ESLVal typeEnvRan = new ESLVal(new Function(new ESLVal("typeEnvRan"),null) { public ESLVal apply(ESLVal... args) { return typeEnvRan(args[0]); }});
  public static ESLVal allEqualTypes(ESLVal t1,ESLVal ts) {
    
    {ESLVal _v250 = ts;
      
      if(_v250.isCons())
      {ESLVal $1149 = _v250.head();
        ESLVal $1150 = _v250.tail();
        
        {ESLVal t2 = $1149;
        
        {ESLVal _v291 = $1150;
        
        if(typeEqual(t1,t2).boolVal)
        return allEqualTypes(t1,_v291);
        else
          {ESLVal _v292 = _v250;
            
            return $false;
          }
      }
      }
      }
    else if(_v250.isNil())
      return $true;
    else {ESLVal _v293 = _v250;
        
        return $false;
      }
    }
  }
  public static ESLVal allEqualTypes = new ESLVal(new Function(new ESLVal("allEqualTypes"),null) { public ESLVal apply(ESLVal... args) { return allEqualTypes(args[0],args[1]); }});
  public static ESLVal substDec(ESLVal newType,ESLVal n,ESLVal d) {
    
    {ESLVal _v251 = d;
      
      switch(_v251.termName) {
      case "Dec": {ESLVal $1154 = _v251.termRef(0);
        ESLVal $1153 = _v251.termRef(1);
        ESLVal $1152 = _v251.termRef(2);
        ESLVal $1151 = _v251.termRef(3);
        
        {ESLVal l = $1154;
        
        {ESLVal name = $1153;
        
        {ESLVal t = $1152;
        
        {ESLVal st = $1151;
        
        return new ESLVal("Dec",l,name,substType(newType,n,t),st);
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(33236,33333)").add(ESLVal.list(_v251)));
    }
    }
  }
  public static ESLVal substDec = new ESLVal(new Function(new ESLVal("substDec"),null) { public ESLVal apply(ESLVal... args) { return substDec(args[0],args[1],args[2]); }});
  public static ESLVal substDecEnv(ESLVal env,ESLVal d) {
    
    {ESLVal _v252 = d;
      
      switch(_v252.termName) {
      case "Dec": {ESLVal $1158 = _v252.termRef(0);
        ESLVal $1157 = _v252.termRef(1);
        ESLVal $1156 = _v252.termRef(2);
        ESLVal $1155 = _v252.termRef(3);
        
        {ESLVal l = $1158;
        
        {ESLVal name = $1157;
        
        {ESLVal t = $1156;
        
        {ESLVal st = $1155;
        
        return new ESLVal("Dec",l,name,substTypeEnv(env,t),st);
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(33378,33472)").add(ESLVal.list(_v252)));
    }
    }
  }
  public static ESLVal substDecEnv = new ESLVal(new Function(new ESLVal("substDecEnv"),null) { public ESLVal apply(ESLVal... args) { return substDecEnv(args[0],args[1]); }});
  public static ESLVal substMType(ESLVal newType,ESLVal n,ESLVal m) {
    
    {ESLVal _v253 = m;
      
      switch(_v253.termName) {
      case "MessageType": {ESLVal $1160 = _v253.termRef(0);
        ESLVal $1159 = _v253.termRef(1);
        
        {ESLVal l = $1160;
        
        {ESLVal ts = $1159;
        
        return new ESLVal("MessageType",l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal t = $l0.head();
              $l0 = $l0.tail();
              $v.add(substType(newType,n,t));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(ts));
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(33532,33640)").add(ESLVal.list(_v253)));
    }
    }
  }
  public static ESLVal substMType = new ESLVal(new Function(new ESLVal("substMType"),null) { public ESLVal apply(ESLVal... args) { return substMType(args[0],args[1],args[2]); }});
  public static ESLVal substMTypeEnv(ESLVal env,ESLVal m) {
    
    {ESLVal _v254 = m;
      
      switch(_v254.termName) {
      case "MessageType": {ESLVal $1162 = _v254.termRef(0);
        ESLVal $1161 = _v254.termRef(1);
        
        {ESLVal l = $1162;
        
        {ESLVal ts = $1161;
        
        return new ESLVal("MessageType",l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal t = $l0.head();
              $l0 = $l0.tail();
              $v.add(substTypeEnv(env,t));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(ts));
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(33692,33797)").add(ESLVal.list(_v254)));
    }
    }
  }
  public static ESLVal substMTypeEnv = new ESLVal(new Function(new ESLVal("substMTypeEnv"),null) { public ESLVal apply(ESLVal... args) { return substMTypeEnv(args[0],args[1]); }});
  public static ESLVal patternNames(ESLVal x) {
    
    {ESLVal _v255 = x;
      
      switch(_v255.termName) {
      case "PAdd": {ESLVal $1194 = _v255.termRef(0);
        ESLVal $1193 = _v255.termRef(1);
        ESLVal $1192 = _v255.termRef(2);
        
        {ESLVal l = $1194;
        
        {ESLVal p1 = $1193;
        
        {ESLVal p2 = $1192;
        
        return patternNames(p1).add(patternNames(p2));
      }
      }
      }
      }
    case "PVar": {ESLVal $1191 = _v255.termRef(0);
        ESLVal $1190 = _v255.termRef(1);
        ESLVal $1189 = _v255.termRef(2);
        
        {ESLVal v0 = $1191;
        
        {ESLVal v1 = $1190;
        
        {ESLVal v2 = $1189;
        
        return ESLVal.list(v1);
      }
      }
      }
      }
    case "PTerm": {ESLVal $1188 = _v255.termRef(0);
        ESLVal $1187 = _v255.termRef(1);
        ESLVal $1186 = _v255.termRef(2);
        ESLVal $1185 = _v255.termRef(3);
        
        {ESLVal v0 = $1188;
        
        {ESLVal v1 = $1187;
        
        {ESLVal v2 = $1186;
        
        {ESLVal v3 = $1185;
        
        return new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal p = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = patternNames(p);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v3);
      }
      }
      }
      }
      }
    case "PApplyType": {ESLVal $1184 = _v255.termRef(0);
        ESLVal $1183 = _v255.termRef(1);
        ESLVal $1182 = _v255.termRef(2);
        
        {ESLVal v0 = $1184;
        
        {ESLVal v1 = $1183;
        
        {ESLVal v2 = $1182;
        
        return patternNames(v1);
      }
      }
      }
      }
    case "PNil": {ESLVal $1181 = _v255.termRef(0);
        
        {ESLVal v0 = $1181;
        
        return ESLVal.list();
      }
      }
    case "PNull": {ESLVal $1180 = _v255.termRef(0);
        
        {ESLVal v0 = $1180;
        
        return ESLVal.list();
      }
      }
    case "PInt": {ESLVal $1179 = _v255.termRef(0);
        ESLVal $1178 = _v255.termRef(1);
        
        {ESLVal v0 = $1179;
        
        {ESLVal v1 = $1178;
        
        return ESLVal.list();
      }
      }
      }
    case "PStr": {ESLVal $1177 = _v255.termRef(0);
        ESLVal $1176 = _v255.termRef(1);
        
        {ESLVal v0 = $1177;
        
        {ESLVal v1 = $1176;
        
        return ESLVal.list();
      }
      }
      }
    case "PBool": {ESLVal $1175 = _v255.termRef(0);
        ESLVal $1174 = _v255.termRef(1);
        
        {ESLVal v0 = $1175;
        
        {ESLVal v1 = $1174;
        
        return ESLVal.list();
      }
      }
      }
    case "PCons": {ESLVal $1173 = _v255.termRef(0);
        ESLVal $1172 = _v255.termRef(1);
        ESLVal $1171 = _v255.termRef(2);
        
        {ESLVal v0 = $1173;
        
        {ESLVal v1 = $1172;
        
        {ESLVal v2 = $1171;
        
        return patternNames(v1).add(patternNames(v2));
      }
      }
      }
      }
    case "PBagCons": {ESLVal $1170 = _v255.termRef(0);
        ESLVal $1169 = _v255.termRef(1);
        ESLVal $1168 = _v255.termRef(2);
        
        {ESLVal v0 = $1170;
        
        {ESLVal v1 = $1169;
        
        {ESLVal v2 = $1168;
        
        return patternNames(v1).add(patternNames(v2));
      }
      }
      }
      }
    case "PEmptyBag": {ESLVal $1167 = _v255.termRef(0);
        
        {ESLVal v0 = $1167;
        
        return ESLVal.list();
      }
      }
    case "PSetCons": {ESLVal $1166 = _v255.termRef(0);
        ESLVal $1165 = _v255.termRef(1);
        ESLVal $1164 = _v255.termRef(2);
        
        {ESLVal v0 = $1166;
        
        {ESLVal v1 = $1165;
        
        {ESLVal v2 = $1164;
        
        return patternNames(v1).add(patternNames(v2));
      }
      }
      }
      }
    case "PEmptySet": {ESLVal $1163 = _v255.termRef(0);
        
        {ESLVal v0 = $1163;
        
        return ESLVal.list();
      }
      }
      default: return error(new ESLVal("case error at Pos(34671,35451)").add(ESLVal.list(_v255)));
    }
    }
  }
  public static ESLVal patternNames = new ESLVal(new Function(new ESLVal("patternNames"),null) { public ESLVal apply(ESLVal... args) { return patternNames(args[0]); }});
  public static ESLVal patternLoc(ESLVal x) {
    
    {ESLVal _v256 = x;
      
      switch(_v256.termName) {
      case "PAdd": {ESLVal $1226 = _v256.termRef(0);
        ESLVal $1225 = _v256.termRef(1);
        ESLVal $1224 = _v256.termRef(2);
        
        {ESLVal l = $1226;
        
        {ESLVal p1 = $1225;
        
        {ESLVal p2 = $1224;
        
        return l;
      }
      }
      }
      }
    case "PVar": {ESLVal $1223 = _v256.termRef(0);
        ESLVal $1222 = _v256.termRef(1);
        ESLVal $1221 = _v256.termRef(2);
        
        {ESLVal l = $1223;
        
        {ESLVal v1 = $1222;
        
        {ESLVal v2 = $1221;
        
        return l;
      }
      }
      }
      }
    case "PTerm": {ESLVal $1220 = _v256.termRef(0);
        ESLVal $1219 = _v256.termRef(1);
        ESLVal $1218 = _v256.termRef(2);
        ESLVal $1217 = _v256.termRef(3);
        
        {ESLVal l = $1220;
        
        {ESLVal v1 = $1219;
        
        {ESLVal v2 = $1218;
        
        {ESLVal v3 = $1217;
        
        return l;
      }
      }
      }
      }
      }
    case "PApplyType": {ESLVal $1216 = _v256.termRef(0);
        ESLVal $1215 = _v256.termRef(1);
        ESLVal $1214 = _v256.termRef(2);
        
        {ESLVal l = $1216;
        
        {ESLVal v1 = $1215;
        
        {ESLVal v2 = $1214;
        
        return l;
      }
      }
      }
      }
    case "PNil": {ESLVal $1213 = _v256.termRef(0);
        
        {ESLVal l = $1213;
        
        return l;
      }
      }
    case "PNull": {ESLVal $1212 = _v256.termRef(0);
        
        {ESLVal l = $1212;
        
        return l;
      }
      }
    case "PInt": {ESLVal $1211 = _v256.termRef(0);
        ESLVal $1210 = _v256.termRef(1);
        
        {ESLVal l = $1211;
        
        {ESLVal v1 = $1210;
        
        return l;
      }
      }
      }
    case "PStr": {ESLVal $1209 = _v256.termRef(0);
        ESLVal $1208 = _v256.termRef(1);
        
        {ESLVal l = $1209;
        
        {ESLVal v1 = $1208;
        
        return l;
      }
      }
      }
    case "PBool": {ESLVal $1207 = _v256.termRef(0);
        ESLVal $1206 = _v256.termRef(1);
        
        {ESLVal l = $1207;
        
        {ESLVal v1 = $1206;
        
        return l;
      }
      }
      }
    case "PCons": {ESLVal $1205 = _v256.termRef(0);
        ESLVal $1204 = _v256.termRef(1);
        ESLVal $1203 = _v256.termRef(2);
        
        {ESLVal l = $1205;
        
        {ESLVal v1 = $1204;
        
        {ESLVal v2 = $1203;
        
        return l;
      }
      }
      }
      }
    case "PBagCons": {ESLVal $1202 = _v256.termRef(0);
        ESLVal $1201 = _v256.termRef(1);
        ESLVal $1200 = _v256.termRef(2);
        
        {ESLVal l = $1202;
        
        {ESLVal v1 = $1201;
        
        {ESLVal v2 = $1200;
        
        return l;
      }
      }
      }
      }
    case "PEmptyBag": {ESLVal $1199 = _v256.termRef(0);
        
        {ESLVal l = $1199;
        
        return l;
      }
      }
    case "PSetCons": {ESLVal $1198 = _v256.termRef(0);
        ESLVal $1197 = _v256.termRef(1);
        ESLVal $1196 = _v256.termRef(2);
        
        {ESLVal l = $1198;
        
        {ESLVal v1 = $1197;
        
        {ESLVal v2 = $1196;
        
        return l;
      }
      }
      }
      }
    case "PEmptySet": {ESLVal $1195 = _v256.termRef(0);
        
        {ESLVal l = $1195;
        
        return l;
      }
      }
      default: return error(new ESLVal("case error at Pos(35489,36045)").add(ESLVal.list(_v256)));
    }
    }
  }
  public static ESLVal patternLoc = new ESLVal(new Function(new ESLVal("patternLoc"),null) { public ESLVal apply(ESLVal... args) { return patternLoc(args[0]); }});
  public static ESLVal mergeFunDefs(ESLVal defs) {
    
    { LetRec letrec = new LetRec() {
      ESLVal getFunCases = new ESLVal(new Function(new ESLVal("getFunCases"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v283 = $args[0];
        ESLVal _v284 = $args[1];
        {ESLVal _v257 = _v284;
              
              if(_v257.isCons())
              {ESLVal $1227 = _v257.head();
                ESLVal $1228 = _v257.tail();
                
                switch($1227.termName) {
                case "FunBind": {ESLVal $1235 = $1227.termRef(0);
                  ESLVal $1234 = $1227.termRef(1);
                  ESLVal $1233 = $1227.termRef(2);
                  ESLVal $1232 = $1227.termRef(3);
                  ESLVal $1231 = $1227.termRef(4);
                  ESLVal $1230 = $1227.termRef(5);
                  ESLVal $1229 = $1227.termRef(6);
                  
                  {ESLVal l = $1235;
                  
                  {ESLVal n0 = $1234;
                  
                  {ESLVal args = $1233;
                  
                  {ESLVal t = $1232;
                  
                  {ESLVal dt = $1231;
                  
                  {ESLVal e = $1230;
                  
                  {ESLVal g = $1229;
                  
                  {ESLVal _v285 = $1228;
                  
                  if(_v283.eql(n0).boolVal)
                  return getFunCases.apply(_v283,_v285).cons(new ESLVal("FunCase",l,args,t,g,e));
                  else
                    {ESLVal def = $1227;
                      
                      {ESLVal _v286 = $1228;
                      
                      return getFunCases.apply(_v283,_v286);
                    }
                    }
                }
                }
                }
                }
                }
                }
                }
                }
                }
                default: {ESLVal def = $1227;
                  
                  {ESLVal _v287 = $1228;
                  
                  return getFunCases.apply(_v283,_v287);
                }
                }
              }
              }
            else if(_v257.isNil())
              return ESLVal.list();
            else return error(new ESLVal("case error at Pos(36424,36601)").add(ESLVal.list(_v257)));
            }
          }
        });
      ESLVal removeFunCases = new ESLVal(new Function(new ESLVal("removeFunCases"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v278 = $args[0];
        ESLVal _v279 = $args[1];
        {ESLVal _v258 = _v279;
              
              if(_v258.isCons())
              {ESLVal $1236 = _v258.head();
                ESLVal $1237 = _v258.tail();
                
                switch($1236.termName) {
                case "FunBind": {ESLVal $1244 = $1236.termRef(0);
                  ESLVal $1243 = $1236.termRef(1);
                  ESLVal $1242 = $1236.termRef(2);
                  ESLVal $1241 = $1236.termRef(3);
                  ESLVal $1240 = $1236.termRef(4);
                  ESLVal $1239 = $1236.termRef(5);
                  ESLVal $1238 = $1236.termRef(6);
                  
                  {ESLVal l = $1244;
                  
                  {ESLVal n0 = $1243;
                  
                  {ESLVal args = $1242;
                  
                  {ESLVal t = $1241;
                  
                  {ESLVal dt = $1240;
                  
                  {ESLVal e = $1239;
                  
                  {ESLVal g = $1238;
                  
                  {ESLVal _v280 = $1237;
                  
                  if(_v278.eql(n0).boolVal)
                  return removeFunCases.apply(_v278,_v280);
                  else
                    {ESLVal def = $1236;
                      
                      {ESLVal _v281 = $1237;
                      
                      return removeFunCases.apply(_v278,_v281).cons(def);
                    }
                    }
                }
                }
                }
                }
                }
                }
                }
                }
                }
                default: {ESLVal def = $1236;
                  
                  {ESLVal _v282 = $1237;
                  
                  return removeFunCases.apply(_v278,_v282).cons(def);
                }
                }
              }
              }
            else if(_v258.isNil())
              return ESLVal.list();
            else return error(new ESLVal("case error at Pos(36660,36825)").add(ESLVal.list(_v258)));
            }
          }
        });
      
      public ESLVal get(String name) {
        switch(name) {
          case "getFunCases": return getFunCases;
          
          case "removeFunCases": return removeFunCases;
          
          default: throw new Error("cannot find letrec binding");
        }
        }
      };
    ESLVal getFunCases = letrec.get("getFunCases");
    
    ESLVal removeFunCases = letrec.get("removeFunCases");
    
      {ESLVal _v259 = defs;
      
      if(_v259.isCons())
      {ESLVal $1245 = _v259.head();
        ESLVal $1246 = _v259.tail();
        
        switch($1245.termName) {
        case "FunBind": {ESLVal $1253 = $1245.termRef(0);
          ESLVal $1252 = $1245.termRef(1);
          ESLVal $1251 = $1245.termRef(2);
          ESLVal $1250 = $1245.termRef(3);
          ESLVal $1249 = $1245.termRef(4);
          ESLVal $1248 = $1245.termRef(5);
          ESLVal $1247 = $1245.termRef(6);
          
          {ESLVal l = $1253;
          
          {ESLVal n = $1252;
          
          {ESLVal args = $1251;
          
          {ESLVal t = $1250;
          
          {ESLVal dt = $1249;
          
          {ESLVal e = $1248;
          
          {ESLVal g = $1247;
          
          {ESLVal _v288 = $1246;
          
          {ESLVal cases = getFunCases.apply(n,_v288);
          
          if(cases.eql(ESLVal.list()).boolVal)
          return mergeFunDefs(_v288).cons(new ESLVal("FunBind",l,n,args,t,dt,e,g));
          else
            {ESLVal _v289 = removeFunCases.apply(n,_v288);
              
              return mergeFunDefs(_v289).cons(new ESLVal("FunBinds",n,cases.cons(new ESLVal("FunCase",l,args,t,g,e))));
            }
        }
        }
        }
        }
        }
        }
        }
        }
        }
        }
        default: {ESLVal def = $1245;
          
          {ESLVal _v290 = $1246;
          
          return mergeFunDefs(_v290).cons(def);
        }
        }
      }
      }
    else if(_v259.isNil())
      return ESLVal.list();
    else return error(new ESLVal("case error at Pos(36837,37257)").add(ESLVal.list(_v259)));
    }}
    
  }
  public static ESLVal mergeFunDefs = new ESLVal(new Function(new ESLVal("mergeFunDefs"),null) { public ESLVal apply(ESLVal... args) { return mergeFunDefs(args[0]); }});
  public static ESLVal expandFunDefs(ESLVal defs) {
    
    {ESLVal _v260 = defs;
      
      if(_v260.isCons())
      {ESLVal $1254 = _v260.head();
        ESLVal $1255 = _v260.tail();
        
        switch($1254.termName) {
        case "FunBinds": {ESLVal $1257 = $1254.termRef(0);
          ESLVal $1256 = $1254.termRef(1);
          
          if($1256.isCons())
          {ESLVal $1258 = $1256.head();
            ESLVal $1259 = $1256.tail();
            
            switch($1258.termName) {
            case "FunCase": {ESLVal $1264 = $1258.termRef(0);
              ESLVal $1263 = $1258.termRef(1);
              ESLVal $1262 = $1258.termRef(2);
              ESLVal $1261 = $1258.termRef(3);
              ESLVal $1260 = $1258.termRef(4);
              
              {ESLVal n = $1257;
              
              {ESLVal l = $1264;
              
              {ESLVal args = $1263;
              
              {ESLVal t = $1262;
              
              {ESLVal g = $1261;
              
              {ESLVal e = $1260;
              
              {ESLVal cases = $1259;
              
              {ESLVal _v268 = $1255;
              
              {ESLVal names = new java.util.function.Function<ESLVal,ESLVal>() {
                  public ESLVal apply(ESLVal $l0) {
                    ESLVal $a = $nil;
                    java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                    while(!$l0.isNil()) { 
                      ESLVal i = $l0.head();
                      $l0 = $l0.tail();
                      $v.add(new ESLVal("$").add(i));
                    }
                    for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                    return $a;
                  }}.apply($zero.to(length.apply(args)));
              
              return expandFunDefs(_v268).cons(new ESLVal("Binding",l,n,t,t,new ESLVal("FunExp",l,new ESLVal("StrExp",l,n),new java.util.function.Function<ESLVal,ESLVal>() {
                public ESLVal apply(ESLVal $l0) {
                  ESLVal $a = $nil;
                  java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                  while(!$l0.isNil()) { 
                    ESLVal n = $l0.head();
                    $l0 = $l0.tail();
                    $v.add(new ESLVal("Dec",l,n,$null,$null));
                  }
                  for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                  return $a;
                }}.apply(names),t,new ESLVal("Case",l,ESLVal.list(),new java.util.function.Function<ESLVal,ESLVal>() {
                public ESLVal apply(ESLVal $l0) {
                  ESLVal $a = $nil;
                  java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                  while(!$l0.isNil()) { 
                    ESLVal n = $l0.head();
                    $l0 = $l0.tail();
                    $v.add(new ESLVal("Var",l,n));
                  }
                  for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                  return $a;
                }}.apply(names),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v261 = $qualArg;
                    
                    switch(_v261.termName) {
                    case "FunCase": {ESLVal $1269 = _v261.termRef(0);
                      ESLVal $1268 = _v261.termRef(1);
                      ESLVal $1267 = _v261.termRef(2);
                      ESLVal $1266 = _v261.termRef(3);
                      ESLVal $1265 = _v261.termRef(4);
                      
                      {ESLVal _v269 = $1269;
                      
                      {ESLVal _v270 = $1268;
                      
                      {ESLVal _v271 = $1267;
                      
                      {ESLVal _v272 = $1266;
                      
                      {ESLVal _v273 = $1265;
                      
                      return ESLVal.list(ESLVal.list(new ESLVal("BArm",_v269,_v270,_v272,_v273)));
                    }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal _0 = _v261;
                      
                      return ESLVal.list();
                    }
                  }
                  }
                }
              }).map(cases.cons(new ESLVal("FunCase",l,args,t,g,e))).flatten().flatten()))));
            }
            }
            }
            }
            }
            }
            }
            }
            }
            }
            default: {ESLVal d = $1254;
              
              {ESLVal _v274 = $1255;
              
              return expandFunDefs(_v274).cons(d);
            }
            }
          }
          }
        else if($1256.isNil())
          {ESLVal d = $1254;
            
            {ESLVal _v275 = $1255;
            
            return expandFunDefs(_v275).cons(d);
          }
          }
        else {ESLVal d = $1254;
            
            {ESLVal _v276 = $1255;
            
            return expandFunDefs(_v276).cons(d);
          }
          }
        }
        default: {ESLVal d = $1254;
          
          {ESLVal _v277 = $1255;
          
          return expandFunDefs(_v277).cons(d);
        }
        }
      }
      }
    else if(_v260.isNil())
      return ESLVal.list();
    else return error(new ESLVal("case error at Pos(37305,37761)").add(ESLVal.list(_v260)));
    }
  }
  public static ESLVal expandFunDefs = new ESLVal(new Function(new ESLVal("expandFunDefs"),null) { public ESLVal apply(ESLVal... args) { return expandFunDefs(args[0]); }});
  public static ESLVal isBinding(ESLVal b) {
    
    {ESLVal _v262 = b;
      
      switch(_v262.termName) {
      case "Binding": {ESLVal $1274 = _v262.termRef(0);
        ESLVal $1273 = _v262.termRef(1);
        ESLVal $1272 = _v262.termRef(2);
        ESLVal $1271 = _v262.termRef(3);
        ESLVal $1270 = _v262.termRef(4);
        
        {ESLVal l = $1274;
        
        {ESLVal n = $1273;
        
        {ESLVal t = $1272;
        
        {ESLVal st = $1271;
        
        {ESLVal e = $1270;
        
        return $true;
      }
      }
      }
      }
      }
      }
      default: {ESLVal _v267 = _v262;
        
        return $false;
      }
    }
    }
  }
  public static ESLVal isBinding = new ESLVal(new Function(new ESLVal("isBinding"),null) { public ESLVal apply(ESLVal... args) { return isBinding(args[0]); }});
  public static ESLVal isFunBind(ESLVal b) {
    
    {ESLVal _v263 = b;
      
      switch(_v263.termName) {
      case "FunBind": {ESLVal $1281 = _v263.termRef(0);
        ESLVal $1280 = _v263.termRef(1);
        ESLVal $1279 = _v263.termRef(2);
        ESLVal $1278 = _v263.termRef(3);
        ESLVal $1277 = _v263.termRef(4);
        ESLVal $1276 = _v263.termRef(5);
        ESLVal $1275 = _v263.termRef(6);
        
        {ESLVal l = $1281;
        
        {ESLVal n = $1280;
        
        {ESLVal args = $1279;
        
        {ESLVal t = $1278;
        
        {ESLVal st = $1277;
        
        {ESLVal g = $1276;
        
        {ESLVal e = $1275;
        
        return $true;
      }
      }
      }
      }
      }
      }
      }
      }
      default: {ESLVal _v266 = _v263;
        
        return $false;
      }
    }
    }
  }
  public static ESLVal isFunBind = new ESLVal(new Function(new ESLVal("isFunBind"),null) { public ESLVal apply(ESLVal... args) { return isFunBind(args[0]); }});
  public static ESLVal bindingName(ESLVal b) {
    
    {ESLVal _v264 = b;
      
      switch(_v264.termName) {
      case "TypeBind": {ESLVal $1307 = _v264.termRef(0);
        ESLVal $1306 = _v264.termRef(1);
        ESLVal $1305 = _v264.termRef(2);
        ESLVal $1304 = _v264.termRef(3);
        
        {ESLVal v0 = $1307;
        
        {ESLVal v1 = $1306;
        
        {ESLVal v2 = $1305;
        
        {ESLVal v3 = $1304;
        
        return v1;
      }
      }
      }
      }
      }
    case "CnstrBind": {ESLVal $1303 = _v264.termRef(0);
        ESLVal $1302 = _v264.termRef(1);
        ESLVal $1301 = _v264.termRef(2);
        ESLVal $1300 = _v264.termRef(3);
        
        {ESLVal v0 = $1303;
        
        {ESLVal v1 = $1302;
        
        {ESLVal v2 = $1301;
        
        {ESLVal v3 = $1300;
        
        return v1;
      }
      }
      }
      }
      }
    case "FunBind": {ESLVal $1299 = _v264.termRef(0);
        ESLVal $1298 = _v264.termRef(1);
        ESLVal $1297 = _v264.termRef(2);
        ESLVal $1296 = _v264.termRef(3);
        ESLVal $1295 = _v264.termRef(4);
        ESLVal $1294 = _v264.termRef(5);
        ESLVal $1293 = _v264.termRef(6);
        
        {ESLVal v0 = $1299;
        
        {ESLVal v1 = $1298;
        
        {ESLVal v2 = $1297;
        
        {ESLVal v3 = $1296;
        
        {ESLVal v4 = $1295;
        
        {ESLVal v5 = $1294;
        
        {ESLVal v6 = $1293;
        
        return v1;
      }
      }
      }
      }
      }
      }
      }
      }
    case "FunBinds": {ESLVal $1292 = _v264.termRef(0);
        ESLVal $1291 = _v264.termRef(1);
        
        {ESLVal n = $1292;
        
        {ESLVal cases = $1291;
        
        return n;
      }
      }
      }
    case "Binding": {ESLVal $1290 = _v264.termRef(0);
        ESLVal $1289 = _v264.termRef(1);
        ESLVal $1288 = _v264.termRef(2);
        ESLVal $1287 = _v264.termRef(3);
        ESLVal $1286 = _v264.termRef(4);
        
        {ESLVal v0 = $1290;
        
        {ESLVal v1 = $1289;
        
        {ESLVal v2 = $1288;
        
        {ESLVal v3 = $1287;
        
        {ESLVal v4 = $1286;
        
        return v1;
      }
      }
      }
      }
      }
      }
    case "DataBind": {ESLVal $1285 = _v264.termRef(0);
        ESLVal $1284 = _v264.termRef(1);
        ESLVal $1283 = _v264.termRef(2);
        ESLVal $1282 = _v264.termRef(3);
        
        {ESLVal v0 = $1285;
        
        {ESLVal v1 = $1284;
        
        {ESLVal v2 = $1283;
        
        {ESLVal v3 = $1282;
        
        return v1;
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(38071,38420)").add(ESLVal.list(_v264)));
    }
    }
  }
  public static ESLVal bindingName = new ESLVal(new Function(new ESLVal("bindingName"),null) { public ESLVal apply(ESLVal... args) { return bindingName(args[0]); }});
  public static ESLVal bindingLoc(ESLVal b) {
    
    {ESLVal _v265 = b;
      
      switch(_v265.termName) {
      case "TypeBind": {ESLVal $1340 = _v265.termRef(0);
        ESLVal $1339 = _v265.termRef(1);
        ESLVal $1338 = _v265.termRef(2);
        ESLVal $1337 = _v265.termRef(3);
        
        {ESLVal v0 = $1340;
        
        {ESLVal v1 = $1339;
        
        {ESLVal v2 = $1338;
        
        {ESLVal v3 = $1337;
        
        return v0;
      }
      }
      }
      }
      }
    case "CnstrBind": {ESLVal $1336 = _v265.termRef(0);
        ESLVal $1335 = _v265.termRef(1);
        ESLVal $1334 = _v265.termRef(2);
        ESLVal $1333 = _v265.termRef(3);
        
        {ESLVal v0 = $1336;
        
        {ESLVal v1 = $1335;
        
        {ESLVal v2 = $1334;
        
        {ESLVal v3 = $1333;
        
        return v0;
      }
      }
      }
      }
      }
    case "FunBind": {ESLVal $1332 = _v265.termRef(0);
        ESLVal $1331 = _v265.termRef(1);
        ESLVal $1330 = _v265.termRef(2);
        ESLVal $1329 = _v265.termRef(3);
        ESLVal $1328 = _v265.termRef(4);
        ESLVal $1327 = _v265.termRef(5);
        ESLVal $1326 = _v265.termRef(6);
        
        {ESLVal v0 = $1332;
        
        {ESLVal v1 = $1331;
        
        {ESLVal v2 = $1330;
        
        {ESLVal v3 = $1329;
        
        {ESLVal v4 = $1328;
        
        {ESLVal v5 = $1327;
        
        {ESLVal v6 = $1326;
        
        return v0;
      }
      }
      }
      }
      }
      }
      }
      }
    case "FunBinds": {ESLVal $1318 = _v265.termRef(0);
        ESLVal $1317 = _v265.termRef(1);
        
        if($1317.isCons())
        {ESLVal $1319 = $1317.head();
          ESLVal $1320 = $1317.tail();
          
          switch($1319.termName) {
          case "FunCase": {ESLVal $1325 = $1319.termRef(0);
            ESLVal $1324 = $1319.termRef(1);
            ESLVal $1323 = $1319.termRef(2);
            ESLVal $1322 = $1319.termRef(3);
            ESLVal $1321 = $1319.termRef(4);
            
            {ESLVal n = $1318;
            
            {ESLVal l = $1325;
            
            {ESLVal args = $1324;
            
            {ESLVal t = $1323;
            
            {ESLVal g = $1322;
            
            {ESLVal e = $1321;
            
            {ESLVal cases = $1320;
            
            return l;
          }
          }
          }
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(38452,38823)").add(ESLVal.list(_v265)));
        }
        }
      else if($1317.isNil())
        return error(new ESLVal("case error at Pos(38452,38823)").add(ESLVal.list(_v265)));
      else return error(new ESLVal("case error at Pos(38452,38823)").add(ESLVal.list(_v265)));
      }
    case "Binding": {ESLVal $1316 = _v265.termRef(0);
        ESLVal $1315 = _v265.termRef(1);
        ESLVal $1314 = _v265.termRef(2);
        ESLVal $1313 = _v265.termRef(3);
        ESLVal $1312 = _v265.termRef(4);
        
        {ESLVal v0 = $1316;
        
        {ESLVal v1 = $1315;
        
        {ESLVal v2 = $1314;
        
        {ESLVal v3 = $1313;
        
        {ESLVal v4 = $1312;
        
        return v0;
      }
      }
      }
      }
      }
      }
    case "DataBind": {ESLVal $1311 = _v265.termRef(0);
        ESLVal $1310 = _v265.termRef(1);
        ESLVal $1309 = _v265.termRef(2);
        ESLVal $1308 = _v265.termRef(3);
        
        {ESLVal v0 = $1311;
        
        {ESLVal v1 = $1310;
        
        {ESLVal v2 = $1309;
        
        {ESLVal v3 = $1308;
        
        return v0;
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(38452,38823)").add(ESLVal.list(_v265)));
    }
    }
  }
  public static ESLVal bindingLoc = new ESLVal(new Function(new ESLVal("bindingLoc"),null) { public ESLVal apply(ESLVal... args) { return bindingLoc(args[0]); }});

public static void main(String[] args) {
  }
}