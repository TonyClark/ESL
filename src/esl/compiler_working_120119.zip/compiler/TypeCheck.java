package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
// import static esl.Lists.*;
import static esl.compiler.Types.*;
import static esl.Tables.*;
import static esl.Displays.*;
import static esl.compiler.UnusedVars.*;
import static esl.compiler.Typeinfo.*;
import java.util.function.Supplier;
public class TypeCheck {
  public static ESLVal getSelf() { return $null; }
  private static ESLVal ppPattern(ESLVal p) {
    
    {ESLVal _v1039 = p;
      
      switch(_v1039.termName) {
      case "PAdd": {ESLVal $1524 = _v1039.termRef(0);
        ESLVal $1523 = _v1039.termRef(1);
        ESLVal $1522 = _v1039.termRef(2);
        
        {ESLVal l = $1524;
        
        {ESLVal p1 = $1523;
        
        {ESLVal p2 = $1522;
        
        return ppPattern(p1).add(new ESLVal(" + ").add(ppPattern(p2)));
      }
      }
      }
      }
    case "PVar": {ESLVal $1521 = _v1039.termRef(0);
        ESLVal $1520 = _v1039.termRef(1);
        ESLVal $1519 = _v1039.termRef(2);
        
        {ESLVal l = $1521;
        
        {ESLVal n = $1520;
        
        {ESLVal t = $1519;
        
        return n;
      }
      }
      }
      }
    case "PTerm": {ESLVal $1516 = _v1039.termRef(0);
        ESLVal $1515 = _v1039.termRef(1);
        ESLVal $1514 = _v1039.termRef(2);
        ESLVal $1513 = _v1039.termRef(3);
        
        if($1514.isCons())
        {ESLVal $1517 = $1514.head();
          ESLVal $1518 = $1514.tail();
          
          {ESLVal l = $1516;
          
          {ESLVal n = $1515;
          
          {ESLVal ts = $1514;
          
          {ESLVal ps = $1513;
          
          return n.add(ppTypes(ts,ESLVal.list()).add(new ESLVal("").add(ppPatterns(ps))));
        }
        }
        }
        }
        }
      else if($1514.isNil())
        {ESLVal l = $1516;
          
          {ESLVal n = $1515;
          
          {ESLVal ps = $1513;
          
          return n.add(ppPatterns(ps));
        }
        }
        }
      else {ESLVal l = $1516;
          
          {ESLVal n = $1515;
          
          {ESLVal ts = $1514;
          
          {ESLVal ps = $1513;
          
          return n.add(ppTypes(ts,ESLVal.list()).add(new ESLVal("").add(ppPatterns(ps))));
        }
        }
        }
        }
      }
    case "PApplyType": {ESLVal $1512 = _v1039.termRef(0);
        ESLVal $1511 = _v1039.termRef(1);
        ESLVal $1510 = _v1039.termRef(2);
        
        {ESLVal l = $1512;
        
        {ESLVal _v1621 = $1511;
        
        {ESLVal ts = $1510;
        
        return ppPattern(_v1621).add(ppTypes(ts,ESLVal.list()));
      }
      }
      }
      }
    case "PNil": {ESLVal $1509 = _v1039.termRef(0);
        
        {ESLVal l = $1509;
        
        return new ESLVal("[]");
      }
      }
    case "PEmptySet": {ESLVal $1508 = _v1039.termRef(0);
        
        {ESLVal l = $1508;
        
        return new ESLVal("Set{}");
      }
      }
    case "PEmptyBag": {ESLVal $1507 = _v1039.termRef(0);
        
        {ESLVal l = $1507;
        
        return new ESLVal("Bag{}");
      }
      }
    case "PInt": {ESLVal $1506 = _v1039.termRef(0);
        ESLVal $1505 = _v1039.termRef(1);
        
        {ESLVal l = $1506;
        
        {ESLVal n = $1505;
        
        return new ESLVal("").add(n);
      }
      }
      }
    case "PBool": {ESLVal $1504 = _v1039.termRef(0);
        ESLVal $1503 = _v1039.termRef(1);
        
        {ESLVal l = $1504;
        
        {ESLVal b = $1503;
        
        return new ESLVal("").add(b);
      }
      }
      }
    case "PStr": {ESLVal $1502 = _v1039.termRef(0);
        ESLVal $1501 = _v1039.termRef(1);
        
        {ESLVal l = $1502;
        
        {ESLVal s = $1501;
        
        return s;
      }
      }
      }
    case "PCons": {ESLVal $1500 = _v1039.termRef(0);
        ESLVal $1499 = _v1039.termRef(1);
        ESLVal $1498 = _v1039.termRef(2);
        
        {ESLVal l = $1500;
        
        {ESLVal h = $1499;
        
        {ESLVal t = $1498;
        
        return ppPattern(h).add(new ESLVal(":").add(ppPattern(t)));
      }
      }
      }
      }
    case "PSetCons": {ESLVal $1497 = _v1039.termRef(0);
        ESLVal $1496 = _v1039.termRef(1);
        ESLVal $1495 = _v1039.termRef(2);
        
        {ESLVal l = $1497;
        
        {ESLVal p1 = $1496;
        
        {ESLVal p2 = $1495;
        
        return new ESLVal("Set{").add(ppPattern(p1).add(new ESLVal(" | ").add(ppPattern(p2).add(new ESLVal("}")))));
      }
      }
      }
      }
    case "PBagCons": {ESLVal $1494 = _v1039.termRef(0);
        ESLVal $1493 = _v1039.termRef(1);
        ESLVal $1492 = _v1039.termRef(2);
        
        {ESLVal l = $1494;
        
        {ESLVal p1 = $1493;
        
        {ESLVal p2 = $1492;
        
        return new ESLVal("Bag{").add(ppPattern(p1).add(new ESLVal(" | ").add(ppPattern(p2).add(new ESLVal("}")))));
      }
      }
      }
      }
      default: {ESLVal _v1622 = _v1039;
        
        return new ESLVal("<unknown: ").add(_v1622.add(new ESLVal(">")));
      }
    }
    }
  }
  private static ESLVal ppPattern = new ESLVal(new Function(new ESLVal("ppPattern"),null) { public ESLVal apply(ESLVal... args) { return ppPattern(args[0]); }});
  private static ESLVal ppPatterns(ESLVal ps) {
    
    return map.apply(ppPattern,ps);
  }
  private static ESLVal ppPatterns = new ESLVal(new Function(new ESLVal("ppPatterns"),null) { public ESLVal apply(ESLVal... args) { return ppPatterns(args[0]); }});
  private static ESLVal ppTypeEnv(ESLVal env) {
    
    {ESLVal[] s = new ESLVal[]{new ESLVal("[")};
      
      {{
      ESLVal _v1042 = env;
      while(_v1042.isCons()) {
        ESLVal _v1041 = _v1042.headVal;
        {ESLVal _v1040 = new ESLVal(new Function(new ESLVal("forp"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                {ESLVal _v1043 = _v1041;
                  
                  switch(_v1043.termName) {
                  case "Map": {ESLVal $1526 = _v1043.termRef(0);
                    ESLVal $1525 = _v1043.termRef(1);
                    
                    {ESLVal n = $1526;
                    
                    {ESLVal t = $1525;
                    
                    {s[0] = s[0].add(n.add(new ESLVal("->").add(ppType(t,env).add(new ESLVal(",")))));
                  return $null;}
                  }
                  }
                  }
                  default: {ESLVal $$$ = _v1043;
                    
                    return $null;
                  }
                }
                }
              }
            });
          
          _v1040.apply();
        }
        _v1042 = _v1042.tailVal;}
    }
    return s[0].add(new ESLVal("]"));}
    }
  }
  private static ESLVal ppTypeEnv = new ESLVal(new Function(new ESLVal("ppTypeEnv"),null) { public ESLVal apply(ESLVal... args) { return ppTypeEnv(args[0]); }});
  private static ESLVal ppTypes(ESLVal ts,ESLVal env) {
    
    return map.apply(ppType0(env),ts);
  }
  private static ESLVal ppTypes = new ESLVal(new Function(new ESLVal("ppTypes"),null) { public ESLVal apply(ESLVal... args) { return ppTypes(args[0],args[1]); }});
  private static ESLVal getTypeName(ESLVal t0,ESLVal env) {
    
    {ESLVal[] name = new ESLVal[]{$null};
      
      {{
      ESLVal _v1046 = env;
      while(_v1046.isCons()) {
        ESLVal _v1045 = _v1046.headVal;
        {ESLVal _v1044 = new ESLVal(new Function(new ESLVal("forp"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                {ESLVal _v1047 = _v1045;
                  
                  switch(_v1047.termName) {
                  case "Map": {ESLVal $1528 = _v1047.termRef(0);
                    ESLVal $1527 = _v1047.termRef(1);
                    
                    {ESLVal n = $1528;
                    
                    {ESLVal t = $1527;
                    
                    if(typeEqual.apply(t0,t).boolVal)
                    {name[0] = n;
                    return $null;}
                    else
                      return $null;
                  }
                  }
                  }
                  default: {ESLVal $$$ = _v1047;
                    
                    return $null;
                  }
                }
                }
              }
            });
          
          _v1044.apply();
        }
        _v1046 = _v1046.tailVal;}
    }
    return name[0];}
    }
  }
  private static ESLVal getTypeName = new ESLVal(new Function(new ESLVal("getTypeName"),null) { public ESLVal apply(ESLVal... args) { return getTypeName(args[0],args[1]); }});
  private static ESLVal ppType0(ESLVal env) {
    
    return new ESLVal(new Function(new ESLVal("fun371"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal t = $args[0];
      return ppType(t,env);
        }
      });
  }
  private static ESLVal ppType0 = new ESLVal(new Function(new ESLVal("ppType0"),null) { public ESLVal apply(ESLVal... args) { return ppType0(args[0]); }});
  private static ESLVal ppHandlers(ESLVal handlers,ESLVal env) {
    
    {ESLVal _v1048 = handlers;
      
      if(_v1048.isCons())
      {ESLVal $1529 = _v1048.head();
        ESLVal $1530 = _v1048.tail();
        
        switch($1529.termName) {
        case "MessageType": {ESLVal $1532 = $1529.termRef(0);
          ESLVal $1531 = $1529.termRef(1);
          
          if($1531.isCons())
          {ESLVal $1533 = $1531.head();
            ESLVal $1534 = $1531.tail();
            
            {ESLVal l = $1532;
            
            {ESLVal t = $1533;
            
            {ESLVal ts = $1534;
            
            {ESLVal hs = $1530;
            
            return ppType(t,env).add(new ESLVal("; ").add(ppHandlers(hs,env)));
          }
          }
          }
          }
          }
        else if($1531.isNil())
          return error(new ESLVal("case error at Pos(5504,5638)").add(ESLVal.list(_v1048)));
        else return error(new ESLVal("case error at Pos(5504,5638)").add(ESLVal.list(_v1048)));
        }
        default: return error(new ESLVal("case error at Pos(5504,5638)").add(ESLVal.list(_v1048)));
      }
      }
    else if(_v1048.isNil())
      return new ESLVal("");
    else return error(new ESLVal("case error at Pos(5504,5638)").add(ESLVal.list(_v1048)));
    }
  }
  private static ESLVal ppHandlers = new ESLVal(new Function(new ESLVal("ppHandlers"),null) { public ESLVal apply(ESLVal... args) { return ppHandlers(args[0],args[1]); }});
  private static ESLVal ppDecs(ESLVal decs,ESLVal env) {
    
    {ESLVal _v1049 = decs;
      
      if(_v1049.isCons())
      {ESLVal $1535 = _v1049.head();
        ESLVal $1536 = _v1049.tail();
        
        switch($1535.termName) {
        case "Dec": {ESLVal $1540 = $1535.termRef(0);
          ESLVal $1539 = $1535.termRef(1);
          ESLVal $1538 = $1535.termRef(2);
          ESLVal $1537 = $1535.termRef(3);
          
          {ESLVal l = $1540;
          
          {ESLVal n = $1539;
          
          {ESLVal t = $1538;
          
          {ESLVal d = $1537;
          
          {ESLVal _v1620 = $1536;
          
          return n.add(new ESLVal("::").add(ppType(t,env).add(new ESLVal("; ").add(ppDecs(_v1620,env)))));
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(5679,5793)").add(ESLVal.list(_v1049)));
      }
      }
    else if(_v1049.isNil())
      return new ESLVal("");
    else return error(new ESLVal("case error at Pos(5679,5793)").add(ESLVal.list(_v1049)));
    }
  }
  private static ESLVal ppDecs = new ESLVal(new Function(new ESLVal("ppDecs"),null) { public ESLVal apply(ESLVal... args) { return ppDecs(args[0],args[1]); }});
  private static ESLVal ppType(ESLVal t,ESLVal env) {
    
    if(getTypeName(t,env).neql($null).boolVal)
      return getTypeName(t,env);
      else
        {ESLVal _v1050 = t;
          
          switch(_v1050.termName) {
          case "ActType": {ESLVal $1610 = _v1050.termRef(0);
            ESLVal $1609 = _v1050.termRef(1);
            ESLVal $1608 = _v1050.termRef(2);
            
            {ESLVal l = $1610;
            
            {ESLVal decs = $1609;
            
            {ESLVal handlers = $1608;
            
            return new ESLVal("Act { ").add(ppHandlers(handlers,env).add(new ESLVal(" }")));
          }
          }
          }
          }
        case "ApplyType": {ESLVal $1607 = _v1050.termRef(0);
            ESLVal $1606 = _v1050.termRef(1);
            ESLVal $1605 = _v1050.termRef(2);
            
            {ESLVal l = $1607;
            
            {ESLVal n = $1606;
            
            {ESLVal args = $1605;
            
            return n.add(map.apply(ppType0(env),args));
          }
          }
          }
          }
        case "ApplyTypeFun": {ESLVal $1604 = _v1050.termRef(0);
            ESLVal $1603 = _v1050.termRef(1);
            ESLVal $1602 = _v1050.termRef(2);
            
            {ESLVal l = $1604;
            
            {ESLVal op = $1603;
            
            {ESLVal args = $1602;
            
            return ppType(op,env).add(map.apply(ppType0(env),args));
          }
          }
          }
          }
        case "ArrayType": {ESLVal $1601 = _v1050.termRef(0);
            ESLVal $1600 = _v1050.termRef(1);
            
            {ESLVal l = $1601;
            
            {ESLVal _v1619 = $1600;
            
            return new ESLVal("Array[").add(ppType(_v1619,env).add(new ESLVal("]")));
          }
          }
          }
        case "BagType": {ESLVal $1599 = _v1050.termRef(0);
            ESLVal $1598 = _v1050.termRef(1);
            
            {ESLVal l = $1599;
            
            {ESLVal _v1618 = $1598;
            
            return new ESLVal("Set{").add(ppType(_v1618,env).add(new ESLVal("}")));
          }
          }
          }
        case "BoolType": {ESLVal $1597 = _v1050.termRef(0);
            
            {ESLVal l = $1597;
            
            return new ESLVal("Bool");
          }
          }
        case "ExtendedAct": {ESLVal $1596 = _v1050.termRef(0);
            ESLVal $1595 = _v1050.termRef(1);
            ESLVal $1594 = _v1050.termRef(2);
            ESLVal $1593 = _v1050.termRef(3);
            
            {ESLVal l = $1596;
            
            {ESLVal parent = $1595;
            
            {ESLVal decs = $1594;
            
            {ESLVal handlers = $1593;
            
            return new ESLVal("Act extends ").add(ppType(parent,env).add(new ESLVal(" { ").add(ppHandlers(handlers,env).add(new ESLVal(" }")))));
          }
          }
          }
          }
          }
        case "FloatType": {ESLVal $1592 = _v1050.termRef(0);
            
            {ESLVal l = $1592;
            
            return new ESLVal("Float");
          }
          }
        case "FieldType": {ESLVal $1591 = _v1050.termRef(0);
            ESLVal $1590 = _v1050.termRef(1);
            ESLVal $1589 = _v1050.termRef(2);
            
            {ESLVal l = $1591;
            
            {ESLVal n = $1590;
            
            {ESLVal _v1617 = $1589;
            
            return n.add(new ESLVal("::").add(ppType(_v1617,env)));
          }
          }
          }
          }
        case "ForallType": {ESLVal $1588 = _v1050.termRef(0);
            ESLVal $1587 = _v1050.termRef(1);
            ESLVal $1586 = _v1050.termRef(2);
            
            {ESLVal l = $1588;
            
            {ESLVal ns = $1587;
            
            {ESLVal _v1616 = $1586;
            
            return new ESLVal("Forall").add(ns.add(new ESLVal(".").add(ppType(_v1616,env))));
          }
          }
          }
          }
        case "FunType": {ESLVal $1585 = _v1050.termRef(0);
            ESLVal $1584 = _v1050.termRef(1);
            ESLVal $1583 = _v1050.termRef(2);
            
            {ESLVal l = $1585;
            
            {ESLVal d = $1584;
            
            {ESLVal r = $1583;
            
            return map.apply(ppType0(env),d).add(new ESLVal("->").add(ppType(r,env)));
          }
          }
          }
          }
        case "TaggedFunType": {ESLVal $1582 = _v1050.termRef(0);
            ESLVal $1581 = _v1050.termRef(1);
            ESLVal $1580 = _v1050.termRef(2);
            ESLVal $1579 = _v1050.termRef(3);
            
            {ESLVal l = $1582;
            
            {ESLVal d = $1581;
            
            {ESLVal p = $1580;
            
            {ESLVal r = $1579;
            
            return map.apply(ppType0(env),d).add(new ESLVal("->").add(ppType(r,env)));
          }
          }
          }
          }
          }
        case "IntType": {ESLVal $1578 = _v1050.termRef(0);
            
            {ESLVal l = $1578;
            
            return new ESLVal("Int");
          }
          }
        case "ListType": {ESLVal $1577 = _v1050.termRef(0);
            ESLVal $1576 = _v1050.termRef(1);
            
            {ESLVal l = $1577;
            
            {ESLVal _v1615 = $1576;
            
            return new ESLVal("[").add(ppType(_v1615,env).add(new ESLVal("]")));
          }
          }
          }
        case "NullType": {ESLVal $1575 = _v1050.termRef(0);
            
            {ESLVal l = $1575;
            
            return new ESLVal("Null");
          }
          }
        case "ObserverType": {ESLVal $1574 = _v1050.termRef(0);
            ESLVal $1573 = _v1050.termRef(1);
            ESLVal $1572 = _v1050.termRef(2);
            
            {ESLVal l = $1574;
            
            {ESLVal s = $1573;
            
            {ESLVal m = $1572;
            
            return new ESLVal("Observer[").add(ppType(s,env).add(new ESLVal(",").add(ppType(m,env).add(new ESLVal("]")))));
          }
          }
          }
          }
        case "ObservedType": {ESLVal $1571 = _v1050.termRef(0);
            ESLVal $1570 = _v1050.termRef(1);
            ESLVal $1569 = _v1050.termRef(2);
            
            {ESLVal l = $1571;
            
            {ESLVal s = $1570;
            
            {ESLVal m = $1569;
            
            return new ESLVal("Observed[").add(ppType(s,env).add(new ESLVal(",").add(ppType(m,env).add(new ESLVal("]")))));
          }
          }
          }
          }
        case "RecType": {ESLVal $1568 = _v1050.termRef(0);
            ESLVal $1567 = _v1050.termRef(1);
            ESLVal $1566 = _v1050.termRef(2);
            
            {ESLVal l = $1568;
            
            {ESLVal n = $1567;
            
            {ESLVal _v1614 = $1566;
            
            return new ESLVal("rec ").add(n.add(new ESLVal(".").add(ppType(_v1614,env))));
          }
          }
          }
          }
        case "RecordType": {ESLVal $1565 = _v1050.termRef(0);
            ESLVal $1564 = _v1050.termRef(1);
            
            {ESLVal l = $1565;
            
            {ESLVal fs = $1564;
            
            return new ESLVal("{").add(ppDecs(fs,env).add(new ESLVal("}")));
          }
          }
          }
        case "SetType": {ESLVal $1563 = _v1050.termRef(0);
            ESLVal $1562 = _v1050.termRef(1);
            
            {ESLVal l = $1563;
            
            {ESLVal _v1613 = $1562;
            
            return new ESLVal("Set{").add(ppType(_v1613,env).add(new ESLVal("}")));
          }
          }
          }
        case "StrType": {ESLVal $1561 = _v1050.termRef(0);
            
            {ESLVal l = $1561;
            
            return new ESLVal("Str");
          }
          }
        case "TableType": {ESLVal $1560 = _v1050.termRef(0);
            ESLVal $1559 = _v1050.termRef(1);
            ESLVal $1558 = _v1050.termRef(2);
            
            {ESLVal l = $1560;
            
            {ESLVal k = $1559;
            
            {ESLVal v = $1558;
            
            return new ESLVal("Hash[").add(ppType(k,env).add(new ESLVal(",").add(ppType(v,env).add(new ESLVal("]")))));
          }
          }
          }
          }
        case "TermType": {ESLVal $1557 = _v1050.termRef(0);
            ESLVal $1556 = _v1050.termRef(1);
            ESLVal $1555 = _v1050.termRef(2);
            
            {ESLVal l = $1557;
            
            {ESLVal n = $1556;
            
            {ESLVal ts = $1555;
            
            return n.add(map.apply(ppType0(env),ts));
          }
          }
          }
          }
        case "TypeFun": {ESLVal $1554 = _v1050.termRef(0);
            ESLVal $1553 = _v1050.termRef(1);
            ESLVal $1552 = _v1050.termRef(2);
            
            {ESLVal l = $1554;
            
            {ESLVal ns = $1553;
            
            {ESLVal _v1612 = $1552;
            
            return new ESLVal("Fun").add(ns.add(new ESLVal(".").add(ppType(_v1612,env))));
          }
          }
          }
          }
        case "UnfoldType": {ESLVal $1551 = _v1050.termRef(0);
            ESLVal $1550 = _v1050.termRef(1);
            
            {ESLVal l = $1551;
            
            {ESLVal _v1611 = $1550;
            
            return new ESLVal("unfold ").add(ppType(_v1611,env));
          }
          }
          }
        case "UnionType": {ESLVal $1549 = _v1050.termRef(0);
            ESLVal $1548 = _v1050.termRef(1);
            
            {ESLVal l = $1549;
            
            {ESLVal ts = $1548;
            
            return new ESLVal("union ").add(map.apply(ppType0(env),ts));
          }
          }
          }
        case "VarType": {ESLVal $1547 = _v1050.termRef(0);
            ESLVal $1546 = _v1050.termRef(1);
            
            {ESLVal l = $1547;
            
            {ESLVal n = $1546;
            
            return n;
          }
          }
          }
        case "VoidType": {ESLVal $1545 = _v1050.termRef(0);
            
            {ESLVal l = $1545;
            
            return new ESLVal("Void");
          }
          }
        case "UnionRef": {ESLVal $1544 = _v1050.termRef(0);
            ESLVal $1543 = _v1050.termRef(1);
            ESLVal $1542 = _v1050.termRef(2);
            
            {ESLVal l = $1544;
            
            {ESLVal _v1610 = $1543;
            
            {ESLVal n = $1542;
            
            return ppType(_v1610,env).add(new ESLVal(".").add(n));
          }
          }
          }
          }
        case "TypeClosure": {ESLVal $1541 = _v1050.termRef(0);
            
            {ESLVal f = $1541;
            
            return f.add(new ESLVal(""));
          }
          }
          default: {ESLVal x = _v1050;
            
            return new ESLVal("<unknown ").add(x.add(new ESLVal(">")));
          }
        }
        }
  }
  private static ESLVal ppType = new ESLVal(new Function(new ESLVal("ppType"),null) { public ESLVal apply(ESLVal... args) { return ppType(args[0],args[1]); }});
  private static ESLVal typeEnv(ESLVal defs) {
    
    {ESLVal _v1051 = defs;
      
      if(_v1051.isCons())
      {ESLVal $1611 = _v1051.head();
        ESLVal $1612 = _v1051.tail();
        
        switch($1611.termName) {
        case "TypeBind": {ESLVal $1620 = $1611.termRef(0);
          ESLVal $1619 = $1611.termRef(1);
          ESLVal $1618 = $1611.termRef(2);
          ESLVal $1617 = $1611.termRef(3);
          
          {ESLVal l = $1620;
          
          {ESLVal n = $1619;
          
          {ESLVal t = $1618;
          
          {ESLVal e = $1617;
          
          {ESLVal ds = $1612;
          
          return typeEnv(ds).cons(new ESLVal("Map",n,t));
        }
        }
        }
        }
        }
        }
      case "DataBind": {ESLVal $1616 = $1611.termRef(0);
          ESLVal $1615 = $1611.termRef(1);
          ESLVal $1614 = $1611.termRef(2);
          ESLVal $1613 = $1611.termRef(3);
          
          {ESLVal l = $1616;
          
          {ESLVal n = $1615;
          
          {ESLVal t = $1614;
          
          {ESLVal e = $1613;
          
          {ESLVal ds = $1612;
          
          return typeEnv(ds).cons(new ESLVal("Map",n,t));
        }
        }
        }
        }
        }
        }
        default: {ESLVal b = $1611;
          
          {ESLVal ds = $1612;
          
          return typeEnv(ds);
        }
        }
      }
      }
    else if(_v1051.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(8067,8310)").add(ESLVal.list(_v1051)));
    }
  }
  private static ESLVal typeEnv = new ESLVal(new Function(new ESLVal("typeEnv"),null) { public ESLVal apply(ESLVal... args) { return typeEnv(args[0]); }});
  private static ESLVal cnstrEnv(ESLVal defs,ESLVal env) {
    
    {ESLVal _v1052 = defs;
      
      if(_v1052.isCons())
      {ESLVal $1621 = _v1052.head();
        ESLVal $1622 = _v1052.tail();
        
        switch($1621.termName) {
        case "TypeBind": {ESLVal $1630 = $1621.termRef(0);
          ESLVal $1629 = $1621.termRef(1);
          ESLVal $1628 = $1621.termRef(2);
          ESLVal $1627 = $1621.termRef(3);
          
          switch($1628.termName) {
          case "RecType": {ESLVal $1635 = $1628.termRef(0);
            ESLVal $1634 = $1628.termRef(1);
            ESLVal $1633 = $1628.termRef(2);
            
            switch($1633.termName) {
            case "UnionType": {ESLVal $1637 = $1633.termRef(0);
              ESLVal $1636 = $1633.termRef(1);
              
              {ESLVal l = $1630;
              
              {ESLVal n = $1629;
              
              {ESLVal ll = $1635;
              
              {ESLVal m = $1634;
              
              {ESLVal lll = $1637;
              
              {ESLVal ts = $1636;
              
              {ESLVal e = $1627;
              
              {ESLVal ds = $1622;
              
              return getConstructors(l,lookupType.apply(n,env),lookupType.apply(n,env)).add(cnstrEnv(ds,env));
            }
            }
            }
            }
            }
            }
            }
            }
            }
            default: {ESLVal l = $1630;
              
              {ESLVal n = $1629;
              
              {ESLVal t = $1628;
              
              {ESLVal e = $1627;
              
              {ESLVal ds = $1622;
              
              return cnstrEnv(ds,env);
            }
            }
            }
            }
            }
          }
          }
        case "UnionType": {ESLVal $1632 = $1628.termRef(0);
            ESLVal $1631 = $1628.termRef(1);
            
            {ESLVal l = $1630;
            
            {ESLVal n = $1629;
            
            {ESLVal lll = $1632;
            
            {ESLVal ts = $1631;
            
            {ESLVal e = $1627;
            
            {ESLVal ds = $1622;
            
            return getConstructors(l,lookupType.apply(n,env),lookupType.apply(n,env)).add(cnstrEnv(ds,env));
          }
          }
          }
          }
          }
          }
          }
          default: {ESLVal l = $1630;
            
            {ESLVal n = $1629;
            
            {ESLVal t = $1628;
            
            {ESLVal e = $1627;
            
            {ESLVal ds = $1622;
            
            return cnstrEnv(ds,env);
          }
          }
          }
          }
          }
        }
        }
      case "DataBind": {ESLVal $1626 = $1621.termRef(0);
          ESLVal $1625 = $1621.termRef(1);
          ESLVal $1624 = $1621.termRef(2);
          ESLVal $1623 = $1621.termRef(3);
          
          {ESLVal l = $1626;
          
          {ESLVal n = $1625;
          
          {ESLVal t = $1624;
          
          {ESLVal e = $1623;
          
          {ESLVal ds = $1622;
          
          return getConstructors(l,lookupType.apply(n,env),lookupType.apply(n,env)).add(cnstrEnv(ds,env));
        }
        }
        }
        }
        }
        }
        default: {ESLVal b = $1621;
          
          {ESLVal ds = $1622;
          
          return cnstrEnv(ds,env);
        }
        }
      }
      }
    else if(_v1052.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(8442,9075)").add(ESLVal.list(_v1052)));
    }
  }
  private static ESLVal cnstrEnv = new ESLVal(new Function(new ESLVal("cnstrEnv"),null) { public ESLVal apply(ESLVal... args) { return cnstrEnv(args[0],args[1]); }});
  private static ESLVal getConstructors(ESLVal l,ESLVal dataType,ESLVal t) {
    
    {ESLVal _v1053 = t;
      
      switch(_v1053.termName) {
      case "RecType": {ESLVal $1645 = _v1053.termRef(0);
        ESLVal $1644 = _v1053.termRef(1);
        ESLVal $1643 = _v1053.termRef(2);
        
        {ESLVal _v1607 = $1645;
        
        {ESLVal n = $1644;
        
        {ESLVal _v1608 = $1643;
        
        return getConstructors(_v1607,dataType,_v1608);
      }
      }
      }
      }
    case "TypeFun": {ESLVal $1642 = _v1053.termRef(0);
        ESLVal $1641 = _v1053.termRef(1);
        ESLVal $1640 = _v1053.termRef(2);
        
        {ESLVal _v1605 = $1642;
        
        {ESLVal ns = $1641;
        
        {ESLVal _v1606 = $1640;
        
        return getConstructors(_v1605,dataType,_v1606);
      }
      }
      }
      }
    case "UnionType": {ESLVal $1639 = _v1053.termRef(0);
        ESLVal $1638 = _v1053.termRef(1);
        
        {ESLVal _v1602 = $1639;
        
        {ESLVal ts = $1638;
        
        return map.apply(new ESLVal(new Function(new ESLVal("fun372"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1603 = $args[0];
        {ESLVal _v1054 = _v1603;
              
              switch(_v1054.termName) {
              case "TermType": {ESLVal $1648 = _v1054.termRef(0);
                ESLVal $1647 = _v1054.termRef(1);
                ESLVal $1646 = _v1054.termRef(2);
                
                {ESLVal _v1604 = $1648;
                
                {ESLVal n = $1647;
                
                {ESLVal tts = $1646;
                
                return new ESLVal("Map",n,dataType);
              }
              }
              }
              }
              default: return error(new ESLVal("case error at Pos(9594,9660)").add(ESLVal.list(_v1054)));
            }
            }
          }
        }),ts);
      }
      }
      }
      default: {ESLVal _v1609 = _v1053;
        
        return error(new ESLVal("TypeError",l,new ESLVal("cannot extract constructors from ").add(ppType(_v1609,ESLVal.list()))));
      }
    }
    }
  }
  private static ESLVal getConstructors = new ESLVal(new Function(new ESLVal("getConstructors"),null) { public ESLVal apply(ESLVal... args) { return getConstructors(args[0],args[1],args[2]); }});
  private static ESLVal checkFreeTypes(ESLVal e) {
    
    {ESLVal dom = typeEnvDom.apply(e);
      ESLVal ran = typeEnvRan.apply(e);
      
      {ESLVal freeNames = removeAll.apply(dom,flatten.apply(map.apply(typeFV,ran)));
      
      if(freeNames.eql($nil).boolVal)
      return $null;
      else
        return error(new ESLVal("TypeError",new ESLVal("Pos",$zero,$zero),new ESLVal("Unbound Types: ").add(freeNames)));
    }
    }
  }
  private static ESLVal checkFreeTypes = new ESLVal(new Function(new ESLVal("checkFreeTypes"),null) { public ESLVal apply(ESLVal... args) { return checkFreeTypes(args[0]); }});
  private static ESLVal checkSingletonTypes(ESLVal e) {
    
    {ESLVal _v1055 = e;
      
      if(_v1055.isCons())
      {ESLVal $1649 = _v1055.head();
        ESLVal $1650 = _v1055.tail();
        
        switch($1649.termName) {
        case "Map": {ESLVal $1652 = $1649.termRef(0);
          ESLVal $1651 = $1649.termRef(1);
          
          {ESLVal n = $1652;
          
          {ESLVal t = $1651;
          
          {ESLVal _v1601 = $1650;
          
          if(member.apply(n,typeEnvDom.apply(_v1601)).boolVal)
          return error(new ESLVal("TypeError",new ESLVal("Pos",$zero,$zero),new ESLVal("Duplicate type name: ").add(n)));
          else
            return checkSingletonTypes(_v1601);
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(10364,10585)").add(ESLVal.list(_v1055)));
      }
      }
    else if(_v1055.isNil())
      return $null;
    else return error(new ESLVal("case error at Pos(10364,10585)").add(ESLVal.list(_v1055)));
    }
  }
  private static ESLVal checkSingletonTypes = new ESLVal(new Function(new ESLVal("checkSingletonTypes"),null) { public ESLVal apply(ESLVal... args) { return checkSingletonTypes(args[0]); }});
  private static ESLVal checkSingletonConstructors(ESLVal cnstrEnv) {
    
    {ESLVal _v1056 = cnstrEnv;
      
      if(_v1056.isCons())
      {ESLVal $1653 = _v1056.head();
        ESLVal $1654 = _v1056.tail();
        
        switch($1653.termName) {
        case "Map": {ESLVal $1656 = $1653.termRef(0);
          ESLVal $1655 = $1653.termRef(1);
          
          {ESLVal n = $1656;
          
          {ESLVal t = $1655;
          
          {ESLVal _v1594 = $1654;
          
          if(member.apply(n,typeEnvDom.apply(_v1594)).boolVal)
          { LetRec letrec = new LetRec() {
            ESLVal throwError = new ESLVal(new Function(new ESLVal("throwError"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal _v1595 = $args[0];
              {ESLVal _v1057 = _v1595;
                    
                    switch(_v1057.termName) {
                    case "UnionType": {ESLVal $1667 = _v1057.termRef(0);
                      ESLVal $1666 = _v1057.termRef(1);
                      
                      {ESLVal l = $1667;
                      
                      {ESLVal ts = $1666;
                      
                      return error(new ESLVal("TypeError",l,new ESLVal("Duplicate constructor name: ").add(n)));
                    }
                    }
                    }
                  case "ForallType": {ESLVal $1665 = _v1057.termRef(0);
                      ESLVal $1664 = _v1057.termRef(1);
                      ESLVal $1663 = _v1057.termRef(2);
                      
                      {ESLVal l = $1665;
                      
                      {ESLVal ns = $1664;
                      
                      {ESLVal _v1599 = $1663;
                      
                      return throwError.apply(_v1599);
                    }
                    }
                    }
                    }
                  case "RecType": {ESLVal $1662 = _v1057.termRef(0);
                      ESLVal $1661 = _v1057.termRef(1);
                      ESLVal $1660 = _v1057.termRef(2);
                      
                      {ESLVal l = $1662;
                      
                      {ESLVal _v1597 = $1661;
                      
                      {ESLVal _v1598 = $1660;
                      
                      return throwError.apply(_v1598);
                    }
                    }
                    }
                    }
                  case "TypeFun": {ESLVal $1659 = _v1057.termRef(0);
                      ESLVal $1658 = _v1057.termRef(1);
                      ESLVal $1657 = _v1057.termRef(2);
                      
                      {ESLVal l = $1659;
                      
                      {ESLVal ns = $1658;
                      
                      {ESLVal _v1596 = $1657;
                      
                      return throwError.apply(_v1596);
                    }
                    }
                    }
                    }
                    default: {ESLVal _v1600 = _v1057;
                      
                      return error(new ESLVal("Duplicate constructor name: ").add(n.add(new ESLVal(" ").add(_v1600))));
                    }
                  }
                  }
                }
              });
            
            public ESLVal get(String name) {
              switch(name) {
                case "throwError": return throwError;
                
                default: throw new Error("cannot find letrec binding");
              }
              }
            };
          ESLVal throwError = letrec.get("throwError");
          
            return throwError.apply(t);}
          
          else
            return checkSingletonConstructors(_v1594);
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(10698,11353)").add(ESLVal.list(_v1056)));
      }
      }
    else if(_v1056.isNil())
      return $null;
    else return error(new ESLVal("case error at Pos(10698,11353)").add(ESLVal.list(_v1056)));
    }
  }
  private static ESLVal checkSingletonConstructors = new ESLVal(new Function(new ESLVal("checkSingletonConstructors"),null) { public ESLVal apply(ESLVal... args) { return checkSingletonConstructors(args[0]); }});
  private static ESLVal valueDefs(ESLVal defs) {
    
    {ESLVal _v1058 = defs;
      
      if(_v1058.isCons())
      {ESLVal $1668 = _v1058.head();
        ESLVal $1669 = _v1058.tail();
        
        switch($1668.termName) {
        case "TypeBind": {ESLVal $1681 = $1668.termRef(0);
          ESLVal $1680 = $1668.termRef(1);
          ESLVal $1679 = $1668.termRef(2);
          ESLVal $1678 = $1668.termRef(3);
          
          {ESLVal l = $1681;
          
          {ESLVal n = $1680;
          
          {ESLVal t = $1679;
          
          {ESLVal e = $1678;
          
          {ESLVal ds = $1669;
          
          return valueDefs(ds);
        }
        }
        }
        }
        }
        }
      case "DataBind": {ESLVal $1677 = $1668.termRef(0);
          ESLVal $1676 = $1668.termRef(1);
          ESLVal $1675 = $1668.termRef(2);
          ESLVal $1674 = $1668.termRef(3);
          
          {ESLVal l1 = $1677;
          
          {ESLVal n = $1676;
          
          {ESLVal t = $1675;
          
          {ESLVal e = $1674;
          
          {ESLVal ds = $1669;
          
          return valueDefs(ds);
        }
        }
        }
        }
        }
        }
      case "CnstrBind": {ESLVal $1673 = $1668.termRef(0);
          ESLVal $1672 = $1668.termRef(1);
          ESLVal $1671 = $1668.termRef(2);
          ESLVal $1670 = $1668.termRef(3);
          
          {ESLVal l1 = $1673;
          
          {ESLVal n = $1672;
          
          {ESLVal t = $1671;
          
          {ESLVal e = $1670;
          
          {ESLVal ds = $1669;
          
          return valueDefs(ds);
        }
        }
        }
        }
        }
        }
        default: {ESLVal b = $1668;
          
          {ESLVal ds = $1669;
          
          return valueDefs(ds).cons(b);
        }
        }
      }
      }
    else if(_v1058.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(11393,11703)").add(ESLVal.list(_v1058)));
    }
  }
  private static ESLVal valueDefs = new ESLVal(new Function(new ESLVal("valueDefs"),null) { public ESLVal apply(ESLVal... args) { return valueDefs(args[0]); }});
  private static ESLVal valueDefsToTEnv(ESLVal defs,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal _v1059 = defs;
      
      if(_v1059.isCons())
      {ESLVal $1682 = _v1059.head();
        ESLVal $1683 = _v1059.tail();
        
        switch($1682.termName) {
        case "FunBinds": {ESLVal $1697 = $1682.termRef(0);
          ESLVal $1696 = $1682.termRef(1);
          
          if($1696.isCons())
          {ESLVal $1698 = $1696.head();
            ESLVal $1699 = $1696.tail();
            
            switch($1698.termName) {
            case "FunCase": {ESLVal $1704 = $1698.termRef(0);
              ESLVal $1703 = $1698.termRef(1);
              ESLVal $1702 = $1698.termRef(2);
              ESLVal $1701 = $1698.termRef(3);
              ESLVal $1700 = $1698.termRef(4);
              
              {ESLVal n = $1697;
              
              {ESLVal l = $1704;
              
              {ESLVal args = $1703;
              
              {ESLVal t = $1702;
              
              {ESLVal g = $1701;
              
              {ESLVal e = $1700;
              
              {ESLVal cases = $1699;
              
              {ESLVal ds = $1683;
              
              return valueDefsToTEnv(ds,selfType,valueEnv,cnstrEnv,typeEnv).cons(new ESLVal("Map",n,substTypeEnv.apply(typeEnv,t)));
            }
            }
            }
            }
            }
            }
            }
            }
            }
            default: return error(new ESLVal("case error at Pos(11810,12343)").add(ESLVal.list(_v1059)));
          }
          }
        else if($1696.isNil())
          return error(new ESLVal("case error at Pos(11810,12343)").add(ESLVal.list(_v1059)));
        else return error(new ESLVal("case error at Pos(11810,12343)").add(ESLVal.list(_v1059)));
        }
      case "FunBind": {ESLVal $1695 = $1682.termRef(0);
          ESLVal $1694 = $1682.termRef(1);
          ESLVal $1693 = $1682.termRef(2);
          ESLVal $1692 = $1682.termRef(3);
          ESLVal $1691 = $1682.termRef(4);
          ESLVal $1690 = $1682.termRef(5);
          ESLVal $1689 = $1682.termRef(6);
          
          {ESLVal l = $1695;
          
          {ESLVal n = $1694;
          
          {ESLVal ps = $1693;
          
          {ESLVal t = $1692;
          
          {ESLVal st = $1691;
          
          {ESLVal b = $1690;
          
          {ESLVal g = $1689;
          
          {ESLVal ds = $1683;
          
          return valueDefsToTEnv(ds,selfType,valueEnv,cnstrEnv,typeEnv).cons(new ESLVal("Map",n,substTypeEnv.apply(typeEnv,t)));
        }
        }
        }
        }
        }
        }
        }
        }
        }
      case "Binding": {ESLVal $1688 = $1682.termRef(0);
          ESLVal $1687 = $1682.termRef(1);
          ESLVal $1686 = $1682.termRef(2);
          ESLVal $1685 = $1682.termRef(3);
          ESLVal $1684 = $1682.termRef(4);
          
          {ESLVal l = $1688;
          
          {ESLVal n = $1687;
          
          {ESLVal t = $1686;
          
          {ESLVal st = $1685;
          
          {ESLVal e = $1684;
          
          {ESLVal ds = $1683;
          
          return valueDefsToTEnv(ds,selfType,valueEnv,cnstrEnv,typeEnv).cons(new ESLVal("Map",n,substTypeEnv.apply(typeEnv,t)));
        }
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(11810,12343)").add(ESLVal.list(_v1059)));
      }
      }
    else if(_v1059.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(11810,12343)").add(ESLVal.list(_v1059)));
    }
  }
  private static ESLVal valueDefsToTEnv = new ESLVal(new Function(new ESLVal("valueDefsToTEnv"),null) { public ESLVal apply(ESLVal... args) { return valueDefsToTEnv(args[0],args[1],args[2],args[3],args[4]); }});
  private static ESLVal getCache() {
    
    {ESLVal cache = edb.ref("getProperty").apply(new ESLVal("typeCheckCache"));
      
      if(cache.eql($null).boolVal)
      return emptyTable;
      else
        return cache;
    }
  }
  private static ESLVal getCache = new ESLVal(new Function(new ESLVal("getCache"),null) { public ESLVal apply(ESLVal... args) { return getCache(); }});
  private static ESLVal setCache(ESLVal cache) {
    
    return edb.ref("setProperty").apply(new ESLVal("typeCheckCache"),cache);
  }
  private static ESLVal setCache = new ESLVal(new Function(new ESLVal("setCache"),null) { public ESLVal apply(ESLVal... args) { return setCache(args[0]); }});
  private static ESLVal updateCache(ESLVal path,ESLVal record,ESLVal cache) {
    
    {ESLVal _v1593 = addEntry.apply(path,record,cache);
      
      {setCache(_v1593);
    return _v1593;}
    }
  }
  private static ESLVal updateCache = new ESLVal(new Function(new ESLVal("updateCache"),null) { public ESLVal apply(ESLVal... args) { return updateCache(args[0],args[1],args[2]); }});
  private static ESLVal recordJustType(ESLVal e,ESLVal t) {
    
    {setTypeInfo.apply(e,new ESLVal("JustType",t));
    return t;}
  }
  private static ESLVal recordJustType = new ESLVal(new Function(new ESLVal("recordJustType"),null) { public ESLVal apply(ESLVal... args) { return recordJustType(args[0],args[1]); }});
  public static ESLVal typeCheckModule(ESLVal path) {
    
    {print.apply(new ESLVal("[ type check ").add(path.add(new ESLVal("]"))));
    return typeCheckModuleInternal(path,getCache(),new ESLVal(new Function(new ESLVal("fun373"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal cache = $args[0];
      ESLVal valueEnv = $args[1];
      ESLVal cnstrEnv = $args[2];
      ESLVal typeEnv = $args[3];
      return $null;
        }
      }));}
  }
  public static ESLVal typeCheckModule = new ESLVal(new Function(new ESLVal("typeCheckModule"),null) { public ESLVal apply(ESLVal... args) { return typeCheckModule(args[0]); }});
  private static ESLVal typeCheckModuleInternal(ESLVal path,ESLVal cache,ESLVal handler) {
    
    if(hasEntry.apply(path,cache).boolVal)
      {ESLVal _v1060 = lookup.apply(path,cache);
        
        switch(_v1060.termName) {
        case "Typed": {ESLVal $1708 = _v1060.termRef(0);
          ESLVal $1707 = _v1060.termRef(1);
          ESLVal $1706 = _v1060.termRef(2);
          ESLVal $1705 = _v1060.termRef(3);
          
          {ESLVal m = $1708;
          
          {ESLVal vEnv = $1707;
          
          {ESLVal cEnv = $1706;
          
          {ESLVal tEnv = $1705;
          
          return handler.apply(cache,vEnv,cEnv,tEnv);
        }
        }
        }
        }
        }
      case "Undefined": {
          return error(new ESLVal("recursive reference to ").add(path));
        }
        default: return error(new ESLVal("case error at Pos(13424,13658)").add(ESLVal.list(_v1060)));
      }
      }
      else
        {ESLVal m = parse.apply(path);
          
          return typeCheckModuleCache(m,updateCache(path,new ESLVal("Undefined",new ESLVal[]{}),cache),new ESLVal(new Function(new ESLVal("fun374"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1589 = $args[0];
          ESLVal _v1590 = $args[1];
          ESLVal _v1591 = $args[2];
          ESLVal _v1592 = $args[3];
          return handler.apply(updateCache(path,new ESLVal("Typed",m,_v1590,_v1591,_v1592),_v1589),_v1590,_v1591,_v1592);
            }
          }));
        }
  }
  private static ESLVal typeCheckModuleInternal = new ESLVal(new Function(new ESLVal("typeCheckModuleInternal"),null) { public ESLVal apply(ESLVal... args) { return typeCheckModuleInternal(args[0],args[1],args[2]); }});
  public static ESLVal typeCheckEntryPoint(ESLVal module) {
    
    return typeCheckModuleCache(module,getCache(),new ESLVal(new Function(new ESLVal("fun375"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal cache = $args[0];
      ESLVal valueEnv = $args[1];
      ESLVal cnstrEnv = $args[2];
      ESLVal typeEnv = $args[3];
      return $null;
        }
      }));
  }
  public static ESLVal typeCheckEntryPoint = new ESLVal(new Function(new ESLVal("typeCheckEntryPoint"),null) { public ESLVal apply(ESLVal... args) { return typeCheckEntryPoint(args[0]); }});
  private static ESLVal typeCheckModuleCache(ESLVal module,ESLVal cache,ESLVal handler) {
    
    return typeCheckModule0(module,cache,new ESLVal(new Function(new ESLVal("fun376"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal _v1585 = $args[0];
      ESLVal _v1586 = $args[1];
      ESLVal _v1587 = $args[2];
      ESLVal _v1588 = $args[3];
      {ESLVal _v1061 = module;
            
            switch(_v1061.termName) {
            case "Module": {ESLVal $1715 = _v1061.termRef(0);
              ESLVal $1714 = _v1061.termRef(1);
              ESLVal $1713 = _v1061.termRef(2);
              ESLVal $1712 = _v1061.termRef(3);
              ESLVal $1711 = _v1061.termRef(4);
              ESLVal $1710 = _v1061.termRef(5);
              ESLVal $1709 = _v1061.termRef(6);
              
              {ESLVal path = $1715;
              
              {ESLVal name = $1714;
              
              {ESLVal exports = $1713;
              
              {ESLVal imports = $1712;
              
              {ESLVal x = $1711;
              
              {ESLVal y = $1710;
              
              {ESLVal defs = $1709;
              
              return handler.apply(_v1585,restrictTypeEnv.apply(_v1586,exports),restrictTypeEnv.apply(_v1587,exports),restrictTypeEnv.apply(_v1588,exports));
            }
            }
            }
            }
            }
            }
            }
            }
            default: return error(new ESLVal("case error at Pos(14649,14907)").add(ESLVal.list(_v1061)));
          }
          }
        }
      }));
  }
  private static ESLVal typeCheckModuleCache = new ESLVal(new Function(new ESLVal("typeCheckModuleCache"),null) { public ESLVal apply(ESLVal... args) { return typeCheckModuleCache(args[0],args[1],args[2]); }});
  private static ESLVal typeCheckModule0(ESLVal module,ESLVal cache,ESLVal handler) {
    
    { LetRec letrec = new LetRec() {
      ESLVal _v1564 = new ESLVal(new Function(new ESLVal("processImports"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1572 = $args[0];
        ESLVal _v1573 = $args[1];
        ESLVal _v1574 = $args[2];
        {ESLVal _v1062 = _v1572;
              
              if(_v1062.isCons())
              {ESLVal $1716 = _v1062.head();
                ESLVal $1717 = _v1062.tail();
                
                {ESLVal path = $1716;
                
                {ESLVal _v1575 = $1717;
                
                {ESLVal _v1576 = _v1575;
                
                return typeCheckModuleInternal(path,_v1573,new ESLVal(new Function(new ESLVal("fun377"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal _v1577 = $args[0];
                ESLVal _v1578 = $args[1];
                ESLVal _v1579 = $args[2];
                ESLVal _v1580 = $args[3];
                return _v1564.apply(_v1576,_v1577,new ESLVal(new Function(new ESLVal("fun378"),getSelf()) {
                        public ESLVal apply(ESLVal... $args) {
                          ESLVal _v1581 = $args[0];
                      ESLVal _v1582 = $args[1];
                      ESLVal _v1583 = $args[2];
                      ESLVal _v1584 = $args[3];
                      return _v1574.apply(_v1581,_v1582.add(_v1578),_v1583.add(_v1579),_v1584.add(_v1580));
                        }
                      }));
                  }
                }));
              }
              }
              }
              }
            else if(_v1062.isNil())
              return _v1574.apply(_v1573,$nil,$nil,$nil);
            else return error(new ESLVal("case error at Pos(15287,15844)").add(ESLVal.list(_v1062)));
            }
          }
        });
      ESLVal _v1565 = new ESLVal(new Function(new ESLVal("main"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            {ESLVal _v1063 = module;
              
              switch(_v1063.termName) {
              case "Module": {ESLVal $1724 = _v1063.termRef(0);
                ESLVal $1723 = _v1063.termRef(1);
                ESLVal $1722 = _v1063.termRef(2);
                ESLVal $1721 = _v1063.termRef(3);
                ESLVal $1720 = _v1063.termRef(4);
                ESLVal $1719 = _v1063.termRef(5);
                ESLVal $1718 = _v1063.termRef(6);
                
                {ESLVal path = $1724;
                
                {ESLVal name = $1723;
                
                {ESLVal exports = $1722;
                
                {ESLVal imports = $1721;
                
                {ESLVal x = $1720;
                
                {ESLVal y = $1719;
                
                {ESLVal defs = $1718;
                
                return _v1564.apply(imports,cache,new ESLVal(new Function(new ESLVal("fun379"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal _v1566 = $args[0];
                ESLVal _v1567 = $args[1];
                ESLVal _v1568 = $args[2];
                ESLVal _v1569 = $args[3];
                {ESLVal _v1570 = typeEnv(defs);
                      ESLVal _v1571 = mergeFunDefs.apply(defs);
                      
                      {resetTypeInfo.apply();
                    checkDupBindings(_v1571);
                    checkFreeTypes(_v1570.add(_v1569.add(tenv0)));
                    checkSingletonTypes(_v1570);
                    {ESLVal typeEnv = recTypes(_v1570.add(_v1569.add(tenv0)));
                      
                      {ESLVal cnstrEnv = cnstrEnv(_v1571,typeEnv).add(_v1568.add(cnstrEnv0));
                      
                      {checkSingletonConstructors(cnstrEnv);
                    {ESLVal valueEnv = typeCheckValues(valueDefs(_v1571),new ESLVal("NullType",p0),_v1567,typeEnv,cnstrEnv);
                      
                      return handler.apply(_v1566,valueEnv,cnstrEnv,typeEnv);
                    }}
                    }
                    }}
                    }
                  }
                }));
              }
              }
              }
              }
              }
              }
              }
              }
              default: return error(new ESLVal("case error at Pos(15873,17399)").add(ESLVal.list(_v1063)));
            }
            }
          }
        });
      
      public ESLVal get(String name) {
        switch(name) {
          case "_v1564": return _v1564;
          
          case "_v1565": return _v1565;
          
          default: throw new Error("cannot find letrec binding");
        }
        }
      };
    ESLVal _v1564 = letrec.get("_v1564");
    
    ESLVal _v1565 = letrec.get("_v1565");
    
      return _v1565.apply();}
    
  }
  private static ESLVal typeCheckModule0 = new ESLVal(new Function(new ESLVal("typeCheckModule0"),null) { public ESLVal apply(ESLVal... args) { return typeCheckModule0(args[0],args[1],args[2]); }});
  private static ESLVal typeCheckValues(ESLVal valueDefs,ESLVal selfType,ESLVal ivalueEnv,ESLVal typeEnv,ESLVal cnstrEnv) {
    
    {ESLVal valueEnv = valueDefsToTEnv(valueDefs,selfType,$nil,cnstrEnv,typeEnv).add(ivalueEnv.add(env0));
      
      {{
      ESLVal _v1064 = valueDefs;
      while(_v1064.isCons()) {
        ESLVal def = _v1064.headVal;
        typeCheckDef(def,selfType,valueEnv,valueEnv,cnstrEnv,typeEnv);
        _v1064 = _v1064.tailVal;}
    }
    return valueEnv;}
    }
  }
  private static ESLVal typeCheckValues = new ESLVal(new Function(new ESLVal("typeCheckValues"),null) { public ESLVal apply(ESLVal... args) { return typeCheckValues(args[0],args[1],args[2],args[3],args[4]); }});
  private static ESLVal genericize(ESLVal l,ESLVal t) {
    
    if(length.apply(typeFV(t)).eql($zero).boolVal)
      return t;
      else
        return new ESLVal("ForallType",l,typeFV(t),t);
  }
  private static ESLVal genericize = new ESLVal(new Function(new ESLVal("genericize"),null) { public ESLVal apply(ESLVal... args) { return genericize(args[0],args[1]); }});
  private static ESLVal checkPatterns(ESLVal l,ESLVal ps) {
    
    {ESLVal names = new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal p = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = patternNames.apply(p);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(ps);
      
      if(removeDups.apply(names).neql(names).boolVal)
      return error(new ESLVal("TypeError",l,new ESLVal("duplicate pattern variables")));
      else
        return $null;
    }
  }
  private static ESLVal checkPatterns = new ESLVal(new Function(new ESLVal("checkPatterns"),null) { public ESLVal apply(ESLVal... args) { return checkPatterns(args[0],args[1]); }});
  private static ESLVal typeCheckDef(ESLVal def,ESLVal selfType,ESLVal baseValueEnv,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal _v1065 = def;
      
      switch(_v1065.termName) {
      case "FunBinds": {ESLVal $1738 = _v1065.termRef(0);
        ESLVal $1737 = _v1065.termRef(1);
        
        {ESLVal n = $1738;
        
        {ESLVal cases = $1737;
        
        { LetRec letrec = new LetRec() {
        ESLVal checkArities = new ESLVal(new Function(new ESLVal("checkArities"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1561 = $args[0];
          ESLVal _v1562 = $args[1];
          {ESLVal _v1069 = _v1561;
                
                if(_v1069.isCons())
                {ESLVal $1748 = _v1069.head();
                  ESLVal $1749 = _v1069.tail();
                  
                  switch($1748.termName) {
                  case "FunCase": {ESLVal $1754 = $1748.termRef(0);
                    ESLVal $1753 = $1748.termRef(1);
                    ESLVal $1752 = $1748.termRef(2);
                    ESLVal $1751 = $1748.termRef(3);
                    ESLVal $1750 = $1748.termRef(4);
                    
                    {ESLVal l = $1754;
                    
                    {ESLVal args = $1753;
                    
                    {ESLVal t = $1752;
                    
                    {ESLVal g = $1751;
                    
                    {ESLVal e = $1750;
                    
                    {ESLVal _v1563 = $1749;
                    
                    if(_v1562.eql(new ESLVal(-1)).or(length.apply(args).eql(_v1562)).boolVal)
                    return checkArities.apply(_v1563,length.apply(args));
                    else
                      return error(new ESLVal("TypeError",l,new ESLVal("inconsistent overloaded arity")));
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(18606,18895)").add(ESLVal.list(_v1069)));
                }
                }
              else if(_v1069.isNil())
                return $null;
              else return error(new ESLVal("case error at Pos(18606,18895)").add(ESLVal.list(_v1069)));
              }
            }
          });
        ESLVal checkLoneVars = new ESLVal(new Function(new ESLVal("checkLoneVars"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1559 = $args[0];
          {ESLVal _v1070 = _v1559;
                
                if(_v1070.isCons())
                {ESLVal $1755 = _v1070.head();
                  ESLVal $1756 = _v1070.tail();
                  
                  switch($1755.termName) {
                  case "FunCase": {ESLVal $1761 = $1755.termRef(0);
                    ESLVal $1760 = $1755.termRef(1);
                    ESLVal $1759 = $1755.termRef(2);
                    ESLVal $1758 = $1755.termRef(3);
                    ESLVal $1757 = $1755.termRef(4);
                    
                    {ESLVal l = $1761;
                    
                    {ESLVal args = $1760;
                    
                    {ESLVal t = $1759;
                    
                    {ESLVal g = $1758;
                    
                    {ESLVal e = $1757;
                    
                    {ESLVal _v1560 = $1756;
                    
                    {{
                    ESLVal _v1071 = args;
                    while(_v1071.isCons()) {
                      ESLVal arg = _v1071.headVal;
                      checkLoneVar.apply(arg);
                      _v1071 = _v1071.tailVal;}
                  }
                  return checkLoneVars.apply(_v1560);}
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(18954,19189)").add(ESLVal.list(_v1070)));
                }
                }
              else if(_v1070.isNil())
                return $null;
              else return error(new ESLVal("case error at Pos(18954,19189)").add(ESLVal.list(_v1070)));
              }
            }
          });
        ESLVal checkLoneVar = new ESLVal(new Function(new ESLVal("checkLoneVar"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal p = $args[0];
          {ESLVal _v1072 = p;
                
                switch(_v1072.termName) {
                case "PVar": {ESLVal $1764 = _v1072.termRef(0);
                  ESLVal $1763 = _v1072.termRef(1);
                  ESLVal $1762 = _v1072.termRef(2);
                  
                  switch($1762.termName) {
                  case "VoidType": {ESLVal $1765 = $1762.termRef(0);
                    
                    {ESLVal l = $1764;
                    
                    {ESLVal _v1556 = $1763;
                    
                    {ESLVal tl = $1765;
                    
                    return error(new ESLVal("TypeError",l,new ESLVal("top level variables should be typed.")));
                  }
                  }
                  }
                  }
                  default: {ESLVal _v1557 = _v1072;
                    
                    return $null;
                  }
                }
                }
                default: {ESLVal _v1558 = _v1072;
                  
                  return $null;
                }
              }
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "checkArities": return checkArities;
            
            case "checkLoneVars": return checkLoneVars;
            
            case "checkLoneVar": return checkLoneVar;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal checkArities = letrec.get("checkArities");
      
      ESLVal checkLoneVars = letrec.get("checkLoneVars");
      
      ESLVal checkLoneVar = letrec.get("checkLoneVar");
      
        {checkArities.apply(cases,new ESLVal(-1));
      return checkLoneVars.apply(cases);}}
      
      }
      }
      }
    case "FunBind": {ESLVal $1736 = _v1065.termRef(0);
        ESLVal $1735 = _v1065.termRef(1);
        ESLVal $1734 = _v1065.termRef(2);
        ESLVal $1733 = _v1065.termRef(3);
        ESLVal $1732 = _v1065.termRef(4);
        ESLVal $1731 = _v1065.termRef(5);
        ESLVal $1730 = _v1065.termRef(6);
        
        {ESLVal l = $1736;
        
        {ESLVal n = $1735;
        
        {ESLVal ps = $1734;
        
        {ESLVal t = $1733;
        
        {ESLVal st = $1732;
        
        {ESLVal b = $1731;
        
        {ESLVal g = $1730;
        
        {checkPatterns(l,ps);
      {ESLVal argTypes = map.apply(new ESLVal(new Function(new ESLVal("fun380"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal p = $args[0];
          {ESLVal _v1066 = p;
                
                switch(_v1066.termName) {
                case "PVar": {ESLVal $1741 = _v1066.termRef(0);
                  ESLVal $1740 = _v1066.termRef(1);
                  ESLVal $1739 = _v1066.termRef(2);
                  
                  {ESLVal _v1550 = $1741;
                  
                  {ESLVal _v1551 = $1740;
                  
                  {ESLVal _v1552 = $1739;
                  
                  return substTypeEnv.apply(typeEnv,_v1552);
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(19821,19887)").add(ESLVal.list(_v1066)));
              }
              }
            }
          }),ps);
        ESLVal argNames = map.apply(new ESLVal(new Function(new ESLVal("fun381"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal p = $args[0];
          {ESLVal _v1067 = p;
                
                switch(_v1067.termName) {
                case "PVar": {ESLVal $1744 = _v1067.termRef(0);
                  ESLVal $1743 = _v1067.termRef(1);
                  ESLVal $1742 = _v1067.termRef(2);
                  
                  {ESLVal _v1547 = $1744;
                  
                  {ESLVal _v1548 = $1743;
                  
                  {ESLVal _v1549 = $1742;
                  
                  return _v1548;
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(19959,20003)").add(ESLVal.list(_v1067)));
              }
              }
            }
          }),ps);
        
        {ESLVal bodyType = guardedExpType(l,g,b,selfType,zipTypeEnv.apply(argNames,argTypes).add(baseValueEnv),cnstrEnv,typeEnv);
        
        {ESLVal fType = ((Supplier<ESLVal>)() -> { 
            {ESLVal _v1068 = t;
              
              switch(_v1068.termName) {
              case "ForallType": {ESLVal $1747 = _v1068.termRef(0);
                ESLVal $1746 = _v1068.termRef(1);
                ESLVal $1745 = _v1068.termRef(2);
                
                {ESLVal _v1553 = $1747;
                
                {ESLVal ns = $1746;
                
                {ESLVal _v1554 = $1745;
                
                return genericize(_v1553,new ESLVal("FunType",_v1553,argTypes,bodyType));
              }
              }
              }
              }
              default: {ESLVal _v1555 = _v1068;
                
                return new ESLVal("FunType",l,argTypes,bodyType);
              }
            }
            }
          }).get();
        ESLVal dType = substTypeEnv.apply(typeEnv,t);
        
        if(subType.apply(fType,dType).boolVal)
        return $null;
        else
          return error(new ESLVal("TypeError",l,new ESLVal("type of ").add(n.add(new ESLVal("::").add(ppType(fType,typeEnv).add(new ESLVal(" does not match declaration ").add(ppType(dType,typeEnv))))))));
      }
      }
      }}
      }
      }
      }
      }
      }
      }
      }
      }
    case "Binding": {ESLVal $1729 = _v1065.termRef(0);
        ESLVal $1728 = _v1065.termRef(1);
        ESLVal $1727 = _v1065.termRef(2);
        ESLVal $1726 = _v1065.termRef(3);
        ESLVal $1725 = _v1065.termRef(4);
        
        {ESLVal l = $1729;
        
        {ESLVal n = $1728;
        
        {ESLVal dt = $1727;
        
        {ESLVal st = $1726;
        
        {ESLVal e = $1725;
        
        {ESLVal valueType = expType(e,selfType,baseValueEnv,cnstrEnv,typeEnv);
        
        {ESLVal valueFV = typeFV(valueType);
        ESLVal declaredType = lookupType.apply(n,valueEnv);
        
        {ESLVal _v1546 = ((Supplier<ESLVal>)() -> { 
            if(valueFV.eql($nil).boolVal)
              return valueType;
              else
                return new ESLVal("ForallType",l,valueFV,valueType);
          }).get();
        
        if(subType.apply(_v1546,declaredType).boolVal)
        return $null;
        else
          return error(new ESLVal("TypeError",l,new ESLVal("type of ").add(n.add(new ESLVal(" ").add(ppType(_v1546,typeEnv).add(new ESLVal(" does not match declared type = ").add(ppType(declaredType,typeEnv))))))));
      }
      }
      }
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(18487,21410)").add(ESLVal.list(_v1065)));
    }
    }
  }
  private static ESLVal typeCheckDef = new ESLVal(new Function(new ESLVal("typeCheckDef"),null) { public ESLVal apply(ESLVal... args) { return typeCheckDef(args[0],args[1],args[2],args[3],args[4],args[5]); }});
  private static ESLVal guardedExpType(ESLVal l,ESLVal g,ESLVal e,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal bt = expType(g,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(isBoolType.apply(bt).boolVal)
      return expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
      else
        return error(new ESLVal("TypeError",l,new ESLVal("guarded expression requires a boolean value: ").add(ppType(bt,typeEnv))));
    }
  }
  private static ESLVal guardedExpType = new ESLVal(new Function(new ESLVal("guardedExpType"),null) { public ESLVal apply(ESLVal... args) { return guardedExpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal expType(ESLVal e,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t = expType1(e,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(hasTypeInfo.apply(e).boolVal)
      return t;
      else
        return recordJustType(e,t);
    }
  }
  private static ESLVal expType = new ESLVal(new Function(new ESLVal("expType"),null) { public ESLVal apply(ESLVal... args) { return expType(args[0],args[1],args[2],args[3],args[4]); }});
  private static ESLVal expType1(ESLVal e,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal _v1073 = e;
      
      switch(_v1073.termName) {
      case "ActExp": {ESLVal $1901 = _v1073.termRef(0);
        ESLVal $1900 = _v1073.termRef(1);
        ESLVal $1899 = _v1073.termRef(2);
        ESLVal $1898 = _v1073.termRef(3);
        ESLVal $1897 = _v1073.termRef(4);
        ESLVal $1896 = _v1073.termRef(5);
        ESLVal $1895 = _v1073.termRef(6);
        ESLVal $1894 = _v1073.termRef(7);
        
        {ESLVal l = $1901;
        
        {ESLVal n = $1900;
        
        {ESLVal args = $1899;
        
        {ESLVal exports = $1898;
        
        {ESLVal parent = $1897;
        
        {ESLVal bindings = $1896;
        
        {ESLVal init = $1895;
        
        {ESLVal arms = $1894;
        
        return actType(l,n,args,parent,exports,bindings,init,arms,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
      }
      }
      }
      }
      }
    case "Apply": {ESLVal $1893 = _v1073.termRef(0);
        ESLVal $1892 = _v1073.termRef(1);
        ESLVal $1891 = _v1073.termRef(2);
        
        {ESLVal l = $1893;
        
        {ESLVal op = $1892;
        
        {ESLVal args = $1891;
        
        return applyType(l,op,args,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "ApplyTypeExp": {ESLVal $1890 = _v1073.termRef(0);
        ESLVal $1889 = _v1073.termRef(1);
        ESLVal $1888 = _v1073.termRef(2);
        
        {ESLVal l = $1890;
        
        {ESLVal _v1545 = $1889;
        
        {ESLVal ts = $1888;
        
        return applyTypeExp(l,_v1545,ts,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "ArrayUpdate": {ESLVal $1887 = _v1073.termRef(0);
        ESLVal $1886 = _v1073.termRef(1);
        ESLVal $1885 = _v1073.termRef(2);
        ESLVal $1884 = _v1073.termRef(3);
        
        {ESLVal l = $1887;
        
        {ESLVal a = $1886;
        
        {ESLVal i = $1885;
        
        {ESLVal v = $1884;
        
        return arrayUpdateType(l,a,i,v,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
      }
    case "ArrayRef": {ESLVal $1883 = _v1073.termRef(0);
        ESLVal $1882 = _v1073.termRef(1);
        ESLVal $1881 = _v1073.termRef(2);
        
        {ESLVal l = $1883;
        
        {ESLVal a = $1882;
        
        {ESLVal i = $1881;
        
        return arrayRefType(l,a,i,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "BagExp": {ESLVal $1880 = _v1073.termRef(0);
        ESLVal $1879 = _v1073.termRef(1);
        
        {ESLVal l = $1880;
        
        {ESLVal es = $1879;
        
        return bagType(l,es,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
    case "Become": {ESLVal $1878 = _v1073.termRef(0);
        ESLVal $1877 = _v1073.termRef(1);
        
        {ESLVal l = $1878;
        
        {ESLVal _v1544 = $1877;
        
        return becomeType(l,_v1544,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
    case "BinExp": {ESLVal $1876 = _v1073.termRef(0);
        ESLVal $1875 = _v1073.termRef(1);
        ESLVal $1874 = _v1073.termRef(2);
        ESLVal $1873 = _v1073.termRef(3);
        
        {ESLVal l = $1876;
        
        {ESLVal e1 = $1875;
        
        {ESLVal op = $1874;
        
        {ESLVal e2 = $1873;
        
        return binExpType(l,e1,op,e2,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
      }
    case "Block": {ESLVal $1872 = _v1073.termRef(0);
        ESLVal $1871 = _v1073.termRef(1);
        
        {ESLVal l = $1872;
        
        {ESLVal es = $1871;
        
        return blockType(l,es,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
    case "BoolExp": {ESLVal $1870 = _v1073.termRef(0);
        ESLVal $1869 = _v1073.termRef(1);
        
        {ESLVal l = $1870;
        
        {ESLVal b = $1869;
        
        return new ESLVal("BoolType",l);
      }
      }
      }
    case "Case": {ESLVal $1868 = _v1073.termRef(0);
        ESLVal $1867 = _v1073.termRef(1);
        ESLVal $1866 = _v1073.termRef(2);
        ESLVal $1865 = _v1073.termRef(3);
        
        {ESLVal l = $1868;
        
        {ESLVal decs = $1867;
        
        {ESLVal es = $1866;
        
        {ESLVal arms = $1865;
        
        return caseType(l,es,arms,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
      }
    case "Cmp": {ESLVal $1864 = _v1073.termRef(0);
        ESLVal $1863 = _v1073.termRef(1);
        ESLVal $1862 = _v1073.termRef(2);
        
        {ESLVal l = $1864;
        
        {ESLVal _v1543 = $1863;
        
        {ESLVal qs = $1862;
        
        return cmpType(l,_v1543,qs,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "Grab": {ESLVal $1861 = _v1073.termRef(0);
        ESLVal $1860 = _v1073.termRef(1);
        ESLVal $1859 = _v1073.termRef(2);
        
        {ESLVal l = $1861;
        
        {ESLVal refs = $1860;
        
        {ESLVal _v1542 = $1859;
        
        return expType(_v1542,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "FloatExp": {ESLVal $1858 = _v1073.termRef(0);
        ESLVal $1857 = _v1073.termRef(1);
        
        {ESLVal l = $1858;
        
        {ESLVal f = $1857;
        
        return new ESLVal("FloatType",l);
      }
      }
      }
    case "Fold": {ESLVal $1856 = _v1073.termRef(0);
        ESLVal $1855 = _v1073.termRef(1);
        ESLVal $1854 = _v1073.termRef(2);
        
        {ESLVal l = $1856;
        
        {ESLVal t = $1855;
        
        {ESLVal _v1541 = $1854;
        
        return foldType(l,t,_v1541,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "For": {ESLVal $1853 = _v1073.termRef(0);
        ESLVal $1852 = _v1073.termRef(1);
        ESLVal $1851 = _v1073.termRef(2);
        ESLVal $1850 = _v1073.termRef(3);
        
        {ESLVal l = $1853;
        
        {ESLVal p = $1852;
        
        {ESLVal list = $1851;
        
        {ESLVal _v1540 = $1850;
        
        return forType(l,p,list,_v1540,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
      }
    case "FunExp": {ESLVal $1849 = _v1073.termRef(0);
        ESLVal $1848 = _v1073.termRef(1);
        ESLVal $1847 = _v1073.termRef(2);
        ESLVal $1846 = _v1073.termRef(3);
        ESLVal $1845 = _v1073.termRef(4);
        
        {ESLVal l = $1849;
        
        {ESLVal n = $1848;
        
        {ESLVal args = $1847;
        
        {ESLVal t = $1846;
        
        {ESLVal _v1539 = $1845;
        
        return funType(l,n,args,t,_v1539,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
      }
      }
    case "If": {ESLVal $1844 = _v1073.termRef(0);
        ESLVal $1843 = _v1073.termRef(1);
        ESLVal $1842 = _v1073.termRef(2);
        ESLVal $1841 = _v1073.termRef(3);
        
        {ESLVal l = $1844;
        
        {ESLVal e1 = $1843;
        
        {ESLVal e2 = $1842;
        
        {ESLVal e3 = $1841;
        
        return ifType(l,e1,e2,e3,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
      }
    case "IntExp": {ESLVal $1840 = _v1073.termRef(0);
        ESLVal $1839 = _v1073.termRef(1);
        
        {ESLVal l = $1840;
        
        {ESLVal n = $1839;
        
        return new ESLVal("IntType",l);
      }
      }
      }
    case "Let": {ESLVal $1838 = _v1073.termRef(0);
        ESLVal $1837 = _v1073.termRef(1);
        ESLVal $1836 = _v1073.termRef(2);
        
        {ESLVal l = $1838;
        
        {ESLVal bs = $1837;
        
        {ESLVal _v1538 = $1836;
        
        return letType(l,bs,_v1538,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "Letrec": {ESLVal $1835 = _v1073.termRef(0);
        ESLVal $1834 = _v1073.termRef(1);
        ESLVal $1833 = _v1073.termRef(2);
        
        {ESLVal l = $1835;
        
        {ESLVal bs = $1834;
        
        {ESLVal _v1537 = $1833;
        
        return letrecType(l,bs,_v1537,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "List": {ESLVal $1832 = _v1073.termRef(0);
        ESLVal $1831 = _v1073.termRef(1);
        
        {ESLVal l = $1832;
        
        {ESLVal es = $1831;
        
        return listType(l,es,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
    case "Now": {ESLVal $1830 = _v1073.termRef(0);
        
        {ESLVal l = $1830;
        
        return new ESLVal("IntType",l);
      }
      }
    case "Probably": {ESLVal $1829 = _v1073.termRef(0);
        ESLVal $1828 = _v1073.termRef(1);
        ESLVal $1827 = _v1073.termRef(2);
        ESLVal $1826 = _v1073.termRef(3);
        ESLVal $1825 = _v1073.termRef(4);
        
        {ESLVal l = $1829;
        
        {ESLVal p = $1828;
        
        {ESLVal t = $1827;
        
        {ESLVal e1 = $1826;
        
        {ESLVal e2 = $1825;
        
        return probablyType(l,p,t,e1,e2,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
      }
      }
    case "PLet": {ESLVal $1824 = _v1073.termRef(0);
        ESLVal $1823 = _v1073.termRef(1);
        ESLVal $1822 = _v1073.termRef(2);
        
        {ESLVal l = $1824;
        
        {ESLVal bs = $1823;
        
        {ESLVal _v1536 = $1822;
        
        return letType(l,bs,_v1536,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "Record": {ESLVal $1821 = _v1073.termRef(0);
        ESLVal $1820 = _v1073.termRef(1);
        
        {ESLVal l = $1821;
        
        {ESLVal fields = $1820;
        
        return recordType(l,fields,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
    case "Ref": {ESLVal $1819 = _v1073.termRef(0);
        ESLVal $1818 = _v1073.termRef(1);
        ESLVal $1817 = _v1073.termRef(2);
        
        {ESLVal l = $1819;
        
        {ESLVal _v1535 = $1818;
        
        {ESLVal n = $1817;
        
        return refType(l,_v1535,n,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "RefSuper": {ESLVal $1816 = _v1073.termRef(0);
        ESLVal $1815 = _v1073.termRef(1);
        
        {ESLVal l = $1816;
        
        {ESLVal n = $1815;
        
        return refType(l,new ESLVal("Var",l,new ESLVal("$super")),n,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
    case "Self": {ESLVal $1814 = _v1073.termRef(0);
        
        {ESLVal l = $1814;
        
        return selfType;
      }
      }
    case "Send": {ESLVal $1809 = _v1073.termRef(0);
        ESLVal $1808 = _v1073.termRef(1);
        ESLVal $1807 = _v1073.termRef(2);
        
        switch($1807.termName) {
        case "Term": {ESLVal $1813 = $1807.termRef(0);
          ESLVal $1812 = $1807.termRef(1);
          ESLVal $1811 = $1807.termRef(2);
          ESLVal $1810 = $1807.termRef(3);
          
          {ESLVal l = $1809;
          
          {ESLVal target = $1808;
          
          {ESLVal tl = $1813;
          
          {ESLVal n = $1812;
          
          {ESLVal ts = $1811;
          
          {ESLVal args = $1810;
          
          return sendType(l,target,n,args,selfType,valueEnv,cnstrEnv,typeEnv);
        }
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(22263,27165)").add(ESLVal.list(_v1073)));
      }
      }
    case "SendTimeSuper": {ESLVal $1806 = _v1073.termRef(0);
        
        {ESLVal l = $1806;
        
        return new ESLVal("VoidType",l);
      }
      }
    case "SendSuper": {ESLVal $1805 = _v1073.termRef(0);
        ESLVal $1804 = _v1073.termRef(1);
        
        {ESLVal l = $1805;
        
        {ESLVal _v1534 = $1804;
        
        return new ESLVal("VoidType",l);
      }
      }
      }
    case "SetExp": {ESLVal $1803 = _v1073.termRef(0);
        ESLVal $1802 = _v1073.termRef(1);
        
        {ESLVal l = $1803;
        
        {ESLVal es = $1802;
        
        return setType(l,es,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
    case "StrExp": {ESLVal $1801 = _v1073.termRef(0);
        ESLVal $1800 = _v1073.termRef(1);
        
        {ESLVal l = $1801;
        
        {ESLVal s = $1800;
        
        return new ESLVal("StrType",l);
      }
      }
      }
    case "Term": {ESLVal $1799 = _v1073.termRef(0);
        ESLVal $1798 = _v1073.termRef(1);
        ESLVal $1797 = _v1073.termRef(2);
        ESLVal $1796 = _v1073.termRef(3);
        
        {ESLVal l = $1799;
        
        {ESLVal n = $1798;
        
        {ESLVal ts = $1797;
        
        {ESLVal es = $1796;
        
        return termType(l,n,ts,es,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
      }
    case "Throw": {ESLVal $1795 = _v1073.termRef(0);
        ESLVal $1794 = _v1073.termRef(1);
        ESLVal $1793 = _v1073.termRef(2);
        
        {ESLVal l = $1795;
        
        {ESLVal t = $1794;
        
        {ESLVal _v1533 = $1793;
        
        return throwType(l,t,_v1533,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "Try": {ESLVal $1792 = _v1073.termRef(0);
        ESLVal $1791 = _v1073.termRef(1);
        ESLVal $1790 = _v1073.termRef(2);
        
        {ESLVal l = $1792;
        
        {ESLVal _v1532 = $1791;
        
        {ESLVal arms = $1790;
        
        return tryType(l,_v1532,arms,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "New": {ESLVal $1789 = _v1073.termRef(0);
        ESLVal $1788 = _v1073.termRef(1);
        ESLVal $1787 = _v1073.termRef(2);
        
        {ESLVal l = $1789;
        
        {ESLVal b = $1788;
        
        {ESLVal args = $1787;
        
        return newType(l,b,args,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "NewArray": {ESLVal $1786 = _v1073.termRef(0);
        ESLVal $1785 = _v1073.termRef(1);
        ESLVal $1784 = _v1073.termRef(2);
        
        {ESLVal l = $1786;
        
        {ESLVal t = $1785;
        
        {ESLVal i = $1784;
        
        return newArrayType(l,t,i,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "NewTable": {ESLVal $1783 = _v1073.termRef(0);
        ESLVal $1782 = _v1073.termRef(1);
        ESLVal $1781 = _v1073.termRef(2);
        
        {ESLVal l = $1783;
        
        {ESLVal key = $1782;
        
        {ESLVal value = $1781;
        
        return new ESLVal("TableType",l,substTypeEnv.apply(typeEnv,key),substTypeEnv.apply(typeEnv,value));
      }
      }
      }
      }
    case "NewJava": {ESLVal $1780 = _v1073.termRef(0);
        ESLVal $1779 = _v1073.termRef(1);
        ESLVal $1778 = _v1073.termRef(2);
        ESLVal $1777 = _v1073.termRef(3);
        
        {ESLVal l = $1780;
        
        {ESLVal path = $1779;
        
        {ESLVal t = $1778;
        
        {ESLVal args = $1777;
        
        {{
        ESLVal _v1074 = args;
        while(_v1074.isCons()) {
          ESLVal a = _v1074.headVal;
          expType(a,selfType,valueEnv,cnstrEnv,typeEnv);
          _v1074 = _v1074.tailVal;}
      }
      return substTypeEnv.apply(typeEnv,t);}
      }
      }
      }
      }
      }
    case "Not": {ESLVal $1776 = _v1073.termRef(0);
        ESLVal $1775 = _v1073.termRef(1);
        
        {ESLVal l = $1776;
        
        {ESLVal _v1531 = $1775;
        
        return notType(l,_v1531,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
    case "NullExp": {ESLVal $1774 = _v1073.termRef(0);
        
        {ESLVal l = $1774;
        
        return new ESLVal("ForallType",l,ESLVal.list(new ESLVal("T")),new ESLVal("VarType",l,new ESLVal("T")));
      }
      }
    case "Unfold": {ESLVal $1773 = _v1073.termRef(0);
        ESLVal $1772 = _v1073.termRef(1);
        ESLVal $1771 = _v1073.termRef(2);
        
        {ESLVal l = $1773;
        
        {ESLVal t = $1772;
        
        {ESLVal _v1530 = $1771;
        
        return unfoldTypeExp(l,t,_v1530,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "Update": {ESLVal $1770 = _v1073.termRef(0);
        ESLVal $1769 = _v1073.termRef(1);
        ESLVal $1768 = _v1073.termRef(2);
        
        {ESLVal l = $1770;
        
        {ESLVal n = $1769;
        
        {ESLVal _v1529 = $1768;
        
        return updateType(l,n,_v1529,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "Var": {ESLVal $1767 = _v1073.termRef(0);
        ESLVal $1766 = _v1073.termRef(1);
        
        {ESLVal l = $1767;
        
        {ESLVal n = $1766;
        
        return varType(l,n,valueEnv);
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(22263,27165)").add(ESLVal.list(_v1073)));
    }
    }
  }
  private static ESLVal expType1 = new ESLVal(new Function(new ESLVal("expType1"),null) { public ESLVal apply(ESLVal... args) { return expType1(args[0],args[1],args[2],args[3],args[4]); }});
  private static ESLVal throwType(ESLVal l,ESLVal t,ESLVal e,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal valType = expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
      
      return substTypeEnv.apply(typeEnv,t);
    }
  }
  private static ESLVal throwType = new ESLVal(new Function(new ESLVal("throwType"),null) { public ESLVal apply(ESLVal... args) { return throwType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal foldType(ESLVal l,ESLVal t,ESLVal e,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal eType = expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(typeEqual.apply(substTypeEnv.apply(typeEnv,t),eType).boolVal)
      return eType;
      else
        return error(new ESLVal("TypeError",l,new ESLVal("fold type ").add(ppType(t,typeEnv).add(new ESLVal(" does not equal ").add(ppType(eType,typeEnv))))));
    }
  }
  private static ESLVal foldType = new ESLVal(new Function(new ESLVal("foldType"),null) { public ESLVal apply(ESLVal... args) { return foldType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal unfoldTypeExp(ESLVal l,ESLVal t,ESLVal e,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal eType = expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal recType = substTypeEnv.apply(typeEnv,t);
      
      {ESLVal _v1075 = recType;
      
      switch(_v1075.termName) {
      case "RecType": {ESLVal $1904 = _v1075.termRef(0);
        ESLVal $1903 = _v1075.termRef(1);
        ESLVal $1902 = _v1075.termRef(2);
        
        {ESLVal rl = $1904;
        
        {ESLVal n = $1903;
        
        {ESLVal _v1527 = $1902;
        
        if(typeEqual.apply(substType.apply(eType,n,_v1527),eType).boolVal)
        return eType;
        else
          return error(new ESLVal("TypeError",l,new ESLVal("unfold type ").add(ppType(substType.apply(eType,n,_v1527),typeEnv).add(new ESLVal(" does not equal ").add(ppType(eType,typeEnv))))));
      }
      }
      }
      }
      default: {ESLVal _v1528 = _v1075;
        
        return error(new ESLVal("TypeError",l,new ESLVal("unfold type expects a rec type").add(ppType(recType,typeEnv))));
      }
    }
    }
    }
  }
  private static ESLVal unfoldTypeExp = new ESLVal(new Function(new ESLVal("unfoldTypeExp"),null) { public ESLVal apply(ESLVal... args) { return unfoldTypeExp(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal arrayUpdateType(ESLVal l,ESLVal a,ESLVal i,ESLVal v,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal aType = expType(a,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal iType = expType(i,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal vType = expType(v,selfType,valueEnv,cnstrEnv,typeEnv);
      
      {ESLVal _v1076 = aType;
      
      switch(_v1076.termName) {
      case "ArrayType": {ESLVal $1906 = _v1076.termRef(0);
        ESLVal $1905 = _v1076.termRef(1);
        
        {ESLVal al = $1906;
        
        {ESLVal t = $1905;
        
        if(isIntType.apply(iType).boolVal)
        if(typeEqual.apply(vType,t).boolVal)
          return aType;
          else
            return error(new ESLVal("TypeError",l,new ESLVal("value type ").add(vType.add(new ESLVal(" does not match array type ").add(t)))));
        else
          return error(new ESLVal("TypeError",l,new ESLVal("array index should be an integer ").add(i)));
      }
      }
      }
      default: {ESLVal t = _v1076;
        
        return error(new ESLVal("TypeError",l,new ESLVal("expecting an array ").add(aType)));
      }
    }
    }
    }
  }
  private static ESLVal arrayUpdateType = new ESLVal(new Function(new ESLVal("arrayUpdateType"),null) { public ESLVal apply(ESLVal... args) { return arrayUpdateType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7]); }});
  private static ESLVal arrayRefType(ESLVal l,ESLVal a,ESLVal i,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal aType = expType(a,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal iType = expType(i,selfType,valueEnv,cnstrEnv,typeEnv);
      
      {ESLVal _v1077 = aType;
      
      switch(_v1077.termName) {
      case "ArrayType": {ESLVal $1908 = _v1077.termRef(0);
        ESLVal $1907 = _v1077.termRef(1);
        
        {ESLVal al = $1908;
        
        {ESLVal t = $1907;
        
        if(isIntType.apply(iType).boolVal)
        return t;
        else
          return error(new ESLVal("TypeError",l,new ESLVal("array index should be an integer ").add(i)));
      }
      }
      }
      default: {ESLVal t = _v1077;
        
        return error(new ESLVal("TypeError",l,new ESLVal("expecting an array ").add(aType)));
      }
    }
    }
    }
  }
  private static ESLVal arrayRefType = new ESLVal(new Function(new ESLVal("arrayRefType"),null) { public ESLVal apply(ESLVal... args) { return arrayRefType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal newArrayType(ESLVal l,ESLVal t,ESLVal e,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal i = expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(isIntType.apply(i).boolVal)
      return new ESLVal("ArrayType",l,substTypeEnv.apply(typeEnv,t));
      else
        return error(new ESLVal("TypeError",l,new ESLVal("expecting an integer type: ").add(i)));
    }
  }
  private static ESLVal newArrayType = new ESLVal(new Function(new ESLVal("newArrayType"),null) { public ESLVal apply(ESLVal... args) { return newArrayType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal becomeType(ESLVal l,ESLVal e,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal bType = expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(typeEqual.apply(bType,selfType).boolVal)
      return bType;
      else
        return error(new ESLVal("TypeError",l,new ESLVal("expecting become to match self type: ").add(ppType(bType,typeEnv).add(new ESLVal(" ").add(ppType(selfType,typeEnv))))));
    }
  }
  private static ESLVal becomeType = new ESLVal(new Function(new ESLVal("becomeType"),null) { public ESLVal apply(ESLVal... args) { return becomeType(args[0],args[1],args[2],args[3],args[4],args[5]); }});
  private static ESLVal probablyType(ESLVal l,ESLVal p,ESLVal t,ESLVal e1,ESLVal e2,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal pt = expType(p,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(isIntType.apply(pt).boolVal)
      {ESLVal _v1524 = substTypeEnv.apply(typeEnv,t);
        ESLVal _v1525 = expType(e1,selfType,valueEnv,cnstrEnv,typeEnv);
        ESLVal _v1526 = expType(e2,selfType,valueEnv,cnstrEnv,typeEnv);
        
        if(typeEqual.apply(_v1524,_v1525).and(typeEqual.apply(_v1524,_v1526)).boolVal)
        return _v1524;
        else
          return error(new ESLVal("TypeError",l,new ESLVal("expecting probably arm types to agree: ").add(ppType(_v1525,typeEnv).add(new ESLVal(" ").add(ppType(_v1524,typeEnv).add(new ESLVal(" ").add(ppType(_v1526,typeEnv))))))));
      }
      else
        return error(new ESLVal("TypeError",l,new ESLVal("expecting an integer: ").add(ppType(pt,typeEnv))));
    }
  }
  private static ESLVal probablyType = new ESLVal(new Function(new ESLVal("probablyType"),null) { public ESLVal apply(ESLVal... args) { return probablyType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7],args[8]); }});
  private static ESLVal newType(ESLVal l,ESLVal b,ESLVal args,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    return expType(new ESLVal("Apply",l,b,args),selfType,valueEnv,cnstrEnv,typeEnv);
  }
  private static ESLVal newType = new ESLVal(new Function(new ESLVal("newType"),null) { public ESLVal apply(ESLVal... args) { return newType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal sendType(ESLVal l,ESLVal target,ESLVal n,ESLVal args,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal _v1078 = typeNF(derefType(expType(target,selfType,valueEnv,cnstrEnv,typeEnv)),typeEnv);
      
      switch(_v1078.termName) {
      case "ActType": {ESLVal $1911 = _v1078.termRef(0);
        ESLVal $1910 = _v1078.termRef(1);
        ESLVal $1909 = _v1078.termRef(2);
        
        {ESLVal al = $1911;
        
        {ESLVal exports = $1910;
        
        {ESLVal handlers = $1909;
        
        { LetRec letrec = new LetRec() {
        ESLVal findHandler = new ESLVal(new Function(new ESLVal("findHandler"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1514 = $args[0];
          {ESLVal _v1079 = _v1514;
                
                if(_v1079.isCons())
                {ESLVal $1912 = _v1079.head();
                  ESLVal $1913 = _v1079.tail();
                  
                  switch($1912.termName) {
                  case "MessageType": {ESLVal $1915 = $1912.termRef(0);
                    ESLVal $1914 = $1912.termRef(1);
                    
                    if($1914.isCons())
                    {ESLVal $1916 = $1914.head();
                      ESLVal $1917 = $1914.tail();
                      
                      switch($1916.termName) {
                      case "TermType": {ESLVal $1920 = $1916.termRef(0);
                        ESLVal $1919 = $1916.termRef(1);
                        ESLVal $1918 = $1916.termRef(2);
                        
                        if($1917.isCons())
                        {ESLVal $1921 = $1917.head();
                          ESLVal $1922 = $1917.tail();
                          
                          {ESLVal m = $1912;
                          
                          {ESLVal _v1515 = $1913;
                          
                          return findHandler.apply(_v1515);
                        }
                        }
                        }
                      else if($1917.isNil())
                        {ESLVal ml = $1915;
                          
                          {ESLVal tl = $1920;
                          
                          {ESLVal m = $1919;
                          
                          {ESLVal ts = $1918;
                          
                          {ESLVal rest = $1913;
                          
                          if(m.eql(n).boolVal)
                          return head.apply(_v1514);
                          else
                            {ESLVal _v1516 = $1912;
                              
                              {ESLVal _v1517 = $1913;
                              
                              return findHandler.apply(_v1517);
                            }
                            }
                        }
                        }
                        }
                        }
                        }
                      else {ESLVal m = $1912;
                          
                          {ESLVal _v1518 = $1913;
                          
                          return findHandler.apply(_v1518);
                        }
                        }
                      }
                      default: {ESLVal m = $1912;
                        
                        {ESLVal _v1519 = $1913;
                        
                        return findHandler.apply(_v1519);
                      }
                      }
                    }
                    }
                  else if($1914.isNil())
                    {ESLVal m = $1912;
                      
                      {ESLVal _v1520 = $1913;
                      
                      return findHandler.apply(_v1520);
                    }
                    }
                  else {ESLVal m = $1912;
                      
                      {ESLVal _v1521 = $1913;
                      
                      return findHandler.apply(_v1521);
                    }
                    }
                  }
                  default: {ESLVal m = $1912;
                    
                    {ESLVal _v1522 = $1913;
                    
                    return findHandler.apply(_v1522);
                  }
                  }
                }
                }
              else if(_v1079.isNil())
                return error(new ESLVal("TypeError",l,new ESLVal("cannot find message handler named ").add(n)));
              else return error(new ESLVal("case error at Pos(31359,31666)").add(ESLVal.list(_v1079)));
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "findHandler": return findHandler;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal findHandler = letrec.get("findHandler");
      
        {ESLVal _v1080 = findHandler.apply(handlers);
        
        switch(_v1080.termName) {
        case "MessageType": {ESLVal $1924 = _v1080.termRef(0);
          ESLVal $1923 = _v1080.termRef(1);
          
          if($1923.isCons())
          {ESLVal $1925 = $1923.head();
            ESLVal $1926 = $1923.tail();
            
            switch($1925.termName) {
            case "TermType": {ESLVal $1929 = $1925.termRef(0);
              ESLVal $1928 = $1925.termRef(1);
              ESLVal $1927 = $1925.termRef(2);
              
              if($1926.isCons())
              {ESLVal $1930 = $1926.head();
                ESLVal $1931 = $1926.tail();
                
                {ESLVal m = _v1080;
                
                return error(new ESLVal("TypeError",l,new ESLVal("cannot find message handler named ").add(n.add(new ESLVal(" in ").add(handlers)))));
              }
              }
            else if($1926.isNil())
              {ESLVal ml = $1924;
                
                {ESLVal tl = $1929;
                
                {ESLVal _v1523 = $1928;
                
                {ESLVal ts1 = $1927;
                
                {ESLVal ts2 = expTypes(args,selfType,valueEnv,cnstrEnv,typeEnv);
                
                if(length.apply(ts1).eql(length.apply(ts2)).boolVal)
                if(subTypes.apply(ts2,ts1).boolVal)
                  {expType(target,selfType,valueEnv,cnstrEnv,typeEnv);
                  return new ESLVal("VoidType",l);}
                  else
                    return error(new ESLVal("TypeError",l,new ESLVal("message argument types ").add(ppTypes(ts2,typeEnv).add(new ESLVal(" do not match expected types ").add(ppTypes(ts1,typeEnv))))));
                else
                  return error(new ESLVal("TypeError",l,new ESLVal("expecting ").add(length.apply(ts1).add(new ESLVal(" args, but received ").add(length.apply(ts2))))));
              }
              }
              }
              }
              }
            else {ESLVal m = _v1080;
                
                return error(new ESLVal("TypeError",l,new ESLVal("cannot find message handler named ").add(n.add(new ESLVal(" in ").add(handlers)))));
              }
            }
            default: {ESLVal m = _v1080;
              
              return error(new ESLVal("TypeError",l,new ESLVal("cannot find message handler named ").add(n.add(new ESLVal(" in ").add(handlers)))));
            }
          }
          }
        else if($1923.isNil())
          {ESLVal m = _v1080;
            
            return error(new ESLVal("TypeError",l,new ESLVal("cannot find message handler named ").add(n.add(new ESLVal(" in ").add(handlers)))));
          }
        else {ESLVal m = _v1080;
            
            return error(new ESLVal("TypeError",l,new ESLVal("cannot find message handler named ").add(n.add(new ESLVal(" in ").add(handlers)))));
          }
        }
        default: {ESLVal m = _v1080;
          
          return error(new ESLVal("TypeError",l,new ESLVal("cannot find message handler named ").add(n.add(new ESLVal(" in ").add(handlers)))));
        }
      }
      }}
      
      }
      }
      }
      }
      default: {ESLVal t = _v1078;
        
        return error(new ESLVal("TypeError",l,new ESLVal("expecting a behaviour type: ").add(typeNF(derefType(expType(target,selfType,valueEnv,cnstrEnv,typeEnv)),typeEnv))));
      }
    }
    }
  }
  private static ESLVal sendType = new ESLVal(new Function(new ESLVal("sendType"),null) { public ESLVal apply(ESLVal... args) { return sendType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7]); }});
  private static ESLVal actType(ESLVal l,ESLVal n,ESLVal args,ESLVal parent,ESLVal exports,ESLVal bindings,ESLVal init,ESLVal arms,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    { LetRec letrec = new LetRec() {
      ESLVal checkObservedMessage = new ESLVal(new Function(new ESLVal("checkObservedMessage"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            {ESLVal _v1081 = bindings;
              
              return $ndCase.apply(_v1081,ESLVal.list(new ESLVal("$selectMid",new ESLVal(new Function(new ESLVal("add"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $1933 = $args[0];
              ESLVal $1934 = $args[1];
              ESLVal $1935 = $args[2];
              ESLVal $1932 = $args[3];
              switch($1934.termName) {
                    case "FunBind": {ESLVal $1942 = $1934.termRef(0);
                      ESLVal $1941 = $1934.termRef(1);
                      ESLVal $1940 = $1934.termRef(2);
                      ESLVal $1939 = $1934.termRef(3);
                      ESLVal $1938 = $1934.termRef(4);
                      ESLVal $1937 = $1934.termRef(5);
                      ESLVal $1936 = $1934.termRef(6);
                      
                      switch($1941.strVal) {
                      case "observeMessage": {ESLVal bs1 = $1933;
                        
                        {ESLVal _v1506 = $1942;
                        
                        {ESLVal ps = $1940;
                        
                        {ESLVal t = $1939;
                        
                        {ESLVal st = $1938;
                        
                        {ESLVal g = $1937;
                        
                        {ESLVal e = $1936;
                        
                        {ESLVal bs2 = $1935;
                        
                        {ESLVal _v1082 = typeNF(t,typeEnv);
                        
                        switch(_v1082.termName) {
                        case "FunType": {ESLVal $1945 = _v1082.termRef(0);
                          ESLVal $1944 = _v1082.termRef(1);
                          ESLVal $1943 = _v1082.termRef(2);
                          
                          if($1944.isCons())
                          {ESLVal $1946 = $1944.head();
                            ESLVal $1947 = $1944.tail();
                            
                            if($1947.isCons())
                            {ESLVal $1948 = $1947.head();
                              ESLVal $1949 = $1947.tail();
                              
                              {ESLVal _v1507 = _v1082;
                              
                              return error(new ESLVal("TypeError",_v1506,new ESLVal("expecting observeMessage to have a type signature (In) -> Maybe[Out]")));
                            }
                            }
                          else if($1947.isNil())
                            {ESLVal fl = $1945;
                              
                              {ESLVal d = $1946;
                              
                              {ESLVal r = $1943;
                              
                              return checkObserveMessageDeclaration.apply(_v1506,d,r);
                            }
                            }
                            }
                          else {ESLVal _v1508 = _v1082;
                              
                              return error(new ESLVal("TypeError",_v1506,new ESLVal("expecting observeMessage to have a type signature (In) -> Maybe[Out]")));
                            }
                          }
                        else if($1944.isNil())
                          {ESLVal _v1509 = _v1082;
                            
                            return error(new ESLVal("TypeError",_v1506,new ESLVal("expecting observeMessage to have a type signature (In) -> Maybe[Out]")));
                          }
                        else {ESLVal _v1510 = _v1082;
                            
                            return error(new ESLVal("TypeError",_v1506,new ESLVal("expecting observeMessage to have a type signature (In) -> Maybe[Out]")));
                          }
                        }
                        default: {ESLVal _v1511 = _v1082;
                          
                          return error(new ESLVal("TypeError",_v1506,new ESLVal("expecting observeMessage to have a type signature (In) -> Maybe[Out]")));
                        }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      default: return $1932.apply();
                    }
                    }
                    default: return $1932.apply();
                  }
                }
              }))),new ESLVal(new Function(new ESLVal("listFail"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  {ESLVal bs = _v1081;
                    
                    return $null;
                  }
                }
              }));
            }
          }
        });
      ESLVal isTime = new ESLVal(new Function(new ESLVal("isTime"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal t = $args[0];
        {ESLVal _v1083 = t;
              
              switch(_v1083.termName) {
              case "TermType": {ESLVal $1952 = _v1083.termRef(0);
                ESLVal $1951 = _v1083.termRef(1);
                ESLVal $1950 = _v1083.termRef(2);
                
                switch($1951.strVal) {
                case "Time": {ESLVal _v1503 = $1952;
                  
                  {ESLVal ts = $1950;
                  
                  return $true;
                }
                }
                default: {ESLVal _v1504 = _v1083;
                  
                  return $false;
                }
              }
              }
              default: {ESLVal _v1505 = _v1083;
                
                return $false;
              }
            }
            }
          }
        });
      ESLVal checkObserveMessageDeclaration = new ESLVal(new Function(new ESLVal("checkObserveMessageDeclaration"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1500 = $args[0];
        ESLVal _v1501 = $args[1];
        ESLVal _v1502 = $args[2];
        if(typeEqual.apply(_v1501,new ESLVal("UnionType",_v1500,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v1084 = $qualArg;
                  
                  switch(_v1084.termName) {
                  case "MessageType": {ESLVal $1954 = _v1084.termRef(0);
                    ESLVal $1953 = _v1084.termRef(1);
                    
                    if($1953.isCons())
                    {ESLVal $1955 = $1953.head();
                      ESLVal $1956 = $1953.tail();
                      
                      if($1956.isCons())
                      {ESLVal $1957 = $1956.head();
                        ESLVal $1958 = $1956.tail();
                        
                        {ESLVal _0 = _v1084;
                        
                        return ESLVal.list();
                      }
                      }
                    else if($1956.isNil())
                      {ESLVal ml = $1954;
                        
                        {ESLVal t = $1955;
                        
                        return ESLVal.list(((Supplier<ESLVal>)() -> { 
                          if(isTime.apply(t).not().boolVal)
                            return ESLVal.list(t);
                            else
                              return ESLVal.list();
                        }).get());
                      }
                      }
                    else {ESLVal _0 = _v1084;
                        
                        return ESLVal.list();
                      }
                    }
                  else if($1953.isNil())
                    {ESLVal _0 = _v1084;
                      
                      return ESLVal.list();
                    }
                  else {ESLVal _0 = _v1084;
                      
                      return ESLVal.list();
                    }
                  }
                  default: {ESLVal _0 = _v1084;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(getMessageTypes.apply(arms)).flatten().flatten())).boolVal)
              {ESLVal _v1085 = typeNF(_v1502,typeEnv);
                
                switch(_v1085.termName) {
                case "UnionType": {ESLVal $1960 = _v1085.termRef(0);
                  ESLVal $1959 = _v1085.termRef(1);
                  
                  if($1959.isCons())
                  {ESLVal $1961 = $1959.head();
                    ESLVal $1962 = $1959.tail();
                    
                    switch($1961.termName) {
                    case "TermType": {ESLVal $1965 = $1961.termRef(0);
                      ESLVal $1964 = $1961.termRef(1);
                      ESLVal $1963 = $1961.termRef(2);
                      
                      switch($1964.strVal) {
                      case "Something": if($1963.isCons())
                        {ESLVal $1966 = $1963.head();
                          ESLVal $1967 = $1963.tail();
                          
                          if($1967.isCons())
                          {ESLVal $1968 = $1967.head();
                            ESLVal $1969 = $1967.tail();
                            
                            {ESLVal ms = _v1085;
                            
                            return error(new ESLVal("TypeError",_v1500,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1502)));
                          }
                          }
                        else if($1967.isNil())
                          if($1962.isCons())
                            {ESLVal $1970 = $1962.head();
                              ESLVal $1971 = $1962.tail();
                              
                              switch($1970.termName) {
                              case "TermType": {ESLVal $1974 = $1970.termRef(0);
                                ESLVal $1973 = $1970.termRef(1);
                                ESLVal $1972 = $1970.termRef(2);
                                
                                switch($1973.strVal) {
                                case "Nothing": if($1972.isCons())
                                  {ESLVal $1975 = $1972.head();
                                    ESLVal $1976 = $1972.tail();
                                    
                                    {ESLVal ms = _v1085;
                                    
                                    return error(new ESLVal("TypeError",_v1500,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1502)));
                                  }
                                  }
                                else if($1972.isNil())
                                  if($1971.isCons())
                                    {ESLVal $1977 = $1971.head();
                                      ESLVal $1978 = $1971.tail();
                                      
                                      {ESLVal ms = _v1085;
                                      
                                      return error(new ESLVal("TypeError",_v1500,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1502)));
                                    }
                                    }
                                  else if($1971.isNil())
                                    {ESLVal ul = $1960;
                                      
                                      {ESLVal l1 = $1965;
                                      
                                      {ESLVal t = $1966;
                                      
                                      {ESLVal l2 = $1974;
                                      
                                      return $null;
                                    }
                                    }
                                    }
                                    }
                                  else {ESLVal ms = _v1085;
                                      
                                      return error(new ESLVal("TypeError",_v1500,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1502)));
                                    }
                                else {ESLVal ms = _v1085;
                                    
                                    return error(new ESLVal("TypeError",_v1500,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1502)));
                                  }
                                default: {ESLVal ms = _v1085;
                                  
                                  return error(new ESLVal("TypeError",_v1500,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1502)));
                                }
                              }
                              }
                              default: {ESLVal ms = _v1085;
                                
                                return error(new ESLVal("TypeError",_v1500,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1502)));
                              }
                            }
                            }
                          else if($1962.isNil())
                            {ESLVal ms = _v1085;
                              
                              return error(new ESLVal("TypeError",_v1500,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1502)));
                            }
                          else {ESLVal ms = _v1085;
                              
                              return error(new ESLVal("TypeError",_v1500,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1502)));
                            }
                        else {ESLVal ms = _v1085;
                            
                            return error(new ESLVal("TypeError",_v1500,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1502)));
                          }
                        }
                      else if($1963.isNil())
                        {ESLVal ms = _v1085;
                          
                          return error(new ESLVal("TypeError",_v1500,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1502)));
                        }
                      else {ESLVal ms = _v1085;
                          
                          return error(new ESLVal("TypeError",_v1500,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1502)));
                        }
                    case "Nothing": if($1963.isCons())
                        {ESLVal $1979 = $1963.head();
                          ESLVal $1980 = $1963.tail();
                          
                          {ESLVal ms = _v1085;
                          
                          return error(new ESLVal("TypeError",_v1500,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1502)));
                        }
                        }
                      else if($1963.isNil())
                        if($1962.isCons())
                          {ESLVal $1981 = $1962.head();
                            ESLVal $1982 = $1962.tail();
                            
                            switch($1981.termName) {
                            case "TermType": {ESLVal $1985 = $1981.termRef(0);
                              ESLVal $1984 = $1981.termRef(1);
                              ESLVal $1983 = $1981.termRef(2);
                              
                              switch($1984.strVal) {
                              case "Something": if($1983.isCons())
                                {ESLVal $1986 = $1983.head();
                                  ESLVal $1987 = $1983.tail();
                                  
                                  if($1987.isCons())
                                  {ESLVal $1988 = $1987.head();
                                    ESLVal $1989 = $1987.tail();
                                    
                                    {ESLVal ms = _v1085;
                                    
                                    return error(new ESLVal("TypeError",_v1500,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1502)));
                                  }
                                  }
                                else if($1987.isNil())
                                  if($1982.isCons())
                                    {ESLVal $1990 = $1982.head();
                                      ESLVal $1991 = $1982.tail();
                                      
                                      {ESLVal ms = _v1085;
                                      
                                      return error(new ESLVal("TypeError",_v1500,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1502)));
                                    }
                                    }
                                  else if($1982.isNil())
                                    {ESLVal ul = $1960;
                                      
                                      {ESLVal l2 = $1965;
                                      
                                      {ESLVal l1 = $1985;
                                      
                                      {ESLVal t = $1986;
                                      
                                      return $null;
                                    }
                                    }
                                    }
                                    }
                                  else {ESLVal ms = _v1085;
                                      
                                      return error(new ESLVal("TypeError",_v1500,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1502)));
                                    }
                                else {ESLVal ms = _v1085;
                                    
                                    return error(new ESLVal("TypeError",_v1500,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1502)));
                                  }
                                }
                              else if($1983.isNil())
                                {ESLVal ms = _v1085;
                                  
                                  return error(new ESLVal("TypeError",_v1500,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1502)));
                                }
                              else {ESLVal ms = _v1085;
                                  
                                  return error(new ESLVal("TypeError",_v1500,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1502)));
                                }
                              default: {ESLVal ms = _v1085;
                                
                                return error(new ESLVal("TypeError",_v1500,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1502)));
                              }
                            }
                            }
                            default: {ESLVal ms = _v1085;
                              
                              return error(new ESLVal("TypeError",_v1500,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1502)));
                            }
                          }
                          }
                        else if($1962.isNil())
                          {ESLVal ms = _v1085;
                            
                            return error(new ESLVal("TypeError",_v1500,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1502)));
                          }
                        else {ESLVal ms = _v1085;
                            
                            return error(new ESLVal("TypeError",_v1500,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1502)));
                          }
                      else {ESLVal ms = _v1085;
                          
                          return error(new ESLVal("TypeError",_v1500,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1502)));
                        }
                      default: {ESLVal ms = _v1085;
                        
                        return error(new ESLVal("TypeError",_v1500,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1502)));
                      }
                    }
                    }
                    default: {ESLVal ms = _v1085;
                      
                      return error(new ESLVal("TypeError",_v1500,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1502)));
                    }
                  }
                  }
                else if($1959.isNil())
                  {ESLVal ms = _v1085;
                    
                    return error(new ESLVal("TypeError",_v1500,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1502)));
                  }
                else {ESLVal ms = _v1085;
                    
                    return error(new ESLVal("TypeError",_v1500,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1502)));
                  }
                }
                default: {ESLVal ms = _v1085;
                  
                  return error(new ESLVal("TypeError",_v1500,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1502)));
                }
              }
              }
              else
                return error(new ESLVal("TypeError",_v1500,new ESLVal("observeMessage must have an arg type that matches the message types of the behaviour type: ").add(ppType(_v1501,typeEnv).add(new ESLVal(" <> ").add(ppType(new ESLVal("UnionType",_v1500,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      ESLVal $qualArg = $args[0];
                  {ESLVal _v1086 = $qualArg;
                        
                        switch(_v1086.termName) {
                        case "MessageType": {ESLVal $1993 = _v1086.termRef(0);
                          ESLVal $1992 = _v1086.termRef(1);
                          
                          if($1992.isCons())
                          {ESLVal $1994 = $1992.head();
                            ESLVal $1995 = $1992.tail();
                            
                            if($1995.isCons())
                            {ESLVal $1996 = $1995.head();
                              ESLVal $1997 = $1995.tail();
                              
                              {ESLVal _0 = _v1086;
                              
                              return ESLVal.list();
                            }
                            }
                          else if($1995.isNil())
                            {ESLVal ml = $1993;
                              
                              {ESLVal t = $1994;
                              
                              return ESLVal.list(((Supplier<ESLVal>)() -> { 
                                if(isTime.apply(t).not().boolVal)
                                  return ESLVal.list(t);
                                  else
                                    return ESLVal.list();
                              }).get());
                            }
                            }
                          else {ESLVal _0 = _v1086;
                              
                              return ESLVal.list();
                            }
                          }
                        else if($1992.isNil())
                          {ESLVal _0 = _v1086;
                            
                            return ESLVal.list();
                          }
                        else {ESLVal _0 = _v1086;
                            
                            return ESLVal.list();
                          }
                        }
                        default: {ESLVal _0 = _v1086;
                          
                          return ESLVal.list();
                        }
                      }
                      }
                    }
                  }).map(getMessageTypes.apply(arms)).flatten().flatten()),typeEnv))))));
          }
        });
      ESLVal findLoc = new ESLVal(new Function(new ESLVal("findLoc"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1491 = $args[0];
        ESLVal _v1492 = $args[1];
        {ESLVal _v1087 = _v1492;
              
              if(_v1087.isCons())
              {ESLVal $1998 = _v1087.head();
                ESLVal $1999 = _v1087.tail();
                
                switch($1998.termName) {
                case "Binding": {ESLVal $2011 = $1998.termRef(0);
                  ESLVal $2010 = $1998.termRef(1);
                  ESLVal $2009 = $1998.termRef(2);
                  ESLVal $2008 = $1998.termRef(3);
                  ESLVal $2007 = $1998.termRef(4);
                  
                  {ESLVal _v1496 = $2011;
                  
                  {ESLVal m = $2010;
                  
                  {ESLVal t = $2009;
                  
                  {ESLVal st = $2008;
                  
                  {ESLVal e = $2007;
                  
                  {ESLVal _v1497 = $1999;
                  
                  if(m.eql(_v1491).boolVal)
                  return _v1496;
                  else
                    {ESLVal b = $1998;
                      
                      {ESLVal _v1498 = $1999;
                      
                      return findLoc.apply(_v1491,_v1498);
                    }
                    }
                }
                }
                }
                }
                }
                }
                }
              case "FunBind": {ESLVal $2006 = $1998.termRef(0);
                  ESLVal $2005 = $1998.termRef(1);
                  ESLVal $2004 = $1998.termRef(2);
                  ESLVal $2003 = $1998.termRef(3);
                  ESLVal $2002 = $1998.termRef(4);
                  ESLVal $2001 = $1998.termRef(5);
                  ESLVal $2000 = $1998.termRef(6);
                  
                  {ESLVal _v1493 = $2006;
                  
                  {ESLVal m = $2005;
                  
                  {ESLVal ps = $2004;
                  
                  {ESLVal t = $2003;
                  
                  {ESLVal st = $2002;
                  
                  {ESLVal g = $2001;
                  
                  {ESLVal e = $2000;
                  
                  {ESLVal _v1494 = $1999;
                  
                  if(m.eql(_v1491).boolVal)
                  return _v1493;
                  else
                    {ESLVal b = $1998;
                      
                      {ESLVal _v1495 = $1999;
                      
                      return findLoc.apply(_v1491,_v1495);
                    }
                    }
                }
                }
                }
                }
                }
                }
                }
                }
                }
                default: {ESLVal b = $1998;
                  
                  {ESLVal _v1499 = $1999;
                  
                  return findLoc.apply(_v1491,_v1499);
                }
                }
              }
              }
            else if(_v1087.isNil())
              return p0;
            else return error(new ESLVal("case error at Pos(34455,34759)").add(ESLVal.list(_v1087)));
            }
          }
        });
      ESLVal findType = new ESLVal(new Function(new ESLVal("findType"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1482 = $args[0];
        ESLVal _v1483 = $args[1];
        {ESLVal _v1088 = _v1483;
              
              if(_v1088.isCons())
              {ESLVal $2012 = _v1088.head();
                ESLVal $2013 = _v1088.tail();
                
                switch($2012.termName) {
                case "Binding": {ESLVal $2025 = $2012.termRef(0);
                  ESLVal $2024 = $2012.termRef(1);
                  ESLVal $2023 = $2012.termRef(2);
                  ESLVal $2022 = $2012.termRef(3);
                  ESLVal $2021 = $2012.termRef(4);
                  
                  {ESLVal _v1487 = $2025;
                  
                  {ESLVal m = $2024;
                  
                  {ESLVal t = $2023;
                  
                  {ESLVal st = $2022;
                  
                  {ESLVal e = $2021;
                  
                  {ESLVal _v1488 = $2013;
                  
                  if(m.eql(_v1482).boolVal)
                  return substTypeEnv.apply(typeEnv,t);
                  else
                    {ESLVal b = $2012;
                      
                      {ESLVal _v1489 = $2013;
                      
                      return findType.apply(_v1482,_v1489);
                    }
                    }
                }
                }
                }
                }
                }
                }
                }
              case "FunBind": {ESLVal $2020 = $2012.termRef(0);
                  ESLVal $2019 = $2012.termRef(1);
                  ESLVal $2018 = $2012.termRef(2);
                  ESLVal $2017 = $2012.termRef(3);
                  ESLVal $2016 = $2012.termRef(4);
                  ESLVal $2015 = $2012.termRef(5);
                  ESLVal $2014 = $2012.termRef(6);
                  
                  {ESLVal _v1484 = $2020;
                  
                  {ESLVal m = $2019;
                  
                  {ESLVal ps = $2018;
                  
                  {ESLVal t = $2017;
                  
                  {ESLVal st = $2016;
                  
                  {ESLVal g = $2015;
                  
                  {ESLVal e = $2014;
                  
                  {ESLVal _v1485 = $2013;
                  
                  if(m.eql(_v1482).boolVal)
                  return substTypeEnv.apply(typeEnv,t);
                  else
                    {ESLVal b = $2012;
                      
                      {ESLVal _v1486 = $2013;
                      
                      return findType.apply(_v1482,_v1486);
                    }
                    }
                }
                }
                }
                }
                }
                }
                }
                }
                }
                default: {ESLVal b = $2012;
                  
                  {ESLVal _v1490 = $2013;
                  
                  return findType.apply(_v1482,_v1490);
                }
                }
              }
              }
            else if(_v1088.isNil())
              return $null;
            else return error(new ESLVal("case error at Pos(34813,35170)").add(ESLVal.list(_v1088)));
            }
          }
        });
      ESLVal decs = new ESLVal(new Function(new ESLVal("decs"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1478 = $args[0];
        {ESLVal _v1089 = _v1478;
              
              if(_v1089.isCons())
              {ESLVal $2026 = _v1089.head();
                ESLVal $2027 = _v1089.tail();
                
                {ESLVal m = $2026;
                
                {ESLVal _v1479 = $2027;
                
                {ESLVal _v1480 = findType.apply(m,bindings);
                ESLVal _v1481 = findLoc.apply(m,bindings);
                
                if(_v1480.eql($null).boolVal)
                return error(new ESLVal("TypeError",_v1481,new ESLVal("cannot find exported name ").add(m)));
                else
                  return decs.apply(_v1479).cons(new ESLVal("Dec",_v1481,m,_v1480,_v1480));
              }
              }
              }
              }
            else if(_v1089.isNil())
              return $nil;
            else return error(new ESLVal("case error at Pos(35213,35544)").add(ESLVal.list(_v1089)));
            }
          }
        });
      ESLVal getMessageTypes = new ESLVal(new Function(new ESLVal("getMessageTypes"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1475 = $args[0];
        {ESLVal _v1090 = _v1475;
              
              if(_v1090.isCons())
              {ESLVal $2028 = _v1090.head();
                ESLVal $2029 = _v1090.tail();
                
                switch($2028.termName) {
                case "BArm": {ESLVal $2033 = $2028.termRef(0);
                  ESLVal $2032 = $2028.termRef(1);
                  ESLVal $2031 = $2028.termRef(2);
                  ESLVal $2030 = $2028.termRef(3);
                  
                  {ESLVal _v1476 = $2033;
                  
                  {ESLVal ps = $2032;
                  
                  {ESLVal g = $2031;
                  
                  {ESLVal e = $2030;
                  
                  {ESLVal _v1477 = $2029;
                  
                  return getMessageTypes.apply(_v1477).cons(getMessageType.apply(ps));
                }
                }
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(35595,35750)").add(ESLVal.list(_v1090)));
              }
              }
            else if(_v1090.isNil())
              return $nil;
            else return error(new ESLVal("case error at Pos(35595,35750)").add(ESLVal.list(_v1090)));
            }
          }
        });
      ESLVal getMessageType = new ESLVal(new Function(new ESLVal("getMessageType"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal ps = $args[0];
        {ESLVal _v1091 = ps;
              
              if(_v1091.isCons())
              {ESLVal $2034 = _v1091.head();
                ESLVal $2035 = _v1091.tail();
                
                switch($2034.termName) {
                case "PTerm": {ESLVal $2039 = $2034.termRef(0);
                  ESLVal $2038 = $2034.termRef(1);
                  ESLVal $2037 = $2034.termRef(2);
                  ESLVal $2036 = $2034.termRef(3);
                  
                  if($2035.isCons())
                  {ESLVal $2040 = $2035.head();
                    ESLVal $2041 = $2035.tail();
                    
                    return error(new ESLVal("case error at Pos(35800,36071)").add(ESLVal.list(_v1091)));
                  }
                else if($2035.isNil())
                  {ESLVal pl = $2039;
                    
                    {ESLVal termName = $2038;
                    
                    {ESLVal targs = $2037;
                    
                    {ESLVal _v1474 = $2036;
                    
                    {ESLVal ts = map.apply(new ESLVal(new Function(new ESLVal("fun382"),getSelf()) {
                        public ESLVal apply(ESLVal... $args) {
                          ESLVal p = $args[0];
                      return getPatternType(l,p,selfType,valueEnv,cnstrEnv,typeEnv);
                        }
                      }),_v1474);
                    
                    return new ESLVal("MessageType",pl,ESLVal.list(new ESLVal("TermType",pl,termName,ts)));
                  }
                  }
                  }
                  }
                  }
                else return error(new ESLVal("case error at Pos(35800,36071)").add(ESLVal.list(_v1091)));
                }
                default: return error(new ESLVal("case error at Pos(35800,36071)").add(ESLVal.list(_v1091)));
              }
              }
            else if(_v1091.isNil())
              return error(new ESLVal("case error at Pos(35800,36071)").add(ESLVal.list(_v1091)));
            else return error(new ESLVal("case error at Pos(35800,36071)").add(ESLVal.list(_v1091)));
            }
          }
        });
      ESLVal typeCheckArms = new ESLVal(new Function(new ESLVal("typeCheckArms"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1469 = $args[0];
        ESLVal _v1470 = $args[1];
        ESLVal _v1471 = $args[2];
        {ESLVal _v1092 = _v1469;
              
              if(_v1092.isCons())
              {ESLVal $2042 = _v1092.head();
                ESLVal $2043 = _v1092.tail();
                
                switch($2042.termName) {
                case "BArm": {ESLVal $2047 = $2042.termRef(0);
                  ESLVal $2046 = $2042.termRef(1);
                  ESLVal $2045 = $2042.termRef(2);
                  ESLVal $2044 = $2042.termRef(3);
                  
                  {ESLVal _v1472 = $2047;
                  
                  {ESLVal ps = $2046;
                  
                  {ESLVal g = $2045;
                  
                  {ESLVal e = $2044;
                  
                  {ESLVal _v1473 = $2043;
                  
                  {typeCheckArm.apply(_v1472,ps,g,e,_v1470,_v1471);
                return typeCheckArms.apply(_v1473,_v1470,_v1471);}
                }
                }
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(36147,36374)").add(ESLVal.list(_v1092)));
              }
              }
            else if(_v1092.isNil())
              return $null;
            else return error(new ESLVal("case error at Pos(36147,36374)").add(ESLVal.list(_v1092)));
            }
          }
        });
      ESLVal typeCheckArm = new ESLVal(new Function(new ESLVal("typeCheckArm"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1460 = $args[0];
        ESLVal _v1461 = $args[1];
        ESLVal _v1462 = $args[2];
        ESLVal _v1463 = $args[3];
        ESLVal _v1464 = $args[4];
        ESLVal _v1465 = $args[5];
        {ESLVal _v1093 = _v1461;
              
              if(_v1093.isCons())
              {ESLVal $2048 = _v1093.head();
                ESLVal $2049 = _v1093.tail();
                
                switch($2048.termName) {
                case "PTerm": {ESLVal $2053 = $2048.termRef(0);
                  ESLVal $2052 = $2048.termRef(1);
                  ESLVal $2051 = $2048.termRef(2);
                  ESLVal $2050 = $2048.termRef(3);
                  
                  if($2049.isCons())
                  {ESLVal $2054 = $2049.head();
                    ESLVal $2055 = $2049.tail();
                    
                    return error(new ESLVal("case error at Pos(36473,36922)").add(ESLVal.list(_v1093)));
                  }
                else if($2049.isNil())
                  {ESLVal pl = $2053;
                    
                    {ESLVal termName = $2052;
                    
                    {ESLVal targs = $2051;
                    
                    {ESLVal _v1466 = $2050;
                    
                    {ESLVal ts = map.apply(new ESLVal(new Function(new ESLVal("fun383"),getSelf()) {
                        public ESLVal apply(ESLVal... $args) {
                          ESLVal p = $args[0];
                      return getPatternType(_v1460,p,_v1464,_v1465,cnstrEnv,typeEnv);
                        }
                      }),_v1466);
                    
                    {patternTypes(_v1460,_v1466,ts,_v1464,_v1465,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun384"),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      ESLVal _v1467 = $args[0];
                  ESLVal _v1468 = $args[1];
                  return expType(_v1463,_v1464,_v1468,cnstrEnv,typeEnv);
                    }
                  }));
                  return $null;}
                  }
                  }
                  }
                  }
                  }
                else return error(new ESLVal("case error at Pos(36473,36922)").add(ESLVal.list(_v1093)));
                }
                default: return error(new ESLVal("case error at Pos(36473,36922)").add(ESLVal.list(_v1093)));
              }
              }
            else if(_v1093.isNil())
              return error(new ESLVal("case error at Pos(36473,36922)").add(ESLVal.list(_v1093)));
            else return error(new ESLVal("case error at Pos(36473,36922)").add(ESLVal.list(_v1093)));
            }
          }
        });
      
      public ESLVal get(String name) {
        switch(name) {
          case "checkObservedMessage": return checkObservedMessage;
          
          case "isTime": return isTime;
          
          case "checkObserveMessageDeclaration": return checkObserveMessageDeclaration;
          
          case "findLoc": return findLoc;
          
          case "findType": return findType;
          
          case "decs": return decs;
          
          case "getMessageTypes": return getMessageTypes;
          
          case "getMessageType": return getMessageType;
          
          case "typeCheckArms": return typeCheckArms;
          
          case "typeCheckArm": return typeCheckArm;
          
          default: throw new Error("cannot find letrec binding");
        }
        }
      };
    ESLVal checkObservedMessage = letrec.get("checkObservedMessage");
    
    ESLVal isTime = letrec.get("isTime");
    
    ESLVal checkObserveMessageDeclaration = letrec.get("checkObserveMessageDeclaration");
    
    ESLVal findLoc = letrec.get("findLoc");
    
    ESLVal findType = letrec.get("findType");
    
    ESLVal decs = letrec.get("decs");
    
    ESLVal getMessageTypes = letrec.get("getMessageTypes");
    
    ESLVal getMessageType = letrec.get("getMessageType");
    
    ESLVal typeCheckArms = letrec.get("typeCheckArms");
    
    ESLVal typeCheckArm = letrec.get("typeCheckArm");
    
      {ESLVal parentType = ((Supplier<ESLVal>)() -> { 
          if(parent.eql($null).boolVal)
            return actType0;
            else
              return expType(parent,selfType,valueEnv,cnstrEnv,typeEnv);
        }).get();
      ESLVal localEnv = parBind(bindings,selfType,valueEnv,cnstrEnv,typeEnv);
      
      {ESLVal exportedDecs = decs.apply(exports);
      
      {ESLVal messageTypes = getMessageTypes.apply(arms);
      
      {ESLVal _v1512 = new ESLVal("ExtendedAct",l,parentType,exportedDecs,messageTypes);
      ESLVal _v1513 = ESLVal.list(new ESLVal("Map",new ESLVal("$super"),parentType));
      
      {typeCheckExports(l,exportedDecs,bindings,_v1512,localEnv.add(valueEnv),typeEnv,cnstrEnv);
    typeCheckValues(valueDefs(bindings),_v1512,_v1513.add(localEnv.add(valueEnv)),typeEnv,cnstrEnv);
    expType(init,_v1512,_v1513.add(localEnv.add(valueEnv)),cnstrEnv,typeEnv);
    typeCheckArms.apply(arms,_v1512,_v1513.add(localEnv.add(valueEnv)));
    checkObservedMessage.apply();
    return _v1512;}
    }
    }
    }
    }}
    
  }
  private static ESLVal actType = new ESLVal(new Function(new ESLVal("actType"),null) { public ESLVal apply(ESLVal... args) { return actType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7],args[8],args[9],args[10],args[11]); }});
  private static ESLVal typeCheckExports(ESLVal l,ESLVal exports,ESLVal defs,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {{
      ESLVal _v1094 = exports;
      while(_v1094.isCons()) {
        ESLVal e = _v1094.headVal;
        if(exists.apply(new ESLVal(new Function(new ESLVal("fun385"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal b = $args[0];
        return bindingName.apply(b).eql(decName.apply(e)).and(typeEqual.apply(lookupType.apply(decName.apply(e),valueEnv),decType.apply(e)));
          }
        }),defs).boolVal)
          {}
          else
            error(new ESLVal("TypeError",l,new ESLVal(" cannot find export for ").add(decName.apply(e))));
        _v1094 = _v1094.tailVal;}
    }
    return $null;}
  }
  private static ESLVal typeCheckExports = new ESLVal(new Function(new ESLVal("typeCheckExports"),null) { public ESLVal apply(ESLVal... args) { return typeCheckExports(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal bTypeExports(ESLVal t) {
    
    {ESLVal _v1095 = t;
      
      switch(_v1095.termName) {
      case "ExtendedAct": {ESLVal $2066 = _v1095.termRef(0);
        ESLVal $2065 = _v1095.termRef(1);
        ESLVal $2064 = _v1095.termRef(2);
        ESLVal $2063 = _v1095.termRef(3);
        
        {ESLVal l = $2066;
        
        {ESLVal parent = $2065;
        
        {ESLVal exports = $2064;
        
        {ESLVal message = $2063;
        
        return bTypeExports(parent).add(exports);
      }
      }
      }
      }
      }
    case "ActType": {ESLVal $2062 = _v1095.termRef(0);
        ESLVal $2061 = _v1095.termRef(1);
        ESLVal $2060 = _v1095.termRef(2);
        
        {ESLVal l = $2062;
        
        {ESLVal exports = $2061;
        
        {ESLVal message = $2060;
        
        return exports;
      }
      }
      }
      }
    case "TypeClosure": {ESLVal $2059 = _v1095.termRef(0);
        
        {ESLVal f = $2059;
        
        return bTypeExports(f.apply());
      }
      }
    case "RecType": {ESLVal $2058 = _v1095.termRef(0);
        ESLVal $2057 = _v1095.termRef(1);
        ESLVal $2056 = _v1095.termRef(2);
        
        {ESLVal l = $2058;
        
        {ESLVal n = $2057;
        
        {ESLVal _v1459 = $2056;
        
        return bTypeExports(substType.apply(new ESLVal("RecType",l,n,_v1459),n,_v1459));
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(38348,38758)").add(ESLVal.list(_v1095)));
    }
    }
  }
  private static ESLVal bTypeExports = new ESLVal(new Function(new ESLVal("bTypeExports"),null) { public ESLVal apply(ESLVal... args) { return bTypeExports(args[0]); }});
  private static ESLVal cmpType(ESLVal l,ESLVal e,ESLVal qs,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal _v1096 = qs;
      
      if(_v1096.isCons())
      {ESLVal $2067 = _v1096.head();
        ESLVal $2068 = _v1096.tail();
        
        switch($2067.termName) {
        case "BQual": {ESLVal $2073 = $2067.termRef(0);
          ESLVal $2072 = $2067.termRef(1);
          ESLVal $2071 = $2067.termRef(2);
          
          {ESLVal _v1454 = $2073;
          
          {ESLVal p = $2072;
          
          {ESLVal list = $2071;
          
          {ESLVal _v1455 = $2068;
          
          {ESLVal lType = expType(list,selfType,valueEnv,cnstrEnv,typeEnv);
          
          {ESLVal _v1097 = lType;
          
          switch(_v1097.termName) {
          case "ListType": {ESLVal $2075 = _v1097.termRef(0);
            ESLVal $2074 = _v1097.termRef(1);
            
            {ESLVal ll = $2075;
            
            {ESLVal t = $2074;
            
            {ESLVal _v1456 = _v1455;
            
            return patternType(_v1454,p,substTypeEnv.apply(typeEnv,t),selfType,valueEnv,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun386"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v1457 = $args[0];
            ESLVal _v1458 = $args[1];
            return cmpType(_v1454,e,_v1456,selfType,_v1458,cnstrEnv,typeEnv);
              }
            }));
          }
          }
          }
          }
          default: {ESLVal t = _v1097;
            
            return error(new ESLVal("TypeError",_v1454,new ESLVal("qualifier binding expects a list: ").add(ppType(t,typeEnv))));
          }
        }
        }
        }
        }
        }
        }
        }
        }
      case "PQual": {ESLVal $2070 = $2067.termRef(0);
          ESLVal $2069 = $2067.termRef(1);
          
          {ESLVal _v1452 = $2070;
          
          {ESLVal b = $2069;
          
          {ESLVal _v1453 = $2068;
          
          {ESLVal bType = expType(b,selfType,valueEnv,cnstrEnv,typeEnv);
          
          if(isBoolType.apply(bType).boolVal)
          return cmpType(_v1452,e,_v1453,selfType,valueEnv,cnstrEnv,typeEnv);
          else
            return error(new ESLVal("TypeError",_v1452,new ESLVal("qualifier expects a boolean type: ").add(ppType(bType,typeEnv))));
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(38869,39855)").add(ESLVal.list(_v1096)));
      }
      }
    else if(_v1096.isNil())
      {ESLVal t = expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
        
        return new ESLVal("ListType",l,t);
      }
    else return error(new ESLVal("case error at Pos(38869,39855)").add(ESLVal.list(_v1096)));
    }
  }
  private static ESLVal cmpType = new ESLVal(new Function(new ESLVal("cmpType"),null) { public ESLVal apply(ESLVal... args) { return cmpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal updateType(ESLVal l,ESLVal n,ESLVal e,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t = lookupType.apply(n,valueEnv);
      
      if(t.eql($null).boolVal)
      return error(new ESLVal("TypeError",l,new ESLVal("unbound variable ").add(n)));
      else
        {ESLVal valueType = expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
          
          if(subType.apply(valueType,t).boolVal)
          return valueType;
          else
            return error(new ESLVal("TypeError",l,new ESLVal("type of variable ").add(n.add(new ESLVal("::").add(ppType(t,typeEnv).add(new ESLVal(" does not agree with value type ").add(ppType(valueType,typeEnv))))))));
        }
    }
  }
  private static ESLVal updateType = new ESLVal(new Function(new ESLVal("updateType"),null) { public ESLVal apply(ESLVal... args) { return updateType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal letType(ESLVal l,ESLVal bs,ESLVal e,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal env = parBind(bs,selfType,valueEnv,cnstrEnv,typeEnv);
      
      {{
      ESLVal _v1098 = bs;
      while(_v1098.isCons()) {
        ESLVal b = _v1098.headVal;
        typeCheckDef(b,selfType,valueEnv,env.add(valueEnv),cnstrEnv,typeEnv);
        _v1098 = _v1098.tailVal;}
    }
    return expType(e,selfType,env.add(valueEnv),cnstrEnv,typeEnv);}
    }
  }
  private static ESLVal letType = new ESLVal(new Function(new ESLVal("letType"),null) { public ESLVal apply(ESLVal... args) { return letType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal letrecType(ESLVal l,ESLVal bs,ESLVal e,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal env = recBind(bs,selfType,valueEnv,cnstrEnv,typeEnv);
      
      {{
      ESLVal _v1099 = bs;
      while(_v1099.isCons()) {
        ESLVal b = _v1099.headVal;
        typeCheckDef(b,selfType,env.add(valueEnv),env.add(valueEnv),cnstrEnv,typeEnv);
        _v1099 = _v1099.tailVal;}
    }
    return expType(e,selfType,env.add(valueEnv),cnstrEnv,typeEnv);}
    }
  }
  private static ESLVal letrecType = new ESLVal(new Function(new ESLVal("letrecType"),null) { public ESLVal apply(ESLVal... args) { return letrecType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal checkDupBindings(ESLVal bs) {
    
    {ESLVal _v1100 = bs;
      
      if(_v1100.isCons())
      {ESLVal $2076 = _v1100.head();
        ESLVal $2077 = _v1100.tail();
        
        {ESLVal b = $2076;
        
        {ESLVal _v1451 = $2077;
        
        if(member.apply(bindingName.apply(b),new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal b = $l0.head();
            $l0 = $l0.tail();
            $v.add(bindingName.apply(b));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(_v1451)).boolVal)
        return error(new ESLVal("TypeError",bindingLoc.apply(b),new ESLVal("duplicate definitions for ").add(bindingName.apply(b))));
        else
          return checkDupBindings(_v1451);
      }
      }
      }
    else if(_v1100.isNil())
      return $null;
    else return error(new ESLVal("case error at Pos(41101,41366)").add(ESLVal.list(_v1100)));
    }
  }
  private static ESLVal checkDupBindings = new ESLVal(new Function(new ESLVal("checkDupBindings"),null) { public ESLVal apply(ESLVal... args) { return checkDupBindings(args[0]); }});
  private static ESLVal parBind(ESLVal bs,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {checkDupBindings(bs);
    return valueDefsToTEnv(valueDefs(bs),selfType,valueEnv,cnstrEnv,typeEnv);}
  }
  private static ESLVal parBind = new ESLVal(new Function(new ESLVal("parBind"),null) { public ESLVal apply(ESLVal... args) { return parBind(args[0],args[1],args[2],args[3],args[4]); }});
  private static ESLVal recBind(ESLVal bs,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    return valueDefsToTEnv(valueDefs(bs),selfType,valueEnv,cnstrEnv,typeEnv);
  }
  private static ESLVal recBind = new ESLVal(new Function(new ESLVal("recBind"),null) { public ESLVal apply(ESLVal... args) { return recBind(args[0],args[1],args[2],args[3],args[4]); }});
  private static ESLVal caseType(ESLVal l,ESLVal es,ESLVal arms,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal ts1 = expTypes(es,selfType,valueEnv,cnstrEnv,typeEnv);
      
      {ESLVal ts2 = armTypes(arms,ts1,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(allEqualTypes.apply(head.apply(ts2),tail.apply(ts2)).boolVal)
      return head.apply(ts2);
      else
        return error(new ESLVal("TypeError",l,new ESLVal("case arm types do not agree: ").add(ppTypes(ts1,typeEnv).add(new ESLVal(" ").add(ppTypes(ts2,typeEnv))))));
    }
    }
  }
  private static ESLVal caseType = new ESLVal(new Function(new ESLVal("caseType"),null) { public ESLVal apply(ESLVal... args) { return caseType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal tryType(ESLVal l,ESLVal e,ESLVal arms,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal ts1 = expTypes(ESLVal.list(e),selfType,valueEnv,cnstrEnv,typeEnv);
      
      {ESLVal ts2 = armTypes(arms,ts1,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(allEqualTypes.apply(head.apply(ts2),tail.apply(ts2)).boolVal)
      return head.apply(ts2);
      else
        return error(new ESLVal("TypeError",l,new ESLVal("try arm types do not agree: ").add(ppTypes(ts1,typeEnv).add(new ESLVal(" ").add(ppTypes(ts2,typeEnv))))));
    }
    }
  }
  private static ESLVal tryType = new ESLVal(new Function(new ESLVal("tryType"),null) { public ESLVal apply(ESLVal... args) { return tryType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal armTypes(ESLVal arms,ESLVal ts,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal _v1101 = arms;
      
      if(_v1101.isCons())
      {ESLVal $2078 = _v1101.head();
        ESLVal $2079 = _v1101.tail();
        
        {ESLVal a = $2078;
        
        {ESLVal _v1450 = $2079;
        
        return armTypes(_v1450,ts,selfType,valueEnv,cnstrEnv,typeEnv).cons(armType(a,ts,selfType,valueEnv,cnstrEnv,typeEnv));
      }
      }
      }
    else if(_v1101.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(42731,42900)").add(ESLVal.list(_v1101)));
    }
  }
  private static ESLVal armTypes = new ESLVal(new Function(new ESLVal("armTypes"),null) { public ESLVal apply(ESLVal... args) { return armTypes(args[0],args[1],args[2],args[3],args[4],args[5]); }});
  private static ESLVal armType(ESLVal arm,ESLVal ts,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal _v1102 = arm;
      
      switch(_v1102.termName) {
      case "BArm": {ESLVal $2083 = _v1102.termRef(0);
        ESLVal $2082 = _v1102.termRef(1);
        ESLVal $2081 = _v1102.termRef(2);
        ESLVal $2080 = _v1102.termRef(3);
        
        {ESLVal l = $2083;
        
        {ESLVal ps = $2082;
        
        {ESLVal guard = $2081;
        
        {ESLVal exp = $2080;
        
        {checkPatterns(l,ps);
      if(length.apply(ps).eql(length.apply(ts)).boolVal)
        return patternTypes(l,ps,ts,selfType,valueEnv,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun387"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1448 = $args[0];
          ESLVal _v1449 = $args[1];
          return guardedExpType(l,guard,exp,selfType,_v1449,cnstrEnv,typeEnv);
            }
          }));
        else
          return error(new ESLVal("TypeError",l,new ESLVal("number of patterns ").add(length.apply(ps).add(new ESLVal(" does not match supplied values: ").add(length.apply(ts))))));}
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(43002,43463)").add(ESLVal.list(_v1102)));
    }
    }
  }
  private static ESLVal armType = new ESLVal(new Function(new ESLVal("armType"),null) { public ESLVal apply(ESLVal... args) { return armType(args[0],args[1],args[2],args[3],args[4],args[5]); }});
  private static ESLVal refType(ESLVal l,ESLVal e,ESLVal n,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    { LetRec letrec = new LetRec() {
      ESLVal t = derefType(expType(e,selfType,valueEnv,cnstrEnv,typeEnv));
      ESLVal findExport = new ESLVal(new Function(new ESLVal("findExport"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal decs = $args[0];
        {ESLVal _v1103 = decs;
              
              if(_v1103.isCons())
              {ESLVal $2084 = _v1103.head();
                ESLVal $2085 = _v1103.tail();
                
                switch($2084.termName) {
                case "Dec": {ESLVal $2089 = $2084.termRef(0);
                  ESLVal $2088 = $2084.termRef(1);
                  ESLVal $2087 = $2084.termRef(2);
                  ESLVal $2086 = $2084.termRef(3);
                  
                  {ESLVal _v1419 = $2089;
                  
                  {ESLVal m = $2088;
                  
                  {ESLVal t = $2087;
                  
                  {ESLVal st = $2086;
                  
                  {ESLVal _v1420 = $2085;
                  
                  if(m.eql(n).boolVal)
                  return t;
                  else
                    {ESLVal d = $2084;
                      
                      {ESLVal _v1421 = $2085;
                      
                      return findExport.apply(_v1421);
                    }
                    }
                }
                }
                }
                }
                }
                }
                default: {ESLVal d = $2084;
                  
                  {ESLVal _v1422 = $2085;
                  
                  return findExport.apply(_v1422);
                }
                }
              }
              }
            else if(_v1103.isNil())
              return $null;
            else return error(new ESLVal("case error at Pos(43691,43864)").add(ESLVal.list(_v1103)));
            }
          }
        });
      ESLVal findField = new ESLVal(new Function(new ESLVal("findField"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal fs = $args[0];
        {ESLVal _v1104 = fs;
              
              if(_v1104.isCons())
              {ESLVal $2090 = _v1104.head();
                ESLVal $2091 = _v1104.tail();
                
                switch($2090.termName) {
                case "Dec": {ESLVal $2095 = $2090.termRef(0);
                  ESLVal $2094 = $2090.termRef(1);
                  ESLVal $2093 = $2090.termRef(2);
                  ESLVal $2092 = $2090.termRef(3);
                  
                  {ESLVal _v1414 = $2095;
                  
                  {ESLVal m = $2094;
                  
                  {ESLVal t = $2093;
                  
                  {ESLVal ds = $2092;
                  
                  {ESLVal _v1415 = $2091;
                  
                  if(m.eql(n).boolVal)
                  return t;
                  else
                    {ESLVal _v1416 = $2090;
                      
                      {ESLVal _v1417 = $2091;
                      
                      return findField.apply(_v1417);
                    }
                    }
                }
                }
                }
                }
                }
                }
                default: {ESLVal t = $2090;
                  
                  {ESLVal _v1418 = $2091;
                  
                  return findField.apply(_v1418);
                }
                }
              }
              }
            else if(_v1104.isNil())
              return error(new ESLVal("TypeError",l,new ESLVal("cannot find field name ").add(n)));
            else return error(new ESLVal("case error at Pos(43905,44113)").add(ESLVal.list(_v1104)));
            }
          }
        });
      ESLVal exportsObserve = new ESLVal(new Function(new ESLVal("exportsObserve"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal exports = $args[0];
        {ESLVal _v1105 = exports;
              
              if(_v1105.isCons())
              {ESLVal $2096 = _v1105.head();
                ESLVal $2097 = _v1105.tail();
                
                switch($2096.termName) {
                case "Dec": {ESLVal $2101 = $2096.termRef(0);
                  ESLVal $2100 = $2096.termRef(1);
                  ESLVal $2099 = $2096.termRef(2);
                  ESLVal $2098 = $2096.termRef(3);
                  
                  switch($2100.strVal) {
                  case "observeState": switch($2099.termName) {
                    case "FunType": {ESLVal $2104 = $2099.termRef(0);
                      ESLVal $2103 = $2099.termRef(1);
                      ESLVal $2102 = $2099.termRef(2);
                      
                      if($2103.isCons())
                      {ESLVal $2105 = $2103.head();
                        ESLVal $2106 = $2103.tail();
                        
                        {ESLVal d = $2096;
                        
                        {ESLVal _v1409 = $2097;
                        
                        return exportsObserve.apply(_v1409);
                      }
                      }
                      }
                    else if($2103.isNil())
                      {ESLVal dl = $2101;
                        
                        {ESLVal fl = $2104;
                        
                        {ESLVal stateType = $2102;
                        
                        {ESLVal dt = $2098;
                        
                        {ESLVal x = $2097;
                        
                        return $true;
                      }
                      }
                      }
                      }
                      }
                    else {ESLVal d = $2096;
                        
                        {ESLVal _v1410 = $2097;
                        
                        return exportsObserve.apply(_v1410);
                      }
                      }
                    }
                    default: {ESLVal d = $2096;
                      
                      {ESLVal _v1411 = $2097;
                      
                      return exportsObserve.apply(_v1411);
                    }
                    }
                  }
                  default: {ESLVal d = $2096;
                    
                    {ESLVal _v1412 = $2097;
                    
                    return exportsObserve.apply(_v1412);
                  }
                  }
                }
                }
                default: {ESLVal d = $2096;
                  
                  {ESLVal _v1413 = $2097;
                  
                  return exportsObserve.apply(_v1413);
                }
                }
              }
              }
            else if(_v1105.isNil())
              return $false;
            else return error(new ESLVal("case error at Pos(44164,44323)").add(ESLVal.list(_v1105)));
            }
          }
        });
      ESLVal getObserver = new ESLVal(new Function(new ESLVal("getObserver"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1398 = $args[0];
        ESLVal _v1399 = $args[1];
        ESLVal _v1400 = $args[2];
        {ESLVal _v1106 = _v1399;
              
              return $ndCase.apply(_v1106,ESLVal.list(new ESLVal("$selectMid",new ESLVal(new Function(new ESLVal("add"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $2108 = $args[0];
              ESLVal $2109 = $args[1];
              ESLVal $2110 = $args[2];
              ESLVal $2107 = $args[3];
              switch($2109.termName) {
                    case "Dec": {ESLVal $2114 = $2109.termRef(0);
                      ESLVal $2113 = $2109.termRef(1);
                      ESLVal $2112 = $2109.termRef(2);
                      ESLVal $2111 = $2109.termRef(3);
                      
                      switch($2113.strVal) {
                      case "observeState": switch($2112.termName) {
                        case "FunType": {ESLVal $2117 = $2112.termRef(0);
                          ESLVal $2116 = $2112.termRef(1);
                          ESLVal $2115 = $2112.termRef(2);
                          
                          if($2116.isCons())
                          {ESLVal $2118 = $2116.head();
                            ESLVal $2119 = $2116.tail();
                            
                            return $2107.apply();
                          }
                        else if($2116.isNil())
                          {ESLVal e1 = $2108;
                            
                            {ESLVal dl = $2114;
                            
                            {ESLVal fl = $2117;
                            
                            {ESLVal stateType = $2115;
                            
                            {ESLVal dt = $2111;
                            
                            {ESLVal e2 = $2110;
                            
                            {ESLVal _v1107 = _v1399;
                            
                            return $ndCase.apply(_v1107,ESLVal.list(new ESLVal("$selectMid",new ESLVal(new Function(new ESLVal("add"),getSelf()) {
                              public ESLVal apply(ESLVal... $args) {
                                ESLVal $2121 = $args[0];
                            ESLVal $2122 = $args[1];
                            ESLVal $2123 = $args[2];
                            ESLVal $2120 = $args[3];
                            switch($2122.termName) {
                                  case "Dec": {ESLVal $2127 = $2122.termRef(0);
                                    ESLVal $2126 = $2122.termRef(1);
                                    ESLVal $2125 = $2122.termRef(2);
                                    ESLVal $2124 = $2122.termRef(3);
                                    
                                    switch($2126.strVal) {
                                    case "observeMessage": switch($2125.termName) {
                                      case "FunType": {ESLVal $2130 = $2125.termRef(0);
                                        ESLVal $2129 = $2125.termRef(1);
                                        ESLVal $2128 = $2125.termRef(2);
                                        
                                        if($2129.isCons())
                                        {ESLVal $2131 = $2129.head();
                                          ESLVal $2132 = $2129.tail();
                                          
                                          if($2132.isCons())
                                          {ESLVal $2133 = $2132.head();
                                            ESLVal $2134 = $2132.tail();
                                            
                                            return $2120.apply();
                                          }
                                        else if($2132.isNil())
                                          {ESLVal _v1401 = $2121;
                                            
                                            {ESLVal _v1402 = $2127;
                                            
                                            {ESLVal _v1403 = $2130;
                                            
                                            {ESLVal t = $2131;
                                            
                                            {ESLVal messageType = $2128;
                                            
                                            {ESLVal _v1404 = $2124;
                                            
                                            {ESLVal _v1405 = $2123;
                                            
                                            {ESLVal _v1108 = typeNF(messageType,typeEnv);
                                            
                                            switch(_v1108.termName) {
                                            case "UnionType": {ESLVal $2136 = _v1108.termRef(0);
                                              ESLVal $2135 = _v1108.termRef(1);
                                              
                                              return $ndCase.apply($2135,ESLVal.list(new ESLVal("$selectMid",new ESLVal(new Function(new ESLVal("add"),getSelf()) {
                                                public ESLVal apply(ESLVal... $args) {
                                                  ESLVal $2138 = $args[0];
                                              ESLVal $2139 = $args[1];
                                              ESLVal $2140 = $args[2];
                                              ESLVal $2137 = $args[3];
                                              switch($2139.termName) {
                                                    case "TermType": {ESLVal $2143 = $2139.termRef(0);
                                                      ESLVal $2142 = $2139.termRef(1);
                                                      ESLVal $2141 = $2139.termRef(2);
                                                      
                                                      switch($2142.strVal) {
                                                      case "Something": if($2141.isCons())
                                                        {ESLVal $2144 = $2141.head();
                                                          ESLVal $2145 = $2141.tail();
                                                          
                                                          if($2145.isCons())
                                                          {ESLVal $2146 = $2145.head();
                                                            ESLVal $2147 = $2145.tail();
                                                            
                                                            return $2137.apply();
                                                          }
                                                        else if($2145.isNil())
                                                          {ESLVal ul = $2136;
                                                            
                                                            {ESLVal ts1 = $2138;
                                                            
                                                            {ESLVal tl = $2143;
                                                            
                                                            {ESLVal _v1406 = $2144;
                                                            
                                                            {ESLVal ts2 = $2140;
                                                            
                                                            return new ESLVal("ObserverType",_v1398,stateType,_v1406);
                                                          }
                                                          }
                                                          }
                                                          }
                                                          }
                                                        else return $2137.apply();
                                                        }
                                                      else if($2141.isNil())
                                                        return $2137.apply();
                                                      else return $2137.apply();
                                                      default: return $2137.apply();
                                                    }
                                                    }
                                                    default: return $2137.apply();
                                                  }
                                                }
                                              }))),new ESLVal(new Function(new ESLVal("listFail"),getSelf()) {
                                                public ESLVal apply(ESLVal... $args) {
                                                  {ESLVal _v1407 = _v1108;
                                                    
                                                    return error(new ESLVal("TypeError",_v1398,new ESLVal("cannot find Something(t) for the message type: ").add(typeNF(messageType,typeEnv))));
                                                  }
                                                }
                                              }));
                                            }
                                            default: {ESLVal _v1408 = _v1108;
                                              
                                              return error(new ESLVal("TypeError",_v1398,new ESLVal("cannot find Something(t) for the message type: ").add(typeNF(messageType,typeEnv))));
                                            }
                                          }
                                          }
                                          }
                                          }
                                          }
                                          }
                                          }
                                          }
                                          }
                                        else return $2120.apply();
                                        }
                                      else if($2129.isNil())
                                        return $2120.apply();
                                      else return $2120.apply();
                                      }
                                      default: return $2120.apply();
                                    }
                                    default: return $2120.apply();
                                  }
                                  }
                                  default: return $2120.apply();
                                }
                              }
                            }))),new ESLVal(new Function(new ESLVal("listFail"),getSelf()) {
                              public ESLVal apply(ESLVal... $args) {
                                return error(new ESLVal("case error at Pos(44497,44919)").add(ESLVal.list(_v1107)));
                              }
                            }));
                          }
                          }
                          }
                          }
                          }
                          }
                          }
                        else return $2107.apply();
                        }
                        default: return $2107.apply();
                      }
                      default: return $2107.apply();
                    }
                    }
                    default: return $2107.apply();
                  }
                }
              }))),new ESLVal(new Function(new ESLVal("listFail"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  {ESLVal es = _v1106;
                    
                    return $null;
                  }
                }
              }));
            }
          }
        });
      
      public ESLVal get(String name) {
        switch(name) {
          case "t": return t;
          
          case "findExport": return findExport;
          
          case "findField": return findField;
          
          case "exportsObserve": return exportsObserve;
          
          case "getObserver": return getObserver;
          
          default: throw new Error("cannot find letrec binding");
        }
        }
      };
    ESLVal t = letrec.get("t");
    
    ESLVal findExport = letrec.get("findExport");
    
    ESLVal findField = letrec.get("findField");
    
    ESLVal exportsObserve = letrec.get("exportsObserve");
    
    ESLVal getObserver = letrec.get("getObserver");
    
      {ESLVal _v1109 = typeNF(t,typeEnv);
      
      switch(_v1109.termName) {
      case "StrType": {ESLVal $2161 = _v1109.termRef(0);
        
        {ESLVal sl = $2161;
        
        if(n.eql(new ESLVal("explode")).boolVal)
        return new ESLVal("ListType",sl,new ESLVal("IntType",sl));
        else
          {ESLVal _v1445 = $2161;
            
            if(n.eql(new ESLVal("writeDate")).boolVal)
            return new ESLVal("FloatType",_v1445);
            else
              {ESLVal _v1446 = _v1109;
                
                return error(new ESLVal("TypeError",l,new ESLVal("expecting a record type, but received ").add(ppType(_v1446,typeEnv))));
              }
          }
      }
      }
    case "TableType": {ESLVal $2160 = _v1109.termRef(0);
        ESLVal $2159 = _v1109.termRef(1);
        ESLVal $2158 = _v1109.termRef(2);
        
        {ESLVal _v1428 = $2160;
        
        {ESLVal k = $2159;
        
        {ESLVal v = $2158;
        
        if(n.eql(new ESLVal("get")).boolVal)
        return new ESLVal("FunType",_v1428,ESLVal.list(k),v);
        else
          {ESLVal _v1429 = $2160;
            
            {ESLVal _v1430 = $2159;
            
            {ESLVal _v1431 = $2158;
            
            if(n.eql(new ESLVal("put")).boolVal)
            return new ESLVal("FunType",_v1429,ESLVal.list(_v1430,_v1431),t);
            else
              {ESLVal _v1432 = $2160;
                
                {ESLVal _v1433 = $2159;
                
                {ESLVal _v1434 = $2158;
                
                if(n.eql(new ESLVal("keys")).boolVal)
                return new ESLVal("ListType",_v1432,_v1433);
                else
                  {ESLVal _v1435 = $2160;
                    
                    {ESLVal _v1436 = $2159;
                    
                    {ESLVal _v1437 = $2158;
                    
                    if(n.eql(new ESLVal("vals")).boolVal)
                    return new ESLVal("ListType",_v1435,_v1437);
                    else
                      {ESLVal _v1438 = $2160;
                        
                        {ESLVal _v1439 = $2159;
                        
                        {ESLVal _v1440 = $2158;
                        
                        if(n.eql(new ESLVal("hasKey")).boolVal)
                        return new ESLVal("FunType",_v1438,ESLVal.list(_v1439),new ESLVal("BoolType",_v1438));
                        else
                          {ESLVal _v1441 = $2160;
                            
                            {ESLVal _v1442 = $2159;
                            
                            {ESLVal _v1443 = $2158;
                            
                            if(n.eql(new ESLVal("clear")).boolVal)
                            return new ESLVal("FunType",_v1441,ESLVal.list(),new ESLVal("VoidType",_v1441));
                            else
                              {ESLVal _v1444 = _v1109;
                                
                                return error(new ESLVal("TypeError",_v1441,new ESLVal("expecting a record type, but received ").add(ppType(_v1444,typeEnv))));
                              }
                          }
                          }
                          }
                      }
                      }
                      }
                  }
                  }
                  }
              }
              }
              }
          }
          }
          }
      }
      }
      }
      }
    case "ListType": {ESLVal $2157 = _v1109.termRef(0);
        ESLVal $2156 = _v1109.termRef(1);
        
        {ESLVal ll = $2157;
        
        {ESLVal _v1426 = $2156;
        
        if(n.eql(new ESLVal("implode")).boolVal)
        return new ESLVal("StrType",ll);
        else
          {ESLVal _v1427 = _v1109;
            
            return error(new ESLVal("TypeError",l,new ESLVal("expecting a record type, but received ").add(ppType(_v1427,typeEnv))));
          }
      }
      }
      }
    case "RecordType": {ESLVal $2155 = _v1109.termRef(0);
        ESLVal $2154 = _v1109.termRef(1);
        
        {ESLVal rl = $2155;
        
        {ESLVal fs = $2154;
        
        return findField.apply(fs);
      }
      }
      }
    case "ObservedType": {ESLVal $2153 = _v1109.termRef(0);
        ESLVal $2152 = _v1109.termRef(1);
        ESLVal $2151 = _v1109.termRef(2);
        
        {ESLVal _v1424 = $2153;
        
        {ESLVal s = $2152;
        
        {ESLVal m = $2151;
        
        if(n.eql(new ESLVal("addObserver")).boolVal)
        return new ESLVal("FunType",_v1424,ESLVal.list(new ESLVal("ObserverType",_v1424,s,m)),new ESLVal("VoidType",new ESLVal("Pos",$zero,$zero)));
        else
          {ESLVal _v1425 = _v1109;
            
            return error(new ESLVal("TypeError",_v1424,new ESLVal("expecting a record type, but received ").add(ppType(_v1425,typeEnv))));
          }
      }
      }
      }
      }
    case "ActType": {ESLVal $2150 = _v1109.termRef(0);
        ESLVal $2149 = _v1109.termRef(1);
        ESLVal $2148 = _v1109.termRef(2);
        
        {ESLVal al = $2150;
        
        {ESLVal exports = $2149;
        
        {ESLVal handlers = $2148;
        
        if(n.eql(new ESLVal("addObserver")).and(exportsObserve.apply(exports)).boolVal)
        return new ESLVal("FunType",l,ESLVal.list(getObserver.apply(al,exports,handlers)),new ESLVal("VoidType",new ESLVal("Pos",$zero,$zero)));
        else
          {ESLVal _v1423 = findExport.apply(exports);
            
            if(_v1423.eql($null).boolVal)
            return error(new ESLVal("TypeError",l,new ESLVal("behaviour type does not export ").add(n)));
            else
              return substTypeEnv.apply(typeEnv,_v1423);
          }
      }
      }
      }
      }
      default: {ESLVal _v1447 = _v1109;
        
        return error(new ESLVal("TypeError",l,new ESLVal("expecting a record type, but received ").add(ppType(_v1447,typeEnv))));
      }
    }
    }}
    
  }
  private static ESLVal refType = new ESLVal(new Function(new ESLVal("refType"),null) { public ESLVal apply(ESLVal... args) { return refType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal derefType(ESLVal t) {
    
    {ESLVal _v1110 = t;
      
      switch(_v1110.termName) {
      case "TypeClosure": {ESLVal $2162 = _v1110.termRef(0);
        
        {ESLVal f = $2162;
        
        return derefType(f.apply());
      }
      }
      default: {ESLVal _v1397 = _v1110;
        
        return _v1397;
      }
    }
    }
  }
  private static ESLVal derefType = new ESLVal(new Function(new ESLVal("derefType"),null) { public ESLVal apply(ESLVal... args) { return derefType(args[0]); }});
  private static ESLVal recordType(ESLVal l,ESLVal fields,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    { LetRec letrec = new LetRec() {
      ESLVal fieldTypes = new ESLVal(new Function(new ESLVal("fieldTypes"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1391 = $args[0];
        {ESLVal _v1111 = _v1391;
              
              if(_v1111.isCons())
              {ESLVal $2163 = _v1111.head();
                ESLVal $2164 = _v1111.tail();
                
                switch($2163.termName) {
                case "Binding": {ESLVal $2169 = $2163.termRef(0);
                  ESLVal $2168 = $2163.termRef(1);
                  ESLVal $2167 = $2163.termRef(2);
                  ESLVal $2166 = $2163.termRef(3);
                  ESLVal $2165 = $2163.termRef(4);
                  
                  {ESLVal _v1392 = $2169;
                  
                  {ESLVal n = $2168;
                  
                  {ESLVal t = $2167;
                  
                  {ESLVal st = $2166;
                  
                  {ESLVal e = $2165;
                  
                  {ESLVal _v1393 = $2164;
                  
                  {ESLVal _v1394 = expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
                  
                  return fieldTypes.apply(_v1393).cons(new ESLVal("Dec",_v1392,n,_v1394,_v1394));
                }
                }
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v1395 = _v1111;
                  
                  return error(new ESLVal("TypeError",l,new ESLVal("unknown field representation: ").add(_v1395)));
                }
              }
              }
            else if(_v1111.isNil())
              return $nil;
            else {ESLVal _v1396 = _v1111;
                
                return error(new ESLVal("TypeError",l,new ESLVal("unknown field representation: ").add(_v1396)));
              }
            }
          }
        });
      
      public ESLVal get(String name) {
        switch(name) {
          case "fieldTypes": return fieldTypes;
          
          default: throw new Error("cannot find letrec binding");
        }
        }
      };
    ESLVal fieldTypes = letrec.get("fieldTypes");
    
      return new ESLVal("RecordType",l,fieldTypes.apply(fields));}
    
  }
  private static ESLVal recordType = new ESLVal(new Function(new ESLVal("recordType"),null) { public ESLVal apply(ESLVal... args) { return recordType(args[0],args[1],args[2],args[3],args[4],args[5]); }});
  private static ESLVal forType(ESLVal l,ESLVal p,ESLVal list,ESLVal body,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal listType = expType(list,selfType,valueEnv,cnstrEnv,typeEnv);
      
      {ESLVal _v1112 = listType;
      
      switch(_v1112.termName) {
      case "ListType": {ESLVal $2171 = _v1112.termRef(0);
        ESLVal $2170 = _v1112.termRef(1);
        
        {ESLVal _v1388 = $2171;
        
        {ESLVal t = $2170;
        
        return patternType(_v1388,p,t,selfType,valueEnv,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun388"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1389 = $args[0];
        ESLVal _v1390 = $args[1];
        return expType(body,selfType,_v1390,cnstrEnv,typeEnv);
          }
        }));
      }
      }
      }
      default: {ESLVal t = _v1112;
        
        return error(new ESLVal("TypeError",l,new ESLVal("for type expects a list: ").add(list)));
      }
    }
    }
    }
  }
  private static ESLVal forType = new ESLVal(new Function(new ESLVal("forType"),null) { public ESLVal apply(ESLVal... args) { return forType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7]); }});
  private static ESLVal patternTypes(ESLVal l,ESLVal ps,ESLVal ts,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv,ESLVal f) {
    
    {ESLVal _v1113 = ps;
      ESLVal _v1114 = ts;
      
      if(_v1113.isCons())
      {ESLVal $2172 = _v1113.head();
        ESLVal $2173 = _v1113.tail();
        
        if(_v1114.isCons())
        {ESLVal $2174 = _v1114.head();
          ESLVal $2175 = _v1114.tail();
          
          {ESLVal p = $2172;
          
          {ESLVal _v1370 = $2173;
          
          {ESLVal t = $2174;
          
          {ESLVal _v1371 = $2175;
          
          {ESLVal _v1372 = _v1370;
          ESLVal _v1373 = _v1371;
          
          return patternType(l,p,t,selfType,valueEnv,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun389"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1374 = $args[0];
          ESLVal _v1375 = $args[1];
          return patternTypes(l,_v1372,_v1373,selfType,_v1375,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun390"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal _v1376 = $args[0];
                ESLVal _v1377 = $args[1];
                return f.apply(_v1376.cons(_v1374),_v1377);
                  }
                }));
            }
          }));
        }
        }
        }
        }
        }
        }
      else if(_v1114.isNil())
        {ESLVal _v1378 = _v1113;
          
          {ESLVal _v1379 = _v1114;
          
          return error(new ESLVal("TypeError",l,new ESLVal("somthing wrong with ").add(_v1378.add(new ESLVal(" ").add(_v1379)))));
        }
        }
      else {ESLVal _v1380 = _v1113;
          
          {ESLVal _v1381 = _v1114;
          
          return error(new ESLVal("TypeError",l,new ESLVal("somthing wrong with ").add(_v1380.add(new ESLVal(" ").add(_v1381)))));
        }
        }
      }
    else if(_v1113.isNil())
      if(_v1114.isCons())
        {ESLVal $2176 = _v1114.head();
          ESLVal $2177 = _v1114.tail();
          
          {ESLVal _v1382 = _v1113;
          
          {ESLVal _v1383 = _v1114;
          
          return error(new ESLVal("TypeError",l,new ESLVal("somthing wrong with ").add(_v1382.add(new ESLVal(" ").add(_v1383)))));
        }
        }
        }
      else if(_v1114.isNil())
        return f.apply($nil,valueEnv);
      else {ESLVal _v1384 = _v1113;
          
          {ESLVal _v1385 = _v1114;
          
          return error(new ESLVal("TypeError",l,new ESLVal("somthing wrong with ").add(_v1384.add(new ESLVal(" ").add(_v1385)))));
        }
        }
    else {ESLVal _v1386 = _v1113;
        
        {ESLVal _v1387 = _v1114;
        
        return error(new ESLVal("TypeError",l,new ESLVal("somthing wrong with ").add(_v1386.add(new ESLVal(" ").add(_v1387)))));
      }
      }
    }
  }
  private static ESLVal patternTypes = new ESLVal(new Function(new ESLVal("patternTypes"),null) { public ESLVal apply(ESLVal... args) { return patternTypes(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7]); }});
  private static ESLVal getPatternType(ESLVal l,ESLVal p,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal _v1115 = p;
      
      switch(_v1115.termName) {
      case "PApplyType": {ESLVal $2206 = _v1115.termRef(0);
        ESLVal $2205 = _v1115.termRef(1);
        ESLVal $2204 = _v1115.termRef(2);
        
        {ESLVal _v1367 = $2206;
        
        {ESLVal _v1368 = $2205;
        
        {ESLVal args = $2204;
        
        return error(new ESLVal("should this happen?"));
      }
      }
      }
      }
    case "PBool": {ESLVal $2203 = _v1115.termRef(0);
        ESLVal $2202 = _v1115.termRef(1);
        
        {ESLVal _v1366 = $2203;
        
        {ESLVal b = $2202;
        
        return new ESLVal("BoolType",_v1366);
      }
      }
      }
    case "PCons": {ESLVal $2201 = _v1115.termRef(0);
        ESLVal $2200 = _v1115.termRef(1);
        ESLVal $2199 = _v1115.termRef(2);
        
        {ESLVal _v1365 = $2201;
        
        {ESLVal hd = $2200;
        
        {ESLVal tl = $2199;
        
        return getPatternType(_v1365,tl,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "PBagCons": {ESLVal $2198 = _v1115.termRef(0);
        ESLVal $2197 = _v1115.termRef(1);
        ESLVal $2196 = _v1115.termRef(2);
        
        {ESLVal _v1364 = $2198;
        
        {ESLVal hd = $2197;
        
        {ESLVal tl = $2196;
        
        return getPatternType(_v1364,tl,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "PSetCons": {ESLVal $2195 = _v1115.termRef(0);
        ESLVal $2194 = _v1115.termRef(1);
        ESLVal $2193 = _v1115.termRef(2);
        
        {ESLVal _v1363 = $2195;
        
        {ESLVal hd = $2194;
        
        {ESLVal tl = $2193;
        
        return getPatternType(_v1363,tl,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "PNil": {ESLVal $2192 = _v1115.termRef(0);
        
        {ESLVal _v1362 = $2192;
        
        return new ESLVal("ForallType",_v1362,ESLVal.list(new ESLVal("T")),new ESLVal("ListType",_v1362,new ESLVal("VarType",_v1362,new ESLVal("T"))));
      }
      }
    case "PNull": {ESLVal $2191 = _v1115.termRef(0);
        
        {ESLVal _v1361 = $2191;
        
        return new ESLVal("ForallType",_v1361,ESLVal.list(new ESLVal("T")),new ESLVal("VarType",_v1361,new ESLVal("T")));
      }
      }
    case "PEmptyBag": {ESLVal $2190 = _v1115.termRef(0);
        
        {ESLVal _v1360 = $2190;
        
        return new ESLVal("ForallType",_v1360,ESLVal.list(new ESLVal("T")),new ESLVal("BagType",_v1360,new ESLVal("VarType",_v1360,new ESLVal("T"))));
      }
      }
    case "PEmptySet": {ESLVal $2189 = _v1115.termRef(0);
        
        {ESLVal _v1359 = $2189;
        
        return new ESLVal("ForallType",_v1359,ESLVal.list(new ESLVal("T")),new ESLVal("SetType",_v1359,new ESLVal("VarType",_v1359,new ESLVal("T"))));
      }
      }
    case "PInt": {ESLVal $2188 = _v1115.termRef(0);
        ESLVal $2187 = _v1115.termRef(1);
        
        {ESLVal _v1358 = $2188;
        
        {ESLVal n = $2187;
        
        return new ESLVal("IntType",_v1358);
      }
      }
      }
    case "PVar": {ESLVal $2186 = _v1115.termRef(0);
        ESLVal $2185 = _v1115.termRef(1);
        ESLVal $2184 = _v1115.termRef(2);
        
        {ESLVal _v1357 = $2186;
        
        {ESLVal n = $2185;
        
        {ESLVal pt = $2184;
        
        return substTypeEnv.apply(typeEnv,pt);
      }
      }
      }
      }
    case "PStr": {ESLVal $2183 = _v1115.termRef(0);
        ESLVal $2182 = _v1115.termRef(1);
        
        {ESLVal _v1356 = $2183;
        
        {ESLVal s = $2182;
        
        return new ESLVal("StrType",_v1356);
      }
      }
      }
    case "PTerm": {ESLVal $2181 = _v1115.termRef(0);
        ESLVal $2180 = _v1115.termRef(1);
        ESLVal $2179 = _v1115.termRef(2);
        ESLVal $2178 = _v1115.termRef(3);
        
        {ESLVal _v1355 = $2181;
        
        {ESLVal n = $2180;
        
        {ESLVal ts = $2179;
        
        {ESLVal ps = $2178;
        
        return lookupType.apply(n,cnstrEnv);
      }
      }
      }
      }
      }
      default: {ESLVal _v1369 = _v1115;
        
        return error(new ESLVal("TypeError",l,new ESLVal("unknown type of pattern: ").add(_v1369)));
      }
    }
    }
  }
  private static ESLVal getPatternType = new ESLVal(new Function(new ESLVal("getPatternType"),null) { public ESLVal apply(ESLVal... args) { return getPatternType(args[0],args[1],args[2],args[3],args[4],args[5]); }});
  private static ESLVal patternType(ESLVal l,ESLVal p,ESLVal t,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv,ESLVal f) {
    
    {ESLVal _v1116 = p;
      
      switch(_v1116.termName) {
      case "PAdd": {ESLVal $2238 = _v1116.termRef(0);
        ESLVal $2237 = _v1116.termRef(1);
        ESLVal $2236 = _v1116.termRef(2);
        
        {ESLVal _v1353 = $2238;
        
        {ESLVal p1 = $2237;
        
        {ESLVal p2 = $2236;
        
        return addPatternType(_v1353,p1,p2,t,selfType,valueEnv,cnstrEnv,typeEnv,f);
      }
      }
      }
      }
    case "PApplyType": {ESLVal $2235 = _v1116.termRef(0);
        ESLVal $2234 = _v1116.termRef(1);
        ESLVal $2233 = _v1116.termRef(2);
        
        {ESLVal _v1351 = $2235;
        
        {ESLVal _v1352 = $2234;
        
        {ESLVal args = $2233;
        
        return applyTypePatternType(_v1351,_v1352,substTypesEnv.apply(typeEnv,args),t,selfType,valueEnv,cnstrEnv,typeEnv,f);
      }
      }
      }
      }
    case "PBool": {ESLVal $2232 = _v1116.termRef(0);
        ESLVal $2231 = _v1116.termRef(1);
        
        {ESLVal _v1350 = $2232;
        
        {ESLVal b = $2231;
        
        if(isBoolType.apply(t).boolVal)
        return f.apply(new ESLVal("BoolType",_v1350),valueEnv);
        else
          return error(new ESLVal("TypeError",_v1350,new ESLVal("type mismatch: Bool and ").add(ppType(t,typeEnv))));
      }
      }
      }
    case "PBagCons": {ESLVal $2230 = _v1116.termRef(0);
        ESLVal $2229 = _v1116.termRef(1);
        ESLVal $2228 = _v1116.termRef(2);
        
        {ESLVal _v1347 = $2230;
        
        {ESLVal hd = $2229;
        
        {ESLVal tl = $2228;
        
        return bagConsPatternType(_v1347,hd,tl,t,selfType,valueEnv,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun391"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1348 = $args[0];
        ESLVal _v1349 = $args[1];
        return f.apply(new ESLVal("ListType",_v1347,_v1348),_v1349);
          }
        }));
      }
      }
      }
      }
    case "PSetCons": {ESLVal $2227 = _v1116.termRef(0);
        ESLVal $2226 = _v1116.termRef(1);
        ESLVal $2225 = _v1116.termRef(2);
        
        {ESLVal _v1344 = $2227;
        
        {ESLVal hd = $2226;
        
        {ESLVal tl = $2225;
        
        return setConsPatternType(_v1344,hd,tl,t,selfType,valueEnv,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun392"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1345 = $args[0];
        ESLVal _v1346 = $args[1];
        return f.apply(new ESLVal("ListType",_v1344,_v1345),_v1346);
          }
        }));
      }
      }
      }
      }
    case "PCons": {ESLVal $2224 = _v1116.termRef(0);
        ESLVal $2223 = _v1116.termRef(1);
        ESLVal $2222 = _v1116.termRef(2);
        
        {ESLVal _v1341 = $2224;
        
        {ESLVal hd = $2223;
        
        {ESLVal tl = $2222;
        
        return consPatternType(_v1341,hd,tl,t,selfType,valueEnv,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun393"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1342 = $args[0];
        ESLVal _v1343 = $args[1];
        return f.apply(new ESLVal("ListType",_v1341,_v1342),_v1343);
          }
        }));
      }
      }
      }
      }
    case "PNil": {ESLVal $2221 = _v1116.termRef(0);
        
        {ESLVal _v1340 = $2221;
        
        return nilType(_v1340,t,selfType,valueEnv,cnstrEnv,typeEnv,f);
      }
      }
    case "PNull": {ESLVal $2220 = _v1116.termRef(0);
        
        {ESLVal _v1339 = $2220;
        
        return f.apply(t,valueEnv);
      }
      }
    case "PEmptyBag": {ESLVal $2219 = _v1116.termRef(0);
        
        {ESLVal _v1338 = $2219;
        
        return emptyBagType(_v1338,t,selfType,valueEnv,cnstrEnv,typeEnv,f);
      }
      }
    case "PEmptySet": {ESLVal $2218 = _v1116.termRef(0);
        
        {ESLVal _v1337 = $2218;
        
        return emptySetType(_v1337,t,selfType,valueEnv,cnstrEnv,typeEnv,f);
      }
      }
    case "PInt": {ESLVal $2217 = _v1116.termRef(0);
        ESLVal $2216 = _v1116.termRef(1);
        
        {ESLVal _v1336 = $2217;
        
        {ESLVal n = $2216;
        
        if(isIntType.apply(t).boolVal)
        return f.apply(new ESLVal("IntType",_v1336),valueEnv);
        else
          return error(new ESLVal("TypeError",_v1336,new ESLVal("type mismatch: Int and ").add(ppType(t,typeEnv))));
      }
      }
      }
    case "PVar": {ESLVal $2215 = _v1116.termRef(0);
        ESLVal $2214 = _v1116.termRef(1);
        ESLVal $2213 = _v1116.termRef(2);
        
        {ESLVal _v1335 = $2215;
        
        {ESLVal n = $2214;
        
        {ESLVal pt = $2213;
        
        return f.apply(t,ESLVal.list(new ESLVal("Map",n,t)).add(valueEnv));
      }
      }
      }
      }
    case "PStr": {ESLVal $2212 = _v1116.termRef(0);
        ESLVal $2211 = _v1116.termRef(1);
        
        {ESLVal _v1334 = $2212;
        
        {ESLVal s = $2211;
        
        if(isStrType.apply(t).boolVal)
        return f.apply(new ESLVal("StrType",_v1334),valueEnv);
        else
          return error(new ESLVal("TypeError",_v1334,new ESLVal("type mismatch: Str and ").add(ppType(t,typeEnv))));
      }
      }
      }
    case "PTerm": {ESLVal $2210 = _v1116.termRef(0);
        ESLVal $2209 = _v1116.termRef(1);
        ESLVal $2208 = _v1116.termRef(2);
        ESLVal $2207 = _v1116.termRef(3);
        
        {ESLVal _v1333 = $2210;
        
        {ESLVal n = $2209;
        
        {ESLVal ts = $2208;
        
        {ESLVal ps = $2207;
        
        return termPatternType(_v1333,n,substTypesEnv.apply(typeEnv,ts),ps,t,selfType,valueEnv,cnstrEnv,typeEnv,f);
      }
      }
      }
      }
      }
      default: {ESLVal _v1354 = _v1116;
        
        return error(new ESLVal("TypeError",l,new ESLVal("unknown type of pattern: ").add(_v1354)));
      }
    }
    }
  }
  private static ESLVal patternType = new ESLVal(new Function(new ESLVal("patternType"),null) { public ESLVal apply(ESLVal... args) { return patternType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7]); }});
  private static ESLVal addPatternType(ESLVal l,ESLVal p1,ESLVal p2,ESLVal valueType,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv,ESLVal f) {
    
    return patternType(l,p1,valueType,selfType,valueEnv,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun394"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal _v1304 = $args[0];
      ESLVal _v1305 = $args[1];
      return patternType(l,p2,valueType,selfType,_v1305,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun395"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v1306 = $args[0];
            ESLVal _v1307 = $args[1];
            {ESLVal _v1117 = valueType;
                  
                  switch(_v1117.termName) {
                  case "ListType": {ESLVal $2241 = _v1117.termRef(0);
                    ESLVal $2240 = _v1117.termRef(1);
                    
                    {ESLVal tl = $2241;
                    
                    {ESLVal t = $2240;
                    
                    {ESLVal _v1118 = p1;
                    ESLVal _v1119 = p2;
                    
                    switch(_v1118.termName) {
                    case "PCons": {ESLVal $2274 = _v1118.termRef(0);
                      ESLVal $2273 = _v1118.termRef(1);
                      ESLVal $2272 = _v1118.termRef(2);
                      
                      switch($2272.termName) {
                      case "PNil": {ESLVal $2275 = $2272.termRef(0);
                        
                        switch(_v1119.termName) {
                        case "PVar": {ESLVal $2278 = _v1119.termRef(0);
                          ESLVal $2277 = _v1119.termRef(1);
                          ESLVal $2276 = _v1119.termRef(2);
                          
                          {ESLVal l1 = $2274;
                          
                          {ESLVal p = $2273;
                          
                          {ESLVal l3 = $2275;
                          
                          {ESLVal l4 = $2278;
                          
                          {ESLVal n2 = $2277;
                          
                          {ESLVal t2 = $2276;
                          
                          return f.apply(valueType,_v1307);
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal _v1327 = _v1118;
                          
                          {ESLVal _v1328 = _v1119;
                          
                          return error(new ESLVal("TypeError",l,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                        }
                        }
                      }
                      }
                      default: {ESLVal _v1329 = _v1118;
                        
                        {ESLVal _v1330 = _v1119;
                        
                        return error(new ESLVal("TypeError",l,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                      }
                      }
                    }
                    }
                  case "PVar": {ESLVal $2257 = _v1118.termRef(0);
                      ESLVal $2256 = _v1118.termRef(1);
                      ESLVal $2255 = _v1118.termRef(2);
                      
                      switch(_v1119.termName) {
                      case "PCons": {ESLVal $2270 = _v1119.termRef(0);
                        ESLVal $2269 = _v1119.termRef(1);
                        ESLVal $2268 = _v1119.termRef(2);
                        
                        switch($2268.termName) {
                        case "PNil": {ESLVal $2271 = $2268.termRef(0);
                          
                          {ESLVal l1 = $2257;
                          
                          {ESLVal n = $2256;
                          
                          {ESLVal _v1322 = $2255;
                          
                          {ESLVal l2 = $2270;
                          
                          {ESLVal p = $2269;
                          
                          {ESLVal l3 = $2271;
                          
                          return f.apply(valueType,_v1307);
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal _v1323 = _v1118;
                          
                          {ESLVal _v1324 = _v1119;
                          
                          return error(new ESLVal("TypeError",l,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                        }
                        }
                      }
                      }
                    case "PAdd": {ESLVal $2260 = _v1119.termRef(0);
                        ESLVal $2259 = _v1119.termRef(1);
                        ESLVal $2258 = _v1119.termRef(2);
                        
                        switch($2259.termName) {
                        case "PCons": {ESLVal $2263 = $2259.termRef(0);
                          ESLVal $2262 = $2259.termRef(1);
                          ESLVal $2261 = $2259.termRef(2);
                          
                          switch($2261.termName) {
                          case "PNil": {ESLVal $2264 = $2261.termRef(0);
                            
                            switch($2258.termName) {
                            case "PVar": {ESLVal $2267 = $2258.termRef(0);
                              ESLVal $2266 = $2258.termRef(1);
                              ESLVal $2265 = $2258.termRef(2);
                              
                              {ESLVal l1 = $2257;
                              
                              {ESLVal n1 = $2256;
                              
                              {ESLVal t1 = $2255;
                              
                              {ESLVal l2 = $2260;
                              
                              {ESLVal l3 = $2263;
                              
                              {ESLVal p = $2262;
                              
                              {ESLVal l5 = $2264;
                              
                              {ESLVal l6 = $2267;
                              
                              {ESLVal n3 = $2266;
                              
                              {ESLVal t3 = $2265;
                              
                              return f.apply(valueType,_v1307);
                            }
                            }
                            }
                            }
                            }
                            }
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v1316 = _v1118;
                              
                              {ESLVal _v1317 = _v1119;
                              
                              return error(new ESLVal("TypeError",l,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                            }
                            }
                          }
                          }
                          default: {ESLVal _v1318 = _v1118;
                            
                            {ESLVal _v1319 = _v1119;
                            
                            return error(new ESLVal("TypeError",l,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                          }
                          }
                        }
                        }
                        default: {ESLVal _v1320 = _v1118;
                          
                          {ESLVal _v1321 = _v1119;
                          
                          return error(new ESLVal("TypeError",l,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                        }
                        }
                      }
                      }
                      default: {ESLVal _v1325 = _v1118;
                        
                        {ESLVal _v1326 = _v1119;
                        
                        return error(new ESLVal("TypeError",l,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                      }
                      }
                    }
                    }
                  case "PAdd": {ESLVal $2244 = _v1118.termRef(0);
                      ESLVal $2243 = _v1118.termRef(1);
                      ESLVal $2242 = _v1118.termRef(2);
                      
                      switch($2243.termName) {
                      case "PVar": {ESLVal $2247 = $2243.termRef(0);
                        ESLVal $2246 = $2243.termRef(1);
                        ESLVal $2245 = $2243.termRef(2);
                        
                        switch($2242.termName) {
                        case "PCons": {ESLVal $2250 = $2242.termRef(0);
                          ESLVal $2249 = $2242.termRef(1);
                          ESLVal $2248 = $2242.termRef(2);
                          
                          switch($2248.termName) {
                          case "PNil": {ESLVal $2251 = $2248.termRef(0);
                            
                            switch(_v1119.termName) {
                            case "PVar": {ESLVal $2254 = _v1119.termRef(0);
                              ESLVal $2253 = _v1119.termRef(1);
                              ESLVal $2252 = _v1119.termRef(2);
                              
                              {ESLVal l1 = $2244;
                              
                              {ESLVal l2 = $2247;
                              
                              {ESLVal n1 = $2246;
                              
                              {ESLVal t1 = $2245;
                              
                              {ESLVal l3 = $2250;
                              
                              {ESLVal p = $2249;
                              
                              {ESLVal l5 = $2251;
                              
                              {ESLVal l6 = $2254;
                              
                              {ESLVal n3 = $2253;
                              
                              {ESLVal t3 = $2252;
                              
                              return f.apply(valueType,_v1307);
                            }
                            }
                            }
                            }
                            }
                            }
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v1308 = _v1118;
                              
                              {ESLVal _v1309 = _v1119;
                              
                              return error(new ESLVal("TypeError",l,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                            }
                            }
                          }
                          }
                          default: {ESLVal _v1310 = _v1118;
                            
                            {ESLVal _v1311 = _v1119;
                            
                            return error(new ESLVal("TypeError",l,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                          }
                          }
                        }
                        }
                        default: {ESLVal _v1312 = _v1118;
                          
                          {ESLVal _v1313 = _v1119;
                          
                          return error(new ESLVal("TypeError",l,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                        }
                        }
                      }
                      }
                      default: {ESLVal _v1314 = _v1118;
                        
                        {ESLVal _v1315 = _v1119;
                        
                        return error(new ESLVal("TypeError",l,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                      }
                      }
                    }
                    }
                    default: {ESLVal _v1331 = _v1118;
                      
                      {ESLVal _v1332 = _v1119;
                      
                      return error(new ESLVal("TypeError",l,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                    }
                    }
                  }
                  }
                  }
                  }
                  }
                case "TypeClosure": {ESLVal $2239 = _v1117.termRef(0);
                    
                    {ESLVal g = $2239;
                    
                    return addPatternType(l,p1,p2,g.apply(),selfType,_v1307,cnstrEnv,typeEnv,f);
                  }
                  }
                  default: {ESLVal t = _v1117;
                    
                    return error(new ESLVal("TypeError",l,new ESLVal("+ expects lists: ").add(ppType(valueType,typeEnv))));
                  }
                }
                }
              }
            }));
        }
      }));
  }
  private static ESLVal addPatternType = new ESLVal(new Function(new ESLVal("addPatternType"),null) { public ESLVal apply(ESLVal... args) { return addPatternType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7],args[8]); }});
  private static ESLVal applyTypePatternType(ESLVal l,ESLVal p,ESLVal args,ESLVal valueType,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv,ESLVal f) {
    
    return patternType(l,p,valueType,selfType,valueEnv,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun396"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal _v1300 = $args[0];
      ESLVal _v1301 = $args[1];
      {ESLVal _v1120 = typeNF(_v1300,typeEnv);
            
            switch(_v1120.termName) {
            case "TypeFun": {ESLVal $2284 = _v1120.termRef(0);
              ESLVal $2283 = _v1120.termRef(1);
              ESLVal $2282 = _v1120.termRef(2);
              
              {ESLVal fl = $2284;
              
              {ESLVal ns = $2283;
              
              {ESLVal t = $2282;
              
              if(length.apply(args).eql(length.apply(ns)).boolVal)
              {ESLVal _v1303 = substTypeEnv.apply(zipTypeEnv.apply(ns,args).add(typeEnv),t);
                
                if(typeEqual.apply(_v1303,valueType).boolVal)
                return f.apply(_v1303,_v1301);
                else
                  return error(new ESLVal("TypeError",l,new ESLVal("value type ").add(ppType(valueType,typeEnv).add(new ESLVal(" does not match pattern type ").add(ppType(_v1303,typeEnv).add(new ESLVal(" ").add(ppTypeEnv(typeEnv))))))));
              }
              else
                return error(new ESLVal("TypeError",l,new ESLVal("expecting ").add(length.apply(ns).add(new ESLVal(" args, but suplied with ").add(length.apply(args))))));
            }
            }
            }
            }
          case "ForallType": {ESLVal $2281 = _v1120.termRef(0);
              ESLVal $2280 = _v1120.termRef(1);
              ESLVal $2279 = _v1120.termRef(2);
              
              {ESLVal fl = $2281;
              
              {ESLVal ns = $2280;
              
              {ESLVal t = $2279;
              
              if(length.apply(args).eql(length.apply(ns)).boolVal)
              {ESLVal _v1302 = substTypeEnv.apply(zipTypeEnv.apply(ns,args).add(typeEnv),t);
                
                if(typeEqual.apply(_v1302,valueType).boolVal)
                return f.apply(_v1302,_v1301);
                else
                  return error(new ESLVal("TypeError",l,new ESLVal("value type ").add(ppType(valueType,typeEnv).add(new ESLVal(" does not match pattern type ").add(ppType(_v1302,typeEnv).add(new ESLVal(" ").add(ppTypeEnv(typeEnv))))))));
              }
              else
                return error(new ESLVal("TypeError",l,new ESLVal("expecting ").add(length.apply(ns).add(new ESLVal(" args, but suplied with ").add(length.apply(args))))));
            }
            }
            }
            }
            default: {ESLVal t = _v1120;
              
              return f.apply(t,_v1301);
            }
          }
          }
        }
      }));
  }
  private static ESLVal applyTypePatternType = new ESLVal(new Function(new ESLVal("applyTypePatternType"),null) { public ESLVal apply(ESLVal... args) { return applyTypePatternType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7],args[8]); }});
  private static ESLVal termPatternType(ESLVal l,ESLVal n,ESLVal genericArgs,ESLVal ps,ESLVal valueType,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv,ESLVal f) {
    
    {ESLVal patternType = getTermPatternType(l,n,genericArgs,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(typeEqual.apply(patternType,valueType).boolVal)
      {ESLVal _v1121 = typeNF(valueType,typeEnv);
        
        switch(_v1121.termName) {
        case "UnionType": {ESLVal $2286 = _v1121.termRef(0);
          ESLVal $2285 = _v1121.termRef(1);
          
          {ESLVal ul = $2286;
          
          {ESLVal cs = $2285;
          
          { LetRec letrec = new LetRec() {
          ESLVal getCnstrArgs = new ESLVal(new Function(new ESLVal("getCnstrArgs"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v1294 = $args[0];
            {ESLVal _v1122 = _v1294;
                  
                  if(_v1122.isCons())
                  {ESLVal $2287 = _v1122.head();
                    ESLVal $2288 = _v1122.tail();
                    
                    switch($2287.termName) {
                    case "TermType": {ESLVal $2291 = $2287.termRef(0);
                      ESLVal $2290 = $2287.termRef(1);
                      ESLVal $2289 = $2287.termRef(2);
                      
                      {ESLVal tl = $2291;
                      
                      {ESLVal m = $2290;
                      
                      {ESLVal args = $2289;
                      
                      {ESLVal _v1295 = $2288;
                      
                      if(m.eql(n).boolVal)
                      return args;
                      else
                        {ESLVal t = $2287;
                          
                          {ESLVal _v1296 = $2288;
                          
                          return getCnstrArgs.apply(_v1296);
                        }
                        }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal t = $2287;
                      
                      {ESLVal _v1297 = $2288;
                      
                      return getCnstrArgs.apply(_v1297);
                    }
                    }
                  }
                  }
                else if(_v1122.isNil())
                  return error(new ESLVal("TypeError",l,new ESLVal("cannot find constructor for ").add(n)));
                else return error(new ESLVal("case error at Pos(54429,54688)").add(ESLVal.list(_v1122)));
                }
              }
            });
          
          public ESLVal get(String name) {
            switch(name) {
              case "getCnstrArgs": return getCnstrArgs;
              
              default: throw new Error("cannot find letrec binding");
            }
            }
          };
        ESLVal getCnstrArgs = letrec.get("getCnstrArgs");
        
          {ESLVal argTypes = getCnstrArgs.apply(cs);
          
          if(length.apply(ps).eql(length.apply(argTypes)).boolVal)
          return patternTypes(l,ps,argTypes,selfType,valueEnv,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun397"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v1298 = $args[0];
            ESLVal _v1299 = $args[1];
            return f.apply(typeNF(valueType,typeEnv),_v1299);
              }
            }));
          else
            return error(new ESLVal("TypeError",l,new ESLVal("arity mismatch.")));
        }}
        
        }
        }
        }
        default: {ESLVal t = _v1121;
          
          return error(new ESLVal("TypeError",l,new ESLVal("expecting a data type: ").add(valueType)));
        }
      }
      }
      else
        return error(new ESLVal("TypeError",l,new ESLVal("term pattern type ").add(ppType(patternType,typeEnv).add(new ESLVal(" does not match supplied value type ").add(ppType(valueType,typeEnv))))));
    }
  }
  private static ESLVal termPatternType = new ESLVal(new Function(new ESLVal("termPatternType"),null) { public ESLVal apply(ESLVal... args) { return termPatternType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7],args[8],args[9]); }});
  private static ESLVal typeNF(ESLVal t,ESLVal typeEnv) {
    
    {ESLVal _v1123 = substTypeEnv.apply(typeEnv,t);
      
      switch(_v1123.termName) {
      case "ApplyTypeFun": {ESLVal $2302 = _v1123.termRef(0);
        ESLVal $2301 = _v1123.termRef(1);
        ESLVal $2300 = _v1123.termRef(2);
        
        {ESLVal l = $2302;
        
        {ESLVal op = $2301;
        
        {ESLVal args = $2300;
        
        {ESLVal _v1125 = typeNF(op,typeEnv);
        
        switch(_v1125.termName) {
        case "TypeFun": {ESLVal $2308 = _v1125.termRef(0);
          ESLVal $2307 = _v1125.termRef(1);
          ESLVal $2306 = _v1125.termRef(2);
          
          {ESLVal _v1290 = $2308;
          
          {ESLVal ns = $2307;
          
          {ESLVal _v1291 = $2306;
          
          if(length.apply(args).eql(length.apply(ns)).boolVal)
          return typeNF(substTypeEnv.apply(zipTypeEnv.apply(ns,args),_v1291),typeEnv);
          else
            return error(new ESLVal("TypeError",_v1290,new ESLVal("function arity error")));
        }
        }
        }
        }
        default: {ESLVal _v1292 = _v1125;
          
          return error(new ESLVal("TypeError",l,new ESLVal("expecting a type function: ").add(ppType(typeNF(op,typeEnv),typeEnv))));
        }
      }
      }
      }
      }
      }
      }
    case "TypeClosure": {ESLVal $2299 = _v1123.termRef(0);
        
        {ESLVal f = $2299;
        
        return typeNF(f.apply(),typeEnv);
      }
      }
    case "RecType": {ESLVal $2298 = _v1123.termRef(0);
        ESLVal $2297 = _v1123.termRef(1);
        ESLVal $2296 = _v1123.termRef(2);
        
        {ESLVal l = $2298;
        
        {ESLVal n = $2297;
        
        {ESLVal _v1289 = $2296;
        
        return typeNF(substType.apply(new ESLVal("RecType",l,n,_v1289),n,_v1289),typeEnv);
      }
      }
      }
      }
    case "ExtendedAct": {ESLVal $2295 = _v1123.termRef(0);
        ESLVal $2294 = _v1123.termRef(1);
        ESLVal $2293 = _v1123.termRef(2);
        ESLVal $2292 = _v1123.termRef(3);
        
        {ESLVal l1 = $2295;
        
        {ESLVal parent = $2294;
        
        {ESLVal decs1 = $2293;
        
        {ESLVal ms1 = $2292;
        
        {ESLVal _v1124 = typeNF(parent,typeEnv);
        
        switch(_v1124.termName) {
        case "ActType": {ESLVal $2305 = _v1124.termRef(0);
          ESLVal $2304 = _v1124.termRef(1);
          ESLVal $2303 = _v1124.termRef(2);
          
          {ESLVal l2 = $2305;
          
          {ESLVal decs2 = $2304;
          
          {ESLVal ms2 = $2303;
          
          return new ESLVal("ActType",l1,decs2.add(decs1),ms2.add(ms1));
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(55999,56134)").add(ESLVal.list(_v1124)));
      }
      }
      }
      }
      }
      }
      }
      default: {ESLVal _v1293 = _v1123;
        
        return _v1293;
      }
    }
    }
  }
  private static ESLVal typeNF = new ESLVal(new Function(new ESLVal("typeNF"),null) { public ESLVal apply(ESLVal... args) { return typeNF(args[0],args[1]); }});
  private static ESLVal getTermPatternType(ESLVal l,ESLVal n,ESLVal genericArgs,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t = lookupType.apply(n,cnstrEnv);
      
      if(t.eql($null).boolVal)
      return error(new ESLVal("TypeError",l,new ESLVal("unknown constructor ").add(n)));
      else
        if(length.apply(genericArgs).gre($zero).boolVal)
          return getGenericTermPatternType(l,t,genericArgs,selfType,valueEnv,cnstrEnv,typeEnv);
          else
            return t;
    }
  }
  private static ESLVal getTermPatternType = new ESLVal(new Function(new ESLVal("getTermPatternType"),null) { public ESLVal apply(ESLVal... args) { return getTermPatternType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal getGenericTermPatternType(ESLVal l,ESLVal t,ESLVal genericArgs,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal _v1126 = t;
      
      switch(_v1126.termName) {
      case "RecType": {ESLVal $2314 = _v1126.termRef(0);
        ESLVal $2313 = _v1126.termRef(1);
        ESLVal $2312 = _v1126.termRef(2);
        
        {ESLVal rl = $2314;
        
        {ESLVal rn = $2313;
        
        {ESLVal rt = $2312;
        
        return getGenericTermPatternType(l,substType.apply(new ESLVal("RecType",rl,rn,rt),rn,rt),genericArgs,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "TypeFun": {ESLVal $2311 = _v1126.termRef(0);
        ESLVal $2310 = _v1126.termRef(1);
        ESLVal $2309 = _v1126.termRef(2);
        
        {ESLVal al = $2311;
        
        {ESLVal ns = $2310;
        
        {ESLVal _v1287 = $2309;
        
        if(length.apply(ns).eql(length.apply(genericArgs)).boolVal)
        {ESLVal e = zipTypeEnv.apply(ns,genericArgs);
          
          return substTypeEnv.apply(e.add(typeEnv),_v1287);
        }
        else
          return error(new ESLVal("TypeError",l,new ESLVal("generic constructor mismatch")));
      }
      }
      }
      }
      default: {ESLVal _v1288 = _v1126;
        
        return error(new ESLVal("TypeError",l,new ESLVal("expecting a generic type: ").add(ppType(_v1288,typeEnv))));
      }
    }
    }
  }
  private static ESLVal getGenericTermPatternType = new ESLVal(new Function(new ESLVal("getGenericTermPatternType"),null) { public ESLVal apply(ESLVal... args) { return getGenericTermPatternType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal nilType(ESLVal l,ESLVal listType,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv,ESLVal f) {
    
    {ESLVal _v1127 = typeNF(listType,typeEnv);
      
      switch(_v1127.termName) {
      case "ListType": {ESLVal $2317 = _v1127.termRef(0);
        ESLVal $2316 = _v1127.termRef(1);
        
        {ESLVal ltl = $2317;
        
        {ESLVal et = $2316;
        
        return f.apply(new ESLVal("ForallType",l,ESLVal.list(new ESLVal("T")),new ESLVal("ListType",l,new ESLVal("VarType",l,new ESLVal("T")))),valueEnv);
      }
      }
      }
    case "TypeClosure": {ESLVal $2315 = _v1127.termRef(0);
        
        {ESLVal g = $2315;
        
        return nilType(l,g.apply(),selfType,valueEnv,cnstrEnv,typeEnv,f);
      }
      }
      default: {ESLVal _v1286 = _v1127;
        
        return error(new ESLVal("TypeError",l,new ESLVal("expecting a list type: ").add(ppType(_v1286,typeEnv))));
      }
    }
    }
  }
  private static ESLVal nilType = new ESLVal(new Function(new ESLVal("nilType"),null) { public ESLVal apply(ESLVal... args) { return nilType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal emptyBagType(ESLVal l,ESLVal bagType,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv,ESLVal f) {
    
    {ESLVal _v1128 = bagType;
      
      switch(_v1128.termName) {
      case "BagType": {ESLVal $2319 = _v1128.termRef(0);
        ESLVal $2318 = _v1128.termRef(1);
        
        {ESLVal ltl = $2319;
        
        {ESLVal et = $2318;
        
        return f.apply(new ESLVal("ForallType",l,ESLVal.list(new ESLVal("T")),new ESLVal("BagType",l,new ESLVal("VarType",l,new ESLVal("T")))),valueEnv);
      }
      }
      }
      default: {ESLVal _v1285 = _v1128;
        
        return error(new ESLVal("TypeError",l,new ESLVal("expecting a bag type: ").add(ppType(_v1285,typeEnv))));
      }
    }
    }
  }
  private static ESLVal emptyBagType = new ESLVal(new Function(new ESLVal("emptyBagType"),null) { public ESLVal apply(ESLVal... args) { return emptyBagType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal emptySetType(ESLVal l,ESLVal setType,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv,ESLVal f) {
    
    {ESLVal _v1129 = setType;
      
      switch(_v1129.termName) {
      case "SetType": {ESLVal $2321 = _v1129.termRef(0);
        ESLVal $2320 = _v1129.termRef(1);
        
        {ESLVal ltl = $2321;
        
        {ESLVal et = $2320;
        
        return f.apply(new ESLVal("ForallType",l,ESLVal.list(new ESLVal("T")),new ESLVal("SetType",l,new ESLVal("VarType",l,new ESLVal("T")))),valueEnv);
      }
      }
      }
      default: {ESLVal _v1284 = _v1129;
        
        return error(new ESLVal("TypeError",l,new ESLVal("expecting a set type: ").add(ppType(_v1284,typeEnv))));
      }
    }
    }
  }
  private static ESLVal emptySetType = new ESLVal(new Function(new ESLVal("emptySetType"),null) { public ESLVal apply(ESLVal... args) { return emptySetType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal consPatternType(ESLVal l,ESLVal h,ESLVal t,ESLVal listType,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv,ESLVal f) {
    
    {ESLVal _v1130 = typeNF(listType,typeEnv);
      
      switch(_v1130.termName) {
      case "ListType": {ESLVal $2324 = _v1130.termRef(0);
        ESLVal $2323 = _v1130.termRef(1);
        
        {ESLVal ltl = $2324;
        
        {ESLVal et = $2323;
        
        return patternType(l,h,substTypeEnv.apply(typeEnv,et),selfType,valueEnv,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun398"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1279 = $args[0];
        ESLVal _v1280 = $args[1];
        return patternType(l,t,listType,selfType,_v1280,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun399"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal _v1281 = $args[0];
              ESLVal _v1282 = $args[1];
              return f.apply(_v1279,_v1282);
                }
              }));
          }
        }));
      }
      }
      }
    case "TypeClosure": {ESLVal $2322 = _v1130.termRef(0);
        
        {ESLVal g = $2322;
        
        return consPatternType(l,h,t,g.apply(),selfType,valueEnv,cnstrEnv,typeEnv,f);
      }
      }
      default: {ESLVal _v1283 = _v1130;
        
        return error(new ESLVal("TypeError",l,new ESLVal("expecting a list type: ").add(ppType(_v1283,typeEnv))));
      }
    }
    }
  }
  private static ESLVal consPatternType = new ESLVal(new Function(new ESLVal("consPatternType"),null) { public ESLVal apply(ESLVal... args) { return consPatternType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7],args[8]); }});
  private static ESLVal bagConsPatternType(ESLVal l,ESLVal h,ESLVal t,ESLVal bagType,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv,ESLVal f) {
    
    {ESLVal _v1131 = bagType;
      
      switch(_v1131.termName) {
      case "BagType": {ESLVal $2326 = _v1131.termRef(0);
        ESLVal $2325 = _v1131.termRef(1);
        
        {ESLVal ltl = $2326;
        
        {ESLVal et = $2325;
        
        return patternType(l,h,substTypeEnv.apply(typeEnv,et),selfType,valueEnv,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun400"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1274 = $args[0];
        ESLVal _v1275 = $args[1];
        return patternType(l,t,bagType,selfType,_v1275,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun401"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal _v1276 = $args[0];
              ESLVal _v1277 = $args[1];
              return f.apply(_v1274,_v1277);
                }
              }));
          }
        }));
      }
      }
      }
      default: {ESLVal _v1278 = _v1131;
        
        return error(new ESLVal("TypeError",l,new ESLVal("expecting a bag type: ").add(ppType(_v1278,typeEnv))));
      }
    }
    }
  }
  private static ESLVal bagConsPatternType = new ESLVal(new Function(new ESLVal("bagConsPatternType"),null) { public ESLVal apply(ESLVal... args) { return bagConsPatternType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7],args[8]); }});
  private static ESLVal setConsPatternType(ESLVal l,ESLVal h,ESLVal t,ESLVal setType,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv,ESLVal f) {
    
    {ESLVal _v1132 = setType;
      
      switch(_v1132.termName) {
      case "SetType": {ESLVal $2328 = _v1132.termRef(0);
        ESLVal $2327 = _v1132.termRef(1);
        
        {ESLVal ltl = $2328;
        
        {ESLVal et = $2327;
        
        return patternType(l,h,substTypeEnv.apply(typeEnv,et),selfType,valueEnv,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun402"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1269 = $args[0];
        ESLVal _v1270 = $args[1];
        return patternType(l,t,setType,selfType,_v1270,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun403"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal _v1271 = $args[0];
              ESLVal _v1272 = $args[1];
              return f.apply(_v1269,_v1272);
                }
              }));
          }
        }));
      }
      }
      }
      default: {ESLVal _v1273 = _v1132;
        
        return error(new ESLVal("TypeError",l,new ESLVal("expecting a set type: ").add(ppType(_v1273,typeEnv))));
      }
    }
    }
  }
  private static ESLVal setConsPatternType = new ESLVal(new Function(new ESLVal("setConsPatternType"),null) { public ESLVal apply(ESLVal... args) { return setConsPatternType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7],args[8]); }});
  private static ESLVal binExpType(ESLVal l,ESLVal e1,ESLVal op,ESLVal e2,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal _v1133 = op;
      
      switch(_v1133.strVal) {
      case "+": return plusExpType(l,e1,e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case "-": return subExpType(l,e1,e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case "*": return mulExpType(l,e1,e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case "/": return divExpType(l,e1,e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case ":": return consExpType(l,e1,e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case "=": return eqlExpType(l,e1,e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case "<>": return neqlExpType(l,e1,e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case "and": return andExpType(l,e1,e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case "andalso": return andExpType(l,e1,e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case "or": return orExpType(l,e1,e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case "orelse": return orExpType(l,e1,e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case ">": return compareExpType(l,e1,new ESLVal(">"),e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case ">=": return compareExpType(l,e1,new ESLVal(">="),e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case "<": return compareExpType(l,e1,new ESLVal("<"),e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case "<=": return compareExpType(l,e1,new ESLVal("<="),e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case "..": return dotDotExpType(l,e1,e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case "%": return percentExpType(l,e1,e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case "@": return atExpType(l,e1,e2,selfType,valueEnv,cnstrEnv,typeEnv);
      default: {ESLVal _v1268 = _v1133;
        
        return error(new ESLVal("TypeError",l,new ESLVal("unknown operator: ").add(_v1268)));
      }
    }
    }
  }
  private static ESLVal binExpType = new ESLVal(new Function(new ESLVal("binExpType"),null) { public ESLVal apply(ESLVal... args) { return binExpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7]); }});
  private static ESLVal andExpType(ESLVal l,ESLVal e1,ESLVal e2,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t1 = expType(e1,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal t2 = expType(e2,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(isBoolType.apply(t1).and(isBoolType.apply(t2)).boolVal)
      return t1;
      else
        return error(new ESLVal("TypeError",l,new ESLVal("and expects boolean arguments: ").add(ppType(t1,typeEnv).add(new ESLVal(" ").add(ppType(t2,typeEnv))))));
    }
  }
  private static ESLVal andExpType = new ESLVal(new Function(new ESLVal("andExpType"),null) { public ESLVal apply(ESLVal... args) { return andExpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal atExpType(ESLVal l,ESLVal e1,ESLVal e2,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t1 = expType(e1,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal t2 = expType(e2,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(typeEqual.apply(t1,t2).boolVal)
      return t1;
      else
        return error(new ESLVal("TypeError",l,new ESLVal("@ expects arguments to be same type: ").add(ppType(t1,typeEnv).add(new ESLVal(" ").add(ppType(t2,typeEnv))))));
    }
  }
  private static ESLVal atExpType = new ESLVal(new Function(new ESLVal("atExpType"),null) { public ESLVal apply(ESLVal... args) { return atExpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal dotDotExpType(ESLVal l,ESLVal e1,ESLVal e2,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t1 = expType(e1,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal t2 = expType(e2,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(isIntType.apply(t1).and(isIntType.apply(t2)).boolVal)
      return new ESLVal("ListType",l,new ESLVal("IntType",l));
      else
        return error(new ESLVal("TypeError",l,new ESLVal(".. expects integer arguments: ").add(ppType(t1,typeEnv).add(new ESLVal(" ").add(ppType(t2,typeEnv))))));
    }
  }
  private static ESLVal dotDotExpType = new ESLVal(new Function(new ESLVal("dotDotExpType"),null) { public ESLVal apply(ESLVal... args) { return dotDotExpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal percentExpType(ESLVal l,ESLVal e1,ESLVal e2,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t1 = expType(e1,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal t2 = expType(e2,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(isIntType.apply(t1).and(isIntType.apply(t2)).boolVal)
      return new ESLVal("IntType",l);
      else
        return error(new ESLVal("TypeError",l,new ESLVal("% expects integer arguments: ").add(ppType(t1,typeEnv).add(new ESLVal(" ").add(ppType(t2,typeEnv))))));
    }
  }
  private static ESLVal percentExpType = new ESLVal(new Function(new ESLVal("percentExpType"),null) { public ESLVal apply(ESLVal... args) { return percentExpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal compareExpType(ESLVal l,ESLVal e1,ESLVal op,ESLVal e2,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t1 = expType(e1,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal t2 = expType(e2,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(isNumType.apply(t1).and(isNumType.apply(t2)).boolVal)
      return new ESLVal("BoolType",l);
      else
        return error(new ESLVal("TypeError",l,op.add(new ESLVal(" expects numeric arguments: ").add(ppType(t1,typeEnv).add(new ESLVal(" ").add(ppType(t2,typeEnv)))))));
    }
  }
  private static ESLVal compareExpType = new ESLVal(new Function(new ESLVal("compareExpType"),null) { public ESLVal apply(ESLVal... args) { return compareExpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7]); }});
  private static ESLVal orExpType(ESLVal l,ESLVal e1,ESLVal e2,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t1 = expType(e1,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal t2 = expType(e2,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(isBoolType.apply(t1).and(isBoolType.apply(t2)).boolVal)
      return t1;
      else
        return error(new ESLVal("TypeError",l,new ESLVal("or expects boolean arguments: ").add(ppType(t1,typeEnv).add(new ESLVal(" ").add(ppType(t2,typeEnv))))));
    }
  }
  private static ESLVal orExpType = new ESLVal(new Function(new ESLVal("orExpType"),null) { public ESLVal apply(ESLVal... args) { return orExpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal eqlExpType(ESLVal l,ESLVal e1,ESLVal e2,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t1 = expType(e1,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal t2 = expType(e2,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(typeEqual.apply(t1,t2).boolVal)
      return new ESLVal("BoolType",l);
      else
        return error(new ESLVal("TypeError",l,new ESLVal("= expects types to agree: ").add(ppType(t1,typeEnv).add(new ESLVal(" <> ").add(ppType(t2,typeEnv))))));
    }
  }
  private static ESLVal eqlExpType = new ESLVal(new Function(new ESLVal("eqlExpType"),null) { public ESLVal apply(ESLVal... args) { return eqlExpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal neqlExpType(ESLVal l,ESLVal e1,ESLVal e2,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t1 = expType(e1,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal t2 = expType(e2,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(typeEqual.apply(t1,t2).boolVal)
      return new ESLVal("BoolType",l);
      else
        return error(new ESLVal("TypeError",l,new ESLVal("<> expects types to agree: ").add(ppType(t1,typeEnv).add(new ESLVal(" <> ").add(ppType(t2,typeEnv))))));
    }
  }
  private static ESLVal neqlExpType = new ESLVal(new Function(new ESLVal("neqlExpType"),null) { public ESLVal apply(ESLVal... args) { return neqlExpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal consExpType(ESLVal l,ESLVal e1,ESLVal e2,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t1 = typeNF(expType(e1,selfType,valueEnv,cnstrEnv,typeEnv),typeEnv);
      ESLVal t2 = typeNF(expType(e2,selfType,valueEnv,cnstrEnv,typeEnv),typeEnv);
      
      {ESLVal _v1134 = t2;
      ESLVal _v1135 = t1;
      
      switch(_v1134.termName) {
      case "ListType": {ESLVal $2330 = _v1134.termRef(0);
        ESLVal $2329 = _v1134.termRef(1);
        
        {ESLVal _v1267 = $2330;
        
        {ESLVal elementType = $2329;
        
        {ESLVal headType = _v1135;
        
        if(subType.apply(headType,elementType).boolVal)
        return t2;
        else
          return error(new ESLVal("TypeError",_v1267,new ESLVal(": expects head type ").add(ppType(headType,typeEnv).add(new ESLVal(" and element type ").add(ppType(elementType,typeEnv).add(new ESLVal(" to agree")))))));
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(65189,65470)").add(ESLVal.list(_v1134,_v1135)));
    }
    }
    }
  }
  private static ESLVal consExpType = new ESLVal(new Function(new ESLVal("consExpType"),null) { public ESLVal apply(ESLVal... args) { return consExpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal divExpType(ESLVal l,ESLVal e1,ESLVal e2,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t1 = expType(e1,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal t2 = expType(e2,selfType,valueEnv,cnstrEnv,typeEnv);
      
      {ESLVal _v1136 = t1;
      ESLVal _v1137 = t2;
      
      switch(_v1136.termName) {
      case "IntType": {ESLVal $2333 = _v1136.termRef(0);
        
        switch(_v1137.termName) {
        case "IntType": {ESLVal $2334 = _v1137.termRef(0);
          
          {ESLVal l1 = $2333;
          
          {ESLVal l2 = $2334;
          
          return t1;
        }
        }
        }
        default: {ESLVal _v1263 = _v1136;
          
          {ESLVal _v1264 = _v1137;
          
          return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for /: ").add(ppType(_v1263,typeEnv).add(new ESLVal(" and ").add(ppType(_v1264,typeEnv))))));
        }
        }
      }
      }
    case "FloatType": {ESLVal $2331 = _v1136.termRef(0);
        
        switch(_v1137.termName) {
        case "FloatType": {ESLVal $2332 = _v1137.termRef(0);
          
          {ESLVal l1 = $2331;
          
          {ESLVal l2 = $2332;
          
          return t1;
        }
        }
        }
        default: {ESLVal _v1261 = _v1136;
          
          {ESLVal _v1262 = _v1137;
          
          return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for /: ").add(ppType(_v1261,typeEnv).add(new ESLVal(" and ").add(ppType(_v1262,typeEnv))))));
        }
        }
      }
      }
      default: {ESLVal _v1265 = _v1136;
        
        {ESLVal _v1266 = _v1137;
        
        return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for /: ").add(ppType(_v1265,typeEnv).add(new ESLVal(" and ").add(ppType(_v1266,typeEnv))))));
      }
      }
    }
    }
    }
  }
  private static ESLVal divExpType = new ESLVal(new Function(new ESLVal("divExpType"),null) { public ESLVal apply(ESLVal... args) { return divExpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal mulExpType(ESLVal l,ESLVal e1,ESLVal e2,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t1 = expType(e1,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal t2 = expType(e2,selfType,valueEnv,cnstrEnv,typeEnv);
      
      {ESLVal _v1138 = t1;
      ESLVal _v1139 = t2;
      
      switch(_v1138.termName) {
      case "IntType": {ESLVal $2338 = _v1138.termRef(0);
        
        switch(_v1139.termName) {
        case "IntType": {ESLVal $2340 = _v1139.termRef(0);
          
          {ESLVal l1 = $2338;
          
          {ESLVal l2 = $2340;
          
          return t1;
        }
        }
        }
      case "FloatType": {ESLVal $2339 = _v1139.termRef(0);
          
          {ESLVal l1 = $2338;
          
          {ESLVal l2 = $2339;
          
          return t2;
        }
        }
        }
        default: {ESLVal _v1257 = _v1138;
          
          {ESLVal _v1258 = _v1139;
          
          return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for *: ").add(ppType(_v1257,typeEnv).add(new ESLVal(" and ").add(ppType(_v1258,typeEnv))))));
        }
        }
      }
      }
    case "FloatType": {ESLVal $2335 = _v1138.termRef(0);
        
        switch(_v1139.termName) {
        case "FloatType": {ESLVal $2337 = _v1139.termRef(0);
          
          {ESLVal l1 = $2335;
          
          {ESLVal l2 = $2337;
          
          return t1;
        }
        }
        }
      case "IntType": {ESLVal $2336 = _v1139.termRef(0);
          
          {ESLVal l1 = $2335;
          
          {ESLVal l2 = $2336;
          
          return t1;
        }
        }
        }
        default: {ESLVal _v1255 = _v1138;
          
          {ESLVal _v1256 = _v1139;
          
          return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for *: ").add(ppType(_v1255,typeEnv).add(new ESLVal(" and ").add(ppType(_v1256,typeEnv))))));
        }
        }
      }
      }
      default: {ESLVal _v1259 = _v1138;
        
        {ESLVal _v1260 = _v1139;
        
        return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for *: ").add(ppType(_v1259,typeEnv).add(new ESLVal(" and ").add(ppType(_v1260,typeEnv))))));
      }
      }
    }
    }
    }
  }
  private static ESLVal mulExpType = new ESLVal(new Function(new ESLVal("mulExpType"),null) { public ESLVal apply(ESLVal... args) { return mulExpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal subExpType(ESLVal l,ESLVal e1,ESLVal e2,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t1 = expType(e1,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal t2 = expType(e2,selfType,valueEnv,cnstrEnv,typeEnv);
      
      {ESLVal _v1140 = t1;
      ESLVal _v1141 = t2;
      
      switch(_v1140.termName) {
      case "IntType": {ESLVal $2344 = _v1140.termRef(0);
        
        switch(_v1141.termName) {
        case "IntType": {ESLVal $2346 = _v1141.termRef(0);
          
          {ESLVal l1 = $2344;
          
          {ESLVal l2 = $2346;
          
          return t1;
        }
        }
        }
      case "FloatType": {ESLVal $2345 = _v1141.termRef(0);
          
          {ESLVal l1 = $2344;
          
          {ESLVal l2 = $2345;
          
          return t2;
        }
        }
        }
        default: {ESLVal _v1251 = _v1140;
          
          {ESLVal _v1252 = _v1141;
          
          return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for -: ").add(ppType(_v1251,typeEnv).add(new ESLVal(" and ").add(ppType(_v1252,typeEnv))))));
        }
        }
      }
      }
    case "FloatType": {ESLVal $2341 = _v1140.termRef(0);
        
        switch(_v1141.termName) {
        case "FloatType": {ESLVal $2343 = _v1141.termRef(0);
          
          {ESLVal l1 = $2341;
          
          {ESLVal l2 = $2343;
          
          return t1;
        }
        }
        }
      case "IntType": {ESLVal $2342 = _v1141.termRef(0);
          
          {ESLVal l1 = $2341;
          
          {ESLVal l2 = $2342;
          
          return t1;
        }
        }
        }
        default: {ESLVal _v1249 = _v1140;
          
          {ESLVal _v1250 = _v1141;
          
          return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for -: ").add(ppType(_v1249,typeEnv).add(new ESLVal(" and ").add(ppType(_v1250,typeEnv))))));
        }
        }
      }
      }
      default: {ESLVal _v1253 = _v1140;
        
        {ESLVal _v1254 = _v1141;
        
        return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for -: ").add(ppType(_v1253,typeEnv).add(new ESLVal(" and ").add(ppType(_v1254,typeEnv))))));
      }
      }
    }
    }
    }
  }
  private static ESLVal subExpType = new ESLVal(new Function(new ESLVal("subExpType"),null) { public ESLVal apply(ESLVal... args) { return subExpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal plusExpType(ESLVal l,ESLVal e1,ESLVal e2,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t1 = expType(e1,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal t2 = expType(e2,selfType,valueEnv,cnstrEnv,typeEnv);
      
      {ESLVal _v1142 = t1;
      ESLVal _v1143 = t2;
      
      switch(_v1142.termName) {
      case "StrType": {ESLVal $2360 = _v1142.termRef(0);
        
        {ESLVal _v1243 = $2360;
        
        {ESLVal _v1244 = _v1143;
        
        return t1;
      }
      }
      }
    case "IntType": {ESLVal $2358 = _v1142.termRef(0);
        
        switch(_v1143.termName) {
        case "IntType": {ESLVal $2359 = _v1143.termRef(0);
          
          {ESLVal l1 = $2358;
          
          {ESLVal l2 = $2359;
          
          return t1;
        }
        }
        }
        default: switch(_v1143.termName) {
          case "StrType": {ESLVal $2347 = _v1143.termRef(0);
            
            {ESLVal _v1239 = _v1142;
            
            {ESLVal _v1240 = $2347;
            
            return t2;
          }
          }
          }
          default: {ESLVal _v1241 = _v1142;
            
            {ESLVal _v1242 = _v1143;
            
            return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for +: ").add(ppType(_v1241,typeEnv).add(new ESLVal(" and ").add(ppType(_v1242,typeEnv))))));
          }
          }
        }
      }
      }
    case "FloatType": {ESLVal $2356 = _v1142.termRef(0);
        
        switch(_v1143.termName) {
        case "FloatType": {ESLVal $2357 = _v1143.termRef(0);
          
          {ESLVal l1 = $2356;
          
          {ESLVal l2 = $2357;
          
          return t1;
        }
        }
        }
        default: switch(_v1143.termName) {
          case "StrType": {ESLVal $2347 = _v1143.termRef(0);
            
            {ESLVal _v1235 = _v1142;
            
            {ESLVal _v1236 = $2347;
            
            return t2;
          }
          }
          }
          default: {ESLVal _v1237 = _v1142;
            
            {ESLVal _v1238 = _v1143;
            
            return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for +: ").add(ppType(_v1237,typeEnv).add(new ESLVal(" and ").add(ppType(_v1238,typeEnv))))));
          }
          }
        }
      }
      }
    case "ListType": {ESLVal $2353 = _v1142.termRef(0);
        ESLVal $2352 = _v1142.termRef(1);
        
        switch(_v1143.termName) {
        case "ListType": {ESLVal $2355 = _v1143.termRef(0);
          ESLVal $2354 = _v1143.termRef(1);
          
          {ESLVal l1 = $2353;
          
          {ESLVal _v1225 = $2352;
          
          {ESLVal l2 = $2355;
          
          {ESLVal _v1226 = $2354;
          
          if(typeEqual.apply(_v1225,_v1226).boolVal)
          return new ESLVal("ListType",l1,_v1225);
          else
            switch(_v1143.termName) {
              case "StrType": {ESLVal $2347 = _v1143.termRef(0);
                
                {ESLVal _v1227 = _v1142;
                
                {ESLVal _v1228 = $2347;
                
                return _v1226;
              }
              }
              }
              default: {ESLVal _v1229 = _v1142;
                
                {ESLVal _v1230 = _v1143;
                
                return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for +: ").add(ppType(_v1229,typeEnv).add(new ESLVal(" and ").add(ppType(_v1230,typeEnv))))));
              }
              }
            }
        }
        }
        }
        }
        }
        default: switch(_v1143.termName) {
          case "StrType": {ESLVal $2347 = _v1143.termRef(0);
            
            {ESLVal _v1231 = _v1142;
            
            {ESLVal _v1232 = $2347;
            
            return t2;
          }
          }
          }
          default: {ESLVal _v1233 = _v1142;
            
            {ESLVal _v1234 = _v1143;
            
            return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for +: ").add(ppType(_v1233,typeEnv).add(new ESLVal(" and ").add(ppType(_v1234,typeEnv))))));
          }
          }
        }
      }
      }
    case "SetType": {ESLVal $2349 = _v1142.termRef(0);
        ESLVal $2348 = _v1142.termRef(1);
        
        switch(_v1143.termName) {
        case "SetType": {ESLVal $2351 = _v1143.termRef(0);
          ESLVal $2350 = _v1143.termRef(1);
          
          {ESLVal l1 = $2349;
          
          {ESLVal _v1215 = $2348;
          
          {ESLVal l2 = $2351;
          
          {ESLVal _v1216 = $2350;
          
          if(typeEqual.apply(_v1215,_v1216).boolVal)
          return new ESLVal("SetType",l1,_v1215);
          else
            switch(_v1143.termName) {
              case "StrType": {ESLVal $2347 = _v1143.termRef(0);
                
                {ESLVal _v1217 = _v1142;
                
                {ESLVal _v1218 = $2347;
                
                return _v1216;
              }
              }
              }
              default: {ESLVal _v1219 = _v1142;
                
                {ESLVal _v1220 = _v1143;
                
                return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for +: ").add(ppType(_v1219,typeEnv).add(new ESLVal(" and ").add(ppType(_v1220,typeEnv))))));
              }
              }
            }
        }
        }
        }
        }
        }
        default: switch(_v1143.termName) {
          case "StrType": {ESLVal $2347 = _v1143.termRef(0);
            
            {ESLVal _v1221 = _v1142;
            
            {ESLVal _v1222 = $2347;
            
            return t2;
          }
          }
          }
          default: {ESLVal _v1223 = _v1142;
            
            {ESLVal _v1224 = _v1143;
            
            return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for +: ").add(ppType(_v1223,typeEnv).add(new ESLVal(" and ").add(ppType(_v1224,typeEnv))))));
          }
          }
        }
      }
      }
      default: switch(_v1143.termName) {
        case "StrType": {ESLVal $2347 = _v1143.termRef(0);
          
          {ESLVal _v1245 = _v1142;
          
          {ESLVal _v1246 = $2347;
          
          return t2;
        }
        }
        }
        default: {ESLVal _v1247 = _v1142;
          
          {ESLVal _v1248 = _v1143;
          
          return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for +: ").add(ppType(_v1247,typeEnv).add(new ESLVal(" and ").add(ppType(_v1248,typeEnv))))));
        }
        }
      }
    }
    }
    }
  }
  private static ESLVal plusExpType = new ESLVal(new Function(new ESLVal("plusExpType"),null) { public ESLVal apply(ESLVal... args) { return plusExpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal applyTypeExp(ESLVal l,ESLVal e,ESLVal ts,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal _v1211 = substTypesEnv.apply(typeEnv,ts);
      ESLVal _v1212 = expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
      
      {ESLVal _v1144 = _v1212;
      
      switch(_v1144.termName) {
      case "ForallType": {ESLVal $2363 = _v1144.termRef(0);
        ESLVal $2362 = _v1144.termRef(1);
        ESLVal $2361 = _v1144.termRef(2);
        
        {ESLVal l1 = $2363;
        
        {ESLVal ns = $2362;
        
        {ESLVal _v1213 = $2361;
        
        if(length.apply(ns).eql(length.apply(_v1211)).boolVal)
        {ESLVal env = zipTypeEnv.apply(ns,_v1211);
          
          return substTypeEnv.apply(env.add(valueEnv),_v1213);
        }
        else
          return error(new ESLVal("TypeError",l,new ESLVal("universal type expects ").add(length.apply(ns).add(new ESLVal(" types, but supplied with ").add(length.apply(_v1211))))));
      }
      }
      }
      }
      default: {ESLVal _v1214 = _v1144;
        
        return error(new ESLVal("TypeError",l,new ESLVal("expecting a universal type: ").add(_v1214)));
      }
    }
    }
    }
  }
  private static ESLVal applyTypeExp = new ESLVal(new Function(new ESLVal("applyTypeExp"),null) { public ESLVal apply(ESLVal... args) { return applyTypeExp(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal expTypes(ESLVal es,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    return map.apply(new ESLVal(new Function(new ESLVal("fun404"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal e = $args[0];
      return expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
        }
      }),es);
  }
  private static ESLVal expTypes = new ESLVal(new Function(new ESLVal("expTypes"),null) { public ESLVal apply(ESLVal... args) { return expTypes(args[0],args[1],args[2],args[3],args[4]); }});
  private static ESLVal applyType(ESLVal l,ESLVal op,ESLVal args,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal _v1145 = typeNF(expType(op,selfType,valueEnv,cnstrEnv,typeEnv),typeEnv);
      
      switch(_v1145.termName) {
      case "FunType": {ESLVal $2366 = _v1145.termRef(0);
        ESLVal $2365 = _v1145.termRef(1);
        ESLVal $2364 = _v1145.termRef(2);
        
        {ESLVal l1 = $2366;
        
        {ESLVal domain = $2365;
        
        {ESLVal range = $2364;
        
        {ESLVal supplied = expTypes(args,selfType,valueEnv,cnstrEnv,typeEnv);
        
        if(length.apply(domain).eql(length.apply(supplied)).boolVal)
        if(subTypes.apply(supplied,domain).boolVal)
          return range;
          else
            return error(new ESLVal("TypeError",l,new ESLVal("supplied argument types ").add(ppTypes(supplied,typeEnv).add(new ESLVal(" do not match function domain ").add(ppTypes(domain,typeEnv))))));
        else
          return error(new ESLVal("TypeError",l,new ESLVal("expecting ").add(length.apply(domain).add(new ESLVal(" args, but supplied with ").add(length.apply(supplied))))));
      }
      }
      }
      }
      }
      default: {ESLVal t = _v1145;
        
        return error(new ESLVal("TypeError",l,new ESLVal("unknown type for apply: ").add(ppType(t,typeEnv))));
      }
    }
    }
  }
  private static ESLVal applyType = new ESLVal(new Function(new ESLVal("applyType"),null) { public ESLVal apply(ESLVal... args) { return applyType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal ifType(ESLVal l,ESLVal e1,ESLVal e2,ESLVal e3,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal testType = expType(e1,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(isBoolType.apply(testType).boolVal)
      {ESLVal conseqType = expType(e2,selfType,valueEnv,cnstrEnv,typeEnv);
        ESLVal altType = expType(e3,selfType,valueEnv,cnstrEnv,typeEnv);
        
        if(typeEqual.apply(conseqType,altType).boolVal)
        return conseqType;
        else
          return error(new ESLVal("TypeError",l,new ESLVal("conseq and alt types do not agree: ").add(ppType(conseqType,typeEnv).add(new ESLVal(" ").add(ppType(altType,typeEnv))))));
      }
      else
        return error(new ESLVal("if expects a bool ").add(ppType(testType,typeEnv)));
    }
  }
  private static ESLVal ifType = new ESLVal(new Function(new ESLVal("ifType"),null) { public ESLVal apply(ESLVal... args) { return ifType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7]); }});
  private static ESLVal checkDecs(ESLVal ds) {
    
    {ESLVal _v1146 = ds;
      
      if(_v1146.isCons())
      {ESLVal $2367 = _v1146.head();
        ESLVal $2368 = _v1146.tail();
        
        {ESLVal d = $2367;
        
        {ESLVal _v1210 = $2368;
        
        if(member.apply(decName.apply(d),new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal d = $l0.head();
            $l0 = $l0.tail();
            $v.add(decName.apply(d));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(_v1210)).boolVal)
        return error(new ESLVal("TypeError",decLoc.apply(d),new ESLVal(" duplicate argument ").add(decName.apply(d))));
        else
          return checkDecs(_v1210);
      }
      }
      }
    else if(_v1146.isNil())
      return $null;
    else return error(new ESLVal("case error at Pos(70336,70569)").add(ESLVal.list(_v1146)));
    }
  }
  private static ESLVal checkDecs = new ESLVal(new Function(new ESLVal("checkDecs"),null) { public ESLVal apply(ESLVal... args) { return checkDecs(args[0]); }});
  private static ESLVal funType(ESLVal l,ESLVal n,ESLVal args,ESLVal t,ESLVal e,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {checkDecs(args);
    {ESLVal nType = expType(n,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(isStrType.apply(nType).boolVal)
      {ESLVal declaredType = substTypeEnv.apply(typeEnv,t);
        
        return decTypes(args,valueEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun405"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1208 = $args[0];
        ESLVal _v1209 = $args[1];
        {ESLVal actualRange = expType(e,selfType,_v1209,cnstrEnv,typeEnv);
              
              if(subType.apply(new ESLVal("FunType",l,_v1208,actualRange),declaredType).boolVal)
              return new ESLVal("FunType",l,_v1208,actualRange);
              else
                return error(new ESLVal("TypeError",l,new ESLVal("function declared type ").add(ppType(declaredType,typeEnv).add(new ESLVal(" but is ").add(ppType(new ESLVal("FunType",l,_v1208,actualRange),typeEnv))))));
            }
          }
        }));
      }
      else
        return error(new ESLVal("TypeError",l,new ESLVal("expecting a string for a function name: ").add(n)));
    }}
  }
  private static ESLVal funType = new ESLVal(new Function(new ESLVal("funType"),null) { public ESLVal apply(ESLVal... args) { return funType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7],args[8]); }});
  private static ESLVal decTypes(ESLVal decs,ESLVal valueEnv,ESLVal typeEnv,ESLVal consumer) {
    
    { LetRec letrec = new LetRec() {
      ESLVal processDecs = new ESLVal(new Function(new ESLVal("processDecs"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1205 = $args[0];
        ESLVal _v1206 = $args[1];
        {ESLVal _v1147 = _v1205;
              
              if(_v1147.isCons())
              {ESLVal $2369 = _v1147.head();
                ESLVal $2370 = _v1147.tail();
                
                switch($2369.termName) {
                case "Dec": {ESLVal $2374 = $2369.termRef(0);
                  ESLVal $2373 = $2369.termRef(1);
                  ESLVal $2372 = $2369.termRef(2);
                  ESLVal $2371 = $2369.termRef(3);
                  
                  {ESLVal l = $2374;
                  
                  {ESLVal n = $2373;
                  
                  {ESLVal t = $2372;
                  
                  {ESLVal st = $2371;
                  
                  {ESLVal _v1207 = $2370;
                  
                  return processDecs.apply(_v1207,_v1206.cons(new ESLVal("Map",n,substTypeEnv.apply(typeEnv,t))));
                }
                }
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(71762,71987)").add(ESLVal.list(_v1147)));
              }
              }
            else if(_v1147.isNil())
              return consumer.apply(reverse.apply(typeEnvRan.apply(_v1206)),_v1206.add(valueEnv));
            else return error(new ESLVal("case error at Pos(71762,71987)").add(ESLVal.list(_v1147)));
            }
          }
        });
      
      public ESLVal get(String name) {
        switch(name) {
          case "processDecs": return processDecs;
          
          default: throw new Error("cannot find letrec binding");
        }
        }
      };
    ESLVal processDecs = letrec.get("processDecs");
    
      return processDecs.apply(decs,$nil);}
    
  }
  private static ESLVal decTypes = new ESLVal(new Function(new ESLVal("decTypes"),null) { public ESLVal apply(ESLVal... args) { return decTypes(args[0],args[1],args[2],args[3]); }});
  private static ESLVal termType(ESLVal l,ESLVal n,ESLVal ts,ESLVal es,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t0 = lookupType.apply(n,cnstrEnv);
      
      if(t0.eql($null).boolVal)
      return error(new ESLVal("TypeError",l,new ESLVal("cannot find cnstr ").add(n)));
      else
        {ESLVal t = unfoldIf(t0);
          
          return termTypeCheckUnion(t,l,n,ts,es,selfType,valueEnv,cnstrEnv,typeEnv);
        }
    }
  }
  private static ESLVal termType = new ESLVal(new Function(new ESLVal("termType"),null) { public ESLVal apply(ESLVal... args) { return termType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7]); }});
  private static ESLVal termTypeCheckUnion(ESLVal t,ESLVal l,ESLVal n,ESLVal ts,ESLVal es,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    if(t.eql($null).boolVal)
      return error(new ESLVal("TypeError",l,new ESLVal("cannot find constructor ").add(n)));
      else
        {ESLVal _v1148 = t;
          
          switch(_v1148.termName) {
          case "TypeFun": {ESLVal $2379 = _v1148.termRef(0);
            ESLVal $2378 = _v1148.termRef(1);
            ESLVal $2377 = _v1148.termRef(2);
            
            {ESLVal lf = $2379;
            
            {ESLVal ns = $2378;
            
            {ESLVal body = $2377;
            
            if(length.apply(ns).eql(length.apply(ts)).boolVal)
            {ESLVal args = map.apply(new ESLVal(new Function(new ESLVal("fun406"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal _v1203 = $args[0];
                return substTypeEnv.apply(typeEnv,_v1203);
                  }
                }),ts);
              
              {ESLVal _v1149 = substTypeEnv.apply(zipTypeEnv.apply(ns,args),body);
              
              switch(_v1149.termName) {
              case "UnionType": {ESLVal $2381 = _v1149.termRef(0);
                ESLVal $2380 = _v1149.termRef(1);
                
                {ESLVal l1 = $2381;
                
                {ESLVal terms = $2380;
                
                {ESLVal ts2 = findTermArgTypes(n,terms);
                
                if(length.apply(es).eql(length.apply(ts2)).boolVal)
                {checkTermArgTypes(l,es,ts2,selfType,valueEnv,cnstrEnv,typeEnv);
                return new ESLVal("UnionType",l1,terms);}
                else
                  return error(new ESLVal("TypeError",l,n.add(new ESLVal(" expects ").add(length.apply(ts2).add(new ESLVal(" args, but you supplied ").add(length.apply(es)))))));
              }
              }
              }
              }
              default: return error(new ESLVal("case error at Pos(72860,73422)").add(ESLVal.list(_v1149)));
            }
            }
            }
            else
              return error(new ESLVal("TypeError",l,new ESLVal("generic constructor ").add(n.add(new ESLVal(" expects ").add(length.apply(ns).add(new ESLVal(" type arguments, but received ").add(length.apply(ts))))))));
          }
          }
          }
          }
        case "UnionType": {ESLVal $2376 = _v1148.termRef(0);
            ESLVal $2375 = _v1148.termRef(1);
            
            {ESLVal l1 = $2376;
            
            {ESLVal terms = $2375;
            
            {ESLVal ts2 = findTermArgTypes(n,terms);
            
            if(length.apply(ts).neql($zero).boolVal)
            return error(new ESLVal("TypeError",l,new ESLVal("generic application of non-generic constructior: ").add(n)));
            else
              if(length.apply(es).eql(length.apply(ts2)).boolVal)
                {checkTermArgTypes(l,es,ts2,selfType,valueEnv,cnstrEnv,typeEnv);
                return t;}
                else
                  return error(new ESLVal("TypeError",l,n.add(new ESLVal(" expects ").add(length.apply(ts2).add(new ESLVal(" args, but you supplied ").add(length.apply(es)))))));
          }
          }
          }
          }
          default: {ESLVal _v1204 = _v1148;
            
            return error(new ESLVal("TypeError",l,new ESLVal("expecting a union type for ").add(n.add(new ESLVal(" but got ").add(ppType(_v1204,typeEnv))))));
          }
        }
        }
  }
  private static ESLVal termTypeCheckUnion = new ESLVal(new Function(new ESLVal("termTypeCheckUnion"),null) { public ESLVal apply(ESLVal... args) { return termTypeCheckUnion(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7],args[8]); }});
  private static ESLVal unfoldIf(ESLVal t) {
    
    {ESLVal _v1150 = t;
      
      switch(_v1150.termName) {
      case "RecType": {ESLVal $2384 = _v1150.termRef(0);
        ESLVal $2383 = _v1150.termRef(1);
        ESLVal $2382 = _v1150.termRef(2);
        
        {ESLVal l = $2384;
        
        {ESLVal n = $2383;
        
        {ESLVal _v1201 = $2382;
        
        return unfoldIf(unfoldType.apply(l,n,_v1201));
      }
      }
      }
      }
      default: {ESLVal _v1202 = _v1150;
        
        return _v1202;
      }
    }
    }
  }
  private static ESLVal unfoldIf = new ESLVal(new Function(new ESLVal("unfoldIf"),null) { public ESLVal apply(ESLVal... args) { return unfoldIf(args[0]); }});
  private static ESLVal findTermArgTypes(ESLVal n,ESLVal terms) {
    
    {ESLVal _v1151 = terms;
      
      if(_v1151.isCons())
      {ESLVal $2385 = _v1151.head();
        ESLVal $2386 = _v1151.tail();
        
        switch($2385.termName) {
        case "TermType": {ESLVal $2389 = $2385.termRef(0);
          ESLVal $2388 = $2385.termRef(1);
          ESLVal $2387 = $2385.termRef(2);
          
          {ESLVal l = $2389;
          
          {ESLVal nn = $2388;
          
          {ESLVal ts = $2387;
          
          {ESLVal _v1199 = $2386;
          
          if(nn.eql(n).boolVal)
          return ts;
          else
            {ESLVal t = $2385;
              
              {ESLVal _v1200 = $2386;
              
              return findTermArgTypes(n,_v1200);
            }
            }
        }
        }
        }
        }
        }
        default: {ESLVal t = $2385;
          
          {ESLVal ts = $2386;
          
          return findTermArgTypes(n,ts);
        }
        }
      }
      }
    else if(_v1151.isNil())
      return error(new ESLVal("cannot find constructor ").add(n));
    else return error(new ESLVal("case error at Pos(74430,74630)").add(ESLVal.list(_v1151)));
    }
  }
  private static ESLVal findTermArgTypes = new ESLVal(new Function(new ESLVal("findTermArgTypes"),null) { public ESLVal apply(ESLVal... args) { return findTermArgTypes(args[0],args[1]); }});
  private static ESLVal checkTermArgTypes(ESLVal l,ESLVal es,ESLVal ts,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal _v1152 = es;
      ESLVal _v1153 = ts;
      
      if(_v1152.isCons())
      {ESLVal $2390 = _v1152.head();
        ESLVal $2391 = _v1152.tail();
        
        if(_v1153.isCons())
        {ESLVal $2392 = _v1153.head();
          ESLVal $2393 = _v1153.tail();
          
          {ESLVal e = $2390;
          
          {ESLVal _v1197 = $2391;
          
          {ESLVal t = $2392;
          
          {ESLVal _v1198 = $2393;
          
          {ESLVal tt = expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
          
          if(typeEqual.apply(t,tt).boolVal)
          return checkTermArgTypes(l,_v1197,_v1198,selfType,valueEnv,cnstrEnv,typeEnv);
          else
            return error(new ESLVal("TypeError",l,new ESLVal("expected constructor arg type ").add(ppType(t,typeEnv).add(new ESLVal(" but supplied ").add(ppType(tt,typeEnv))))));
        }
        }
        }
        }
        }
        }
      else if(_v1153.isNil())
        return error(new ESLVal("case error at Pos(74748,75170)").add(ESLVal.list(_v1152,_v1153)));
      else return error(new ESLVal("case error at Pos(74748,75170)").add(ESLVal.list(_v1152,_v1153)));
      }
    else if(_v1152.isNil())
      if(_v1153.isCons())
        {ESLVal $2394 = _v1153.head();
          ESLVal $2395 = _v1153.tail();
          
          return error(new ESLVal("case error at Pos(74748,75170)").add(ESLVal.list(_v1152,_v1153)));
        }
      else if(_v1153.isNil())
        return $null;
      else return error(new ESLVal("case error at Pos(74748,75170)").add(ESLVal.list(_v1152,_v1153)));
    else return error(new ESLVal("case error at Pos(74748,75170)").add(ESLVal.list(_v1152,_v1153)));
    }
  }
  private static ESLVal checkTermArgTypes = new ESLVal(new Function(new ESLVal("checkTermArgTypes"),null) { public ESLVal apply(ESLVal... args) { return checkTermArgTypes(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal notType(ESLVal l,ESLVal e,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal _v1154 = expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
      
      switch(_v1154.termName) {
      case "BoolType": {ESLVal $2396 = _v1154.termRef(0);
        
        {ESLVal _v1196 = $2396;
        
        return new ESLVal("BoolType",_v1196);
      }
      }
      default: {ESLVal t = _v1154;
        
        return error(new ESLVal("TypeError",l,new ESLVal("expecting a boolean: ").add(ppType(t,typeEnv))));
      }
    }
    }
  }
  private static ESLVal notType = new ESLVal(new Function(new ESLVal("notType"),null) { public ESLVal apply(ESLVal... args) { return notType(args[0],args[1],args[2],args[3],args[4],args[5]); }});
  private static ESLVal varType(ESLVal l,ESLVal n,ESLVal valueEnv) {
    
    {ESLVal t = lookupType.apply(n,valueEnv);
      
      if(t.eql($null).boolVal)
      return error(new ESLVal("TypeError",l,new ESLVal("unbound variable ").add(n)));
      else
        {ESLVal _v1155 = t;
          
          switch(_v1155.termName) {
          case "TypeClosure": {ESLVal $2397 = _v1155.termRef(0);
            
            {ESLVal f = $2397;
            
            return f.apply();
          }
          }
          default: {ESLVal _v1195 = _v1155;
            
            return _v1195;
          }
        }
        }
    }
  }
  private static ESLVal varType = new ESLVal(new Function(new ESLVal("varType"),null) { public ESLVal apply(ESLVal... args) { return varType(args[0],args[1],args[2]); }});
  private static ESLVal blockType(ESLVal l,ESLVal es,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal[] t = new ESLVal[]{new ESLVal("VoidType",l)};
      
      {{
      ESLVal _v1156 = es;
      while(_v1156.isCons()) {
        ESLVal e = _v1156.headVal;
        t[0] = expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
        _v1156 = _v1156.tailVal;}
    }
    return t[0];}
    }
  }
  private static ESLVal blockType = new ESLVal(new Function(new ESLVal("blockType"),null) { public ESLVal apply(ESLVal... args) { return blockType(args[0],args[1],args[2],args[3],args[4],args[5]); }});
  private static ESLVal listType(ESLVal l,ESLVal es,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    if(es.eql($nil).boolVal)
      return new ESLVal("ForallType",l,ESLVal.list(new ESLVal("T")),new ESLVal("ListType",l,new ESLVal("VarType",l,new ESLVal("T"))));
      else
        {ESLVal ts = map.apply(new ESLVal(new Function(new ESLVal("fun407"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal e = $args[0];
            return expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
              }
            }),es);
          
          if(allEqualTypes.apply(head.apply(ts),tail.apply(ts)).boolVal)
          return new ESLVal("ListType",l,head.apply(ts));
          else
            return error(new ESLVal("TypeError",l,new ESLVal("lists should have elements of the same type: ").add(es)));
        }
  }
  private static ESLVal listType = new ESLVal(new Function(new ESLVal("listType"),null) { public ESLVal apply(ESLVal... args) { return listType(args[0],args[1],args[2],args[3],args[4],args[5]); }});
  private static ESLVal setType(ESLVal l,ESLVal es,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    if(es.eql($nil).boolVal)
      return new ESLVal("ForallType",l,ESLVal.list(new ESLVal("T")),new ESLVal("SetType",l,new ESLVal("VarType",l,new ESLVal("T"))));
      else
        {ESLVal ts = map.apply(new ESLVal(new Function(new ESLVal("fun408"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal e = $args[0];
            return expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
              }
            }),es);
          
          if(allEqualTypes.apply(head.apply(ts),tail.apply(ts)).boolVal)
          return new ESLVal("SetType",l,head.apply(ts));
          else
            return error(new ESLVal("TypeError",l,new ESLVal("sets should have elements of the same type: ").add(es)));
        }
  }
  private static ESLVal setType = new ESLVal(new Function(new ESLVal("setType"),null) { public ESLVal apply(ESLVal... args) { return setType(args[0],args[1],args[2],args[3],args[4],args[5]); }});
  private static ESLVal bagType(ESLVal l,ESLVal es,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    if(es.eql($nil).boolVal)
      return new ESLVal("ForallType",l,ESLVal.list(new ESLVal("T")),new ESLVal("BagType",l,new ESLVal("VarType",l,new ESLVal("T"))));
      else
        {ESLVal ts = map.apply(new ESLVal(new Function(new ESLVal("fun409"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal e = $args[0];
            return expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
              }
            }),es);
          
          if(allEqualTypes.apply(head.apply(ts),tail.apply(ts)).boolVal)
          return new ESLVal("BagType",l,head.apply(ts));
          else
            return error(new ESLVal("TypeError",l,new ESLVal("bags should have elements of the same type: ").add(es)));
        }
  }
  private static ESLVal bagType = new ESLVal(new Function(new ESLVal("bagType"),null) { public ESLVal apply(ESLVal... args) { return bagType(args[0],args[1],args[2],args[3],args[4],args[5]); }});
  private static ESLVal recTypes(ESLVal env) {
    
    { LetRec letrec = new LetRec() {
      ESLVal fixEnv = new ESLVal(new Function(new ESLVal("fixEnv"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1194 = $args[0];
        {ESLVal[] e = new ESLVal[]{$null};
              
              {ESLVal fenv = new java.util.function.Function<ESLVal,ESLVal>() {
                  public ESLVal apply(ESLVal $l0) {
                    ESLVal $a = $nil;
                    java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                    while(!$l0.isNil()) { 
                      ESLVal t = $l0.head();
                      $l0 = $l0.tail();
                      ESLVal $l1 = typeFV(t);
                while(!$l1.isNil()) {
                  ESLVal n = $l1.head();
                  $l1 = $l1.tail();
                  $v.add(new ESLVal("Map",n,new ESLVal("TypeClosure",new ESLVal(new Function(new ESLVal("lookup: ").add(n),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      return lookupType.apply(n,e[0]);
                    }
                  }))));
                }
                    }
                    for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                    return $a;
                  }}.apply(typeEnvRan.apply(_v1194));
              
              {ESLVal env1 = substOnce.apply(_v1194,fenv);
              
              {e[0] = env1;
            return env1;}
            }
            }
            }
          }
        });
      ESLVal introduceRecTypes = new ESLVal(new Function(new ESLVal("introduceRecTypes"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1193 = $args[0];
        {ESLVal _v1157 = _v1193;
              
              if(_v1157.isCons())
              {ESLVal $2398 = _v1157.head();
                ESLVal $2399 = _v1157.tail();
                
                switch($2398.termName) {
                case "Map": {ESLVal $2401 = $2398.termRef(0);
                  ESLVal $2400 = $2398.termRef(1);
                  
                  switch($2400.termName) {
                  case "RecordType": {ESLVal $2403 = $2400.termRef(0);
                    ESLVal $2402 = $2400.termRef(1);
                    
                    {ESLVal n = $2401;
                    
                    {ESLVal l = $2403;
                    
                    {ESLVal fs = $2402;
                    
                    {ESLVal e = $2399;
                    
                    return introduceRecTypes.apply(e).cons(new ESLVal("Map",n,new ESLVal("RecordType",l,fs)));
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal n = $2401;
                    
                    {ESLVal t = $2400;
                    
                    {ESLVal e = $2399;
                    
                    if(member.apply(n,typeFV(t)).boolVal)
                    return introduceRecTypes.apply(e).cons(new ESLVal("Map",n,new ESLVal("RecType",p0,n,t)));
                    else
                      return introduceRecTypes.apply(e).cons(new ESLVal("Map",n,t));
                  }
                  }
                  }
                }
                }
                default: return error(new ESLVal("case error at Pos(77719,78033)").add(ESLVal.list(_v1157)));
              }
              }
            else if(_v1157.isNil())
              return _v1193;
            else return error(new ESLVal("case error at Pos(77719,78033)").add(ESLVal.list(_v1157)));
            }
          }
        });
      ESLVal substOnce = new ESLVal(new Function(new ESLVal("substOnce"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1191 = $args[0];
        ESLVal _v1192 = $args[1];
        {ESLVal map1 = new ESLVal(new Function(new ESLVal("map1"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal m = $args[0];
                {ESLVal _v1158 = m;
                      
                      switch(_v1158.termName) {
                      case "Map": {ESLVal $2405 = _v1158.termRef(0);
                        ESLVal $2404 = _v1158.termRef(1);
                        
                        {ESLVal n = $2405;
                        
                        {ESLVal t = $2404;
                        
                        return new ESLVal("Map",n,substTypeEnv.apply(new java.util.function.Function<ESLVal,ESLVal>() {
                          public ESLVal apply(ESLVal $l0) {
                            ESLVal $a = $nil;
                            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                            while(!$l0.isNil()) { 
                              ESLVal n = $l0.head();
                              $l0 = $l0.tail();
                              $v.add(new ESLVal("Map",n,lookupType.apply(n,_v1192)));
                            }
                            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                            return $a;
                          }}.apply(typeFV(t)),t));
                      }
                      }
                      }
                      default: return error(new ESLVal("case error at Pos(78143,78274)").add(ESLVal.list(_v1158)));
                    }
                    }
                  }
                });
              
              return map.apply(map1,_v1191);
            }
          }
        });
      
      public ESLVal get(String name) {
        switch(name) {
          case "fixEnv": return fixEnv;
          
          case "introduceRecTypes": return introduceRecTypes;
          
          case "substOnce": return substOnce;
          
          default: throw new Error("cannot find letrec binding");
        }
        }
      };
    ESLVal fixEnv = letrec.get("fixEnv");
    
    ESLVal introduceRecTypes = letrec.get("introduceRecTypes");
    
    ESLVal substOnce = letrec.get("substOnce");
    
      return fixEnv.apply(introduceRecTypes.apply(env));}
    
  }
  private static ESLVal recTypes = new ESLVal(new Function(new ESLVal("recTypes"),null) { public ESLVal apply(ESLVal... args) { return recTypes(args[0]); }});
  private static ESLVal typeFV(ESLVal t) {
    
    return removeDups.apply(varTypeNames(typeFV1(t,$nil)));
  }
  private static ESLVal typeFV = new ESLVal(new Function(new ESLVal("typeFV"),null) { public ESLVal apply(ESLVal... args) { return typeFV(args[0]); }});
  private static ESLVal varTypeNames(ESLVal vs) {
    
    return map.apply(varTypeName,vs);
  }
  private static ESLVal varTypeNames = new ESLVal(new Function(new ESLVal("varTypeNames"),null) { public ESLVal apply(ESLVal... args) { return varTypeNames(args[0]); }});
  private static ESLVal varTypeName(ESLVal t) {
    
    {ESLVal _v1159 = t;
      
      switch(_v1159.termName) {
      case "VarType": {ESLVal $2407 = _v1159.termRef(0);
        ESLVal $2406 = _v1159.termRef(1);
        
        {ESLVal l = $2407;
        
        {ESLVal n = $2406;
        
        return n;
      }
      }
      }
      default: {ESLVal x = _v1159;
        
        return new ESLVal("<var>");
      }
    }
    }
  }
  private static ESLVal varTypeName = new ESLVal(new Function(new ESLVal("varTypeName"),null) { public ESLVal apply(ESLVal... args) { return varTypeName(args[0]); }});
  private static ESLVal tdecsFV1(ESLVal decs,ESLVal fv) {
    
    {ESLVal _v1160 = decs;
      
      if(_v1160.isCons())
      {ESLVal $2408 = _v1160.head();
        ESLVal $2409 = _v1160.tail();
        
        {ESLVal d = $2408;
        
        {ESLVal ds = $2409;
        
        return tdecFV1(d,tdecsFV1(ds,fv));
      }
      }
      }
    else if(_v1160.isNil())
      return fv;
    else return error(new ESLVal("case error at Pos(78660,78749)").add(ESLVal.list(_v1160)));
    }
  }
  private static ESLVal tdecsFV1 = new ESLVal(new Function(new ESLVal("tdecsFV1"),null) { public ESLVal apply(ESLVal... args) { return tdecsFV1(args[0],args[1]); }});
  private static ESLVal tdecFV1(ESLVal d,ESLVal fv) {
    
    {ESLVal _v1161 = d;
      
      switch(_v1161.termName) {
      case "Dec": {ESLVal $2413 = _v1161.termRef(0);
        ESLVal $2412 = _v1161.termRef(1);
        ESLVal $2411 = _v1161.termRef(2);
        ESLVal $2410 = _v1161.termRef(3);
        
        {ESLVal l = $2413;
        
        {ESLVal n = $2412;
        
        {ESLVal t = $2411;
        
        {ESLVal st = $2410;
        
        return typeFV1(t,fv);
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(78793,78872)").add(ESLVal.list(_v1161)));
    }
    }
  }
  private static ESLVal tdecFV1 = new ESLVal(new Function(new ESLVal("tdecFV1"),null) { public ESLVal apply(ESLVal... args) { return tdecFV1(args[0],args[1]); }});
  private static ESLVal handlersFV1(ESLVal handlers,ESLVal fv) {
    
    {ESLVal _v1162 = handlers;
      
      if(_v1162.isCons())
      {ESLVal $2414 = _v1162.head();
        ESLVal $2415 = _v1162.tail();
        
        {ESLVal m = $2414;
        
        {ESLVal hs = $2415;
        
        return handlerFV1(m,handlersFV1(hs,fv));
      }
      }
      }
    else if(_v1162.isNil())
      return fv;
    else return error(new ESLVal("case error at Pos(78930,79032)").add(ESLVal.list(_v1162)));
    }
  }
  private static ESLVal handlersFV1 = new ESLVal(new Function(new ESLVal("handlersFV1"),null) { public ESLVal apply(ESLVal... args) { return handlersFV1(args[0],args[1]); }});
  private static ESLVal handlerFV1(ESLVal m,ESLVal fv) {
    
    {ESLVal _v1163 = m;
      
      switch(_v1163.termName) {
      case "MessageType": {ESLVal $2417 = _v1163.termRef(0);
        ESLVal $2416 = _v1163.termRef(1);
        
        {ESLVal l = $2417;
        
        {ESLVal ts = $2416;
        
        return typesFV1(ts,fv);
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(79080,79156)").add(ESLVal.list(_v1163)));
    }
    }
  }
  private static ESLVal handlerFV1 = new ESLVal(new Function(new ESLVal("handlerFV1"),null) { public ESLVal apply(ESLVal... args) { return handlerFV1(args[0],args[1]); }});
  private static ESLVal typesFV1(ESLVal ts,ESLVal fv) {
    
    {ESLVal _v1164 = ts;
      
      if(_v1164.isCons())
      {ESLVal $2418 = _v1164.head();
        ESLVal $2419 = _v1164.tail();
        
        {ESLVal t = $2418;
        
        {ESLVal _v1190 = $2419;
        
        return typeFV1(t,typesFV1(_v1190,fv));
      }
      }
      }
    else if(_v1164.isNil())
      return fv;
    else return error(new ESLVal("case error at Pos(79205,79292)").add(ESLVal.list(_v1164)));
    }
  }
  private static ESLVal typesFV1 = new ESLVal(new Function(new ESLVal("typesFV1"),null) { public ESLVal apply(ESLVal... args) { return typesFV1(args[0],args[1]); }});
  private static ESLVal typeFV1(ESLVal t,ESLVal fv) {
    
    {ESLVal _v1165 = t;
      
      switch(_v1165.termName) {
      case "ArrayType": {ESLVal $2485 = _v1165.termRef(0);
        ESLVal $2484 = _v1165.termRef(1);
        
        {ESLVal l = $2485;
        
        {ESLVal _v1189 = $2484;
        
        return typeFV1(_v1189,fv);
      }
      }
      }
    case "ActType": {ESLVal $2483 = _v1165.termRef(0);
        ESLVal $2482 = _v1165.termRef(1);
        ESLVal $2481 = _v1165.termRef(2);
        
        {ESLVal l = $2483;
        
        {ESLVal decs = $2482;
        
        {ESLVal handlers = $2481;
        
        return tdecsFV1(decs,handlersFV1(handlers,fv));
      }
      }
      }
      }
    case "ExtendedAct": {ESLVal $2480 = _v1165.termRef(0);
        ESLVal $2479 = _v1165.termRef(1);
        ESLVal $2478 = _v1165.termRef(2);
        ESLVal $2477 = _v1165.termRef(3);
        
        {ESLVal l = $2480;
        
        {ESLVal parent = $2479;
        
        {ESLVal decs = $2478;
        
        {ESLVal handlers = $2477;
        
        return tdecsFV1(decs,handlersFV1(handlers,typeFV1(parent,fv)));
      }
      }
      }
      }
      }
    case "ApplyType": {ESLVal $2476 = _v1165.termRef(0);
        ESLVal $2475 = _v1165.termRef(1);
        ESLVal $2474 = _v1165.termRef(2);
        
        {ESLVal l = $2476;
        
        {ESLVal n = $2475;
        
        {ESLVal types = $2474;
        
        return typesFV1(types,fv.cons(new ESLVal("VarType",l,n)));
      }
      }
      }
      }
    case "ApplyTypeFun": {ESLVal $2473 = _v1165.termRef(0);
        ESLVal $2472 = _v1165.termRef(1);
        ESLVal $2471 = _v1165.termRef(2);
        
        {ESLVal l = $2473;
        
        {ESLVal op = $2472;
        
        {ESLVal args = $2471;
        
        return typesFV1(args,typeFV1(op,fv));
      }
      }
      }
      }
    case "BoolType": {ESLVal $2470 = _v1165.termRef(0);
        
        {ESLVal l = $2470;
        
        return fv;
      }
      }
    case "FieldType": {ESLVal $2469 = _v1165.termRef(0);
        ESLVal $2468 = _v1165.termRef(1);
        ESLVal $2467 = _v1165.termRef(2);
        
        {ESLVal l = $2469;
        
        {ESLVal n = $2468;
        
        {ESLVal _v1188 = $2467;
        
        return typeFV1(_v1188,fv);
      }
      }
      }
      }
    case "FloatType": {ESLVal $2466 = _v1165.termRef(0);
        
        {ESLVal l = $2466;
        
        return fv;
      }
      }
    case "ForallType": {ESLVal $2465 = _v1165.termRef(0);
        ESLVal $2464 = _v1165.termRef(1);
        ESLVal $2463 = _v1165.termRef(2);
        
        {ESLVal l = $2465;
        
        {ESLVal ns = $2464;
        
        {ESLVal _v1185 = $2463;
        
        return filter.apply(new ESLVal(new Function(new ESLVal("fun410"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1186 = $args[0];
        {ESLVal _v1169 = _v1186;
              
              switch(_v1169.termName) {
              case "VarType": {ESLVal $2495 = _v1169.termRef(0);
                ESLVal $2494 = _v1169.termRef(1);
                
                {ESLVal _v1187 = $2495;
                
                {ESLVal n = $2494;
                
                return member.apply(n,ns).not();
              }
              }
              }
              default: return error(new ESLVal("case error at Pos(80131,80191)").add(ESLVal.list(_v1169)));
            }
            }
          }
        }),typeFV1(_v1185,$nil)).add(fv);
      }
      }
      }
      }
    case "FunType": {ESLVal $2462 = _v1165.termRef(0);
        ESLVal $2461 = _v1165.termRef(1);
        ESLVal $2460 = _v1165.termRef(2);
        
        {ESLVal l = $2462;
        
        {ESLVal d = $2461;
        
        {ESLVal r = $2460;
        
        return typesFV1(d,typeFV1(r,fv));
      }
      }
      }
      }
    case "IntType": {ESLVal $2459 = _v1165.termRef(0);
        
        {ESLVal l = $2459;
        
        return fv;
      }
      }
    case "ListType": {ESLVal $2458 = _v1165.termRef(0);
        ESLVal $2457 = _v1165.termRef(1);
        
        {ESLVal l = $2458;
        
        {ESLVal _v1184 = $2457;
        
        return typeFV1(_v1184,fv);
      }
      }
      }
    case "BagType": {ESLVal $2456 = _v1165.termRef(0);
        ESLVal $2455 = _v1165.termRef(1);
        
        {ESLVal l = $2456;
        
        {ESLVal _v1183 = $2455;
        
        return typeFV1(_v1183,fv);
      }
      }
      }
    case "SetType": {ESLVal $2454 = _v1165.termRef(0);
        ESLVal $2453 = _v1165.termRef(1);
        
        {ESLVal l = $2454;
        
        {ESLVal _v1182 = $2453;
        
        return typeFV1(_v1182,fv);
      }
      }
      }
    case "NullType": {ESLVal $2452 = _v1165.termRef(0);
        
        {ESLVal l = $2452;
        
        return fv;
      }
      }
    case "ObserverType": {ESLVal $2451 = _v1165.termRef(0);
        ESLVal $2450 = _v1165.termRef(1);
        ESLVal $2449 = _v1165.termRef(2);
        
        {ESLVal l = $2451;
        
        {ESLVal s = $2450;
        
        {ESLVal m = $2449;
        
        return typeFV1(s,typeFV1(m,fv));
      }
      }
      }
      }
    case "ObservedType": {ESLVal $2448 = _v1165.termRef(0);
        ESLVal $2447 = _v1165.termRef(1);
        ESLVal $2446 = _v1165.termRef(2);
        
        {ESLVal l = $2448;
        
        {ESLVal s = $2447;
        
        {ESLVal m = $2446;
        
        return typeFV1(s,typeFV1(m,fv));
      }
      }
      }
      }
    case "RecordType": {ESLVal $2445 = _v1165.termRef(0);
        ESLVal $2444 = _v1165.termRef(1);
        
        {ESLVal l = $2445;
        
        {ESLVal fs = $2444;
        
        return typesFV1(new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v1168 = $qualArg;
              
              switch(_v1168.termName) {
              case "Dec": {ESLVal $2493 = _v1168.termRef(0);
                ESLVal $2492 = _v1168.termRef(1);
                ESLVal $2491 = _v1168.termRef(2);
                ESLVal $2490 = _v1168.termRef(3);
                
                {ESLVal _v1180 = $2493;
                
                {ESLVal n = $2492;
                
                {ESLVal _v1181 = $2491;
                
                {ESLVal dt = $2490;
                
                return ESLVal.list(ESLVal.list(_v1181));
              }
              }
              }
              }
              }
              default: {ESLVal _0 = _v1168;
                
                return ESLVal.list();
              }
            }
            }
          }
        }).map(fs).flatten().flatten(),fv);
      }
      }
      }
    case "RecType": {ESLVal $2443 = _v1165.termRef(0);
        ESLVal $2442 = _v1165.termRef(1);
        ESLVal $2441 = _v1165.termRef(2);
        
        {ESLVal l = $2443;
        
        {ESLVal a = $2442;
        
        {ESLVal _v1177 = $2441;
        
        return filter.apply(new ESLVal(new Function(new ESLVal("fun411"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1178 = $args[0];
        {ESLVal _v1167 = _v1178;
              
              switch(_v1167.termName) {
              case "VarType": {ESLVal $2489 = _v1167.termRef(0);
                ESLVal $2488 = _v1167.termRef(1);
                
                {ESLVal _v1179 = $2489;
                
                {ESLVal n = $2488;
                
                return n.eql(a).not();
              }
              }
              }
              default: return error(new ESLVal("case error at Pos(80772,80820)").add(ESLVal.list(_v1167)));
            }
            }
          }
        }),typeFV1(_v1177,$nil)).add(fv);
      }
      }
      }
      }
    case "StrType": {ESLVal $2440 = _v1165.termRef(0);
        
        {ESLVal l = $2440;
        
        return fv;
      }
      }
    case "TableType": {ESLVal $2439 = _v1165.termRef(0);
        ESLVal $2438 = _v1165.termRef(1);
        ESLVal $2437 = _v1165.termRef(2);
        
        {ESLVal l = $2439;
        
        {ESLVal k = $2438;
        
        {ESLVal v = $2437;
        
        return typeFV1(k,typeFV1(v,fv));
      }
      }
      }
      }
    case "TypeClosure": {ESLVal $2436 = _v1165.termRef(0);
        
        {ESLVal f = $2436;
        
        return $nil;
      }
      }
    case "TermType": {ESLVal $2435 = _v1165.termRef(0);
        ESLVal $2434 = _v1165.termRef(1);
        ESLVal $2433 = _v1165.termRef(2);
        
        {ESLVal l = $2435;
        
        {ESLVal n = $2434;
        
        {ESLVal ts = $2433;
        
        return typesFV1(ts,fv);
      }
      }
      }
      }
    case "TypeFun": {ESLVal $2432 = _v1165.termRef(0);
        ESLVal $2431 = _v1165.termRef(1);
        ESLVal $2430 = _v1165.termRef(2);
        
        {ESLVal l = $2432;
        
        {ESLVal ns = $2431;
        
        {ESLVal _v1174 = $2430;
        
        return filter.apply(new ESLVal(new Function(new ESLVal("fun412"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1175 = $args[0];
        {ESLVal _v1166 = _v1175;
              
              switch(_v1166.termName) {
              case "VarType": {ESLVal $2487 = _v1166.termRef(0);
                ESLVal $2486 = _v1166.termRef(1);
                
                {ESLVal _v1176 = $2487;
                
                {ESLVal n = $2486;
                
                return member.apply(n,ns).not();
              }
              }
              }
              default: return error(new ESLVal("case error at Pos(81116,81176)").add(ESLVal.list(_v1166)));
            }
            }
          }
        }),typeFV1(_v1174,$nil)).add(fv);
      }
      }
      }
      }
    case "UnfoldType": {ESLVal $2429 = _v1165.termRef(0);
        ESLVal $2428 = _v1165.termRef(1);
        
        {ESLVal l = $2429;
        
        {ESLVal _v1173 = $2428;
        
        return typeFV1(_v1173,fv);
      }
      }
      }
    case "UnionType": {ESLVal $2427 = _v1165.termRef(0);
        ESLVal $2426 = _v1165.termRef(1);
        
        {ESLVal l = $2427;
        
        {ESLVal ts = $2426;
        
        return typesFV1(ts,fv);
      }
      }
      }
    case "VarType": {ESLVal $2425 = _v1165.termRef(0);
        ESLVal $2424 = _v1165.termRef(1);
        
        {ESLVal l = $2425;
        
        {ESLVal n = $2424;
        
        return fv.cons(t);
      }
      }
      }
    case "VoidType": {ESLVal $2423 = _v1165.termRef(0);
        
        {ESLVal l = $2423;
        
        return fv;
      }
      }
    case "UnionRef": {ESLVal $2422 = _v1165.termRef(0);
        ESLVal $2421 = _v1165.termRef(1);
        ESLVal $2420 = _v1165.termRef(2);
        
        {ESLVal l = $2422;
        
        {ESLVal _v1172 = $2421;
        
        {ESLVal n = $2420;
        
        return typeFV1(_v1172,fv);
      }
      }
      }
      }
      default: {ESLVal x = _v1165;
        
        return error(x);
      }
    }
    }
  }
  private static ESLVal typeFV1 = new ESLVal(new Function(new ESLVal("typeFV1"),null) { public ESLVal apply(ESLVal... args) { return typeFV1(args[0],args[1]); }});
private static ESLVal p0 = new ESLVal("Pos",$zero,$zero);
  private static ESLVal actType0 = new ESLVal("ActType",p0,ESLVal.list(),ESLVal.list());
  private static ESLVal contentType = new ESLVal("UnionType",p0,ESLVal.list(new ESLVal("TermType",p0,new ESLVal("RawText"),ESLVal.list(new ESLVal("StrType",p0))),new ESLVal("TermType",p0,new ESLVal("ESLSource"),ESLVal.list(new ESLVal("StrType",p0),new ESLVal("StrType",p0))),new ESLVal("TermType",p0,new ESLVal("JavaSource"),ESLVal.list(new ESLVal("StrType",p0),new ESLVal("StrType",p0),new ESLVal("StrType",p0)))));
  private static ESLVal editMessage = new ESLVal("MessageType",p0,ESLVal.list(new ESLVal("TermType",p0,new ESLVal("Edit"),ESLVal.list(contentType))));
  private static ESLVal env0 = ESLVal.list(new ESLVal("Map",new ESLVal("edb"),new ESLVal("ActType",p0,ESLVal.list(new ESLVal("Dec",p0,new ESLVal("button"),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("StrType",p0),new ESLVal("StrType",p0),new ESLVal("StrType",p0),new ESLVal("StrType",p0),new ESLVal("FunType",p0,ESLVal.list(),new ESLVal("VoidType",p0))),new ESLVal("VoidType",p0)),$null),new ESLVal("Dec",p0,new ESLVal("display"),new ESLVal("ForallType",p0,ESLVal.list(new ESLVal("T")),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("StrType",p0),new ESLVal("VarType",p0,new ESLVal("T"))),new ESLVal("VarType",p0,new ESLVal("T")))),$null)),ESLVal.list(editMessage))),new ESLVal("Map",new ESLVal("kill"),new ESLVal("ForallType",p0,ESLVal.list(new ESLVal("T")),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("VarType",p0,new ESLVal("T"))),new ESLVal("VoidType",p0)))),new ESLVal("Map",new ESLVal("print"),new ESLVal("ForallType",p0,ESLVal.list(new ESLVal("T")),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("VarType",p0,new ESLVal("T"))),new ESLVal("VoidType",p0)))),new ESLVal("Map",new ESLVal("parse"),new ESLVal("ForallType",p0,ESLVal.list(new ESLVal("T")),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("StrType",p0)),new ESLVal("VarType",p0,new ESLVal("T"))))),new ESLVal("Map",new ESLVal("random"),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("IntType",p0)),new ESLVal("IntType",p0))),new ESLVal("Map",new ESLVal("wait"),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("IntType",p0)),new ESLVal("VoidType",p0))),new ESLVal("Map",new ESLVal("stopAll"),new ESLVal("FunType",p0,ESLVal.list(),new ESLVal("VoidType",p0))),new ESLVal("Map",new ESLVal("isqrt"),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("IntType",p0)),new ESLVal("FloatType",p0))),new ESLVal("Map",new ESLVal("round"),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("FloatType",p0)),new ESLVal("IntType",p0))),new ESLVal("Map",new ESLVal("builtin"),new ESLVal("ForallType",p0,ESLVal.list(new ESLVal("T")),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("StrType",p0),new ESLVal("StrType",p0),new ESLVal("IntType",p0)),new ESLVal("VarType",p0,new ESLVal("T"))))));
  private static ESLVal cnstrEnv0 = ESLVal.list(new ESLVal("Map",new ESLVal("Time"),new ESLVal("UnionType",p0,ESLVal.list(new ESLVal("TermType",p0,new ESLVal("Time"),ESLVal.list(new ESLVal("IntType",p0)))))));
  private static ESLVal tenv0 = ESLVal.list(new ESLVal("Map",new ESLVal("EditType"),contentType),new ESLVal("Map",new ESLVal("Time"),new ESLVal("UnionType",p0,ESLVal.list(new ESLVal("TermType",p0,new ESLVal("Time"),ESLVal.list(new ESLVal("IntType",p0)))))),new ESLVal("Map",new ESLVal("Point"),new ESLVal("UnionType",p0,ESLVal.list(new ESLVal("TermType",p0,new ESLVal("Point"),ESLVal.list(new ESLVal("IntType",p0),new ESLVal("IntType",p0)))))));
  public static ESLVal main = new ESLVal(new Function(new ESLVal("main"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      return new ESLVal(new BehaviourAdapter(false,getSelf(),new ESLVal("main")) {
          
          public ESLVal handle(ESLVal $m) {{ESLVal _v1171 = $m;
            
            return error(new ESLVal("case error at Pos(0,0)").add(ESLVal.list(_v1171)));
          }}
          public ESLVal get(String name) {
            switch(name) {
              
              default: throw new Error("ref illegal " + self + "." + name);
            }
          }
        public void handleTime(ESLVal $t) {
          {}
        }
        public ESLVal init() {
            return ((Supplier<ESLVal>)() -> { 
                {new Function(new ESLVal("try"),getSelf()) {
                  public ESLVal apply(ESLVal... args) { 
                    try { 
                      return typeCheckModule(new ESLVal("esl/compiler/test1.esl"));
                    } catch(ESLError $exception) {
                      ESLVal $x = $exception.value;
                      {ESLVal _v1170 = $x;
                  
                  {ESLVal message = _v1170;
                  
                  return print.apply(new ESLVal("Type Error: ").add(message));
                }
                }
                    }
                  }
                }.apply();
                print.apply(new ESLVal("DONE"));
                return stopAll.apply();}
              }).get();
          }
        });
    }
  });
public static void main(String[] args) {
    newActor(main,new ESLVal(new Actor())); 
  }
}