package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
import static esl.compiler.Types.*;
// import static esl.Lists.*;
import java.util.function.Supplier;
public class FV {
  public static ESLVal getSelf() { return $null; }
  private static ESLVal remStr(ESLVal s,ESLVal ss) {
    
    return remove.apply(s,ss);
  }
  private static ESLVal remStr = new ESLVal(new Function(new ESLVal("remStr"),null) { public ESLVal apply(ESLVal... args) { return remStr(args[0],args[1]); }});
  private static ESLVal remStrs(ESLVal ss1,ESLVal ss2) {
    
    return removeAll.apply(ss1,ss2);
  }
  private static ESLVal remStrs = new ESLVal(new Function(new ESLVal("remStrs"),null) { public ESLVal apply(ESLVal... args) { return remStrs(args[0],args[1]); }});
  public static ESLVal bindingFV(ESLVal b) {
    
    {ESLVal _v1682 = b;
      
      switch(_v1682.termName) {
      case "TypeBind": {ESLVal $2811 = _v1682.termRef(0);
        ESLVal $2810 = _v1682.termRef(1);
        ESLVal $2809 = _v1682.termRef(2);
        ESLVal $2808 = _v1682.termRef(3);
        
        {ESLVal v0 = $2811;
        
        {ESLVal v1 = $2810;
        
        {ESLVal v2 = $2809;
        
        {ESLVal v3 = $2808;
        
        return ESLVal.list();
      }
      }
      }
      }
      }
    case "CnstrBind": {ESLVal $2807 = _v1682.termRef(0);
        ESLVal $2806 = _v1682.termRef(1);
        ESLVal $2805 = _v1682.termRef(2);
        ESLVal $2804 = _v1682.termRef(3);
        
        {ESLVal v0 = $2807;
        
        {ESLVal v1 = $2806;
        
        {ESLVal v2 = $2805;
        
        {ESLVal v3 = $2804;
        
        return ESLVal.list();
      }
      }
      }
      }
      }
    case "FunBind": {ESLVal $2803 = _v1682.termRef(0);
        ESLVal $2802 = _v1682.termRef(1);
        ESLVal $2801 = _v1682.termRef(2);
        ESLVal $2800 = _v1682.termRef(3);
        ESLVal $2799 = _v1682.termRef(4);
        ESLVal $2798 = _v1682.termRef(5);
        ESLVal $2797 = _v1682.termRef(6);
        
        {ESLVal v0 = $2803;
        
        {ESLVal v1 = $2802;
        
        {ESLVal v2 = $2801;
        
        {ESLVal v3 = $2800;
        
        {ESLVal v4 = $2799;
        
        {ESLVal body = $2798;
        
        {ESLVal guard = $2797;
        
        return remStrs(new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal p = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = patternNames.apply(p);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v2),freeVars(body));
      }
      }
      }
      }
      }
      }
      }
      }
    case "FunBinds": {ESLVal $2789 = _v1682.termRef(0);
        ESLVal $2788 = _v1682.termRef(1);
        
        if($2788.isCons())
        {ESLVal $2790 = $2788.head();
          ESLVal $2791 = $2788.tail();
          
          switch($2790.termName) {
          case "FunCase": {ESLVal $2796 = $2790.termRef(0);
            ESLVal $2795 = $2790.termRef(1);
            ESLVal $2794 = $2790.termRef(2);
            ESLVal $2793 = $2790.termRef(3);
            ESLVal $2792 = $2790.termRef(4);
            
            {ESLVal n = $2789;
            
            {ESLVal l = $2796;
            
            {ESLVal args = $2795;
            
            {ESLVal t = $2794;
            
            {ESLVal g = $2793;
            
            {ESLVal e = $2792;
            
            {ESLVal cases = $2791;
            
            return ESLVal.list();
          }
          }
          }
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(230,815)").add(ESLVal.list(_v1682)));
        }
        }
      else if($2788.isNil())
        return error(new ESLVal("case error at Pos(230,815)").add(ESLVal.list(_v1682)));
      else return error(new ESLVal("case error at Pos(230,815)").add(ESLVal.list(_v1682)));
      }
    case "Binding": {ESLVal $2787 = _v1682.termRef(0);
        ESLVal $2786 = _v1682.termRef(1);
        ESLVal $2785 = _v1682.termRef(2);
        ESLVal $2784 = _v1682.termRef(3);
        ESLVal $2783 = _v1682.termRef(4);
        
        {ESLVal v0 = $2787;
        
        {ESLVal v1 = $2786;
        
        {ESLVal v2 = $2785;
        
        {ESLVal v3 = $2784;
        
        {ESLVal v4 = $2783;
        
        return freeVars(v4);
      }
      }
      }
      }
      }
      }
    case "DataBind": {ESLVal $2782 = _v1682.termRef(0);
        ESLVal $2781 = _v1682.termRef(1);
        ESLVal $2780 = _v1682.termRef(2);
        ESLVal $2779 = _v1682.termRef(3);
        
        {ESLVal v0 = $2782;
        
        {ESLVal v1 = $2781;
        
        {ESLVal v2 = $2780;
        
        {ESLVal v3 = $2779;
        
        return ESLVal.list();
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(230,815)").add(ESLVal.list(_v1682)));
    }
    }
  }
  public static ESLVal bindingFV = new ESLVal(new Function(new ESLVal("bindingFV"),null) { public ESLVal apply(ESLVal... args) { return bindingFV(args[0]); }});
  private static ESLVal armFV(ESLVal a) {
    
    {ESLVal _v1683 = a;
      
      switch(_v1683.termName) {
      case "BArm": {ESLVal $2815 = _v1683.termRef(0);
        ESLVal $2814 = _v1683.termRef(1);
        ESLVal $2813 = _v1683.termRef(2);
        ESLVal $2812 = _v1683.termRef(3);
        
        {ESLVal l = $2815;
        
        {ESLVal ps = $2814;
        
        {ESLVal g = $2813;
        
        {ESLVal e = $2812;
        
        {ESLVal bound = new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal p = $l0.head();
                $l0 = $l0.tail();
                ESLVal $l1 = patternNames.apply(p);
          while(!$l1.isNil()) {
            ESLVal n = $l1.head();
            $l1 = $l1.tail();
            $v.add(n);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(ps);
        
        return remStrs(bound,freeVars(g).add(freeVars(e)));
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(842,993)").add(ESLVal.list(_v1683)));
    }
    }
  }
  private static ESLVal armFV = new ESLVal(new Function(new ESLVal("armFV"),null) { public ESLVal apply(ESLVal... args) { return armFV(args[0]); }});
  public static ESLVal freeVars(ESLVal e) {
    
    {ESLVal _v1684 = e;
      
      switch(_v1684.termName) {
      case "ActExp": {ESLVal $2967 = _v1684.termRef(0);
        ESLVal $2966 = _v1684.termRef(1);
        ESLVal $2965 = _v1684.termRef(2);
        ESLVal $2964 = _v1684.termRef(3);
        ESLVal $2963 = _v1684.termRef(4);
        ESLVal $2962 = _v1684.termRef(5);
        ESLVal $2961 = _v1684.termRef(6);
        ESLVal $2960 = _v1684.termRef(7);
        
        {ESLVal l = $2967;
        
        {ESLVal name = $2966;
        
        {ESLVal args = $2965;
        
        {ESLVal exports = $2964;
        
        {ESLVal parent = $2963;
        
        {ESLVal bindings = $2962;
        
        {ESLVal init = $2961;
        
        {ESLVal handlers = $2960;
        
        {ESLVal outerBoundVars = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1687 = $qualArg;
                
                switch(_v1687.termName) {
                case "Dec": {ESLVal $2977 = _v1687.termRef(0);
                  ESLVal $2976 = _v1687.termRef(1);
                  ESLVal $2975 = _v1687.termRef(2);
                  ESLVal $2974 = _v1687.termRef(3);
                  
                  {ESLVal _v1692 = $2977;
                  
                  {ESLVal n = $2976;
                  
                  {ESLVal t = $2975;
                  
                  {ESLVal dt = $2974;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                }
                default: {ESLVal _0 = _v1687;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(args).flatten().flatten();
        ESLVal innerBoundVars = new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal b = $l0.head();
                $l0 = $l0.tail();
                $v.add(bindingName.apply(b));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(bindings);
        ESLVal bindingFV = new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal b = $l0.head();
                $l0 = $l0.tail();
                ESLVal $l1 = bindingFV(b);
          while(!$l1.isNil()) {
            ESLVal n = $l1.head();
            $l1 = $l1.tail();
            $v.add(n);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(bindings);
        ESLVal handlerFV = new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal a = $l0.head();
                $l0 = $l0.tail();
                ESLVal $l1 = armFV(a);
          while(!$l1.isNil()) {
            ESLVal n = $l1.head();
            $l1 = $l1.tail();
            $v.add(n);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(handlers);
        ESLVal parentFV = ((Supplier<ESLVal>)() -> { 
            if(parent.eql($null).boolVal)
              return ESLVal.list();
              else
                return freeVars(parent);
          }).get();
        
        return remStrs(outerBoundVars,freeVars(name).add(parentFV.add(freeVars(init)))).add(remStrs(outerBoundVars.add(innerBoundVars),bindingFV.add(handlerFV)));
      }
      }
      }
      }
      }
      }
      }
      }
      }
      }
    case "Apply": {ESLVal $2959 = _v1684.termRef(0);
        ESLVal $2958 = _v1684.termRef(1);
        ESLVal $2957 = _v1684.termRef(2);
        
        {ESLVal v0 = $2959;
        
        {ESLVal v1 = $2958;
        
        {ESLVal v2 = $2957;
        
        return freeVars(v1).add(new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = freeVars(e);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v2));
      }
      }
      }
      }
    case "ApplyTypeExp": {ESLVal $2956 = _v1684.termRef(0);
        ESLVal $2955 = _v1684.termRef(1);
        ESLVal $2954 = _v1684.termRef(2);
        
        {ESLVal v0 = $2956;
        
        {ESLVal v1 = $2955;
        
        {ESLVal v2 = $2954;
        
        return freeVars(v1);
      }
      }
      }
      }
    case "ArrayRef": {ESLVal $2953 = _v1684.termRef(0);
        ESLVal $2952 = _v1684.termRef(1);
        ESLVal $2951 = _v1684.termRef(2);
        
        {ESLVal v0 = $2953;
        
        {ESLVal v1 = $2952;
        
        {ESLVal v2 = $2951;
        
        return freeVars(v1).add(freeVars(v2));
      }
      }
      }
      }
    case "ArrayUpdate": {ESLVal $2950 = _v1684.termRef(0);
        ESLVal $2949 = _v1684.termRef(1);
        ESLVal $2948 = _v1684.termRef(2);
        ESLVal $2947 = _v1684.termRef(3);
        
        {ESLVal v0 = $2950;
        
        {ESLVal v1 = $2949;
        
        {ESLVal v2 = $2948;
        
        {ESLVal v3 = $2947;
        
        return freeVars(v1).add(freeVars(v2).add(freeVars(v3)));
      }
      }
      }
      }
      }
    case "BagExp": {ESLVal $2946 = _v1684.termRef(0);
        ESLVal $2945 = _v1684.termRef(1);
        
        {ESLVal v0 = $2946;
        
        {ESLVal v1 = $2945;
        
        return new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = freeVars(e);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1);
      }
      }
      }
    case "Become": {ESLVal $2944 = _v1684.termRef(0);
        ESLVal $2943 = _v1684.termRef(1);
        
        {ESLVal v0 = $2944;
        
        {ESLVal v1 = $2943;
        
        return freeVars(v1);
      }
      }
      }
    case "BinExp": {ESLVal $2942 = _v1684.termRef(0);
        ESLVal $2941 = _v1684.termRef(1);
        ESLVal $2940 = _v1684.termRef(2);
        ESLVal $2939 = _v1684.termRef(3);
        
        {ESLVal v0 = $2942;
        
        {ESLVal v1 = $2941;
        
        {ESLVal v2 = $2940;
        
        {ESLVal v3 = $2939;
        
        return freeVars(v1).add(freeVars(v3));
      }
      }
      }
      }
      }
    case "Block": {ESLVal $2938 = _v1684.termRef(0);
        ESLVal $2937 = _v1684.termRef(1);
        
        {ESLVal v0 = $2938;
        
        {ESLVal v1 = $2937;
        
        return new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = freeVars(e);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1);
      }
      }
      }
    case "BoolExp": {ESLVal $2936 = _v1684.termRef(0);
        ESLVal $2935 = _v1684.termRef(1);
        
        {ESLVal v0 = $2936;
        
        {ESLVal v1 = $2935;
        
        return ESLVal.list();
      }
      }
      }
    case "Case": {ESLVal $2934 = _v1684.termRef(0);
        ESLVal $2933 = _v1684.termRef(1);
        ESLVal $2932 = _v1684.termRef(2);
        ESLVal $2931 = _v1684.termRef(3);
        
        {ESLVal v0 = $2934;
        
        {ESLVal v1 = $2933;
        
        {ESLVal v2 = $2932;
        
        {ESLVal v3 = $2931;
        
        return new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = freeVars(e);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v2).add(new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal a = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = armFV(a);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v3));
      }
      }
      }
      }
      }
    case "Cmp": {ESLVal $2923 = _v1684.termRef(0);
        ESLVal $2922 = _v1684.termRef(1);
        ESLVal $2921 = _v1684.termRef(2);
        
        if($2921.isCons())
        {ESLVal $2924 = $2921.head();
          ESLVal $2925 = $2921.tail();
          
          switch($2924.termName) {
          case "BQual": {ESLVal $2930 = $2924.termRef(0);
            ESLVal $2929 = $2924.termRef(1);
            ESLVal $2928 = $2924.termRef(2);
            
            {ESLVal l = $2923;
            
            {ESLVal _v1690 = $2922;
            
            {ESLVal ql = $2930;
            
            {ESLVal qp = $2929;
            
            {ESLVal qe = $2928;
            
            {ESLVal qs = $2925;
            
            return freeVars(qe).add(remStrs(patternNames.apply(qp),freeVars(new ESLVal("Cmp",l,_v1690,qs))));
          }
          }
          }
          }
          }
          }
          }
        case "PQual": {ESLVal $2927 = $2924.termRef(0);
            ESLVal $2926 = $2924.termRef(1);
            
            {ESLVal l = $2923;
            
            {ESLVal _v1689 = $2922;
            
            {ESLVal ql = $2927;
            
            {ESLVal qe = $2926;
            
            {ESLVal qs = $2925;
            
            return freeVars(qe).add(freeVars(new ESLVal("Cmp",l,_v1689,qs)));
          }
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(1025,6155)").add(ESLVal.list(_v1684)));
        }
        }
      else if($2921.isNil())
        {ESLVal l = $2923;
          
          {ESLVal _v1691 = $2922;
          
          return freeVars(_v1691);
        }
        }
      else return error(new ESLVal("case error at Pos(1025,6155)").add(ESLVal.list(_v1684)));
      }
    case "Cons": {ESLVal $2920 = _v1684.termRef(0);
        ESLVal $2919 = _v1684.termRef(1);
        
        {ESLVal v0 = $2920;
        
        {ESLVal v1 = $2919;
        
        return freeVars(v0).add(freeVars(v1));
      }
      }
      }
    case "For": {ESLVal $2918 = _v1684.termRef(0);
        ESLVal $2917 = _v1684.termRef(1);
        ESLVal $2916 = _v1684.termRef(2);
        ESLVal $2915 = _v1684.termRef(3);
        
        {ESLVal v0 = $2918;
        
        {ESLVal v1 = $2917;
        
        {ESLVal v2 = $2916;
        
        {ESLVal v3 = $2915;
        
        return freeVars(v2).add(remStrs(patternNames.apply(v1),freeVars(v3)));
      }
      }
      }
      }
      }
    case "FunExp": {ESLVal $2914 = _v1684.termRef(0);
        ESLVal $2913 = _v1684.termRef(1);
        ESLVal $2912 = _v1684.termRef(2);
        ESLVal $2911 = _v1684.termRef(3);
        ESLVal $2910 = _v1684.termRef(4);
        
        {ESLVal v0 = $2914;
        
        {ESLVal v1 = $2913;
        
        {ESLVal v2 = $2912;
        
        {ESLVal v3 = $2911;
        
        {ESLVal v4 = $2910;
        
        return remStrs(new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v1686 = $qualArg;
              
              switch(_v1686.termName) {
              case "Dec": {ESLVal $2973 = _v1686.termRef(0);
                ESLVal $2972 = _v1686.termRef(1);
                ESLVal $2971 = _v1686.termRef(2);
                ESLVal $2970 = _v1686.termRef(3);
                
                {ESLVal l = $2973;
                
                {ESLVal n = $2972;
                
                {ESLVal t = $2971;
                
                {ESLVal dt = $2970;
                
                return ESLVal.list(ESLVal.list(n));
              }
              }
              }
              }
              }
              default: {ESLVal _0 = _v1686;
                
                return ESLVal.list();
              }
            }
            }
          }
        }).map(v2).flatten().flatten(),freeVars(v1).add(freeVars(v4)));
      }
      }
      }
      }
      }
      }
    case "Grab": {ESLVal $2909 = _v1684.termRef(0);
        ESLVal $2908 = _v1684.termRef(1);
        ESLVal $2907 = _v1684.termRef(2);
        
        {ESLVal v0 = $2909;
        
        {ESLVal v1 = $2908;
        
        {ESLVal v2 = $2907;
        
        return new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v1685 = $qualArg;
              
              switch(_v1685.termName) {
              case "VarDynamicRef": {ESLVal $2969 = _v1685.termRef(0);
                ESLVal $2968 = _v1685.termRef(1);
                
                {ESLVal l = $2969;
                
                {ESLVal _v1688 = $2968;
                
                return ESLVal.list(new java.util.function.Function<ESLVal,ESLVal>() {
                  public ESLVal apply(ESLVal $l0) {
                    ESLVal $a = $nil;
                    java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                    while(!$l0.isNil()) { 
                      ESLVal n = $l0.head();
                      $l0 = $l0.tail();
                      $v.add(n);
                    }
                    for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                    return $a;
                  }}.apply(freeVars(_v1688)));
              }
              }
              }
              default: {ESLVal _0 = _v1685;
                
                return ESLVal.list();
              }
            }
            }
          }
        }).map(v1).flatten().flatten().add(freeVars(v2));
      }
      }
      }
      }
    case "If": {ESLVal $2906 = _v1684.termRef(0);
        ESLVal $2905 = _v1684.termRef(1);
        ESLVal $2904 = _v1684.termRef(2);
        ESLVal $2903 = _v1684.termRef(3);
        
        {ESLVal v0 = $2906;
        
        {ESLVal v1 = $2905;
        
        {ESLVal v2 = $2904;
        
        {ESLVal v3 = $2903;
        
        return freeVars(v1).add(freeVars(v2).add(freeVars(v3)));
      }
      }
      }
      }
      }
    case "IntExp": {ESLVal $2902 = _v1684.termRef(0);
        ESLVal $2901 = _v1684.termRef(1);
        
        {ESLVal v0 = $2902;
        
        {ESLVal v1 = $2901;
        
        return ESLVal.list();
      }
      }
      }
    case "FloatExp": {ESLVal $2900 = _v1684.termRef(0);
        ESLVal $2899 = _v1684.termRef(1);
        
        {ESLVal v0 = $2900;
        
        {ESLVal v1 = $2899;
        
        return ESLVal.list();
      }
      }
      }
    case "Fold": {ESLVal $2898 = _v1684.termRef(0);
        ESLVal $2897 = _v1684.termRef(1);
        ESLVal $2896 = _v1684.termRef(2);
        
        {ESLVal v0 = $2898;
        
        {ESLVal v1 = $2897;
        
        {ESLVal v2 = $2896;
        
        return freeVars(v2);
      }
      }
      }
      }
    case "Head": {ESLVal $2895 = _v1684.termRef(0);
        
        {ESLVal v0 = $2895;
        
        return freeVars(v0);
      }
      }
    case "Let": {ESLVal $2894 = _v1684.termRef(0);
        ESLVal $2893 = _v1684.termRef(1);
        ESLVal $2892 = _v1684.termRef(2);
        
        {ESLVal v0 = $2894;
        
        {ESLVal v1 = $2893;
        
        {ESLVal v2 = $2892;
        
        return new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = bindingFV(b);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1).add(remStrs(new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              $v.add(bindingName.apply(b));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1),freeVars(v2)));
      }
      }
      }
      }
    case "Letrec": {ESLVal $2891 = _v1684.termRef(0);
        ESLVal $2890 = _v1684.termRef(1);
        ESLVal $2889 = _v1684.termRef(2);
        
        {ESLVal v0 = $2891;
        
        {ESLVal v1 = $2890;
        
        {ESLVal v2 = $2889;
        
        return remStrs(new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              $v.add(bindingName.apply(b));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = bindingFV(b);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1).add(freeVars(v2)));
      }
      }
      }
      }
    case "List": {ESLVal $2888 = _v1684.termRef(0);
        ESLVal $2887 = _v1684.termRef(1);
        
        {ESLVal v0 = $2888;
        
        {ESLVal v1 = $2887;
        
        return new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = freeVars(e);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1);
      }
      }
      }
    case "Module": {ESLVal $2886 = _v1684.termRef(0);
        ESLVal $2885 = _v1684.termRef(1);
        ESLVal $2884 = _v1684.termRef(2);
        ESLVal $2883 = _v1684.termRef(3);
        ESLVal $2882 = _v1684.termRef(4);
        ESLVal $2881 = _v1684.termRef(5);
        ESLVal $2880 = _v1684.termRef(6);
        
        {ESLVal v0 = $2886;
        
        {ESLVal v1 = $2885;
        
        {ESLVal v2 = $2884;
        
        {ESLVal v3 = $2883;
        
        {ESLVal v4 = $2882;
        
        {ESLVal v5 = $2881;
        
        {ESLVal v6 = $2880;
        
        return remStrs(new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              $v.add(bindingName.apply(b));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v6),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = bindingFV(b);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v6));
      }
      }
      }
      }
      }
      }
      }
      }
    case "New": {ESLVal $2879 = _v1684.termRef(0);
        ESLVal $2878 = _v1684.termRef(1);
        ESLVal $2877 = _v1684.termRef(2);
        
        {ESLVal v0 = $2879;
        
        {ESLVal v1 = $2878;
        
        {ESLVal v2 = $2877;
        
        return freeVars(v1).add(new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = freeVars(e);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v2));
      }
      }
      }
      }
    case "NewArray": {ESLVal $2876 = _v1684.termRef(0);
        ESLVal $2875 = _v1684.termRef(1);
        ESLVal $2874 = _v1684.termRef(2);
        
        {ESLVal v0 = $2876;
        
        {ESLVal v1 = $2875;
        
        {ESLVal v2 = $2874;
        
        return freeVars(v2);
      }
      }
      }
      }
    case "NewJava": {ESLVal $2873 = _v1684.termRef(0);
        ESLVal $2872 = _v1684.termRef(1);
        ESLVal $2871 = _v1684.termRef(2);
        ESLVal $2870 = _v1684.termRef(3);
        
        {ESLVal v0 = $2873;
        
        {ESLVal v1 = $2872;
        
        {ESLVal v2 = $2871;
        
        {ESLVal v3 = $2870;
        
        return new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = freeVars(e);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v3);
      }
      }
      }
      }
      }
    case "NewTable": {ESLVal $2869 = _v1684.termRef(0);
        ESLVal $2868 = _v1684.termRef(1);
        ESLVal $2867 = _v1684.termRef(2);
        
        {ESLVal v0 = $2869;
        
        {ESLVal v1 = $2868;
        
        {ESLVal v2 = $2867;
        
        return ESLVal.list();
      }
      }
      }
      }
    case "Not": {ESLVal $2866 = _v1684.termRef(0);
        ESLVal $2865 = _v1684.termRef(1);
        
        {ESLVal v0 = $2866;
        
        {ESLVal v1 = $2865;
        
        return freeVars(v1);
      }
      }
      }
    case "Now": {ESLVal $2864 = _v1684.termRef(0);
        
        {ESLVal v0 = $2864;
        
        return ESLVal.list();
      }
      }
    case "NullExp": {ESLVal $2863 = _v1684.termRef(0);
        
        {ESLVal v0 = $2863;
        
        return ESLVal.list();
      }
      }
    case "PLet": {ESLVal $2862 = _v1684.termRef(0);
        ESLVal $2861 = _v1684.termRef(1);
        ESLVal $2860 = _v1684.termRef(2);
        
        {ESLVal v0 = $2862;
        
        {ESLVal v1 = $2861;
        
        {ESLVal v2 = $2860;
        
        return new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = bindingFV(b);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1).add(remStrs(new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              $v.add(bindingName.apply(b));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1),freeVars(v2)));
      }
      }
      }
      }
    case "Probably": {ESLVal $2859 = _v1684.termRef(0);
        ESLVal $2858 = _v1684.termRef(1);
        ESLVal $2857 = _v1684.termRef(2);
        ESLVal $2856 = _v1684.termRef(3);
        ESLVal $2855 = _v1684.termRef(4);
        
        {ESLVal v0 = $2859;
        
        {ESLVal v1 = $2858;
        
        {ESLVal v2 = $2857;
        
        {ESLVal v3 = $2856;
        
        {ESLVal v4 = $2855;
        
        return freeVars(v1).add(freeVars(v3).add(freeVars(v4)));
      }
      }
      }
      }
      }
      }
    case "Record": {ESLVal $2854 = _v1684.termRef(0);
        ESLVal $2853 = _v1684.termRef(1);
        
        {ESLVal v0 = $2854;
        
        {ESLVal v1 = $2853;
        
        return new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = bindingFV(b);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1);
      }
      }
      }
    case "RefSuper": {ESLVal $2852 = _v1684.termRef(0);
        ESLVal $2851 = _v1684.termRef(1);
        
        {ESLVal v0 = $2852;
        
        {ESLVal v1 = $2851;
        
        return ESLVal.list();
      }
      }
      }
    case "Ref": {ESLVal $2850 = _v1684.termRef(0);
        ESLVal $2849 = _v1684.termRef(1);
        ESLVal $2848 = _v1684.termRef(2);
        
        {ESLVal v0 = $2850;
        
        {ESLVal v1 = $2849;
        
        {ESLVal v2 = $2848;
        
        return freeVars(v1);
      }
      }
      }
      }
    case "Self": {ESLVal $2847 = _v1684.termRef(0);
        
        {ESLVal v0 = $2847;
        
        return ESLVal.list();
      }
      }
    case "Send": {ESLVal $2846 = _v1684.termRef(0);
        ESLVal $2845 = _v1684.termRef(1);
        ESLVal $2844 = _v1684.termRef(2);
        
        {ESLVal v0 = $2846;
        
        {ESLVal v1 = $2845;
        
        {ESLVal v2 = $2844;
        
        return freeVars(v1).add(freeVars(v2));
      }
      }
      }
      }
    case "SendSuper": {ESLVal $2843 = _v1684.termRef(0);
        ESLVal $2842 = _v1684.termRef(1);
        
        {ESLVal v0 = $2843;
        
        {ESLVal v1 = $2842;
        
        return freeVars(v1);
      }
      }
      }
    case "SendTimeSuper": {ESLVal $2841 = _v1684.termRef(0);
        
        {ESLVal v0 = $2841;
        
        return ESLVal.list();
      }
      }
    case "SetExp": {ESLVal $2840 = _v1684.termRef(0);
        ESLVal $2839 = _v1684.termRef(1);
        
        {ESLVal v0 = $2840;
        
        {ESLVal v1 = $2839;
        
        return new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = freeVars(e);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1);
      }
      }
      }
    case "StrExp": {ESLVal $2838 = _v1684.termRef(0);
        ESLVal $2837 = _v1684.termRef(1);
        
        {ESLVal v0 = $2838;
        
        {ESLVal v1 = $2837;
        
        return ESLVal.list();
      }
      }
      }
    case "Tail": {ESLVal $2836 = _v1684.termRef(0);
        
        {ESLVal v0 = $2836;
        
        return freeVars(v0);
      }
      }
    case "Term": {ESLVal $2835 = _v1684.termRef(0);
        ESLVal $2834 = _v1684.termRef(1);
        ESLVal $2833 = _v1684.termRef(2);
        ESLVal $2832 = _v1684.termRef(3);
        
        {ESLVal v0 = $2835;
        
        {ESLVal v1 = $2834;
        
        {ESLVal v2 = $2833;
        
        {ESLVal v3 = $2832;
        
        return new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = freeVars(e);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v3);
      }
      }
      }
      }
      }
    case "TermRef": {ESLVal $2831 = _v1684.termRef(0);
        ESLVal $2830 = _v1684.termRef(1);
        
        {ESLVal v0 = $2831;
        
        {ESLVal v1 = $2830;
        
        return freeVars(v0);
      }
      }
      }
    case "Throw": {ESLVal $2829 = _v1684.termRef(0);
        ESLVal $2828 = _v1684.termRef(1);
        ESLVal $2827 = _v1684.termRef(2);
        
        {ESLVal v0 = $2829;
        
        {ESLVal v1 = $2828;
        
        {ESLVal v2 = $2827;
        
        return freeVars(v2);
      }
      }
      }
      }
    case "Try": {ESLVal $2826 = _v1684.termRef(0);
        ESLVal $2825 = _v1684.termRef(1);
        ESLVal $2824 = _v1684.termRef(2);
        
        {ESLVal v0 = $2826;
        
        {ESLVal v1 = $2825;
        
        {ESLVal v2 = $2824;
        
        return freeVars(v1).add(new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal a = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = armFV(a);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v2));
      }
      }
      }
      }
    case "Update": {ESLVal $2823 = _v1684.termRef(0);
        ESLVal $2822 = _v1684.termRef(1);
        ESLVal $2821 = _v1684.termRef(2);
        
        {ESLVal v0 = $2823;
        
        {ESLVal v1 = $2822;
        
        {ESLVal v2 = $2821;
        
        return ESLVal.list(v1).add(freeVars(v2));
      }
      }
      }
      }
    case "Unfold": {ESLVal $2820 = _v1684.termRef(0);
        ESLVal $2819 = _v1684.termRef(1);
        ESLVal $2818 = _v1684.termRef(2);
        
        {ESLVal v0 = $2820;
        
        {ESLVal v1 = $2819;
        
        {ESLVal v2 = $2818;
        
        return freeVars(v2);
      }
      }
      }
      }
    case "Var": {ESLVal $2817 = _v1684.termRef(0);
        ESLVal $2816 = _v1684.termRef(1);
        
        {ESLVal v0 = $2817;
        
        {ESLVal v1 = $2816;
        
        return ESLVal.list(v1);
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(1025,6155)").add(ESLVal.list(_v1684)));
    }
    }
  }
  public static ESLVal freeVars = new ESLVal(new Function(new ESLVal("freeVars"),null) { public ESLVal apply(ESLVal... args) { return freeVars(args[0]); }});

public static void main(String[] args) {
  }
}