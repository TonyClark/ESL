package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
// import static esl.Lists.*;
import static esl.compiler.Types.*;
import static esl.compiler.DynamicVars.*;
import static esl.compiler.Strings.*;
import java.util.function.Supplier;
public class PpExp {
  public static ESLVal getSelf() { return $null; }
  private static ESLVal indentStr(ESLVal indent) {
    
    if(indent.eql($zero).boolVal)
      return new ESLVal("");
      else
        return new ESLVal(" ").add(indentStr(indent.sub($one)));
  }
  private static ESLVal indentStr = new ESLVal(new Function(new ESLVal("indentStr"),null) { public ESLVal apply(ESLVal... args) { return indentStr(args[0]); }});
  private static ESLVal nl(ESLVal indent) {
    
    return new ESLVal("\n").add(indentStr(indent));
  }
  private static ESLVal nl = new ESLVal(new Function(new ESLVal("nl"),null) { public ESLVal apply(ESLVal... args) { return nl(args[0]); }});
  private static ESLVal ppJoin(ESLVal indent,ESLVal ss) {
    
    {ESLVal _v7 = ss;
      
      if(_v7.isCons())
      {ESLVal $8 = _v7.head();
        ESLVal $9 = _v7.tail();
        
        if($9.isCons())
        {ESLVal $10 = $9.head();
          ESLVal $11 = $9.tail();
          
          if($11.isCons())
          {ESLVal $12 = $11.head();
            ESLVal $13 = $11.tail();
            
            {ESLVal s = $8;
            
            {ESLVal _v132 = $9;
            
            return s.add(nl(indent).add(ppJoin(indent,_v132)));
          }
          }
          }
        else if($11.isNil())
          {ESLVal s1 = $8;
            
            {ESLVal s2 = $10;
            
            return s1.add(nl(indent).add(s2));
          }
          }
        else {ESLVal s = $8;
            
            {ESLVal _v133 = $9;
            
            return s.add(nl(indent).add(ppJoin(indent,_v133)));
          }
          }
        }
      else if($9.isNil())
        {ESLVal s = $8;
          
          return s;
        }
      else {ESLVal s = $8;
          
          {ESLVal _v134 = $9;
          
          return s.add(nl(indent).add(ppJoin(indent,_v134)));
        }
        }
      }
    else if(_v7.isNil())
      return new ESLVal("");
    else return error(new ESLVal("case error at Pos(1593,1751)").add(ESLVal.list(_v7)));
    }
  }
  private static ESLVal ppJoin = new ESLVal(new Function(new ESLVal("ppJoin"),null) { public ESLVal apply(ESLVal... args) { return ppJoin(args[0],args[1]); }});
  public static ESLVal ppTypeEnv(ESLVal env) {
    
    {ESLVal[] s = new ESLVal[]{new ESLVal("[")};
      
      {{
      ESLVal _v10 = env;
      while(_v10.isCons()) {
        ESLVal _v9 = _v10.headVal;
        {ESLVal _v8 = new ESLVal(new Function(new ESLVal("forp"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                {ESLVal _v11 = _v9;
                  
                  switch(_v11.termName) {
                  case "Map": {ESLVal $15 = _v11.termRef(0);
                    ESLVal $14 = _v11.termRef(1);
                    
                    {ESLVal n = $15;
                    
                    {ESLVal t = $14;
                    
                    {s[0] = s[0].add(n.add(new ESLVal("->").add(ppType(t).add(new ESLVal(",")))));
                  return $null;}
                  }
                  }
                  }
                  default: {ESLVal $$$ = _v11;
                    
                    return $null;
                  }
                }
                }
              }
            });
          
          _v8.apply();
        }
        _v10 = _v10.tailVal;}
    }
    return s[0].add(new ESLVal("]"));}
    }
  }
  public static ESLVal ppTypeEnv = new ESLVal(new Function(new ESLVal("ppTypeEnv"),null) { public ESLVal apply(ESLVal... args) { return ppTypeEnv(args[0]); }});
  public static ESLVal ppTypes(ESLVal ts) {
    
    return map.apply(ppType,ts);
  }
  public static ESLVal ppTypes = new ESLVal(new Function(new ESLVal("ppTypes"),null) { public ESLVal apply(ESLVal... args) { return ppTypes(args[0]); }});
  public static ESLVal ppType(ESLVal t) {
    
    {ESLVal _v12 = t;
      
      switch(_v12.termName) {
      case "ActType": {ESLVal $74 = _v12.termRef(0);
        ESLVal $73 = _v12.termRef(1);
        ESLVal $72 = _v12.termRef(2);
        
        {ESLVal l = $74;
        
        {ESLVal decs = $73;
        
        {ESLVal handlers = $72;
        
        return new ESLVal("").add(t);
      }
      }
      }
      }
    case "ApplyType": {ESLVal $71 = _v12.termRef(0);
        ESLVal $70 = _v12.termRef(1);
        ESLVal $69 = _v12.termRef(2);
        
        {ESLVal l = $71;
        
        {ESLVal n = $70;
        
        {ESLVal args = $69;
        
        return n.add(map.apply(ppType,args));
      }
      }
      }
      }
    case "ApplyTypeFun": {ESLVal $68 = _v12.termRef(0);
        ESLVal $67 = _v12.termRef(1);
        ESLVal $66 = _v12.termRef(2);
        
        {ESLVal l = $68;
        
        {ESLVal op = $67;
        
        {ESLVal args = $66;
        
        return ppType(op).add(map.apply(ppType,args));
      }
      }
      }
      }
    case "ArrayType": {ESLVal $65 = _v12.termRef(0);
        ESLVal $64 = _v12.termRef(1);
        
        {ESLVal l = $65;
        
        {ESLVal _v131 = $64;
        
        return new ESLVal("Array[").add(ppType(_v131).add(new ESLVal("]")));
      }
      }
      }
    case "BoolType": {ESLVal $63 = _v12.termRef(0);
        
        {ESLVal l = $63;
        
        return new ESLVal("Bool");
      }
      }
    case "FloatType": {ESLVal $62 = _v12.termRef(0);
        
        {ESLVal l = $62;
        
        return new ESLVal("Float");
      }
      }
    case "FieldType": {ESLVal $61 = _v12.termRef(0);
        ESLVal $60 = _v12.termRef(1);
        ESLVal $59 = _v12.termRef(2);
        
        {ESLVal l = $61;
        
        {ESLVal n = $60;
        
        {ESLVal _v130 = $59;
        
        return n.add(new ESLVal("::").add(ppType(_v130)));
      }
      }
      }
      }
    case "ForallType": {ESLVal $58 = _v12.termRef(0);
        ESLVal $57 = _v12.termRef(1);
        ESLVal $56 = _v12.termRef(2);
        
        {ESLVal l = $58;
        
        {ESLVal ns = $57;
        
        {ESLVal _v129 = $56;
        
        return new ESLVal("Forall").add(ns.add(new ESLVal(".").add(ppType(_v129))));
      }
      }
      }
      }
    case "FunType": {ESLVal $55 = _v12.termRef(0);
        ESLVal $54 = _v12.termRef(1);
        ESLVal $53 = _v12.termRef(2);
        
        {ESLVal l = $55;
        
        {ESLVal d = $54;
        
        {ESLVal r = $53;
        
        return map.apply(ppType,d).add(new ESLVal("->").add(ppType(r)));
      }
      }
      }
      }
    case "TaggedFunType": {ESLVal $52 = _v12.termRef(0);
        ESLVal $51 = _v12.termRef(1);
        ESLVal $50 = _v12.termRef(2);
        ESLVal $49 = _v12.termRef(3);
        
        {ESLVal l = $52;
        
        {ESLVal d = $51;
        
        {ESLVal p = $50;
        
        {ESLVal r = $49;
        
        return map.apply(ppType,d).add(new ESLVal("->").add(ppType(r)));
      }
      }
      }
      }
      }
    case "IntType": {ESLVal $48 = _v12.termRef(0);
        
        {ESLVal l = $48;
        
        return new ESLVal("Int");
      }
      }
    case "ListType": {ESLVal $47 = _v12.termRef(0);
        ESLVal $46 = _v12.termRef(1);
        
        {ESLVal l = $47;
        
        {ESLVal _v128 = $46;
        
        return new ESLVal("[").add(ppType(_v128).add(new ESLVal("]")));
      }
      }
      }
    case "NullType": {ESLVal $45 = _v12.termRef(0);
        
        {ESLVal l = $45;
        
        return new ESLVal("Null");
      }
      }
    case "ObserverType": {ESLVal $44 = _v12.termRef(0);
        ESLVal $43 = _v12.termRef(1);
        ESLVal $42 = _v12.termRef(2);
        
        {ESLVal l = $44;
        
        {ESLVal s = $43;
        
        {ESLVal m = $42;
        
        return new ESLVal("Observer[").add(ppType(s).add(new ESLVal(",").add(ppType(m).add(new ESLVal("]")))));
      }
      }
      }
      }
    case "RecType": {ESLVal $41 = _v12.termRef(0);
        ESLVal $40 = _v12.termRef(1);
        ESLVal $39 = _v12.termRef(2);
        
        {ESLVal l = $41;
        
        {ESLVal n = $40;
        
        {ESLVal _v127 = $39;
        
        return new ESLVal("rec ").add(n.add(new ESLVal(".").add(ppType(_v127))));
      }
      }
      }
      }
    case "RecordType": {ESLVal $38 = _v12.termRef(0);
        ESLVal $37 = _v12.termRef(1);
        
        {ESLVal l = $38;
        
        {ESLVal fs = $37;
        
        return new ESLVal("{").add(fs.add(new ESLVal("}")));
      }
      }
      }
    case "StrType": {ESLVal $36 = _v12.termRef(0);
        
        {ESLVal l = $36;
        
        return new ESLVal("Str");
      }
      }
    case "TableType": {ESLVal $35 = _v12.termRef(0);
        ESLVal $34 = _v12.termRef(1);
        ESLVal $33 = _v12.termRef(2);
        
        {ESLVal l = $35;
        
        {ESLVal k = $34;
        
        {ESLVal v = $33;
        
        return new ESLVal("Hash[").add(ppType(k).add(new ESLVal(",").add(ppType(v).add(new ESLVal("]")))));
      }
      }
      }
      }
    case "TermType": {ESLVal $32 = _v12.termRef(0);
        ESLVal $31 = _v12.termRef(1);
        ESLVal $30 = _v12.termRef(2);
        
        {ESLVal l = $32;
        
        {ESLVal n = $31;
        
        {ESLVal ts = $30;
        
        return n.add(map.apply(ppType,ts));
      }
      }
      }
      }
    case "TypeFun": {ESLVal $29 = _v12.termRef(0);
        ESLVal $28 = _v12.termRef(1);
        ESLVal $27 = _v12.termRef(2);
        
        {ESLVal l = $29;
        
        {ESLVal ns = $28;
        
        {ESLVal _v126 = $27;
        
        return new ESLVal("Fun").add(ns.add(new ESLVal(".").add(ppType(_v126))));
      }
      }
      }
      }
    case "UnfoldType": {ESLVal $26 = _v12.termRef(0);
        ESLVal $25 = _v12.termRef(1);
        
        {ESLVal l = $26;
        
        {ESLVal _v125 = $25;
        
        return new ESLVal("unfold ").add(ppType(_v125));
      }
      }
      }
    case "UnionType": {ESLVal $24 = _v12.termRef(0);
        ESLVal $23 = _v12.termRef(1);
        
        {ESLVal l = $24;
        
        {ESLVal ts = $23;
        
        return new ESLVal("union ").add(map.apply(ppType,ts));
      }
      }
      }
    case "VarType": {ESLVal $22 = _v12.termRef(0);
        ESLVal $21 = _v12.termRef(1);
        
        {ESLVal l = $22;
        
        {ESLVal n = $21;
        
        return n;
      }
      }
      }
    case "VoidType": {ESLVal $20 = _v12.termRef(0);
        
        {ESLVal l = $20;
        
        return new ESLVal("Void");
      }
      }
    case "UnionRef": {ESLVal $19 = _v12.termRef(0);
        ESLVal $18 = _v12.termRef(1);
        ESLVal $17 = _v12.termRef(2);
        
        {ESLVal l = $19;
        
        {ESLVal _v124 = $18;
        
        {ESLVal n = $17;
        
        return ppType(_v124).add(new ESLVal(".").add(n));
      }
      }
      }
      }
    case "TypeClosure": {ESLVal $16 = _v12.termRef(0);
        
        {ESLVal f = $16;
        
        return f.add(new ESLVal(""));
      }
      }
      default: {ESLVal x = _v12;
        
        return new ESLVal("<unknown ").add(x.add(new ESLVal(">")));
      }
    }
    }
  }
  public static ESLVal ppType = new ESLVal(new Function(new ESLVal("ppType"),null) { public ESLVal apply(ESLVal... args) { return ppType(args[0]); }});
  public static ESLVal ppExps(ESLVal indent,ESLVal exps,ESLVal sep) {
    
    {ESLVal _v13 = exps;
      
      if(_v13.isCons())
      {ESLVal $75 = _v13.head();
        ESLVal $76 = _v13.tail();
        
        if($76.isCons())
        {ESLVal $77 = $76.head();
          ESLVal $78 = $76.tail();
          
          {ESLVal e1 = $75;
          
          {ESLVal e2 = $77;
          
          {ESLVal es = $78;
          
          return ppExp(indent,e1).add(sep.add(ppExps(indent,es.cons(e2),sep)));
        }
        }
        }
        }
      else if($76.isNil())
        {ESLVal e = $75;
          
          return ppExp(indent,e);
        }
      else return error(new ESLVal("case error at Pos(3657,3815)").add(ESLVal.list(_v13)));
      }
    else if(_v13.isNil())
      return new ESLVal("");
    else return error(new ESLVal("case error at Pos(3657,3815)").add(ESLVal.list(_v13)));
    }
  }
  public static ESLVal ppExps = new ESLVal(new Function(new ESLVal("ppExps"),null) { public ESLVal apply(ESLVal... args) { return ppExps(args[0],args[1],args[2]); }});
  private static ESLVal ppPattern(ESLVal p) {
    
    {ESLVal _v14 = p;
      
      switch(_v14.termName) {
      case "PVar": {ESLVal $100 = _v14.termRef(0);
        ESLVal $99 = _v14.termRef(1);
        ESLVal $98 = _v14.termRef(2);
        
        {ESLVal l = $100;
        
        {ESLVal n = $99;
        
        {ESLVal t = $98;
        
        return n;
      }
      }
      }
      }
    case "PTerm": {ESLVal $95 = _v14.termRef(0);
        ESLVal $94 = _v14.termRef(1);
        ESLVal $93 = _v14.termRef(2);
        ESLVal $92 = _v14.termRef(3);
        
        if($93.isCons())
        {ESLVal $96 = $93.head();
          ESLVal $97 = $93.tail();
          
          {ESLVal l = $95;
          
          {ESLVal n = $94;
          
          {ESLVal ts = $93;
          
          {ESLVal ps = $92;
          
          return n.add(ppPatterns(ps));
        }
        }
        }
        }
        }
      else if($93.isNil())
        {ESLVal l = $95;
          
          {ESLVal n = $94;
          
          {ESLVal ps = $92;
          
          return n.add(ppPatterns(ps));
        }
        }
        }
      else {ESLVal l = $95;
          
          {ESLVal n = $94;
          
          {ESLVal ts = $93;
          
          {ESLVal ps = $92;
          
          return n.add(ppPatterns(ps));
        }
        }
        }
        }
      }
    case "PApplyType": {ESLVal $91 = _v14.termRef(0);
        ESLVal $90 = _v14.termRef(1);
        ESLVal $89 = _v14.termRef(2);
        
        {ESLVal l = $91;
        
        {ESLVal _v122 = $90;
        
        {ESLVal ts = $89;
        
        return ppPattern(_v122);
      }
      }
      }
      }
    case "PNil": {ESLVal $88 = _v14.termRef(0);
        
        {ESLVal l = $88;
        
        return new ESLVal("[]");
      }
      }
    case "PInt": {ESLVal $87 = _v14.termRef(0);
        ESLVal $86 = _v14.termRef(1);
        
        {ESLVal l = $87;
        
        {ESLVal n = $86;
        
        return new ESLVal("").add(n);
      }
      }
      }
    case "PBool": {ESLVal $85 = _v14.termRef(0);
        ESLVal $84 = _v14.termRef(1);
        
        {ESLVal l = $85;
        
        {ESLVal b = $84;
        
        return new ESLVal("").add(b);
      }
      }
      }
    case "PStr": {ESLVal $83 = _v14.termRef(0);
        ESLVal $82 = _v14.termRef(1);
        
        {ESLVal l = $83;
        
        {ESLVal s = $82;
        
        return new ESLVal("\'").add(s.add(new ESLVal("\'")));
      }
      }
      }
    case "PCons": {ESLVal $81 = _v14.termRef(0);
        ESLVal $80 = _v14.termRef(1);
        ESLVal $79 = _v14.termRef(2);
        
        {ESLVal l = $81;
        
        {ESLVal h = $80;
        
        {ESLVal t = $79;
        
        return ppPattern(h).add(new ESLVal(":").add(ppPattern(t)));
      }
      }
      }
      }
      default: {ESLVal _v123 = _v14;
        
        return new ESLVal("<unknown: ").add(_v123.add(new ESLVal(">")));
      }
    }
    }
  }
  private static ESLVal ppPattern = new ESLVal(new Function(new ESLVal("ppPattern"),null) { public ESLVal apply(ESLVal... args) { return ppPattern(args[0]); }});
  private static ESLVal ppPatterns(ESLVal ps) {
    
    return map.apply(ppPattern,ps);
  }
  private static ESLVal ppPatterns = new ESLVal(new Function(new ESLVal("ppPatterns"),null) { public ESLVal apply(ESLVal... args) { return ppPatterns(args[0]); }});
  public static ESLVal ppExp(ESLVal indent,ESLVal exp) {
    
    {ESLVal _v15 = exp;
      
      switch(_v15.termName) {
      case "Module": {ESLVal $251 = _v15.termRef(0);
        ESLVal $250 = _v15.termRef(1);
        ESLVal $249 = _v15.termRef(2);
        ESLVal $248 = _v15.termRef(3);
        ESLVal $247 = _v15.termRef(4);
        ESLVal $246 = _v15.termRef(5);
        ESLVal $245 = _v15.termRef(6);
        
        {ESLVal path = $251;
        
        {ESLVal name = $250;
        
        {ESLVal exports = $249;
        
        {ESLVal imports = $248;
        
        {ESLVal x = $247;
        
        {ESLVal y = $246;
        
        {ESLVal defs = $245;
        
        return new ESLVal("module ").add(name.add(new ESLVal("{").add(nl(indent.add(new ESLVal(2))).add(ppBinds(indent.add(new ESLVal(2)),defs).add(nl(indent).add(new ESLVal("}")))))));
      }
      }
      }
      }
      }
      }
      }
      }
    case "Var": {ESLVal $244 = _v15.termRef(0);
        ESLVal $243 = _v15.termRef(1);
        
        {ESLVal l = $244;
        
        {ESLVal n = $243;
        
        return n;
      }
      }
      }
    case "StrExp": {ESLVal $242 = _v15.termRef(0);
        ESLVal $241 = _v15.termRef(1);
        
        {ESLVal l = $242;
        
        {ESLVal v = $241;
        
        return new ESLVal("\'").add(v.add(new ESLVal("\'")));
      }
      }
      }
    case "IntExp": {ESLVal $240 = _v15.termRef(0);
        ESLVal $239 = _v15.termRef(1);
        
        {ESLVal l = $240;
        
        {ESLVal v = $239;
        
        return v.add(new ESLVal(""));
      }
      }
      }
    case "BoolExp": {ESLVal $238 = _v15.termRef(0);
        ESLVal $237 = _v15.termRef(1);
        
        {ESLVal l = $238;
        
        {ESLVal v = $237;
        
        return v.add(new ESLVal(""));
      }
      }
      }
    case "NullExp": {ESLVal $236 = _v15.termRef(0);
        
        {ESLVal l = $236;
        
        return new ESLVal("null");
      }
      }
    case "FloatExp": {ESLVal $235 = _v15.termRef(0);
        ESLVal $234 = _v15.termRef(1);
        
        {ESLVal l = $235;
        
        {ESLVal f = $234;
        
        return f.add(new ESLVal(""));
      }
      }
      }
    case "Apply": {ESLVal $233 = _v15.termRef(0);
        ESLVal $232 = _v15.termRef(1);
        ESLVal $231 = _v15.termRef(2);
        
        {ESLVal l = $233;
        
        {ESLVal op = $232;
        
        {ESLVal args = $231;
        
        return ppExp(indent,op).add(new ESLVal("(").add(ppExps(indent,args,new ESLVal(",")).add(new ESLVal(")"))));
      }
      }
      }
      }
    case "ApplyTypeExp": {ESLVal $230 = _v15.termRef(0);
        ESLVal $229 = _v15.termRef(1);
        ESLVal $228 = _v15.termRef(2);
        
        {ESLVal l = $230;
        
        {ESLVal op = $229;
        
        {ESLVal args = $228;
        
        return ppExp(indent,op);
      }
      }
      }
      }
    case "Block": {ESLVal $227 = _v15.termRef(0);
        ESLVal $226 = _v15.termRef(1);
        
        {ESLVal l = $227;
        
        {ESLVal es = $226;
        
        return new ESLVal("{").add(nl(indent.add(new ESLVal(2))).add(ppExps(indent.add(new ESLVal(2)),es,new ESLVal(";")).add(nl(indent).add(new ESLVal("}")))));
      }
      }
      }
    case "Case": {ESLVal $225 = _v15.termRef(0);
        ESLVal $224 = _v15.termRef(1);
        ESLVal $223 = _v15.termRef(2);
        ESLVal $222 = _v15.termRef(3);
        
        {ESLVal l = $225;
        
        {ESLVal ds = $224;
        
        {ESLVal es = $223;
        
        {ESLVal as = $222;
        
        return new ESLVal("case ").add(ppExps(indent,es,new ESLVal(",")).add(new ESLVal(" {").add(nl(indent.add(new ESLVal(2))).add(ppJoin(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun304"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return ppArm(indent,a);
          }
        }),as)).add(nl(indent).add(new ESLVal("}")))))));
      }
      }
      }
      }
      }
    case "CaseTerm": {ESLVal $221 = _v15.termRef(0);
        ESLVal $220 = _v15.termRef(1);
        ESLVal $219 = _v15.termRef(2);
        ESLVal $218 = _v15.termRef(3);
        
        {ESLVal l = $221;
        
        {ESLVal e = $220;
        
        {ESLVal arms = $219;
        
        {ESLVal alt = $218;
        
        return new ESLVal("caseTerm ").add(ppExp(indent,e).add(new ESLVal(" {").add(nl(indent.add(new ESLVal(2))).add(ppJoin(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun305"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return ppCaseTermArm(indent.add(new ESLVal(2)),a);
          }
        }),arms)).add(nl(indent.add(new ESLVal(2))).add(new ESLVal("else ").add(ppExp(indent.add(new ESLVal(4)),alt).add(nl(indent).add(new ESLVal("}"))))))))));
      }
      }
      }
      }
      }
    case "CaseList": {ESLVal $217 = _v15.termRef(0);
        ESLVal $216 = _v15.termRef(1);
        ESLVal $215 = _v15.termRef(2);
        ESLVal $214 = _v15.termRef(3);
        ESLVal $213 = _v15.termRef(4);
        
        {ESLVal l = $217;
        
        {ESLVal e = $216;
        
        {ESLVal cons = $215;
        
        {ESLVal nil = $214;
        
        {ESLVal alt = $213;
        
        return new ESLVal("caseList ").add(ppExp(indent,e).add(new ESLVal(" {").add(nl(indent.add(new ESLVal(2))).add(new ESLVal("CONS ->").add(nl(indent.add(new ESLVal(4))).add(ppExp(indent.add(new ESLVal(4)),cons).add(nl(indent.add(new ESLVal(2))).add(new ESLVal("NIL ->").add(nl(indent.add(new ESLVal(4))).add(ppExp(indent.add(new ESLVal(4)),nil).add(nl(indent.add(new ESLVal(2))).add(new ESLVal("else ").add(ppExp(indent.add(new ESLVal(4)),alt).add(nl(indent).add(new ESLVal("}"))))))))))))))));
      }
      }
      }
      }
      }
      }
    case "CaseInt": {ESLVal $212 = _v15.termRef(0);
        ESLVal $211 = _v15.termRef(1);
        ESLVal $210 = _v15.termRef(2);
        ESLVal $209 = _v15.termRef(3);
        
        {ESLVal l = $212;
        
        {ESLVal e = $211;
        
        {ESLVal arms = $210;
        
        {ESLVal alt = $209;
        
        return new ESLVal("caseInt ").add(ppExp(indent,e).add(new ESLVal(" {").add(nl(indent.add(new ESLVal(2))).add(ppJoin(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun306"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return ppCaseIntsArm(indent.add(new ESLVal(2)),a);
          }
        }),arms)).add(nl(indent.add(new ESLVal(2))).add(new ESLVal("else ").add(ppExp(indent.add(new ESLVal(4)),alt).add(nl(indent).add(new ESLVal("}"))))))))));
      }
      }
      }
      }
      }
    case "CaseStr": {ESLVal $208 = _v15.termRef(0);
        ESLVal $207 = _v15.termRef(1);
        ESLVal $206 = _v15.termRef(2);
        ESLVal $205 = _v15.termRef(3);
        
        {ESLVal l = $208;
        
        {ESLVal e = $207;
        
        {ESLVal arms = $206;
        
        {ESLVal alt = $205;
        
        return new ESLVal("caseStr ").add(ppExp(indent,e).add(new ESLVal(" {").add(nl(indent.add(new ESLVal(2))).add(ppJoin(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun307"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return ppCaseStrsArm(indent.add(new ESLVal(2)),a);
          }
        }),arms)).add(nl(indent.add(new ESLVal(2))).add(new ESLVal("else ").add(ppExp(indent.add(new ESLVal(4)),alt).add(nl(indent).add(new ESLVal("}"))))))))));
      }
      }
      }
      }
      }
    case "CaseBool": {ESLVal $204 = _v15.termRef(0);
        ESLVal $203 = _v15.termRef(1);
        ESLVal $202 = _v15.termRef(2);
        ESLVal $201 = _v15.termRef(3);
        
        {ESLVal l = $204;
        
        {ESLVal e = $203;
        
        {ESLVal arms = $202;
        
        {ESLVal alt = $201;
        
        return new ESLVal("caseBool ").add(ppExp(indent,e).add(new ESLVal(" {").add(nl(indent.add(new ESLVal(2))).add(ppJoin(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun308"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return ppCaseBoolsArm(indent.add(new ESLVal(2)),a);
          }
        }),arms)).add(nl(indent.add(new ESLVal(2))).add(new ESLVal("else ").add(ppExp(indent.add(new ESLVal(4)),alt).add(nl(indent).add(new ESLVal("}"))))))))));
      }
      }
      }
      }
      }
    case "CaseError": {ESLVal $200 = _v15.termRef(0);
        ESLVal $199 = _v15.termRef(1);
        
        {ESLVal l = $200;
        
        {ESLVal e = $199;
        
        return new ESLVal("caseError()");
      }
      }
      }
    case "Head": {ESLVal $198 = _v15.termRef(0);
        
        {ESLVal e = $198;
        
        return new ESLVal("head(").add(ppExp(indent,e).add(new ESLVal(")")));
      }
      }
    case "Tail": {ESLVal $197 = _v15.termRef(0);
        
        {ESLVal e = $197;
        
        return new ESLVal("tail(").add(ppExp(indent,e).add(new ESLVal(")")));
      }
      }
    case "Cons": {ESLVal $196 = _v15.termRef(0);
        ESLVal $195 = _v15.termRef(1);
        
        {ESLVal h = $196;
        
        {ESLVal t = $195;
        
        return new ESLVal("cons(").add(ppExp(indent,h).add(new ESLVal(",").add(ppExp(indent,t).add(new ESLVal(")")))));
      }
      }
      }
    case "If": {ESLVal $194 = _v15.termRef(0);
        ESLVal $193 = _v15.termRef(1);
        ESLVal $192 = _v15.termRef(2);
        ESLVal $191 = _v15.termRef(3);
        
        {ESLVal l = $194;
        
        {ESLVal e1 = $193;
        
        {ESLVal e2 = $192;
        
        {ESLVal e3 = $191;
        
        return new ESLVal("if ").add(ppExp(indent,e1).add(nl(indent).add(new ESLVal("then").add(nl(indent.add(new ESLVal(2))).add(ppExp(indent.add(new ESLVal(2)),e2).add(nl(indent).add(new ESLVal("else").add(nl(indent.add(new ESLVal(2))).add(ppExp(indent.add(new ESLVal(2)),e3))))))))));
      }
      }
      }
      }
      }
    case "FunExp": {ESLVal $190 = _v15.termRef(0);
        ESLVal $189 = _v15.termRef(1);
        ESLVal $188 = _v15.termRef(2);
        ESLVal $187 = _v15.termRef(3);
        ESLVal $186 = _v15.termRef(4);
        
        {ESLVal l = $190;
        
        {ESLVal n = $189;
        
        {ESLVal args = $188;
        
        {ESLVal t = $187;
        
        {ESLVal e = $186;
        
        return new ESLVal("fun(").add(ppDecs(indent,args).add(new ESLVal(")::").add(ppType(t).add(new ESLVal(" ").add(ppExp(indent.add(new ESLVal(2)),e))))));
      }
      }
      }
      }
      }
      }
    case "Let": {ESLVal $185 = _v15.termRef(0);
        ESLVal $184 = _v15.termRef(1);
        ESLVal $183 = _v15.termRef(2);
        
        {ESLVal l = $185;
        
        {ESLVal bs = $184;
        
        {ESLVal e = $183;
        
        return new ESLVal("let ").add(ppBinds(indent.add(new ESLVal(4)),bs).add(nl(indent).add(new ESLVal("in ").add(ppExp(indent.add(new ESLVal(3)),e)))));
      }
      }
      }
      }
    case "Letrec": {ESLVal $182 = _v15.termRef(0);
        ESLVal $181 = _v15.termRef(1);
        ESLVal $180 = _v15.termRef(2);
        
        {ESLVal l = $182;
        
        {ESLVal bs = $181;
        
        {ESLVal e = $180;
        
        return new ESLVal("letrec ").add(ppBinds(indent.add(new ESLVal(7)),bs).add(nl(indent).add(new ESLVal("in ").add(ppExp(indent.add(new ESLVal(3)),e)))));
      }
      }
      }
      }
    case "List": {ESLVal $179 = _v15.termRef(0);
        ESLVal $178 = _v15.termRef(1);
        
        {ESLVal l = $179;
        
        {ESLVal es = $178;
        
        return new ESLVal("[").add(ppExps(indent,es,new ESLVal(",")).add(new ESLVal("]")));
      }
      }
      }
    case "Throw": {ESLVal $177 = _v15.termRef(0);
        ESLVal $176 = _v15.termRef(1);
        ESLVal $175 = _v15.termRef(2);
        
        {ESLVal l = $177;
        
        {ESLVal t = $176;
        
        {ESLVal e = $175;
        
        return new ESLVal("throw ").add(ppExp(indent,e));
      }
      }
      }
      }
    case "Term": {ESLVal $174 = _v15.termRef(0);
        ESLVal $173 = _v15.termRef(1);
        ESLVal $172 = _v15.termRef(2);
        ESLVal $171 = _v15.termRef(3);
        
        {ESLVal l = $174;
        
        {ESLVal n = $173;
        
        {ESLVal ts = $172;
        
        {ESLVal es = $171;
        
        return n.add(new ESLVal("(").add(ppExps(indent,es,new ESLVal(",")).add(new ESLVal(")"))));
      }
      }
      }
      }
      }
    case "TermRef": {ESLVal $170 = _v15.termRef(0);
        ESLVal $169 = _v15.termRef(1);
        
        {ESLVal e = $170;
        
        {ESLVal n = $169;
        
        return new ESLVal("termRef(").add(ppExp(indent,e).add(new ESLVal(",").add(n.add(new ESLVal(")")))));
      }
      }
      }
    case "BinExp": {ESLVal $168 = _v15.termRef(0);
        ESLVal $167 = _v15.termRef(1);
        ESLVal $166 = _v15.termRef(2);
        ESLVal $165 = _v15.termRef(3);
        
        {ESLVal l = $168;
        
        {ESLVal e1 = $167;
        
        {ESLVal op = $166;
        
        {ESLVal e2 = $165;
        
        return ppExp(indent,e1).add(op.add(ppExp(indent,e2)));
      }
      }
      }
      }
      }
    case "Update": {ESLVal $164 = _v15.termRef(0);
        ESLVal $163 = _v15.termRef(1);
        ESLVal $162 = _v15.termRef(2);
        
        {ESLVal l = $164;
        
        {ESLVal n = $163;
        
        {ESLVal e = $162;
        
        return n.add(new ESLVal(" := ").add(ppExp(indent,e)));
      }
      }
      }
      }
    case "NewArray": {ESLVal $161 = _v15.termRef(0);
        ESLVal $160 = _v15.termRef(1);
        ESLVal $159 = _v15.termRef(2);
        
        {ESLVal l = $161;
        
        {ESLVal t = $160;
        
        {ESLVal n = $159;
        
        return new ESLVal("new Array[").add(ppType(t).add(new ESLVal("](").add(ppExp(indent,n).add(new ESLVal(")")))));
      }
      }
      }
      }
    case "For": {ESLVal $158 = _v15.termRef(0);
        ESLVal $157 = _v15.termRef(1);
        ESLVal $156 = _v15.termRef(2);
        ESLVal $155 = _v15.termRef(3);
        
        {ESLVal l = $158;
        
        {ESLVal p = $157;
        
        {ESLVal e1 = $156;
        
        {ESLVal e2 = $155;
        
        return new ESLVal("for ").add(ppPattern(p).add(new ESLVal(" in ").add(ppExp(indent,e1).add(new ESLVal(" do {").add(nl(indent.add(new ESLVal(2))).add(ppExp(indent.add(new ESLVal(2)),e2).add(new ESLVal("}"))))))));
      }
      }
      }
      }
      }
    case "Try": {ESLVal $154 = _v15.termRef(0);
        ESLVal $153 = _v15.termRef(1);
        ESLVal $152 = _v15.termRef(2);
        
        {ESLVal l = $154;
        
        {ESLVal e = $153;
        
        {ESLVal as = $152;
        
        return new ESLVal("try ").add(ppExp(indent,e).add(new ESLVal(" {").add(nl(indent.add(new ESLVal(2))).add(ppJoin(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun309"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return ppArm(indent,a);
          }
        }),as)).add(nl(indent).add(new ESLVal("}")))))));
      }
      }
      }
      }
    case "ActExp": {ESLVal $151 = _v15.termRef(0);
        ESLVal $150 = _v15.termRef(1);
        ESLVal $149 = _v15.termRef(2);
        ESLVal $148 = _v15.termRef(3);
        ESLVal $147 = _v15.termRef(4);
        ESLVal $146 = _v15.termRef(5);
        ESLVal $145 = _v15.termRef(6);
        ESLVal $144 = _v15.termRef(7);
        
        {ESLVal l = $151;
        
        {ESLVal n = $150;
        
        {ESLVal args = $149;
        
        {ESLVal x = $148;
        
        {ESLVal parent = $147;
        
        {ESLVal locals = $146;
        
        {ESLVal init = $145;
        
        {ESLVal handlers = $144;
        
        return new ESLVal("act ").add(ppExp(indent,n).add(new ESLVal("(").add(ppDecs(indent,args).add(new ESLVal(") {").add(nl(indent.add(new ESLVal(2))).add(ppBinds(indent.add(new ESLVal(5)),locals).add(nl(indent.add(new ESLVal(2))).add(new ESLVal("-> ").add(ppExp(indent.add(new ESLVal(4)),init).add(nl(indent.add(new ESLVal(2))).add(ppJoin(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun310"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return ppArm(indent,a);
          }
        }),handlers)).add(nl(indent).add(new ESLVal("}"))))))))))))));
      }
      }
      }
      }
      }
      }
      }
      }
      }
    case "Self": {ESLVal $143 = _v15.termRef(0);
        
        {ESLVal l = $143;
        
        return new ESLVal("self");
      }
      }
    case "Ref": {ESLVal $142 = _v15.termRef(0);
        ESLVal $141 = _v15.termRef(1);
        ESLVal $140 = _v15.termRef(2);
        
        {ESLVal l = $142;
        
        {ESLVal e = $141;
        
        {ESLVal n = $140;
        
        return ppExp(indent,e).add(new ESLVal(".").add(n));
      }
      }
      }
      }
    case "Send": {ESLVal $139 = _v15.termRef(0);
        ESLVal $138 = _v15.termRef(1);
        ESLVal $137 = _v15.termRef(2);
        
        {ESLVal l = $139;
        
        {ESLVal target = $138;
        
        {ESLVal message = $137;
        
        return ppExp(indent,target).add(new ESLVal(" <- ").add(ppExp(indent,message)));
      }
      }
      }
      }
    case "Cmp": {ESLVal $136 = _v15.termRef(0);
        ESLVal $135 = _v15.termRef(1);
        ESLVal $134 = _v15.termRef(2);
        
        {ESLVal l = $136;
        
        {ESLVal e = $135;
        
        {ESLVal qs = $134;
        
        return new ESLVal("[").add(ppExp(indent,e).add(new ESLVal(" | ").add(ppJoin(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun311"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal q = $args[0];
        return ppQual(indent,q);
          }
        }),qs)).add(new ESLVal("]")))));
      }
      }
      }
      }
    case "New": {ESLVal $133 = _v15.termRef(0);
        ESLVal $132 = _v15.termRef(1);
        ESLVal $131 = _v15.termRef(2);
        
        {ESLVal l = $133;
        
        {ESLVal b = $132;
        
        {ESLVal args = $131;
        
        return new ESLVal("new ").add(ppExp(indent,b).add(new ESLVal("(").add(ppExps(indent,args,new ESLVal(",")).add(new ESLVal(")")))));
      }
      }
      }
      }
    case "NewJava": {ESLVal $130 = _v15.termRef(0);
        ESLVal $129 = _v15.termRef(1);
        ESLVal $128 = _v15.termRef(2);
        ESLVal $127 = _v15.termRef(3);
        
        {ESLVal l = $130;
        
        {ESLVal className = $129;
        
        {ESLVal t = $128;
        
        {ESLVal args = $127;
        
        return new ESLVal("javaNew[").add(ppType(t).add(new ESLVal("](\' + className + ").add(ppExps(indent,args,new ESLVal(",")).add(new ESLVal(")")))));
      }
      }
      }
      }
      }
    case "Grab": {ESLVal $126 = _v15.termRef(0);
        ESLVal $125 = _v15.termRef(1);
        ESLVal $124 = _v15.termRef(2);
        
        {ESLVal l = $126;
        
        {ESLVal rs = $125;
        
        {ESLVal e = $124;
        
        return new ESLVal("*********grab");
      }
      }
      }
      }
    case "Probably": {ESLVal $123 = _v15.termRef(0);
        ESLVal $122 = _v15.termRef(1);
        ESLVal $121 = _v15.termRef(2);
        ESLVal $120 = _v15.termRef(3);
        ESLVal $119 = _v15.termRef(4);
        
        {ESLVal l = $123;
        
        {ESLVal p = $122;
        
        {ESLVal t = $121;
        
        {ESLVal e1 = $120;
        
        {ESLVal e2 = $119;
        
        return new ESLVal("**** probably");
      }
      }
      }
      }
      }
      }
    case "Not": {ESLVal $118 = _v15.termRef(0);
        ESLVal $117 = _v15.termRef(1);
        
        {ESLVal l = $118;
        
        {ESLVal e = $117;
        
        return new ESLVal("not(").add(ppExp(indent,e).add(new ESLVal(")")));
      }
      }
      }
    case "Fold": {ESLVal $116 = _v15.termRef(0);
        ESLVal $115 = _v15.termRef(1);
        ESLVal $114 = _v15.termRef(2);
        
        {ESLVal l = $116;
        
        {ESLVal t = $115;
        
        {ESLVal e = $114;
        
        return new ESLVal("******** fold");
      }
      }
      }
      }
    case "Unfold": {ESLVal $113 = _v15.termRef(0);
        ESLVal $112 = _v15.termRef(1);
        ESLVal $111 = _v15.termRef(2);
        
        {ESLVal l = $113;
        
        {ESLVal t = $112;
        
        {ESLVal e = $111;
        
        return new ESLVal("******unfold");
      }
      }
      }
      }
    case "Now": {ESLVal $110 = _v15.termRef(0);
        
        {ESLVal l = $110;
        
        return new ESLVal("now");
      }
      }
    case "Become": {ESLVal $109 = _v15.termRef(0);
        ESLVal $108 = _v15.termRef(1);
        
        {ESLVal l = $109;
        
        {ESLVal e = $108;
        
        return new ESLVal("become ").add(ppExp(indent,e));
      }
      }
      }
    case "ArrayRef": {ESLVal $107 = _v15.termRef(0);
        ESLVal $106 = _v15.termRef(1);
        ESLVal $105 = _v15.termRef(2);
        
        {ESLVal l = $107;
        
        {ESLVal a = $106;
        
        {ESLVal i = $105;
        
        return ppExp(indent,a).add(new ESLVal("[").add(ppExp(indent,i).add(new ESLVal("]"))));
      }
      }
      }
      }
    case "ArrayUpdate": {ESLVal $104 = _v15.termRef(0);
        ESLVal $103 = _v15.termRef(1);
        ESLVal $102 = _v15.termRef(2);
        ESLVal $101 = _v15.termRef(3);
        
        {ESLVal l = $104;
        
        {ESLVal a = $103;
        
        {ESLVal i = $102;
        
        {ESLVal v = $101;
        
        return ppExp(indent,a).add(new ESLVal("[").add(ppExp(indent,i).add(new ESLVal("] := ").add(ppExp(indent,v)))));
      }
      }
      }
      }
      }
      default: {ESLVal x = _v15;
        
        return error(new ESLVal("ppExp: ").add(x));
      }
    }
    }
  }
  public static ESLVal ppExp = new ESLVal(new Function(new ESLVal("ppExp"),null) { public ESLVal apply(ESLVal... args) { return ppExp(args[0],args[1]); }});
  private static ESLVal ppQual(ESLVal indent,ESLVal q) {
    
    return new ESLVal("qualifier: ").add(q);
  }
  private static ESLVal ppQual = new ESLVal(new Function(new ESLVal("ppQual"),null) { public ESLVal apply(ESLVal... args) { return ppQual(args[0],args[1]); }});
  private static ESLVal ppDecs(ESLVal indent,ESLVal bs) {
    
    return ppJoin(indent,map.apply(new ESLVal(new Function(new ESLVal("fun312"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal b = $args[0];
      return ppDec(indent,b);
        }
      }),bs));
  }
  private static ESLVal ppDecs = new ESLVal(new Function(new ESLVal("ppDecs"),null) { public ESLVal apply(ESLVal... args) { return ppDecs(args[0],args[1]); }});
  private static ESLVal ppDec(ESLVal indent,ESLVal d) {
    
    {ESLVal _v16 = d;
      
      switch(_v16.termName) {
      case "Dec": {ESLVal $255 = _v16.termRef(0);
        ESLVal $254 = _v16.termRef(1);
        ESLVal $253 = _v16.termRef(2);
        ESLVal $252 = _v16.termRef(3);
        
        {ESLVal l = $255;
        
        {ESLVal n = $254;
        
        {ESLVal dt = $253;
        
        {ESLVal t = $252;
        
        return n.add(new ESLVal("::").add(ppType(t)));
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(10810,10887)").add(ESLVal.list(_v16)));
    }
    }
  }
  private static ESLVal ppDec = new ESLVal(new Function(new ESLVal("ppDec"),null) { public ESLVal apply(ESLVal... args) { return ppDec(args[0],args[1]); }});
  private static ESLVal ppBinds(ESLVal indent,ESLVal bs) {
    
    return ppJoin(indent,map.apply(new ESLVal(new Function(new ESLVal("fun313"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal b = $args[0];
      return ppBind(indent,b);
        }
      }),bs));
  }
  private static ESLVal ppBinds = new ESLVal(new Function(new ESLVal("ppBinds"),null) { public ESLVal apply(ESLVal... args) { return ppBinds(args[0],args[1]); }});
  private static ESLVal ppBind(ESLVal indent,ESLVal b) {
    
    {ESLVal _v17 = b;
      
      switch(_v17.termName) {
      case "Binding": {ESLVal $279 = _v17.termRef(0);
        ESLVal $278 = _v17.termRef(1);
        ESLVal $277 = _v17.termRef(2);
        ESLVal $276 = _v17.termRef(3);
        ESLVal $275 = _v17.termRef(4);
        
        {ESLVal l = $279;
        
        {ESLVal name = $278;
        
        {ESLVal t = $277;
        
        {ESLVal st = $276;
        
        {ESLVal value = $275;
        
        return name.add(new ESLVal("=").add(ppExp(indent,value).add(new ESLVal(";"))));
      }
      }
      }
      }
      }
      }
    case "TypeBind": {ESLVal $274 = _v17.termRef(0);
        ESLVal $273 = _v17.termRef(1);
        ESLVal $272 = _v17.termRef(2);
        ESLVal $271 = _v17.termRef(3);
        
        {ESLVal l = $274;
        
        {ESLVal name = $273;
        
        {ESLVal t = $272;
        
        {ESLVal ignore = $271;
        
        return new ESLVal("type ").add(name);
      }
      }
      }
      }
      }
    case "DataBind": {ESLVal $270 = _v17.termRef(0);
        ESLVal $269 = _v17.termRef(1);
        ESLVal $268 = _v17.termRef(2);
        ESLVal $267 = _v17.termRef(3);
        
        {ESLVal l = $270;
        
        {ESLVal name = $269;
        
        {ESLVal t = $268;
        
        {ESLVal ignore = $267;
        
        return new ESLVal("data ").add(name);
      }
      }
      }
      }
      }
    case "FunBind": {ESLVal $266 = _v17.termRef(0);
        ESLVal $265 = _v17.termRef(1);
        ESLVal $264 = _v17.termRef(2);
        ESLVal $263 = _v17.termRef(3);
        ESLVal $262 = _v17.termRef(4);
        ESLVal $261 = _v17.termRef(5);
        ESLVal $260 = _v17.termRef(6);
        
        {ESLVal l = $266;
        
        {ESLVal name = $265;
        
        {ESLVal args = $264;
        
        {ESLVal t = $263;
        
        {ESLVal st = $262;
        
        {ESLVal body = $261;
        
        {ESLVal guard = $260;
        
        return name.add(new ESLVal("(").add(ppPatterns(args).add(new ESLVal(") = ").add(nl(indent.add(new ESLVal(2))).add(ppExp(indent.add(new ESLVal(2)),body))))));
      }
      }
      }
      }
      }
      }
      }
      }
    case "CnstrBind": {ESLVal $259 = _v17.termRef(0);
        ESLVal $258 = _v17.termRef(1);
        ESLVal $257 = _v17.termRef(2);
        ESLVal $256 = _v17.termRef(3);
        
        {ESLVal l = $259;
        
        {ESLVal name = $258;
        
        {ESLVal t = $257;
        
        {ESLVal ignore = $256;
        
        return name;
      }
      }
      }
      }
      }
      default: {ESLVal x = _v17;
        
        return error(new ESLVal("ppBind: ").add(x));
      }
    }
    }
  }
  private static ESLVal ppBind = new ESLVal(new Function(new ESLVal("ppBind"),null) { public ESLVal apply(ESLVal... args) { return ppBind(args[0],args[1]); }});
  public static ESLVal ppArm(ESLVal indent,ESLVal a) {
    
    {ESLVal _v18 = a;
      
      switch(_v18.termName) {
      case "BArm": {ESLVal $283 = _v18.termRef(0);
        ESLVal $282 = _v18.termRef(1);
        ESLVal $281 = _v18.termRef(2);
        ESLVal $280 = _v18.termRef(3);
        
        {ESLVal l = $283;
        
        {ESLVal ps = $282;
        
        {ESLVal guard = $281;
        
        {ESLVal e = $280;
        
        return ppPatterns(ps).add(new ESLVal(" -> ").add(nl(indent.add(new ESLVal(2))).add(ppExp(indent.add(new ESLVal(2)),e))));
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(11672,11810)").add(ESLVal.list(_v18)));
    }
    }
  }
  public static ESLVal ppArm = new ESLVal(new Function(new ESLVal("ppArm"),null) { public ESLVal apply(ESLVal... args) { return ppArm(args[0],args[1]); }});
  public static ESLVal ppArms(ESLVal indent,ESLVal arms) {
    
    return ppJoin(indent,map.apply(new ESLVal(new Function(new ESLVal("fun314"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return ppArm(indent,a);
        }
      }),arms));
  }
  public static ESLVal ppArms = new ESLVal(new Function(new ESLVal("ppArms"),null) { public ESLVal apply(ESLVal... args) { return ppArms(args[0],args[1]); }});
  private static ESLVal ppCaseTermArm(ESLVal indent,ESLVal a) {
    
    {ESLVal _v19 = a;
      
      switch(_v19.termName) {
      case "TArm": {ESLVal $285 = _v19.termRef(0);
        ESLVal $284 = _v19.termRef(1);
        
        {ESLVal n = $285;
        
        {ESLVal e = $284;
        
        return n.add(new ESLVal(" -> ").add(nl(indent.add(new ESLVal(2))).add(ppExp(indent.add(new ESLVal(2)),e))));
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(11972,12072)").add(ESLVal.list(_v19)));
    }
    }
  }
  private static ESLVal ppCaseTermArm = new ESLVal(new Function(new ESLVal("ppCaseTermArm"),null) { public ESLVal apply(ESLVal... args) { return ppCaseTermArm(args[0],args[1]); }});
  private static ESLVal ppCaseIntsArm(ESLVal indent,ESLVal a) {
    
    {ESLVal _v20 = a;
      
      switch(_v20.termName) {
      case "IArm": {ESLVal $287 = _v20.termRef(0);
        ESLVal $286 = _v20.termRef(1);
        
        {ESLVal n = $287;
        
        {ESLVal e = $286;
        
        return n.add(new ESLVal(" -> ").add(nl(indent.add(new ESLVal(2))).add(ppExp(indent.add(new ESLVal(2)),e))));
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(12128,12228)").add(ESLVal.list(_v20)));
    }
    }
  }
  private static ESLVal ppCaseIntsArm = new ESLVal(new Function(new ESLVal("ppCaseIntsArm"),null) { public ESLVal apply(ESLVal... args) { return ppCaseIntsArm(args[0],args[1]); }});
  private static ESLVal ppCaseStrsArm(ESLVal indent,ESLVal a) {
    
    {ESLVal _v21 = a;
      
      switch(_v21.termName) {
      case "SArm": {ESLVal $289 = _v21.termRef(0);
        ESLVal $288 = _v21.termRef(1);
        
        {ESLVal n = $289;
        
        {ESLVal e = $288;
        
        return new ESLVal("\'").add(n.add(new ESLVal("\'").add(new ESLVal(" -> ").add(nl(indent.add(new ESLVal(2))).add(ppExp(indent.add(new ESLVal(2)),e))))));
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(12284,12398)").add(ESLVal.list(_v21)));
    }
    }
  }
  private static ESLVal ppCaseStrsArm = new ESLVal(new Function(new ESLVal("ppCaseStrsArm"),null) { public ESLVal apply(ESLVal... args) { return ppCaseStrsArm(args[0],args[1]); }});
  private static ESLVal ppCaseBoolsArm(ESLVal indent,ESLVal a) {
    
    {ESLVal _v22 = a;
      
      switch(_v22.termName) {
      case "BoolArm": {ESLVal $291 = _v22.termRef(0);
        ESLVal $290 = _v22.termRef(1);
        
        {ESLVal b = $291;
        
        {ESLVal e = $290;
        
        return b.add(new ESLVal(" -> ").add(nl(indent.add(new ESLVal(2))).add(ppExp(indent.add(new ESLVal(2)),e))));
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(12456,12560)").add(ESLVal.list(_v22)));
    }
    }
  }
  private static ESLVal ppCaseBoolsArm = new ESLVal(new Function(new ESLVal("ppCaseBoolsArm"),null) { public ESLVal apply(ESLVal... args) { return ppCaseBoolsArm(args[0],args[1]); }});
  private static ESLVal getImport(ESLVal sourceFile) {
    
    {ESLVal path = toPath.apply(sourceFile);
      
      {ESLVal p = pathToJavaPackage.apply(path);
      ESLVal className = pathToJavaClassName.apply(path);
      
      {ESLVal _v23 = sourceFile;
      
      switch(_v23.strVal) {
      case "esl/lists.esl": return new ESLVal("// import static ").add(p.add(new ESLVal(".").add(className.add(new ESLVal(".*;")))));
      default: {ESLVal x = _v23;
        
        return new ESLVal("import static ").add(p.add(new ESLVal(".").add(className.add(new ESLVal(".*;")))));
      }
    }
    }
    }
    }
  }
  private static ESLVal getImport = new ESLVal(new Function(new ESLVal("getImport"),null) { public ESLVal apply(ESLVal... args) { return getImport(args[0]); }});
  public static ESLVal ppJModule(ESLVal name,ESLVal p,ESLVal m) {
    
    {ESLVal _v24 = m;
      
      switch(_v24.termName) {
      case "JModule": {ESLVal $296 = _v24.termRef(0);
        ESLVal $295 = _v24.termRef(1);
        ESLVal $294 = _v24.termRef(2);
        ESLVal $293 = _v24.termRef(3);
        ESLVal $292 = _v24.termRef(4);
        
        {ESLVal n = $296;
        
        {ESLVal exports = $295;
        
        {ESLVal imports = $294;
        
        {ESLVal methods = $293;
        
        {ESLVal fields = $292;
        
        return new ESLVal("package ").add(p.add(new ESLVal(";").add(nl($zero).add(new ESLVal("import esl.lib.*;").add(nl($zero).add(new ESLVal("import static esl.lib.Lib.*;").add(nl($zero).add(ppJoin($zero,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal i = $l0.head();
              $l0 = $l0.tail();
              $v.add(getImport(i));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(imports)).add(nl($zero).add(new ESLVal("import java.util.function.Supplier;").add(nl($zero).add(new ESLVal("public class ").add(name.add(new ESLVal(" {").add(nl(new ESLVal(2)).add(new ESLVal("public static ESLVal getSelf() { return $null; }").add(nl(new ESLVal(2)).add(ppJoin(new ESLVal(2),map.apply(new ESLVal(new Function(new ESLVal("fun315"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v120 = $args[0];
        return ppJModuleMethod(new ESLVal(2),exports,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v25 = $qualArg;
                    
                    switch(_v25.termName) {
                    case "JField": {ESLVal $299 = _v25.termRef(0);
                      ESLVal $298 = _v25.termRef(1);
                      ESLVal $297 = _v25.termRef(2);
                      
                      {ESLVal _v121 = $299;
                      
                      {ESLVal t = $298;
                      
                      {ESLVal e = $297;
                      
                      return ESLVal.list(ESLVal.list(_v121));
                    }
                    }
                    }
                    }
                    default: {ESLVal _0 = _v25;
                      
                      return ESLVal.list();
                    }
                  }
                  }
                }
              }).map(fields).flatten().flatten(),_v120);
          }
        }),methods)).add(nl($zero).add(ppJoin(new ESLVal(2),map.apply(new ESLVal(new Function(new ESLVal("fun316"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal f = $args[0];
        return ppJModuleField(new ESLVal(2),exports,f);
          }
        }),fields)).add(nl($zero).add(new ESLVal("public static void main(String[] args) {").add(nl(new ESLVal(2)).add(((Supplier<ESLVal>)() -> { 
          if(member.apply(new ESLVal("main"),exports).boolVal)
            return new ESLVal("  newActor(main,new ESLVal(new Actor())); ").add(nl(new ESLVal(2)));
            else
              return new ESLVal("");
        }).get().add(new ESLVal("}").add(nl($zero).add(new ESLVal("}"))))))))))))))))))))))))))));
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(12955,13882)").add(ESLVal.list(_v24)));
    }
    }
  }
  public static ESLVal ppJModule = new ESLVal(new Function(new ESLVal("ppJModule"),null) { public ESLVal apply(ESLVal... args) { return ppJModule(args[0],args[1],args[2]); }});
  private static ESLVal ppJModuleField(ESLVal indent,ESLVal exports,ESLVal f) {
    
    {ESLVal _v26 = f;
      
      switch(_v26.termName) {
      case "JField": {ESLVal $302 = _v26.termRef(0);
        ESLVal $301 = _v26.termRef(1);
        ESLVal $300 = _v26.termRef(2);
        
        switch($302.strVal) {
        case "edb": switch($300.termName) {
          case "JNull": {
            {ESLVal t = $301;
            
            return new ESLVal("// static ESLVal edb = null;");
          }
          }
          default: {ESLVal n = $302;
            
            {ESLVal t = $301;
            
            {ESLVal e = $300;
            
            return ((Supplier<ESLVal>)() -> { 
              if(member.apply(n,exports).boolVal)
                return new ESLVal("public ");
                else
                  return new ESLVal("private ");
            }).get().add(new ESLVal("static ESLVal ").add(n.add(new ESLVal(" = ").add(ppJExp(indent,ESLVal.list(),e).add(new ESLVal(";"))))));
          }
          }
          }
        }
        default: {ESLVal n = $302;
          
          {ESLVal t = $301;
          
          {ESLVal e = $300;
          
          return ((Supplier<ESLVal>)() -> { 
            if(member.apply(n,exports).boolVal)
              return new ESLVal("public ");
              else
                return new ESLVal("private ");
          }).get().add(new ESLVal("static ESLVal ").add(n.add(new ESLVal(" = ").add(ppJExp(indent,ESLVal.list(),e).add(new ESLVal(";"))))));
        }
        }
        }
      }
      }
      default: return error(new ESLVal("case error at Pos(13951,14201)").add(ESLVal.list(_v26)));
    }
    }
  }
  private static ESLVal ppJModuleField = new ESLVal(new Function(new ESLVal("ppJModuleField"),null) { public ESLVal apply(ESLVal... args) { return ppJModuleField(args[0],args[1],args[2]); }});
  private static ESLVal ppJModuleMethod(ESLVal indent,ESLVal exports,ESLVal fieldNames,ESLVal method) {
    
    {ESLVal _v27 = method;
      
      switch(_v27.termName) {
      case "JMethod": {ESLVal $305 = _v27.termRef(0);
        ESLVal $304 = _v27.termRef(1);
        ESLVal $303 = _v27.termRef(2);
        
        {ESLVal name = $305;
        
        {ESLVal args = $304;
        
        {ESLVal body = $303;
        
        {ESLVal freeDynamics = removeAll.apply(fieldNames,dynamicVarsJCommand.apply(body));
        
        {ESLVal argDecs = joinBy.apply(new ESLVal(44),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v28 = $qualArg;
                
                switch(_v28.termName) {
                case "JDec": {ESLVal $307 = _v28.termRef(0);
                  ESLVal $306 = _v28.termRef(1);
                  
                  {ESLVal n = $307;
                  
                  {ESLVal t = $306;
                  
                  return ESLVal.list(ESLVal.list(((Supplier<ESLVal>)() -> { 
                    if(member.apply(n,freeDynamics).boolVal)
                      return pJDec(indent,new ESLVal("JDec",new ESLVal("$raw_").add(n),t));
                      else
                        return pJDec(indent,new ESLVal("JDec",n,t));
                  }).get()));
                }
                }
                }
                default: {ESLVal _0 = _v28;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(args).flatten().flatten());
        ESLVal freeNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v29 = $qualArg;
                
                switch(_v29.termName) {
                case "JDec": {ESLVal $309 = _v29.termRef(0);
                  ESLVal $308 = _v29.termRef(1);
                  
                  {ESLVal n = $309;
                  
                  {ESLVal t = $308;
                  
                  return ESLVal.list(((Supplier<ESLVal>)() -> { 
                    if(member.apply(n,freeDynamics).boolVal)
                      return ESLVal.list(n);
                      else
                        return ESLVal.list();
                  }).get());
                }
                }
                }
                default: {ESLVal _0 = _v29;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(args).flatten().flatten();
        
        {ESLVal freeDecs = joinBy.apply(new ESLVal(32),new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal n = $l0.head();
                $l0 = $l0.tail();
                $v.add(new ESLVal("ESLVal[] ").add(n.add(new ESLVal(" = new ESLVal[]{$raw_").add(n.add(new ESLVal("};"))))));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(freeNames));
        
        return ((Supplier<ESLVal>)() -> { 
          if(member.apply(name,exports).boolVal)
            return new ESLVal("public ");
            else
              return new ESLVal("private ");
        }).get().add(new ESLVal("static ESLVal ").add(name.add(new ESLVal("(").add(argDecs.add(new ESLVal(") {").add(nl(indent.add(new ESLVal(2))).add(freeDecs.add(nl(indent.add(new ESLVal(2))).add(ppJCommand(indent.add(new ESLVal(2)),freeDynamics,body).add(nl(indent).add(new ESLVal("}").add(nl(indent).add(((Supplier<ESLVal>)() -> { 
          if(member.apply(name,exports).boolVal)
            return new ESLVal("public ");
            else
              return new ESLVal("private ");
        }).get().add(new ESLVal("static ESLVal ").add(name.add(new ESLVal(" = new ESLVal(new Function(").add(ppJExp(indent,ESLVal.list(),new ESLVal("JConstExp",new ESLVal("JConstStr",name))).add(new ESLVal(",null) { ").add(new ESLVal("public ESLVal apply(ESLVal... args) { ").add(new ESLVal("return ").add(name.add(new ESLVal("(").add(joinBy.apply(new ESLVal(44),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal i = $l0.head();
              $l0 = $l0.tail();
              $v.add(new ESLVal("args[").add(i.add(new ESLVal("]"))));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply($zero.to(length.apply(args)))).add(new ESLVal("); }});")))))))))))))))))))))))));
      }
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(14293,15553)").add(ESLVal.list(_v27)));
    }
    }
  }
  private static ESLVal ppJModuleMethod = new ESLVal(new Function(new ESLVal("ppJModuleMethod"),null) { public ESLVal apply(ESLVal... args) { return ppJModuleMethod(args[0],args[1],args[2],args[3]); }});
  private static ESLVal ppJExps(ESLVal indent,ESLVal dynamics,ESLVal exps,ESLVal sep) {
    
    {ESLVal _v30 = exps;
      
      if(_v30.isCons())
      {ESLVal $310 = _v30.head();
        ESLVal $311 = _v30.tail();
        
        if($311.isCons())
        {ESLVal $312 = $311.head();
          ESLVal $313 = $311.tail();
          
          {ESLVal e1 = $310;
          
          {ESLVal e2 = $312;
          
          {ESLVal es = $313;
          
          return ppJExp(indent,dynamics,e1).add(sep.add(ppJExps(indent,dynamics,es.cons(e2),sep)));
        }
        }
        }
        }
      else if($311.isNil())
        {ESLVal e = $310;
          
          return ppJExp(indent,dynamics,e);
        }
      else return error(new ESLVal("case error at Pos(15623,15817)").add(ESLVal.list(_v30)));
      }
    else if(_v30.isNil())
      return new ESLVal("");
    else return error(new ESLVal("case error at Pos(15623,15817)").add(ESLVal.list(_v30)));
    }
  }
  private static ESLVal ppJExps = new ESLVal(new Function(new ESLVal("ppJExps"),null) { public ESLVal apply(ESLVal... args) { return ppJExps(args[0],args[1],args[2],args[3]); }});
  private static ESLVal ppJDecs(ESLVal indent,ESLVal decs,ESLVal sep) {
    
    {ESLVal _v31 = decs;
      
      if(_v31.isCons())
      {ESLVal $314 = _v31.head();
        ESLVal $315 = _v31.tail();
        
        if($315.isCons())
        {ESLVal $316 = $315.head();
          ESLVal $317 = $315.tail();
          
          {ESLVal e1 = $314;
          
          {ESLVal e2 = $316;
          
          {ESLVal es = $317;
          
          return pJDec(indent,e1).add(sep.add(ppJDecs(indent,es.cons(e2),sep)));
        }
        }
        }
        }
      else if($315.isNil())
        {ESLVal e = $314;
          
          return pJDec(indent,e);
        }
      else return error(new ESLVal("case error at Pos(15879,16091)").add(ESLVal.list(_v31)));
      }
    else if(_v31.isNil())
      return new ESLVal("");
    else return error(new ESLVal("case error at Pos(15879,16091)").add(ESLVal.list(_v31)));
    }
  }
  private static ESLVal ppJDecs = new ESLVal(new Function(new ESLVal("ppJDecs"),null) { public ESLVal apply(ESLVal... args) { return ppJDecs(args[0],args[1],args[2]); }});
  private static ESLVal pJDec(ESLVal indent,ESLVal d) {
    
    {ESLVal _v32 = d;
      
      switch(_v32.termName) {
      case "JDec": {ESLVal $319 = _v32.termRef(0);
        ESLVal $318 = _v32.termRef(1);
        
        {ESLVal n = $319;
        
        {ESLVal t = $318;
        
        return new ESLVal("ESLVal ").add(n);
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(16137,16193)").add(ESLVal.list(_v32)));
    }
    }
  }
  private static ESLVal pJDec = new ESLVal(new Function(new ESLVal("pJDec"),null) { public ESLVal apply(ESLVal... args) { return pJDec(args[0],args[1]); }});
  private static ESLVal ppJExp(ESLVal indent,ESLVal dynamics,ESLVal e) {
    
    {ESLVal _v33 = e;
      
      switch(_v33.termName) {
      case "JArrayRef": {ESLVal $420 = _v33.termRef(0);
        ESLVal $419 = _v33.termRef(1);
        
        {ESLVal a = $420;
        
        {ESLVal i = $419;
        
        return ppJExp(indent,dynamics,a).add(new ESLVal(".array[").add(ppJExp(indent,dynamics,i).add(new ESLVal(".intVal]"))));
      }
      }
      }
    case "JArrayUpdate": {ESLVal $418 = _v33.termRef(0);
        ESLVal $417 = _v33.termRef(1);
        ESLVal $416 = _v33.termRef(2);
        
        {ESLVal a = $418;
        
        {ESLVal i = $417;
        
        {ESLVal v = $416;
        
        return ppJExp(indent,dynamics,a).add(new ESLVal(".array[").add(ppJExp(indent,dynamics,i).add(new ESLVal(".intVal] = ").add(ppJExp(indent,dynamics,v)))));
      }
      }
      }
      }
    case "JBecome": {ESLVal $413 = _v33.termRef(0);
        ESLVal $412 = _v33.termRef(1);
        
        if($412.isCons())
        {ESLVal $414 = $412.head();
          ESLVal $415 = $412.tail();
          
          {ESLVal _v116 = $413;
          
          {ESLVal es = $412;
          
          return new ESLVal("become(").add(ppJExp(indent.add(new ESLVal(2)),dynamics,_v116).add(new ESLVal(",getSelf(),").add(ppJExps(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")")))));
        }
        }
        }
      else if($412.isNil())
        {ESLVal _v117 = $413;
          
          return new ESLVal("become(").add(ppJExp(indent.add(new ESLVal(2)),dynamics,_v117).add(new ESLVal(",getSelf())")));
        }
      else {ESLVal _v118 = $413;
          
          {ESLVal es = $412;
          
          return new ESLVal("become(").add(ppJExp(indent.add(new ESLVal(2)),dynamics,_v118).add(new ESLVal(",getSelf(),").add(ppJExps(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")")))));
        }
        }
      }
    case "JConstExp": {ESLVal $407 = _v33.termRef(0);
        
        switch($407.termName) {
        case "JConstInt": {ESLVal $411 = $407.termRef(0);
          
          switch($411.intVal) {
          case 0: return new ESLVal("$zero");
        case 1: return new ESLVal("$one");
          default: {ESLVal n = $411;
            
            return new ESLVal("new ESLVal(").add(n.add(new ESLVal(")")));
          }
        }
        }
      case "JConstBool": {ESLVal $410 = $407.termRef(0);
          
          switch($410.boolVal ? 1 : 0) {
          case 1: return new ESLVal("$true");
        case 0: return new ESLVal("$false");
          default: {ESLVal _v114 = _v33;
            
            return new ESLVal("********** unknown expression: ").add(_v114);
          }
        }
        }
      case "JConstStr": {ESLVal $409 = $407.termRef(0);
          
          {ESLVal s = $409;
          
          return new ESLVal("new ESLVal(\"").add(javaString.apply(s).add(new ESLVal("\")")));
        }
        }
      case "JConstDouble": {ESLVal $408 = $407.termRef(0);
          
          {ESLVal d = $408;
          
          return new ESLVal("new ESLVal(").add(d.add(new ESLVal(")")));
        }
        }
        default: {ESLVal _v115 = _v33;
          
          return new ESLVal("********** unknown expression: ").add(_v115);
        }
      }
      }
    case "JNot": {ESLVal $406 = _v33.termRef(0);
        
        {ESLVal _v113 = $406;
        
        return ppJExp(indent,dynamics,_v113).add(new ESLVal(".not()"));
      }
      }
    case "JNil": {ESLVal $405 = _v33.termRef(0);
        
        {ESLVal t = $405;
        
        return new ESLVal("$nil");
      }
      }
    case "JList": {ESLVal $404 = _v33.termRef(0);
        ESLVal $403 = _v33.termRef(1);
        
        {ESLVal t = $404;
        
        {ESLVal es = $403;
        
        return ppJListExp(indent,dynamics,t,es);
      }
      }
      }
    case "JSet": {ESLVal $402 = _v33.termRef(0);
        ESLVal $401 = _v33.termRef(1);
        
        {ESLVal t = $402;
        
        {ESLVal es = $401;
        
        return ppJSetExp(indent,dynamics,t,es);
      }
      }
      }
    case "JBag": {ESLVal $400 = _v33.termRef(0);
        ESLVal $399 = _v33.termRef(1);
        
        {ESLVal t = $400;
        
        {ESLVal es = $399;
        
        return ppJBagExp(indent,dynamics,t,es);
      }
      }
      }
    case "JTerm": {ESLVal $396 = _v33.termRef(0);
        ESLVal $395 = _v33.termRef(1);
        
        if($395.isCons())
        {ESLVal $397 = $395.head();
          ESLVal $398 = $395.tail();
          
          {ESLVal n = $396;
          
          {ESLVal es = $395;
          
          return new ESLVal("new ESLVal(\"").add(n.add(new ESLVal("\",").add(ppJExps(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")")))));
        }
        }
        }
      else if($395.isNil())
        {ESLVal n = $396;
          
          return new ESLVal("new ESLVal(\"").add(n.add(new ESLVal("\",new ESLVal[]{})")));
        }
      else {ESLVal n = $396;
          
          {ESLVal es = $395;
          
          return new ESLVal("new ESLVal(\"").add(n.add(new ESLVal("\",").add(ppJExps(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")")))));
        }
        }
      }
    case "JFun": {ESLVal $394 = _v33.termRef(0);
        ESLVal $393 = _v33.termRef(1);
        ESLVal $392 = _v33.termRef(2);
        ESLVal $391 = _v33.termRef(3);
        
        {ESLVal n = $394;
        
        {ESLVal args = $393;
        
        {ESLVal t = $392;
        
        {ESLVal body = $391;
        
        return ppJFun(indent,dynamics,n,args,t,body);
      }
      }
      }
      }
      }
    case "JBinExp": {ESLVal $390 = _v33.termRef(0);
        ESLVal $389 = _v33.termRef(1);
        ESLVal $388 = _v33.termRef(2);
        
        switch($389.strVal) {
        case "at": {ESLVal e1 = $390;
          
          {ESLVal e2 = $388;
          
          return new ESLVal("at(() -> { return ").add(ppJExp(indent,dynamics,e1).add(new ESLVal("; },() -> { return ").add(ppJExp(indent,dynamics,e2).add(new ESLVal("; })")))));
        }
        }
      case "==": {ESLVal e1 = $390;
          
          {ESLVal e2 = $388;
          
          return ppJExp(indent,dynamics,e1).add(new ESLVal(".equals(").add(ppJExp(indent,dynamics,e2).add(new ESLVal(")"))));
        }
        }
      case "cons": {ESLVal e1 = $390;
          
          {ESLVal e2 = $388;
          
          return ppJExp(indent,dynamics,e2).add(new ESLVal(".cons(").add(ppJExp(indent,dynamics,e1).add(new ESLVal(")"))));
        }
        }
        default: {ESLVal e1 = $390;
          
          {ESLVal op = $389;
          
          {ESLVal e2 = $388;
          
          return ppJExp(indent,dynamics,e1).add(new ESLVal(".").add(op.add(new ESLVal("(").add(ppJExp(indent,dynamics,e2).add(new ESLVal(")"))))));
        }
        }
        }
      }
      }
    case "JCmpExp": {ESLVal $387 = _v33.termRef(0);
        
        {ESLVal c = $387;
        
        return ppJCmp(indent,dynamics,c);
      }
      }
    case "JMethodCall": {ESLVal $386 = _v33.termRef(0);
        ESLVal $385 = _v33.termRef(1);
        
        {ESLVal name = $386;
        
        {ESLVal args = $385;
        
        return name.add(new ESLVal("(").add(ppJExps(indent,dynamics,args,new ESLVal(",")).add(new ESLVal(")"))));
      }
      }
      }
    case "JNull": {
        return new ESLVal("$null");
      }
    case "JNow": {
        return new ESLVal("now()");
      }
    case "JVar": {ESLVal $384 = _v33.termRef(0);
        ESLVal $383 = _v33.termRef(1);
        
        {ESLVal n = $384;
        
        {ESLVal t = $383;
        
        if(member.apply(n,dynamics).boolVal)
        return n.add(new ESLVal("[0]"));
        else
          {ESLVal _v111 = $384;
            
            {ESLVal _v112 = $383;
            
            return _v111;
          }
          }
      }
      }
      }
    case "JError": {ESLVal $382 = _v33.termRef(0);
        
        {ESLVal _v110 = $382;
        
        return new ESLVal("error(").add(ppJExp(indent,dynamics,_v110).add(new ESLVal(")")));
      }
      }
    case "JApply": {ESLVal $381 = _v33.termRef(0);
        ESLVal $380 = _v33.termRef(1);
        
        {ESLVal _v109 = $381;
        
        {ESLVal es = $380;
        
        return ppJExp(indent,dynamics,_v109).add(new ESLVal(".apply(").add(ppJExps(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")"))));
      }
      }
      }
    case "JCommandExp": {ESLVal $379 = _v33.termRef(0);
        ESLVal $378 = _v33.termRef(1);
        
        {ESLVal c = $379;
        
        {ESLVal t = $378;
        
        return new ESLVal("((Supplier<ESLVal>)() -> { ").add(nl(indent.add(new ESLVal(2))).add(ppJCommand(indent.add(new ESLVal(2)),dynamics,c).add(nl(indent).add(new ESLVal("}).get()")))));
      }
      }
      }
    case "JIfExp": {ESLVal $377 = _v33.termRef(0);
        ESLVal $376 = _v33.termRef(1);
        ESLVal $375 = _v33.termRef(2);
        
        {ESLVal _v108 = $377;
        
        {ESLVal e1 = $376;
        
        {ESLVal e2 = $375;
        
        return new ESLVal("(").add(ppJExp(indent,dynamics,_v108).add(new ESLVal(".boolVal) ? (").add(ppJExp(indent,dynamics,e1).add(new ESLVal(") : (").add(ppJExp(indent,dynamics,e2).add(new ESLVal(")")))))));
      }
      }
      }
      }
    case "JHead": {ESLVal $374 = _v33.termRef(0);
        
        {ESLVal _v107 = $374;
        
        return ppJExp(indent,dynamics,_v107).add(new ESLVal(".head()"));
      }
      }
    case "JTail": {ESLVal $373 = _v33.termRef(0);
        
        {ESLVal _v106 = $373;
        
        return ppJExp(indent,dynamics,_v106).add(new ESLVal(".tail()"));
      }
      }
    case "JTermRef": {ESLVal $372 = _v33.termRef(0);
        ESLVal $371 = _v33.termRef(1);
        
        {ESLVal _v105 = $372;
        
        {ESLVal n = $371;
        
        return ppJExp(indent,dynamics,_v105).add(new ESLVal(".termRef(").add(n.add(new ESLVal(")"))));
      }
      }
      }
    case "JMapFun": {ESLVal $370 = _v33.termRef(0);
        ESLVal $369 = _v33.termRef(1);
        
        {ESLVal f = $370;
        
        {ESLVal l = $369;
        
        return ppJExp(indent,dynamics,f).add(new ESLVal(".map(").add(ppJExp(indent,dynamics,l).add(new ESLVal(")"))));
      }
      }
      }
    case "JFlatten": {ESLVal $368 = _v33.termRef(0);
        
        {ESLVal ls = $368;
        
        return ppJExp(indent,dynamics,ls).add(new ESLVal(".flatten()"));
      }
      }
    case "JBehaviour": {ESLVal $363 = _v33.termRef(0);
        ESLVal $362 = _v33.termRef(1);
        ESLVal $361 = _v33.termRef(2);
        ESLVal $360 = _v33.termRef(3);
        ESLVal $359 = _v33.termRef(4);
        ESLVal $358 = _v33.termRef(5);
        
        switch($359.termName) {
        case "JFun": {ESLVal $367 = $359.termRef(0);
          ESLVal $366 = $359.termRef(1);
          ESLVal $365 = $359.termRef(2);
          ESLVal $364 = $359.termRef(3);
          
          {ESLVal es = $363;
          
          {ESLVal fs = $362;
          
          {ESLVal methods = $361;
          
          {ESLVal init = $360;
          
          {ESLVal n = $367;
          
          {ESLVal args = $366;
          
          {ESLVal t = $365;
          
          {ESLVal body = $364;
          
          {ESLVal time = $358;
          
          return new ESLVal("new ESLVal(new BehaviourAdapter(").add(((Supplier<ESLVal>)() -> { 
            if(time.eql(new ESLVal("JBlock",ESLVal.list())).boolVal)
              return new ESLVal("false");
              else
                return new ESLVal("true");
          }).get().add(new ESLVal(",getSelf(),").add(ppJExp(indent,dynamics,n).add(new ESLVal(") {").add(nl(indent.add(new ESLVal(2))).add(ppJFields(indent.add(new ESLVal(2)),dynamics,fs).add(nl(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal handle(ESLVal $m) {").add(ppJCommand(indent.add(new ESLVal(2)),dynamics,body).add(new ESLVal("}").add(nl(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal get(String name) {").add(nl(indent.add(new ESLVal(4))).add(new ESLVal("switch(name) {").add(nl(indent.add(new ESLVal(6))).add(ppJoin(indent.add(new ESLVal(6)),new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal n = $l0.head();
                $l0 = $l0.tail();
                $v.add(new ESLVal("case \"").add(n.add(new ESLVal("\": return ").add(n.add(new ESLVal(";"))))));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(es)).add(nl(indent.add(new ESLVal(6))).add(new ESLVal("default: throw new Error(\"ref illegal \" + self + \".\" + name);").add(nl(indent.add(new ESLVal(4))).add(new ESLVal("}").add(nl(indent.add(new ESLVal(2))).add(new ESLVal("}").add(nl(indent).add(new ESLVal("public void handleTime(ESLVal $t) {").add(nl(indent.add(new ESLVal(2))).add(ppJCommand(indent.add(new ESLVal(2)),dynamics,time).add(nl(indent).add(new ESLVal("}").add(nl(indent).add(new ESLVal("public ESLVal init() {").add(nl(indent.add(new ESLVal(4))).add(new ESLVal("return ").add(ppJExp(indent.add(new ESLVal(6)),dynamics,init).add(new ESLVal(";").add(nl(indent.add(new ESLVal(2))).add(new ESLVal("}").add(nl(indent).add(new ESLVal("})")))))))))))))))))))))))))))))))))))))));
        }
        }
        }
        }
        }
        }
        }
        }
        }
        }
        default: {ESLVal _v104 = _v33;
          
          return new ESLVal("********** unknown expression: ").add(_v104);
        }
      }
      }
    case "JExtendedBehaviour": {ESLVal $353 = _v33.termRef(0);
        ESLVal $352 = _v33.termRef(1);
        ESLVal $351 = _v33.termRef(2);
        ESLVal $350 = _v33.termRef(3);
        ESLVal $349 = _v33.termRef(4);
        ESLVal $348 = _v33.termRef(5);
        ESLVal $347 = _v33.termRef(6);
        
        switch($348.termName) {
        case "JFun": {ESLVal $357 = $348.termRef(0);
          ESLVal $356 = $348.termRef(1);
          ESLVal $355 = $348.termRef(2);
          ESLVal $354 = $348.termRef(3);
          
          {ESLVal es = $353;
          
          {ESLVal parent = $352;
          
          {ESLVal fs = $351;
          
          {ESLVal methods = $350;
          
          {ESLVal init = $349;
          
          {ESLVal n = $357;
          
          {ESLVal args = $356;
          
          {ESLVal t = $355;
          
          {ESLVal body = $354;
          
          {ESLVal time = $347;
          
          return new ESLVal("new ESLVal(new BehaviourAdapter(").add(ppBehaviourParent(indent,dynamics,parent).add(new ESLVal(",").add(((Supplier<ESLVal>)() -> { 
            if(time.eql(new ESLVal("JBlock",ESLVal.list())).boolVal)
              return new ESLVal("false");
              else
                return new ESLVal("true");
          }).get().add(new ESLVal(",getSelf(),").add(ppJExp(indent,dynamics,n).add(new ESLVal(") {").add(nl(indent.add(new ESLVal(2))).add(ppJFields(indent.add(new ESLVal(2)),dynamics,fs).add(nl(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal handle(ESLVal $m) {").add(ppJCommand(indent.add(new ESLVal(2)),dynamics,body).add(new ESLVal("}").add(nl(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal get(String name) {").add(nl(indent.add(new ESLVal(4))).add(new ESLVal("switch(name) {").add(nl(indent.add(new ESLVal(6))).add(ppJoin(indent.add(new ESLVal(6)),new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal n = $l0.head();
                $l0 = $l0.tail();
                $v.add(new ESLVal("case \"").add(n.add(new ESLVal("\": return ").add(n.add(new ESLVal(";"))))));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(es)).add(nl(indent.add(new ESLVal(6))).add(new ESLVal("default: return refSuper(name);").add(nl(indent.add(new ESLVal(4))).add(new ESLVal("}").add(nl(indent.add(new ESLVal(2))).add(new ESLVal("}").add(nl(indent).add(new ESLVal("public void handleTime(ESLVal $t) {").add(nl(indent.add(new ESLVal(2))).add(ppJCommand(indent.add(new ESLVal(2)),dynamics,time).add(nl(indent).add(new ESLVal("}").add(nl(indent).add(new ESLVal("public ESLVal init() {").add(nl(indent.add(new ESLVal(4))).add(new ESLVal("return ").add(ppJExp(indent.add(new ESLVal(6)),dynamics,init).add(new ESLVal(";").add(nl(indent.add(new ESLVal(2))).add(new ESLVal("}").add(nl(indent).add(new ESLVal("})")))))))))))))))))))))))))))))))))))))))));
        }
        }
        }
        }
        }
        }
        }
        }
        }
        }
        }
        default: {ESLVal _v103 = _v33;
          
          return new ESLVal("********** unknown expression: ").add(_v103);
        }
      }
      }
    case "JNew": {ESLVal $344 = _v33.termRef(0);
        ESLVal $343 = _v33.termRef(1);
        
        if($343.isCons())
        {ESLVal $345 = $343.head();
          ESLVal $346 = $343.tail();
          
          {ESLVal b = $344;
          
          {ESLVal args = $343;
          
          return new ESLVal("newActor(").add(ppJExp(indent,dynamics,b).add(new ESLVal(",new ESLVal(new Actor()),").add(ppJExps(indent,dynamics,args,new ESLVal(",")).add(new ESLVal(")")))));
        }
        }
        }
      else if($343.isNil())
        {ESLVal b = $344;
          
          return new ESLVal("newActor(").add(ppJExp(indent,dynamics,b).add(new ESLVal(",new ESLVal(new Actor()))")));
        }
      else {ESLVal b = $344;
          
          {ESLVal args = $343;
          
          return new ESLVal("newActor(").add(ppJExp(indent,dynamics,b).add(new ESLVal(",new ESLVal(new Actor()),").add(ppJExps(indent,dynamics,args,new ESLVal(",")).add(new ESLVal(")")))));
        }
        }
      }
    case "JNewArray": {ESLVal $342 = _v33.termRef(0);
        
        {ESLVal i = $342;
        
        return new ESLVal("newArray(").add(ppJExp(indent,dynamics,i).add(new ESLVal(".intVal)")));
      }
      }
    case "JNewTable": {
        return new ESLVal("newTable()");
      }
    case "JNewJava": {ESLVal $339 = _v33.termRef(0);
        ESLVal $338 = _v33.termRef(1);
        
        if($338.isCons())
        {ESLVal $340 = $338.head();
          ESLVal $341 = $338.tail();
          
          {ESLVal n = $339;
          
          {ESLVal args = $338;
          
          return new ESLVal("newJavaActor(\"").add(n.add(new ESLVal("\",").add(ppJExps(indent,dynamics,args,new ESLVal(",")).add(new ESLVal(")")))));
        }
        }
        }
      else if($338.isNil())
        {ESLVal n = $339;
          
          return new ESLVal("newJavaActor(\"").add(n.add(new ESLVal("\")")));
        }
      else {ESLVal n = $339;
          
          {ESLVal args = $338;
          
          return new ESLVal("newJavaActor(\"").add(n.add(new ESLVal("\",").add(ppJExps(indent,dynamics,args,new ESLVal(",")).add(new ESLVal(")")))));
        }
        }
      }
    case "JRecord": {ESLVal $337 = _v33.termRef(0);
        
        {ESLVal fs = $337;
        
        return new ESLVal("newRecord(new ESLVal[]{").add(ppJExps(indent,dynamics,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v34 = $qualArg;
              
              switch(_v34.termName) {
              case "JField": {ESLVal $423 = _v34.termRef(0);
                ESLVal $422 = _v34.termRef(1);
                ESLVal $421 = _v34.termRef(2);
                
                {ESLVal n = $423;
                
                {ESLVal t = $422;
                
                {ESLVal _v101 = $421;
                
                return ESLVal.list(ESLVal.list(new ESLVal("JConstExp",new ESLVal("JConstStr",n))));
              }
              }
              }
              }
              default: {ESLVal _0 = _v34;
                
                return ESLVal.list();
              }
            }
            }
          }
        }).map(fs).flatten().flatten(),new ESLVal(",")).add(new ESLVal("},").add(ppJExps(indent,dynamics,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v35 = $qualArg;
              
              switch(_v35.termName) {
              case "JField": {ESLVal $426 = _v35.termRef(0);
                ESLVal $425 = _v35.termRef(1);
                ESLVal $424 = _v35.termRef(2);
                
                {ESLVal n = $426;
                
                {ESLVal t = $425;
                
                {ESLVal _v102 = $424;
                
                return ESLVal.list(ESLVal.list(_v102));
              }
              }
              }
              }
              default: {ESLVal _0 = _v35;
                
                return ESLVal.list();
              }
            }
            }
          }
        }).map(fs).flatten().flatten(),new ESLVal(",")).add(new ESLVal(")")))));
      }
      }
    case "JSend": {ESLVal $334 = _v33.termRef(0);
        ESLVal $333 = _v33.termRef(1);
        ESLVal $332 = _v33.termRef(2);
        
        if($332.isCons())
        {ESLVal $335 = $332.head();
          ESLVal $336 = $332.tail();
          
          {ESLVal _v98 = $334;
          
          {ESLVal m = $333;
          
          {ESLVal args = $332;
          
          return new ESLVal("Lib.send(").add(ppJExp(indent,dynamics,_v98).add(new ESLVal(",\"").add(m.add(new ESLVal("\",").add(ppJExps(indent,dynamics,args,new ESLVal(",")).add(new ESLVal(")")))))));
        }
        }
        }
        }
      else if($332.isNil())
        {ESLVal _v99 = $334;
          
          {ESLVal m = $333;
          
          return new ESLVal("Lib.send(").add(ppJExp(indent,dynamics,_v99).add(new ESLVal(",\"").add(m.add(new ESLVal("\")")))));
        }
        }
      else {ESLVal _v100 = $334;
          
          {ESLVal m = $333;
          
          {ESLVal args = $332;
          
          return new ESLVal("Lib.send(").add(ppJExp(indent,dynamics,_v100).add(new ESLVal(",\"").add(m.add(new ESLVal("\",").add(ppJExps(indent,dynamics,args,new ESLVal(",")).add(new ESLVal(")")))))));
        }
        }
        }
      }
    case "JSendSuper": {ESLVal $331 = _v33.termRef(0);
        
        {ESLVal _v97 = $331;
        
        return new ESLVal("sendSuper(").add(ppJExp(indent,dynamics,_v97).add(new ESLVal(")")));
      }
      }
    case "JSendTimeSuper": {
        return new ESLVal("sendTimeSuper($t)");
      }
    case "JSelf": {
        return new ESLVal("getSelf()");
      }
    case "JRef": {ESLVal $330 = _v33.termRef(0);
        ESLVal $329 = _v33.termRef(1);
        
        {ESLVal _v96 = $330;
        
        {ESLVal n = $329;
        
        return ppJExp(indent,dynamics,_v96).add(new ESLVal(".ref(\"").add(n.add(new ESLVal("\")"))));
      }
      }
      }
    case "JRefSuper": {ESLVal $328 = _v33.termRef(0);
        
        {ESLVal n = $328;
        
        return new ESLVal("refSuper(\"").add(n.add(new ESLVal("\")")));
      }
      }
    case "JGrab": {ESLVal $327 = _v33.termRef(0);
        ESLVal $326 = _v33.termRef(1);
        
        {ESLVal es = $327;
        
        {ESLVal c = $326;
        
        return new ESLVal("lock(new Function(new ESLVal(\"grab\"),getSelf()) {").add(nl(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal apply(ESLVal ...args) { ").add(nl(indent.add(new ESLVal(4))).add(new ESLVal("return ").add(ppJExp(indent,dynamics,c).add(new ESLVal(";").add(nl(indent.add(new ESLVal(2))).add(new ESLVal("}},").add(ppJExps(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")")))))))))));
      }
      }
      }
    case "JTry": {ESLVal $325 = _v33.termRef(0);
        ESLVal $324 = _v33.termRef(1);
        ESLVal $323 = _v33.termRef(2);
        
        {ESLVal _v95 = $325;
        
        {ESLVal n = $324;
        
        {ESLVal c = $323;
        
        return new ESLVal("new Function(new ESLVal(\"try\"),getSelf()) {").add(nl(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal apply(ESLVal... args) { ").add(nl(indent.add(new ESLVal(4))).add(new ESLVal("try { ").add(nl(indent.add(new ESLVal(6))).add(new ESLVal("return ").add(ppJExp(indent.add(new ESLVal(4)),dynamics,_v95).add(new ESLVal(";").add(nl(indent.add(new ESLVal(4))).add(new ESLVal("} catch(ESLError $exception) {").add(nl(indent.add(new ESLVal(6))).add(new ESLVal("ESLVal ").add(n.add(new ESLVal(" = $exception.value;").add(nl(indent.add(new ESLVal(6))).add(ppJCommand(indent,dynamics,c).add(nl(indent.add(new ESLVal(4))).add(new ESLVal("}").add(nl(indent.add(new ESLVal(2))).add(new ESLVal("}").add(nl(indent).add(new ESLVal("}.apply()")))))))))))))))))))))));
      }
      }
      }
      }
    case "JProbably": {ESLVal $322 = _v33.termRef(0);
        ESLVal $321 = _v33.termRef(1);
        ESLVal $320 = _v33.termRef(2);
        
        {ESLVal _v94 = $322;
        
        {ESLVal e1 = $321;
        
        {ESLVal e2 = $320;
        
        return new ESLVal("probably(").add(ppJExp(indent,dynamics,_v94).add(new ESLVal(",").add(ppJExp(indent,dynamics,probFun(e1)).add(new ESLVal(",").add(ppJExp(indent,dynamics,probFun(e2)).add(new ESLVal(")")))))));
      }
      }
      }
      }
      default: {ESLVal _v119 = _v33;
        
        return new ESLVal("********** unknown expression: ").add(_v119);
      }
    }
    }
  }
  private static ESLVal ppJExp = new ESLVal(new Function(new ESLVal("ppJExp"),null) { public ESLVal apply(ESLVal... args) { return ppJExp(args[0],args[1],args[2]); }});
  private static ESLVal ppJCmp(ESLVal indent,ESLVal dynamics,ESLVal c) {
    
    { LetRec letrec = new LetRec() {
      ESLVal inner = new ESLVal(new Function(new ESLVal("inner"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v87 = $args[0];
        ESLVal _v88 = $args[1];
        ESLVal _v89 = $args[2];
        {ESLVal _v36 = _v89;
              
              switch(_v36.termName) {
              case "JCmpBind": {ESLVal $432 = _v36.termRef(0);
                ESLVal $431 = _v36.termRef(1);
                ESLVal $430 = _v36.termRef(2);
                
                {ESLVal n = $432;
                
                {ESLVal e = $431;
                
                {ESLVal _v91 = $430;
                
                return new ESLVal("ESLVal $l").add(_v88.add(new ESLVal(" = ").add(ppJExp(_v87,dynamics,e).add(new ESLVal(";").add(nl(_v87).add(new ESLVal("while(!$l").add(_v88.add(new ESLVal(".isNil()) {").add(nl(_v87.add(new ESLVal(2))).add(new ESLVal("ESLVal ").add(n.add(new ESLVal(" = $l").add(_v88.add(new ESLVal(".head();").add(nl(_v87.add(new ESLVal(2))).add(new ESLVal("$l").add(_v88.add(new ESLVal(" = $l").add(_v88.add(new ESLVal(".tail();").add(nl(_v87.add(new ESLVal(2))).add(inner.apply(_v87.add(new ESLVal(2)),_v88.add($one),_v91).add(nl(_v87).add(new ESLVal("}")))))))))))))))))))))))));
              }
              }
              }
              }
            case "JCmpList": {ESLVal $429 = _v36.termRef(0);
                
                {ESLVal e = $429;
                
                return new ESLVal("$v.add(").add(ppJExp(_v87,dynamics,e).add(new ESLVal(");")));
              }
              }
            case "JCmpIf": {ESLVal $428 = _v36.termRef(0);
                ESLVal $427 = _v36.termRef(1);
                
                {ESLVal e = $428;
                
                {ESLVal _v90 = $427;
                
                return new ESLVal("if(").add(ppJExp(_v87,dynamics,e).add(new ESLVal(".boolVal) {").add(inner.apply(_v87,_v88,_v90).add(nl(_v87).add(new ESLVal("}"))))));
              }
              }
              }
              default: return error(new ESLVal("case error at Pos(24454,25055)").add(ESLVal.list(_v36)));
            }
            }
          }
        });
      
      public ESLVal get(String name) {
        switch(name) {
          case "inner": return inner;
          
          default: throw new Error("cannot find letrec binding");
        }
        }
      };
    ESLVal inner = letrec.get("inner");
    
      {ESLVal _v37 = c;
      
      switch(_v37.termName) {
      case "JCmpOuter": {ESLVal $435 = _v37.termRef(0);
        ESLVal $434 = _v37.termRef(1);
        ESLVal $433 = _v37.termRef(2);
        
        {ESLVal n = $435;
        
        {ESLVal e = $434;
        
        {ESLVal _v92 = $433;
        
        return new ESLVal("new java.util.function.Function<ESLVal,ESLVal>() {").add(nl(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal apply(ESLVal $l0) {").add(nl(indent.add(new ESLVal(4))).add(new ESLVal("ESLVal $a = $nil;").add(nl(indent.add(new ESLVal(4))).add(new ESLVal("java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();").add(nl(indent.add(new ESLVal(4))).add(new ESLVal("while(!$l0.isNil()) { ").add(nl(indent.add(new ESLVal(6))).add(new ESLVal("ESLVal ").add(n.add(new ESLVal(" = $l0.head();").add(nl(indent.add(new ESLVal(6))).add(new ESLVal("$l0 = $l0.tail();").add(nl(indent.add(new ESLVal(6))).add(inner.apply(indent,$one,_v92).add(nl(indent.add(new ESLVal(4))).add(new ESLVal("}").add(nl(indent.add(new ESLVal(4))).add(new ESLVal("for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);").add(nl(indent.add(new ESLVal(4))).add(new ESLVal("return $a;").add(nl(indent.add(new ESLVal(2))).add(new ESLVal("}}.apply(").add(ppJExp(indent,dynamics,e).add(new ESLVal(")")))))))))))))))))))))))))));
      }
      }
      }
      }
      default: {ESLVal _v93 = _v37;
        
        return new ESLVal("// Illegal Comprehension ").add(_v93);
      }
    }
    }}
    
  }
  private static ESLVal ppJCmp = new ESLVal(new Function(new ESLVal("ppJCmp"),null) { public ESLVal apply(ESLVal... args) { return ppJCmp(args[0],args[1],args[2]); }});
  private static ESLVal ppBehaviourParent(ESLVal indent,ESLVal dynamics,ESLVal e) {
    
    {ESLVal _v38 = e;
      
      switch(_v38.termName) {
      case "JApply": {ESLVal $437 = _v38.termRef(0);
        ESLVal $436 = _v38.termRef(1);
        
        {ESLVal op = $437;
        
        {ESLVal args = $436;
        
        return new ESLVal("getParent(getSelf(),").add(ppJExp(indent,dynamics,op).add(new ESLVal(",").add(ppJExps(indent,dynamics,args,new ESLVal(",")).add(new ESLVal(")")))));
      }
      }
      }
      default: {ESLVal _v86 = _v38;
        
        return ppJExp(indent,dynamics,_v86);
      }
    }
    }
  }
  private static ESLVal ppBehaviourParent = new ESLVal(new Function(new ESLVal("ppBehaviourParent"),null) { public ESLVal apply(ESLVal... args) { return ppBehaviourParent(args[0],args[1],args[2]); }});
  private static ESLVal probFun(ESLVal e) {
    
    return new ESLVal("JFun",new ESLVal("JConstExp",new ESLVal("JConstStr",new ESLVal("probFun"))),ESLVal.list(),$null,new ESLVal("JReturn",e));
  }
  private static ESLVal probFun = new ESLVal(new Function(new ESLVal("probFun"),null) { public ESLVal apply(ESLVal... args) { return probFun(args[0]); }});
  private static ESLVal ppJFun(ESLVal indent,ESLVal dynamics,ESLVal n,ESLVal args,ESLVal t,ESLVal body) {
    
    {ESLVal freeDynamics = dynamicVarsJCommand.apply(body);
      ESLVal argNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v39 = $qualArg;
              
              switch(_v39.termName) {
              case "JDec": {ESLVal $439 = _v39.termRef(0);
                ESLVal $438 = _v39.termRef(1);
                
                {ESLVal _v82 = $439;
                
                {ESLVal _v83 = $438;
                
                return ESLVal.list(ESLVal.list(_v82));
              }
              }
              }
              default: {ESLVal _0 = _v39;
                
                return ESLVal.list();
              }
            }
            }
          }
        }).map(args).flatten().flatten();
      
      {ESLVal boundDynamics = new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal d = $l0.head();
              $l0 = $l0.tail();
              if(member.apply(d,freeDynamics).boolVal) {$v.add(d);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(argNames);
      
      {ESLVal dom = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v40 = $qualArg;
              
              switch(_v40.termName) {
              case "JDec": {ESLVal $441 = _v40.termRef(0);
                ESLVal $440 = _v40.termRef(1);
                
                {ESLVal _v84 = $441;
                
                {ESLVal _v85 = $440;
                
                return ESLVal.list(ESLVal.list(_v85));
              }
              }
              }
              default: {ESLVal _0 = _v40;
                
                return ESLVal.list();
              }
            }
            }
          }
        }).map(args).flatten().flatten();
      ESLVal ran = t;
      
      return new ESLVal("new ESLVal(new Function(").add(ppJExp(indent,dynamics,n).add(new ESLVal(",getSelf()) {").add(nl(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal apply(ESLVal... $args) {").add(nl(indent.add(new ESLVal(4))).add(ppFunArgs(indent,$zero,args,boundDynamics).add(ppJCommand(indent.add(new ESLVal(4)),boundDynamics.add(new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal d = $l0.head();
            $l0 = $l0.tail();
            if(member.apply(d,argNames).not().boolVal) {$v.add(d);
      }
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(dynamics)),body).add(nl(indent.add(new ESLVal(2))).add(new ESLVal("}").add(nl(indent).add(new ESLVal("})"))))))))))));
    }
    }
    }
  }
  private static ESLVal ppJFun = new ESLVal(new Function(new ESLVal("ppJFun"),null) { public ESLVal apply(ESLVal... args) { return ppJFun(args[0],args[1],args[2],args[3],args[4],args[5]); }});
  private static ESLVal ppFunArgs(ESLVal indent,ESLVal i,ESLVal args,ESLVal dynamicArgs) {
    
    {ESLVal _v41 = args;
      
      if(_v41.isCons())
      {ESLVal $442 = _v41.head();
        ESLVal $443 = _v41.tail();
        
        switch($442.termName) {
        case "JDec": {ESLVal $445 = $442.termRef(0);
          ESLVal $444 = $442.termRef(1);
          
          {ESLVal n = $445;
          
          {ESLVal t = $444;
          
          {ESLVal _v78 = $443;
          
          if(member.apply(n,dynamicArgs).boolVal)
          return new ESLVal("ESLVal[] ").add(n.add(new ESLVal(" = new ESLVal[]{$args[").add(i.add(new ESLVal("]};").add(nl(indent).add(ppFunArgs(indent,i.add($one),_v78,dynamicArgs)))))));
          else
            {ESLVal _v79 = $445;
              
              {ESLVal _v80 = $444;
              
              {ESLVal _v81 = $443;
              
              return new ESLVal("ESLVal ").add(_v79.add(new ESLVal(" = $args[").add(i.add(new ESLVal("];").add(nl(indent).add(ppFunArgs(indent,i.add($one),_v81,dynamicArgs)))))));
            }
            }
            }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(27039,27433)").add(ESLVal.list(_v41)));
      }
      }
    else if(_v41.isNil())
      return new ESLVal("");
    else return error(new ESLVal("case error at Pos(27039,27433)").add(ESLVal.list(_v41)));
    }
  }
  private static ESLVal ppFunArgs = new ESLVal(new Function(new ESLVal("ppFunArgs"),null) { public ESLVal apply(ESLVal... args) { return ppFunArgs(args[0],args[1],args[2],args[3]); }});
  private static ESLVal ppJCommand(ESLVal indent,ESLVal dynamics,ESLVal c) {
    
    {ESLVal _v42 = c;
      
      switch(_v42.termName) {
      case "JIfCommand": {ESLVal $481 = _v42.termRef(0);
        ESLVal $480 = _v42.termRef(1);
        ESLVal $479 = _v42.termRef(2);
        
        {ESLVal e = $481;
        
        {ESLVal c1 = $480;
        
        {ESLVal c2 = $479;
        
        return new ESLVal("if(").add(ppJExp(indent,dynamics,e).add(new ESLVal(".boolVal)").add(nl(indent.add(new ESLVal(2))).add(ppJCommand(indent.add(new ESLVal(2)),dynamics,c1).add(nl(indent.add(new ESLVal(2))).add(new ESLVal("else").add(nl(indent.add(new ESLVal(4))).add(ppJCommand(indent.add(new ESLVal(4)),dynamics,c2)))))))));
      }
      }
      }
      }
    case "JReturn": {ESLVal $476 = _v42.termRef(0);
        
        switch($476.termName) {
        case "JCommandExp": {ESLVal $478 = $476.termRef(0);
          ESLVal $477 = $476.termRef(1);
          
          {ESLVal _v76 = $478;
          
          {ESLVal t = $477;
          
          return ppJCommand(indent,dynamics,_v76);
        }
        }
        }
        default: {ESLVal e = $476;
          
          return new ESLVal("return ").add(ppJExp(indent.add(new ESLVal(2)),dynamics,e).add(new ESLVal(";")));
        }
      }
      }
    case "JCaseList": {ESLVal $475 = _v42.termRef(0);
        ESLVal $474 = _v42.termRef(1);
        ESLVal $473 = _v42.termRef(2);
        ESLVal $472 = _v42.termRef(3);
        
        {ESLVal l = $475;
        
        {ESLVal cons = $474;
        
        {ESLVal nil = $473;
        
        {ESLVal alt = $472;
        
        return new ESLVal("if(").add(ppJExp(indent,dynamics,l).add(new ESLVal(".isCons())").add(nl(indent.add(new ESLVal(2))).add(ppJCommand(indent.add(new ESLVal(2)),dynamics,cons).add(nl(indent).add(new ESLVal("else if(").add(ppJExp(indent,dynamics,l).add(new ESLVal(".isNil())").add(nl(indent.add(new ESLVal(2))).add(ppJCommand(indent.add(new ESLVal(2)),dynamics,nil).add(nl(indent).add(new ESLVal("else ").add(ppJCommand(indent.add(new ESLVal(2)),dynamics,alt))))))))))))));
      }
      }
      }
      }
      }
    case "JCaseTerm": {ESLVal $471 = _v42.termRef(0);
        ESLVal $470 = _v42.termRef(1);
        ESLVal $469 = _v42.termRef(2);
        
        {ESLVal e = $471;
        
        {ESLVal arms = $470;
        
        {ESLVal alt = $469;
        
        return new ESLVal("switch(").add(ppJExp(indent,dynamics,e).add(new ESLVal(".termName) {").add(nl(indent.add(new ESLVal(2))).add(ppJoin(indent,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v50 = $qualArg;
              
              switch(_v50.termName) {
              case "JTArm": {ESLVal $502 = _v50.termRef(0);
                ESLVal $501 = _v50.termRef(1);
                ESLVal $500 = _v50.termRef(2);
                
                {ESLVal n = $502;
                
                {ESLVal i = $501;
                
                {ESLVal _v75 = $500;
                
                return ESLVal.list(ESLVal.list(new ESLVal("case \"").add(n.add(new ESLVal("\": ").add(ppJCommand(indent.add(new ESLVal(2)),dynamics,_v75))))));
              }
              }
              }
              }
              default: {ESLVal _0 = _v50;
                
                return ESLVal.list();
              }
            }
            }
          }
        }).map(arms).flatten().flatten()).add(nl(indent.add(new ESLVal(2))).add(new ESLVal("default: ").add(ppJCommand(indent.add(new ESLVal(2)),dynamics,alt).add(nl(indent).add(new ESLVal("}"))))))))));
      }
      }
      }
      }
    case "JCaseInt": {ESLVal $468 = _v42.termRef(0);
        ESLVal $467 = _v42.termRef(1);
        ESLVal $466 = _v42.termRef(2);
        
        {ESLVal e = $468;
        
        {ESLVal arms = $467;
        
        {ESLVal alt = $466;
        
        return new ESLVal("switch(").add(ppJExp(indent,dynamics,e).add(new ESLVal(".intVal) {").add(nl(indent.add(new ESLVal(2))).add(ppJoin(indent,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v49 = $qualArg;
              
              switch(_v49.termName) {
              case "JIArm": {ESLVal $499 = _v49.termRef(0);
                ESLVal $498 = _v49.termRef(1);
                
                {ESLVal n = $499;
                
                {ESLVal _v74 = $498;
                
                return ESLVal.list(ESLVal.list(new ESLVal("case ").add(n.add(new ESLVal(": ").add(ppJCommand(indent.add(new ESLVal(2)),dynamics,_v74))))));
              }
              }
              }
              default: {ESLVal _0 = _v49;
                
                return ESLVal.list();
              }
            }
            }
          }
        }).map(arms).flatten().flatten()).add(nl(indent.add(new ESLVal(2))).add(new ESLVal("default: ").add(ppJCommand(indent.add(new ESLVal(2)),dynamics,alt).add(nl(indent).add(new ESLVal("}"))))))))));
      }
      }
      }
      }
    case "JCaseStr": {ESLVal $465 = _v42.termRef(0);
        ESLVal $464 = _v42.termRef(1);
        ESLVal $463 = _v42.termRef(2);
        
        {ESLVal e = $465;
        
        {ESLVal arms = $464;
        
        {ESLVal alt = $463;
        
        return new ESLVal("switch(").add(ppJExp(indent,dynamics,e).add(new ESLVal(".strVal) {").add(nl(indent.add(new ESLVal(2))).add(ppJoin(indent,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v48 = $qualArg;
              
              switch(_v48.termName) {
              case "JSArm": {ESLVal $497 = _v48.termRef(0);
                ESLVal $496 = _v48.termRef(1);
                
                {ESLVal s = $497;
                
                {ESLVal _v73 = $496;
                
                return ESLVal.list(ESLVal.list(new ESLVal("case \"").add(s.add(new ESLVal("\": ").add(ppJCommand(indent.add(new ESLVal(2)),dynamics,_v73))))));
              }
              }
              }
              default: {ESLVal _0 = _v48;
                
                return ESLVal.list();
              }
            }
            }
          }
        }).map(arms).flatten().flatten()).add(nl(indent.add(new ESLVal(2))).add(new ESLVal("default: ").add(ppJCommand(indent.add(new ESLVal(2)),dynamics,alt).add(nl(indent).add(new ESLVal("}"))))))))));
      }
      }
      }
      }
    case "JCaseBool": {ESLVal $462 = _v42.termRef(0);
        ESLVal $461 = _v42.termRef(1);
        ESLVal $460 = _v42.termRef(2);
        
        {ESLVal e = $462;
        
        {ESLVal arms = $461;
        
        {ESLVal alt = $460;
        
        return new ESLVal("switch(").add(ppJExp(indent,dynamics,e).add(new ESLVal(".boolVal ? 1 : 0) {").add(nl(indent.add(new ESLVal(2))).add(ppJoin(indent,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v47 = $qualArg;
              
              switch(_v47.termName) {
              case "JBArm": {ESLVal $495 = _v47.termRef(0);
                ESLVal $494 = _v47.termRef(1);
                
                {ESLVal b = $495;
                
                {ESLVal _v72 = $494;
                
                return ESLVal.list(ESLVal.list(new ESLVal("case ").add(((Supplier<ESLVal>)() -> { 
                  if(b.boolVal)
                    return $one;
                    else
                      return $zero;
                }).get().add(new ESLVal(": ").add(ppJCommand(indent.add(new ESLVal(2)),dynamics,_v72))))));
              }
              }
              }
              default: {ESLVal _0 = _v47;
                
                return ESLVal.list();
              }
            }
            }
          }
        }).map(arms).flatten().flatten()).add(nl(indent.add(new ESLVal(2))).add(new ESLVal("default: ").add(ppJCommand(indent.add(new ESLVal(2)),dynamics,alt).add(nl(indent).add(new ESLVal("}"))))))))));
      }
      }
      }
      }
    case "JLet": {ESLVal $459 = _v42.termRef(0);
        ESLVal $458 = _v42.termRef(1);
        
        {ESLVal bs = $459;
        
        {ESLVal _v71 = $458;
        
        {ESLVal boundVars = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v46 = $qualArg;
                
                switch(_v46.termName) {
                case "JField": {ESLVal $493 = _v46.termRef(0);
                  ESLVal $492 = _v46.termRef(1);
                  ESLVal $491 = _v46.termRef(2);
                  
                  {ESLVal n = $493;
                  
                  {ESLVal t = $492;
                  
                  {ESLVal e = $491;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                default: {ESLVal _0 = _v46;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(bs).flatten().flatten();
        ESLVal dynamicVars = dynamicVarsJCommand.apply(_v71);
        
        {ESLVal boundDynamicVars = filter.apply(new ESLVal(new Function(new ESLVal("fun317"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal s = $args[0];
          return member.apply(s,dynamicVars);
            }
          }),boundVars);
        
        return new ESLVal("{").add(ppJFields(indent.add(new ESLVal(2)),dynamics.add(boundDynamicVars),bs).add(nl(indent.add(new ESLVal(2))).add(ppJCommand(indent,dynamics.add(boundDynamicVars),_v71).add(nl(indent).add(new ESLVal("}"))))));
      }
      }
      }
      }
      }
    case "JLetRec": {ESLVal $457 = _v42.termRef(0);
        ESLVal $456 = _v42.termRef(1);
        
        {ESLVal bs = $457;
        
        {ESLVal _v70 = $456;
        
        return new ESLVal("{ LetRec letrec = new LetRec() {").add(nl(indent.add(new ESLVal(2))).add(ppJFields(indent.add(new ESLVal(2)),dynamics,bs).add(nl(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal get(String name) {").add(nl(indent.add(new ESLVal(4))).add(new ESLVal("switch(name) {").add(nl(indent.add(new ESLVal(6))).add(ppJoin(indent.add(new ESLVal(6)),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v44 = $qualArg;
              
              switch(_v44.termName) {
              case "JField": {ESLVal $487 = _v44.termRef(0);
                ESLVal $486 = _v44.termRef(1);
                ESLVal $485 = _v44.termRef(2);
                
                {ESLVal n = $487;
                
                {ESLVal t = $486;
                
                {ESLVal e = $485;
                
                return ESLVal.list(ESLVal.list(new ESLVal("case \"").add(n.add(new ESLVal("\": return ").add(n.add(new ESLVal(";").add(nl(indent.add(new ESLVal(6))))))))));
              }
              }
              }
              }
              default: {ESLVal _0 = _v44;
                
                return ESLVal.list();
              }
            }
            }
          }
        }).map(bs).flatten().flatten()).add(nl(indent.add(new ESLVal(6))).add(new ESLVal("default: throw new Error(\"cannot find letrec binding\");").add(nl(indent.add(new ESLVal(4))).add(new ESLVal("}").add(nl(indent.add(new ESLVal(4))).add(new ESLVal("}").add(nl(indent.add(new ESLVal(2))).add(new ESLVal("};").add(nl(indent).add(ppJoin(indent,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v45 = $qualArg;
              
              switch(_v45.termName) {
              case "JField": {ESLVal $490 = _v45.termRef(0);
                ESLVal $489 = _v45.termRef(1);
                ESLVal $488 = _v45.termRef(2);
                
                {ESLVal n = $490;
                
                {ESLVal t = $489;
                
                {ESLVal e = $488;
                
                return ESLVal.list(ESLVal.list(new ESLVal("ESLVal ").add(n.add(new ESLVal(" = letrec.get(\"").add(n.add(new ESLVal("\");").add(nl(indent))))))));
              }
              }
              }
              }
              default: {ESLVal _0 = _v45;
                
                return ESLVal.list();
              }
            }
            }
          }
        }).map(bs).flatten().flatten()).add(nl(indent.add(new ESLVal(2))).add(ppJCommand(indent,dynamics,_v70).add(new ESLVal("}").add(nl(indent)))))))))))))))))))))));
      }
      }
      }
    case "JPLet": {ESLVal $455 = _v42.termRef(0);
        ESLVal $454 = _v42.termRef(1);
        
        {ESLVal bs = $455;
        
        {ESLVal _v69 = $454;
        
        {ESLVal boundVars = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v43 = $qualArg;
                
                switch(_v43.termName) {
                case "JField": {ESLVal $484 = _v43.termRef(0);
                  ESLVal $483 = _v43.termRef(1);
                  ESLVal $482 = _v43.termRef(2);
                  
                  {ESLVal n = $484;
                  
                  {ESLVal t = $483;
                  
                  {ESLVal e = $482;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                default: {ESLVal _0 = _v43;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(bs).flatten().flatten();
        ESLVal dynamicVars = dynamicVarsJCommand.apply(_v69);
        
        {ESLVal boundDynamicVars = filter.apply(new ESLVal(new Function(new ESLVal("fun318"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal s = $args[0];
          return member.apply(s,dynamicVars);
            }
          }),boundVars);
        
        return new ESLVal("{").add(ppJParFields(indent.add(new ESLVal(2)),dynamics.add(boundDynamicVars),bs).add(nl(indent.add(new ESLVal(2))).add(ppJCommand(indent,dynamics.add(boundDynamicVars),_v69).add(nl(indent).add(new ESLVal("}"))))));
      }
      }
      }
      }
      }
    case "JBlock": {ESLVal $453 = _v42.termRef(0);
        
        {ESLVal cs = $453;
        
        return new ESLVal("{").add(ppJoin(indent,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal c = $l0.head();
              $l0 = $l0.tail();
              $v.add(ppJCommand(indent,dynamics,c));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(cs)).add(new ESLVal("}")));
      }
      }
    case "JUpdate": {ESLVal $452 = _v42.termRef(0);
        ESLVal $451 = _v42.termRef(1);
        
        {ESLVal n = $452;
        
        {ESLVal e = $451;
        
        if(member.apply(n,dynamics).boolVal)
        return n.add(new ESLVal("[0] = ").add(ppJExp(indent,dynamics,e).add(new ESLVal(";"))));
        else
          {ESLVal _v67 = $452;
            
            {ESLVal _v68 = $451;
            
            return _v67.add(new ESLVal(" = ").add(ppJExp(indent,dynamics,_v68).add(new ESLVal(";"))));
          }
          }
      }
      }
      }
    case "JFor": {ESLVal $450 = _v42.termRef(0);
        ESLVal $449 = _v42.termRef(1);
        ESLVal $448 = _v42.termRef(2);
        ESLVal $447 = _v42.termRef(3);
        
        {ESLVal listName = $450;
        
        {ESLVal varName = $449;
        
        {ESLVal e = $448;
        
        {ESLVal _v66 = $447;
        
        return new ESLVal("{").add(nl(indent.add(new ESLVal(2))).add(new ESLVal("ESLVal ").add(listName.add(new ESLVal(" = ").add(ppJExp(indent.add(new ESLVal(2)),dynamics,e).add(new ESLVal(";").add(nl(indent.add(new ESLVal(2))).add(new ESLVal("while(").add(listName.add(new ESLVal(".isCons()) {").add(nl(indent.add(new ESLVal(4))).add(new ESLVal("ESLVal ").add(varName.add(new ESLVal(" = ").add(listName.add(new ESLVal(".headVal;").add(nl(indent.add(new ESLVal(4))).add(ppJCommand(indent.add(new ESLVal(4)),dynamics,_v66).add(nl(indent.add(new ESLVal(4))).add(listName.add(new ESLVal(" = ").add(listName.add(new ESLVal(".tailVal;").add(new ESLVal("}").add(nl(indent).add(new ESLVal("}")))))))))))))))))))))))))));
      }
      }
      }
      }
      }
    case "JStatement": {ESLVal $446 = _v42.termRef(0);
        
        {ESLVal e = $446;
        
        return ppJExp(indent,dynamics,e).add(new ESLVal(";"));
      }
      }
      default: {ESLVal _v77 = _v42;
        
        return new ESLVal("******* unknown command: ").add(_v77);
      }
    }
    }
  }
  private static ESLVal ppJCommand = new ESLVal(new Function(new ESLVal("ppJCommand"),null) { public ESLVal apply(ESLVal... args) { return ppJCommand(args[0],args[1],args[2]); }});
  private static ESLVal ppJParFields(ESLVal indent,ESLVal dynamics,ESLVal bs) {
    
    { LetRec letrec = new LetRec() {
      ESLVal vals = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v51 = $qualArg;
              
              switch(_v51.termName) {
              case "JField": {ESLVal $505 = _v51.termRef(0);
                ESLVal $504 = _v51.termRef(1);
                ESLVal $503 = _v51.termRef(2);
                
                {ESLVal n = $505;
                
                {ESLVal t = $504;
                
                {ESLVal e = $503;
                
                return ESLVal.list(ESLVal.list(e));
              }
              }
              }
              }
              default: {ESLVal _0 = _v51;
                
                return ESLVal.list();
              }
            }
            }
          }
        }).map(bs).flatten().flatten();
      ESLVal names = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v52 = $qualArg;
              
              switch(_v52.termName) {
              case "JField": {ESLVal $508 = _v52.termRef(0);
                ESLVal $507 = _v52.termRef(1);
                ESLVal $506 = _v52.termRef(2);
                
                {ESLVal n = $508;
                
                {ESLVal t = $507;
                
                {ESLVal e = $506;
                
                return ESLVal.list(ESLVal.list(n));
              }
              }
              }
              }
              default: {ESLVal _0 = _v52;
                
                return ESLVal.list();
              }
            }
            }
          }
        }).map(bs).flatten().flatten();
      ESLVal doVals = new ESLVal(new Function(new ESLVal("doVals"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal vals = $args[0];
        {ESLVal _v53 = vals;
              
              if(_v53.isCons())
              {ESLVal $509 = _v53.head();
                ESLVal $510 = _v53.tail();
                
                if($510.isCons())
                {ESLVal $511 = $510.head();
                  ESLVal $512 = $510.tail();
                  
                  {ESLVal v = $509;
                  
                  {ESLVal vs = $510;
                  
                  return new ESLVal("() -> ").add(ppJExp(indent,dynamics,v).add(new ESLVal(",").add(doVals.apply(vs))));
                }
                }
                }
              else if($510.isNil())
                {ESLVal v = $509;
                  
                  return new ESLVal("() -> ").add(ppJExp(indent,dynamics,v));
                }
              else {ESLVal v = $509;
                  
                  {ESLVal vs = $510;
                  
                  return new ESLVal("() -> ").add(ppJExp(indent,dynamics,v).add(new ESLVal(",").add(doVals.apply(vs))));
                }
                }
              }
            else if(_v53.isNil())
              return new ESLVal("");
            else return error(new ESLVal("case error at Pos(32554,32717)").add(ESLVal.list(_v53)));
            }
          }
        });
      ESLVal bindNames = new ESLVal(new Function(new ESLVal("bindNames"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal ns = $args[0];
        ESLVal i = $args[1];
        {ESLVal _v54 = ns;
              
              if(_v54.isCons())
              {ESLVal $513 = _v54.head();
                ESLVal $514 = _v54.tail();
                
                {ESLVal n = $513;
                
                {ESLVal _v63 = $514;
                
                if(member.apply(n,dynamics).boolVal)
                return new ESLVal("ESLVal[] ").add(n.add(new ESLVal("= new ESLVal[]{$p[").add(i.add(new ESLVal("]};").add(nl(indent).add(bindNames.apply(_v63,i.add($one))))))));
                else
                  {ESLVal _v64 = $513;
                    
                    {ESLVal _v65 = $514;
                    
                    return new ESLVal("ESLVal ").add(_v64.add(new ESLVal("= $p[").add(i.add(new ESLVal("];").add(nl(indent).add(bindNames.apply(_v65,i.add($one))))))));
                  }
                  }
              }
              }
              }
            else if(_v54.isNil())
              return new ESLVal("");
            else return error(new ESLVal("case error at Pos(32763,33013)").add(ESLVal.list(_v54)));
            }
          }
        });
      
      public ESLVal get(String name) {
        switch(name) {
          case "vals": return vals;
          
          case "names": return names;
          
          case "doVals": return doVals;
          
          case "bindNames": return bindNames;
          
          default: throw new Error("cannot find letrec binding");
        }
        }
      };
    ESLVal vals = letrec.get("vals");
    
    ESLVal names = letrec.get("names");
    
    ESLVal doVals = letrec.get("doVals");
    
    ESLVal bindNames = letrec.get("bindNames");
    
      return new ESLVal("ESLVal[] $p = plet(new Supplier[]{").add(doVals.apply(vals).add(new ESLVal("});").add(nl(indent).add(bindNames.apply(names,$zero)))));}
    
  }
  private static ESLVal ppJParFields = new ESLVal(new Function(new ESLVal("ppJParFields"),null) { public ESLVal apply(ESLVal... args) { return ppJParFields(args[0],args[1],args[2]); }});
  private static ESLVal ppJFields(ESLVal indent,ESLVal dynamics,ESLVal bs) {
    
    {ESLVal _v55 = bs;
      
      if(_v55.isCons())
      {ESLVal $515 = _v55.head();
        ESLVal $516 = _v55.tail();
        
        {ESLVal f = $515;
        
        {ESLVal _v62 = $516;
        
        return ppFieldDef(indent,dynamics,f).add(nl(indent).add(ppJFields(indent,dynamics,_v62)));
      }
      }
      }
    else if(_v55.isNil())
      return new ESLVal("");
    else return error(new ESLVal("case error at Pos(33182,33332)").add(ESLVal.list(_v55)));
    }
  }
  private static ESLVal ppJFields = new ESLVal(new Function(new ESLVal("ppJFields"),null) { public ESLVal apply(ESLVal... args) { return ppJFields(args[0],args[1],args[2]); }});
  private static ESLVal ppFieldDef(ESLVal indent,ESLVal dynamics,ESLVal f) {
    
    {ESLVal _v56 = f;
      
      switch(_v56.termName) {
      case "JField": {ESLVal $519 = _v56.termRef(0);
        ESLVal $518 = _v56.termRef(1);
        ESLVal $517 = _v56.termRef(2);
        
        {ESLVal n = $519;
        
        {ESLVal t = $518;
        
        {ESLVal e = $517;
        
        if(member.apply(n,dynamics).boolVal)
        return new ESLVal("ESLVal[] ").add(n.add(new ESLVal(" = new ESLVal[]{").add(ppJExp(indent.add(new ESLVal(2)),dynamics,e).add(new ESLVal("};")))));
        else
          {ESLVal _v59 = $519;
            
            {ESLVal _v60 = $518;
            
            {ESLVal _v61 = $517;
            
            return new ESLVal("ESLVal ").add(_v59.add(new ESLVal(" = ").add(ppJExp(indent.add(new ESLVal(2)),dynamics,_v61).add(new ESLVal(";")))));
          }
          }
          }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(33396,33650)").add(ESLVal.list(_v56)));
    }
    }
  }
  private static ESLVal ppFieldDef = new ESLVal(new Function(new ESLVal("ppFieldDef"),null) { public ESLVal apply(ESLVal... args) { return ppFieldDef(args[0],args[1],args[2]); }});
  private static ESLVal ppJListExp(ESLVal indent,ESLVal dynamics,ESLVal t,ESLVal es) {
    
    return new ESLVal("ESLVal.list(").add(ppJExps(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")")));
  }
  private static ESLVal ppJListExp = new ESLVal(new Function(new ESLVal("ppJListExp"),null) { public ESLVal apply(ESLVal... args) { return ppJListExp(args[0],args[1],args[2],args[3]); }});
  private static ESLVal ppJSetExp(ESLVal indent,ESLVal dynamics,ESLVal t,ESLVal es) {
    
    return new ESLVal("ESLVal.set(").add(ppJExps(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")")));
  }
  private static ESLVal ppJSetExp = new ESLVal(new Function(new ESLVal("ppJSetExp"),null) { public ESLVal apply(ESLVal... args) { return ppJSetExp(args[0],args[1],args[2],args[3]); }});
  private static ESLVal ppJBagExp(ESLVal indent,ESLVal dynamics,ESLVal t,ESLVal es) {
    
    return new ESLVal("ESLVal.bag(").add(ppJExps(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")")));
  }
  private static ESLVal ppJBagExp = new ESLVal(new Function(new ESLVal("ppJBagExp"),null) { public ESLVal apply(ESLVal... args) { return ppJBagExp(args[0],args[1],args[2],args[3]); }});
public static ESLVal main = new ESLVal(new Function(new ESLVal("main"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      return new ESLVal(new BehaviourAdapter(true,getSelf(),new ESLVal("main")) {
          
          public ESLVal handle(ESLVal $m) {{ESLVal _v58 = $m;
            
            return error(new ESLVal("case error at Pos(0,0)").add(ESLVal.list(_v58)));
          }}
          public ESLVal get(String name) {
            switch(name) {
              
              default: throw new Error("ref illegal " + self + "." + name);
            }
          }
        public void handleTime(ESLVal $t) {
          {ESLVal t = $t;
            
            if($true.boolVal)
            {new Function(new ESLVal("try"),getSelf()) {
              public ESLVal apply(ESLVal... args) { 
                try { 
                  return print.apply(ppExp($zero,parse.apply(new ESLVal("esl/compiler/test1.esl"))));
                } catch(ESLError $exception) {
                  ESLVal $x = $exception.value;
                  {ESLVal _v57 = $x;
              
              {ESLVal message = _v57;
              
              return print.apply(new ESLVal("PP Error: ").add(message));
            }
            }
                }
              }
            }.apply();
            print.apply(new ESLVal("DONE"));
            stopAll.apply();}
            else
              {}
          }
        }
        public ESLVal init() {
            return $null;
          }
        });
    }
  });
public static void main(String[] args) {
    newActor(main,new ESLVal(new Actor())); 
  }
}