package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
import static esl.Tables.*;
// import static esl.Lists.*;
import static esl.compiler.Cases.*;
import static esl.compiler.Types.*;
import java.util.function.Supplier;
public class ToJava {
  public static ESLVal getSelf() { return $null; }
  private static ESLVal defToField = new ESLVal(new Function(new ESLVal("defToField"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d = $args[0];
  {ESLVal _v1904 = d;
        
        switch(_v1904.termName) {
        case "Binding": {ESLVal $2329 = _v1904.termRef(0);
          ESLVal $2328 = _v1904.termRef(1);
          ESLVal $2327 = _v1904.termRef(2);
          ESLVal $2326 = _v1904.termRef(3);
          ESLVal $2325 = _v1904.termRef(4);
          
          {ESLVal l = $2329;
          
          {ESLVal n = $2328;
          
          {ESLVal t = $2327;
          
          {ESLVal st = $2326;
          
          {ESLVal e = $2325;
          
          return new ESLVal("JField",n,$null,expToJExp.apply(e));
        }
        }
        }
        }
        }
        }
      case "FunBind": {ESLVal $2322 = _v1904.termRef(0);
          ESLVal $2321 = _v1904.termRef(1);
          ESLVal $2320 = _v1904.termRef(2);
          ESLVal $2319 = _v1904.termRef(3);
          ESLVal $2318 = _v1904.termRef(4);
          ESLVal $2317 = _v1904.termRef(5);
          ESLVal $2316 = _v1904.termRef(6);
          
          switch($2316.termName) {
          case "BoolExp": {ESLVal $2324 = $2316.termRef(0);
            ESLVal $2323 = $2316.termRef(1);
            
            switch($2323.boolVal ? 1 : 0) {
            case 1: {ESLVal l = $2322;
              
              {ESLVal n = $2321;
              
              {ESLVal args = $2320;
              
              {ESLVal t = $2319;
              
              {ESLVal st = $2318;
              
              {ESLVal e = $2317;
              
              {ESLVal bl = $2324;
              
              {ESLVal formals = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal $qualArg = $args[0];
                {ESLVal _v1905 = $qualArg;
                      
                      switch(_v1905.termName) {
                      case "PVar": {ESLVal $2332 = _v1905.termRef(0);
                        ESLVal $2331 = _v1905.termRef(1);
                        ESLVal $2330 = _v1905.termRef(2);
                        
                        {ESLVal _v2043 = $2332;
                        
                        {ESLVal _v2044 = $2331;
                        
                        {ESLVal _v2045 = $2330;
                        
                        return ESLVal.list(ESLVal.list(new ESLVal("Dec",_v2043,_v2044,_v2045,st)));
                      }
                      }
                      }
                      }
                      default: {ESLVal _0 = _v1905;
                        
                        return ESLVal.list();
                      }
                    }
                    }
                  }
                }).map(args).flatten().flatten();
              
              return new ESLVal("JField",n,$null,expToJExp.apply(new ESLVal("FunExp",l,new ESLVal("StrExp",l,n),formals,t,e)));
            }
            }
            }
            }
            }
            }
            }
            }
            default: {ESLVal l = $2322;
              
              {ESLVal n = $2321;
              
              {ESLVal args = $2320;
              
              {ESLVal t = $2319;
              
              {ESLVal st = $2318;
              
              {ESLVal e = $2317;
              
              {ESLVal g = $2316;
              
              {ESLVal formals = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal $qualArg = $args[0];
                {ESLVal _v1906 = $qualArg;
                      
                      switch(_v1906.termName) {
                      case "PVar": {ESLVal $2335 = _v1906.termRef(0);
                        ESLVal $2334 = _v1906.termRef(1);
                        ESLVal $2333 = _v1906.termRef(2);
                        
                        {ESLVal _v2046 = $2335;
                        
                        {ESLVal _v2047 = $2334;
                        
                        {ESLVal _v2048 = $2333;
                        
                        return ESLVal.list(ESLVal.list(new ESLVal("Dec",_v2046,_v2047,_v2048,st)));
                      }
                      }
                      }
                      }
                      default: {ESLVal _0 = _v1906;
                        
                        return ESLVal.list();
                      }
                    }
                    }
                  }
                }).map(args).flatten().flatten();
              
              return new ESLVal("JField",n,$null,expToJExp.apply(new ESLVal("FunExp",l,new ESLVal("StrExp",l,n),formals,t,new ESLVal("If",l,g,e,new ESLVal("Throw",l,t,new ESLVal("StrExp",l,new ESLVal("guard failed for ").add(n)))))));
            }
            }
            }
            }
            }
            }
            }
            }
          }
          }
          default: {ESLVal l = $2322;
            
            {ESLVal n = $2321;
            
            {ESLVal args = $2320;
            
            {ESLVal t = $2319;
            
            {ESLVal st = $2318;
            
            {ESLVal e = $2317;
            
            {ESLVal g = $2316;
            
            {ESLVal formals = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v1907 = $qualArg;
                    
                    switch(_v1907.termName) {
                    case "PVar": {ESLVal $2338 = _v1907.termRef(0);
                      ESLVal $2337 = _v1907.termRef(1);
                      ESLVal $2336 = _v1907.termRef(2);
                      
                      {ESLVal _v2049 = $2338;
                      
                      {ESLVal _v2050 = $2337;
                      
                      {ESLVal _v2051 = $2336;
                      
                      return ESLVal.list(ESLVal.list(new ESLVal("Dec",_v2049,_v2050,_v2051,st)));
                    }
                    }
                    }
                    }
                    default: {ESLVal _0 = _v1907;
                      
                      return ESLVal.list();
                    }
                  }
                  }
                }
              }).map(args).flatten().flatten();
            
            return new ESLVal("JField",n,$null,expToJExp.apply(new ESLVal("FunExp",l,new ESLVal("StrExp",l,n),formals,t,new ESLVal("If",l,g,e,new ESLVal("Throw",l,t,new ESLVal("StrExp",l,new ESLVal("guard failed for ").add(n)))))));
          }
          }
          }
          }
          }
          }
          }
          }
        }
        }
        default: return error(new ESLVal("case error at Pos(172,825)").add(ESLVal.list(_v1904)));
      }
      }
    }
  });
  private static ESLVal decToJDec = new ESLVal(new Function(new ESLVal("decToJDec"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d = $args[0];
  {ESLVal _v1908 = d;
        
        switch(_v1908.termName) {
        case "Dec": {ESLVal $2342 = _v1908.termRef(0);
          ESLVal $2341 = _v1908.termRef(1);
          ESLVal $2340 = _v1908.termRef(2);
          ESLVal $2339 = _v1908.termRef(3);
          
          {ESLVal l = $2342;
          
          {ESLVal n = $2341;
          
          {ESLVal t = $2340;
          
          {ESLVal st = $2339;
          
          return new ESLVal("JDec",n,$null);
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(869,945)").add(ESLVal.list(_v1908)));
      }
      }
    }
  });
  private static ESLVal expsToJCommands = new ESLVal(new Function(new ESLVal("expsToJCommands"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal cs = $args[0];
  ESLVal isLast = $args[1];
  {ESLVal _v1909 = cs;
        
        if(_v1909.isCons())
        {ESLVal $2343 = _v1909.head();
          ESLVal $2344 = _v1909.tail();
          
          if($2344.isCons())
          {ESLVal $2345 = $2344.head();
            ESLVal $2346 = $2344.tail();
            
            {ESLVal c = $2343;
            
            {ESLVal _v2041 = $2344;
            
            return expsToJCommands.apply(_v2041,isLast).cons(expToJCommand.apply(c,$false));
          }
          }
          }
        else if($2344.isNil())
          {ESLVal c = $2343;
            
            return ESLVal.list(expToJCommand.apply(c,isLast));
          }
        else {ESLVal c = $2343;
            
            {ESLVal _v2042 = $2344;
            
            return expsToJCommands.apply(_v2042,isLast).cons(expToJCommand.apply(c,$false));
          }
          }
        }
      else if(_v1909.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(1004,1164)").add(ESLVal.list(_v1909)));
      }
    }
  });
  private static ESLVal expToJCommand = new ESLVal(new Function(new ESLVal("expToJCommand"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal c = $args[0];
  ESLVal isLast = $args[1];
  {ESLVal _v1910 = c;
        
        switch(_v1910.termName) {
        case "Block": {ESLVal $2392 = _v1910.termRef(0);
          ESLVal $2391 = _v1910.termRef(1);
          
          if($2391.isCons())
          {ESLVal $2393 = $2391.head();
            ESLVal $2394 = $2391.tail();
            
            if($2394.isCons())
            {ESLVal $2395 = $2394.head();
              ESLVal $2396 = $2394.tail();
              
              {ESLVal l = $2392;
              
              {ESLVal es = $2391;
              
              return new ESLVal("JBlock",new java.util.function.Function<ESLVal,ESLVal>() {
                public ESLVal apply(ESLVal $l0) {
                  ESLVal $a = $nil;
                  java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                  while(!$l0.isNil()) { 
                    ESLVal e = $l0.head();
                    $l0 = $l0.tail();
                    $v.add(expToJCommand.apply(e,$false));
                  }
                  for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                  return $a;
                }}.apply(butlast.apply(es)).add(ESLVal.list(expToJCommand.apply(last.apply(es),isLast))));
            }
            }
            }
          else if($2394.isNil())
            {ESLVal l = $2392;
              
              {ESLVal e = $2393;
              
              return expToJCommand.apply(e,isLast);
            }
            }
          else {ESLVal l = $2392;
              
              {ESLVal es = $2391;
              
              return new ESLVal("JBlock",new java.util.function.Function<ESLVal,ESLVal>() {
                public ESLVal apply(ESLVal $l0) {
                  ESLVal $a = $nil;
                  java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                  while(!$l0.isNil()) { 
                    ESLVal e = $l0.head();
                    $l0 = $l0.tail();
                    $v.add(expToJCommand.apply(e,$false));
                  }
                  for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                  return $a;
                }}.apply(butlast.apply(es)).add(ESLVal.list(expToJCommand.apply(last.apply(es),isLast))));
            }
            }
          }
        else if($2391.isNil())
          {ESLVal l = $2392;
            
            if(isLast.boolVal)
            return new ESLVal("JReturn",new ESLVal("JNull",new ESLVal[]{}));
            else
              {ESLVal _v2039 = $2392;
                
                return new ESLVal("JBlock",$nil);
              }
          }
        else {ESLVal l = $2392;
            
            {ESLVal es = $2391;
            
            return new ESLVal("JBlock",new java.util.function.Function<ESLVal,ESLVal>() {
              public ESLVal apply(ESLVal $l0) {
                ESLVal $a = $nil;
                java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                while(!$l0.isNil()) { 
                  ESLVal e = $l0.head();
                  $l0 = $l0.tail();
                  $v.add(expToJCommand.apply(e,$false));
                }
                for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                return $a;
              }}.apply(butlast.apply(es)).add(ESLVal.list(expToJCommand.apply(last.apply(es),isLast))));
          }
          }
        }
      case "Update": {ESLVal $2390 = _v1910.termRef(0);
          ESLVal $2389 = _v1910.termRef(1);
          ESLVal $2388 = _v1910.termRef(2);
          
          {ESLVal l = $2390;
          
          {ESLVal n = $2389;
          
          {ESLVal e = $2388;
          
          if(isLast.boolVal)
          return new ESLVal("JBlock",ESLVal.list(new ESLVal("JUpdate",n,expToJExp.apply(e)),new ESLVal("JReturn",new ESLVal("JNull",new ESLVal[]{}))));
          else
            {ESLVal _v2036 = $2390;
              
              {ESLVal _v2037 = $2389;
              
              {ESLVal _v2038 = $2388;
              
              return new ESLVal("JUpdate",_v2037,expToJExp.apply(_v2038));
            }
            }
            }
        }
        }
        }
        }
      case "If": {ESLVal $2387 = _v1910.termRef(0);
          ESLVal $2386 = _v1910.termRef(1);
          ESLVal $2385 = _v1910.termRef(2);
          ESLVal $2384 = _v1910.termRef(3);
          
          {ESLVal l = $2387;
          
          {ESLVal e1 = $2386;
          
          {ESLVal e2 = $2385;
          
          {ESLVal e3 = $2384;
          
          return new ESLVal("JIfCommand",expToJExp.apply(e1),expToJCommand.apply(e2,isLast),expToJCommand.apply(e3,isLast));
        }
        }
        }
        }
        }
      case "CaseList": {ESLVal $2383 = _v1910.termRef(0);
          ESLVal $2382 = _v1910.termRef(1);
          ESLVal $2381 = _v1910.termRef(2);
          ESLVal $2380 = _v1910.termRef(3);
          ESLVal $2379 = _v1910.termRef(4);
          
          {ESLVal l = $2383;
          
          {ESLVal e = $2382;
          
          {ESLVal cons = $2381;
          
          {ESLVal nil = $2380;
          
          {ESLVal alt = $2379;
          
          return new ESLVal("JCaseList",expToJExp.apply(e),expToJCommand.apply(cons,isLast),expToJCommand.apply(nil,isLast),expToJCommand.apply(alt,isLast));
        }
        }
        }
        }
        }
        }
      case "CaseTerm": {ESLVal $2378 = _v1910.termRef(0);
          ESLVal $2377 = _v1910.termRef(1);
          ESLVal $2376 = _v1910.termRef(2);
          ESLVal $2375 = _v1910.termRef(3);
          
          {ESLVal l = $2378;
          
          {ESLVal e = $2377;
          
          {ESLVal arms = $2376;
          
          {ESLVal alt = $2375;
          
          return new ESLVal("JCaseTerm",expToJExp.apply(e),termArmsToJTermArms.apply(arms,isLast),expToJCommand.apply(alt,isLast));
        }
        }
        }
        }
        }
      case "CaseInt": {ESLVal $2374 = _v1910.termRef(0);
          ESLVal $2373 = _v1910.termRef(1);
          ESLVal $2372 = _v1910.termRef(2);
          ESLVal $2371 = _v1910.termRef(3);
          
          {ESLVal l = $2374;
          
          {ESLVal e = $2373;
          
          {ESLVal arms = $2372;
          
          {ESLVal alt = $2371;
          
          return new ESLVal("JCaseInt",expToJExp.apply(e),intArmsToJIntArms.apply(arms,isLast),expToJCommand.apply(alt,isLast));
        }
        }
        }
        }
        }
      case "CaseStr": {ESLVal $2370 = _v1910.termRef(0);
          ESLVal $2369 = _v1910.termRef(1);
          ESLVal $2368 = _v1910.termRef(2);
          ESLVal $2367 = _v1910.termRef(3);
          
          {ESLVal l = $2370;
          
          {ESLVal e = $2369;
          
          {ESLVal arms = $2368;
          
          {ESLVal alt = $2367;
          
          return new ESLVal("JCaseStr",expToJExp.apply(e),strArmsToJStrArms.apply(arms,isLast),expToJCommand.apply(alt,isLast));
        }
        }
        }
        }
        }
      case "CaseBool": {ESLVal $2366 = _v1910.termRef(0);
          ESLVal $2365 = _v1910.termRef(1);
          ESLVal $2364 = _v1910.termRef(2);
          ESLVal $2363 = _v1910.termRef(3);
          
          {ESLVal l = $2366;
          
          {ESLVal e = $2365;
          
          {ESLVal arms = $2364;
          
          {ESLVal alt = $2363;
          
          return new ESLVal("JCaseBool",expToJExp.apply(e),boolArmsToJBoolArms.apply(arms,isLast),expToJCommand.apply(alt,isLast));
        }
        }
        }
        }
        }
      case "Let": {ESLVal $2362 = _v1910.termRef(0);
          ESLVal $2361 = _v1910.termRef(1);
          ESLVal $2360 = _v1910.termRef(2);
          
          {ESLVal l = $2362;
          
          {ESLVal bs = $2361;
          
          {ESLVal e = $2360;
          
          return new ESLVal("JLet",new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal b = $l0.head();
                $l0 = $l0.tail();
                $v.add(defToField.apply(b));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(bs),expToJCommand.apply(e,isLast));
        }
        }
        }
        }
      case "Letrec": {ESLVal $2359 = _v1910.termRef(0);
          ESLVal $2358 = _v1910.termRef(1);
          ESLVal $2357 = _v1910.termRef(2);
          
          {ESLVal l = $2359;
          
          {ESLVal bs = $2358;
          
          {ESLVal e = $2357;
          
          return new ESLVal("JLetRec",new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal b = $l0.head();
                $l0 = $l0.tail();
                $v.add(defToField.apply(b));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(bs),expToJCommand.apply(e,$true));
        }
        }
        }
        }
      case "For": {ESLVal $2353 = _v1910.termRef(0);
          ESLVal $2352 = _v1910.termRef(1);
          ESLVal $2351 = _v1910.termRef(2);
          ESLVal $2350 = _v1910.termRef(3);
          
          switch($2352.termName) {
          case "PVar": {ESLVal $2356 = $2352.termRef(0);
            ESLVal $2355 = $2352.termRef(1);
            ESLVal $2354 = $2352.termRef(2);
            
            {ESLVal l1 = $2353;
            
            {ESLVal l2 = $2356;
            
            {ESLVal n = $2355;
            
            {ESLVal t = $2354;
            
            {ESLVal e = $2351;
            
            {ESLVal b = $2350;
            
            if(isLast.boolVal)
            return new ESLVal("JBlock",ESLVal.list(new ESLVal("JFor",newName.apply(),n,expToJExp.apply(e),expToJCommand.apply(b,$false)),new ESLVal("JReturn",new ESLVal("JNull",new ESLVal[]{}))));
            else
              {ESLVal _v2030 = $2353;
                
                {ESLVal _v2031 = $2356;
                
                {ESLVal _v2032 = $2355;
                
                {ESLVal _v2033 = $2354;
                
                {ESLVal _v2034 = $2351;
                
                {ESLVal _v2035 = $2350;
                
                return new ESLVal("JFor",newName.apply(),_v2032,expToJExp.apply(_v2034),expToJCommand.apply(_v2035,$false));
              }
              }
              }
              }
              }
              }
          }
          }
          }
          }
          }
          }
          }
          default: {ESLVal l = $2353;
            
            {ESLVal p = $2352;
            
            {ESLVal e = $2351;
            
            {ESLVal b = $2350;
            
            {ESLVal opName = newName.apply();
            ESLVal varName = newName.apply();
            
            return expToJCommand.apply(new ESLVal("For",l,new ESLVal("PVar",l,varName,$null),e,new ESLVal("Let",l,ESLVal.list(new ESLVal("Binding",l,opName,$null,$null,new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("forp")),ESLVal.list(),$null,new ESLVal("Case",l,$nil,ESLVal.list(new ESLVal("Var",l,varName)),ESLVal.list(new ESLVal("BArm",l,ESLVal.list(p),new ESLVal("BoolExp",l,$true),b),new ESLVal("BArm",l,ESLVal.list(new ESLVal("PVar",l,new ESLVal("$$$"),$null)),new ESLVal("BoolExp",l,$true),new ESLVal("Block",l,ESLVal.list()))))))),new ESLVal("Apply",l,new ESLVal("Var",l,opName),ESLVal.list()))),isLast);
          }
          }
          }
          }
          }
        }
        }
      case "PLet": {ESLVal $2349 = _v1910.termRef(0);
          ESLVal $2348 = _v1910.termRef(1);
          ESLVal $2347 = _v1910.termRef(2);
          
          {ESLVal l = $2349;
          
          {ESLVal bs = $2348;
          
          {ESLVal e = $2347;
          
          return new ESLVal("JPLet",new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal b = $l0.head();
                $l0 = $l0.tail();
                $v.add(defToField.apply(b));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(bs),expToJCommand.apply(e,isLast));
        }
        }
        }
        }
        default: {ESLVal e = _v1910;
          
          if(isLast.boolVal)
          return new ESLVal("JReturn",expToJExp.apply(e));
          else
            {ESLVal _v2040 = _v1910;
              
              return new ESLVal("JStatement",expToJExp.apply(_v2040));
            }
        }
      }
      }
    }
  });
  private static ESLVal expsToJExps = new ESLVal(new Function(new ESLVal("expsToJExps"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal es = $args[0];
  return map.apply(new ESLVal(new Function(new ESLVal("fun398"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal e = $args[0];
        return expToJExp.apply(e);
          }
        }),es);
    }
  });
  private static ESLVal termArmsToJTermArms = new ESLVal(new Function(new ESLVal("termArmsToJTermArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  ESLVal isLast = $args[1];
  {ESLVal _v1911 = arms;
        
        if(_v1911.isCons())
        {ESLVal $2397 = _v1911.head();
          ESLVal $2398 = _v1911.tail();
          
          switch($2397.termName) {
          case "TArm": {ESLVal $2400 = $2397.termRef(0);
            ESLVal $2399 = $2397.termRef(1);
            
            {ESLVal n = $2400;
            
            {ESLVal e = $2399;
            
            {ESLVal _v2029 = $2398;
            
            return termArmsToJTermArms.apply(_v2029,isLast).cons(new ESLVal("JTArm",n,$zero,expToJCommand.apply(e,isLast)));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(4499,4668)").add(ESLVal.list(_v1911)));
        }
        }
      else if(_v1911.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(4499,4668)").add(ESLVal.list(_v1911)));
      }
    }
  });
  private static ESLVal intArmsToJIntArms = new ESLVal(new Function(new ESLVal("intArmsToJIntArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  ESLVal isLast = $args[1];
  {ESLVal _v1912 = arms;
        
        if(_v1912.isCons())
        {ESLVal $2401 = _v1912.head();
          ESLVal $2402 = _v1912.tail();
          
          switch($2401.termName) {
          case "IArm": {ESLVal $2404 = $2401.termRef(0);
            ESLVal $2403 = $2401.termRef(1);
            
            {ESLVal n = $2404;
            
            {ESLVal e = $2403;
            
            {ESLVal _v2028 = $2402;
            
            return intArmsToJIntArms.apply(_v2028,isLast).cons(new ESLVal("JIArm",n,expToJCommand.apply(e,isLast)));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(4737,4901)").add(ESLVal.list(_v1912)));
        }
        }
      else if(_v1912.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(4737,4901)").add(ESLVal.list(_v1912)));
      }
    }
  });
  private static ESLVal strArmsToJStrArms = new ESLVal(new Function(new ESLVal("strArmsToJStrArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  ESLVal isLast = $args[1];
  {ESLVal _v1913 = arms;
        
        if(_v1913.isCons())
        {ESLVal $2405 = _v1913.head();
          ESLVal $2406 = _v1913.tail();
          
          switch($2405.termName) {
          case "SArm": {ESLVal $2408 = $2405.termRef(0);
            ESLVal $2407 = $2405.termRef(1);
            
            {ESLVal s = $2408;
            
            {ESLVal e = $2407;
            
            {ESLVal _v2027 = $2406;
            
            return strArmsToJStrArms.apply(_v2027,isLast).cons(new ESLVal("JSArm",s,expToJCommand.apply(e,isLast)));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(4970,5134)").add(ESLVal.list(_v1913)));
        }
        }
      else if(_v1913.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(4970,5134)").add(ESLVal.list(_v1913)));
      }
    }
  });
  private static ESLVal boolArmsToJBoolArms = new ESLVal(new Function(new ESLVal("boolArmsToJBoolArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  ESLVal isLast = $args[1];
  {ESLVal _v1914 = arms;
        
        if(_v1914.isCons())
        {ESLVal $2409 = _v1914.head();
          ESLVal $2410 = _v1914.tail();
          
          switch($2409.termName) {
          case "BoolArm": {ESLVal $2412 = $2409.termRef(0);
            ESLVal $2411 = $2409.termRef(1);
            
            {ESLVal b = $2412;
            
            {ESLVal e = $2411;
            
            {ESLVal _v2026 = $2410;
            
            return boolArmsToJBoolArms.apply(_v2026,isLast).cons(new ESLVal("JBArm",b,expToJCommand.apply(e,isLast)));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(5209,5382)").add(ESLVal.list(_v1914)));
        }
        }
      else if(_v1914.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(5209,5382)").add(ESLVal.list(_v1914)));
      }
    }
  });
  private static ESLVal opToJOp = new ESLVal(new Function(new ESLVal("opToJOp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal op = $args[0];
  {ESLVal _v1915 = op;
        
        switch(_v1915.strVal) {
        case "@": return new ESLVal("at");
      case "+": return new ESLVal("add");
      case "-": return new ESLVal("sub");
      case "*": return new ESLVal("mul");
      case "/": return new ESLVal("div");
      case "%": return new ESLVal("mod");
      case ">": return new ESLVal("gre");
      case ">=": return new ESLVal("greql");
      case "<": return new ESLVal("less");
      case "<=": return new ESLVal("lesseql");
      case "=": return new ESLVal("eql");
      case "<>": return new ESLVal("neql");
      case ":": return new ESLVal("cons");
      case "..": return new ESLVal("to");
      case "or": return new ESLVal("or");
      case "and": return new ESLVal("and");
      case "andalso": return new ESLVal("andalso");
      case "orelse": return new ESLVal("orelse");
        default: return error(new ESLVal("case error at Pos(5410,5779)").add(ESLVal.list(_v1915)));
      }
      }
    }
  });
  private static ESLVal caseToJExp = new ESLVal(new Function(new ESLVal("caseToJExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  {ESLVal bindings = new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal e = $l0.head();
                $l0 = $l0.tail();
                $v.add(new ESLVal("Binding",l,newName.apply(),$null,$null,e));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(es);
        
        {ESLVal names = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1916 = $qualArg;
                
                switch(_v1916.termName) {
                case "Binding": {ESLVal $2417 = _v1916.termRef(0);
                  ESLVal $2416 = _v1916.termRef(1);
                  ESLVal $2415 = _v1916.termRef(2);
                  ESLVal $2414 = _v1916.termRef(3);
                  ESLVal $2413 = _v1916.termRef(4);
                  
                  {ESLVal _v2025 = $2417;
                  
                  {ESLVal n = $2416;
                  
                  {ESLVal dt = $2415;
                  
                  {ESLVal t = $2414;
                  
                  {ESLVal e = $2413;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _0 = _v1916;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(bindings).flatten().flatten();
        
        return expToJExp.apply(new ESLVal("Let",l,bindings,translateCases.apply(new ESLVal("Case",l,ESLVal.list(),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal n = $l0.head();
              $l0 = $l0.tail();
              $v.add(new ESLVal("Var",l,n));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(names),arms))));
      }
      }
    }
  });
  private static ESLVal expToJExp = new ESLVal(new Function(new ESLVal("expToJExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  {ESLVal _v1917 = e;
        
        switch(_v1917.termName) {
        case "Apply": {ESLVal $2598 = _v1917.termRef(0);
          ESLVal $2597 = _v1917.termRef(1);
          ESLVal $2596 = _v1917.termRef(2);
          
          {ESLVal l = $2598;
          
          {ESLVal op = $2597;
          
          {ESLVal args = $2596;
          
          return new ESLVal("JApply",expToJExp.apply(op),expsToJExps.apply(args));
        }
        }
        }
        }
      case "ArrayUpdate": {ESLVal $2595 = _v1917.termRef(0);
          ESLVal $2594 = _v1917.termRef(1);
          ESLVal $2593 = _v1917.termRef(2);
          ESLVal $2592 = _v1917.termRef(3);
          
          {ESLVal l = $2595;
          
          {ESLVal a = $2594;
          
          {ESLVal i = $2593;
          
          {ESLVal v = $2592;
          
          return new ESLVal("JArrayUpdate",expToJExp.apply(a),expToJExp.apply(i),expToJExp.apply(v));
        }
        }
        }
        }
        }
      case "ArrayRef": {ESLVal $2591 = _v1917.termRef(0);
          ESLVal $2590 = _v1917.termRef(1);
          ESLVal $2589 = _v1917.termRef(2);
          
          {ESLVal l = $2591;
          
          {ESLVal a = $2590;
          
          {ESLVal i = $2589;
          
          return new ESLVal("JArrayRef",expToJExp.apply(a),expToJExp.apply(i));
        }
        }
        }
        }
      case "IntExp": {ESLVal $2588 = _v1917.termRef(0);
          ESLVal $2587 = _v1917.termRef(1);
          
          {ESLVal l = $2588;
          
          {ESLVal n = $2587;
          
          return new ESLVal("JConstExp",new ESLVal("JConstInt",n));
        }
        }
        }
      case "StrExp": {ESLVal $2586 = _v1917.termRef(0);
          ESLVal $2585 = _v1917.termRef(1);
          
          {ESLVal l = $2586;
          
          {ESLVal s = $2585;
          
          return new ESLVal("JConstExp",new ESLVal("JConstStr",s));
        }
        }
        }
      case "BoolExp": {ESLVal $2584 = _v1917.termRef(0);
          ESLVal $2583 = _v1917.termRef(1);
          
          {ESLVal l = $2584;
          
          {ESLVal b = $2583;
          
          return new ESLVal("JConstExp",new ESLVal("JConstBool",b));
        }
        }
        }
      case "FloatExp": {ESLVal $2582 = _v1917.termRef(0);
          ESLVal $2581 = _v1917.termRef(1);
          
          {ESLVal l = $2582;
          
          {ESLVal f = $2581;
          
          return new ESLVal("JConstExp",new ESLVal("JConstDouble",f));
        }
        }
        }
      case "ApplyTypeExp": {ESLVal $2567 = _v1917.termRef(0);
          ESLVal $2566 = _v1917.termRef(1);
          ESLVal $2565 = _v1917.termRef(2);
          
          switch($2566.termName) {
          case "List": {ESLVal $2574 = $2566.termRef(0);
            ESLVal $2573 = $2566.termRef(1);
            
            if($2573.isCons())
            {ESLVal $2575 = $2573.head();
              ESLVal $2576 = $2573.tail();
              
              {ESLVal l = $2567;
              
              {ESLVal _v2018 = $2566;
              
              {ESLVal ts = $2565;
              
              return expToJExp.apply(_v2018);
            }
            }
            }
            }
          else if($2573.isNil())
            if($2565.isCons())
              {ESLVal $2577 = $2565.head();
                ESLVal $2578 = $2565.tail();
                
                if($2578.isCons())
                {ESLVal $2579 = $2578.head();
                  ESLVal $2580 = $2578.tail();
                  
                  {ESLVal l = $2567;
                  
                  {ESLVal _v2019 = $2566;
                  
                  {ESLVal ts = $2565;
                  
                  return expToJExp.apply(_v2019);
                }
                }
                }
                }
              else if($2578.isNil())
                {ESLVal l1 = $2567;
                  
                  {ESLVal l2 = $2574;
                  
                  {ESLVal t = $2577;
                  
                  return new ESLVal("JNil",$null);
                }
                }
                }
              else {ESLVal l = $2567;
                  
                  {ESLVal _v2020 = $2566;
                  
                  {ESLVal ts = $2565;
                  
                  return expToJExp.apply(_v2020);
                }
                }
                }
              }
            else if($2565.isNil())
              {ESLVal l = $2567;
                
                {ESLVal _v2021 = $2566;
                
                {ESLVal ts = $2565;
                
                return expToJExp.apply(_v2021);
              }
              }
              }
            else {ESLVal l = $2567;
                
                {ESLVal _v2022 = $2566;
                
                {ESLVal ts = $2565;
                
                return expToJExp.apply(_v2022);
              }
              }
              }
          else {ESLVal l = $2567;
              
              {ESLVal _v2023 = $2566;
              
              {ESLVal ts = $2565;
              
              return expToJExp.apply(_v2023);
            }
            }
            }
          }
        case "NullExp": {ESLVal $2568 = $2566.termRef(0);
            
            if($2565.isCons())
            {ESLVal $2569 = $2565.head();
              ESLVal $2570 = $2565.tail();
              
              if($2570.isCons())
              {ESLVal $2571 = $2570.head();
                ESLVal $2572 = $2570.tail();
                
                {ESLVal l = $2567;
                
                {ESLVal _v2014 = $2566;
                
                {ESLVal ts = $2565;
                
                return expToJExp.apply(_v2014);
              }
              }
              }
              }
            else if($2570.isNil())
              {ESLVal l1 = $2567;
                
                {ESLVal l2 = $2568;
                
                {ESLVal t = $2569;
                
                return new ESLVal("JNull",new ESLVal[]{});
              }
              }
              }
            else {ESLVal l = $2567;
                
                {ESLVal _v2015 = $2566;
                
                {ESLVal ts = $2565;
                
                return expToJExp.apply(_v2015);
              }
              }
              }
            }
          else if($2565.isNil())
            {ESLVal l = $2567;
              
              {ESLVal _v2016 = $2566;
              
              {ESLVal ts = $2565;
              
              return expToJExp.apply(_v2016);
            }
            }
            }
          else {ESLVal l = $2567;
              
              {ESLVal _v2017 = $2566;
              
              {ESLVal ts = $2565;
              
              return expToJExp.apply(_v2017);
            }
            }
            }
          }
          default: {ESLVal l = $2567;
            
            {ESLVal _v2024 = $2566;
            
            {ESLVal ts = $2565;
            
            return expToJExp.apply(_v2024);
          }
          }
          }
        }
        }
      case "List": {ESLVal $2564 = _v1917.termRef(0);
          ESLVal $2563 = _v1917.termRef(1);
          
          {ESLVal l = $2564;
          
          {ESLVal es = $2563;
          
          return new ESLVal("JList",$null,expsToJExps.apply(es));
        }
        }
        }
      case "SetExp": {ESLVal $2562 = _v1917.termRef(0);
          ESLVal $2561 = _v1917.termRef(1);
          
          {ESLVal l = $2562;
          
          {ESLVal es = $2561;
          
          return new ESLVal("JSet",$null,expsToJExps.apply(es));
        }
        }
        }
      case "BagExp": {ESLVal $2560 = _v1917.termRef(0);
          ESLVal $2559 = _v1917.termRef(1);
          
          {ESLVal l = $2560;
          
          {ESLVal es = $2559;
          
          return new ESLVal("JBag",$null,expsToJExps.apply(es));
        }
        }
        }
      case "Term": {ESLVal $2558 = _v1917.termRef(0);
          ESLVal $2557 = _v1917.termRef(1);
          ESLVal $2556 = _v1917.termRef(2);
          ESLVal $2555 = _v1917.termRef(3);
          
          {ESLVal l = $2558;
          
          {ESLVal n = $2557;
          
          {ESLVal ts = $2556;
          
          {ESLVal es = $2555;
          
          return new ESLVal("JTerm",n,expsToJExps.apply(es));
        }
        }
        }
        }
        }
      case "Case": {ESLVal $2554 = _v1917.termRef(0);
          ESLVal $2553 = _v1917.termRef(1);
          ESLVal $2552 = _v1917.termRef(2);
          ESLVal $2551 = _v1917.termRef(3);
          
          {ESLVal l = $2554;
          
          {ESLVal ds = $2553;
          
          {ESLVal es = $2552;
          
          {ESLVal arms = $2551;
          
          return caseToJExp.apply(l,es,arms);
        }
        }
        }
        }
        }
      case "CaseAdd": {ESLVal $2550 = _v1917.termRef(0);
          ESLVal $2549 = _v1917.termRef(1);
          ESLVal $2548 = _v1917.termRef(2);
          ESLVal $2547 = _v1917.termRef(3);
          
          {ESLVal l = $2550;
          
          {ESLVal s = $2549;
          
          {ESLVal handler = $2548;
          
          {ESLVal fail = $2547;
          
          return expToJExp.apply(new ESLVal("Apply",l,new ESLVal("Var",l,new ESLVal("$ndCase")),ESLVal.list(s,handler,fail)));
        }
        }
        }
        }
        }
      case "CaseList": {ESLVal $2546 = _v1917.termRef(0);
          ESLVal $2545 = _v1917.termRef(1);
          ESLVal $2544 = _v1917.termRef(2);
          ESLVal $2543 = _v1917.termRef(3);
          ESLVal $2542 = _v1917.termRef(4);
          
          {ESLVal l = $2546;
          
          {ESLVal list = $2545;
          
          {ESLVal cons = $2544;
          
          {ESLVal nil = $2543;
          
          {ESLVal alt = $2542;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
        }
        }
      case "CaseTerm": {ESLVal $2541 = _v1917.termRef(0);
          ESLVal $2540 = _v1917.termRef(1);
          ESLVal $2539 = _v1917.termRef(2);
          ESLVal $2538 = _v1917.termRef(3);
          
          {ESLVal l = $2541;
          
          {ESLVal list = $2540;
          
          {ESLVal arms = $2539;
          
          {ESLVal alt = $2538;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
        }
      case "CaseStr": {ESLVal $2537 = _v1917.termRef(0);
          ESLVal $2536 = _v1917.termRef(1);
          ESLVal $2535 = _v1917.termRef(2);
          ESLVal $2534 = _v1917.termRef(3);
          
          {ESLVal l = $2537;
          
          {ESLVal s = $2536;
          
          {ESLVal arms = $2535;
          
          {ESLVal alt = $2534;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
        }
      case "CaseBool": {ESLVal $2533 = _v1917.termRef(0);
          ESLVal $2532 = _v1917.termRef(1);
          ESLVal $2531 = _v1917.termRef(2);
          ESLVal $2530 = _v1917.termRef(3);
          
          {ESLVal l = $2533;
          
          {ESLVal s = $2532;
          
          {ESLVal arms = $2531;
          
          {ESLVal alt = $2530;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
        }
      case "CaseSet": {ESLVal $2529 = _v1917.termRef(0);
          ESLVal $2528 = _v1917.termRef(1);
          ESLVal $2527 = _v1917.termRef(2);
          ESLVal $2526 = _v1917.termRef(3);
          
          {ESLVal l = $2529;
          
          {ESLVal s = $2528;
          
          {ESLVal handler = $2527;
          
          {ESLVal fail = $2526;
          
          return expToJExp.apply(new ESLVal("Apply",l,new ESLVal("Var",l,new ESLVal("$ndCase")),ESLVal.list(s,handler,fail)));
        }
        }
        }
        }
        }
      case "Head": {ESLVal $2525 = _v1917.termRef(0);
          
          {ESLVal _v2013 = $2525;
          
          return new ESLVal("JHead",expToJExp.apply(_v2013));
        }
        }
      case "Tail": {ESLVal $2524 = _v1917.termRef(0);
          
          {ESLVal _v2012 = $2524;
          
          return new ESLVal("JTail",expToJExp.apply(_v2012));
        }
        }
      case "CaseError": {ESLVal $2523 = _v1917.termRef(0);
          ESLVal $2522 = _v1917.termRef(1);
          
          {ESLVal l = $2523;
          
          {ESLVal _v2011 = $2522;
          
          return new ESLVal("JError",new ESLVal("JBinExp",new ESLVal("JConstExp",new ESLVal("JConstStr",new ESLVal("case error at ").add(l))),new ESLVal("add"),expToJExp.apply(_v2011)));
        }
        }
        }
      case "NullExp": {ESLVal $2521 = _v1917.termRef(0);
          
          {ESLVal l = $2521;
          
          return new ESLVal("JNull",new ESLVal[]{});
        }
        }
      case "Var": {ESLVal $2520 = _v1917.termRef(0);
          ESLVal $2519 = _v1917.termRef(1);
          
          {ESLVal l = $2520;
          
          {ESLVal n = $2519;
          
          return new ESLVal("JVar",n,$null);
        }
        }
        }
      case "Let": {ESLVal $2518 = _v1917.termRef(0);
          ESLVal $2517 = _v1917.termRef(1);
          ESLVal $2516 = _v1917.termRef(2);
          
          {ESLVal l = $2518;
          
          {ESLVal bs = $2517;
          
          {ESLVal body = $2516;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
      case "Letrec": {ESLVal $2515 = _v1917.termRef(0);
          ESLVal $2514 = _v1917.termRef(1);
          ESLVal $2513 = _v1917.termRef(2);
          
          {ESLVal l = $2515;
          
          {ESLVal bs = $2514;
          
          {ESLVal body = $2513;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
      case "Throw": {ESLVal $2512 = _v1917.termRef(0);
          ESLVal $2511 = _v1917.termRef(1);
          ESLVal $2510 = _v1917.termRef(2);
          
          {ESLVal l = $2512;
          
          {ESLVal t = $2511;
          
          {ESLVal _v2010 = $2510;
          
          return new ESLVal("JError",expToJExp.apply(_v2010));
        }
        }
        }
        }
      case "BinExp": {ESLVal $2509 = _v1917.termRef(0);
          ESLVal $2508 = _v1917.termRef(1);
          ESLVal $2507 = _v1917.termRef(2);
          ESLVal $2506 = _v1917.termRef(3);
          
          {ESLVal l = $2509;
          
          {ESLVal e1 = $2508;
          
          {ESLVal op = $2507;
          
          {ESLVal e2 = $2506;
          
          return new ESLVal("JBinExp",expToJExp.apply(e1),opToJOp.apply(op),expToJExp.apply(e2));
        }
        }
        }
        }
        }
      case "Become": {ESLVal $2502 = _v1917.termRef(0);
          ESLVal $2501 = _v1917.termRef(1);
          
          switch($2501.termName) {
          case "Apply": {ESLVal $2505 = $2501.termRef(0);
            ESLVal $2504 = $2501.termRef(1);
            ESLVal $2503 = $2501.termRef(2);
            
            {ESLVal l = $2502;
            
            {ESLVal al = $2505;
            
            {ESLVal b = $2504;
            
            {ESLVal args = $2503;
            
            return new ESLVal("JBecome",expToJExp.apply(b),expsToJExps.apply(args));
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(6137,14761)").add(ESLVal.list(_v1917)));
        }
        }
      case "Block": {ESLVal $2496 = _v1917.termRef(0);
          ESLVal $2495 = _v1917.termRef(1);
          
          if($2495.isCons())
          {ESLVal $2497 = $2495.head();
            ESLVal $2498 = $2495.tail();
            
            if($2498.isCons())
            {ESLVal $2499 = $2498.head();
              ESLVal $2500 = $2498.tail();
              
              {ESLVal l = $2496;
              
              {ESLVal es = $2495;
              
              return new ESLVal("JCommandExp",new ESLVal("JBlock",expsToJCommands.apply(es,$true)),$null);
            }
            }
            }
          else if($2498.isNil())
            {ESLVal l = $2496;
              
              {ESLVal _v2009 = $2497;
              
              return expToJExp.apply(_v2009);
            }
            }
          else {ESLVal l = $2496;
              
              {ESLVal es = $2495;
              
              return new ESLVal("JCommandExp",new ESLVal("JBlock",expsToJCommands.apply(es,$true)),$null);
            }
            }
          }
        else if($2495.isNil())
          {ESLVal l = $2496;
            
            return new ESLVal("JNull",new ESLVal[]{});
          }
        else {ESLVal l = $2496;
            
            {ESLVal es = $2495;
            
            return new ESLVal("JCommandExp",new ESLVal("JBlock",expsToJCommands.apply(es,$true)),$null);
          }
          }
        }
      case "If": {ESLVal $2494 = _v1917.termRef(0);
          ESLVal $2493 = _v1917.termRef(1);
          ESLVal $2492 = _v1917.termRef(2);
          ESLVal $2491 = _v1917.termRef(3);
          
          {ESLVal l = $2494;
          
          {ESLVal e1 = $2493;
          
          {ESLVal e2 = $2492;
          
          {ESLVal e3 = $2491;
          
          return new ESLVal("JCommandExp",new ESLVal("JIfCommand",expToJExp.apply(e1),expToJCommand.apply(e2,$true),expToJCommand.apply(e3,$true)),$null);
        }
        }
        }
        }
        }
      case "FunExp": {ESLVal $2490 = _v1917.termRef(0);
          ESLVal $2489 = _v1917.termRef(1);
          ESLVal $2488 = _v1917.termRef(2);
          ESLVal $2487 = _v1917.termRef(3);
          ESLVal $2486 = _v1917.termRef(4);
          
          {ESLVal l = $2490;
          
          {ESLVal n = $2489;
          
          {ESLVal args = $2488;
          
          {ESLVal t = $2487;
          
          {ESLVal body = $2486;
          
          return new ESLVal("JFun",expToJExp.apply(n),map.apply(new ESLVal(new Function(new ESLVal("fun399"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal d = $args[0];
          return decToJDec.apply(d);
            }
          }),args),new ESLVal("JFunType",new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal a = $l0.head();
                $l0 = $l0.tail();
                $v.add($null);
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(args),$null),expToJCommand.apply(body,$true));
        }
        }
        }
        }
        }
        }
      case "TermRef": {ESLVal $2485 = _v1917.termRef(0);
          ESLVal $2484 = _v1917.termRef(1);
          
          {ESLVal _v2008 = $2485;
          
          {ESLVal i = $2484;
          
          return new ESLVal("JTermRef",expToJExp.apply(_v2008),i);
        }
        }
        }
      case "Cmp": {ESLVal $2483 = _v1917.termRef(0);
          ESLVal $2482 = _v1917.termRef(1);
          ESLVal $2481 = _v1917.termRef(2);
          
          {ESLVal l = $2483;
          
          {ESLVal _v2004 = $2482;
          
          {ESLVal qs = $2481;
          
          if(exists.apply(isBindingQualifier,qs).and(forall.apply(isSimpleQualifier,qs)).boolVal)
          return new ESLVal("JCmpExp",cmpToJCmp.apply(_v2004,qs));
          else
            {ESLVal _v2005 = $2483;
              
              {ESLVal _v2006 = $2482;
              
              {ESLVal _v2007 = $2481;
              
              return cmpToJExp.apply(_v2006,_v2007);
            }
            }
            }
        }
        }
        }
        }
      case "Not": {ESLVal $2480 = _v1917.termRef(0);
          ESLVal $2479 = _v1917.termRef(1);
          
          {ESLVal l = $2480;
          
          {ESLVal _v2003 = $2479;
          
          return new ESLVal("JNot",expToJExp.apply(_v2003));
        }
        }
        }
      case "New": {ESLVal $2478 = _v1917.termRef(0);
          ESLVal $2477 = _v1917.termRef(1);
          ESLVal $2476 = _v1917.termRef(2);
          
          {ESLVal l = $2478;
          
          {ESLVal b = $2477;
          
          {ESLVal args = $2476;
          
          return new ESLVal("JNew",expToJExp.apply(b),expsToJExps.apply(args));
        }
        }
        }
        }
      case "NewArray": {ESLVal $2475 = _v1917.termRef(0);
          ESLVal $2474 = _v1917.termRef(1);
          ESLVal $2473 = _v1917.termRef(2);
          
          {ESLVal l = $2475;
          
          {ESLVal t = $2474;
          
          {ESLVal i = $2473;
          
          return new ESLVal("JNewArray",expToJExp.apply(i));
        }
        }
        }
        }
      case "NewJava": {ESLVal $2472 = _v1917.termRef(0);
          ESLVal $2471 = _v1917.termRef(1);
          ESLVal $2470 = _v1917.termRef(2);
          ESLVal $2469 = _v1917.termRef(3);
          
          {ESLVal l = $2472;
          
          {ESLVal n = $2471;
          
          {ESLVal t = $2470;
          
          {ESLVal args = $2469;
          
          return new ESLVal("JNewJava",n,expsToJExps.apply(args));
        }
        }
        }
        }
        }
      case "NewTable": {ESLVal $2468 = _v1917.termRef(0);
          ESLVal $2467 = _v1917.termRef(1);
          ESLVal $2466 = _v1917.termRef(2);
          
          {ESLVal l = $2468;
          
          {ESLVal key = $2467;
          
          {ESLVal value = $2466;
          
          return new ESLVal("JNewTable",new ESLVal[]{});
        }
        }
        }
        }
      case "Record": {ESLVal $2465 = _v1917.termRef(0);
          ESLVal $2464 = _v1917.termRef(1);
          
          {ESLVal l = $2465;
          
          {ESLVal fs = $2464;
          
          return new ESLVal("JRecord",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1918 = $qualArg;
                
                switch(_v1918.termName) {
                case "Binding": {ESLVal $2603 = _v1918.termRef(0);
                  ESLVal $2602 = _v1918.termRef(1);
                  ESLVal $2601 = _v1918.termRef(2);
                  ESLVal $2600 = _v1918.termRef(3);
                  ESLVal $2599 = _v1918.termRef(4);
                  
                  {ESLVal bl = $2603;
                  
                  {ESLVal n = $2602;
                  
                  {ESLVal t = $2601;
                  
                  {ESLVal dt = $2600;
                  
                  {ESLVal _v2002 = $2599;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",n,$null,expToJExp.apply(_v2002))));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _0 = _v1918;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten());
        }
        }
        }
      case "Send": {ESLVal $2459 = _v1917.termRef(0);
          ESLVal $2458 = _v1917.termRef(1);
          ESLVal $2457 = _v1917.termRef(2);
          
          switch($2457.termName) {
          case "Term": {ESLVal $2463 = $2457.termRef(0);
            ESLVal $2462 = $2457.termRef(1);
            ESLVal $2461 = $2457.termRef(2);
            ESLVal $2460 = $2457.termRef(3);
            
            {ESLVal l = $2459;
            
            {ESLVal a = $2458;
            
            {ESLVal lt = $2463;
            
            {ESLVal n = $2462;
            
            {ESLVal ts = $2461;
            
            {ESLVal es = $2460;
            
            return new ESLVal("JSend",expToJExp.apply(a),n,expsToJExps.apply(es));
          }
          }
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(6137,14761)").add(ESLVal.list(_v1917)));
        }
        }
      case "SendTimeSuper": {ESLVal $2456 = _v1917.termRef(0);
          
          {ESLVal l = $2456;
          
          return new ESLVal("JSendTimeSuper",new ESLVal[]{});
        }
        }
      case "SendSuper": {ESLVal $2455 = _v1917.termRef(0);
          ESLVal $2454 = _v1917.termRef(1);
          
          {ESLVal l = $2455;
          
          {ESLVal _v2001 = $2454;
          
          return new ESLVal("JSendSuper",expToJExp.apply(_v2001));
        }
        }
        }
      case "Self": {ESLVal $2453 = _v1917.termRef(0);
          
          {ESLVal l = $2453;
          
          return new ESLVal("JSelf",new ESLVal[]{});
        }
        }
      case "Fold": {ESLVal $2452 = _v1917.termRef(0);
          ESLVal $2451 = _v1917.termRef(1);
          ESLVal $2450 = _v1917.termRef(2);
          
          {ESLVal l = $2452;
          
          {ESLVal t = $2451;
          
          {ESLVal _v2000 = $2450;
          
          return expToJExp.apply(_v2000);
        }
        }
        }
        }
      case "Now": {ESLVal $2449 = _v1917.termRef(0);
          
          {ESLVal l = $2449;
          
          return new ESLVal("JNow",new ESLVal[]{});
        }
        }
      case "Ref": {ESLVal $2448 = _v1917.termRef(0);
          ESLVal $2447 = _v1917.termRef(1);
          ESLVal $2446 = _v1917.termRef(2);
          
          {ESLVal l = $2448;
          
          {ESLVal _v1999 = $2447;
          
          {ESLVal n = $2446;
          
          return new ESLVal("JRef",expToJExp.apply(_v1999),n);
        }
        }
        }
        }
      case "RefSuper": {ESLVal $2445 = _v1917.termRef(0);
          ESLVal $2444 = _v1917.termRef(1);
          
          {ESLVal l = $2445;
          
          {ESLVal n = $2444;
          
          return new ESLVal("JRefSuper",n);
        }
        }
        }
      case "For": {ESLVal $2443 = _v1917.termRef(0);
          ESLVal $2442 = _v1917.termRef(1);
          ESLVal $2441 = _v1917.termRef(2);
          ESLVal $2440 = _v1917.termRef(3);
          
          {ESLVal l1 = $2443;
          
          {ESLVal p = $2442;
          
          {ESLVal l2 = $2441;
          
          {ESLVal c = $2440;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
        }
      case "Grab": {ESLVal $2439 = _v1917.termRef(0);
          ESLVal $2438 = _v1917.termRef(1);
          ESLVal $2437 = _v1917.termRef(2);
          
          {ESLVal l = $2439;
          
          {ESLVal refs = $2438;
          
          {ESLVal _v1998 = $2437;
          
          return new ESLVal("JGrab",refsToJExps.apply(refs),expToJExp.apply(_v1998));
        }
        }
        }
        }
      case "Update": {ESLVal $2436 = _v1917.termRef(0);
          ESLVal $2435 = _v1917.termRef(1);
          ESLVal $2434 = _v1917.termRef(2);
          
          {ESLVal l = $2436;
          
          {ESLVal n = $2435;
          
          {ESLVal v = $2434;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
      case "Probably": {ESLVal $2433 = _v1917.termRef(0);
          ESLVal $2432 = _v1917.termRef(1);
          ESLVal $2431 = _v1917.termRef(2);
          ESLVal $2430 = _v1917.termRef(3);
          ESLVal $2429 = _v1917.termRef(4);
          
          {ESLVal l = $2433;
          
          {ESLVal _v1997 = $2432;
          
          {ESLVal t = $2431;
          
          {ESLVal e1 = $2430;
          
          {ESLVal e2 = $2429;
          
          return new ESLVal("JProbably",expToJExp.apply(_v1997),expToJExp.apply(e1),expToJExp.apply(e2));
        }
        }
        }
        }
        }
        }
      case "Try": {ESLVal $2428 = _v1917.termRef(0);
          ESLVal $2427 = _v1917.termRef(1);
          ESLVal $2426 = _v1917.termRef(2);
          
          {ESLVal l = $2428;
          
          {ESLVal _v1996 = $2427;
          
          {ESLVal arms = $2426;
          
          return new ESLVal("JTry",expToJExp.apply(_v1996),new ESLVal("$x"),expToJCommand.apply(new ESLVal("Case",l,$nil,ESLVal.list(new ESLVal("Var",l,new ESLVal("$x"))),arms),$true));
        }
        }
        }
        }
      case "ActExp": {ESLVal $2425 = _v1917.termRef(0);
          ESLVal $2424 = _v1917.termRef(1);
          ESLVal $2423 = _v1917.termRef(2);
          ESLVal $2422 = _v1917.termRef(3);
          ESLVal $2421 = _v1917.termRef(4);
          ESLVal $2420 = _v1917.termRef(5);
          ESLVal $2419 = _v1917.termRef(6);
          ESLVal $2418 = _v1917.termRef(7);
          
          {ESLVal l = $2425;
          
          {ESLVal name = $2424;
          
          {ESLVal decs = $2423;
          
          {ESLVal exports = $2422;
          
          {ESLVal parent = $2421;
          
          {ESLVal defs = $2420;
          
          {ESLVal init = $2419;
          
          {ESLVal arms = $2418;
          
          return actToJava.apply(name,decs,exports,parent,defs,init,arms);
        }
        }
        }
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(6137,14761)").add(ESLVal.list(_v1917)));
      }
      }
    }
  });
  private static ESLVal isSimpleQualifier = new ESLVal(new Function(new ESLVal("isSimpleQualifier"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal q = $args[0];
  {ESLVal _v1919 = q;
        
        switch(_v1919.termName) {
        case "BQual": {ESLVal $2606 = _v1919.termRef(0);
          ESLVal $2605 = _v1919.termRef(1);
          ESLVal $2604 = _v1919.termRef(2);
          
          switch($2605.termName) {
          case "PVar": {ESLVal $2609 = $2605.termRef(0);
            ESLVal $2608 = $2605.termRef(1);
            ESLVal $2607 = $2605.termRef(2);
            
            {ESLVal l = $2606;
            
            {ESLVal vl = $2609;
            
            {ESLVal n = $2608;
            
            {ESLVal t = $2607;
            
            {ESLVal e = $2604;
            
            return $true;
          }
          }
          }
          }
          }
          }
          default: {ESLVal l = $2606;
            
            {ESLVal p = $2605;
            
            {ESLVal e = $2604;
            
            return $false;
          }
          }
          }
        }
        }
        default: {ESLVal _v1995 = _v1919;
          
          return $true;
        }
      }
      }
    }
  });
  private static ESLVal isBindingQualifier = new ESLVal(new Function(new ESLVal("isBindingQualifier"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal q = $args[0];
  {ESLVal _v1920 = q;
        
        switch(_v1920.termName) {
        case "BQual": {ESLVal $2612 = _v1920.termRef(0);
          ESLVal $2611 = _v1920.termRef(1);
          ESLVal $2610 = _v1920.termRef(2);
          
          {ESLVal l = $2612;
          
          {ESLVal p = $2611;
          
          {ESLVal e = $2610;
          
          return $true;
        }
        }
        }
        }
        default: {ESLVal _v1994 = _v1920;
          
          return $false;
        }
      }
      }
    }
  });
  private static ESLVal cmpToJCmp = new ESLVal(new Function(new ESLVal("cmpToJCmp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  ESLVal qs = $args[1];
  { LetRec letrec = new LetRec() {
        ESLVal inner = new ESLVal(new Function(new ESLVal("inner"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1989 = $args[0];
          {ESLVal _v1921 = _v1989;
                
                if(_v1921.isCons())
                {ESLVal $2613 = _v1921.head();
                  ESLVal $2614 = _v1921.tail();
                  
                  switch($2613.termName) {
                  case "BQual": {ESLVal $2619 = $2613.termRef(0);
                    ESLVal $2618 = $2613.termRef(1);
                    ESLVal $2617 = $2613.termRef(2);
                    
                    switch($2618.termName) {
                    case "PVar": {ESLVal $2622 = $2618.termRef(0);
                      ESLVal $2621 = $2618.termRef(1);
                      ESLVal $2620 = $2618.termRef(2);
                      
                      {ESLVal l = $2619;
                      
                      {ESLVal vl = $2622;
                      
                      {ESLVal n = $2621;
                      
                      {ESLVal t = $2620;
                      
                      {ESLVal listExp = $2617;
                      
                      {ESLVal _v1991 = $2614;
                      
                      return new ESLVal("JCmpBind",n,expToJExp.apply(listExp),inner.apply(_v1991));
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: return error(new ESLVal("case error at Pos(15164,15362)").add(ESLVal.list(_v1921)));
                  }
                  }
                case "PQual": {ESLVal $2616 = $2613.termRef(0);
                    ESLVal $2615 = $2613.termRef(1);
                    
                    {ESLVal l = $2616;
                    
                    {ESLVal p = $2615;
                    
                    {ESLVal _v1990 = $2614;
                    
                    return new ESLVal("JCmpIf",expToJExp.apply(p),inner.apply(_v1990));
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(15164,15362)").add(ESLVal.list(_v1921)));
                }
                }
              else if(_v1921.isNil())
                return new ESLVal("JCmpList",expToJExp.apply(e));
              else return error(new ESLVal("case error at Pos(15164,15362)").add(ESLVal.list(_v1921)));
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "inner": return inner;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal inner = letrec.get("inner");
      
        {ESLVal _v1922 = qs;
        
        if(_v1922.isCons())
        {ESLVal $2623 = _v1922.head();
          ESLVal $2624 = _v1922.tail();
          
          switch($2623.termName) {
          case "BQual": {ESLVal $2629 = $2623.termRef(0);
            ESLVal $2628 = $2623.termRef(1);
            ESLVal $2627 = $2623.termRef(2);
            
            switch($2628.termName) {
            case "PVar": {ESLVal $2632 = $2628.termRef(0);
              ESLVal $2631 = $2628.termRef(1);
              ESLVal $2630 = $2628.termRef(2);
              
              {ESLVal l = $2629;
              
              {ESLVal vl = $2632;
              
              {ESLVal n = $2631;
              
              {ESLVal t = $2630;
              
              {ESLVal listExp = $2627;
              
              {ESLVal _v1993 = $2624;
              
              return new ESLVal("JCmpOuter",n,expToJExp.apply(listExp),inner.apply(_v1993));
            }
            }
            }
            }
            }
            }
            }
            default: return error(new ESLVal("case error at Pos(15374,15571)").add(ESLVal.list(_v1922)));
          }
          }
        case "PQual": {ESLVal $2626 = $2623.termRef(0);
            ESLVal $2625 = $2623.termRef(1);
            
            {ESLVal l = $2626;
            
            {ESLVal p = $2625;
            
            {ESLVal _v1992 = $2624;
            
            return new ESLVal("JCmpIf",expToJExp.apply(p),cmpToJCmp.apply(e,_v1992));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(15374,15571)").add(ESLVal.list(_v1922)));
        }
        }
      else if(_v1922.isNil())
        return new ESLVal("JCmpList",expToJExp.apply(e));
      else return error(new ESLVal("case error at Pos(15374,15571)").add(ESLVal.list(_v1922)));
      }}
      
    }
  });
  private static ESLVal refsToJExps = new ESLVal(new Function(new ESLVal("refsToJExps"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal refs = $args[0];
  {ESLVal _v1923 = refs;
        
        if(_v1923.isCons())
        {ESLVal $2633 = _v1923.head();
          ESLVal $2634 = _v1923.tail();
          
          switch($2633.termName) {
          case "VarDynamicRef": {ESLVal $2639 = $2633.termRef(0);
            ESLVal $2638 = $2633.termRef(1);
            
            switch($2638.termName) {
            case "Var": {ESLVal $2641 = $2638.termRef(0);
              ESLVal $2640 = $2638.termRef(1);
              
              {ESLVal l = $2639;
              
              {ESLVal vl = $2641;
              
              {ESLVal n = $2640;
              
              {ESLVal _v1988 = $2634;
              
              return refsToJExps.apply(_v1988).cons(new ESLVal("JVar",n,$null));
            }
            }
            }
            }
            }
            default: return error(new ESLVal("case error at Pos(15618,15859)").add(ESLVal.list(_v1923)));
          }
          }
        case "ActorDynamicRef": {ESLVal $2637 = $2633.termRef(0);
            ESLVal $2636 = $2633.termRef(1);
            ESLVal $2635 = $2633.termRef(2);
            
            {ESLVal l = $2637;
            
            {ESLVal e = $2636;
            
            {ESLVal n = $2635;
            
            {ESLVal _v1987 = $2634;
            
            return refsToJExps.apply(_v1987).cons(new ESLVal("JRef",expToJExp.apply(e),n));
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(15618,15859)").add(ESLVal.list(_v1923)));
        }
        }
      else if(_v1923.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(15618,15859)").add(ESLVal.list(_v1923)));
      }
    }
  });
  private static ESLVal actToJava = new ESLVal(new Function(new ESLVal("actToJava"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal name = $args[0];
  ESLVal decs = $args[1];
  ESLVal exports = $args[2];
  ESLVal parent = $args[3];
  ESLVal defs = $args[4];
  ESLVal init = $args[5];
  ESLVal arms = $args[6];
  if(parent.eql($null).boolVal)
        return simpleActToJava.apply(name,decs,exports,defs,init,arms);
        else
          return extendedActToJava.apply(name,decs,exports,parent,defs,init,arms);
    }
  });
  private static ESLVal simpleActToJava = new ESLVal(new Function(new ESLVal("simpleActToJava"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal name = $args[0];
  ESLVal decs = $args[1];
  ESLVal exports = $args[2];
  ESLVal defs = $args[3];
  ESLVal init = $args[4];
  ESLVal arms = $args[5];
  {ESLVal timeArms = select.apply(isTimeArm,arms);
        
        {ESLVal nonTimeArms = reject.apply(isTimeArm,arms);
        
        {ESLVal timeCommand = ((Supplier<ESLVal>)() -> { 
            if(timeArms.eql(ESLVal.list()).boolVal)
              return new ESLVal("JBlock",ESLVal.list());
              else
                return timeArmsToJCommand.apply(timeArms);
          }).get();
        
        {ESLVal f = new ESLVal("FunExp",new ESLVal("Pos",$zero,$zero),name,ESLVal.list(new ESLVal("Dec",new ESLVal("Pos",$zero,$zero),new ESLVal("$m"),$null,$null)),new ESLVal("VoidType",new ESLVal("Pos",$zero,$zero)),new ESLVal("Case",new ESLVal("Pos",$zero,$zero),$nil,ESLVal.list(new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("$m"))),nonTimeArms));
        
        return new ESLVal("JBehaviour",exports,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              $v.add(defToField.apply(b));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(defs),expToJExp.apply(init),expToJExp.apply(f),timeCommand);
      }
      }
      }
      }
    }
  });
  private static ESLVal extendedActToJava = new ESLVal(new Function(new ESLVal("extendedActToJava"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal name = $args[0];
  ESLVal decs = $args[1];
  ESLVal exports = $args[2];
  ESLVal parent = $args[3];
  ESLVal defs = $args[4];
  ESLVal init = $args[5];
  ESLVal arms = $args[6];
  {ESLVal p0 = new ESLVal("Pos",$zero,$zero);
        
        {ESLVal timeSuper = new ESLVal("BArm",p0,ESLVal.list(new ESLVal("PTerm",p0,new ESLVal("Time"),ESLVal.list(),ESLVal.list(new ESLVal("PVar",p0,new ESLVal("$"),$null)))),new ESLVal("BoolExp",p0,$true),new ESLVal("SendTimeSuper",p0));
        
        {ESLVal timeArms = select.apply(isTimeArm,arms).add(ESLVal.list(timeSuper));
        
        {ESLVal messageSuper = new ESLVal("BArm",p0,ESLVal.list(new ESLVal("PVar",p0,new ESLVal("$m"),$null)),new ESLVal("BoolExp",p0,$true),new ESLVal("Block",p0,ESLVal.list(new ESLVal("SendSuper",p0,new ESLVal("Var",p0,new ESLVal("$m"))),new ESLVal("NullExp",p0))));
        
        {ESLVal nonTimeArms = reject.apply(isTimeArm,arms).add(ESLVal.list(messageSuper));
        
        {ESLVal timeCommand = ((Supplier<ESLVal>)() -> { 
            if(timeArms.eql(ESLVal.list()).boolVal)
              return new ESLVal("JBlock",ESLVal.list());
              else
                return timeArmsToJCommand.apply(timeArms);
          }).get();
        
        {ESLVal f = new ESLVal("FunExp",new ESLVal("Pos",$zero,$zero),name,ESLVal.list(new ESLVal("Dec",new ESLVal("Pos",$zero,$zero),new ESLVal("$m"),$null,$null)),new ESLVal("VoidType",new ESLVal("Pos",$zero,$zero)),new ESLVal("Case",new ESLVal("Pos",$zero,$zero),$nil,ESLVal.list(new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("$m"))),nonTimeArms));
        
        return new ESLVal("JExtendedBehaviour",exports,expToJExp.apply(parent),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              $v.add(defToField.apply(b));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(defs),expToJExp.apply(init),expToJExp.apply(f),timeCommand);
      }
      }
      }
      }
      }
      }
      }
    }
  });
  private static ESLVal isTimeArm = new ESLVal(new Function(new ESLVal("isTimeArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal a = $args[0];
  {ESLVal _v1924 = a;
        
        switch(_v1924.termName) {
        case "BArm": {ESLVal $2645 = _v1924.termRef(0);
          ESLVal $2644 = _v1924.termRef(1);
          ESLVal $2643 = _v1924.termRef(2);
          ESLVal $2642 = _v1924.termRef(3);
          
          if($2644.isCons())
          {ESLVal $2646 = $2644.head();
            ESLVal $2647 = $2644.tail();
            
            switch($2646.termName) {
            case "PTerm": {ESLVal $2651 = $2646.termRef(0);
              ESLVal $2650 = $2646.termRef(1);
              ESLVal $2649 = $2646.termRef(2);
              ESLVal $2648 = $2646.termRef(3);
              
              switch($2650.strVal) {
              case "Time": if($2647.isCons())
                {ESLVal $2652 = $2647.head();
                  ESLVal $2653 = $2647.tail();
                  
                  {ESLVal _v1980 = _v1924;
                  
                  return $false;
                }
                }
              else if($2647.isNil())
                {ESLVal l = $2645;
                  
                  {ESLVal pl = $2651;
                  
                  {ESLVal ts = $2649;
                  
                  {ESLVal ps = $2648;
                  
                  {ESLVal g = $2643;
                  
                  {ESLVal e = $2642;
                  
                  return $true;
                }
                }
                }
                }
                }
                }
              else {ESLVal _v1981 = _v1924;
                  
                  return $false;
                }
              default: {ESLVal _v1982 = _v1924;
                
                return $false;
              }
            }
            }
            default: {ESLVal _v1983 = _v1924;
              
              return $false;
            }
          }
          }
        else if($2644.isNil())
          {ESLVal _v1984 = _v1924;
            
            return $false;
          }
        else {ESLVal _v1985 = _v1924;
            
            return $false;
          }
        }
        default: {ESLVal _v1986 = _v1924;
          
          return $false;
        }
      }
      }
    }
  });
  private static ESLVal timeArmsToJCommand = new ESLVal(new Function(new ESLVal("timeArmsToJCommand"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  {ESLVal _v1925 = arms;
        
        if(_v1925.isCons())
        {ESLVal $2654 = _v1925.head();
          ESLVal $2655 = _v1925.tail();
          
          switch($2654.termName) {
          case "BArm": {ESLVal $2659 = $2654.termRef(0);
            ESLVal $2658 = $2654.termRef(1);
            ESLVal $2657 = $2654.termRef(2);
            ESLVal $2656 = $2654.termRef(3);
            
            if($2658.isCons())
            {ESLVal $2660 = $2658.head();
              ESLVal $2661 = $2658.tail();
              
              switch($2660.termName) {
              case "PTerm": {ESLVal $2665 = $2660.termRef(0);
                ESLVal $2664 = $2660.termRef(1);
                ESLVal $2663 = $2660.termRef(2);
                ESLVal $2662 = $2660.termRef(3);
                
                switch($2664.strVal) {
                case "Time": if($2663.isCons())
                  {ESLVal $2666 = $2663.head();
                    ESLVal $2667 = $2663.tail();
                    
                    return error(new ESLVal("case error at Pos(17960,18490)").add(ESLVal.list(_v1925)));
                  }
                else if($2663.isNil())
                  if($2662.isCons())
                    {ESLVal $2668 = $2662.head();
                      ESLVal $2669 = $2662.tail();
                      
                      switch($2668.termName) {
                      case "PVar": {ESLVal $2680 = $2668.termRef(0);
                        ESLVal $2679 = $2668.termRef(1);
                        ESLVal $2678 = $2668.termRef(2);
                        
                        if($2669.isCons())
                        {ESLVal $2681 = $2669.head();
                          ESLVal $2682 = $2669.tail();
                          
                          return error(new ESLVal("case error at Pos(17960,18490)").add(ESLVal.list(_v1925)));
                        }
                      else if($2669.isNil())
                        if($2661.isCons())
                          {ESLVal $2683 = $2661.head();
                            ESLVal $2684 = $2661.tail();
                            
                            return error(new ESLVal("case error at Pos(17960,18490)").add(ESLVal.list(_v1925)));
                          }
                        else if($2661.isNil())
                          {ESLVal l = $2659;
                            
                            {ESLVal tl = $2665;
                            
                            {ESLVal vl = $2680;
                            
                            {ESLVal n = $2679;
                            
                            {ESLVal t = $2678;
                            
                            {ESLVal g = $2657;
                            
                            {ESLVal e = $2656;
                            
                            {ESLVal _v1979 = $2655;
                            
                            return new ESLVal("JLet",ESLVal.list(new ESLVal("JField",n,$null,new ESLVal("JVar",new ESLVal("$t"),$null))),new ESLVal("JIfCommand",expToJExp.apply(g),expToJCommand.apply(e,$false),timeArmsToJCommand.apply(_v1979)));
                          }
                          }
                          }
                          }
                          }
                          }
                          }
                          }
                        else return error(new ESLVal("case error at Pos(17960,18490)").add(ESLVal.list(_v1925)));
                      else return error(new ESLVal("case error at Pos(17960,18490)").add(ESLVal.list(_v1925)));
                      }
                    case "PInt": {ESLVal $2671 = $2668.termRef(0);
                        ESLVal $2670 = $2668.termRef(1);
                        
                        if($2669.isCons())
                        {ESLVal $2672 = $2669.head();
                          ESLVal $2673 = $2669.tail();
                          
                          return error(new ESLVal("case error at Pos(17960,18490)").add(ESLVal.list(_v1925)));
                        }
                      else if($2669.isNil())
                        if($2661.isCons())
                          {ESLVal $2674 = $2661.head();
                            ESLVal $2675 = $2661.tail();
                            
                            return error(new ESLVal("case error at Pos(17960,18490)").add(ESLVal.list(_v1925)));
                          }
                        else if($2661.isNil())
                          switch($2657.termName) {
                            case "BoolExp": {ESLVal $2677 = $2657.termRef(0);
                              ESLVal $2676 = $2657.termRef(1);
                              
                              switch($2676.boolVal ? 1 : 0) {
                              case 1: {ESLVal l = $2659;
                                
                                {ESLVal tl = $2665;
                                
                                {ESLVal vl = $2671;
                                
                                {ESLVal n = $2670;
                                
                                {ESLVal bl = $2677;
                                
                                {ESLVal e = $2656;
                                
                                {ESLVal _v1978 = $2655;
                                
                                return new ESLVal("JIfCommand",new ESLVal("JBinExp",new ESLVal("JVar",new ESLVal("$t"),$null),new ESLVal("eq"),new ESLVal("JConstExp",new ESLVal("JConstInt",n))),expToJCommand.apply(e,$false),timeArmsToJCommand.apply(_v1978));
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              default: return error(new ESLVal("case error at Pos(17960,18490)").add(ESLVal.list(_v1925)));
                            }
                            }
                            default: return error(new ESLVal("case error at Pos(17960,18490)").add(ESLVal.list(_v1925)));
                          }
                        else return error(new ESLVal("case error at Pos(17960,18490)").add(ESLVal.list(_v1925)));
                      else return error(new ESLVal("case error at Pos(17960,18490)").add(ESLVal.list(_v1925)));
                      }
                      default: return error(new ESLVal("case error at Pos(17960,18490)").add(ESLVal.list(_v1925)));
                    }
                    }
                  else if($2662.isNil())
                    return error(new ESLVal("case error at Pos(17960,18490)").add(ESLVal.list(_v1925)));
                  else return error(new ESLVal("case error at Pos(17960,18490)").add(ESLVal.list(_v1925)));
                else return error(new ESLVal("case error at Pos(17960,18490)").add(ESLVal.list(_v1925)));
                default: return error(new ESLVal("case error at Pos(17960,18490)").add(ESLVal.list(_v1925)));
              }
              }
              default: return error(new ESLVal("case error at Pos(17960,18490)").add(ESLVal.list(_v1925)));
            }
            }
          else if($2658.isNil())
            return error(new ESLVal("case error at Pos(17960,18490)").add(ESLVal.list(_v1925)));
          else return error(new ESLVal("case error at Pos(17960,18490)").add(ESLVal.list(_v1925)));
          }
          default: return error(new ESLVal("case error at Pos(17960,18490)").add(ESLVal.list(_v1925)));
        }
        }
      else if(_v1925.isNil())
        return new ESLVal("JBlock",ESLVal.list());
      else return error(new ESLVal("case error at Pos(17960,18490)").add(ESLVal.list(_v1925)));
      }
    }
  });
  private static ESLVal cmpToJExp = new ESLVal(new Function(new ESLVal("cmpToJExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  ESLVal qs = $args[1];
  {ESLVal _v1926 = qs;
        
        if(_v1926.isCons())
        {ESLVal $2685 = _v1926.head();
          ESLVal $2686 = _v1926.tail();
          
          switch($2685.termName) {
          case "BQual": {ESLVal $2691 = $2685.termRef(0);
            ESLVal $2690 = $2685.termRef(1);
            ESLVal $2689 = $2685.termRef(2);
            
            {ESLVal l = $2691;
            
            {ESLVal p = $2690;
            
            {ESLVal v = $2689;
            
            {ESLVal _v1977 = $2686;
            
            {ESLVal f = new ESLVal("FunExp",new ESLVal("Pos",$zero,$zero),new ESLVal("StrExp",new ESLVal("Pos",$zero,$zero),new ESLVal("qual")),ESLVal.list(new ESLVal("Dec",new ESLVal("Pos",$zero,$zero),new ESLVal("$qualArg"),$null,$null)),$null,new ESLVal("Case",new ESLVal("Pos",$zero,$zero),ESLVal.list(),ESLVal.list(new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("$qualArg"))),ESLVal.list(new ESLVal("BArm",new ESLVal("Pos",$zero,$zero),ESLVal.list(p),new ESLVal("BoolExp",new ESLVal("Pos",$zero,$zero),$true),new ESLVal("List",new ESLVal("Pos",$zero,$zero),ESLVal.list(new ESLVal("Cmp",new ESLVal("Pos",$zero,$zero),e,_v1977)))),new ESLVal("BArm",new ESLVal("Pos",$zero,$zero),ESLVal.list(new ESLVal("PVar",new ESLVal("Pos",$zero,$zero),new ESLVal("_0"),$null)),new ESLVal("BoolExp",new ESLVal("Pos",$zero,$zero),$true),new ESLVal("List",new ESLVal("Pos",$zero,$zero),$nil)))));
            
            return new ESLVal("JFlatten",new ESLVal("JFlatten",new ESLVal("JMapFun",expToJExp.apply(f),expToJExp.apply(v))));
          }
          }
          }
          }
          }
          }
        case "PQual": {ESLVal $2688 = $2685.termRef(0);
            ESLVal $2687 = $2685.termRef(1);
            
            {ESLVal l = $2688;
            
            {ESLVal p = $2687;
            
            {ESLVal _v1976 = $2686;
            
            return new ESLVal("JIfExp",expToJExp.apply(p),cmpToJExp.apply(e,_v1976),new ESLVal("JNil",$null));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(18537,19205)").add(ESLVal.list(_v1926)));
        }
        }
      else if(_v1926.isNil())
        return new ESLVal("JList",$null,ESLVal.list(expToJExp.apply(e)));
      else return error(new ESLVal("case error at Pos(18537,19205)").add(ESLVal.list(_v1926)));
      }
    }
  });
  public static ESLVal moduleToJava = new ESLVal(new Function(new ESLVal("moduleToJava"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal module = $args[0];
  {ESLVal _v1927 = module;
        
        switch(_v1927.termName) {
        case "Module": {ESLVal $2698 = _v1927.termRef(0);
          ESLVal $2697 = _v1927.termRef(1);
          ESLVal $2696 = _v1927.termRef(2);
          ESLVal $2695 = _v1927.termRef(3);
          ESLVal $2694 = _v1927.termRef(4);
          ESLVal $2693 = _v1927.termRef(5);
          ESLVal $2692 = _v1927.termRef(6);
          
          {ESLVal path = $2698;
          
          {ESLVal name = $2697;
          
          {ESLVal exports = $2696;
          
          {ESLVal imports = $2695;
          
          {ESLVal x = $2694;
          
          {ESLVal y = $2693;
          
          {ESLVal defs = $2692;
          
          return renameJVarsModule.apply(new ESLVal("JModule",name,exports,imports,new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal d = $l0.head();
                $l0 = $l0.tail();
                if(isBinding.apply(d).or(isFunBind.apply(d)).boolVal) {$v.add(defToField.apply(d));
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(expandFunDefs.apply(mergeFunDefs.apply(defs)))));
        }
        }
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(19243,19516)").add(ESLVal.list(_v1927)));
      }
      }
    }
  });
  private static ESLVal renameJVarsModule = new ESLVal(new Function(new ESLVal("renameJVarsModule"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal m = $args[0];
  {ESLVal _v1928 = m;
        
        switch(_v1928.termName) {
        case "JModule": {ESLVal $2702 = _v1928.termRef(0);
          ESLVal $2701 = _v1928.termRef(1);
          ESLVal $2700 = _v1928.termRef(2);
          ESLVal $2699 = _v1928.termRef(3);
          
          {ESLVal name = $2702;
          
          {ESLVal exports = $2701;
          
          {ESLVal imports = $2700;
          
          {ESLVal fs = $2699;
          
          {ESLVal fieldNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v1929 = $qualArg;
                  
                  switch(_v1929.termName) {
                  case "JField": {ESLVal $2705 = _v1929.termRef(0);
                    ESLVal $2704 = _v1929.termRef(1);
                    ESLVal $2703 = _v1929.termRef(2);
                    
                    {ESLVal n = $2705;
                    
                    {ESLVal t = $2704;
                    
                    {ESLVal e = $2703;
                    
                    return ESLVal.list(ESLVal.list(n));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v1929;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(fs).flatten().flatten();
          
          return new ESLVal("JModule",name,exports,imports,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1930 = $qualArg;
                
                switch(_v1930.termName) {
                case "JField": {ESLVal $2708 = _v1930.termRef(0);
                  ESLVal $2707 = _v1930.termRef(1);
                  ESLVal $2706 = _v1930.termRef(2);
                  
                  {ESLVal n = $2708;
                  
                  {ESLVal t = $2707;
                  
                  {ESLVal e = $2706;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(e,fieldNames,emptyTable))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1930;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten());
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(19556,19863)").add(ESLVal.list(_v1928)));
      }
      }
    }
  });
  private static ESLVal renameJVarsExp = new ESLVal(new Function(new ESLVal("renameJVarsExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  ESLVal vars = $args[1];
  ESLVal env = $args[2];
  {ESLVal _v1931 = e;
        
        switch(_v1931.termName) {
        case "JFun": {ESLVal $2788 = _v1931.termRef(0);
          ESLVal $2787 = _v1931.termRef(1);
          ESLVal $2786 = _v1931.termRef(2);
          ESLVal $2785 = _v1931.termRef(3);
          
          {ESLVal v0 = $2788;
          
          {ESLVal v1 = $2787;
          
          {ESLVal v2 = $2786;
          
          {ESLVal v3 = $2785;
          
          {ESLVal boundNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v1935 = $qualArg;
                  
                  switch(_v1935.termName) {
                  case "JDec": {ESLVal $2799 = _v1935.termRef(0);
                    ESLVal $2798 = _v1935.termRef(1);
                    
                    {ESLVal n = $2799;
                    
                    {ESLVal t = $2798;
                    
                    return ESLVal.list(ESLVal.list(n));
                  }
                  }
                  }
                  default: {ESLVal _0 = _v1935;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v1).flatten().flatten();
          
          if(exists.apply(new ESLVal(new Function(new ESLVal("fun400"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal n = $args[0];
        return member.apply(n,boundNames);
          }
        }),vars).boolVal)
          {ESLVal newNames = new java.util.function.Function<ESLVal,ESLVal>() {
                public ESLVal apply(ESLVal $l0) {
                  ESLVal $a = $nil;
                  java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                  while(!$l0.isNil()) { 
                    ESLVal n = $l0.head();
                    $l0 = $l0.tail();
                    $v.add(newName.apply());
                  }
                  for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                  return $a;
                }}.apply(boundNames);
            
            {ESLVal env1 = addEntries.apply(boundNames,newNames,env);
            
            return new ESLVal("JFun",v0,new java.util.function.Function<ESLVal,ESLVal>() {
              public ESLVal apply(ESLVal $l0) {
                ESLVal $a = $nil;
                java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                while(!$l0.isNil()) { 
                  ESLVal n = $l0.head();
                  $l0 = $l0.tail();
                  $v.add(new ESLVal("JDec",n,$null));
                }
                for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                return $a;
              }}.apply(newNames),v2,renameJVarsCommand.apply(v3,boundNames.add(vars),env1));
          }
          }
          else
            return new ESLVal("JFun",v0,v1,v2,renameJVarsCommand.apply(v3,boundNames.add(vars),env));
        }
        }
        }
        }
        }
        }
      case "JApply": {ESLVal $2784 = _v1931.termRef(0);
          ESLVal $2783 = _v1931.termRef(1);
          
          {ESLVal v0 = $2784;
          
          {ESLVal v1 = $2783;
          
          return new ESLVal("JApply",renameJVarsExp.apply(v0,vars,env),new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal v = $l0.head();
                $l0 = $l0.tail();
                $v.add(renameJVarsExp.apply(v,vars,env));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v1));
        }
        }
        }
      case "JArrayRef": {ESLVal $2782 = _v1931.termRef(0);
          ESLVal $2781 = _v1931.termRef(1);
          
          {ESLVal a = $2782;
          
          {ESLVal i = $2781;
          
          return new ESLVal("JArrayRef",renameJVarsExp.apply(a,vars,env),renameJVarsExp.apply(i,vars,env));
        }
        }
        }
      case "JArrayUpdate": {ESLVal $2780 = _v1931.termRef(0);
          ESLVal $2779 = _v1931.termRef(1);
          ESLVal $2778 = _v1931.termRef(2);
          
          {ESLVal a = $2780;
          
          {ESLVal i = $2779;
          
          {ESLVal v = $2778;
          
          return new ESLVal("JArrayUpdate",renameJVarsExp.apply(a,vars,env),renameJVarsExp.apply(i,vars,env),renameJVarsExp.apply(v,vars,env));
        }
        }
        }
        }
      case "JBecome": {ESLVal $2777 = _v1931.termRef(0);
          ESLVal $2776 = _v1931.termRef(1);
          
          {ESLVal _v1975 = $2777;
          
          {ESLVal es = $2776;
          
          return new ESLVal("JBecome",renameJVarsExp.apply(_v1975,vars,env),new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal v = $l0.head();
                $l0 = $l0.tail();
                $v.add(renameJVarsExp.apply(v,vars,env));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(es));
        }
        }
        }
      case "JBinExp": {ESLVal $2775 = _v1931.termRef(0);
          ESLVal $2774 = _v1931.termRef(1);
          ESLVal $2773 = _v1931.termRef(2);
          
          {ESLVal v0 = $2775;
          
          {ESLVal v1 = $2774;
          
          {ESLVal v2 = $2773;
          
          return new ESLVal("JBinExp",renameJVarsExp.apply(v0,vars,env),v1,renameJVarsExp.apply(v2,vars,env));
        }
        }
        }
        }
      case "JCommandExp": {ESLVal $2772 = _v1931.termRef(0);
          ESLVal $2771 = _v1931.termRef(1);
          
          {ESLVal v0 = $2772;
          
          {ESLVal v1 = $2771;
          
          return new ESLVal("JCommandExp",renameJVarsCommand.apply(v0,vars,env),v1);
        }
        }
        }
      case "JIfExp": {ESLVal $2770 = _v1931.termRef(0);
          ESLVal $2769 = _v1931.termRef(1);
          ESLVal $2768 = _v1931.termRef(2);
          
          {ESLVal v0 = $2770;
          
          {ESLVal v1 = $2769;
          
          {ESLVal v2 = $2768;
          
          return new ESLVal("JIfExp",renameJVarsExp.apply(v0,vars,env),renameJVarsExp.apply(v1,vars,env),renameJVarsExp.apply(v2,vars,env));
        }
        }
        }
        }
      case "JConstExp": {ESLVal $2767 = _v1931.termRef(0);
          
          {ESLVal v0 = $2767;
          
          return e;
        }
        }
      case "JTerm": {ESLVal $2766 = _v1931.termRef(0);
          ESLVal $2765 = _v1931.termRef(1);
          
          {ESLVal v0 = $2766;
          
          {ESLVal v1 = $2765;
          
          return new ESLVal("JTerm",v0,new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal v = $l0.head();
                $l0 = $l0.tail();
                $v.add(renameJVarsExp.apply(v,vars,env));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v1));
        }
        }
        }
      case "JTermRef": {ESLVal $2764 = _v1931.termRef(0);
          ESLVal $2763 = _v1931.termRef(1);
          
          {ESLVal v0 = $2764;
          
          {ESLVal v1 = $2763;
          
          return new ESLVal("JTermRef",renameJVarsExp.apply(v0,vars,env),v1);
        }
        }
        }
      case "JList": {ESLVal $2762 = _v1931.termRef(0);
          ESLVal $2761 = _v1931.termRef(1);
          
          {ESLVal v0 = $2762;
          
          {ESLVal v1 = $2761;
          
          return new ESLVal("JList",v0,new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal v = $l0.head();
                $l0 = $l0.tail();
                $v.add(renameJVarsExp.apply(v,vars,env));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v1));
        }
        }
        }
      case "JSet": {ESLVal $2760 = _v1931.termRef(0);
          ESLVal $2759 = _v1931.termRef(1);
          
          {ESLVal v0 = $2760;
          
          {ESLVal v1 = $2759;
          
          return new ESLVal("JSet",v0,new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal v = $l0.head();
                $l0 = $l0.tail();
                $v.add(renameJVarsExp.apply(v,vars,env));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v1));
        }
        }
        }
      case "JBag": {ESLVal $2758 = _v1931.termRef(0);
          ESLVal $2757 = _v1931.termRef(1);
          
          {ESLVal v0 = $2758;
          
          {ESLVal v1 = $2757;
          
          return new ESLVal("JBag",v0,new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal v = $l0.head();
                $l0 = $l0.tail();
                $v.add(renameJVarsExp.apply(v,vars,env));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v1));
        }
        }
        }
      case "JNil": {ESLVal $2756 = _v1931.termRef(0);
          
          {ESLVal v0 = $2756;
          
          return e;
        }
        }
      case "JNow": {
          return e;
        }
      case "JVar": {ESLVal $2755 = _v1931.termRef(0);
          ESLVal $2754 = _v1931.termRef(1);
          
          {ESLVal v0 = $2755;
          
          {ESLVal v1 = $2754;
          
          if(hasEntry.apply(v0,env).boolVal)
          return new ESLVal("JVar",lookup.apply(v0,env),v1);
          else
            return e;
        }
        }
        }
      case "JNull": {
          return e;
        }
      case "JError": {ESLVal $2753 = _v1931.termRef(0);
          
          {ESLVal v0 = $2753;
          
          return new ESLVal("JError",renameJVarsExp.apply(v0,vars,env));
        }
        }
      case "JHead": {ESLVal $2752 = _v1931.termRef(0);
          
          {ESLVal v0 = $2752;
          
          return new ESLVal("JHead",renameJVarsExp.apply(v0,vars,env));
        }
        }
      case "JTail": {ESLVal $2751 = _v1931.termRef(0);
          
          {ESLVal v0 = $2751;
          
          return new ESLVal("JTail",renameJVarsExp.apply(v0,vars,env));
        }
        }
      case "JCastp": {ESLVal $2750 = _v1931.termRef(0);
          ESLVal $2749 = _v1931.termRef(1);
          ESLVal $2748 = _v1931.termRef(2);
          
          {ESLVal v0 = $2750;
          
          {ESLVal v1 = $2749;
          
          {ESLVal v2 = $2748;
          
          return new ESLVal("JCastp",v0,v1,renameJVarsExp.apply(v2,vars,env));
        }
        }
        }
        }
      case "JCast": {ESLVal $2747 = _v1931.termRef(0);
          ESLVal $2746 = _v1931.termRef(1);
          
          {ESLVal v0 = $2747;
          
          {ESLVal v1 = $2746;
          
          return new ESLVal("JCast",v0,renameJVarsExp.apply(v1,vars,env));
        }
        }
        }
      case "JCmpExp": {ESLVal $2745 = _v1931.termRef(0);
          
          {ESLVal cmp = $2745;
          
          return new ESLVal("JCmpExp",renameJVarsCmp.apply(cmp,vars,env));
        }
        }
      case "JNot": {ESLVal $2744 = _v1931.termRef(0);
          
          {ESLVal _v1974 = $2744;
          
          return new ESLVal("JNot",renameJVarsExp.apply(_v1974,vars,env));
        }
        }
      case "JNew": {ESLVal $2743 = _v1931.termRef(0);
          ESLVal $2742 = _v1931.termRef(1);
          
          {ESLVal b = $2743;
          
          {ESLVal args = $2742;
          
          return new ESLVal("JNew",renameJVarsExp.apply(b,vars,env),new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal a = $l0.head();
                $l0 = $l0.tail();
                $v.add(renameJVarsExp.apply(a,vars,env));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(args));
        }
        }
        }
      case "JNewArray": {ESLVal $2741 = _v1931.termRef(0);
          
          {ESLVal b = $2741;
          
          return new ESLVal("JNewArray",renameJVarsExp.apply(b,vars,env));
        }
        }
      case "JNewJava": {ESLVal $2740 = _v1931.termRef(0);
          ESLVal $2739 = _v1931.termRef(1);
          
          {ESLVal n = $2740;
          
          {ESLVal args = $2739;
          
          return new ESLVal("JNewJava",n,new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal a = $l0.head();
                $l0 = $l0.tail();
                $v.add(renameJVarsExp.apply(a,vars,env));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(args));
        }
        }
        }
      case "JNewTable": {
          return new ESLVal("JNewTable",new ESLVal[]{});
        }
      case "JMapFun": {ESLVal $2738 = _v1931.termRef(0);
          ESLVal $2737 = _v1931.termRef(1);
          
          {ESLVal f = $2738;
          
          {ESLVal l = $2737;
          
          return new ESLVal("JMapFun",renameJVarsExp.apply(f,vars,env),renameJVarsExp.apply(l,vars,env));
        }
        }
        }
      case "JRecord": {ESLVal $2736 = _v1931.termRef(0);
          
          {ESLVal fs = $2736;
          
          return new ESLVal("JRecord",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1934 = $qualArg;
                
                switch(_v1934.termName) {
                case "JField": {ESLVal $2797 = _v1934.termRef(0);
                  ESLVal $2796 = _v1934.termRef(1);
                  ESLVal $2795 = _v1934.termRef(2);
                  
                  {ESLVal n = $2797;
                  
                  {ESLVal t = $2796;
                  
                  {ESLVal _v1973 = $2795;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(_v1973,vars,env))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1934;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten());
        }
        }
      case "JFlatten": {ESLVal $2735 = _v1931.termRef(0);
          
          {ESLVal _v1972 = $2735;
          
          return new ESLVal("JFlatten",renameJVarsExp.apply(_v1972,vars,env));
        }
        }
      case "JSend": {ESLVal $2734 = _v1931.termRef(0);
          ESLVal $2733 = _v1931.termRef(1);
          ESLVal $2732 = _v1931.termRef(2);
          
          {ESLVal _v1971 = $2734;
          
          {ESLVal n = $2733;
          
          {ESLVal es = $2732;
          
          return new ESLVal("JSend",renameJVarsExp.apply(_v1971,vars,env),n,new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal e = $l0.head();
                $l0 = $l0.tail();
                $v.add(renameJVarsExp.apply(e,vars,env));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(es));
        }
        }
        }
        }
      case "JSendSuper": {ESLVal $2731 = _v1931.termRef(0);
          
          {ESLVal _v1970 = $2731;
          
          return new ESLVal("JSendSuper",renameJVarsExp.apply(_v1970,vars,env));
        }
        }
      case "JSendTimeSuper": {
          return new ESLVal("JSendTimeSuper",new ESLVal[]{});
        }
      case "JSelf": {
          return new ESLVal("JSelf",new ESLVal[]{});
        }
      case "JRef": {ESLVal $2730 = _v1931.termRef(0);
          ESLVal $2729 = _v1931.termRef(1);
          
          {ESLVal _v1969 = $2730;
          
          {ESLVal n = $2729;
          
          return new ESLVal("JRef",renameJVarsExp.apply(_v1969,vars,env),n);
        }
        }
        }
      case "JRefSuper": {ESLVal $2728 = _v1931.termRef(0);
          
          {ESLVal n = $2728;
          
          return new ESLVal("JRefSuper",n);
        }
        }
      case "JBehaviour": {ESLVal $2727 = _v1931.termRef(0);
          ESLVal $2726 = _v1931.termRef(1);
          ESLVal $2725 = _v1931.termRef(2);
          ESLVal $2724 = _v1931.termRef(3);
          ESLVal $2723 = _v1931.termRef(4);
          
          {ESLVal es = $2727;
          
          {ESLVal fs = $2726;
          
          {ESLVal init = $2725;
          
          {ESLVal handler = $2724;
          
          {ESLVal time = $2723;
          
          return new ESLVal("JBehaviour",es,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1933 = $qualArg;
                
                switch(_v1933.termName) {
                case "JField": {ESLVal $2794 = _v1933.termRef(0);
                  ESLVal $2793 = _v1933.termRef(1);
                  ESLVal $2792 = _v1933.termRef(2);
                  
                  {ESLVal n = $2794;
                  
                  {ESLVal t = $2793;
                  
                  {ESLVal _v1968 = $2792;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(_v1968,vars,env))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1933;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten(),renameJVarsExp.apply(init,vars,env),renameJVarsExp.apply(handler,vars,env),renameJVarsCommand.apply(time,vars,env));
        }
        }
        }
        }
        }
        }
      case "JExtendedBehaviour": {ESLVal $2722 = _v1931.termRef(0);
          ESLVal $2721 = _v1931.termRef(1);
          ESLVal $2720 = _v1931.termRef(2);
          ESLVal $2719 = _v1931.termRef(3);
          ESLVal $2718 = _v1931.termRef(4);
          ESLVal $2717 = _v1931.termRef(5);
          
          {ESLVal es = $2722;
          
          {ESLVal parent = $2721;
          
          {ESLVal fs = $2720;
          
          {ESLVal init = $2719;
          
          {ESLVal handler = $2718;
          
          {ESLVal time = $2717;
          
          return new ESLVal("JExtendedBehaviour",es,renameJVarsExp.apply(parent,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1932 = $qualArg;
                
                switch(_v1932.termName) {
                case "JField": {ESLVal $2791 = _v1932.termRef(0);
                  ESLVal $2790 = _v1932.termRef(1);
                  ESLVal $2789 = _v1932.termRef(2);
                  
                  {ESLVal n = $2791;
                  
                  {ESLVal t = $2790;
                  
                  {ESLVal _v1967 = $2789;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(_v1967,vars,env))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1932;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten(),renameJVarsExp.apply(init,vars,env),renameJVarsExp.apply(handler,vars,env),renameJVarsCommand.apply(time,vars,env));
        }
        }
        }
        }
        }
        }
        }
      case "JTry": {ESLVal $2716 = _v1931.termRef(0);
          ESLVal $2715 = _v1931.termRef(1);
          ESLVal $2714 = _v1931.termRef(2);
          
          {ESLVal _v1966 = $2716;
          
          {ESLVal n = $2715;
          
          {ESLVal c = $2714;
          
          return new ESLVal("JTry",renameJVarsExp.apply(_v1966,vars,env),n,renameJVarsCommand.apply(c,vars,env));
        }
        }
        }
        }
      case "JProbably": {ESLVal $2713 = _v1931.termRef(0);
          ESLVal $2712 = _v1931.termRef(1);
          ESLVal $2711 = _v1931.termRef(2);
          
          {ESLVal _v1965 = $2713;
          
          {ESLVal e1 = $2712;
          
          {ESLVal e2 = $2711;
          
          return new ESLVal("JProbably",renameJVarsExp.apply(_v1965,vars,env),renameJVarsExp.apply(e1,vars,env),renameJVarsExp.apply(e2,vars,env));
        }
        }
        }
        }
      case "JGrab": {ESLVal $2710 = _v1931.termRef(0);
          ESLVal $2709 = _v1931.termRef(1);
          
          {ESLVal es = $2710;
          
          {ESLVal c = $2709;
          
          return new ESLVal("JGrab",new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal e = $l0.head();
                $l0 = $l0.tail();
                $v.add(renameJVarsExp.apply(e,vars,env));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(es),renameJVarsExp.apply(c,vars,env));
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(19933,24577)").add(ESLVal.list(_v1931)));
      }
      }
    }
  });
  private static ESLVal renameJVarsCmp = new ESLVal(new Function(new ESLVal("renameJVarsCmp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal c = $args[0];
  ESLVal vars = $args[1];
  ESLVal env = $args[2];
  {ESLVal _v1936 = c;
        
        switch(_v1936.termName) {
        case "JCmpList": {ESLVal $2808 = _v1936.termRef(0);
          
          {ESLVal e = $2808;
          
          return new ESLVal("JCmpList",renameJVarsExp.apply(e,vars,env));
        }
        }
      case "JCmpOuter": {ESLVal $2807 = _v1936.termRef(0);
          ESLVal $2806 = _v1936.termRef(1);
          ESLVal $2805 = _v1936.termRef(2);
          
          {ESLVal n = $2807;
          
          {ESLVal e = $2806;
          
          {ESLVal _v1962 = $2805;
          
          {ESLVal _v1963 = remove.apply(n,vars);
          ESLVal _v1964 = addEntry.apply(n,n,env);
          
          return new ESLVal("JCmpOuter",n,renameJVarsExp.apply(e,_v1963,_v1964),renameJVarsCmp.apply(_v1962,_v1963,_v1964));
        }
        }
        }
        }
        }
      case "JCmpBind": {ESLVal $2804 = _v1936.termRef(0);
          ESLVal $2803 = _v1936.termRef(1);
          ESLVal $2802 = _v1936.termRef(2);
          
          {ESLVal n = $2804;
          
          {ESLVal e = $2803;
          
          {ESLVal _v1959 = $2802;
          
          {ESLVal _v1960 = remove.apply(n,vars);
          ESLVal _v1961 = addEntry.apply(n,n,env);
          
          return new ESLVal("JCmpBind",n,renameJVarsExp.apply(e,_v1960,_v1961),renameJVarsCmp.apply(_v1959,_v1960,_v1961));
        }
        }
        }
        }
        }
      case "JCmpIf": {ESLVal $2801 = _v1936.termRef(0);
          ESLVal $2800 = _v1936.termRef(1);
          
          {ESLVal e = $2801;
          
          {ESLVal _v1958 = $2800;
          
          return new ESLVal("JCmpIf",renameJVarsExp.apply(e,vars,env),renameJVarsCmp.apply(_v1958,vars,env));
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(24652,25233)").add(ESLVal.list(_v1936)));
      }
      }
    }
  });
  private static ESLVal nameCount = $zero;
  private static ESLVal newName = new ESLVal(new Function(new ESLVal("newName"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      {nameCount = nameCount.add($one);
      return new ESLVal("_v").add(nameCount);}
    }
  });
  private static ESLVal renameJVarsCommand = new ESLVal(new Function(new ESLVal("renameJVarsCommand"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal c = $args[0];
  ESLVal vars = $args[1];
  ESLVal env = $args[2];
  {ESLVal _v1937 = c;
        
        switch(_v1937.termName) {
        case "JBlock": {ESLVal $2849 = _v1937.termRef(0);
          
          {ESLVal v0 = $2849;
          
          return new ESLVal("JBlock",new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal c = $l0.head();
                $l0 = $l0.tail();
                $v.add(renameJVarsCommand.apply(c,vars,env));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v0));
        }
        }
      case "JReturn": {ESLVal $2848 = _v1937.termRef(0);
          
          {ESLVal v0 = $2848;
          
          return new ESLVal("JReturn",renameJVarsExp.apply(v0,vars,env));
        }
        }
      case "JSwitch": {ESLVal $2847 = _v1937.termRef(0);
          ESLVal $2846 = _v1937.termRef(1);
          ESLVal $2845 = _v1937.termRef(2);
          
          {ESLVal v0 = $2847;
          
          {ESLVal v1 = $2846;
          
          {ESLVal v2 = $2845;
          
          return error(new ESLVal("jswitch should not occur"));
        }
        }
        }
        }
      case "JSwitchList": {ESLVal $2844 = _v1937.termRef(0);
          ESLVal $2843 = _v1937.termRef(1);
          ESLVal $2842 = _v1937.termRef(2);
          ESLVal $2841 = _v1937.termRef(3);
          
          {ESLVal v0 = $2844;
          
          {ESLVal v1 = $2843;
          
          {ESLVal v2 = $2842;
          
          {ESLVal v3 = $2841;
          
          return new ESLVal("JSwitchList",renameJVarsExp.apply(v0,vars,env),renameJVarsCommand.apply(v1,vars,env),renameJVarsCommand.apply(v2,vars,env),renameJVarsCommand.apply(v3,vars,env));
        }
        }
        }
        }
        }
      case "JIfCommand": {ESLVal $2840 = _v1937.termRef(0);
          ESLVal $2839 = _v1937.termRef(1);
          ESLVal $2838 = _v1937.termRef(2);
          
          {ESLVal v0 = $2840;
          
          {ESLVal v1 = $2839;
          
          {ESLVal v2 = $2838;
          
          return new ESLVal("JIfCommand",renameJVarsExp.apply(v0,vars,env),renameJVarsCommand.apply(v1,vars,env),renameJVarsCommand.apply(v2,vars,env));
        }
        }
        }
        }
      case "JCaseList": {ESLVal $2837 = _v1937.termRef(0);
          ESLVal $2836 = _v1937.termRef(1);
          ESLVal $2835 = _v1937.termRef(2);
          ESLVal $2834 = _v1937.termRef(3);
          
          {ESLVal v0 = $2837;
          
          {ESLVal v1 = $2836;
          
          {ESLVal v2 = $2835;
          
          {ESLVal v3 = $2834;
          
          return new ESLVal("JCaseList",renameJVarsExp.apply(v0,vars,env),renameJVarsCommand.apply(v1,vars,env),renameJVarsCommand.apply(v2,vars,env),renameJVarsCommand.apply(v3,vars,env));
        }
        }
        }
        }
        }
      case "JCaseInt": {ESLVal $2833 = _v1937.termRef(0);
          ESLVal $2832 = _v1937.termRef(1);
          ESLVal $2831 = _v1937.termRef(2);
          
          {ESLVal e = $2833;
          
          {ESLVal arms = $2832;
          
          {ESLVal alt = $2831;
          
          return new ESLVal("JCaseInt",renameJVarsExp.apply(e,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1950 = $qualArg;
                
                switch(_v1950.termName) {
                case "JIArm": {ESLVal $2885 = _v1950.termRef(0);
                  ESLVal $2884 = _v1950.termRef(1);
                  
                  {ESLVal n = $2885;
                  
                  {ESLVal _v1957 = $2884;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JIArm",n,renameJVarsCommand.apply(_v1957,vars,env))));
                }
                }
                }
                default: {ESLVal _0 = _v1950;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten(),renameJVarsCommand.apply(alt,vars,env));
        }
        }
        }
        }
      case "JCaseStr": {ESLVal $2830 = _v1937.termRef(0);
          ESLVal $2829 = _v1937.termRef(1);
          ESLVal $2828 = _v1937.termRef(2);
          
          {ESLVal e = $2830;
          
          {ESLVal arms = $2829;
          
          {ESLVal alt = $2828;
          
          return new ESLVal("JCaseStr",renameJVarsExp.apply(e,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1949 = $qualArg;
                
                switch(_v1949.termName) {
                case "JSArm": {ESLVal $2883 = _v1949.termRef(0);
                  ESLVal $2882 = _v1949.termRef(1);
                  
                  {ESLVal s = $2883;
                  
                  {ESLVal _v1956 = $2882;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JSArm",s,renameJVarsCommand.apply(_v1956,vars,env))));
                }
                }
                }
                default: {ESLVal _0 = _v1949;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten(),renameJVarsCommand.apply(alt,vars,env));
        }
        }
        }
        }
      case "JCaseBool": {ESLVal $2827 = _v1937.termRef(0);
          ESLVal $2826 = _v1937.termRef(1);
          ESLVal $2825 = _v1937.termRef(2);
          
          {ESLVal e = $2827;
          
          {ESLVal arms = $2826;
          
          {ESLVal alt = $2825;
          
          return new ESLVal("JCaseBool",renameJVarsExp.apply(e,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1948 = $qualArg;
                
                switch(_v1948.termName) {
                case "JBArm": {ESLVal $2881 = _v1948.termRef(0);
                  ESLVal $2880 = _v1948.termRef(1);
                  
                  {ESLVal b = $2881;
                  
                  {ESLVal _v1955 = $2880;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JBArm",b,renameJVarsCommand.apply(_v1955,vars,env))));
                }
                }
                }
                default: {ESLVal _0 = _v1948;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten(),renameJVarsCommand.apply(alt,vars,env));
        }
        }
        }
        }
      case "JCaseTerm": {ESLVal $2824 = _v1937.termRef(0);
          ESLVal $2823 = _v1937.termRef(1);
          ESLVal $2822 = _v1937.termRef(2);
          
          {ESLVal e = $2824;
          
          {ESLVal arms = $2823;
          
          {ESLVal alt = $2822;
          
          return new ESLVal("JCaseTerm",renameJVarsExp.apply(e,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1947 = $qualArg;
                
                switch(_v1947.termName) {
                case "JTArm": {ESLVal $2879 = _v1947.termRef(0);
                  ESLVal $2878 = _v1947.termRef(1);
                  ESLVal $2877 = _v1947.termRef(2);
                  
                  {ESLVal n = $2879;
                  
                  {ESLVal i = $2878;
                  
                  {ESLVal _v1954 = $2877;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JTArm",n,i,renameJVarsCommand.apply(_v1954,vars,env))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1947;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten(),renameJVarsCommand.apply(alt,vars,env));
        }
        }
        }
        }
      case "JLet": {ESLVal $2821 = _v1937.termRef(0);
          ESLVal $2820 = _v1937.termRef(1);
          
          {ESLVal v0 = $2821;
          
          {ESLVal v1 = $2820;
          
          {ESLVal boundNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v1944 = $qualArg;
                  
                  switch(_v1944.termName) {
                  case "JField": {ESLVal $2870 = _v1944.termRef(0);
                    ESLVal $2869 = _v1944.termRef(1);
                    ESLVal $2868 = _v1944.termRef(2);
                    
                    {ESLVal n = $2870;
                    
                    {ESLVal t = $2869;
                    
                    {ESLVal e = $2868;
                    
                    return ESLVal.list(ESLVal.list(n));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v1944;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten();
          
          if(exists.apply(new ESLVal(new Function(new ESLVal("fun401"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal n = $args[0];
        return member.apply(n,vars);
          }
        }),boundNames).boolVal)
          {ESLVal newNames = new java.util.function.Function<ESLVal,ESLVal>() {
                public ESLVal apply(ESLVal $l0) {
                  ESLVal $a = $nil;
                  java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                  while(!$l0.isNil()) { 
                    ESLVal n = $l0.head();
                    $l0 = $l0.tail();
                    $v.add(newName.apply());
                  }
                  for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                  return $a;
                }}.apply(boundNames);
            
            {ESLVal env1 = addEntries.apply(boundNames,newNames,env);
            
            return new ESLVal("JLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v1945 = $qualArg;
                  
                  switch(_v1945.termName) {
                  case "JField": {ESLVal $2873 = _v1945.termRef(0);
                    ESLVal $2872 = _v1945.termRef(1);
                    ESLVal $2871 = _v1945.termRef(2);
                    
                    {ESLVal n = $2873;
                    
                    {ESLVal t = $2872;
                    
                    {ESLVal e = $2871;
                    
                    return ESLVal.list(ESLVal.list(new ESLVal("JField",lookup.apply(n,env1),t,renameJVarsExp.apply(e,vars,env))));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v1945;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten(),renameJVarsCommand.apply(v1,boundNames.add(vars),env1));
          }
          }
          else
            return new ESLVal("JLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v1946 = $qualArg;
                    
                    switch(_v1946.termName) {
                    case "JField": {ESLVal $2876 = _v1946.termRef(0);
                      ESLVal $2875 = _v1946.termRef(1);
                      ESLVal $2874 = _v1946.termRef(2);
                      
                      {ESLVal n = $2876;
                      
                      {ESLVal t = $2875;
                      
                      {ESLVal e = $2874;
                      
                      return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(e,vars,env))));
                    }
                    }
                    }
                    }
                    default: {ESLVal _0 = _v1946;
                      
                      return ESLVal.list();
                    }
                  }
                  }
                }
              }).map(v0).flatten().flatten(),renameJVarsCommand.apply(v1,boundNames.add(vars),env));
        }
        }
        }
        }
      case "JPLet": {ESLVal $2819 = _v1937.termRef(0);
          ESLVal $2818 = _v1937.termRef(1);
          
          {ESLVal v0 = $2819;
          
          {ESLVal v1 = $2818;
          
          {ESLVal boundNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v1941 = $qualArg;
                  
                  switch(_v1941.termName) {
                  case "JField": {ESLVal $2861 = _v1941.termRef(0);
                    ESLVal $2860 = _v1941.termRef(1);
                    ESLVal $2859 = _v1941.termRef(2);
                    
                    {ESLVal n = $2861;
                    
                    {ESLVal t = $2860;
                    
                    {ESLVal e = $2859;
                    
                    return ESLVal.list(ESLVal.list(n));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v1941;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten();
          
          if(exists.apply(new ESLVal(new Function(new ESLVal("fun402"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal n = $args[0];
        return member.apply(n,vars);
          }
        }),boundNames).boolVal)
          {ESLVal newNames = new java.util.function.Function<ESLVal,ESLVal>() {
                public ESLVal apply(ESLVal $l0) {
                  ESLVal $a = $nil;
                  java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                  while(!$l0.isNil()) { 
                    ESLVal n = $l0.head();
                    $l0 = $l0.tail();
                    $v.add(newName.apply());
                  }
                  for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                  return $a;
                }}.apply(boundNames);
            
            {ESLVal env1 = addEntries.apply(boundNames,newNames,env);
            
            return new ESLVal("JPLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v1942 = $qualArg;
                  
                  switch(_v1942.termName) {
                  case "JField": {ESLVal $2864 = _v1942.termRef(0);
                    ESLVal $2863 = _v1942.termRef(1);
                    ESLVal $2862 = _v1942.termRef(2);
                    
                    {ESLVal n = $2864;
                    
                    {ESLVal t = $2863;
                    
                    {ESLVal e = $2862;
                    
                    return ESLVal.list(ESLVal.list(new ESLVal("JField",lookup.apply(n,env1),t,renameJVarsExp.apply(e,vars,env))));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v1942;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten(),renameJVarsCommand.apply(v1,boundNames.add(vars),env1));
          }
          }
          else
            return new ESLVal("JPLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v1943 = $qualArg;
                    
                    switch(_v1943.termName) {
                    case "JField": {ESLVal $2867 = _v1943.termRef(0);
                      ESLVal $2866 = _v1943.termRef(1);
                      ESLVal $2865 = _v1943.termRef(2);
                      
                      {ESLVal n = $2867;
                      
                      {ESLVal t = $2866;
                      
                      {ESLVal e = $2865;
                      
                      return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(e,vars,env))));
                    }
                    }
                    }
                    }
                    default: {ESLVal _0 = _v1943;
                      
                      return ESLVal.list();
                    }
                  }
                  }
                }
              }).map(v0).flatten().flatten(),renameJVarsCommand.apply(v1,boundNames.add(vars),env));
        }
        }
        }
        }
      case "JLetRec": {ESLVal $2817 = _v1937.termRef(0);
          ESLVal $2816 = _v1937.termRef(1);
          
          {ESLVal v0 = $2817;
          
          {ESLVal v1 = $2816;
          
          {ESLVal boundNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v1938 = $qualArg;
                  
                  switch(_v1938.termName) {
                  case "JField": {ESLVal $2852 = _v1938.termRef(0);
                    ESLVal $2851 = _v1938.termRef(1);
                    ESLVal $2850 = _v1938.termRef(2);
                    
                    {ESLVal n = $2852;
                    
                    {ESLVal t = $2851;
                    
                    {ESLVal e = $2850;
                    
                    return ESLVal.list(ESLVal.list(n));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v1938;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten();
          
          if(exists.apply(new ESLVal(new Function(new ESLVal("fun403"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal n = $args[0];
        return member.apply(n,vars);
          }
        }),boundNames).boolVal)
          {ESLVal newNames = new java.util.function.Function<ESLVal,ESLVal>() {
                public ESLVal apply(ESLVal $l0) {
                  ESLVal $a = $nil;
                  java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                  while(!$l0.isNil()) { 
                    ESLVal n = $l0.head();
                    $l0 = $l0.tail();
                    $v.add(newName.apply());
                  }
                  for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                  return $a;
                }}.apply(boundNames);
            
            {ESLVal _v1953 = addEntries.apply(boundNames,newNames,env);
            
            return new ESLVal("JLetRec",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v1939 = $qualArg;
                  
                  switch(_v1939.termName) {
                  case "JField": {ESLVal $2855 = _v1939.termRef(0);
                    ESLVal $2854 = _v1939.termRef(1);
                    ESLVal $2853 = _v1939.termRef(2);
                    
                    {ESLVal n = $2855;
                    
                    {ESLVal t = $2854;
                    
                    {ESLVal e = $2853;
                    
                    return ESLVal.list(ESLVal.list(new ESLVal("JField",lookup.apply(n,_v1953),t,renameJVarsExp.apply(e,vars,_v1953))));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v1939;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten(),renameJVarsCommand.apply(v1,boundNames.add(vars),_v1953));
          }
          }
          else
            return new ESLVal("JLetRec",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v1940 = $qualArg;
                    
                    switch(_v1940.termName) {
                    case "JField": {ESLVal $2858 = _v1940.termRef(0);
                      ESLVal $2857 = _v1940.termRef(1);
                      ESLVal $2856 = _v1940.termRef(2);
                      
                      {ESLVal n = $2858;
                      
                      {ESLVal t = $2857;
                      
                      {ESLVal e = $2856;
                      
                      return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(e,vars,env))));
                    }
                    }
                    }
                    }
                    default: {ESLVal _0 = _v1940;
                      
                      return ESLVal.list();
                    }
                  }
                  }
                }
              }).map(v0).flatten().flatten(),renameJVarsCommand.apply(v1,boundNames.add(vars),env));
        }
        }
        }
        }
      case "JStatement": {ESLVal $2815 = _v1937.termRef(0);
          
          {ESLVal e = $2815;
          
          return new ESLVal("JStatement",renameJVarsExp.apply(e,vars,env));
        }
        }
      case "JUpdate": {ESLVal $2814 = _v1937.termRef(0);
          ESLVal $2813 = _v1937.termRef(1);
          
          {ESLVal name = $2814;
          
          {ESLVal value = $2813;
          
          if(hasEntry.apply(name,env).boolVal)
          return new ESLVal("JUpdate",lookup.apply(name,env),renameJVarsExp.apply(value,vars,env));
          else
            {ESLVal v0 = $2814;
              
              {ESLVal v1 = $2813;
              
              return new ESLVal("JUpdate",v0,renameJVarsExp.apply(v1,vars,env));
            }
            }
        }
        }
        }
      case "JFor": {ESLVal $2812 = _v1937.termRef(0);
          ESLVal $2811 = _v1937.termRef(1);
          ESLVal $2810 = _v1937.termRef(2);
          ESLVal $2809 = _v1937.termRef(3);
          
          {ESLVal l = $2812;
          
          {ESLVal n = $2811;
          
          {ESLVal e = $2810;
          
          {ESLVal _v1952 = $2809;
          
          return new ESLVal("JFor",l,n,renameJVarsExp.apply(e,vars,env),renameJVarsCommand.apply(_v1952,vars,env));
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(25471,29879)").add(ESLVal.list(_v1937)));
      }
      }
    }
  });
  public static ESLVal main = new ESLVal(new Function(new ESLVal("main"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      return new ESLVal(new BehaviourAdapter(true,getSelf(),new ESLVal("main")) {
          
          public ESLVal handle(ESLVal $m) {{ESLVal _v1951 = $m;
            
            return error(new ESLVal("case error at Pos(0,0)").add(ESLVal.list(_v1951)));
          }}
          public ESLVal get(String name) {
            switch(name) {
              
              default: throw new Error("ref illegal " + self + "." + name);
            }
          }
        public void handleTime(ESLVal $t) {
          {ESLVal n = $t;
            
            if($true.boolVal)
            {print.apply(new ESLVal("").add(emptyTable));
            stopAll.apply();}
            else
              {}
          }
        }
        public ESLVal init() {
            return $null;
          }
        });
    }
  });
public static void main(String[] args) {
    newActor(main,new ESLVal(new Actor())); 
  }
}