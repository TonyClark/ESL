package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
import static esl.compiler.Types.*;
// import static esl.Lists.*;
import java.util.function.Supplier;
public class DynamicVars {
  public static ESLVal getSelf() { return $null; }
  private static ESLVal decName = new ESLVal(new Function(new ESLVal("decName"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d = $args[0];
  {ESLVal _v1005 = d;
        
        switch(_v1005.termName) {
        case "JDec": {ESLVal $1291 = _v1005.termRef(0);
          ESLVal $1290 = _v1005.termRef(1);
          
          {ESLVal n = $1291;
          
          {ESLVal t = $1290;
          
          return n;
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(156,201)").add(ESLVal.list(_v1005)));
      }
      }
    }
  });
  private static ESLVal fieldName = new ESLVal(new Function(new ESLVal("fieldName"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d = $args[0];
  {ESLVal _v1006 = d;
        
        switch(_v1006.termName) {
        case "JField": {ESLVal $1294 = _v1006.termRef(0);
          ESLVal $1293 = _v1006.termRef(1);
          ESLVal $1292 = _v1006.termRef(2);
          
          {ESLVal n = $1294;
          
          {ESLVal t = $1293;
          
          {ESLVal e = $1292;
          
          return n;
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(236,290)").add(ESLVal.list(_v1006)));
      }
      }
    }
  });
  private static ESLVal fieldJExp = new ESLVal(new Function(new ESLVal("fieldJExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d = $args[0];
  {ESLVal _v1007 = d;
        
        switch(_v1007.termName) {
        case "JField": {ESLVal $1297 = _v1007.termRef(0);
          ESLVal $1296 = _v1007.termRef(1);
          ESLVal $1295 = _v1007.termRef(2);
          
          {ESLVal n = $1297;
          
          {ESLVal t = $1296;
          
          {ESLVal e = $1295;
          
          return e;
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(326,380)").add(ESLVal.list(_v1007)));
      }
      }
    }
  });
  public static ESLVal dynamicVarsJModule = new ESLVal(new Function(new ESLVal("dynamicVarsJModule"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal m = $args[0];
  {ESLVal _v1008 = m;
        
        switch(_v1008.termName) {
        case "JModule": {ESLVal $1301 = _v1008.termRef(0);
          ESLVal $1300 = _v1008.termRef(1);
          ESLVal $1299 = _v1008.termRef(2);
          ESLVal $1298 = _v1008.termRef(3);
          
          {ESLVal n = $1301;
          
          {ESLVal exports = $1300;
          
          {ESLVal imports = $1299;
          
          {ESLVal fs = $1298;
          
          {{
          ESLVal _v1009 = fs;
          while(_v1009.isCons()) {
            ESLVal f = _v1009.headVal;
            ((Supplier<ESLVal>)() -> { 
              {ESLVal _v1010 = f;
                
                switch(_v1010.termName) {
                case "JField": {ESLVal $1304 = _v1010.termRef(0);
                  ESLVal $1303 = _v1010.termRef(1);
                  ESLVal $1302 = _v1010.termRef(2);
                  
                  {ESLVal name = $1304;
                  
                  {ESLVal t = $1303;
                  
                  {ESLVal e = $1302;
                  
                  return dynamicVarsJExp.apply(e);
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(540,638)").add(ESLVal.list(_v1010)));
              }
              }
            }).get();
            _v1009 = _v1009.tailVal;}
        }
        return $null;}
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(420,650)").add(ESLVal.list(_v1008)));
      }
      }
    }
  });
  public static ESLVal dynamicVarsJExp = new ESLVal(new Function(new ESLVal("dynamicVarsJExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal x = $args[0];
  {ESLVal _v1011 = x;
        
        switch(_v1011.termName) {
        case "JArrayRef": {ESLVal $1379 = _v1011.termRef(0);
          ESLVal $1378 = _v1011.termRef(1);
          
          {ESLVal a = $1379;
          
          {ESLVal i = $1378;
          
          return dynamicVarsJExp.apply(a).add(dynamicVarsJExp.apply(i));
        }
        }
        }
      case "JArrayUpdate": {ESLVal $1377 = _v1011.termRef(0);
          ESLVal $1376 = _v1011.termRef(1);
          ESLVal $1375 = _v1011.termRef(2);
          
          {ESLVal a = $1377;
          
          {ESLVal i = $1376;
          
          {ESLVal v = $1375;
          
          return dynamicVarsJExp.apply(a).add(dynamicVarsJExp.apply(i).add(dynamicVarsJExp.apply(v)));
        }
        }
        }
        }
      case "JBecome": {ESLVal $1374 = _v1011.termRef(0);
          ESLVal $1373 = _v1011.termRef(1);
          
          {ESLVal e = $1374;
          
          {ESLVal es = $1373;
          
          return dynamicVarsJExp.apply(e).add(flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun332"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1019 = $args[0];
          return dynamicVarsJExp.apply(_v1019);
            }
          }),es)));
        }
        }
        }
      case "JFun": {ESLVal $1372 = _v1011.termRef(0);
          ESLVal $1371 = _v1011.termRef(1);
          ESLVal $1370 = _v1011.termRef(2);
          ESLVal $1369 = _v1011.termRef(3);
          
          {ESLVal v0 = $1372;
          
          {ESLVal v1 = $1371;
          
          {ESLVal v2 = $1370;
          
          {ESLVal v3 = $1369;
          
          return reject.apply(new ESLVal(new Function(new ESLVal("fun333"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal n = $args[0];
          return member.apply(n,map.apply(decName,v1));
            }
          }),dynamicVarsJCommand.apply(v3));
        }
        }
        }
        }
        }
      case "JApply": {ESLVal $1368 = _v1011.termRef(0);
          ESLVal $1367 = _v1011.termRef(1);
          
          {ESLVal v0 = $1368;
          
          {ESLVal v1 = $1367;
          
          return dynamicVarsJExp.apply(v0).add(flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun334"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal e = $args[0];
          return dynamicVarsJExp.apply(e);
            }
          }),v1)));
        }
        }
        }
      case "JBinExp": {ESLVal $1366 = _v1011.termRef(0);
          ESLVal $1365 = _v1011.termRef(1);
          ESLVal $1364 = _v1011.termRef(2);
          
          {ESLVal v0 = $1366;
          
          {ESLVal v1 = $1365;
          
          {ESLVal v2 = $1364;
          
          return dynamicVarsJExp.apply(v0).add(dynamicVarsJExp.apply(v2));
        }
        }
        }
        }
      case "JCommandExp": {ESLVal $1363 = _v1011.termRef(0);
          ESLVal $1362 = _v1011.termRef(1);
          
          {ESLVal v0 = $1363;
          
          {ESLVal v1 = $1362;
          
          return dynamicVarsJCommand.apply(v0);
        }
        }
        }
      case "JIfExp": {ESLVal $1361 = _v1011.termRef(0);
          ESLVal $1360 = _v1011.termRef(1);
          ESLVal $1359 = _v1011.termRef(2);
          
          {ESLVal v0 = $1361;
          
          {ESLVal v1 = $1360;
          
          {ESLVal v2 = $1359;
          
          return dynamicVarsJExp.apply(v0).add(dynamicVarsJExp.apply(v1).add(dynamicVarsJExp.apply(v2)));
        }
        }
        }
        }
      case "JConstExp": {ESLVal $1358 = _v1011.termRef(0);
          
          {ESLVal v0 = $1358;
          
          return ESLVal.list();
        }
        }
      case "JCmpExp": {ESLVal $1357 = _v1011.termRef(0);
          
          {ESLVal c = $1357;
          
          return ESLVal.list();
        }
        }
      case "JTerm": {ESLVal $1356 = _v1011.termRef(0);
          ESLVal $1355 = _v1011.termRef(1);
          
          {ESLVal v0 = $1356;
          
          {ESLVal v1 = $1355;
          
          return flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun335"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal e = $args[0];
          return dynamicVarsJExp.apply(e);
            }
          }),v1));
        }
        }
        }
      case "JTermRef": {ESLVal $1354 = _v1011.termRef(0);
          ESLVal $1353 = _v1011.termRef(1);
          
          {ESLVal v0 = $1354;
          
          {ESLVal v1 = $1353;
          
          return dynamicVarsJExp.apply(v0);
        }
        }
        }
      case "JList": {ESLVal $1352 = _v1011.termRef(0);
          ESLVal $1351 = _v1011.termRef(1);
          
          {ESLVal v0 = $1352;
          
          {ESLVal v1 = $1351;
          
          return flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun336"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal e = $args[0];
          return dynamicVarsJExp.apply(e);
            }
          }),v1));
        }
        }
        }
      case "JBag": {ESLVal $1350 = _v1011.termRef(0);
          ESLVal $1349 = _v1011.termRef(1);
          
          {ESLVal v0 = $1350;
          
          {ESLVal v1 = $1349;
          
          return flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun337"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal e = $args[0];
          return dynamicVarsJExp.apply(e);
            }
          }),v1));
        }
        }
        }
      case "JSet": {ESLVal $1348 = _v1011.termRef(0);
          ESLVal $1347 = _v1011.termRef(1);
          
          {ESLVal v0 = $1348;
          
          {ESLVal v1 = $1347;
          
          return flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun338"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal e = $args[0];
          return dynamicVarsJExp.apply(e);
            }
          }),v1));
        }
        }
        }
      case "JNil": {ESLVal $1346 = _v1011.termRef(0);
          
          {ESLVal v0 = $1346;
          
          return ESLVal.list();
        }
        }
      case "JVar": {ESLVal $1345 = _v1011.termRef(0);
          ESLVal $1344 = _v1011.termRef(1);
          
          {ESLVal v0 = $1345;
          
          {ESLVal v1 = $1344;
          
          return ESLVal.list();
        }
        }
        }
      case "JNull": {
          return ESLVal.list();
        }
      case "JNow": {
          return ESLVal.list();
        }
      case "JError": {ESLVal $1343 = _v1011.termRef(0);
          
          {ESLVal v0 = $1343;
          
          return dynamicVarsJExp.apply(v0);
        }
        }
      case "JHead": {ESLVal $1342 = _v1011.termRef(0);
          
          {ESLVal v0 = $1342;
          
          return dynamicVarsJExp.apply(v0);
        }
        }
      case "JTail": {ESLVal $1341 = _v1011.termRef(0);
          
          {ESLVal v0 = $1341;
          
          return dynamicVarsJExp.apply(v0);
        }
        }
      case "JMapFun": {ESLVal $1340 = _v1011.termRef(0);
          ESLVal $1339 = _v1011.termRef(1);
          
          {ESLVal v0 = $1340;
          
          {ESLVal v1 = $1339;
          
          return dynamicVarsJExp.apply(v0).add(dynamicVarsJExp.apply(v1));
        }
        }
        }
      case "JFlatten": {ESLVal $1338 = _v1011.termRef(0);
          
          {ESLVal v0 = $1338;
          
          return dynamicVarsJExp.apply(v0);
        }
        }
      case "JNot": {ESLVal $1337 = _v1011.termRef(0);
          
          {ESLVal v0 = $1337;
          
          return dynamicVarsJExp.apply(v0);
        }
        }
      case "JBehaviour": {ESLVal $1336 = _v1011.termRef(0);
          ESLVal $1335 = _v1011.termRef(1);
          ESLVal $1334 = _v1011.termRef(2);
          ESLVal $1333 = _v1011.termRef(3);
          ESLVal $1332 = _v1011.termRef(4);
          
          {ESLVal v0 = $1336;
          
          {ESLVal v1 = $1335;
          
          {ESLVal v2 = $1334;
          
          {ESLVal v3 = $1333;
          
          {ESLVal v4 = $1332;
          
          return flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun339"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal d = $args[0];
          return dynamicVarsJFieldDef.apply(d);
            }
          }),v1)).add(dynamicVarsJExp.apply(v2).add(dynamicVarsJExp.apply(v3).add(dynamicVarsJCommand.apply(v4))));
        }
        }
        }
        }
        }
        }
      case "JExtendedBehaviour": {ESLVal $1331 = _v1011.termRef(0);
          ESLVal $1330 = _v1011.termRef(1);
          ESLVal $1329 = _v1011.termRef(2);
          ESLVal $1328 = _v1011.termRef(3);
          ESLVal $1327 = _v1011.termRef(4);
          ESLVal $1326 = _v1011.termRef(5);
          
          {ESLVal v0 = $1331;
          
          {ESLVal parent = $1330;
          
          {ESLVal v1 = $1329;
          
          {ESLVal v2 = $1328;
          
          {ESLVal v3 = $1327;
          
          {ESLVal v4 = $1326;
          
          return dynamicVarsJExp.apply(parent).add(flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun340"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal d = $args[0];
          return dynamicVarsJFieldDef.apply(d);
            }
          }),v1)).add(dynamicVarsJExp.apply(v2).add(dynamicVarsJExp.apply(v3).add(dynamicVarsJCommand.apply(v4)))));
        }
        }
        }
        }
        }
        }
        }
      case "JNew": {ESLVal $1325 = _v1011.termRef(0);
          ESLVal $1324 = _v1011.termRef(1);
          
          {ESLVal v0 = $1325;
          
          {ESLVal v1 = $1324;
          
          return dynamicVarsJExp.apply(v0).add(flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun341"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal e = $args[0];
          return dynamicVarsJExp.apply(e);
            }
          }),v1)));
        }
        }
        }
      case "JNewArray": {ESLVal $1323 = _v1011.termRef(0);
          
          {ESLVal v0 = $1323;
          
          return dynamicVarsJExp.apply(v0);
        }
        }
      case "JNewJava": {ESLVal $1322 = _v1011.termRef(0);
          ESLVal $1321 = _v1011.termRef(1);
          
          {ESLVal v0 = $1322;
          
          {ESLVal v1 = $1321;
          
          return flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun342"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal e = $args[0];
          return dynamicVarsJExp.apply(e);
            }
          }),v1));
        }
        }
        }
      case "JNewTable": {
          return ESLVal.list();
        }
      case "JRecord": {ESLVal $1320 = _v1011.termRef(0);
          
          {ESLVal fs = $1320;
          
          return new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1012 = $qualArg;
                
                switch(_v1012.termName) {
                case "JField": {ESLVal $1382 = _v1012.termRef(0);
                  ESLVal $1381 = _v1012.termRef(1);
                  ESLVal $1380 = _v1012.termRef(2);
                  
                  {ESLVal n = $1382;
                  
                  {ESLVal t = $1381;
                  
                  {ESLVal e = $1380;
                  
                  return ESLVal.list(new java.util.function.Function<ESLVal,ESLVal>() {
                    public ESLVal apply(ESLVal $l0) {
                      ESLVal $a = $nil;
                      java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                      while(!$l0.isNil()) { 
                        ESLVal v = $l0.head();
                        $l0 = $l0.tail();
                        $v.add(v);
                      }
                      for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                      return $a;
                    }}.apply(dynamicVarsJExp.apply(e)));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1012;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten();
        }
        }
      case "JSend": {ESLVal $1319 = _v1011.termRef(0);
          ESLVal $1318 = _v1011.termRef(1);
          ESLVal $1317 = _v1011.termRef(2);
          
          {ESLVal v0 = $1319;
          
          {ESLVal v1 = $1318;
          
          {ESLVal v2 = $1317;
          
          return dynamicVarsJExp.apply(v0).add(flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun343"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal e = $args[0];
          return dynamicVarsJExp.apply(e);
            }
          }),v2)));
        }
        }
        }
        }
      case "JSendSuper": {ESLVal $1316 = _v1011.termRef(0);
          
          {ESLVal e = $1316;
          
          return dynamicVarsJExp.apply(e);
        }
        }
      case "JSendTimeSuper": {
          return ESLVal.list();
        }
      case "JSelf": {
          return ESLVal.list();
        }
      case "JTry": {ESLVal $1315 = _v1011.termRef(0);
          ESLVal $1314 = _v1011.termRef(1);
          ESLVal $1313 = _v1011.termRef(2);
          
          {ESLVal e = $1315;
          
          {ESLVal n = $1314;
          
          {ESLVal c = $1313;
          
          return dynamicVarsJExp.apply(e).add(dynamicVarsJCommand.apply(c));
        }
        }
        }
        }
      case "JRef": {ESLVal $1312 = _v1011.termRef(0);
          ESLVal $1311 = _v1011.termRef(1);
          
          {ESLVal v0 = $1312;
          
          {ESLVal v1 = $1311;
          
          return dynamicVarsJExp.apply(v0);
        }
        }
        }
      case "JRefSuper": {ESLVal $1310 = _v1011.termRef(0);
          
          {ESLVal n = $1310;
          
          return ESLVal.list();
        }
        }
      case "JGrab": {ESLVal $1309 = _v1011.termRef(0);
          ESLVal $1308 = _v1011.termRef(1);
          
          {ESLVal v0 = $1309;
          
          {ESLVal v1 = $1308;
          
          return flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun344"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal e = $args[0];
          return dynamicVarsJExp.apply(e);
            }
          }),v0)).add(dynamicVarsJExp.apply(v1));
        }
        }
        }
      case "JProbably": {ESLVal $1307 = _v1011.termRef(0);
          ESLVal $1306 = _v1011.termRef(1);
          ESLVal $1305 = _v1011.termRef(2);
          
          {ESLVal v0 = $1307;
          
          {ESLVal v1 = $1306;
          
          {ESLVal v2 = $1305;
          
          return dynamicVarsJExp.apply(v0).add(dynamicVarsJExp.apply(v1).add(dynamicVarsJExp.apply(v2)));
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(726,4167)").add(ESLVal.list(_v1011)));
      }
      }
    }
  });
  private static ESLVal dynamicVarsJFieldDef = new ESLVal(new Function(new ESLVal("dynamicVarsJFieldDef"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d = $args[0];
  {ESLVal _v1013 = d;
        
        switch(_v1013.termName) {
        case "JField": {ESLVal $1385 = _v1013.termRef(0);
          ESLVal $1384 = _v1013.termRef(1);
          ESLVal $1383 = _v1013.termRef(2);
          
          {ESLVal n = $1385;
          
          {ESLVal t = $1384;
          
          {ESLVal e = $1383;
          
          return dynamicVarsJExp.apply(e);
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(4217,4288)").add(ESLVal.list(_v1013)));
      }
      }
    }
  });
  private static ESLVal dynamicVarsJTermArm = new ESLVal(new Function(new ESLVal("dynamicVarsJTermArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v1014 = t;
        
        switch(_v1014.termName) {
        case "JTArm": {ESLVal $1388 = _v1014.termRef(0);
          ESLVal $1387 = _v1014.termRef(1);
          ESLVal $1386 = _v1014.termRef(2);
          
          {ESLVal n = $1388;
          
          {ESLVal i = $1387;
          
          {ESLVal c = $1386;
          
          return dynamicVarsJCommand.apply(c);
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(4335,4411)").add(ESLVal.list(_v1014)));
      }
      }
    }
  });
  private static ESLVal dynamicVarsJIntArm = new ESLVal(new Function(new ESLVal("dynamicVarsJIntArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v1015 = t;
        
        switch(_v1015.termName) {
        case "JIArm": {ESLVal $1390 = _v1015.termRef(0);
          ESLVal $1389 = _v1015.termRef(1);
          
          {ESLVal i = $1390;
          
          {ESLVal c = $1389;
          
          return dynamicVarsJCommand.apply(c);
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(4456,4525)").add(ESLVal.list(_v1015)));
      }
      }
    }
  });
  private static ESLVal dynamicVarsJStrArm = new ESLVal(new Function(new ESLVal("dynamicVarsJStrArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v1016 = t;
        
        switch(_v1016.termName) {
        case "JSArm": {ESLVal $1392 = _v1016.termRef(0);
          ESLVal $1391 = _v1016.termRef(1);
          
          {ESLVal s = $1392;
          
          {ESLVal c = $1391;
          
          return dynamicVarsJCommand.apply(c);
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(4570,4639)").add(ESLVal.list(_v1016)));
      }
      }
    }
  });
  private static ESLVal dynamicVarsJBoolArm = new ESLVal(new Function(new ESLVal("dynamicVarsJBoolArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v1017 = t;
        
        switch(_v1017.termName) {
        case "JBArm": {ESLVal $1394 = _v1017.termRef(0);
          ESLVal $1393 = _v1017.termRef(1);
          
          {ESLVal b = $1394;
          
          {ESLVal c = $1393;
          
          return dynamicVarsJCommand.apply(c);
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(4686,4757)").add(ESLVal.list(_v1017)));
      }
      }
    }
  });
  public static ESLVal dynamicVarsJCommand = new ESLVal(new Function(new ESLVal("dynamicVarsJCommand"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal x = $args[0];
  {ESLVal _v1018 = x;
        
        switch(_v1018.termName) {
        case "JBlock": {ESLVal $1428 = _v1018.termRef(0);
          
          {ESLVal v0 = $1428;
          
          return flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun345"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal e = $args[0];
          return dynamicVarsJCommand.apply(e);
            }
          }),v0));
        }
        }
      case "JReturn": {ESLVal $1427 = _v1018.termRef(0);
          
          {ESLVal v0 = $1427;
          
          return dynamicVarsJExp.apply(v0);
        }
        }
      case "JIfCommand": {ESLVal $1426 = _v1018.termRef(0);
          ESLVal $1425 = _v1018.termRef(1);
          ESLVal $1424 = _v1018.termRef(2);
          
          {ESLVal v0 = $1426;
          
          {ESLVal v1 = $1425;
          
          {ESLVal v2 = $1424;
          
          return dynamicVarsJExp.apply(v0).add(dynamicVarsJCommand.apply(v1).add(dynamicVarsJCommand.apply(v2)));
        }
        }
        }
        }
      case "JCaseList": {ESLVal $1423 = _v1018.termRef(0);
          ESLVal $1422 = _v1018.termRef(1);
          ESLVal $1421 = _v1018.termRef(2);
          ESLVal $1420 = _v1018.termRef(3);
          
          {ESLVal v0 = $1423;
          
          {ESLVal v1 = $1422;
          
          {ESLVal v2 = $1421;
          
          {ESLVal v3 = $1420;
          
          return dynamicVarsJExp.apply(v0).add(dynamicVarsJCommand.apply(v1).add(dynamicVarsJCommand.apply(v2).add(dynamicVarsJCommand.apply(v3))));
        }
        }
        }
        }
        }
      case "JCaseTerm": {ESLVal $1419 = _v1018.termRef(0);
          ESLVal $1418 = _v1018.termRef(1);
          ESLVal $1417 = _v1018.termRef(2);
          
          {ESLVal v0 = $1419;
          
          {ESLVal v1 = $1418;
          
          {ESLVal v2 = $1417;
          
          return dynamicVarsJExp.apply(v0).add(flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun346"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal t = $args[0];
          return dynamicVarsJTermArm.apply(t);
            }
          }),v1)).add(dynamicVarsJCommand.apply(v2)));
        }
        }
        }
        }
      case "JCaseInt": {ESLVal $1416 = _v1018.termRef(0);
          ESLVal $1415 = _v1018.termRef(1);
          ESLVal $1414 = _v1018.termRef(2);
          
          {ESLVal v0 = $1416;
          
          {ESLVal v1 = $1415;
          
          {ESLVal v2 = $1414;
          
          return dynamicVarsJExp.apply(v0).add(flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun347"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal t = $args[0];
          return dynamicVarsJIntArm.apply(t);
            }
          }),v1)).add(dynamicVarsJCommand.apply(v2)));
        }
        }
        }
        }
      case "JCaseStr": {ESLVal $1413 = _v1018.termRef(0);
          ESLVal $1412 = _v1018.termRef(1);
          ESLVal $1411 = _v1018.termRef(2);
          
          {ESLVal v0 = $1413;
          
          {ESLVal v1 = $1412;
          
          {ESLVal v2 = $1411;
          
          return dynamicVarsJExp.apply(v0).add(flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun348"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal t = $args[0];
          return dynamicVarsJStrArm.apply(t);
            }
          }),v1)).add(dynamicVarsJCommand.apply(v2)));
        }
        }
        }
        }
      case "JCaseBool": {ESLVal $1410 = _v1018.termRef(0);
          ESLVal $1409 = _v1018.termRef(1);
          ESLVal $1408 = _v1018.termRef(2);
          
          {ESLVal v0 = $1410;
          
          {ESLVal v1 = $1409;
          
          {ESLVal v2 = $1408;
          
          return dynamicVarsJExp.apply(v0).add(flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun349"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal t = $args[0];
          return dynamicVarsJBoolArm.apply(t);
            }
          }),v1)).add(dynamicVarsJCommand.apply(v2)));
        }
        }
        }
        }
      case "JLet": {ESLVal $1407 = _v1018.termRef(0);
          ESLVal $1406 = _v1018.termRef(1);
          
          {ESLVal v0 = $1407;
          
          {ESLVal v1 = $1406;
          
          return flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun350"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal f = $args[0];
          return dynamicVarsJExp.apply(fieldJExp.apply(f));
            }
          }),v0)).add(reject.apply(new ESLVal(new Function(new ESLVal("fun351"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal n = $args[0];
          return member.apply(n,map.apply(fieldName,v0));
            }
          }),dynamicVarsJCommand.apply(v1)));
        }
        }
        }
      case "JPLet": {ESLVal $1405 = _v1018.termRef(0);
          ESLVal $1404 = _v1018.termRef(1);
          
          {ESLVal v0 = $1405;
          
          {ESLVal v1 = $1404;
          
          return flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun352"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal f = $args[0];
          return dynamicVarsJExp.apply(fieldJExp.apply(f));
            }
          }),v0)).add(reject.apply(new ESLVal(new Function(new ESLVal("fun353"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal n = $args[0];
          return member.apply(n,map.apply(fieldName,v0));
            }
          }),dynamicVarsJCommand.apply(v1)));
        }
        }
        }
      case "JLetRec": {ESLVal $1403 = _v1018.termRef(0);
          ESLVal $1402 = _v1018.termRef(1);
          
          {ESLVal v0 = $1403;
          
          {ESLVal v1 = $1402;
          
          return reject.apply(new ESLVal(new Function(new ESLVal("fun354"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal n = $args[0];
          return member.apply(n,map.apply(fieldName,v0));
            }
          }),flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun355"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal f = $args[0];
          return dynamicVarsJExp.apply(fieldJExp.apply(f));
            }
          }),v0)).add(dynamicVarsJCommand.apply(v1)));
        }
        }
        }
      case "JUpdate": {ESLVal $1401 = _v1018.termRef(0);
          ESLVal $1400 = _v1018.termRef(1);
          
          {ESLVal v0 = $1401;
          
          {ESLVal v1 = $1400;
          
          return ESLVal.list(v0).add(dynamicVarsJExp.apply(v1));
        }
        }
        }
      case "JStatement": {ESLVal $1399 = _v1018.termRef(0);
          
          {ESLVal v0 = $1399;
          
          return dynamicVarsJExp.apply(v0);
        }
        }
      case "JFor": {ESLVal $1398 = _v1018.termRef(0);
          ESLVal $1397 = _v1018.termRef(1);
          ESLVal $1396 = _v1018.termRef(2);
          ESLVal $1395 = _v1018.termRef(3);
          
          {ESLVal listName = $1398;
          
          {ESLVal v0 = $1397;
          
          {ESLVal v1 = $1396;
          
          {ESLVal v2 = $1395;
          
          return ESLVal.list(listName).add(dynamicVarsJExp.apply(v1).add(dynamicVarsJCommand.apply(v2)));
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(4847,7018)").add(ESLVal.list(_v1018)));
      }
      }
    }
  });
public static void main(String[] args) {
  }
}