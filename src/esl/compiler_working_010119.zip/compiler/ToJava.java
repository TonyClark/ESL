package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
import static esl.Tables.*;
// import static esl.Lists.*;
import static esl.compiler.Cases.*;
import static esl.compiler.Types.*;
import java.util.function.Supplier;
public class ToJava {
  public static ESLVal getSelf() { return $null; }
  private static ESLVal defToField = new ESLVal(new Function(new ESLVal("defToField"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d = $args[0];
  {ESLVal _v1 = d;
        
        switch(_v1.termName) {
        case "Binding": {ESLVal $14 = _v1.termRef(0);
          ESLVal $13 = _v1.termRef(1);
          ESLVal $12 = _v1.termRef(2);
          ESLVal $11 = _v1.termRef(3);
          ESLVal $10 = _v1.termRef(4);
          
          {ESLVal l = $14;
          
          {ESLVal n = $13;
          
          {ESLVal t = $12;
          
          {ESLVal st = $11;
          
          {ESLVal e = $10;
          
          return new ESLVal("JField",n,$null,expToJExp.apply(e));
        }
        }
        }
        }
        }
        }
      case "FunBind": {ESLVal $7 = _v1.termRef(0);
          ESLVal $6 = _v1.termRef(1);
          ESLVal $5 = _v1.termRef(2);
          ESLVal $4 = _v1.termRef(3);
          ESLVal $3 = _v1.termRef(4);
          ESLVal $2 = _v1.termRef(5);
          ESLVal $1 = _v1.termRef(6);
          
          switch($1.termName) {
          case "BoolExp": {ESLVal $9 = $1.termRef(0);
            ESLVal $8 = $1.termRef(1);
            
            switch($8.boolVal ? 1 : 0) {
            case 1: {ESLVal l = $7;
              
              {ESLVal n = $6;
              
              {ESLVal args = $5;
              
              {ESLVal t = $4;
              
              {ESLVal st = $3;
              
              {ESLVal e = $2;
              
              {ESLVal bl = $9;
              
              {ESLVal formals = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal $qualArg = $args[0];
                {ESLVal _v2 = $qualArg;
                      
                      switch(_v2.termName) {
                      case "PVar": {ESLVal $17 = _v2.termRef(0);
                        ESLVal $16 = _v2.termRef(1);
                        ESLVal $15 = _v2.termRef(2);
                        
                        {ESLVal _v149 = $17;
                        
                        {ESLVal _v150 = $16;
                        
                        {ESLVal _v151 = $15;
                        
                        return ESLVal.list(ESLVal.list(new ESLVal("Dec",_v149,_v150,_v151,st)));
                      }
                      }
                      }
                      }
                      default: {ESLVal _0 = _v2;
                        
                        return ESLVal.list();
                      }
                    }
                    }
                  }
                }).map(args).flatten().flatten();
              
              return new ESLVal("JField",n,$null,expToJExp.apply(new ESLVal("FunExp",l,new ESLVal("StrExp",l,n),formals,t,e)));
            }
            }
            }
            }
            }
            }
            }
            }
            default: {ESLVal l = $7;
              
              {ESLVal n = $6;
              
              {ESLVal args = $5;
              
              {ESLVal t = $4;
              
              {ESLVal st = $3;
              
              {ESLVal e = $2;
              
              {ESLVal g = $1;
              
              {ESLVal formals = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal $qualArg = $args[0];
                {ESLVal _v3 = $qualArg;
                      
                      switch(_v3.termName) {
                      case "PVar": {ESLVal $20 = _v3.termRef(0);
                        ESLVal $19 = _v3.termRef(1);
                        ESLVal $18 = _v3.termRef(2);
                        
                        {ESLVal _v152 = $20;
                        
                        {ESLVal _v153 = $19;
                        
                        {ESLVal _v154 = $18;
                        
                        return ESLVal.list(ESLVal.list(new ESLVal("Dec",_v152,_v153,_v154,st)));
                      }
                      }
                      }
                      }
                      default: {ESLVal _0 = _v3;
                        
                        return ESLVal.list();
                      }
                    }
                    }
                  }
                }).map(args).flatten().flatten();
              
              return new ESLVal("JField",n,$null,expToJExp.apply(new ESLVal("FunExp",l,new ESLVal("StrExp",l,n),formals,t,new ESLVal("If",l,g,e,new ESLVal("Throw",l,t,new ESLVal("StrExp",l,new ESLVal("guard failed for ").add(n)))))));
            }
            }
            }
            }
            }
            }
            }
            }
          }
          }
          default: {ESLVal l = $7;
            
            {ESLVal n = $6;
            
            {ESLVal args = $5;
            
            {ESLVal t = $4;
            
            {ESLVal st = $3;
            
            {ESLVal e = $2;
            
            {ESLVal g = $1;
            
            {ESLVal formals = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v4 = $qualArg;
                    
                    switch(_v4.termName) {
                    case "PVar": {ESLVal $23 = _v4.termRef(0);
                      ESLVal $22 = _v4.termRef(1);
                      ESLVal $21 = _v4.termRef(2);
                      
                      {ESLVal _v155 = $23;
                      
                      {ESLVal _v156 = $22;
                      
                      {ESLVal _v157 = $21;
                      
                      return ESLVal.list(ESLVal.list(new ESLVal("Dec",_v155,_v156,_v157,st)));
                    }
                    }
                    }
                    }
                    default: {ESLVal _0 = _v4;
                      
                      return ESLVal.list();
                    }
                  }
                  }
                }
              }).map(args).flatten().flatten();
            
            return new ESLVal("JField",n,$null,expToJExp.apply(new ESLVal("FunExp",l,new ESLVal("StrExp",l,n),formals,t,new ESLVal("If",l,g,e,new ESLVal("Throw",l,t,new ESLVal("StrExp",l,new ESLVal("guard failed for ").add(n)))))));
          }
          }
          }
          }
          }
          }
          }
          }
        }
        }
        default: return error(new ESLVal("case error at Pos(172,825)").add(ESLVal.list(_v1)));
      }
      }
    }
  });
  private static ESLVal decToJDec = new ESLVal(new Function(new ESLVal("decToJDec"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d = $args[0];
  {ESLVal _v5 = d;
        
        switch(_v5.termName) {
        case "Dec": {ESLVal $27 = _v5.termRef(0);
          ESLVal $26 = _v5.termRef(1);
          ESLVal $25 = _v5.termRef(2);
          ESLVal $24 = _v5.termRef(3);
          
          {ESLVal l = $27;
          
          {ESLVal n = $26;
          
          {ESLVal t = $25;
          
          {ESLVal st = $24;
          
          return new ESLVal("JDec",n,$null);
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(869,945)").add(ESLVal.list(_v5)));
      }
      }
    }
  });
  private static ESLVal expsToJCommands = new ESLVal(new Function(new ESLVal("expsToJCommands"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal cs = $args[0];
  ESLVal isLast = $args[1];
  {ESLVal _v6 = cs;
        
        if(_v6.isCons())
        {ESLVal $28 = _v6.head();
          ESLVal $29 = _v6.tail();
          
          if($29.isCons())
          {ESLVal $30 = $29.head();
            ESLVal $31 = $29.tail();
            
            {ESLVal c = $28;
            
            {ESLVal _v147 = $29;
            
            return expsToJCommands.apply(_v147,isLast).cons(expToJCommand.apply(c,$false));
          }
          }
          }
        else if($29.isNil())
          {ESLVal c = $28;
            
            return ESLVal.list(expToJCommand.apply(c,isLast));
          }
        else {ESLVal c = $28;
            
            {ESLVal _v148 = $29;
            
            return expsToJCommands.apply(_v148,isLast).cons(expToJCommand.apply(c,$false));
          }
          }
        }
      else if(_v6.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(1004,1164)").add(ESLVal.list(_v6)));
      }
    }
  });
  private static ESLVal expToJCommand = new ESLVal(new Function(new ESLVal("expToJCommand"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal c = $args[0];
  ESLVal isLast = $args[1];
  {ESLVal _v7 = c;
        
        switch(_v7.termName) {
        case "Block": {ESLVal $77 = _v7.termRef(0);
          ESLVal $76 = _v7.termRef(1);
          
          if($76.isCons())
          {ESLVal $78 = $76.head();
            ESLVal $79 = $76.tail();
            
            if($79.isCons())
            {ESLVal $80 = $79.head();
              ESLVal $81 = $79.tail();
              
              {ESLVal l = $77;
              
              {ESLVal es = $76;
              
              return new ESLVal("JBlock",new java.util.function.Function<ESLVal,ESLVal>() {
                public ESLVal apply(ESLVal $l0) {
                  ESLVal $a = $nil;
                  java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                  while(!$l0.isNil()) { 
                    ESLVal e = $l0.head();
                    $l0 = $l0.tail();
                    $v.add(expToJCommand.apply(e,$false));
                  }
                  for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                  return $a;
                }}.apply(butlast.apply(es)).add(ESLVal.list(expToJCommand.apply(last.apply(es),isLast))));
            }
            }
            }
          else if($79.isNil())
            {ESLVal l = $77;
              
              {ESLVal e = $78;
              
              return expToJCommand.apply(e,isLast);
            }
            }
          else {ESLVal l = $77;
              
              {ESLVal es = $76;
              
              return new ESLVal("JBlock",new java.util.function.Function<ESLVal,ESLVal>() {
                public ESLVal apply(ESLVal $l0) {
                  ESLVal $a = $nil;
                  java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                  while(!$l0.isNil()) { 
                    ESLVal e = $l0.head();
                    $l0 = $l0.tail();
                    $v.add(expToJCommand.apply(e,$false));
                  }
                  for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                  return $a;
                }}.apply(butlast.apply(es)).add(ESLVal.list(expToJCommand.apply(last.apply(es),isLast))));
            }
            }
          }
        else if($76.isNil())
          {ESLVal l = $77;
            
            if(isLast.boolVal)
            return new ESLVal("JReturn",new ESLVal("JNull",new ESLVal[]{}));
            else
              {ESLVal _v145 = $77;
                
                return new ESLVal("JBlock",$nil);
              }
          }
        else {ESLVal l = $77;
            
            {ESLVal es = $76;
            
            return new ESLVal("JBlock",new java.util.function.Function<ESLVal,ESLVal>() {
              public ESLVal apply(ESLVal $l0) {
                ESLVal $a = $nil;
                java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                while(!$l0.isNil()) { 
                  ESLVal e = $l0.head();
                  $l0 = $l0.tail();
                  $v.add(expToJCommand.apply(e,$false));
                }
                for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                return $a;
              }}.apply(butlast.apply(es)).add(ESLVal.list(expToJCommand.apply(last.apply(es),isLast))));
          }
          }
        }
      case "Update": {ESLVal $75 = _v7.termRef(0);
          ESLVal $74 = _v7.termRef(1);
          ESLVal $73 = _v7.termRef(2);
          
          {ESLVal l = $75;
          
          {ESLVal n = $74;
          
          {ESLVal e = $73;
          
          if(isLast.boolVal)
          return new ESLVal("JBlock",ESLVal.list(new ESLVal("JUpdate",n,expToJExp.apply(e)),new ESLVal("JReturn",new ESLVal("JNull",new ESLVal[]{}))));
          else
            {ESLVal _v142 = $75;
              
              {ESLVal _v143 = $74;
              
              {ESLVal _v144 = $73;
              
              return new ESLVal("JUpdate",_v143,expToJExp.apply(_v144));
            }
            }
            }
        }
        }
        }
        }
      case "If": {ESLVal $72 = _v7.termRef(0);
          ESLVal $71 = _v7.termRef(1);
          ESLVal $70 = _v7.termRef(2);
          ESLVal $69 = _v7.termRef(3);
          
          {ESLVal l = $72;
          
          {ESLVal e1 = $71;
          
          {ESLVal e2 = $70;
          
          {ESLVal e3 = $69;
          
          return new ESLVal("JIfCommand",expToJExp.apply(e1),expToJCommand.apply(e2,isLast),expToJCommand.apply(e3,isLast));
        }
        }
        }
        }
        }
      case "CaseList": {ESLVal $68 = _v7.termRef(0);
          ESLVal $67 = _v7.termRef(1);
          ESLVal $66 = _v7.termRef(2);
          ESLVal $65 = _v7.termRef(3);
          ESLVal $64 = _v7.termRef(4);
          
          {ESLVal l = $68;
          
          {ESLVal e = $67;
          
          {ESLVal cons = $66;
          
          {ESLVal nil = $65;
          
          {ESLVal alt = $64;
          
          return new ESLVal("JCaseList",expToJExp.apply(e),expToJCommand.apply(cons,isLast),expToJCommand.apply(nil,isLast),expToJCommand.apply(alt,isLast));
        }
        }
        }
        }
        }
        }
      case "CaseTerm": {ESLVal $63 = _v7.termRef(0);
          ESLVal $62 = _v7.termRef(1);
          ESLVal $61 = _v7.termRef(2);
          ESLVal $60 = _v7.termRef(3);
          
          {ESLVal l = $63;
          
          {ESLVal e = $62;
          
          {ESLVal arms = $61;
          
          {ESLVal alt = $60;
          
          return new ESLVal("JCaseTerm",expToJExp.apply(e),termArmsToJTermArms.apply(arms,isLast),expToJCommand.apply(alt,isLast));
        }
        }
        }
        }
        }
      case "CaseInt": {ESLVal $59 = _v7.termRef(0);
          ESLVal $58 = _v7.termRef(1);
          ESLVal $57 = _v7.termRef(2);
          ESLVal $56 = _v7.termRef(3);
          
          {ESLVal l = $59;
          
          {ESLVal e = $58;
          
          {ESLVal arms = $57;
          
          {ESLVal alt = $56;
          
          return new ESLVal("JCaseInt",expToJExp.apply(e),intArmsToJIntArms.apply(arms,isLast),expToJCommand.apply(alt,isLast));
        }
        }
        }
        }
        }
      case "CaseStr": {ESLVal $55 = _v7.termRef(0);
          ESLVal $54 = _v7.termRef(1);
          ESLVal $53 = _v7.termRef(2);
          ESLVal $52 = _v7.termRef(3);
          
          {ESLVal l = $55;
          
          {ESLVal e = $54;
          
          {ESLVal arms = $53;
          
          {ESLVal alt = $52;
          
          return new ESLVal("JCaseStr",expToJExp.apply(e),strArmsToJStrArms.apply(arms,isLast),expToJCommand.apply(alt,isLast));
        }
        }
        }
        }
        }
      case "CaseBool": {ESLVal $51 = _v7.termRef(0);
          ESLVal $50 = _v7.termRef(1);
          ESLVal $49 = _v7.termRef(2);
          ESLVal $48 = _v7.termRef(3);
          
          {ESLVal l = $51;
          
          {ESLVal e = $50;
          
          {ESLVal arms = $49;
          
          {ESLVal alt = $48;
          
          return new ESLVal("JCaseBool",expToJExp.apply(e),boolArmsToJBoolArms.apply(arms,isLast),expToJCommand.apply(alt,isLast));
        }
        }
        }
        }
        }
      case "Let": {ESLVal $47 = _v7.termRef(0);
          ESLVal $46 = _v7.termRef(1);
          ESLVal $45 = _v7.termRef(2);
          
          {ESLVal l = $47;
          
          {ESLVal bs = $46;
          
          {ESLVal e = $45;
          
          return new ESLVal("JLet",new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal b = $l0.head();
                $l0 = $l0.tail();
                $v.add(defToField.apply(b));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(bs),expToJCommand.apply(e,isLast));
        }
        }
        }
        }
      case "Letrec": {ESLVal $44 = _v7.termRef(0);
          ESLVal $43 = _v7.termRef(1);
          ESLVal $42 = _v7.termRef(2);
          
          {ESLVal l = $44;
          
          {ESLVal bs = $43;
          
          {ESLVal e = $42;
          
          return new ESLVal("JLetRec",new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal b = $l0.head();
                $l0 = $l0.tail();
                $v.add(defToField.apply(b));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(bs),expToJCommand.apply(e,$true));
        }
        }
        }
        }
      case "For": {ESLVal $38 = _v7.termRef(0);
          ESLVal $37 = _v7.termRef(1);
          ESLVal $36 = _v7.termRef(2);
          ESLVal $35 = _v7.termRef(3);
          
          switch($37.termName) {
          case "PVar": {ESLVal $41 = $37.termRef(0);
            ESLVal $40 = $37.termRef(1);
            ESLVal $39 = $37.termRef(2);
            
            {ESLVal l1 = $38;
            
            {ESLVal l2 = $41;
            
            {ESLVal n = $40;
            
            {ESLVal t = $39;
            
            {ESLVal e = $36;
            
            {ESLVal b = $35;
            
            if(isLast.boolVal)
            return new ESLVal("JBlock",ESLVal.list(new ESLVal("JFor",newName.apply(),n,expToJExp.apply(e),expToJCommand.apply(b,$false)),new ESLVal("JReturn",new ESLVal("JNull",new ESLVal[]{}))));
            else
              {ESLVal _v136 = $38;
                
                {ESLVal _v137 = $41;
                
                {ESLVal _v138 = $40;
                
                {ESLVal _v139 = $39;
                
                {ESLVal _v140 = $36;
                
                {ESLVal _v141 = $35;
                
                return new ESLVal("JFor",newName.apply(),_v138,expToJExp.apply(_v140),expToJCommand.apply(_v141,$false));
              }
              }
              }
              }
              }
              }
          }
          }
          }
          }
          }
          }
          }
          default: {ESLVal l = $38;
            
            {ESLVal p = $37;
            
            {ESLVal e = $36;
            
            {ESLVal b = $35;
            
            {ESLVal opName = newName.apply();
            ESLVal varName = newName.apply();
            
            return expToJCommand.apply(new ESLVal("For",l,new ESLVal("PVar",l,varName,$null),e,new ESLVal("Let",l,ESLVal.list(new ESLVal("Binding",l,opName,$null,$null,new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("forp")),ESLVal.list(),$null,new ESLVal("Case",l,$nil,ESLVal.list(new ESLVal("Var",l,varName)),ESLVal.list(new ESLVal("BArm",l,ESLVal.list(p),new ESLVal("BoolExp",l,$true),b),new ESLVal("BArm",l,ESLVal.list(new ESLVal("PVar",l,new ESLVal("$$$"),$null)),new ESLVal("BoolExp",l,$true),new ESLVal("Block",l,ESLVal.list()))))))),new ESLVal("Apply",l,new ESLVal("Var",l,opName),ESLVal.list()))),isLast);
          }
          }
          }
          }
          }
        }
        }
      case "PLet": {ESLVal $34 = _v7.termRef(0);
          ESLVal $33 = _v7.termRef(1);
          ESLVal $32 = _v7.termRef(2);
          
          {ESLVal l = $34;
          
          {ESLVal bs = $33;
          
          {ESLVal e = $32;
          
          return new ESLVal("JPLet",new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal b = $l0.head();
                $l0 = $l0.tail();
                $v.add(defToField.apply(b));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(bs),expToJCommand.apply(e,isLast));
        }
        }
        }
        }
        default: {ESLVal e = _v7;
          
          if(isLast.boolVal)
          return new ESLVal("JReturn",expToJExp.apply(e));
          else
            {ESLVal _v146 = _v7;
              
              return new ESLVal("JStatement",expToJExp.apply(_v146));
            }
        }
      }
      }
    }
  });
  private static ESLVal expsToJExps = new ESLVal(new Function(new ESLVal("expsToJExps"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal es = $args[0];
  return map.apply(new ESLVal(new Function(new ESLVal("fun416"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal e = $args[0];
        return expToJExp.apply(e);
          }
        }),es);
    }
  });
  private static ESLVal termArmsToJTermArms = new ESLVal(new Function(new ESLVal("termArmsToJTermArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  ESLVal isLast = $args[1];
  {ESLVal _v8 = arms;
        
        if(_v8.isCons())
        {ESLVal $82 = _v8.head();
          ESLVal $83 = _v8.tail();
          
          switch($82.termName) {
          case "TArm": {ESLVal $85 = $82.termRef(0);
            ESLVal $84 = $82.termRef(1);
            
            {ESLVal n = $85;
            
            {ESLVal e = $84;
            
            {ESLVal _v135 = $83;
            
            return termArmsToJTermArms.apply(_v135,isLast).cons(new ESLVal("JTArm",n,$zero,expToJCommand.apply(e,isLast)));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(4499,4668)").add(ESLVal.list(_v8)));
        }
        }
      else if(_v8.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(4499,4668)").add(ESLVal.list(_v8)));
      }
    }
  });
  private static ESLVal intArmsToJIntArms = new ESLVal(new Function(new ESLVal("intArmsToJIntArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  ESLVal isLast = $args[1];
  {ESLVal _v9 = arms;
        
        if(_v9.isCons())
        {ESLVal $86 = _v9.head();
          ESLVal $87 = _v9.tail();
          
          switch($86.termName) {
          case "IArm": {ESLVal $89 = $86.termRef(0);
            ESLVal $88 = $86.termRef(1);
            
            {ESLVal n = $89;
            
            {ESLVal e = $88;
            
            {ESLVal _v134 = $87;
            
            return intArmsToJIntArms.apply(_v134,isLast).cons(new ESLVal("JIArm",n,expToJCommand.apply(e,isLast)));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(4737,4901)").add(ESLVal.list(_v9)));
        }
        }
      else if(_v9.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(4737,4901)").add(ESLVal.list(_v9)));
      }
    }
  });
  private static ESLVal strArmsToJStrArms = new ESLVal(new Function(new ESLVal("strArmsToJStrArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  ESLVal isLast = $args[1];
  {ESLVal _v10 = arms;
        
        if(_v10.isCons())
        {ESLVal $90 = _v10.head();
          ESLVal $91 = _v10.tail();
          
          switch($90.termName) {
          case "SArm": {ESLVal $93 = $90.termRef(0);
            ESLVal $92 = $90.termRef(1);
            
            {ESLVal s = $93;
            
            {ESLVal e = $92;
            
            {ESLVal _v133 = $91;
            
            return strArmsToJStrArms.apply(_v133,isLast).cons(new ESLVal("JSArm",s,expToJCommand.apply(e,isLast)));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(4970,5134)").add(ESLVal.list(_v10)));
        }
        }
      else if(_v10.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(4970,5134)").add(ESLVal.list(_v10)));
      }
    }
  });
  private static ESLVal boolArmsToJBoolArms = new ESLVal(new Function(new ESLVal("boolArmsToJBoolArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  ESLVal isLast = $args[1];
  {ESLVal _v11 = arms;
        
        if(_v11.isCons())
        {ESLVal $94 = _v11.head();
          ESLVal $95 = _v11.tail();
          
          switch($94.termName) {
          case "BoolArm": {ESLVal $97 = $94.termRef(0);
            ESLVal $96 = $94.termRef(1);
            
            {ESLVal b = $97;
            
            {ESLVal e = $96;
            
            {ESLVal _v132 = $95;
            
            return boolArmsToJBoolArms.apply(_v132,isLast).cons(new ESLVal("JBArm",b,expToJCommand.apply(e,isLast)));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(5209,5382)").add(ESLVal.list(_v11)));
        }
        }
      else if(_v11.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(5209,5382)").add(ESLVal.list(_v11)));
      }
    }
  });
  private static ESLVal opToJOp = new ESLVal(new Function(new ESLVal("opToJOp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal op = $args[0];
  {ESLVal _v12 = op;
        
        switch(_v12.strVal) {
        case "@": return new ESLVal("at");
      case "+": return new ESLVal("add");
      case "-": return new ESLVal("sub");
      case "*": return new ESLVal("mul");
      case "/": return new ESLVal("div");
      case "%": return new ESLVal("mod");
      case ">": return new ESLVal("gre");
      case ">=": return new ESLVal("greql");
      case "<": return new ESLVal("less");
      case "<=": return new ESLVal("lesseql");
      case "=": return new ESLVal("eql");
      case "<>": return new ESLVal("neql");
      case ":": return new ESLVal("cons");
      case "..": return new ESLVal("to");
      case "or": return new ESLVal("or");
      case "and": return new ESLVal("and");
      case "andalso": return new ESLVal("andalso");
      case "orelse": return new ESLVal("orelse");
        default: return error(new ESLVal("case error at Pos(5410,5779)").add(ESLVal.list(_v12)));
      }
      }
    }
  });
  private static ESLVal caseToJExp = new ESLVal(new Function(new ESLVal("caseToJExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  {ESLVal bindings = new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal e = $l0.head();
                $l0 = $l0.tail();
                $v.add(new ESLVal("Binding",l,newName.apply(),$null,$null,e));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(es);
        
        {ESLVal names = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v13 = $qualArg;
                
                switch(_v13.termName) {
                case "Binding": {ESLVal $102 = _v13.termRef(0);
                  ESLVal $101 = _v13.termRef(1);
                  ESLVal $100 = _v13.termRef(2);
                  ESLVal $99 = _v13.termRef(3);
                  ESLVal $98 = _v13.termRef(4);
                  
                  {ESLVal _v131 = $102;
                  
                  {ESLVal n = $101;
                  
                  {ESLVal dt = $100;
                  
                  {ESLVal t = $99;
                  
                  {ESLVal e = $98;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _0 = _v13;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(bindings).flatten().flatten();
        
        return expToJExp.apply(new ESLVal("Let",l,bindings,translateCases.apply(new ESLVal("Case",l,ESLVal.list(),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal n = $l0.head();
              $l0 = $l0.tail();
              $v.add(new ESLVal("Var",l,n));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(names),arms))));
      }
      }
    }
  });
  private static ESLVal expToJExp = new ESLVal(new Function(new ESLVal("expToJExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  {ESLVal _v14 = e;
        
        switch(_v14.termName) {
        case "Apply": {ESLVal $287 = _v14.termRef(0);
          ESLVal $286 = _v14.termRef(1);
          ESLVal $285 = _v14.termRef(2);
          
          {ESLVal l = $287;
          
          {ESLVal op = $286;
          
          {ESLVal args = $285;
          
          return new ESLVal("JApply",expToJExp.apply(op),expsToJExps.apply(args));
        }
        }
        }
        }
      case "ArrayUpdate": {ESLVal $284 = _v14.termRef(0);
          ESLVal $283 = _v14.termRef(1);
          ESLVal $282 = _v14.termRef(2);
          ESLVal $281 = _v14.termRef(3);
          
          {ESLVal l = $284;
          
          {ESLVal a = $283;
          
          {ESLVal i = $282;
          
          {ESLVal v = $281;
          
          return new ESLVal("JArrayUpdate",expToJExp.apply(a),expToJExp.apply(i),expToJExp.apply(v));
        }
        }
        }
        }
        }
      case "ArrayRef": {ESLVal $280 = _v14.termRef(0);
          ESLVal $279 = _v14.termRef(1);
          ESLVal $278 = _v14.termRef(2);
          
          {ESLVal l = $280;
          
          {ESLVal a = $279;
          
          {ESLVal i = $278;
          
          return new ESLVal("JArrayRef",expToJExp.apply(a),expToJExp.apply(i));
        }
        }
        }
        }
      case "IntExp": {ESLVal $277 = _v14.termRef(0);
          ESLVal $276 = _v14.termRef(1);
          
          {ESLVal l = $277;
          
          {ESLVal n = $276;
          
          return new ESLVal("JConstExp",new ESLVal("JConstInt",n));
        }
        }
        }
      case "StrExp": {ESLVal $275 = _v14.termRef(0);
          ESLVal $274 = _v14.termRef(1);
          
          {ESLVal l = $275;
          
          {ESLVal s = $274;
          
          return new ESLVal("JConstExp",new ESLVal("JConstStr",s));
        }
        }
        }
      case "BoolExp": {ESLVal $273 = _v14.termRef(0);
          ESLVal $272 = _v14.termRef(1);
          
          {ESLVal l = $273;
          
          {ESLVal b = $272;
          
          return new ESLVal("JConstExp",new ESLVal("JConstBool",b));
        }
        }
        }
      case "FloatExp": {ESLVal $271 = _v14.termRef(0);
          ESLVal $270 = _v14.termRef(1);
          
          {ESLVal l = $271;
          
          {ESLVal f = $270;
          
          return new ESLVal("JConstExp",new ESLVal("JConstDouble",f));
        }
        }
        }
      case "ApplyTypeExp": {ESLVal $256 = _v14.termRef(0);
          ESLVal $255 = _v14.termRef(1);
          ESLVal $254 = _v14.termRef(2);
          
          switch($255.termName) {
          case "List": {ESLVal $263 = $255.termRef(0);
            ESLVal $262 = $255.termRef(1);
            
            if($262.isCons())
            {ESLVal $264 = $262.head();
              ESLVal $265 = $262.tail();
              
              {ESLVal l = $256;
              
              {ESLVal _v124 = $255;
              
              {ESLVal ts = $254;
              
              return expToJExp.apply(_v124);
            }
            }
            }
            }
          else if($262.isNil())
            if($254.isCons())
              {ESLVal $266 = $254.head();
                ESLVal $267 = $254.tail();
                
                if($267.isCons())
                {ESLVal $268 = $267.head();
                  ESLVal $269 = $267.tail();
                  
                  {ESLVal l = $256;
                  
                  {ESLVal _v125 = $255;
                  
                  {ESLVal ts = $254;
                  
                  return expToJExp.apply(_v125);
                }
                }
                }
                }
              else if($267.isNil())
                {ESLVal l1 = $256;
                  
                  {ESLVal l2 = $263;
                  
                  {ESLVal t = $266;
                  
                  return new ESLVal("JNil",$null);
                }
                }
                }
              else {ESLVal l = $256;
                  
                  {ESLVal _v126 = $255;
                  
                  {ESLVal ts = $254;
                  
                  return expToJExp.apply(_v126);
                }
                }
                }
              }
            else if($254.isNil())
              {ESLVal l = $256;
                
                {ESLVal _v127 = $255;
                
                {ESLVal ts = $254;
                
                return expToJExp.apply(_v127);
              }
              }
              }
            else {ESLVal l = $256;
                
                {ESLVal _v128 = $255;
                
                {ESLVal ts = $254;
                
                return expToJExp.apply(_v128);
              }
              }
              }
          else {ESLVal l = $256;
              
              {ESLVal _v129 = $255;
              
              {ESLVal ts = $254;
              
              return expToJExp.apply(_v129);
            }
            }
            }
          }
        case "NullExp": {ESLVal $257 = $255.termRef(0);
            
            if($254.isCons())
            {ESLVal $258 = $254.head();
              ESLVal $259 = $254.tail();
              
              if($259.isCons())
              {ESLVal $260 = $259.head();
                ESLVal $261 = $259.tail();
                
                {ESLVal l = $256;
                
                {ESLVal _v120 = $255;
                
                {ESLVal ts = $254;
                
                return expToJExp.apply(_v120);
              }
              }
              }
              }
            else if($259.isNil())
              {ESLVal l1 = $256;
                
                {ESLVal l2 = $257;
                
                {ESLVal t = $258;
                
                return new ESLVal("JNull",new ESLVal[]{});
              }
              }
              }
            else {ESLVal l = $256;
                
                {ESLVal _v121 = $255;
                
                {ESLVal ts = $254;
                
                return expToJExp.apply(_v121);
              }
              }
              }
            }
          else if($254.isNil())
            {ESLVal l = $256;
              
              {ESLVal _v122 = $255;
              
              {ESLVal ts = $254;
              
              return expToJExp.apply(_v122);
            }
            }
            }
          else {ESLVal l = $256;
              
              {ESLVal _v123 = $255;
              
              {ESLVal ts = $254;
              
              return expToJExp.apply(_v123);
            }
            }
            }
          }
          default: {ESLVal l = $256;
            
            {ESLVal _v130 = $255;
            
            {ESLVal ts = $254;
            
            return expToJExp.apply(_v130);
          }
          }
          }
        }
        }
      case "List": {ESLVal $253 = _v14.termRef(0);
          ESLVal $252 = _v14.termRef(1);
          
          {ESLVal l = $253;
          
          {ESLVal es = $252;
          
          return new ESLVal("JList",$null,expsToJExps.apply(es));
        }
        }
        }
      case "SetExp": {ESLVal $251 = _v14.termRef(0);
          ESLVal $250 = _v14.termRef(1);
          
          {ESLVal l = $251;
          
          {ESLVal es = $250;
          
          return new ESLVal("JSet",$null,expsToJExps.apply(es));
        }
        }
        }
      case "BagExp": {ESLVal $249 = _v14.termRef(0);
          ESLVal $248 = _v14.termRef(1);
          
          {ESLVal l = $249;
          
          {ESLVal es = $248;
          
          return new ESLVal("JBag",$null,expsToJExps.apply(es));
        }
        }
        }
      case "Term": {ESLVal $247 = _v14.termRef(0);
          ESLVal $246 = _v14.termRef(1);
          ESLVal $245 = _v14.termRef(2);
          ESLVal $244 = _v14.termRef(3);
          
          {ESLVal l = $247;
          
          {ESLVal n = $246;
          
          {ESLVal ts = $245;
          
          {ESLVal es = $244;
          
          return new ESLVal("JTerm",n,expsToJExps.apply(es));
        }
        }
        }
        }
        }
      case "Case": {ESLVal $243 = _v14.termRef(0);
          ESLVal $242 = _v14.termRef(1);
          ESLVal $241 = _v14.termRef(2);
          ESLVal $240 = _v14.termRef(3);
          
          {ESLVal l = $243;
          
          {ESLVal ds = $242;
          
          {ESLVal es = $241;
          
          {ESLVal arms = $240;
          
          return caseToJExp.apply(l,es,arms);
        }
        }
        }
        }
        }
      case "CaseAdd": {ESLVal $239 = _v14.termRef(0);
          ESLVal $238 = _v14.termRef(1);
          ESLVal $237 = _v14.termRef(2);
          ESLVal $236 = _v14.termRef(3);
          
          {ESLVal l = $239;
          
          {ESLVal s = $238;
          
          {ESLVal handler = $237;
          
          {ESLVal fail = $236;
          
          return expToJExp.apply(new ESLVal("Apply",l,new ESLVal("Var",l,new ESLVal("$ndCase")),ESLVal.list(s,handler,fail)));
        }
        }
        }
        }
        }
      case "CaseList": {ESLVal $235 = _v14.termRef(0);
          ESLVal $234 = _v14.termRef(1);
          ESLVal $233 = _v14.termRef(2);
          ESLVal $232 = _v14.termRef(3);
          ESLVal $231 = _v14.termRef(4);
          
          {ESLVal l = $235;
          
          {ESLVal list = $234;
          
          {ESLVal cons = $233;
          
          {ESLVal nil = $232;
          
          {ESLVal alt = $231;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
        }
        }
      case "CaseTerm": {ESLVal $230 = _v14.termRef(0);
          ESLVal $229 = _v14.termRef(1);
          ESLVal $228 = _v14.termRef(2);
          ESLVal $227 = _v14.termRef(3);
          
          {ESLVal l = $230;
          
          {ESLVal list = $229;
          
          {ESLVal arms = $228;
          
          {ESLVal alt = $227;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
        }
      case "CaseStr": {ESLVal $226 = _v14.termRef(0);
          ESLVal $225 = _v14.termRef(1);
          ESLVal $224 = _v14.termRef(2);
          ESLVal $223 = _v14.termRef(3);
          
          {ESLVal l = $226;
          
          {ESLVal s = $225;
          
          {ESLVal arms = $224;
          
          {ESLVal alt = $223;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
        }
      case "CaseBool": {ESLVal $222 = _v14.termRef(0);
          ESLVal $221 = _v14.termRef(1);
          ESLVal $220 = _v14.termRef(2);
          ESLVal $219 = _v14.termRef(3);
          
          {ESLVal l = $222;
          
          {ESLVal s = $221;
          
          {ESLVal arms = $220;
          
          {ESLVal alt = $219;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
        }
      case "CaseSet": {ESLVal $218 = _v14.termRef(0);
          ESLVal $217 = _v14.termRef(1);
          ESLVal $216 = _v14.termRef(2);
          ESLVal $215 = _v14.termRef(3);
          
          {ESLVal l = $218;
          
          {ESLVal s = $217;
          
          {ESLVal handler = $216;
          
          {ESLVal fail = $215;
          
          return expToJExp.apply(new ESLVal("Apply",l,new ESLVal("Var",l,new ESLVal("$ndCase")),ESLVal.list(s,handler,fail)));
        }
        }
        }
        }
        }
      case "Head": {ESLVal $214 = _v14.termRef(0);
          
          {ESLVal _v119 = $214;
          
          return new ESLVal("JHead",expToJExp.apply(_v119));
        }
        }
      case "Tail": {ESLVal $213 = _v14.termRef(0);
          
          {ESLVal _v118 = $213;
          
          return new ESLVal("JTail",expToJExp.apply(_v118));
        }
        }
      case "CaseError": {ESLVal $212 = _v14.termRef(0);
          ESLVal $211 = _v14.termRef(1);
          
          {ESLVal l = $212;
          
          {ESLVal _v117 = $211;
          
          return new ESLVal("JError",new ESLVal("JBinExp",new ESLVal("JConstExp",new ESLVal("JConstStr",new ESLVal("case error at ").add(l))),new ESLVal("add"),expToJExp.apply(_v117)));
        }
        }
        }
      case "NullExp": {ESLVal $210 = _v14.termRef(0);
          
          {ESLVal l = $210;
          
          return new ESLVal("JNull",new ESLVal[]{});
        }
        }
      case "Var": {ESLVal $209 = _v14.termRef(0);
          ESLVal $208 = _v14.termRef(1);
          
          {ESLVal l = $209;
          
          {ESLVal n = $208;
          
          return new ESLVal("JVar",n,$null);
        }
        }
        }
      case "Let": {ESLVal $207 = _v14.termRef(0);
          ESLVal $206 = _v14.termRef(1);
          ESLVal $205 = _v14.termRef(2);
          
          {ESLVal l = $207;
          
          {ESLVal bs = $206;
          
          {ESLVal body = $205;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
      case "Letrec": {ESLVal $204 = _v14.termRef(0);
          ESLVal $203 = _v14.termRef(1);
          ESLVal $202 = _v14.termRef(2);
          
          {ESLVal l = $204;
          
          {ESLVal bs = $203;
          
          {ESLVal body = $202;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
      case "Throw": {ESLVal $201 = _v14.termRef(0);
          ESLVal $200 = _v14.termRef(1);
          ESLVal $199 = _v14.termRef(2);
          
          {ESLVal l = $201;
          
          {ESLVal t = $200;
          
          {ESLVal _v116 = $199;
          
          return new ESLVal("JError",expToJExp.apply(_v116));
        }
        }
        }
        }
      case "BinExp": {ESLVal $198 = _v14.termRef(0);
          ESLVal $197 = _v14.termRef(1);
          ESLVal $196 = _v14.termRef(2);
          ESLVal $195 = _v14.termRef(3);
          
          {ESLVal l = $198;
          
          {ESLVal e1 = $197;
          
          {ESLVal op = $196;
          
          {ESLVal e2 = $195;
          
          return new ESLVal("JBinExp",expToJExp.apply(e1),opToJOp.apply(op),expToJExp.apply(e2));
        }
        }
        }
        }
        }
      case "Become": {ESLVal $191 = _v14.termRef(0);
          ESLVal $190 = _v14.termRef(1);
          
          switch($190.termName) {
          case "Apply": {ESLVal $194 = $190.termRef(0);
            ESLVal $193 = $190.termRef(1);
            ESLVal $192 = $190.termRef(2);
            
            {ESLVal l = $191;
            
            {ESLVal al = $194;
            
            {ESLVal b = $193;
            
            {ESLVal args = $192;
            
            return new ESLVal("JBecome",expToJExp.apply(b),expsToJExps.apply(args));
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(6137,14913)").add(ESLVal.list(_v14)));
        }
        }
      case "Block": {ESLVal $185 = _v14.termRef(0);
          ESLVal $184 = _v14.termRef(1);
          
          if($184.isCons())
          {ESLVal $186 = $184.head();
            ESLVal $187 = $184.tail();
            
            if($187.isCons())
            {ESLVal $188 = $187.head();
              ESLVal $189 = $187.tail();
              
              {ESLVal l = $185;
              
              {ESLVal es = $184;
              
              return new ESLVal("JCommandExp",new ESLVal("JBlock",expsToJCommands.apply(es,$true)),$null);
            }
            }
            }
          else if($187.isNil())
            {ESLVal l = $185;
              
              {ESLVal _v115 = $186;
              
              return expToJExp.apply(_v115);
            }
            }
          else {ESLVal l = $185;
              
              {ESLVal es = $184;
              
              return new ESLVal("JCommandExp",new ESLVal("JBlock",expsToJCommands.apply(es,$true)),$null);
            }
            }
          }
        else if($184.isNil())
          {ESLVal l = $185;
            
            return new ESLVal("JNull",new ESLVal[]{});
          }
        else {ESLVal l = $185;
            
            {ESLVal es = $184;
            
            return new ESLVal("JCommandExp",new ESLVal("JBlock",expsToJCommands.apply(es,$true)),$null);
          }
          }
        }
      case "If": {ESLVal $183 = _v14.termRef(0);
          ESLVal $182 = _v14.termRef(1);
          ESLVal $181 = _v14.termRef(2);
          ESLVal $180 = _v14.termRef(3);
          
          {ESLVal l = $183;
          
          {ESLVal e1 = $182;
          
          {ESLVal e2 = $181;
          
          {ESLVal e3 = $180;
          
          return new ESLVal("JCommandExp",new ESLVal("JIfCommand",expToJExp.apply(e1),expToJCommand.apply(e2,$true),expToJCommand.apply(e3,$true)),$null);
        }
        }
        }
        }
        }
      case "FunExp": {ESLVal $179 = _v14.termRef(0);
          ESLVal $178 = _v14.termRef(1);
          ESLVal $177 = _v14.termRef(2);
          ESLVal $176 = _v14.termRef(3);
          ESLVal $175 = _v14.termRef(4);
          
          {ESLVal l = $179;
          
          {ESLVal n = $178;
          
          {ESLVal args = $177;
          
          {ESLVal t = $176;
          
          {ESLVal body = $175;
          
          return new ESLVal("JFun",expToJExp.apply(n),map.apply(new ESLVal(new Function(new ESLVal("fun417"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal d = $args[0];
          return decToJDec.apply(d);
            }
          }),args),new ESLVal("JFunType",new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal a = $l0.head();
                $l0 = $l0.tail();
                $v.add($null);
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(args),$null),expToJCommand.apply(body,$true));
        }
        }
        }
        }
        }
        }
      case "TermRef": {ESLVal $174 = _v14.termRef(0);
          ESLVal $173 = _v14.termRef(1);
          
          {ESLVal _v114 = $174;
          
          {ESLVal i = $173;
          
          return new ESLVal("JTermRef",expToJExp.apply(_v114),i);
        }
        }
        }
      case "Cmp": {ESLVal $168 = _v14.termRef(0);
          ESLVal $167 = _v14.termRef(1);
          ESLVal $166 = _v14.termRef(2);
          
          if($166.isCons())
          {ESLVal $169 = $166.head();
            ESLVal $170 = $166.tail();
            
            switch($169.termName) {
            case "PQual": {ESLVal $172 = $169.termRef(0);
              ESLVal $171 = $169.termRef(1);
              
              {ESLVal l = $168;
              
              {ESLVal _v101 = $167;
              
              {ESLVal ql = $172;
              
              {ESLVal p = $171;
              
              {ESLVal qs = $170;
              
              return expToJExp.apply(new ESLVal("If",ql,p,new ESLVal("Cmp",l,_v101,qs),new ESLVal("List",l,ESLVal.list())));
            }
            }
            }
            }
            }
            }
            default: {ESLVal l = $168;
              
              {ESLVal _v102 = $167;
              
              {ESLVal qs = $166;
              
              if(exists.apply(isBindingQualifier,qs).and(forall.apply(isSimpleQualifier,qs)).boolVal)
              return new ESLVal("JCmpExp",cmpToJCmp.apply(_v102,qs));
              else
                {ESLVal _v103 = $168;
                  
                  {ESLVal _v104 = $167;
                  
                  {ESLVal _v105 = $166;
                  
                  return cmpToJExp.apply(_v104,_v105);
                }
                }
                }
            }
            }
            }
          }
          }
        else if($166.isNil())
          {ESLVal l = $168;
            
            {ESLVal _v106 = $167;
            
            {ESLVal qs = $166;
            
            if(exists.apply(isBindingQualifier,qs).and(forall.apply(isSimpleQualifier,qs)).boolVal)
            return new ESLVal("JCmpExp",cmpToJCmp.apply(_v106,qs));
            else
              {ESLVal _v107 = $168;
                
                {ESLVal _v108 = $167;
                
                {ESLVal _v109 = $166;
                
                return cmpToJExp.apply(_v108,_v109);
              }
              }
              }
          }
          }
          }
        else {ESLVal l = $168;
            
            {ESLVal _v110 = $167;
            
            {ESLVal qs = $166;
            
            if(exists.apply(isBindingQualifier,qs).and(forall.apply(isSimpleQualifier,qs)).boolVal)
            return new ESLVal("JCmpExp",cmpToJCmp.apply(_v110,qs));
            else
              {ESLVal _v111 = $168;
                
                {ESLVal _v112 = $167;
                
                {ESLVal _v113 = $166;
                
                return cmpToJExp.apply(_v112,_v113);
              }
              }
              }
          }
          }
          }
        }
      case "Not": {ESLVal $165 = _v14.termRef(0);
          ESLVal $164 = _v14.termRef(1);
          
          {ESLVal l = $165;
          
          {ESLVal _v100 = $164;
          
          return new ESLVal("JNot",expToJExp.apply(_v100));
        }
        }
        }
      case "New": {ESLVal $163 = _v14.termRef(0);
          ESLVal $162 = _v14.termRef(1);
          ESLVal $161 = _v14.termRef(2);
          
          {ESLVal l = $163;
          
          {ESLVal b = $162;
          
          {ESLVal args = $161;
          
          return new ESLVal("JNew",expToJExp.apply(b),expsToJExps.apply(args));
        }
        }
        }
        }
      case "NewArray": {ESLVal $160 = _v14.termRef(0);
          ESLVal $159 = _v14.termRef(1);
          ESLVal $158 = _v14.termRef(2);
          
          {ESLVal l = $160;
          
          {ESLVal t = $159;
          
          {ESLVal i = $158;
          
          return new ESLVal("JNewArray",expToJExp.apply(i));
        }
        }
        }
        }
      case "NewJava": {ESLVal $157 = _v14.termRef(0);
          ESLVal $156 = _v14.termRef(1);
          ESLVal $155 = _v14.termRef(2);
          ESLVal $154 = _v14.termRef(3);
          
          {ESLVal l = $157;
          
          {ESLVal n = $156;
          
          {ESLVal t = $155;
          
          {ESLVal args = $154;
          
          return new ESLVal("JNewJava",n,expsToJExps.apply(args));
        }
        }
        }
        }
        }
      case "NewTable": {ESLVal $153 = _v14.termRef(0);
          ESLVal $152 = _v14.termRef(1);
          ESLVal $151 = _v14.termRef(2);
          
          {ESLVal l = $153;
          
          {ESLVal key = $152;
          
          {ESLVal value = $151;
          
          return new ESLVal("JNewTable",new ESLVal[]{});
        }
        }
        }
        }
      case "Record": {ESLVal $150 = _v14.termRef(0);
          ESLVal $149 = _v14.termRef(1);
          
          {ESLVal l = $150;
          
          {ESLVal fs = $149;
          
          return new ESLVal("JRecord",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v15 = $qualArg;
                
                switch(_v15.termName) {
                case "Binding": {ESLVal $292 = _v15.termRef(0);
                  ESLVal $291 = _v15.termRef(1);
                  ESLVal $290 = _v15.termRef(2);
                  ESLVal $289 = _v15.termRef(3);
                  ESLVal $288 = _v15.termRef(4);
                  
                  {ESLVal bl = $292;
                  
                  {ESLVal n = $291;
                  
                  {ESLVal t = $290;
                  
                  {ESLVal dt = $289;
                  
                  {ESLVal _v99 = $288;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",n,$null,expToJExp.apply(_v99))));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _0 = _v15;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten());
        }
        }
        }
      case "Send": {ESLVal $144 = _v14.termRef(0);
          ESLVal $143 = _v14.termRef(1);
          ESLVal $142 = _v14.termRef(2);
          
          switch($142.termName) {
          case "Term": {ESLVal $148 = $142.termRef(0);
            ESLVal $147 = $142.termRef(1);
            ESLVal $146 = $142.termRef(2);
            ESLVal $145 = $142.termRef(3);
            
            {ESLVal l = $144;
            
            {ESLVal a = $143;
            
            {ESLVal lt = $148;
            
            {ESLVal n = $147;
            
            {ESLVal ts = $146;
            
            {ESLVal es = $145;
            
            return new ESLVal("JSend",expToJExp.apply(a),n,expsToJExps.apply(es));
          }
          }
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(6137,14913)").add(ESLVal.list(_v14)));
        }
        }
      case "SendTimeSuper": {ESLVal $141 = _v14.termRef(0);
          
          {ESLVal l = $141;
          
          return new ESLVal("JSendTimeSuper",new ESLVal[]{});
        }
        }
      case "SendSuper": {ESLVal $140 = _v14.termRef(0);
          ESLVal $139 = _v14.termRef(1);
          
          {ESLVal l = $140;
          
          {ESLVal _v98 = $139;
          
          return new ESLVal("JSendSuper",expToJExp.apply(_v98));
        }
        }
        }
      case "Self": {ESLVal $138 = _v14.termRef(0);
          
          {ESLVal l = $138;
          
          return new ESLVal("JSelf",new ESLVal[]{});
        }
        }
      case "Fold": {ESLVal $137 = _v14.termRef(0);
          ESLVal $136 = _v14.termRef(1);
          ESLVal $135 = _v14.termRef(2);
          
          {ESLVal l = $137;
          
          {ESLVal t = $136;
          
          {ESLVal _v97 = $135;
          
          return expToJExp.apply(_v97);
        }
        }
        }
        }
      case "Now": {ESLVal $134 = _v14.termRef(0);
          
          {ESLVal l = $134;
          
          return new ESLVal("JNow",new ESLVal[]{});
        }
        }
      case "Ref": {ESLVal $133 = _v14.termRef(0);
          ESLVal $132 = _v14.termRef(1);
          ESLVal $131 = _v14.termRef(2);
          
          {ESLVal l = $133;
          
          {ESLVal _v96 = $132;
          
          {ESLVal n = $131;
          
          return new ESLVal("JRef",expToJExp.apply(_v96),n);
        }
        }
        }
        }
      case "RefSuper": {ESLVal $130 = _v14.termRef(0);
          ESLVal $129 = _v14.termRef(1);
          
          {ESLVal l = $130;
          
          {ESLVal n = $129;
          
          return new ESLVal("JRefSuper",n);
        }
        }
        }
      case "For": {ESLVal $128 = _v14.termRef(0);
          ESLVal $127 = _v14.termRef(1);
          ESLVal $126 = _v14.termRef(2);
          ESLVal $125 = _v14.termRef(3);
          
          {ESLVal l1 = $128;
          
          {ESLVal p = $127;
          
          {ESLVal l2 = $126;
          
          {ESLVal c = $125;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
        }
      case "Grab": {ESLVal $124 = _v14.termRef(0);
          ESLVal $123 = _v14.termRef(1);
          ESLVal $122 = _v14.termRef(2);
          
          {ESLVal l = $124;
          
          {ESLVal refs = $123;
          
          {ESLVal _v95 = $122;
          
          return new ESLVal("JGrab",refsToJExps.apply(refs),expToJExp.apply(_v95));
        }
        }
        }
        }
      case "Update": {ESLVal $121 = _v14.termRef(0);
          ESLVal $120 = _v14.termRef(1);
          ESLVal $119 = _v14.termRef(2);
          
          {ESLVal l = $121;
          
          {ESLVal n = $120;
          
          {ESLVal v = $119;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
      case "Probably": {ESLVal $118 = _v14.termRef(0);
          ESLVal $117 = _v14.termRef(1);
          ESLVal $116 = _v14.termRef(2);
          ESLVal $115 = _v14.termRef(3);
          ESLVal $114 = _v14.termRef(4);
          
          {ESLVal l = $118;
          
          {ESLVal _v94 = $117;
          
          {ESLVal t = $116;
          
          {ESLVal e1 = $115;
          
          {ESLVal e2 = $114;
          
          return new ESLVal("JProbably",expToJExp.apply(_v94),expToJExp.apply(e1),expToJExp.apply(e2));
        }
        }
        }
        }
        }
        }
      case "Try": {ESLVal $113 = _v14.termRef(0);
          ESLVal $112 = _v14.termRef(1);
          ESLVal $111 = _v14.termRef(2);
          
          {ESLVal l = $113;
          
          {ESLVal _v93 = $112;
          
          {ESLVal arms = $111;
          
          return new ESLVal("JTry",expToJExp.apply(_v93),new ESLVal("$x"),expToJCommand.apply(new ESLVal("Case",l,$nil,ESLVal.list(new ESLVal("Var",l,new ESLVal("$x"))),arms),$true));
        }
        }
        }
        }
      case "ActExp": {ESLVal $110 = _v14.termRef(0);
          ESLVal $109 = _v14.termRef(1);
          ESLVal $108 = _v14.termRef(2);
          ESLVal $107 = _v14.termRef(3);
          ESLVal $106 = _v14.termRef(4);
          ESLVal $105 = _v14.termRef(5);
          ESLVal $104 = _v14.termRef(6);
          ESLVal $103 = _v14.termRef(7);
          
          {ESLVal l = $110;
          
          {ESLVal name = $109;
          
          {ESLVal decs = $108;
          
          {ESLVal exports = $107;
          
          {ESLVal parent = $106;
          
          {ESLVal defs = $105;
          
          {ESLVal init = $104;
          
          {ESLVal arms = $103;
          
          return actToJava.apply(name,decs,exports,parent,defs,init,arms);
        }
        }
        }
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(6137,14913)").add(ESLVal.list(_v14)));
      }
      }
    }
  });
  private static ESLVal isSimpleQualifier = new ESLVal(new Function(new ESLVal("isSimpleQualifier"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal q = $args[0];
  {ESLVal _v16 = q;
        
        switch(_v16.termName) {
        case "BQual": {ESLVal $295 = _v16.termRef(0);
          ESLVal $294 = _v16.termRef(1);
          ESLVal $293 = _v16.termRef(2);
          
          switch($294.termName) {
          case "PVar": {ESLVal $298 = $294.termRef(0);
            ESLVal $297 = $294.termRef(1);
            ESLVal $296 = $294.termRef(2);
            
            {ESLVal l = $295;
            
            {ESLVal vl = $298;
            
            {ESLVal n = $297;
            
            {ESLVal t = $296;
            
            {ESLVal e = $293;
            
            return $true;
          }
          }
          }
          }
          }
          }
          default: {ESLVal l = $295;
            
            {ESLVal p = $294;
            
            {ESLVal e = $293;
            
            return $false;
          }
          }
          }
        }
        }
        default: {ESLVal _v92 = _v16;
          
          return $true;
        }
      }
      }
    }
  });
  private static ESLVal isBindingQualifier = new ESLVal(new Function(new ESLVal("isBindingQualifier"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal q = $args[0];
  {ESLVal _v17 = q;
        
        switch(_v17.termName) {
        case "BQual": {ESLVal $301 = _v17.termRef(0);
          ESLVal $300 = _v17.termRef(1);
          ESLVal $299 = _v17.termRef(2);
          
          {ESLVal l = $301;
          
          {ESLVal p = $300;
          
          {ESLVal e = $299;
          
          return $true;
        }
        }
        }
        }
        default: {ESLVal _v91 = _v17;
          
          return $false;
        }
      }
      }
    }
  });
  private static ESLVal cmpToJCmp = new ESLVal(new Function(new ESLVal("cmpToJCmp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  ESLVal qs = $args[1];
  { LetRec letrec = new LetRec() {
        ESLVal inner = new ESLVal(new Function(new ESLVal("inner"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v86 = $args[0];
          {ESLVal _v18 = _v86;
                
                if(_v18.isCons())
                {ESLVal $302 = _v18.head();
                  ESLVal $303 = _v18.tail();
                  
                  switch($302.termName) {
                  case "BQual": {ESLVal $308 = $302.termRef(0);
                    ESLVal $307 = $302.termRef(1);
                    ESLVal $306 = $302.termRef(2);
                    
                    switch($307.termName) {
                    case "PVar": {ESLVal $311 = $307.termRef(0);
                      ESLVal $310 = $307.termRef(1);
                      ESLVal $309 = $307.termRef(2);
                      
                      {ESLVal l = $308;
                      
                      {ESLVal vl = $311;
                      
                      {ESLVal n = $310;
                      
                      {ESLVal t = $309;
                      
                      {ESLVal listExp = $306;
                      
                      {ESLVal _v88 = $303;
                      
                      return new ESLVal("JCmpBind",n,expToJExp.apply(listExp),inner.apply(_v88));
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: return error(new ESLVal("case error at Pos(15316,15514)").add(ESLVal.list(_v18)));
                  }
                  }
                case "PQual": {ESLVal $305 = $302.termRef(0);
                    ESLVal $304 = $302.termRef(1);
                    
                    {ESLVal l = $305;
                    
                    {ESLVal p = $304;
                    
                    {ESLVal _v87 = $303;
                    
                    return new ESLVal("JCmpIf",expToJExp.apply(p),inner.apply(_v87));
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(15316,15514)").add(ESLVal.list(_v18)));
                }
                }
              else if(_v18.isNil())
                return new ESLVal("JCmpList",expToJExp.apply(e));
              else return error(new ESLVal("case error at Pos(15316,15514)").add(ESLVal.list(_v18)));
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "inner": return inner;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal inner = letrec.get("inner");
      
        {ESLVal _v19 = qs;
        
        if(_v19.isCons())
        {ESLVal $312 = _v19.head();
          ESLVal $313 = _v19.tail();
          
          switch($312.termName) {
          case "BQual": {ESLVal $318 = $312.termRef(0);
            ESLVal $317 = $312.termRef(1);
            ESLVal $316 = $312.termRef(2);
            
            switch($317.termName) {
            case "PVar": {ESLVal $321 = $317.termRef(0);
              ESLVal $320 = $317.termRef(1);
              ESLVal $319 = $317.termRef(2);
              
              {ESLVal l = $318;
              
              {ESLVal vl = $321;
              
              {ESLVal n = $320;
              
              {ESLVal t = $319;
              
              {ESLVal listExp = $316;
              
              {ESLVal _v90 = $313;
              
              return new ESLVal("JCmpOuter",n,expToJExp.apply(listExp),inner.apply(_v90));
            }
            }
            }
            }
            }
            }
            }
            default: return error(new ESLVal("case error at Pos(15526,15723)").add(ESLVal.list(_v19)));
          }
          }
        case "PQual": {ESLVal $315 = $312.termRef(0);
            ESLVal $314 = $312.termRef(1);
            
            {ESLVal l = $315;
            
            {ESLVal p = $314;
            
            {ESLVal _v89 = $313;
            
            return new ESLVal("JCmpIf",expToJExp.apply(p),cmpToJCmp.apply(e,_v89));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(15526,15723)").add(ESLVal.list(_v19)));
        }
        }
      else if(_v19.isNil())
        return new ESLVal("JCmpList",expToJExp.apply(e));
      else return error(new ESLVal("case error at Pos(15526,15723)").add(ESLVal.list(_v19)));
      }}
      
    }
  });
  private static ESLVal refsToJExps = new ESLVal(new Function(new ESLVal("refsToJExps"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal refs = $args[0];
  {ESLVal _v20 = refs;
        
        if(_v20.isCons())
        {ESLVal $322 = _v20.head();
          ESLVal $323 = _v20.tail();
          
          switch($322.termName) {
          case "VarDynamicRef": {ESLVal $328 = $322.termRef(0);
            ESLVal $327 = $322.termRef(1);
            
            switch($327.termName) {
            case "Var": {ESLVal $330 = $327.termRef(0);
              ESLVal $329 = $327.termRef(1);
              
              {ESLVal l = $328;
              
              {ESLVal vl = $330;
              
              {ESLVal n = $329;
              
              {ESLVal _v85 = $323;
              
              return refsToJExps.apply(_v85).cons(new ESLVal("JVar",n,$null));
            }
            }
            }
            }
            }
            default: return error(new ESLVal("case error at Pos(15770,16011)").add(ESLVal.list(_v20)));
          }
          }
        case "ActorDynamicRef": {ESLVal $326 = $322.termRef(0);
            ESLVal $325 = $322.termRef(1);
            ESLVal $324 = $322.termRef(2);
            
            {ESLVal l = $326;
            
            {ESLVal e = $325;
            
            {ESLVal n = $324;
            
            {ESLVal _v84 = $323;
            
            return refsToJExps.apply(_v84).cons(new ESLVal("JRef",expToJExp.apply(e),n));
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(15770,16011)").add(ESLVal.list(_v20)));
        }
        }
      else if(_v20.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(15770,16011)").add(ESLVal.list(_v20)));
      }
    }
  });
  private static ESLVal actToJava = new ESLVal(new Function(new ESLVal("actToJava"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal name = $args[0];
  ESLVal decs = $args[1];
  ESLVal exports = $args[2];
  ESLVal parent = $args[3];
  ESLVal defs = $args[4];
  ESLVal init = $args[5];
  ESLVal arms = $args[6];
  if(parent.eql($null).boolVal)
        return simpleActToJava.apply(name,decs,exports,defs,init,arms);
        else
          return extendedActToJava.apply(name,decs,exports,parent,defs,init,arms);
    }
  });
  private static ESLVal wrapListeners = new ESLVal(new Function(new ESLVal("wrapListeners"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal exports = $args[0];
  ESLVal body = $args[1];
  {ESLVal p0 = new ESLVal("Pos",$zero,$zero);
        ESLVal t0 = $null;
        
        if(member.apply(new ESLVal("observeState"),exports).boolVal)
        return new ESLVal("Block",p0,ESLVal.list(body,new ESLVal("Let",p0,ESLVal.list(new ESLVal("Binding",p0,new ESLVal("$s"),t0,t0,new ESLVal("Apply",p0,new ESLVal("Var",p0,new ESLVal("observeState")),ESLVal.list()))),new ESLVal("For",p0,new ESLVal("PVar",p0,new ESLVal("$o"),t0),new ESLVal("Var",p0,new ESLVal("$observers")),new ESLVal("Case",p0,ESLVal.list(),ESLVal.list(new ESLVal("Apply",p0,new ESLVal("Var",p0,new ESLVal("observeMessage")),ESLVal.list(new ESLVal("Var",p0,new ESLVal("$m"))))),ESLVal.list(new ESLVal("BArm",p0,ESLVal.list(new ESLVal("PTerm",p0,new ESLVal("Something"),ESLVal.list(),ESLVal.list(new ESLVal("PVar",p0,new ESLVal("$x"),$null)))),new ESLVal("BoolExp",p0,$true),new ESLVal("Send",p0,new ESLVal("Var",p0,new ESLVal("$o")),new ESLVal("Term",p0,new ESLVal("Transition"),ESLVal.list(),ESLVal.list(new ESLVal("Self",p0),new ESLVal("Now",p0),new ESLVal("Var",p0,new ESLVal("$x")),new ESLVal("Var",p0,new ESLVal("$s")))))),new ESLVal("BArm",p0,ESLVal.list(new ESLVal("PTerm",p0,new ESLVal("Nothing"),ESLVal.list(),ESLVal.list())),new ESLVal("BoolExp",p0,$true),new ESLVal("Block",p0,ESLVal.list()))))))));
        else
          return body;
      }
    }
  });
  private static ESLVal addObserverJField = new ESLVal("JField",new ESLVal("addObserver"),$null,new ESLVal("JFun",new ESLVal("JConstExp",new ESLVal("JConstStr",new ESLVal("addObserver"))),ESLVal.list(new ESLVal("JDec",new ESLVal("o"),$null)),$null,new ESLVal("JBlock",ESLVal.list(new ESLVal("JUpdate",new ESLVal("$observers"),new ESLVal("JBinExp",new ESLVal("JVar",new ESLVal("o"),$null),new ESLVal("cons"),new ESLVal("JVar",new ESLVal("$observers"),$null))),new ESLVal("JReturn",new ESLVal("JSend",new ESLVal("JVar",new ESLVal("o"),$null),new ESLVal("Start"),ESLVal.list(new ESLVal("JSelf",new ESLVal[]{}),new ESLVal("JNow",new ESLVal[]{}),new ESLVal("JApply",new ESLVal("JVar",new ESLVal("observeState"),$null),ESLVal.list()))))))));
  private static ESLVal simpleActToJava = new ESLVal(new Function(new ESLVal("simpleActToJava"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal name = $args[0];
  ESLVal decs = $args[1];
  ESLVal exports = $args[2];
  ESLVal defs = $args[3];
  ESLVal init = $args[4];
  ESLVal arms = $args[5];
  {ESLVal timeArms = select.apply(isTimeArm,arms);
        
        {ESLVal nonTimeArms = reject.apply(isTimeArm,arms);
        
        {ESLVal timeCommand = ((Supplier<ESLVal>)() -> { 
            if(timeArms.eql(ESLVal.list()).boolVal)
              return new ESLVal("JBlock",ESLVal.list());
              else
                return timeArmsToJCommand.apply(timeArms);
          }).get();
        
        {ESLVal observers = ((Supplier<ESLVal>)() -> { 
            if(member.apply(new ESLVal("observeState"),exports).boolVal)
              return ESLVal.list(new ESLVal("JField",new ESLVal("$observers"),$null,new ESLVal("JList",$null,ESLVal.list())));
              else
                return ESLVal.list();
          }).get();
        
        {ESLVal addObserver = ((Supplier<ESLVal>)() -> { 
            if(member.apply(new ESLVal("observeState"),exports).boolVal)
              return ESLVal.list(addObserverJField);
              else
                return ESLVal.list();
          }).get();
        
        {ESLVal xAdd = ((Supplier<ESLVal>)() -> { 
            if(member.apply(new ESLVal("observeState"),exports).boolVal)
              return ESLVal.list(new ESLVal("addObserver"));
              else
                return ESLVal.list();
          }).get();
        
        {ESLVal f = new ESLVal("FunExp",new ESLVal("Pos",$zero,$zero),name,ESLVal.list(new ESLVal("Dec",new ESLVal("Pos",$zero,$zero),new ESLVal("$m"),$null,$null)),new ESLVal("VoidType",new ESLVal("Pos",$zero,$zero)),wrapListeners.apply(exports,new ESLVal("Case",new ESLVal("Pos",$zero,$zero),$nil,ESLVal.list(new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("$m"))),nonTimeArms)));
        
        return new ESLVal("JBehaviour",exports.add(xAdd),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              $v.add(defToField.apply(b));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(defs).add(observers.add(addObserver)),expToJExp.apply(init),expToJExp.apply(f),timeCommand);
      }
      }
      }
      }
      }
      }
      }
    }
  });
  private static ESLVal extendedActToJava = new ESLVal(new Function(new ESLVal("extendedActToJava"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal name = $args[0];
  ESLVal decs = $args[1];
  ESLVal exports = $args[2];
  ESLVal parent = $args[3];
  ESLVal defs = $args[4];
  ESLVal init = $args[5];
  ESLVal arms = $args[6];
  {ESLVal p0 = new ESLVal("Pos",$zero,$zero);
        
        {ESLVal timeSuper = new ESLVal("BArm",p0,ESLVal.list(new ESLVal("PTerm",p0,new ESLVal("Time"),ESLVal.list(),ESLVal.list(new ESLVal("PVar",p0,new ESLVal("$"),$null)))),new ESLVal("BoolExp",p0,$true),new ESLVal("SendTimeSuper",p0));
        
        {ESLVal timeArms = select.apply(isTimeArm,arms).add(ESLVal.list(timeSuper));
        
        {ESLVal messageSuper = new ESLVal("BArm",p0,ESLVal.list(new ESLVal("PVar",p0,new ESLVal("$m"),$null)),new ESLVal("BoolExp",p0,$true),new ESLVal("Block",p0,ESLVal.list(new ESLVal("SendSuper",p0,new ESLVal("Var",p0,new ESLVal("$m"))),new ESLVal("NullExp",p0))));
        
        {ESLVal nonTimeArms = reject.apply(isTimeArm,arms).add(ESLVal.list(messageSuper));
        
        {ESLVal timeCommand = ((Supplier<ESLVal>)() -> { 
            if(timeArms.eql(ESLVal.list()).boolVal)
              return new ESLVal("JBlock",ESLVal.list());
              else
                return timeArmsToJCommand.apply(timeArms);
          }).get();
        
        {ESLVal f = new ESLVal("FunExp",new ESLVal("Pos",$zero,$zero),name,ESLVal.list(new ESLVal("Dec",new ESLVal("Pos",$zero,$zero),new ESLVal("$m"),$null,$null)),new ESLVal("VoidType",new ESLVal("Pos",$zero,$zero)),wrapListeners.apply(exports,new ESLVal("Case",new ESLVal("Pos",$zero,$zero),$nil,ESLVal.list(new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("$m"))),nonTimeArms)));
        
        return new ESLVal("JExtendedBehaviour",exports,expToJExp.apply(parent),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              $v.add(defToField.apply(b));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(defs),expToJExp.apply(init),expToJExp.apply(f),timeCommand);
      }
      }
      }
      }
      }
      }
      }
    }
  });
  private static ESLVal isTimeArm = new ESLVal(new Function(new ESLVal("isTimeArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal a = $args[0];
  {ESLVal _v21 = a;
        
        switch(_v21.termName) {
        case "BArm": {ESLVal $334 = _v21.termRef(0);
          ESLVal $333 = _v21.termRef(1);
          ESLVal $332 = _v21.termRef(2);
          ESLVal $331 = _v21.termRef(3);
          
          if($333.isCons())
          {ESLVal $335 = $333.head();
            ESLVal $336 = $333.tail();
            
            switch($335.termName) {
            case "PTerm": {ESLVal $340 = $335.termRef(0);
              ESLVal $339 = $335.termRef(1);
              ESLVal $338 = $335.termRef(2);
              ESLVal $337 = $335.termRef(3);
              
              switch($339.strVal) {
              case "Time": if($336.isCons())
                {ESLVal $341 = $336.head();
                  ESLVal $342 = $336.tail();
                  
                  {ESLVal _v77 = _v21;
                  
                  return $false;
                }
                }
              else if($336.isNil())
                {ESLVal l = $334;
                  
                  {ESLVal pl = $340;
                  
                  {ESLVal ts = $338;
                  
                  {ESLVal ps = $337;
                  
                  {ESLVal g = $332;
                  
                  {ESLVal e = $331;
                  
                  return $true;
                }
                }
                }
                }
                }
                }
              else {ESLVal _v78 = _v21;
                  
                  return $false;
                }
              default: {ESLVal _v79 = _v21;
                
                return $false;
              }
            }
            }
            default: {ESLVal _v80 = _v21;
              
              return $false;
            }
          }
          }
        else if($333.isNil())
          {ESLVal _v81 = _v21;
            
            return $false;
          }
        else {ESLVal _v82 = _v21;
            
            return $false;
          }
        }
        default: {ESLVal _v83 = _v21;
          
          return $false;
        }
      }
      }
    }
  });
  private static ESLVal timeArmsToJCommand = new ESLVal(new Function(new ESLVal("timeArmsToJCommand"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  {ESLVal _v22 = arms;
        
        if(_v22.isCons())
        {ESLVal $343 = _v22.head();
          ESLVal $344 = _v22.tail();
          
          switch($343.termName) {
          case "BArm": {ESLVal $348 = $343.termRef(0);
            ESLVal $347 = $343.termRef(1);
            ESLVal $346 = $343.termRef(2);
            ESLVal $345 = $343.termRef(3);
            
            if($347.isCons())
            {ESLVal $349 = $347.head();
              ESLVal $350 = $347.tail();
              
              switch($349.termName) {
              case "PTerm": {ESLVal $354 = $349.termRef(0);
                ESLVal $353 = $349.termRef(1);
                ESLVal $352 = $349.termRef(2);
                ESLVal $351 = $349.termRef(3);
                
                switch($353.strVal) {
                case "Time": if($352.isCons())
                  {ESLVal $355 = $352.head();
                    ESLVal $356 = $352.tail();
                    
                    return error(new ESLVal("case error at Pos(19624,20154)").add(ESLVal.list(_v22)));
                  }
                else if($352.isNil())
                  if($351.isCons())
                    {ESLVal $357 = $351.head();
                      ESLVal $358 = $351.tail();
                      
                      switch($357.termName) {
                      case "PVar": {ESLVal $369 = $357.termRef(0);
                        ESLVal $368 = $357.termRef(1);
                        ESLVal $367 = $357.termRef(2);
                        
                        if($358.isCons())
                        {ESLVal $370 = $358.head();
                          ESLVal $371 = $358.tail();
                          
                          return error(new ESLVal("case error at Pos(19624,20154)").add(ESLVal.list(_v22)));
                        }
                      else if($358.isNil())
                        if($350.isCons())
                          {ESLVal $372 = $350.head();
                            ESLVal $373 = $350.tail();
                            
                            return error(new ESLVal("case error at Pos(19624,20154)").add(ESLVal.list(_v22)));
                          }
                        else if($350.isNil())
                          {ESLVal l = $348;
                            
                            {ESLVal tl = $354;
                            
                            {ESLVal vl = $369;
                            
                            {ESLVal n = $368;
                            
                            {ESLVal t = $367;
                            
                            {ESLVal g = $346;
                            
                            {ESLVal e = $345;
                            
                            {ESLVal _v76 = $344;
                            
                            return new ESLVal("JLet",ESLVal.list(new ESLVal("JField",n,$null,new ESLVal("JVar",new ESLVal("$t"),$null))),new ESLVal("JIfCommand",expToJExp.apply(g),expToJCommand.apply(e,$false),timeArmsToJCommand.apply(_v76)));
                          }
                          }
                          }
                          }
                          }
                          }
                          }
                          }
                        else return error(new ESLVal("case error at Pos(19624,20154)").add(ESLVal.list(_v22)));
                      else return error(new ESLVal("case error at Pos(19624,20154)").add(ESLVal.list(_v22)));
                      }
                    case "PInt": {ESLVal $360 = $357.termRef(0);
                        ESLVal $359 = $357.termRef(1);
                        
                        if($358.isCons())
                        {ESLVal $361 = $358.head();
                          ESLVal $362 = $358.tail();
                          
                          return error(new ESLVal("case error at Pos(19624,20154)").add(ESLVal.list(_v22)));
                        }
                      else if($358.isNil())
                        if($350.isCons())
                          {ESLVal $363 = $350.head();
                            ESLVal $364 = $350.tail();
                            
                            return error(new ESLVal("case error at Pos(19624,20154)").add(ESLVal.list(_v22)));
                          }
                        else if($350.isNil())
                          switch($346.termName) {
                            case "BoolExp": {ESLVal $366 = $346.termRef(0);
                              ESLVal $365 = $346.termRef(1);
                              
                              switch($365.boolVal ? 1 : 0) {
                              case 1: {ESLVal l = $348;
                                
                                {ESLVal tl = $354;
                                
                                {ESLVal vl = $360;
                                
                                {ESLVal n = $359;
                                
                                {ESLVal bl = $366;
                                
                                {ESLVal e = $345;
                                
                                {ESLVal _v75 = $344;
                                
                                return new ESLVal("JIfCommand",new ESLVal("JBinExp",new ESLVal("JVar",new ESLVal("$t"),$null),new ESLVal("eq"),new ESLVal("JConstExp",new ESLVal("JConstInt",n))),expToJCommand.apply(e,$false),timeArmsToJCommand.apply(_v75));
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              default: return error(new ESLVal("case error at Pos(19624,20154)").add(ESLVal.list(_v22)));
                            }
                            }
                            default: return error(new ESLVal("case error at Pos(19624,20154)").add(ESLVal.list(_v22)));
                          }
                        else return error(new ESLVal("case error at Pos(19624,20154)").add(ESLVal.list(_v22)));
                      else return error(new ESLVal("case error at Pos(19624,20154)").add(ESLVal.list(_v22)));
                      }
                      default: return error(new ESLVal("case error at Pos(19624,20154)").add(ESLVal.list(_v22)));
                    }
                    }
                  else if($351.isNil())
                    return error(new ESLVal("case error at Pos(19624,20154)").add(ESLVal.list(_v22)));
                  else return error(new ESLVal("case error at Pos(19624,20154)").add(ESLVal.list(_v22)));
                else return error(new ESLVal("case error at Pos(19624,20154)").add(ESLVal.list(_v22)));
                default: return error(new ESLVal("case error at Pos(19624,20154)").add(ESLVal.list(_v22)));
              }
              }
              default: return error(new ESLVal("case error at Pos(19624,20154)").add(ESLVal.list(_v22)));
            }
            }
          else if($347.isNil())
            return error(new ESLVal("case error at Pos(19624,20154)").add(ESLVal.list(_v22)));
          else return error(new ESLVal("case error at Pos(19624,20154)").add(ESLVal.list(_v22)));
          }
          default: return error(new ESLVal("case error at Pos(19624,20154)").add(ESLVal.list(_v22)));
        }
        }
      else if(_v22.isNil())
        return new ESLVal("JBlock",ESLVal.list());
      else return error(new ESLVal("case error at Pos(19624,20154)").add(ESLVal.list(_v22)));
      }
    }
  });
  private static ESLVal cmpToJExp = new ESLVal(new Function(new ESLVal("cmpToJExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  ESLVal qs = $args[1];
  {ESLVal _v23 = qs;
        
        if(_v23.isCons())
        {ESLVal $374 = _v23.head();
          ESLVal $375 = _v23.tail();
          
          switch($374.termName) {
          case "BQual": {ESLVal $380 = $374.termRef(0);
            ESLVal $379 = $374.termRef(1);
            ESLVal $378 = $374.termRef(2);
            
            {ESLVal l = $380;
            
            {ESLVal p = $379;
            
            {ESLVal v = $378;
            
            {ESLVal _v74 = $375;
            
            {ESLVal f = new ESLVal("FunExp",new ESLVal("Pos",$zero,$zero),new ESLVal("StrExp",new ESLVal("Pos",$zero,$zero),new ESLVal("qual")),ESLVal.list(new ESLVal("Dec",new ESLVal("Pos",$zero,$zero),new ESLVal("$qualArg"),$null,$null)),$null,new ESLVal("Case",new ESLVal("Pos",$zero,$zero),ESLVal.list(),ESLVal.list(new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("$qualArg"))),ESLVal.list(new ESLVal("BArm",new ESLVal("Pos",$zero,$zero),ESLVal.list(p),new ESLVal("BoolExp",new ESLVal("Pos",$zero,$zero),$true),new ESLVal("List",new ESLVal("Pos",$zero,$zero),ESLVal.list(new ESLVal("Cmp",new ESLVal("Pos",$zero,$zero),e,_v74)))),new ESLVal("BArm",new ESLVal("Pos",$zero,$zero),ESLVal.list(new ESLVal("PVar",new ESLVal("Pos",$zero,$zero),new ESLVal("_0"),$null)),new ESLVal("BoolExp",new ESLVal("Pos",$zero,$zero),$true),new ESLVal("List",new ESLVal("Pos",$zero,$zero),$nil)))));
            
            return new ESLVal("JFlatten",new ESLVal("JFlatten",new ESLVal("JMapFun",expToJExp.apply(f),expToJExp.apply(v))));
          }
          }
          }
          }
          }
          }
        case "PQual": {ESLVal $377 = $374.termRef(0);
            ESLVal $376 = $374.termRef(1);
            
            {ESLVal l = $377;
            
            {ESLVal p = $376;
            
            {ESLVal _v73 = $375;
            
            return new ESLVal("JIfExp",expToJExp.apply(p),cmpToJExp.apply(e,_v73),new ESLVal("JNil",$null));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(20201,20869)").add(ESLVal.list(_v23)));
        }
        }
      else if(_v23.isNil())
        return new ESLVal("JList",$null,ESLVal.list(expToJExp.apply(e)));
      else return error(new ESLVal("case error at Pos(20201,20869)").add(ESLVal.list(_v23)));
      }
    }
  });
  public static ESLVal moduleToJava = new ESLVal(new Function(new ESLVal("moduleToJava"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal module = $args[0];
  {ESLVal _v24 = module;
        
        switch(_v24.termName) {
        case "Module": {ESLVal $387 = _v24.termRef(0);
          ESLVal $386 = _v24.termRef(1);
          ESLVal $385 = _v24.termRef(2);
          ESLVal $384 = _v24.termRef(3);
          ESLVal $383 = _v24.termRef(4);
          ESLVal $382 = _v24.termRef(5);
          ESLVal $381 = _v24.termRef(6);
          
          {ESLVal path = $387;
          
          {ESLVal name = $386;
          
          {ESLVal exports = $385;
          
          {ESLVal imports = $384;
          
          {ESLVal x = $383;
          
          {ESLVal y = $382;
          
          {ESLVal defs = $381;
          
          return renameJVarsModule.apply(new ESLVal("JModule",name,exports,imports,new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal d = $l0.head();
                $l0 = $l0.tail();
                if(isBinding.apply(d).or(isFunBind.apply(d)).boolVal) {$v.add(defToField.apply(d));
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(expandFunDefs.apply(mergeFunDefs.apply(defs)))));
        }
        }
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(20907,21180)").add(ESLVal.list(_v24)));
      }
      }
    }
  });
  private static ESLVal renameJVarsModule = new ESLVal(new Function(new ESLVal("renameJVarsModule"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal m = $args[0];
  {ESLVal _v25 = m;
        
        switch(_v25.termName) {
        case "JModule": {ESLVal $391 = _v25.termRef(0);
          ESLVal $390 = _v25.termRef(1);
          ESLVal $389 = _v25.termRef(2);
          ESLVal $388 = _v25.termRef(3);
          
          {ESLVal name = $391;
          
          {ESLVal exports = $390;
          
          {ESLVal imports = $389;
          
          {ESLVal fs = $388;
          
          {ESLVal fieldNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v26 = $qualArg;
                  
                  switch(_v26.termName) {
                  case "JField": {ESLVal $394 = _v26.termRef(0);
                    ESLVal $393 = _v26.termRef(1);
                    ESLVal $392 = _v26.termRef(2);
                    
                    {ESLVal n = $394;
                    
                    {ESLVal t = $393;
                    
                    {ESLVal e = $392;
                    
                    return ESLVal.list(ESLVal.list(n));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v26;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(fs).flatten().flatten();
          
          return new ESLVal("JModule",name,exports,imports,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v27 = $qualArg;
                
                switch(_v27.termName) {
                case "JField": {ESLVal $397 = _v27.termRef(0);
                  ESLVal $396 = _v27.termRef(1);
                  ESLVal $395 = _v27.termRef(2);
                  
                  {ESLVal n = $397;
                  
                  {ESLVal t = $396;
                  
                  {ESLVal e = $395;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(e,fieldNames,emptyTable))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v27;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten());
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(21220,21527)").add(ESLVal.list(_v25)));
      }
      }
    }
  });
  private static ESLVal renameJVarsExp = new ESLVal(new Function(new ESLVal("renameJVarsExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  ESLVal vars = $args[1];
  ESLVal env = $args[2];
  {ESLVal _v28 = e;
        
        switch(_v28.termName) {
        case "JFun": {ESLVal $477 = _v28.termRef(0);
          ESLVal $476 = _v28.termRef(1);
          ESLVal $475 = _v28.termRef(2);
          ESLVal $474 = _v28.termRef(3);
          
          {ESLVal v0 = $477;
          
          {ESLVal v1 = $476;
          
          {ESLVal v2 = $475;
          
          {ESLVal v3 = $474;
          
          {ESLVal boundNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v32 = $qualArg;
                  
                  switch(_v32.termName) {
                  case "JDec": {ESLVal $488 = _v32.termRef(0);
                    ESLVal $487 = _v32.termRef(1);
                    
                    {ESLVal n = $488;
                    
                    {ESLVal t = $487;
                    
                    return ESLVal.list(ESLVal.list(n));
                  }
                  }
                  }
                  default: {ESLVal _0 = _v32;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v1).flatten().flatten();
          
          if(exists.apply(new ESLVal(new Function(new ESLVal("fun418"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal n = $args[0];
        return member.apply(n,boundNames);
          }
        }),vars).boolVal)
          {ESLVal newNames = new java.util.function.Function<ESLVal,ESLVal>() {
                public ESLVal apply(ESLVal $l0) {
                  ESLVal $a = $nil;
                  java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                  while(!$l0.isNil()) { 
                    ESLVal n = $l0.head();
                    $l0 = $l0.tail();
                    $v.add(newName.apply());
                  }
                  for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                  return $a;
                }}.apply(boundNames);
            
            {ESLVal env1 = addEntries.apply(boundNames,newNames,env);
            
            return new ESLVal("JFun",v0,new java.util.function.Function<ESLVal,ESLVal>() {
              public ESLVal apply(ESLVal $l0) {
                ESLVal $a = $nil;
                java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                while(!$l0.isNil()) { 
                  ESLVal n = $l0.head();
                  $l0 = $l0.tail();
                  $v.add(new ESLVal("JDec",n,$null));
                }
                for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                return $a;
              }}.apply(newNames),v2,renameJVarsCommand.apply(v3,boundNames.add(vars),env1));
          }
          }
          else
            return new ESLVal("JFun",v0,v1,v2,renameJVarsCommand.apply(v3,boundNames.add(vars),env));
        }
        }
        }
        }
        }
        }
      case "JApply": {ESLVal $473 = _v28.termRef(0);
          ESLVal $472 = _v28.termRef(1);
          
          {ESLVal v0 = $473;
          
          {ESLVal v1 = $472;
          
          return new ESLVal("JApply",renameJVarsExp.apply(v0,vars,env),new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal v = $l0.head();
                $l0 = $l0.tail();
                $v.add(renameJVarsExp.apply(v,vars,env));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v1));
        }
        }
        }
      case "JArrayRef": {ESLVal $471 = _v28.termRef(0);
          ESLVal $470 = _v28.termRef(1);
          
          {ESLVal a = $471;
          
          {ESLVal i = $470;
          
          return new ESLVal("JArrayRef",renameJVarsExp.apply(a,vars,env),renameJVarsExp.apply(i,vars,env));
        }
        }
        }
      case "JArrayUpdate": {ESLVal $469 = _v28.termRef(0);
          ESLVal $468 = _v28.termRef(1);
          ESLVal $467 = _v28.termRef(2);
          
          {ESLVal a = $469;
          
          {ESLVal i = $468;
          
          {ESLVal v = $467;
          
          return new ESLVal("JArrayUpdate",renameJVarsExp.apply(a,vars,env),renameJVarsExp.apply(i,vars,env),renameJVarsExp.apply(v,vars,env));
        }
        }
        }
        }
      case "JBecome": {ESLVal $466 = _v28.termRef(0);
          ESLVal $465 = _v28.termRef(1);
          
          {ESLVal _v72 = $466;
          
          {ESLVal es = $465;
          
          return new ESLVal("JBecome",renameJVarsExp.apply(_v72,vars,env),new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal v = $l0.head();
                $l0 = $l0.tail();
                $v.add(renameJVarsExp.apply(v,vars,env));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(es));
        }
        }
        }
      case "JBinExp": {ESLVal $464 = _v28.termRef(0);
          ESLVal $463 = _v28.termRef(1);
          ESLVal $462 = _v28.termRef(2);
          
          {ESLVal v0 = $464;
          
          {ESLVal v1 = $463;
          
          {ESLVal v2 = $462;
          
          return new ESLVal("JBinExp",renameJVarsExp.apply(v0,vars,env),v1,renameJVarsExp.apply(v2,vars,env));
        }
        }
        }
        }
      case "JCommandExp": {ESLVal $461 = _v28.termRef(0);
          ESLVal $460 = _v28.termRef(1);
          
          {ESLVal v0 = $461;
          
          {ESLVal v1 = $460;
          
          return new ESLVal("JCommandExp",renameJVarsCommand.apply(v0,vars,env),v1);
        }
        }
        }
      case "JIfExp": {ESLVal $459 = _v28.termRef(0);
          ESLVal $458 = _v28.termRef(1);
          ESLVal $457 = _v28.termRef(2);
          
          {ESLVal v0 = $459;
          
          {ESLVal v1 = $458;
          
          {ESLVal v2 = $457;
          
          return new ESLVal("JIfExp",renameJVarsExp.apply(v0,vars,env),renameJVarsExp.apply(v1,vars,env),renameJVarsExp.apply(v2,vars,env));
        }
        }
        }
        }
      case "JConstExp": {ESLVal $456 = _v28.termRef(0);
          
          {ESLVal v0 = $456;
          
          return e;
        }
        }
      case "JTerm": {ESLVal $455 = _v28.termRef(0);
          ESLVal $454 = _v28.termRef(1);
          
          {ESLVal v0 = $455;
          
          {ESLVal v1 = $454;
          
          return new ESLVal("JTerm",v0,new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal v = $l0.head();
                $l0 = $l0.tail();
                $v.add(renameJVarsExp.apply(v,vars,env));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v1));
        }
        }
        }
      case "JTermRef": {ESLVal $453 = _v28.termRef(0);
          ESLVal $452 = _v28.termRef(1);
          
          {ESLVal v0 = $453;
          
          {ESLVal v1 = $452;
          
          return new ESLVal("JTermRef",renameJVarsExp.apply(v0,vars,env),v1);
        }
        }
        }
      case "JList": {ESLVal $451 = _v28.termRef(0);
          ESLVal $450 = _v28.termRef(1);
          
          {ESLVal v0 = $451;
          
          {ESLVal v1 = $450;
          
          return new ESLVal("JList",v0,new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal v = $l0.head();
                $l0 = $l0.tail();
                $v.add(renameJVarsExp.apply(v,vars,env));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v1));
        }
        }
        }
      case "JSet": {ESLVal $449 = _v28.termRef(0);
          ESLVal $448 = _v28.termRef(1);
          
          {ESLVal v0 = $449;
          
          {ESLVal v1 = $448;
          
          return new ESLVal("JSet",v0,new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal v = $l0.head();
                $l0 = $l0.tail();
                $v.add(renameJVarsExp.apply(v,vars,env));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v1));
        }
        }
        }
      case "JBag": {ESLVal $447 = _v28.termRef(0);
          ESLVal $446 = _v28.termRef(1);
          
          {ESLVal v0 = $447;
          
          {ESLVal v1 = $446;
          
          return new ESLVal("JBag",v0,new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal v = $l0.head();
                $l0 = $l0.tail();
                $v.add(renameJVarsExp.apply(v,vars,env));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v1));
        }
        }
        }
      case "JNil": {ESLVal $445 = _v28.termRef(0);
          
          {ESLVal v0 = $445;
          
          return e;
        }
        }
      case "JNow": {
          return e;
        }
      case "JVar": {ESLVal $444 = _v28.termRef(0);
          ESLVal $443 = _v28.termRef(1);
          
          {ESLVal v0 = $444;
          
          {ESLVal v1 = $443;
          
          if(hasEntry.apply(v0,env).boolVal)
          return new ESLVal("JVar",lookup.apply(v0,env),v1);
          else
            return e;
        }
        }
        }
      case "JNull": {
          return e;
        }
      case "JError": {ESLVal $442 = _v28.termRef(0);
          
          {ESLVal v0 = $442;
          
          return new ESLVal("JError",renameJVarsExp.apply(v0,vars,env));
        }
        }
      case "JHead": {ESLVal $441 = _v28.termRef(0);
          
          {ESLVal v0 = $441;
          
          return new ESLVal("JHead",renameJVarsExp.apply(v0,vars,env));
        }
        }
      case "JTail": {ESLVal $440 = _v28.termRef(0);
          
          {ESLVal v0 = $440;
          
          return new ESLVal("JTail",renameJVarsExp.apply(v0,vars,env));
        }
        }
      case "JCastp": {ESLVal $439 = _v28.termRef(0);
          ESLVal $438 = _v28.termRef(1);
          ESLVal $437 = _v28.termRef(2);
          
          {ESLVal v0 = $439;
          
          {ESLVal v1 = $438;
          
          {ESLVal v2 = $437;
          
          return new ESLVal("JCastp",v0,v1,renameJVarsExp.apply(v2,vars,env));
        }
        }
        }
        }
      case "JCast": {ESLVal $436 = _v28.termRef(0);
          ESLVal $435 = _v28.termRef(1);
          
          {ESLVal v0 = $436;
          
          {ESLVal v1 = $435;
          
          return new ESLVal("JCast",v0,renameJVarsExp.apply(v1,vars,env));
        }
        }
        }
      case "JCmpExp": {ESLVal $434 = _v28.termRef(0);
          
          {ESLVal cmp = $434;
          
          return new ESLVal("JCmpExp",renameJVarsCmp.apply(cmp,vars,env));
        }
        }
      case "JNot": {ESLVal $433 = _v28.termRef(0);
          
          {ESLVal _v71 = $433;
          
          return new ESLVal("JNot",renameJVarsExp.apply(_v71,vars,env));
        }
        }
      case "JNew": {ESLVal $432 = _v28.termRef(0);
          ESLVal $431 = _v28.termRef(1);
          
          {ESLVal b = $432;
          
          {ESLVal args = $431;
          
          return new ESLVal("JNew",renameJVarsExp.apply(b,vars,env),new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal a = $l0.head();
                $l0 = $l0.tail();
                $v.add(renameJVarsExp.apply(a,vars,env));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(args));
        }
        }
        }
      case "JNewArray": {ESLVal $430 = _v28.termRef(0);
          
          {ESLVal b = $430;
          
          return new ESLVal("JNewArray",renameJVarsExp.apply(b,vars,env));
        }
        }
      case "JNewJava": {ESLVal $429 = _v28.termRef(0);
          ESLVal $428 = _v28.termRef(1);
          
          {ESLVal n = $429;
          
          {ESLVal args = $428;
          
          return new ESLVal("JNewJava",n,new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal a = $l0.head();
                $l0 = $l0.tail();
                $v.add(renameJVarsExp.apply(a,vars,env));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(args));
        }
        }
        }
      case "JNewTable": {
          return new ESLVal("JNewTable",new ESLVal[]{});
        }
      case "JMapFun": {ESLVal $427 = _v28.termRef(0);
          ESLVal $426 = _v28.termRef(1);
          
          {ESLVal f = $427;
          
          {ESLVal l = $426;
          
          return new ESLVal("JMapFun",renameJVarsExp.apply(f,vars,env),renameJVarsExp.apply(l,vars,env));
        }
        }
        }
      case "JRecord": {ESLVal $425 = _v28.termRef(0);
          
          {ESLVal fs = $425;
          
          return new ESLVal("JRecord",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v31 = $qualArg;
                
                switch(_v31.termName) {
                case "JField": {ESLVal $486 = _v31.termRef(0);
                  ESLVal $485 = _v31.termRef(1);
                  ESLVal $484 = _v31.termRef(2);
                  
                  {ESLVal n = $486;
                  
                  {ESLVal t = $485;
                  
                  {ESLVal _v70 = $484;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(_v70,vars,env))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v31;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten());
        }
        }
      case "JFlatten": {ESLVal $424 = _v28.termRef(0);
          
          {ESLVal _v69 = $424;
          
          return new ESLVal("JFlatten",renameJVarsExp.apply(_v69,vars,env));
        }
        }
      case "JSend": {ESLVal $423 = _v28.termRef(0);
          ESLVal $422 = _v28.termRef(1);
          ESLVal $421 = _v28.termRef(2);
          
          {ESLVal _v68 = $423;
          
          {ESLVal n = $422;
          
          {ESLVal es = $421;
          
          return new ESLVal("JSend",renameJVarsExp.apply(_v68,vars,env),n,new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal e = $l0.head();
                $l0 = $l0.tail();
                $v.add(renameJVarsExp.apply(e,vars,env));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(es));
        }
        }
        }
        }
      case "JSendSuper": {ESLVal $420 = _v28.termRef(0);
          
          {ESLVal _v67 = $420;
          
          return new ESLVal("JSendSuper",renameJVarsExp.apply(_v67,vars,env));
        }
        }
      case "JSendTimeSuper": {
          return new ESLVal("JSendTimeSuper",new ESLVal[]{});
        }
      case "JSelf": {
          return new ESLVal("JSelf",new ESLVal[]{});
        }
      case "JRef": {ESLVal $419 = _v28.termRef(0);
          ESLVal $418 = _v28.termRef(1);
          
          {ESLVal _v66 = $419;
          
          {ESLVal n = $418;
          
          return new ESLVal("JRef",renameJVarsExp.apply(_v66,vars,env),n);
        }
        }
        }
      case "JRefSuper": {ESLVal $417 = _v28.termRef(0);
          
          {ESLVal n = $417;
          
          return new ESLVal("JRefSuper",n);
        }
        }
      case "JBehaviour": {ESLVal $416 = _v28.termRef(0);
          ESLVal $415 = _v28.termRef(1);
          ESLVal $414 = _v28.termRef(2);
          ESLVal $413 = _v28.termRef(3);
          ESLVal $412 = _v28.termRef(4);
          
          {ESLVal es = $416;
          
          {ESLVal fs = $415;
          
          {ESLVal init = $414;
          
          {ESLVal handler = $413;
          
          {ESLVal time = $412;
          
          return new ESLVal("JBehaviour",es,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v30 = $qualArg;
                
                switch(_v30.termName) {
                case "JField": {ESLVal $483 = _v30.termRef(0);
                  ESLVal $482 = _v30.termRef(1);
                  ESLVal $481 = _v30.termRef(2);
                  
                  {ESLVal n = $483;
                  
                  {ESLVal t = $482;
                  
                  {ESLVal _v65 = $481;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(_v65,vars,env))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v30;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten(),renameJVarsExp.apply(init,vars,env),renameJVarsExp.apply(handler,vars,env),renameJVarsCommand.apply(time,vars,env));
        }
        }
        }
        }
        }
        }
      case "JExtendedBehaviour": {ESLVal $411 = _v28.termRef(0);
          ESLVal $410 = _v28.termRef(1);
          ESLVal $409 = _v28.termRef(2);
          ESLVal $408 = _v28.termRef(3);
          ESLVal $407 = _v28.termRef(4);
          ESLVal $406 = _v28.termRef(5);
          
          {ESLVal es = $411;
          
          {ESLVal parent = $410;
          
          {ESLVal fs = $409;
          
          {ESLVal init = $408;
          
          {ESLVal handler = $407;
          
          {ESLVal time = $406;
          
          return new ESLVal("JExtendedBehaviour",es,renameJVarsExp.apply(parent,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v29 = $qualArg;
                
                switch(_v29.termName) {
                case "JField": {ESLVal $480 = _v29.termRef(0);
                  ESLVal $479 = _v29.termRef(1);
                  ESLVal $478 = _v29.termRef(2);
                  
                  {ESLVal n = $480;
                  
                  {ESLVal t = $479;
                  
                  {ESLVal _v64 = $478;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(_v64,vars,env))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v29;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten(),renameJVarsExp.apply(init,vars,env),renameJVarsExp.apply(handler,vars,env),renameJVarsCommand.apply(time,vars,env));
        }
        }
        }
        }
        }
        }
        }
      case "JTry": {ESLVal $405 = _v28.termRef(0);
          ESLVal $404 = _v28.termRef(1);
          ESLVal $403 = _v28.termRef(2);
          
          {ESLVal _v63 = $405;
          
          {ESLVal n = $404;
          
          {ESLVal c = $403;
          
          return new ESLVal("JTry",renameJVarsExp.apply(_v63,vars,env),n,renameJVarsCommand.apply(c,vars,env));
        }
        }
        }
        }
      case "JProbably": {ESLVal $402 = _v28.termRef(0);
          ESLVal $401 = _v28.termRef(1);
          ESLVal $400 = _v28.termRef(2);
          
          {ESLVal _v62 = $402;
          
          {ESLVal e1 = $401;
          
          {ESLVal e2 = $400;
          
          return new ESLVal("JProbably",renameJVarsExp.apply(_v62,vars,env),renameJVarsExp.apply(e1,vars,env),renameJVarsExp.apply(e2,vars,env));
        }
        }
        }
        }
      case "JGrab": {ESLVal $399 = _v28.termRef(0);
          ESLVal $398 = _v28.termRef(1);
          
          {ESLVal es = $399;
          
          {ESLVal c = $398;
          
          return new ESLVal("JGrab",new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal e = $l0.head();
                $l0 = $l0.tail();
                $v.add(renameJVarsExp.apply(e,vars,env));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(es),renameJVarsExp.apply(c,vars,env));
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(21597,26241)").add(ESLVal.list(_v28)));
      }
      }
    }
  });
  private static ESLVal renameJVarsCmp = new ESLVal(new Function(new ESLVal("renameJVarsCmp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal c = $args[0];
  ESLVal vars = $args[1];
  ESLVal env = $args[2];
  {ESLVal _v33 = c;
        
        switch(_v33.termName) {
        case "JCmpList": {ESLVal $497 = _v33.termRef(0);
          
          {ESLVal e = $497;
          
          return new ESLVal("JCmpList",renameJVarsExp.apply(e,vars,env));
        }
        }
      case "JCmpOuter": {ESLVal $496 = _v33.termRef(0);
          ESLVal $495 = _v33.termRef(1);
          ESLVal $494 = _v33.termRef(2);
          
          {ESLVal n = $496;
          
          {ESLVal e = $495;
          
          {ESLVal _v59 = $494;
          
          {ESLVal _v60 = remove.apply(n,vars);
          ESLVal _v61 = addEntry.apply(n,n,env);
          
          return new ESLVal("JCmpOuter",n,renameJVarsExp.apply(e,_v60,_v61),renameJVarsCmp.apply(_v59,_v60,_v61));
        }
        }
        }
        }
        }
      case "JCmpBind": {ESLVal $493 = _v33.termRef(0);
          ESLVal $492 = _v33.termRef(1);
          ESLVal $491 = _v33.termRef(2);
          
          {ESLVal n = $493;
          
          {ESLVal e = $492;
          
          {ESLVal _v56 = $491;
          
          {ESLVal _v57 = remove.apply(n,vars);
          ESLVal _v58 = addEntry.apply(n,n,env);
          
          return new ESLVal("JCmpBind",n,renameJVarsExp.apply(e,_v57,_v58),renameJVarsCmp.apply(_v56,_v57,_v58));
        }
        }
        }
        }
        }
      case "JCmpIf": {ESLVal $490 = _v33.termRef(0);
          ESLVal $489 = _v33.termRef(1);
          
          {ESLVal e = $490;
          
          {ESLVal _v55 = $489;
          
          return new ESLVal("JCmpIf",renameJVarsExp.apply(e,vars,env),renameJVarsCmp.apply(_v55,vars,env));
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(26316,26897)").add(ESLVal.list(_v33)));
      }
      }
    }
  });
  private static ESLVal nameCount = $zero;
  private static ESLVal newName = new ESLVal(new Function(new ESLVal("newName"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      {nameCount = nameCount.add($one);
      return new ESLVal("_v").add(nameCount);}
    }
  });
  private static ESLVal renameJVarsCommand = new ESLVal(new Function(new ESLVal("renameJVarsCommand"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal c = $args[0];
  ESLVal vars = $args[1];
  ESLVal env = $args[2];
  {ESLVal _v34 = c;
        
        switch(_v34.termName) {
        case "JBlock": {ESLVal $538 = _v34.termRef(0);
          
          {ESLVal v0 = $538;
          
          return new ESLVal("JBlock",new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal c = $l0.head();
                $l0 = $l0.tail();
                $v.add(renameJVarsCommand.apply(c,vars,env));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(v0));
        }
        }
      case "JReturn": {ESLVal $537 = _v34.termRef(0);
          
          {ESLVal v0 = $537;
          
          return new ESLVal("JReturn",renameJVarsExp.apply(v0,vars,env));
        }
        }
      case "JSwitch": {ESLVal $536 = _v34.termRef(0);
          ESLVal $535 = _v34.termRef(1);
          ESLVal $534 = _v34.termRef(2);
          
          {ESLVal v0 = $536;
          
          {ESLVal v1 = $535;
          
          {ESLVal v2 = $534;
          
          return error(new ESLVal("jswitch should not occur"));
        }
        }
        }
        }
      case "JSwitchList": {ESLVal $533 = _v34.termRef(0);
          ESLVal $532 = _v34.termRef(1);
          ESLVal $531 = _v34.termRef(2);
          ESLVal $530 = _v34.termRef(3);
          
          {ESLVal v0 = $533;
          
          {ESLVal v1 = $532;
          
          {ESLVal v2 = $531;
          
          {ESLVal v3 = $530;
          
          return new ESLVal("JSwitchList",renameJVarsExp.apply(v0,vars,env),renameJVarsCommand.apply(v1,vars,env),renameJVarsCommand.apply(v2,vars,env),renameJVarsCommand.apply(v3,vars,env));
        }
        }
        }
        }
        }
      case "JIfCommand": {ESLVal $529 = _v34.termRef(0);
          ESLVal $528 = _v34.termRef(1);
          ESLVal $527 = _v34.termRef(2);
          
          {ESLVal v0 = $529;
          
          {ESLVal v1 = $528;
          
          {ESLVal v2 = $527;
          
          return new ESLVal("JIfCommand",renameJVarsExp.apply(v0,vars,env),renameJVarsCommand.apply(v1,vars,env),renameJVarsCommand.apply(v2,vars,env));
        }
        }
        }
        }
      case "JCaseList": {ESLVal $526 = _v34.termRef(0);
          ESLVal $525 = _v34.termRef(1);
          ESLVal $524 = _v34.termRef(2);
          ESLVal $523 = _v34.termRef(3);
          
          {ESLVal v0 = $526;
          
          {ESLVal v1 = $525;
          
          {ESLVal v2 = $524;
          
          {ESLVal v3 = $523;
          
          return new ESLVal("JCaseList",renameJVarsExp.apply(v0,vars,env),renameJVarsCommand.apply(v1,vars,env),renameJVarsCommand.apply(v2,vars,env),renameJVarsCommand.apply(v3,vars,env));
        }
        }
        }
        }
        }
      case "JCaseInt": {ESLVal $522 = _v34.termRef(0);
          ESLVal $521 = _v34.termRef(1);
          ESLVal $520 = _v34.termRef(2);
          
          {ESLVal e = $522;
          
          {ESLVal arms = $521;
          
          {ESLVal alt = $520;
          
          return new ESLVal("JCaseInt",renameJVarsExp.apply(e,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v47 = $qualArg;
                
                switch(_v47.termName) {
                case "JIArm": {ESLVal $574 = _v47.termRef(0);
                  ESLVal $573 = _v47.termRef(1);
                  
                  {ESLVal n = $574;
                  
                  {ESLVal _v54 = $573;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JIArm",n,renameJVarsCommand.apply(_v54,vars,env))));
                }
                }
                }
                default: {ESLVal _0 = _v47;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten(),renameJVarsCommand.apply(alt,vars,env));
        }
        }
        }
        }
      case "JCaseStr": {ESLVal $519 = _v34.termRef(0);
          ESLVal $518 = _v34.termRef(1);
          ESLVal $517 = _v34.termRef(2);
          
          {ESLVal e = $519;
          
          {ESLVal arms = $518;
          
          {ESLVal alt = $517;
          
          return new ESLVal("JCaseStr",renameJVarsExp.apply(e,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v46 = $qualArg;
                
                switch(_v46.termName) {
                case "JSArm": {ESLVal $572 = _v46.termRef(0);
                  ESLVal $571 = _v46.termRef(1);
                  
                  {ESLVal s = $572;
                  
                  {ESLVal _v53 = $571;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JSArm",s,renameJVarsCommand.apply(_v53,vars,env))));
                }
                }
                }
                default: {ESLVal _0 = _v46;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten(),renameJVarsCommand.apply(alt,vars,env));
        }
        }
        }
        }
      case "JCaseBool": {ESLVal $516 = _v34.termRef(0);
          ESLVal $515 = _v34.termRef(1);
          ESLVal $514 = _v34.termRef(2);
          
          {ESLVal e = $516;
          
          {ESLVal arms = $515;
          
          {ESLVal alt = $514;
          
          return new ESLVal("JCaseBool",renameJVarsExp.apply(e,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v45 = $qualArg;
                
                switch(_v45.termName) {
                case "JBArm": {ESLVal $570 = _v45.termRef(0);
                  ESLVal $569 = _v45.termRef(1);
                  
                  {ESLVal b = $570;
                  
                  {ESLVal _v52 = $569;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JBArm",b,renameJVarsCommand.apply(_v52,vars,env))));
                }
                }
                }
                default: {ESLVal _0 = _v45;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten(),renameJVarsCommand.apply(alt,vars,env));
        }
        }
        }
        }
      case "JCaseTerm": {ESLVal $513 = _v34.termRef(0);
          ESLVal $512 = _v34.termRef(1);
          ESLVal $511 = _v34.termRef(2);
          
          {ESLVal e = $513;
          
          {ESLVal arms = $512;
          
          {ESLVal alt = $511;
          
          return new ESLVal("JCaseTerm",renameJVarsExp.apply(e,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v44 = $qualArg;
                
                switch(_v44.termName) {
                case "JTArm": {ESLVal $568 = _v44.termRef(0);
                  ESLVal $567 = _v44.termRef(1);
                  ESLVal $566 = _v44.termRef(2);
                  
                  {ESLVal n = $568;
                  
                  {ESLVal i = $567;
                  
                  {ESLVal _v51 = $566;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JTArm",n,i,renameJVarsCommand.apply(_v51,vars,env))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v44;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten(),renameJVarsCommand.apply(alt,vars,env));
        }
        }
        }
        }
      case "JLet": {ESLVal $510 = _v34.termRef(0);
          ESLVal $509 = _v34.termRef(1);
          
          {ESLVal v0 = $510;
          
          {ESLVal v1 = $509;
          
          {ESLVal boundNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v41 = $qualArg;
                  
                  switch(_v41.termName) {
                  case "JField": {ESLVal $559 = _v41.termRef(0);
                    ESLVal $558 = _v41.termRef(1);
                    ESLVal $557 = _v41.termRef(2);
                    
                    {ESLVal n = $559;
                    
                    {ESLVal t = $558;
                    
                    {ESLVal e = $557;
                    
                    return ESLVal.list(ESLVal.list(n));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v41;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten();
          
          if(exists.apply(new ESLVal(new Function(new ESLVal("fun419"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal n = $args[0];
        return member.apply(n,vars);
          }
        }),boundNames).boolVal)
          {ESLVal newNames = new java.util.function.Function<ESLVal,ESLVal>() {
                public ESLVal apply(ESLVal $l0) {
                  ESLVal $a = $nil;
                  java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                  while(!$l0.isNil()) { 
                    ESLVal n = $l0.head();
                    $l0 = $l0.tail();
                    $v.add(newName.apply());
                  }
                  for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                  return $a;
                }}.apply(boundNames);
            
            {ESLVal env1 = addEntries.apply(boundNames,newNames,env);
            
            return new ESLVal("JLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v42 = $qualArg;
                  
                  switch(_v42.termName) {
                  case "JField": {ESLVal $562 = _v42.termRef(0);
                    ESLVal $561 = _v42.termRef(1);
                    ESLVal $560 = _v42.termRef(2);
                    
                    {ESLVal n = $562;
                    
                    {ESLVal t = $561;
                    
                    {ESLVal e = $560;
                    
                    return ESLVal.list(ESLVal.list(new ESLVal("JField",lookup.apply(n,env1),t,renameJVarsExp.apply(e,vars,env))));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v42;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten(),renameJVarsCommand.apply(v1,boundNames.add(vars),env1));
          }
          }
          else
            return new ESLVal("JLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v43 = $qualArg;
                    
                    switch(_v43.termName) {
                    case "JField": {ESLVal $565 = _v43.termRef(0);
                      ESLVal $564 = _v43.termRef(1);
                      ESLVal $563 = _v43.termRef(2);
                      
                      {ESLVal n = $565;
                      
                      {ESLVal t = $564;
                      
                      {ESLVal e = $563;
                      
                      return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(e,vars,env))));
                    }
                    }
                    }
                    }
                    default: {ESLVal _0 = _v43;
                      
                      return ESLVal.list();
                    }
                  }
                  }
                }
              }).map(v0).flatten().flatten(),renameJVarsCommand.apply(v1,boundNames.add(vars),env));
        }
        }
        }
        }
      case "JPLet": {ESLVal $508 = _v34.termRef(0);
          ESLVal $507 = _v34.termRef(1);
          
          {ESLVal v0 = $508;
          
          {ESLVal v1 = $507;
          
          {ESLVal boundNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v38 = $qualArg;
                  
                  switch(_v38.termName) {
                  case "JField": {ESLVal $550 = _v38.termRef(0);
                    ESLVal $549 = _v38.termRef(1);
                    ESLVal $548 = _v38.termRef(2);
                    
                    {ESLVal n = $550;
                    
                    {ESLVal t = $549;
                    
                    {ESLVal e = $548;
                    
                    return ESLVal.list(ESLVal.list(n));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v38;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten();
          
          if(exists.apply(new ESLVal(new Function(new ESLVal("fun420"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal n = $args[0];
        return member.apply(n,vars);
          }
        }),boundNames).boolVal)
          {ESLVal newNames = new java.util.function.Function<ESLVal,ESLVal>() {
                public ESLVal apply(ESLVal $l0) {
                  ESLVal $a = $nil;
                  java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                  while(!$l0.isNil()) { 
                    ESLVal n = $l0.head();
                    $l0 = $l0.tail();
                    $v.add(newName.apply());
                  }
                  for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                  return $a;
                }}.apply(boundNames);
            
            {ESLVal env1 = addEntries.apply(boundNames,newNames,env);
            
            return new ESLVal("JPLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v39 = $qualArg;
                  
                  switch(_v39.termName) {
                  case "JField": {ESLVal $553 = _v39.termRef(0);
                    ESLVal $552 = _v39.termRef(1);
                    ESLVal $551 = _v39.termRef(2);
                    
                    {ESLVal n = $553;
                    
                    {ESLVal t = $552;
                    
                    {ESLVal e = $551;
                    
                    return ESLVal.list(ESLVal.list(new ESLVal("JField",lookup.apply(n,env1),t,renameJVarsExp.apply(e,vars,env))));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v39;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten(),renameJVarsCommand.apply(v1,boundNames.add(vars),env1));
          }
          }
          else
            return new ESLVal("JPLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v40 = $qualArg;
                    
                    switch(_v40.termName) {
                    case "JField": {ESLVal $556 = _v40.termRef(0);
                      ESLVal $555 = _v40.termRef(1);
                      ESLVal $554 = _v40.termRef(2);
                      
                      {ESLVal n = $556;
                      
                      {ESLVal t = $555;
                      
                      {ESLVal e = $554;
                      
                      return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(e,vars,env))));
                    }
                    }
                    }
                    }
                    default: {ESLVal _0 = _v40;
                      
                      return ESLVal.list();
                    }
                  }
                  }
                }
              }).map(v0).flatten().flatten(),renameJVarsCommand.apply(v1,boundNames.add(vars),env));
        }
        }
        }
        }
      case "JLetRec": {ESLVal $506 = _v34.termRef(0);
          ESLVal $505 = _v34.termRef(1);
          
          {ESLVal v0 = $506;
          
          {ESLVal v1 = $505;
          
          {ESLVal boundNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v35 = $qualArg;
                  
                  switch(_v35.termName) {
                  case "JField": {ESLVal $541 = _v35.termRef(0);
                    ESLVal $540 = _v35.termRef(1);
                    ESLVal $539 = _v35.termRef(2);
                    
                    {ESLVal n = $541;
                    
                    {ESLVal t = $540;
                    
                    {ESLVal e = $539;
                    
                    return ESLVal.list(ESLVal.list(n));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v35;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten();
          
          if(exists.apply(new ESLVal(new Function(new ESLVal("fun421"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal n = $args[0];
        return member.apply(n,vars);
          }
        }),boundNames).boolVal)
          {ESLVal newNames = new java.util.function.Function<ESLVal,ESLVal>() {
                public ESLVal apply(ESLVal $l0) {
                  ESLVal $a = $nil;
                  java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                  while(!$l0.isNil()) { 
                    ESLVal n = $l0.head();
                    $l0 = $l0.tail();
                    $v.add(newName.apply());
                  }
                  for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                  return $a;
                }}.apply(boundNames);
            
            {ESLVal _v50 = addEntries.apply(boundNames,newNames,env);
            
            return new ESLVal("JLetRec",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v36 = $qualArg;
                  
                  switch(_v36.termName) {
                  case "JField": {ESLVal $544 = _v36.termRef(0);
                    ESLVal $543 = _v36.termRef(1);
                    ESLVal $542 = _v36.termRef(2);
                    
                    {ESLVal n = $544;
                    
                    {ESLVal t = $543;
                    
                    {ESLVal e = $542;
                    
                    return ESLVal.list(ESLVal.list(new ESLVal("JField",lookup.apply(n,_v50),t,renameJVarsExp.apply(e,vars,_v50))));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v36;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten(),renameJVarsCommand.apply(v1,boundNames.add(vars),_v50));
          }
          }
          else
            return new ESLVal("JLetRec",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v37 = $qualArg;
                    
                    switch(_v37.termName) {
                    case "JField": {ESLVal $547 = _v37.termRef(0);
                      ESLVal $546 = _v37.termRef(1);
                      ESLVal $545 = _v37.termRef(2);
                      
                      {ESLVal n = $547;
                      
                      {ESLVal t = $546;
                      
                      {ESLVal e = $545;
                      
                      return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(e,vars,env))));
                    }
                    }
                    }
                    }
                    default: {ESLVal _0 = _v37;
                      
                      return ESLVal.list();
                    }
                  }
                  }
                }
              }).map(v0).flatten().flatten(),renameJVarsCommand.apply(v1,boundNames.add(vars),env));
        }
        }
        }
        }
      case "JStatement": {ESLVal $504 = _v34.termRef(0);
          
          {ESLVal e = $504;
          
          return new ESLVal("JStatement",renameJVarsExp.apply(e,vars,env));
        }
        }
      case "JUpdate": {ESLVal $503 = _v34.termRef(0);
          ESLVal $502 = _v34.termRef(1);
          
          {ESLVal name = $503;
          
          {ESLVal value = $502;
          
          if(hasEntry.apply(name,env).boolVal)
          return new ESLVal("JUpdate",lookup.apply(name,env),renameJVarsExp.apply(value,vars,env));
          else
            {ESLVal v0 = $503;
              
              {ESLVal v1 = $502;
              
              return new ESLVal("JUpdate",v0,renameJVarsExp.apply(v1,vars,env));
            }
            }
        }
        }
        }
      case "JFor": {ESLVal $501 = _v34.termRef(0);
          ESLVal $500 = _v34.termRef(1);
          ESLVal $499 = _v34.termRef(2);
          ESLVal $498 = _v34.termRef(3);
          
          {ESLVal l = $501;
          
          {ESLVal n = $500;
          
          {ESLVal e = $499;
          
          {ESLVal _v49 = $498;
          
          return new ESLVal("JFor",l,n,renameJVarsExp.apply(e,vars,env),renameJVarsCommand.apply(_v49,vars,env));
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(27135,31543)").add(ESLVal.list(_v34)));
      }
      }
    }
  });
  public static ESLVal main = new ESLVal(new Function(new ESLVal("main"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      return new ESLVal(new BehaviourAdapter(true,getSelf(),new ESLVal("main")) {
          
          public ESLVal handle(ESLVal $m) {{ESLVal _v48 = $m;
            
            return error(new ESLVal("case error at Pos(0,0)").add(ESLVal.list(_v48)));
          }}
          public ESLVal get(String name) {
            switch(name) {
              
              default: throw new Error("ref illegal " + self + "." + name);
            }
          }
        public void handleTime(ESLVal $t) {
          {ESLVal n = $t;
            
            if($true.boolVal)
            {print.apply(new ESLVal("").add(emptyTable));
            stopAll.apply();}
            else
              {}
          }
        }
        public ESLVal init() {
            return $null;
          }
        });
    }
  });
public static void main(String[] args) {
    newActor(main,new ESLVal(new Actor())); 
  }
}