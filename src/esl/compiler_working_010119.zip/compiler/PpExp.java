package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
// import static esl.Lists.*;
import static esl.compiler.Types.*;
import static esl.compiler.DynamicVars.*;
import static esl.compiler.Strings.*;
import java.util.function.Supplier;
public class PpExp {
  public static ESLVal getSelf() { return $null; }
  private static ESLVal p0 = new ESLVal("Pos",$zero,$zero);
  private static ESLVal indentStr = new ESLVal(new Function(new ESLVal("indentStr"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  if(indent.eql($zero).boolVal)
        return new ESLVal("");
        else
          return new ESLVal(" ").add(indentStr.apply(indent.sub($one)));
    }
  });
  private static ESLVal nl = new ESLVal(new Function(new ESLVal("nl"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  return new ESLVal("\n").add(indentStr.apply(indent));
    }
  });
  private static ESLVal ppJoin = new ESLVal(new Function(new ESLVal("ppJoin"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal ss = $args[1];
  {ESLVal _v1 = ss;
        
        if(_v1.isCons())
        {ESLVal $1 = _v1.head();
          ESLVal $2 = _v1.tail();
          
          if($2.isCons())
          {ESLVal $3 = $2.head();
            ESLVal $4 = $2.tail();
            
            if($4.isCons())
            {ESLVal $5 = $4.head();
              ESLVal $6 = $4.tail();
              
              {ESLVal s = $1;
              
              {ESLVal _v123 = $2;
              
              return s.add(nl.apply(indent).add(ppJoin.apply(indent,_v123)));
            }
            }
            }
          else if($4.isNil())
            {ESLVal s1 = $1;
              
              {ESLVal s2 = $3;
              
              return s1.add(nl.apply(indent).add(s2));
            }
            }
          else {ESLVal s = $1;
              
              {ESLVal _v124 = $2;
              
              return s.add(nl.apply(indent).add(ppJoin.apply(indent,_v124)));
            }
            }
          }
        else if($2.isNil())
          {ESLVal s = $1;
            
            return s;
          }
        else {ESLVal s = $1;
            
            {ESLVal _v125 = $2;
            
            return s.add(nl.apply(indent).add(ppJoin.apply(indent,_v125)));
          }
          }
        }
      else if(_v1.isNil())
        return new ESLVal("");
      else return error(new ESLVal("case error at Pos(441,599)").add(ESLVal.list(_v1)));
      }
    }
  });
  public static ESLVal ppTypeEnv = new ESLVal(new Function(new ESLVal("ppTypeEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal env = $args[0];
  {ESLVal[] s = new ESLVal[]{new ESLVal("[")};
        
        {{
        ESLVal _v4 = env;
        while(_v4.isCons()) {
          ESLVal _v3 = _v4.headVal;
          {ESLVal _v2 = new ESLVal(new Function(new ESLVal("forp"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  {ESLVal _v5 = _v3;
                    
                    switch(_v5.termName) {
                    case "Map": {ESLVal $8 = _v5.termRef(0);
                      ESLVal $7 = _v5.termRef(1);
                      
                      {ESLVal n = $8;
                      
                      {ESLVal t = $7;
                      
                      {s[0] = s[0].add(n.add(new ESLVal("->").add(ppType.apply(t).add(new ESLVal(",")))));
                    return $null;}
                    }
                    }
                    }
                    default: {ESLVal $$$ = _v5;
                      
                      return $null;
                    }
                  }
                  }
                }
              });
            
            _v2.apply();
          }
          _v4 = _v4.tailVal;}
      }
      return s[0].add(new ESLVal("]"));}
      }
    }
  });
  public static ESLVal ppTypes = new ESLVal(new Function(new ESLVal("ppTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal ts = $args[0];
  return map.apply(ppType,ts);
    }
  });
  public static ESLVal ppType = new ESLVal(new Function(new ESLVal("ppType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v6 = t;
        
        switch(_v6.termName) {
        case "ActType": {ESLVal $67 = _v6.termRef(0);
          ESLVal $66 = _v6.termRef(1);
          ESLVal $65 = _v6.termRef(2);
          
          {ESLVal l = $67;
          
          {ESLVal decs = $66;
          
          {ESLVal handlers = $65;
          
          return new ESLVal("").add(t);
        }
        }
        }
        }
      case "ApplyType": {ESLVal $64 = _v6.termRef(0);
          ESLVal $63 = _v6.termRef(1);
          ESLVal $62 = _v6.termRef(2);
          
          {ESLVal l = $64;
          
          {ESLVal n = $63;
          
          {ESLVal args = $62;
          
          return n.add(map.apply(ppType,args));
        }
        }
        }
        }
      case "ApplyTypeFun": {ESLVal $61 = _v6.termRef(0);
          ESLVal $60 = _v6.termRef(1);
          ESLVal $59 = _v6.termRef(2);
          
          {ESLVal l = $61;
          
          {ESLVal op = $60;
          
          {ESLVal args = $59;
          
          return ppType.apply(op).add(map.apply(ppType,args));
        }
        }
        }
        }
      case "ArrayType": {ESLVal $58 = _v6.termRef(0);
          ESLVal $57 = _v6.termRef(1);
          
          {ESLVal l = $58;
          
          {ESLVal _v122 = $57;
          
          return new ESLVal("Array[").add(ppType.apply(_v122).add(new ESLVal("]")));
        }
        }
        }
      case "BoolType": {ESLVal $56 = _v6.termRef(0);
          
          {ESLVal l = $56;
          
          return new ESLVal("Bool");
        }
        }
      case "FloatType": {ESLVal $55 = _v6.termRef(0);
          
          {ESLVal l = $55;
          
          return new ESLVal("Float");
        }
        }
      case "FieldType": {ESLVal $54 = _v6.termRef(0);
          ESLVal $53 = _v6.termRef(1);
          ESLVal $52 = _v6.termRef(2);
          
          {ESLVal l = $54;
          
          {ESLVal n = $53;
          
          {ESLVal _v121 = $52;
          
          return n.add(new ESLVal("::").add(ppType.apply(_v121)));
        }
        }
        }
        }
      case "ForallType": {ESLVal $51 = _v6.termRef(0);
          ESLVal $50 = _v6.termRef(1);
          ESLVal $49 = _v6.termRef(2);
          
          {ESLVal l = $51;
          
          {ESLVal ns = $50;
          
          {ESLVal _v120 = $49;
          
          return new ESLVal("Forall").add(ns.add(new ESLVal(".").add(ppType.apply(_v120))));
        }
        }
        }
        }
      case "FunType": {ESLVal $48 = _v6.termRef(0);
          ESLVal $47 = _v6.termRef(1);
          ESLVal $46 = _v6.termRef(2);
          
          {ESLVal l = $48;
          
          {ESLVal d = $47;
          
          {ESLVal r = $46;
          
          return map.apply(ppType,d).add(new ESLVal("->").add(ppType.apply(r)));
        }
        }
        }
        }
      case "TaggedFunType": {ESLVal $45 = _v6.termRef(0);
          ESLVal $44 = _v6.termRef(1);
          ESLVal $43 = _v6.termRef(2);
          ESLVal $42 = _v6.termRef(3);
          
          {ESLVal l = $45;
          
          {ESLVal d = $44;
          
          {ESLVal p = $43;
          
          {ESLVal r = $42;
          
          return map.apply(ppType,d).add(new ESLVal("->").add(ppType.apply(r)));
        }
        }
        }
        }
        }
      case "IntType": {ESLVal $41 = _v6.termRef(0);
          
          {ESLVal l = $41;
          
          return new ESLVal("Int");
        }
        }
      case "ListType": {ESLVal $40 = _v6.termRef(0);
          ESLVal $39 = _v6.termRef(1);
          
          {ESLVal l = $40;
          
          {ESLVal _v119 = $39;
          
          return new ESLVal("[").add(ppType.apply(_v119).add(new ESLVal("]")));
        }
        }
        }
      case "NullType": {ESLVal $38 = _v6.termRef(0);
          
          {ESLVal l = $38;
          
          return new ESLVal("Null");
        }
        }
      case "ObserverType": {ESLVal $37 = _v6.termRef(0);
          ESLVal $36 = _v6.termRef(1);
          ESLVal $35 = _v6.termRef(2);
          
          {ESLVal l = $37;
          
          {ESLVal s = $36;
          
          {ESLVal m = $35;
          
          return new ESLVal("Observer[").add(ppType.apply(s).add(new ESLVal(",").add(ppType.apply(m).add(new ESLVal("]")))));
        }
        }
        }
        }
      case "RecType": {ESLVal $34 = _v6.termRef(0);
          ESLVal $33 = _v6.termRef(1);
          ESLVal $32 = _v6.termRef(2);
          
          {ESLVal l = $34;
          
          {ESLVal n = $33;
          
          {ESLVal _v118 = $32;
          
          return new ESLVal("rec ").add(n.add(new ESLVal(".").add(ppType.apply(_v118))));
        }
        }
        }
        }
      case "RecordType": {ESLVal $31 = _v6.termRef(0);
          ESLVal $30 = _v6.termRef(1);
          
          {ESLVal l = $31;
          
          {ESLVal fs = $30;
          
          return new ESLVal("{").add(fs.add(new ESLVal("}")));
        }
        }
        }
      case "StrType": {ESLVal $29 = _v6.termRef(0);
          
          {ESLVal l = $29;
          
          return new ESLVal("Str");
        }
        }
      case "TableType": {ESLVal $28 = _v6.termRef(0);
          ESLVal $27 = _v6.termRef(1);
          ESLVal $26 = _v6.termRef(2);
          
          {ESLVal l = $28;
          
          {ESLVal k = $27;
          
          {ESLVal v = $26;
          
          return new ESLVal("Hash[").add(ppType.apply(k).add(new ESLVal(",").add(ppType.apply(v).add(new ESLVal("]")))));
        }
        }
        }
        }
      case "TermType": {ESLVal $25 = _v6.termRef(0);
          ESLVal $24 = _v6.termRef(1);
          ESLVal $23 = _v6.termRef(2);
          
          {ESLVal l = $25;
          
          {ESLVal n = $24;
          
          {ESLVal ts = $23;
          
          return n.add(map.apply(ppType,ts));
        }
        }
        }
        }
      case "TypeFun": {ESLVal $22 = _v6.termRef(0);
          ESLVal $21 = _v6.termRef(1);
          ESLVal $20 = _v6.termRef(2);
          
          {ESLVal l = $22;
          
          {ESLVal ns = $21;
          
          {ESLVal _v117 = $20;
          
          return new ESLVal("Fun").add(ns.add(new ESLVal(".").add(ppType.apply(_v117))));
        }
        }
        }
        }
      case "UnfoldType": {ESLVal $19 = _v6.termRef(0);
          ESLVal $18 = _v6.termRef(1);
          
          {ESLVal l = $19;
          
          {ESLVal _v116 = $18;
          
          return new ESLVal("unfold ").add(ppType.apply(_v116));
        }
        }
        }
      case "UnionType": {ESLVal $17 = _v6.termRef(0);
          ESLVal $16 = _v6.termRef(1);
          
          {ESLVal l = $17;
          
          {ESLVal ts = $16;
          
          return new ESLVal("union ").add(map.apply(ppType,ts));
        }
        }
        }
      case "VarType": {ESLVal $15 = _v6.termRef(0);
          ESLVal $14 = _v6.termRef(1);
          
          {ESLVal l = $15;
          
          {ESLVal n = $14;
          
          return n;
        }
        }
        }
      case "VoidType": {ESLVal $13 = _v6.termRef(0);
          
          {ESLVal l = $13;
          
          return new ESLVal("Void");
        }
        }
      case "UnionRef": {ESLVal $12 = _v6.termRef(0);
          ESLVal $11 = _v6.termRef(1);
          ESLVal $10 = _v6.termRef(2);
          
          {ESLVal l = $12;
          
          {ESLVal _v115 = $11;
          
          {ESLVal n = $10;
          
          return ppType.apply(_v115).add(new ESLVal(".").add(n));
        }
        }
        }
        }
      case "TypeClosure": {ESLVal $9 = _v6.termRef(0);
          
          {ESLVal f = $9;
          
          return f.add(new ESLVal(""));
        }
        }
        default: {ESLVal x = _v6;
          
          return new ESLVal("<unknown ").add(x.add(new ESLVal(">")));
        }
      }
      }
    }
  });
  public static ESLVal ppExps = new ESLVal(new Function(new ESLVal("ppExps"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal exps = $args[1];
  ESLVal sep = $args[2];
  {ESLVal _v7 = exps;
        
        if(_v7.isCons())
        {ESLVal $68 = _v7.head();
          ESLVal $69 = _v7.tail();
          
          if($69.isCons())
          {ESLVal $70 = $69.head();
            ESLVal $71 = $69.tail();
            
            {ESLVal e1 = $68;
            
            {ESLVal e2 = $70;
            
            {ESLVal es = $71;
            
            return ppExp.apply(indent,e1).add(sep.add(ppExps.apply(indent,es.cons(e2),sep)));
          }
          }
          }
          }
        else if($69.isNil())
          {ESLVal e = $68;
            
            return ppExp.apply(indent,e);
          }
        else return error(new ESLVal("case error at Pos(2505,2663)").add(ESLVal.list(_v7)));
        }
      else if(_v7.isNil())
        return new ESLVal("");
      else return error(new ESLVal("case error at Pos(2505,2663)").add(ESLVal.list(_v7)));
      }
    }
  });
  private static ESLVal ppPattern = new ESLVal(new Function(new ESLVal("ppPattern"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v8 = p;
        
        switch(_v8.termName) {
        case "PVar": {ESLVal $93 = _v8.termRef(0);
          ESLVal $92 = _v8.termRef(1);
          ESLVal $91 = _v8.termRef(2);
          
          {ESLVal l = $93;
          
          {ESLVal n = $92;
          
          {ESLVal t = $91;
          
          return n;
        }
        }
        }
        }
      case "PTerm": {ESLVal $88 = _v8.termRef(0);
          ESLVal $87 = _v8.termRef(1);
          ESLVal $86 = _v8.termRef(2);
          ESLVal $85 = _v8.termRef(3);
          
          if($86.isCons())
          {ESLVal $89 = $86.head();
            ESLVal $90 = $86.tail();
            
            {ESLVal l = $88;
            
            {ESLVal n = $87;
            
            {ESLVal ts = $86;
            
            {ESLVal ps = $85;
            
            return n.add(ppPatterns.apply(ps));
          }
          }
          }
          }
          }
        else if($86.isNil())
          {ESLVal l = $88;
            
            {ESLVal n = $87;
            
            {ESLVal ps = $85;
            
            return n.add(ppPatterns.apply(ps));
          }
          }
          }
        else {ESLVal l = $88;
            
            {ESLVal n = $87;
            
            {ESLVal ts = $86;
            
            {ESLVal ps = $85;
            
            return n.add(ppPatterns.apply(ps));
          }
          }
          }
          }
        }
      case "PApplyType": {ESLVal $84 = _v8.termRef(0);
          ESLVal $83 = _v8.termRef(1);
          ESLVal $82 = _v8.termRef(2);
          
          {ESLVal l = $84;
          
          {ESLVal _v113 = $83;
          
          {ESLVal ts = $82;
          
          return ppPattern.apply(_v113);
        }
        }
        }
        }
      case "PNil": {ESLVal $81 = _v8.termRef(0);
          
          {ESLVal l = $81;
          
          return new ESLVal("[]");
        }
        }
      case "PInt": {ESLVal $80 = _v8.termRef(0);
          ESLVal $79 = _v8.termRef(1);
          
          {ESLVal l = $80;
          
          {ESLVal n = $79;
          
          return new ESLVal("").add(n);
        }
        }
        }
      case "PBool": {ESLVal $78 = _v8.termRef(0);
          ESLVal $77 = _v8.termRef(1);
          
          {ESLVal l = $78;
          
          {ESLVal b = $77;
          
          return new ESLVal("").add(b);
        }
        }
        }
      case "PStr": {ESLVal $76 = _v8.termRef(0);
          ESLVal $75 = _v8.termRef(1);
          
          {ESLVal l = $76;
          
          {ESLVal s = $75;
          
          return new ESLVal("\'").add(s.add(new ESLVal("\'")));
        }
        }
        }
      case "PCons": {ESLVal $74 = _v8.termRef(0);
          ESLVal $73 = _v8.termRef(1);
          ESLVal $72 = _v8.termRef(2);
          
          {ESLVal l = $74;
          
          {ESLVal h = $73;
          
          {ESLVal t = $72;
          
          return ppPattern.apply(h).add(new ESLVal(":").add(ppPattern.apply(t)));
        }
        }
        }
        }
        default: {ESLVal _v114 = _v8;
          
          return new ESLVal("<unknown: ").add(_v114.add(new ESLVal(">")));
        }
      }
      }
    }
  });
  private static ESLVal ppPatterns = new ESLVal(new Function(new ESLVal("ppPatterns"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal ps = $args[0];
  return map.apply(ppPattern,ps);
    }
  });
  public static ESLVal ppExp = new ESLVal(new Function(new ESLVal("ppExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal exp = $args[1];
  {ESLVal _v9 = exp;
        
        switch(_v9.termName) {
        case "Module": {ESLVal $244 = _v9.termRef(0);
          ESLVal $243 = _v9.termRef(1);
          ESLVal $242 = _v9.termRef(2);
          ESLVal $241 = _v9.termRef(3);
          ESLVal $240 = _v9.termRef(4);
          ESLVal $239 = _v9.termRef(5);
          ESLVal $238 = _v9.termRef(6);
          
          {ESLVal path = $244;
          
          {ESLVal name = $243;
          
          {ESLVal exports = $242;
          
          {ESLVal imports = $241;
          
          {ESLVal x = $240;
          
          {ESLVal y = $239;
          
          {ESLVal defs = $238;
          
          return new ESLVal("module ").add(name.add(new ESLVal("{").add(nl.apply(indent.add(new ESLVal(2))).add(ppBinds.apply(indent.add(new ESLVal(2)),defs).add(nl.apply(indent).add(new ESLVal("}")))))));
        }
        }
        }
        }
        }
        }
        }
        }
      case "Var": {ESLVal $237 = _v9.termRef(0);
          ESLVal $236 = _v9.termRef(1);
          
          {ESLVal l = $237;
          
          {ESLVal n = $236;
          
          return n;
        }
        }
        }
      case "StrExp": {ESLVal $235 = _v9.termRef(0);
          ESLVal $234 = _v9.termRef(1);
          
          {ESLVal l = $235;
          
          {ESLVal v = $234;
          
          return new ESLVal("\'").add(v.add(new ESLVal("\'")));
        }
        }
        }
      case "IntExp": {ESLVal $233 = _v9.termRef(0);
          ESLVal $232 = _v9.termRef(1);
          
          {ESLVal l = $233;
          
          {ESLVal v = $232;
          
          return v.add(new ESLVal(""));
        }
        }
        }
      case "BoolExp": {ESLVal $231 = _v9.termRef(0);
          ESLVal $230 = _v9.termRef(1);
          
          {ESLVal l = $231;
          
          {ESLVal v = $230;
          
          return v.add(new ESLVal(""));
        }
        }
        }
      case "NullExp": {ESLVal $229 = _v9.termRef(0);
          
          {ESLVal l = $229;
          
          return new ESLVal("null");
        }
        }
      case "FloatExp": {ESLVal $228 = _v9.termRef(0);
          ESLVal $227 = _v9.termRef(1);
          
          {ESLVal l = $228;
          
          {ESLVal f = $227;
          
          return f.add(new ESLVal(""));
        }
        }
        }
      case "Apply": {ESLVal $226 = _v9.termRef(0);
          ESLVal $225 = _v9.termRef(1);
          ESLVal $224 = _v9.termRef(2);
          
          {ESLVal l = $226;
          
          {ESLVal op = $225;
          
          {ESLVal args = $224;
          
          return ppExp.apply(indent,op).add(new ESLVal("(").add(ppExps.apply(indent,args,new ESLVal(",")).add(new ESLVal(")"))));
        }
        }
        }
        }
      case "ApplyTypeExp": {ESLVal $223 = _v9.termRef(0);
          ESLVal $222 = _v9.termRef(1);
          ESLVal $221 = _v9.termRef(2);
          
          {ESLVal l = $223;
          
          {ESLVal op = $222;
          
          {ESLVal args = $221;
          
          return ppExp.apply(indent,op);
        }
        }
        }
        }
      case "Block": {ESLVal $220 = _v9.termRef(0);
          ESLVal $219 = _v9.termRef(1);
          
          {ESLVal l = $220;
          
          {ESLVal es = $219;
          
          return new ESLVal("{").add(nl.apply(indent.add(new ESLVal(2))).add(ppExps.apply(indent.add(new ESLVal(2)),es,new ESLVal(";")).add(nl.apply(indent).add(new ESLVal("}")))));
        }
        }
        }
      case "Case": {ESLVal $218 = _v9.termRef(0);
          ESLVal $217 = _v9.termRef(1);
          ESLVal $216 = _v9.termRef(2);
          ESLVal $215 = _v9.termRef(3);
          
          {ESLVal l = $218;
          
          {ESLVal ds = $217;
          
          {ESLVal es = $216;
          
          {ESLVal as = $215;
          
          return new ESLVal("case ").add(ppExps.apply(indent,es,new ESLVal(",")).add(new ESLVal(" {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun124"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal a = $args[0];
          return ppArm.apply(indent,a);
            }
          }),as)).add(nl.apply(indent).add(new ESLVal("}")))))));
        }
        }
        }
        }
        }
      case "CaseTerm": {ESLVal $214 = _v9.termRef(0);
          ESLVal $213 = _v9.termRef(1);
          ESLVal $212 = _v9.termRef(2);
          ESLVal $211 = _v9.termRef(3);
          
          {ESLVal l = $214;
          
          {ESLVal e = $213;
          
          {ESLVal arms = $212;
          
          {ESLVal alt = $211;
          
          return new ESLVal("caseTerm ").add(ppExp.apply(indent,e).add(new ESLVal(" {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun125"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal a = $args[0];
          return ppCaseTermArm.apply(indent.add(new ESLVal(2)),a);
            }
          }),arms)).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("else ").add(ppExp.apply(indent.add(new ESLVal(4)),alt).add(nl.apply(indent).add(new ESLVal("}"))))))))));
        }
        }
        }
        }
        }
      case "CaseList": {ESLVal $210 = _v9.termRef(0);
          ESLVal $209 = _v9.termRef(1);
          ESLVal $208 = _v9.termRef(2);
          ESLVal $207 = _v9.termRef(3);
          ESLVal $206 = _v9.termRef(4);
          
          {ESLVal l = $210;
          
          {ESLVal e = $209;
          
          {ESLVal cons = $208;
          
          {ESLVal nil = $207;
          
          {ESLVal alt = $206;
          
          return new ESLVal("caseList ").add(ppExp.apply(indent,e).add(new ESLVal(" {").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("CONS ->").add(nl.apply(indent.add(new ESLVal(4))).add(ppExp.apply(indent.add(new ESLVal(4)),cons).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("NIL ->").add(nl.apply(indent.add(new ESLVal(4))).add(ppExp.apply(indent.add(new ESLVal(4)),nil).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("else ").add(ppExp.apply(indent.add(new ESLVal(4)),alt).add(nl.apply(indent).add(new ESLVal("}"))))))))))))))));
        }
        }
        }
        }
        }
        }
      case "CaseInt": {ESLVal $205 = _v9.termRef(0);
          ESLVal $204 = _v9.termRef(1);
          ESLVal $203 = _v9.termRef(2);
          ESLVal $202 = _v9.termRef(3);
          
          {ESLVal l = $205;
          
          {ESLVal e = $204;
          
          {ESLVal arms = $203;
          
          {ESLVal alt = $202;
          
          return new ESLVal("caseInt ").add(ppExp.apply(indent,e).add(new ESLVal(" {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun126"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal a = $args[0];
          return ppCaseIntsArm.apply(indent.add(new ESLVal(2)),a);
            }
          }),arms)).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("else ").add(ppExp.apply(indent.add(new ESLVal(4)),alt).add(nl.apply(indent).add(new ESLVal("}"))))))))));
        }
        }
        }
        }
        }
      case "CaseStr": {ESLVal $201 = _v9.termRef(0);
          ESLVal $200 = _v9.termRef(1);
          ESLVal $199 = _v9.termRef(2);
          ESLVal $198 = _v9.termRef(3);
          
          {ESLVal l = $201;
          
          {ESLVal e = $200;
          
          {ESLVal arms = $199;
          
          {ESLVal alt = $198;
          
          return new ESLVal("caseStr ").add(ppExp.apply(indent,e).add(new ESLVal(" {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun127"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal a = $args[0];
          return ppCaseStrsArm.apply(indent.add(new ESLVal(2)),a);
            }
          }),arms)).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("else ").add(ppExp.apply(indent.add(new ESLVal(4)),alt).add(nl.apply(indent).add(new ESLVal("}"))))))))));
        }
        }
        }
        }
        }
      case "CaseBool": {ESLVal $197 = _v9.termRef(0);
          ESLVal $196 = _v9.termRef(1);
          ESLVal $195 = _v9.termRef(2);
          ESLVal $194 = _v9.termRef(3);
          
          {ESLVal l = $197;
          
          {ESLVal e = $196;
          
          {ESLVal arms = $195;
          
          {ESLVal alt = $194;
          
          return new ESLVal("caseBool ").add(ppExp.apply(indent,e).add(new ESLVal(" {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun128"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal a = $args[0];
          return ppCaseBoolsArm.apply(indent.add(new ESLVal(2)),a);
            }
          }),arms)).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("else ").add(ppExp.apply(indent.add(new ESLVal(4)),alt).add(nl.apply(indent).add(new ESLVal("}"))))))))));
        }
        }
        }
        }
        }
      case "CaseError": {ESLVal $193 = _v9.termRef(0);
          ESLVal $192 = _v9.termRef(1);
          
          {ESLVal l = $193;
          
          {ESLVal e = $192;
          
          return new ESLVal("caseError()");
        }
        }
        }
      case "Head": {ESLVal $191 = _v9.termRef(0);
          
          {ESLVal e = $191;
          
          return new ESLVal("head(").add(ppExp.apply(indent,e).add(new ESLVal(")")));
        }
        }
      case "Tail": {ESLVal $190 = _v9.termRef(0);
          
          {ESLVal e = $190;
          
          return new ESLVal("tail(").add(ppExp.apply(indent,e).add(new ESLVal(")")));
        }
        }
      case "Cons": {ESLVal $189 = _v9.termRef(0);
          ESLVal $188 = _v9.termRef(1);
          
          {ESLVal h = $189;
          
          {ESLVal t = $188;
          
          return new ESLVal("cons(").add(ppExp.apply(indent,h).add(new ESLVal(",").add(ppExp.apply(indent,t).add(new ESLVal(")")))));
        }
        }
        }
      case "If": {ESLVal $187 = _v9.termRef(0);
          ESLVal $186 = _v9.termRef(1);
          ESLVal $185 = _v9.termRef(2);
          ESLVal $184 = _v9.termRef(3);
          
          {ESLVal l = $187;
          
          {ESLVal e1 = $186;
          
          {ESLVal e2 = $185;
          
          {ESLVal e3 = $184;
          
          return new ESLVal("if ").add(ppExp.apply(indent,e1).add(nl.apply(indent).add(new ESLVal("then").add(nl.apply(indent.add(new ESLVal(2))).add(ppExp.apply(indent.add(new ESLVal(2)),e2).add(nl.apply(indent).add(new ESLVal("else").add(nl.apply(indent.add(new ESLVal(2))).add(ppExp.apply(indent.add(new ESLVal(2)),e3))))))))));
        }
        }
        }
        }
        }
      case "FunExp": {ESLVal $183 = _v9.termRef(0);
          ESLVal $182 = _v9.termRef(1);
          ESLVal $181 = _v9.termRef(2);
          ESLVal $180 = _v9.termRef(3);
          ESLVal $179 = _v9.termRef(4);
          
          {ESLVal l = $183;
          
          {ESLVal n = $182;
          
          {ESLVal args = $181;
          
          {ESLVal t = $180;
          
          {ESLVal e = $179;
          
          return new ESLVal("fun(").add(ppDecs.apply(indent,args).add(new ESLVal(")::").add(ppType.apply(t).add(new ESLVal(" ").add(ppExp.apply(indent.add(new ESLVal(2)),e))))));
        }
        }
        }
        }
        }
        }
      case "Let": {ESLVal $178 = _v9.termRef(0);
          ESLVal $177 = _v9.termRef(1);
          ESLVal $176 = _v9.termRef(2);
          
          {ESLVal l = $178;
          
          {ESLVal bs = $177;
          
          {ESLVal e = $176;
          
          return new ESLVal("let ").add(ppBinds.apply(indent.add(new ESLVal(4)),bs).add(nl.apply(indent).add(new ESLVal("in ").add(ppExp.apply(indent.add(new ESLVal(3)),e)))));
        }
        }
        }
        }
      case "Letrec": {ESLVal $175 = _v9.termRef(0);
          ESLVal $174 = _v9.termRef(1);
          ESLVal $173 = _v9.termRef(2);
          
          {ESLVal l = $175;
          
          {ESLVal bs = $174;
          
          {ESLVal e = $173;
          
          return new ESLVal("letrec ").add(ppBinds.apply(indent.add(new ESLVal(7)),bs).add(nl.apply(indent).add(new ESLVal("in ").add(ppExp.apply(indent.add(new ESLVal(3)),e)))));
        }
        }
        }
        }
      case "List": {ESLVal $172 = _v9.termRef(0);
          ESLVal $171 = _v9.termRef(1);
          
          {ESLVal l = $172;
          
          {ESLVal es = $171;
          
          return new ESLVal("[").add(ppExps.apply(indent,es,new ESLVal(",")).add(new ESLVal("]")));
        }
        }
        }
      case "Throw": {ESLVal $170 = _v9.termRef(0);
          ESLVal $169 = _v9.termRef(1);
          ESLVal $168 = _v9.termRef(2);
          
          {ESLVal l = $170;
          
          {ESLVal t = $169;
          
          {ESLVal e = $168;
          
          return new ESLVal("throw ").add(ppExp.apply(indent,e));
        }
        }
        }
        }
      case "Term": {ESLVal $167 = _v9.termRef(0);
          ESLVal $166 = _v9.termRef(1);
          ESLVal $165 = _v9.termRef(2);
          ESLVal $164 = _v9.termRef(3);
          
          {ESLVal l = $167;
          
          {ESLVal n = $166;
          
          {ESLVal ts = $165;
          
          {ESLVal es = $164;
          
          return n.add(new ESLVal("(").add(ppExps.apply(indent,es,new ESLVal(",")).add(new ESLVal(")"))));
        }
        }
        }
        }
        }
      case "TermRef": {ESLVal $163 = _v9.termRef(0);
          ESLVal $162 = _v9.termRef(1);
          
          {ESLVal e = $163;
          
          {ESLVal n = $162;
          
          return new ESLVal("termRef(").add(ppExp.apply(indent,e).add(new ESLVal(",").add(n.add(new ESLVal(")")))));
        }
        }
        }
      case "BinExp": {ESLVal $161 = _v9.termRef(0);
          ESLVal $160 = _v9.termRef(1);
          ESLVal $159 = _v9.termRef(2);
          ESLVal $158 = _v9.termRef(3);
          
          {ESLVal l = $161;
          
          {ESLVal e1 = $160;
          
          {ESLVal op = $159;
          
          {ESLVal e2 = $158;
          
          return ppExp.apply(indent,e1).add(op.add(ppExp.apply(indent,e2)));
        }
        }
        }
        }
        }
      case "Update": {ESLVal $157 = _v9.termRef(0);
          ESLVal $156 = _v9.termRef(1);
          ESLVal $155 = _v9.termRef(2);
          
          {ESLVal l = $157;
          
          {ESLVal n = $156;
          
          {ESLVal e = $155;
          
          return n.add(new ESLVal(" := ").add(ppExp.apply(indent,e)));
        }
        }
        }
        }
      case "NewArray": {ESLVal $154 = _v9.termRef(0);
          ESLVal $153 = _v9.termRef(1);
          ESLVal $152 = _v9.termRef(2);
          
          {ESLVal l = $154;
          
          {ESLVal t = $153;
          
          {ESLVal n = $152;
          
          return new ESLVal("new Array[").add(ppType.apply(t).add(new ESLVal("](").add(ppExp.apply(indent,n).add(new ESLVal(")")))));
        }
        }
        }
        }
      case "For": {ESLVal $151 = _v9.termRef(0);
          ESLVal $150 = _v9.termRef(1);
          ESLVal $149 = _v9.termRef(2);
          ESLVal $148 = _v9.termRef(3);
          
          {ESLVal l = $151;
          
          {ESLVal p = $150;
          
          {ESLVal e1 = $149;
          
          {ESLVal e2 = $148;
          
          return new ESLVal("for ").add(ppPattern.apply(p).add(new ESLVal(" in ").add(ppExp.apply(indent,e1).add(new ESLVal(" do {").add(nl.apply(indent.add(new ESLVal(2))).add(ppExp.apply(indent.add(new ESLVal(2)),e2).add(new ESLVal("}"))))))));
        }
        }
        }
        }
        }
      case "Try": {ESLVal $147 = _v9.termRef(0);
          ESLVal $146 = _v9.termRef(1);
          ESLVal $145 = _v9.termRef(2);
          
          {ESLVal l = $147;
          
          {ESLVal e = $146;
          
          {ESLVal as = $145;
          
          return new ESLVal("try ").add(ppExp.apply(indent,e).add(new ESLVal(" {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun129"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal a = $args[0];
          return ppArm.apply(indent,a);
            }
          }),as)).add(nl.apply(indent).add(new ESLVal("}")))))));
        }
        }
        }
        }
      case "ActExp": {ESLVal $144 = _v9.termRef(0);
          ESLVal $143 = _v9.termRef(1);
          ESLVal $142 = _v9.termRef(2);
          ESLVal $141 = _v9.termRef(3);
          ESLVal $140 = _v9.termRef(4);
          ESLVal $139 = _v9.termRef(5);
          ESLVal $138 = _v9.termRef(6);
          ESLVal $137 = _v9.termRef(7);
          
          {ESLVal l = $144;
          
          {ESLVal n = $143;
          
          {ESLVal args = $142;
          
          {ESLVal x = $141;
          
          {ESLVal parent = $140;
          
          {ESLVal locals = $139;
          
          {ESLVal init = $138;
          
          {ESLVal handlers = $137;
          
          return new ESLVal("act ").add(ppExp.apply(indent,n).add(new ESLVal("(").add(ppDecs.apply(indent,args).add(new ESLVal(") {").add(nl.apply(indent.add(new ESLVal(2))).add(ppBinds.apply(indent.add(new ESLVal(5)),locals).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("-> ").add(ppExp.apply(indent.add(new ESLVal(4)),init).add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun130"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal a = $args[0];
          return ppArm.apply(indent,a);
            }
          }),handlers)).add(nl.apply(indent).add(new ESLVal("}"))))))))))))));
        }
        }
        }
        }
        }
        }
        }
        }
        }
      case "Self": {ESLVal $136 = _v9.termRef(0);
          
          {ESLVal l = $136;
          
          return new ESLVal("self");
        }
        }
      case "Ref": {ESLVal $135 = _v9.termRef(0);
          ESLVal $134 = _v9.termRef(1);
          ESLVal $133 = _v9.termRef(2);
          
          {ESLVal l = $135;
          
          {ESLVal e = $134;
          
          {ESLVal n = $133;
          
          return ppExp.apply(indent,e).add(new ESLVal(".").add(n));
        }
        }
        }
        }
      case "Send": {ESLVal $132 = _v9.termRef(0);
          ESLVal $131 = _v9.termRef(1);
          ESLVal $130 = _v9.termRef(2);
          
          {ESLVal l = $132;
          
          {ESLVal target = $131;
          
          {ESLVal message = $130;
          
          return ppExp.apply(indent,target).add(new ESLVal(" <- ").add(ppExp.apply(indent,message)));
        }
        }
        }
        }
      case "Cmp": {ESLVal $129 = _v9.termRef(0);
          ESLVal $128 = _v9.termRef(1);
          ESLVal $127 = _v9.termRef(2);
          
          {ESLVal l = $129;
          
          {ESLVal e = $128;
          
          {ESLVal qs = $127;
          
          return new ESLVal("[").add(ppExp.apply(indent,e).add(new ESLVal(" | ").add(ppJoin.apply(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun131"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal q = $args[0];
          return ppQual.apply(indent,q);
            }
          }),qs)).add(new ESLVal("]")))));
        }
        }
        }
        }
      case "New": {ESLVal $126 = _v9.termRef(0);
          ESLVal $125 = _v9.termRef(1);
          ESLVal $124 = _v9.termRef(2);
          
          {ESLVal l = $126;
          
          {ESLVal b = $125;
          
          {ESLVal args = $124;
          
          return new ESLVal("new ").add(ppExp.apply(indent,b).add(new ESLVal("(").add(ppExps.apply(indent,args,new ESLVal(",")).add(new ESLVal(")")))));
        }
        }
        }
        }
      case "NewJava": {ESLVal $123 = _v9.termRef(0);
          ESLVal $122 = _v9.termRef(1);
          ESLVal $121 = _v9.termRef(2);
          ESLVal $120 = _v9.termRef(3);
          
          {ESLVal l = $123;
          
          {ESLVal className = $122;
          
          {ESLVal t = $121;
          
          {ESLVal args = $120;
          
          return new ESLVal("javaNew[").add(ppType.apply(t).add(new ESLVal("](\' + className + ").add(ppExps.apply(indent,args,new ESLVal(",")).add(new ESLVal(")")))));
        }
        }
        }
        }
        }
      case "Grab": {ESLVal $119 = _v9.termRef(0);
          ESLVal $118 = _v9.termRef(1);
          ESLVal $117 = _v9.termRef(2);
          
          {ESLVal l = $119;
          
          {ESLVal rs = $118;
          
          {ESLVal e = $117;
          
          return new ESLVal("*********grab");
        }
        }
        }
        }
      case "Probably": {ESLVal $116 = _v9.termRef(0);
          ESLVal $115 = _v9.termRef(1);
          ESLVal $114 = _v9.termRef(2);
          ESLVal $113 = _v9.termRef(3);
          ESLVal $112 = _v9.termRef(4);
          
          {ESLVal l = $116;
          
          {ESLVal p = $115;
          
          {ESLVal t = $114;
          
          {ESLVal e1 = $113;
          
          {ESLVal e2 = $112;
          
          return new ESLVal("**** probably");
        }
        }
        }
        }
        }
        }
      case "Not": {ESLVal $111 = _v9.termRef(0);
          ESLVal $110 = _v9.termRef(1);
          
          {ESLVal l = $111;
          
          {ESLVal e = $110;
          
          return new ESLVal("not(").add(ppExp.apply(indent,e).add(new ESLVal(")")));
        }
        }
        }
      case "Fold": {ESLVal $109 = _v9.termRef(0);
          ESLVal $108 = _v9.termRef(1);
          ESLVal $107 = _v9.termRef(2);
          
          {ESLVal l = $109;
          
          {ESLVal t = $108;
          
          {ESLVal e = $107;
          
          return new ESLVal("******** fold");
        }
        }
        }
        }
      case "Unfold": {ESLVal $106 = _v9.termRef(0);
          ESLVal $105 = _v9.termRef(1);
          ESLVal $104 = _v9.termRef(2);
          
          {ESLVal l = $106;
          
          {ESLVal t = $105;
          
          {ESLVal e = $104;
          
          return new ESLVal("******unfold");
        }
        }
        }
        }
      case "Now": {ESLVal $103 = _v9.termRef(0);
          
          {ESLVal l = $103;
          
          return new ESLVal("now");
        }
        }
      case "Become": {ESLVal $102 = _v9.termRef(0);
          ESLVal $101 = _v9.termRef(1);
          
          {ESLVal l = $102;
          
          {ESLVal e = $101;
          
          return new ESLVal("become ").add(ppExp.apply(indent,e));
        }
        }
        }
      case "ArrayRef": {ESLVal $100 = _v9.termRef(0);
          ESLVal $99 = _v9.termRef(1);
          ESLVal $98 = _v9.termRef(2);
          
          {ESLVal l = $100;
          
          {ESLVal a = $99;
          
          {ESLVal i = $98;
          
          return ppExp.apply(indent,a).add(new ESLVal("[").add(ppExp.apply(indent,i).add(new ESLVal("]"))));
        }
        }
        }
        }
      case "ArrayUpdate": {ESLVal $97 = _v9.termRef(0);
          ESLVal $96 = _v9.termRef(1);
          ESLVal $95 = _v9.termRef(2);
          ESLVal $94 = _v9.termRef(3);
          
          {ESLVal l = $97;
          
          {ESLVal a = $96;
          
          {ESLVal i = $95;
          
          {ESLVal v = $94;
          
          return ppExp.apply(indent,a).add(new ESLVal("[").add(ppExp.apply(indent,i).add(new ESLVal("] := ").add(ppExp.apply(indent,v)))));
        }
        }
        }
        }
        }
        default: {ESLVal x = _v9;
          
          return error(new ESLVal("ppExp: ").add(x));
        }
      }
      }
    }
  });
  private static ESLVal ppQual = new ESLVal(new Function(new ESLVal("ppQual"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal q = $args[1];
  return new ESLVal("qualifier: ").add(q);
    }
  });
  private static ESLVal ppDecs = new ESLVal(new Function(new ESLVal("ppDecs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal bs = $args[1];
  return ppJoin.apply(indent,map.apply(new ESLVal(new Function(new ESLVal("fun132"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal b = $args[0];
        return ppDec.apply(indent,b);
          }
        }),bs));
    }
  });
  private static ESLVal ppDec = new ESLVal(new Function(new ESLVal("ppDec"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal d = $args[1];
  {ESLVal _v10 = d;
        
        switch(_v10.termName) {
        case "Dec": {ESLVal $248 = _v10.termRef(0);
          ESLVal $247 = _v10.termRef(1);
          ESLVal $246 = _v10.termRef(2);
          ESLVal $245 = _v10.termRef(3);
          
          {ESLVal l = $248;
          
          {ESLVal n = $247;
          
          {ESLVal dt = $246;
          
          {ESLVal t = $245;
          
          return n.add(new ESLVal("::").add(ppType.apply(t)));
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(9658,9735)").add(ESLVal.list(_v10)));
      }
      }
    }
  });
  private static ESLVal ppBinds = new ESLVal(new Function(new ESLVal("ppBinds"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal bs = $args[1];
  return ppJoin.apply(indent,map.apply(new ESLVal(new Function(new ESLVal("fun133"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal b = $args[0];
        return ppBind.apply(indent,b);
          }
        }),bs));
    }
  });
  private static ESLVal ppBind = new ESLVal(new Function(new ESLVal("ppBind"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal b = $args[1];
  {ESLVal _v11 = b;
        
        switch(_v11.termName) {
        case "Binding": {ESLVal $272 = _v11.termRef(0);
          ESLVal $271 = _v11.termRef(1);
          ESLVal $270 = _v11.termRef(2);
          ESLVal $269 = _v11.termRef(3);
          ESLVal $268 = _v11.termRef(4);
          
          {ESLVal l = $272;
          
          {ESLVal name = $271;
          
          {ESLVal t = $270;
          
          {ESLVal st = $269;
          
          {ESLVal value = $268;
          
          return name.add(new ESLVal("=").add(ppExp.apply(indent,value).add(new ESLVal(";"))));
        }
        }
        }
        }
        }
        }
      case "TypeBind": {ESLVal $267 = _v11.termRef(0);
          ESLVal $266 = _v11.termRef(1);
          ESLVal $265 = _v11.termRef(2);
          ESLVal $264 = _v11.termRef(3);
          
          {ESLVal l = $267;
          
          {ESLVal name = $266;
          
          {ESLVal t = $265;
          
          {ESLVal ignore = $264;
          
          return new ESLVal("type ").add(name);
        }
        }
        }
        }
        }
      case "DataBind": {ESLVal $263 = _v11.termRef(0);
          ESLVal $262 = _v11.termRef(1);
          ESLVal $261 = _v11.termRef(2);
          ESLVal $260 = _v11.termRef(3);
          
          {ESLVal l = $263;
          
          {ESLVal name = $262;
          
          {ESLVal t = $261;
          
          {ESLVal ignore = $260;
          
          return new ESLVal("data ").add(name);
        }
        }
        }
        }
        }
      case "FunBind": {ESLVal $259 = _v11.termRef(0);
          ESLVal $258 = _v11.termRef(1);
          ESLVal $257 = _v11.termRef(2);
          ESLVal $256 = _v11.termRef(3);
          ESLVal $255 = _v11.termRef(4);
          ESLVal $254 = _v11.termRef(5);
          ESLVal $253 = _v11.termRef(6);
          
          {ESLVal l = $259;
          
          {ESLVal name = $258;
          
          {ESLVal args = $257;
          
          {ESLVal t = $256;
          
          {ESLVal st = $255;
          
          {ESLVal body = $254;
          
          {ESLVal guard = $253;
          
          return name.add(new ESLVal("(").add(ppPatterns.apply(args).add(new ESLVal(") = ").add(nl.apply(indent.add(new ESLVal(2))).add(ppExp.apply(indent.add(new ESLVal(2)),body))))));
        }
        }
        }
        }
        }
        }
        }
        }
      case "CnstrBind": {ESLVal $252 = _v11.termRef(0);
          ESLVal $251 = _v11.termRef(1);
          ESLVal $250 = _v11.termRef(2);
          ESLVal $249 = _v11.termRef(3);
          
          {ESLVal l = $252;
          
          {ESLVal name = $251;
          
          {ESLVal t = $250;
          
          {ESLVal ignore = $249;
          
          return name;
        }
        }
        }
        }
        }
        default: {ESLVal x = _v11;
          
          return error(new ESLVal("ppBind: ").add(x));
        }
      }
      }
    }
  });
  public static ESLVal ppArm = new ESLVal(new Function(new ESLVal("ppArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal a = $args[1];
  {ESLVal _v12 = a;
        
        switch(_v12.termName) {
        case "BArm": {ESLVal $276 = _v12.termRef(0);
          ESLVal $275 = _v12.termRef(1);
          ESLVal $274 = _v12.termRef(2);
          ESLVal $273 = _v12.termRef(3);
          
          {ESLVal l = $276;
          
          {ESLVal ps = $275;
          
          {ESLVal guard = $274;
          
          {ESLVal e = $273;
          
          return ppPatterns.apply(ps).add(new ESLVal(" -> ").add(nl.apply(indent.add(new ESLVal(2))).add(ppExp.apply(indent.add(new ESLVal(2)),e))));
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(10520,10658)").add(ESLVal.list(_v12)));
      }
      }
    }
  });
  public static ESLVal ppArms = new ESLVal(new Function(new ESLVal("ppArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal arms = $args[1];
  return ppJoin.apply(indent,map.apply(new ESLVal(new Function(new ESLVal("fun134"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return ppArm.apply(indent,a);
          }
        }),arms));
    }
  });
  private static ESLVal ppCaseTermArm = new ESLVal(new Function(new ESLVal("ppCaseTermArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal a = $args[1];
  {ESLVal _v13 = a;
        
        switch(_v13.termName) {
        case "TArm": {ESLVal $278 = _v13.termRef(0);
          ESLVal $277 = _v13.termRef(1);
          
          {ESLVal n = $278;
          
          {ESLVal e = $277;
          
          return n.add(new ESLVal(" -> ").add(nl.apply(indent.add(new ESLVal(2))).add(ppExp.apply(indent.add(new ESLVal(2)),e))));
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(10820,10920)").add(ESLVal.list(_v13)));
      }
      }
    }
  });
  private static ESLVal ppCaseIntsArm = new ESLVal(new Function(new ESLVal("ppCaseIntsArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal a = $args[1];
  {ESLVal _v14 = a;
        
        switch(_v14.termName) {
        case "IArm": {ESLVal $280 = _v14.termRef(0);
          ESLVal $279 = _v14.termRef(1);
          
          {ESLVal n = $280;
          
          {ESLVal e = $279;
          
          return n.add(new ESLVal(" -> ").add(nl.apply(indent.add(new ESLVal(2))).add(ppExp.apply(indent.add(new ESLVal(2)),e))));
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(10976,11076)").add(ESLVal.list(_v14)));
      }
      }
    }
  });
  private static ESLVal ppCaseStrsArm = new ESLVal(new Function(new ESLVal("ppCaseStrsArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal a = $args[1];
  {ESLVal _v15 = a;
        
        switch(_v15.termName) {
        case "SArm": {ESLVal $282 = _v15.termRef(0);
          ESLVal $281 = _v15.termRef(1);
          
          {ESLVal n = $282;
          
          {ESLVal e = $281;
          
          return new ESLVal("\'").add(n.add(new ESLVal("\'").add(new ESLVal(" -> ").add(nl.apply(indent.add(new ESLVal(2))).add(ppExp.apply(indent.add(new ESLVal(2)),e))))));
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(11132,11246)").add(ESLVal.list(_v15)));
      }
      }
    }
  });
  private static ESLVal ppCaseBoolsArm = new ESLVal(new Function(new ESLVal("ppCaseBoolsArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal a = $args[1];
  {ESLVal _v16 = a;
        
        switch(_v16.termName) {
        case "BoolArm": {ESLVal $284 = _v16.termRef(0);
          ESLVal $283 = _v16.termRef(1);
          
          {ESLVal b = $284;
          
          {ESLVal e = $283;
          
          return b.add(new ESLVal(" -> ").add(nl.apply(indent.add(new ESLVal(2))).add(ppExp.apply(indent.add(new ESLVal(2)),e))));
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(11304,11408)").add(ESLVal.list(_v16)));
      }
      }
    }
  });
  private static ESLVal getImport = new ESLVal(new Function(new ESLVal("getImport"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal sourceFile = $args[0];
  {ESLVal path = toPath.apply(sourceFile);
        
        {ESLVal p = pathToJavaPackage.apply(path);
        ESLVal className = pathToJavaClassName.apply(path);
        
        {ESLVal _v17 = sourceFile;
        
        switch(_v17.strVal) {
        case "esl/lists.esl": return new ESLVal("// import static ").add(p.add(new ESLVal(".").add(className.add(new ESLVal(".*;")))));
        default: {ESLVal x = _v17;
          
          return new ESLVal("import static ").add(p.add(new ESLVal(".").add(className.add(new ESLVal(".*;")))));
        }
      }
      }
      }
      }
    }
  });
  public static ESLVal ppJModule = new ESLVal(new Function(new ESLVal("ppJModule"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal name = $args[0];
  ESLVal p = $args[1];
  ESLVal m = $args[2];
  {ESLVal _v18 = m;
        
        switch(_v18.termName) {
        case "JModule": {ESLVal $288 = _v18.termRef(0);
          ESLVal $287 = _v18.termRef(1);
          ESLVal $286 = _v18.termRef(2);
          ESLVal $285 = _v18.termRef(3);
          
          {ESLVal n = $288;
          
          {ESLVal exports = $287;
          
          {ESLVal imports = $286;
          
          {ESLVal fields = $285;
          
          return new ESLVal("package ").add(p.add(new ESLVal(";").add(nl.apply($zero).add(new ESLVal("import esl.lib.*;").add(nl.apply($zero).add(new ESLVal("import static esl.lib.Lib.*;").add(nl.apply($zero).add(ppJoin.apply($zero,new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal i = $l0.head();
                $l0 = $l0.tail();
                $v.add(getImport.apply(i));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(imports)).add(nl.apply($zero).add(new ESLVal("import java.util.function.Supplier;").add(nl.apply($zero).add(new ESLVal("public class ").add(name.add(new ESLVal(" {").add(nl.apply(new ESLVal(2)).add(new ESLVal("public static ESLVal getSelf() { return $null; }").add(nl.apply(new ESLVal(2)).add(ppJoin.apply(new ESLVal(2),map.apply(new ESLVal(new Function(new ESLVal("fun135"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal f = $args[0];
          return ppJModuleField.apply(new ESLVal(2),exports,f);
            }
          }),fields)).add(nl.apply($zero).add(new ESLVal("public static void main(String[] args) {").add(nl.apply(new ESLVal(2)).add(((Supplier<ESLVal>)() -> { 
            if(member.apply(new ESLVal("main"),exports).boolVal)
              return new ESLVal("  newActor(main,new ESLVal(new Actor())); ").add(nl.apply(new ESLVal(2)));
              else
                return new ESLVal("");
          }).get().add(new ESLVal("}").add(nl.apply($zero).add(new ESLVal("}"))))))))))))))))))))))))));
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(11803,12565)").add(ESLVal.list(_v18)));
      }
      }
    }
  });
  private static ESLVal ppJModuleField = new ESLVal(new Function(new ESLVal("ppJModuleField"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal exports = $args[1];
  ESLVal f = $args[2];
  {ESLVal _v19 = f;
        
        switch(_v19.termName) {
        case "JField": {ESLVal $291 = _v19.termRef(0);
          ESLVal $290 = _v19.termRef(1);
          ESLVal $289 = _v19.termRef(2);
          
          switch($291.strVal) {
          case "edb": switch($289.termName) {
            case "JNull": {
              {ESLVal t = $290;
              
              return new ESLVal("// static ESLVal edb = null;");
            }
            }
            default: {ESLVal n = $291;
              
              {ESLVal t = $290;
              
              {ESLVal e = $289;
              
              return ((Supplier<ESLVal>)() -> { 
                if(member.apply(n,exports).boolVal)
                  return new ESLVal("public ");
                  else
                    return new ESLVal("private ");
              }).get().add(new ESLVal("static ESLVal ").add(n.add(new ESLVal(" = ").add(ppJExp.apply(indent,ESLVal.list(),e).add(new ESLVal(";"))))));
            }
            }
            }
          }
          default: {ESLVal n = $291;
            
            {ESLVal t = $290;
            
            {ESLVal e = $289;
            
            return ((Supplier<ESLVal>)() -> { 
              if(member.apply(n,exports).boolVal)
                return new ESLVal("public ");
                else
                  return new ESLVal("private ");
            }).get().add(new ESLVal("static ESLVal ").add(n.add(new ESLVal(" = ").add(ppJExp.apply(indent,ESLVal.list(),e).add(new ESLVal(";"))))));
          }
          }
          }
        }
        }
        default: return error(new ESLVal("case error at Pos(12634,12884)").add(ESLVal.list(_v19)));
      }
      }
    }
  });
  private static ESLVal ppJExps = new ESLVal(new Function(new ESLVal("ppJExps"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal exps = $args[2];
  ESLVal sep = $args[3];
  {ESLVal _v20 = exps;
        
        if(_v20.isCons())
        {ESLVal $292 = _v20.head();
          ESLVal $293 = _v20.tail();
          
          if($293.isCons())
          {ESLVal $294 = $293.head();
            ESLVal $295 = $293.tail();
            
            {ESLVal e1 = $292;
            
            {ESLVal e2 = $294;
            
            {ESLVal es = $295;
            
            return ppJExp.apply(indent,dynamics,e1).add(sep.add(ppJExps.apply(indent,dynamics,es.cons(e2),sep)));
          }
          }
          }
          }
        else if($293.isNil())
          {ESLVal e = $292;
            
            return ppJExp.apply(indent,dynamics,e);
          }
        else return error(new ESLVal("case error at Pos(12954,13148)").add(ESLVal.list(_v20)));
        }
      else if(_v20.isNil())
        return new ESLVal("");
      else return error(new ESLVal("case error at Pos(12954,13148)").add(ESLVal.list(_v20)));
      }
    }
  });
  private static ESLVal ppJDecs = new ESLVal(new Function(new ESLVal("ppJDecs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal decs = $args[1];
  ESLVal sep = $args[2];
  {ESLVal _v21 = decs;
        
        if(_v21.isCons())
        {ESLVal $296 = _v21.head();
          ESLVal $297 = _v21.tail();
          
          if($297.isCons())
          {ESLVal $298 = $297.head();
            ESLVal $299 = $297.tail();
            
            {ESLVal e1 = $296;
            
            {ESLVal e2 = $298;
            
            {ESLVal es = $299;
            
            return pJDec.apply(indent,e1).add(sep.add(ppJDecs.apply(indent,es.cons(e2),sep)));
          }
          }
          }
          }
        else if($297.isNil())
          {ESLVal e = $296;
            
            return pJDec.apply(indent,e);
          }
        else return error(new ESLVal("case error at Pos(13210,13422)").add(ESLVal.list(_v21)));
        }
      else if(_v21.isNil())
        return new ESLVal("");
      else return error(new ESLVal("case error at Pos(13210,13422)").add(ESLVal.list(_v21)));
      }
    }
  });
  private static ESLVal pJDec = new ESLVal(new Function(new ESLVal("pJDec"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal d = $args[1];
  {ESLVal _v22 = d;
        
        switch(_v22.termName) {
        case "JDec": {ESLVal $301 = _v22.termRef(0);
          ESLVal $300 = _v22.termRef(1);
          
          {ESLVal n = $301;
          
          {ESLVal t = $300;
          
          return new ESLVal("ESLVal ").add(n);
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(13468,13524)").add(ESLVal.list(_v22)));
      }
      }
    }
  });
  private static ESLVal ppJExp = new ESLVal(new Function(new ESLVal("ppJExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal e = $args[2];
  {ESLVal _v23 = e;
        
        switch(_v23.termName) {
        case "JArrayRef": {ESLVal $398 = _v23.termRef(0);
          ESLVal $397 = _v23.termRef(1);
          
          {ESLVal a = $398;
          
          {ESLVal i = $397;
          
          return ppJExp.apply(indent,dynamics,a).add(new ESLVal(".array[").add(ppJExp.apply(indent,dynamics,i).add(new ESLVal(".intVal]"))));
        }
        }
        }
      case "JArrayUpdate": {ESLVal $396 = _v23.termRef(0);
          ESLVal $395 = _v23.termRef(1);
          ESLVal $394 = _v23.termRef(2);
          
          {ESLVal a = $396;
          
          {ESLVal i = $395;
          
          {ESLVal v = $394;
          
          return ppJExp.apply(indent,dynamics,a).add(new ESLVal(".array[").add(ppJExp.apply(indent,dynamics,i).add(new ESLVal(".intVal] = ").add(ppJExp.apply(indent,dynamics,v)))));
        }
        }
        }
        }
      case "JBecome": {ESLVal $391 = _v23.termRef(0);
          ESLVal $390 = _v23.termRef(1);
          
          if($390.isCons())
          {ESLVal $392 = $390.head();
            ESLVal $393 = $390.tail();
            
            {ESLVal _v109 = $391;
            
            {ESLVal es = $390;
            
            return new ESLVal("become(").add(ppJExp.apply(indent.add(new ESLVal(2)),dynamics,_v109).add(new ESLVal(",getSelf(),").add(ppJExps.apply(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")")))));
          }
          }
          }
        else if($390.isNil())
          {ESLVal _v110 = $391;
            
            return new ESLVal("become(").add(ppJExp.apply(indent.add(new ESLVal(2)),dynamics,_v110).add(new ESLVal(",getSelf())")));
          }
        else {ESLVal _v111 = $391;
            
            {ESLVal es = $390;
            
            return new ESLVal("become(").add(ppJExp.apply(indent.add(new ESLVal(2)),dynamics,_v111).add(new ESLVal(",getSelf(),").add(ppJExps.apply(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")")))));
          }
          }
        }
      case "JConstExp": {ESLVal $385 = _v23.termRef(0);
          
          switch($385.termName) {
          case "JConstInt": {ESLVal $389 = $385.termRef(0);
            
            switch($389.intVal) {
            case 0: return new ESLVal("$zero");
          case 1: return new ESLVal("$one");
            default: {ESLVal n = $389;
              
              return new ESLVal("new ESLVal(").add(n.add(new ESLVal(")")));
            }
          }
          }
        case "JConstBool": {ESLVal $388 = $385.termRef(0);
            
            switch($388.boolVal ? 1 : 0) {
            case 1: return new ESLVal("$true");
          case 0: return new ESLVal("$false");
            default: {ESLVal _v107 = _v23;
              
              return new ESLVal("********** unknown expression: ").add(_v107);
            }
          }
          }
        case "JConstStr": {ESLVal $387 = $385.termRef(0);
            
            {ESLVal s = $387;
            
            return new ESLVal("new ESLVal(\"").add(javaString.apply(s).add(new ESLVal("\")")));
          }
          }
        case "JConstDouble": {ESLVal $386 = $385.termRef(0);
            
            {ESLVal d = $386;
            
            return new ESLVal("new ESLVal(").add(d.add(new ESLVal(")")));
          }
          }
          default: {ESLVal _v108 = _v23;
            
            return new ESLVal("********** unknown expression: ").add(_v108);
          }
        }
        }
      case "JNot": {ESLVal $384 = _v23.termRef(0);
          
          {ESLVal _v106 = $384;
          
          return ppJExp.apply(indent,dynamics,_v106).add(new ESLVal(".not()"));
        }
        }
      case "JNil": {ESLVal $383 = _v23.termRef(0);
          
          {ESLVal t = $383;
          
          return new ESLVal("$nil");
        }
        }
      case "JList": {ESLVal $382 = _v23.termRef(0);
          ESLVal $381 = _v23.termRef(1);
          
          {ESLVal t = $382;
          
          {ESLVal es = $381;
          
          return ppJListExp.apply(indent,dynamics,t,es);
        }
        }
        }
      case "JSet": {ESLVal $380 = _v23.termRef(0);
          ESLVal $379 = _v23.termRef(1);
          
          {ESLVal t = $380;
          
          {ESLVal es = $379;
          
          return ppJSetExp.apply(indent,dynamics,t,es);
        }
        }
        }
      case "JBag": {ESLVal $378 = _v23.termRef(0);
          ESLVal $377 = _v23.termRef(1);
          
          {ESLVal t = $378;
          
          {ESLVal es = $377;
          
          return ppJBagExp.apply(indent,dynamics,t,es);
        }
        }
        }
      case "JTerm": {ESLVal $374 = _v23.termRef(0);
          ESLVal $373 = _v23.termRef(1);
          
          if($373.isCons())
          {ESLVal $375 = $373.head();
            ESLVal $376 = $373.tail();
            
            {ESLVal n = $374;
            
            {ESLVal es = $373;
            
            return new ESLVal("new ESLVal(\"").add(n.add(new ESLVal("\",").add(ppJExps.apply(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")")))));
          }
          }
          }
        else if($373.isNil())
          {ESLVal n = $374;
            
            return new ESLVal("new ESLVal(\"").add(n.add(new ESLVal("\",new ESLVal[]{})")));
          }
        else {ESLVal n = $374;
            
            {ESLVal es = $373;
            
            return new ESLVal("new ESLVal(\"").add(n.add(new ESLVal("\",").add(ppJExps.apply(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")")))));
          }
          }
        }
      case "JFun": {ESLVal $372 = _v23.termRef(0);
          ESLVal $371 = _v23.termRef(1);
          ESLVal $370 = _v23.termRef(2);
          ESLVal $369 = _v23.termRef(3);
          
          {ESLVal n = $372;
          
          {ESLVal args = $371;
          
          {ESLVal t = $370;
          
          {ESLVal body = $369;
          
          return ppJFun.apply(indent,dynamics,n,args,t,body);
        }
        }
        }
        }
        }
      case "JBinExp": {ESLVal $368 = _v23.termRef(0);
          ESLVal $367 = _v23.termRef(1);
          ESLVal $366 = _v23.termRef(2);
          
          switch($367.strVal) {
          case "at": {ESLVal e1 = $368;
            
            {ESLVal e2 = $366;
            
            return new ESLVal("at(() -> { return ").add(ppJExp.apply(indent,dynamics,e1).add(new ESLVal("; },() -> { return ").add(ppJExp.apply(indent,dynamics,e2).add(new ESLVal("; })")))));
          }
          }
        case "==": {ESLVal e1 = $368;
            
            {ESLVal e2 = $366;
            
            return ppJExp.apply(indent,dynamics,e1).add(new ESLVal(".equals(").add(ppJExp.apply(indent,dynamics,e2).add(new ESLVal(")"))));
          }
          }
        case "cons": {ESLVal e1 = $368;
            
            {ESLVal e2 = $366;
            
            return ppJExp.apply(indent,dynamics,e2).add(new ESLVal(".cons(").add(ppJExp.apply(indent,dynamics,e1).add(new ESLVal(")"))));
          }
          }
          default: {ESLVal e1 = $368;
            
            {ESLVal op = $367;
            
            {ESLVal e2 = $366;
            
            return ppJExp.apply(indent,dynamics,e1).add(new ESLVal(".").add(op.add(new ESLVal("(").add(ppJExp.apply(indent,dynamics,e2).add(new ESLVal(")"))))));
          }
          }
          }
        }
        }
      case "JCmpExp": {ESLVal $365 = _v23.termRef(0);
          
          {ESLVal c = $365;
          
          return ppJCmp.apply(indent,dynamics,c);
        }
        }
      case "JNull": {
          return new ESLVal("$null");
        }
      case "JNow": {
          return new ESLVal("now()");
        }
      case "JVar": {ESLVal $364 = _v23.termRef(0);
          ESLVal $363 = _v23.termRef(1);
          
          {ESLVal n = $364;
          
          {ESLVal t = $363;
          
          if(member.apply(n,dynamics).boolVal)
          return n.add(new ESLVal("[0]"));
          else
            {ESLVal _v104 = $364;
              
              {ESLVal _v105 = $363;
              
              return _v104;
            }
            }
        }
        }
        }
      case "JError": {ESLVal $362 = _v23.termRef(0);
          
          {ESLVal _v103 = $362;
          
          return new ESLVal("error(").add(ppJExp.apply(indent,dynamics,_v103).add(new ESLVal(")")));
        }
        }
      case "JApply": {ESLVal $361 = _v23.termRef(0);
          ESLVal $360 = _v23.termRef(1);
          
          {ESLVal _v102 = $361;
          
          {ESLVal es = $360;
          
          return ppJExp.apply(indent,dynamics,_v102).add(new ESLVal(".apply(").add(ppJExps.apply(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")"))));
        }
        }
        }
      case "JCommandExp": {ESLVal $359 = _v23.termRef(0);
          ESLVal $358 = _v23.termRef(1);
          
          {ESLVal c = $359;
          
          {ESLVal t = $358;
          
          return new ESLVal("((Supplier<ESLVal>)() -> { ").add(nl.apply(indent.add(new ESLVal(2))).add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,c).add(nl.apply(indent).add(new ESLVal("}).get()")))));
        }
        }
        }
      case "JIfExp": {ESLVal $357 = _v23.termRef(0);
          ESLVal $356 = _v23.termRef(1);
          ESLVal $355 = _v23.termRef(2);
          
          {ESLVal _v101 = $357;
          
          {ESLVal e1 = $356;
          
          {ESLVal e2 = $355;
          
          return new ESLVal("(").add(ppJExp.apply(indent,dynamics,_v101).add(new ESLVal(".boolVal) ? (").add(ppJExp.apply(indent,dynamics,e1).add(new ESLVal(") : (").add(ppJExp.apply(indent,dynamics,e2).add(new ESLVal(")")))))));
        }
        }
        }
        }
      case "JHead": {ESLVal $354 = _v23.termRef(0);
          
          {ESLVal _v100 = $354;
          
          return ppJExp.apply(indent,dynamics,_v100).add(new ESLVal(".head()"));
        }
        }
      case "JTail": {ESLVal $353 = _v23.termRef(0);
          
          {ESLVal _v99 = $353;
          
          return ppJExp.apply(indent,dynamics,_v99).add(new ESLVal(".tail()"));
        }
        }
      case "JTermRef": {ESLVal $352 = _v23.termRef(0);
          ESLVal $351 = _v23.termRef(1);
          
          {ESLVal _v98 = $352;
          
          {ESLVal n = $351;
          
          return ppJExp.apply(indent,dynamics,_v98).add(new ESLVal(".termRef(").add(n.add(new ESLVal(")"))));
        }
        }
        }
      case "JMapFun": {ESLVal $350 = _v23.termRef(0);
          ESLVal $349 = _v23.termRef(1);
          
          {ESLVal f = $350;
          
          {ESLVal l = $349;
          
          return ppJExp.apply(indent,dynamics,f).add(new ESLVal(".map(").add(ppJExp.apply(indent,dynamics,l).add(new ESLVal(")"))));
        }
        }
        }
      case "JFlatten": {ESLVal $348 = _v23.termRef(0);
          
          {ESLVal ls = $348;
          
          return ppJExp.apply(indent,dynamics,ls).add(new ESLVal(".flatten()"));
        }
        }
      case "JBehaviour": {ESLVal $343 = _v23.termRef(0);
          ESLVal $342 = _v23.termRef(1);
          ESLVal $341 = _v23.termRef(2);
          ESLVal $340 = _v23.termRef(3);
          ESLVal $339 = _v23.termRef(4);
          
          switch($340.termName) {
          case "JFun": {ESLVal $347 = $340.termRef(0);
            ESLVal $346 = $340.termRef(1);
            ESLVal $345 = $340.termRef(2);
            ESLVal $344 = $340.termRef(3);
            
            {ESLVal es = $343;
            
            {ESLVal fs = $342;
            
            {ESLVal init = $341;
            
            {ESLVal n = $347;
            
            {ESLVal args = $346;
            
            {ESLVal t = $345;
            
            {ESLVal body = $344;
            
            {ESLVal time = $339;
            
            return new ESLVal("new ESLVal(new BehaviourAdapter(").add(((Supplier<ESLVal>)() -> { 
              if(time.eql(new ESLVal("JBlock",ESLVal.list())).boolVal)
                return new ESLVal("false");
                else
                  return new ESLVal("true");
            }).get().add(new ESLVal(",getSelf(),").add(ppJExp.apply(indent,dynamics,n).add(new ESLVal(") {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJFields.apply(indent.add(new ESLVal(2)),dynamics,fs).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal handle(ESLVal $m) {").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,body).add(new ESLVal("}").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal get(String name) {").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("switch(name) {").add(nl.apply(indent.add(new ESLVal(6))).add(ppJoin.apply(indent.add(new ESLVal(6)),new java.util.function.Function<ESLVal,ESLVal>() {
              public ESLVal apply(ESLVal $l0) {
                ESLVal $a = $nil;
                java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                while(!$l0.isNil()) { 
                  ESLVal n = $l0.head();
                  $l0 = $l0.tail();
                  $v.add(new ESLVal("case \"").add(n.add(new ESLVal("\": return ").add(n.add(new ESLVal(";"))))));
                }
                for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                return $a;
              }}.apply(es)).add(nl.apply(indent.add(new ESLVal(6))).add(new ESLVal("default: throw new Error(\"ref illegal \" + self + \".\" + name);").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("}").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("}").add(nl.apply(indent).add(new ESLVal("public void handleTime(ESLVal $t) {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,time).add(nl.apply(indent).add(new ESLVal("}").add(nl.apply(indent).add(new ESLVal("public ESLVal init() {").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("return ").add(ppJExp.apply(indent.add(new ESLVal(6)),dynamics,init).add(new ESLVal(";").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("}").add(nl.apply(indent).add(new ESLVal("})")))))))))))))))))))))))))))))))))))))));
          }
          }
          }
          }
          }
          }
          }
          }
          }
          default: {ESLVal _v97 = _v23;
            
            return new ESLVal("********** unknown expression: ").add(_v97);
          }
        }
        }
      case "JExtendedBehaviour": {ESLVal $334 = _v23.termRef(0);
          ESLVal $333 = _v23.termRef(1);
          ESLVal $332 = _v23.termRef(2);
          ESLVal $331 = _v23.termRef(3);
          ESLVal $330 = _v23.termRef(4);
          ESLVal $329 = _v23.termRef(5);
          
          switch($330.termName) {
          case "JFun": {ESLVal $338 = $330.termRef(0);
            ESLVal $337 = $330.termRef(1);
            ESLVal $336 = $330.termRef(2);
            ESLVal $335 = $330.termRef(3);
            
            {ESLVal es = $334;
            
            {ESLVal parent = $333;
            
            {ESLVal fs = $332;
            
            {ESLVal init = $331;
            
            {ESLVal n = $338;
            
            {ESLVal args = $337;
            
            {ESLVal t = $336;
            
            {ESLVal body = $335;
            
            {ESLVal time = $329;
            
            return new ESLVal("new ESLVal(new BehaviourAdapter(").add(ppBehaviourParent.apply(indent,dynamics,parent).add(new ESLVal(",").add(((Supplier<ESLVal>)() -> { 
              if(time.eql(new ESLVal("JBlock",ESLVal.list())).boolVal)
                return new ESLVal("false");
                else
                  return new ESLVal("true");
            }).get().add(new ESLVal(",getSelf(),").add(ppJExp.apply(indent,dynamics,n).add(new ESLVal(") {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJFields.apply(indent.add(new ESLVal(2)),dynamics,fs).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal handle(ESLVal $m) {").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,body).add(new ESLVal("}").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal get(String name) {").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("switch(name) {").add(nl.apply(indent.add(new ESLVal(6))).add(ppJoin.apply(indent.add(new ESLVal(6)),new java.util.function.Function<ESLVal,ESLVal>() {
              public ESLVal apply(ESLVal $l0) {
                ESLVal $a = $nil;
                java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                while(!$l0.isNil()) { 
                  ESLVal n = $l0.head();
                  $l0 = $l0.tail();
                  $v.add(new ESLVal("case \"").add(n.add(new ESLVal("\": return ").add(n.add(new ESLVal(";"))))));
                }
                for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                return $a;
              }}.apply(es)).add(nl.apply(indent.add(new ESLVal(6))).add(new ESLVal("default: return refSuper(name);").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("}").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("}").add(nl.apply(indent).add(new ESLVal("public void handleTime(ESLVal $t) {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,time).add(nl.apply(indent).add(new ESLVal("}").add(nl.apply(indent).add(new ESLVal("public ESLVal init() {").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("return ").add(ppJExp.apply(indent.add(new ESLVal(6)),dynamics,init).add(new ESLVal(";").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("}").add(nl.apply(indent).add(new ESLVal("})")))))))))))))))))))))))))))))))))))))))));
          }
          }
          }
          }
          }
          }
          }
          }
          }
          }
          default: {ESLVal _v96 = _v23;
            
            return new ESLVal("********** unknown expression: ").add(_v96);
          }
        }
        }
      case "JNew": {ESLVal $326 = _v23.termRef(0);
          ESLVal $325 = _v23.termRef(1);
          
          if($325.isCons())
          {ESLVal $327 = $325.head();
            ESLVal $328 = $325.tail();
            
            {ESLVal b = $326;
            
            {ESLVal args = $325;
            
            return new ESLVal("newActor(").add(ppJExp.apply(indent,dynamics,b).add(new ESLVal(",new ESLVal(new Actor()),").add(ppJExps.apply(indent,dynamics,args,new ESLVal(",")).add(new ESLVal(")")))));
          }
          }
          }
        else if($325.isNil())
          {ESLVal b = $326;
            
            return new ESLVal("newActor(").add(ppJExp.apply(indent,dynamics,b).add(new ESLVal(",new ESLVal(new Actor()))")));
          }
        else {ESLVal b = $326;
            
            {ESLVal args = $325;
            
            return new ESLVal("newActor(").add(ppJExp.apply(indent,dynamics,b).add(new ESLVal(",new ESLVal(new Actor()),").add(ppJExps.apply(indent,dynamics,args,new ESLVal(",")).add(new ESLVal(")")))));
          }
          }
        }
      case "JNewArray": {ESLVal $324 = _v23.termRef(0);
          
          {ESLVal i = $324;
          
          return new ESLVal("newArray(").add(ppJExp.apply(indent,dynamics,i).add(new ESLVal(".intVal)")));
        }
        }
      case "JNewTable": {
          return new ESLVal("newTable()");
        }
      case "JNewJava": {ESLVal $321 = _v23.termRef(0);
          ESLVal $320 = _v23.termRef(1);
          
          if($320.isCons())
          {ESLVal $322 = $320.head();
            ESLVal $323 = $320.tail();
            
            {ESLVal n = $321;
            
            {ESLVal args = $320;
            
            return new ESLVal("newJavaActor(\"").add(n.add(new ESLVal("\",").add(ppJExps.apply(indent,dynamics,args,new ESLVal(",")).add(new ESLVal(")")))));
          }
          }
          }
        else if($320.isNil())
          {ESLVal n = $321;
            
            return new ESLVal("newJavaActor(\"").add(n.add(new ESLVal("\")")));
          }
        else {ESLVal n = $321;
            
            {ESLVal args = $320;
            
            return new ESLVal("newJavaActor(\"").add(n.add(new ESLVal("\",").add(ppJExps.apply(indent,dynamics,args,new ESLVal(",")).add(new ESLVal(")")))));
          }
          }
        }
      case "JRecord": {ESLVal $319 = _v23.termRef(0);
          
          {ESLVal fs = $319;
          
          return new ESLVal("newRecord(new ESLVal[]{").add(ppJExps.apply(indent,dynamics,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v24 = $qualArg;
                
                switch(_v24.termName) {
                case "JField": {ESLVal $401 = _v24.termRef(0);
                  ESLVal $400 = _v24.termRef(1);
                  ESLVal $399 = _v24.termRef(2);
                  
                  {ESLVal n = $401;
                  
                  {ESLVal t = $400;
                  
                  {ESLVal _v94 = $399;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JConstExp",new ESLVal("JConstStr",n))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v24;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten(),new ESLVal(",")).add(new ESLVal("},").add(ppJExps.apply(indent,dynamics,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v25 = $qualArg;
                
                switch(_v25.termName) {
                case "JField": {ESLVal $404 = _v25.termRef(0);
                  ESLVal $403 = _v25.termRef(1);
                  ESLVal $402 = _v25.termRef(2);
                  
                  {ESLVal n = $404;
                  
                  {ESLVal t = $403;
                  
                  {ESLVal _v95 = $402;
                  
                  return ESLVal.list(ESLVal.list(_v95));
                }
                }
                }
                }
                default: {ESLVal _0 = _v25;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten(),new ESLVal(",")).add(new ESLVal(")")))));
        }
        }
      case "JSend": {ESLVal $316 = _v23.termRef(0);
          ESLVal $315 = _v23.termRef(1);
          ESLVal $314 = _v23.termRef(2);
          
          if($314.isCons())
          {ESLVal $317 = $314.head();
            ESLVal $318 = $314.tail();
            
            {ESLVal _v91 = $316;
            
            {ESLVal m = $315;
            
            {ESLVal args = $314;
            
            return new ESLVal("Lib.send(").add(ppJExp.apply(indent,dynamics,_v91).add(new ESLVal(",\"").add(m.add(new ESLVal("\",").add(ppJExps.apply(indent,dynamics,args,new ESLVal(",")).add(new ESLVal(")")))))));
          }
          }
          }
          }
        else if($314.isNil())
          {ESLVal _v92 = $316;
            
            {ESLVal m = $315;
            
            return new ESLVal("Lib.send(").add(ppJExp.apply(indent,dynamics,_v92).add(new ESLVal(",\"").add(m.add(new ESLVal("\")")))));
          }
          }
        else {ESLVal _v93 = $316;
            
            {ESLVal m = $315;
            
            {ESLVal args = $314;
            
            return new ESLVal("Lib.send(").add(ppJExp.apply(indent,dynamics,_v93).add(new ESLVal(",\"").add(m.add(new ESLVal("\",").add(ppJExps.apply(indent,dynamics,args,new ESLVal(",")).add(new ESLVal(")")))))));
          }
          }
          }
        }
      case "JSendSuper": {ESLVal $313 = _v23.termRef(0);
          
          {ESLVal _v90 = $313;
          
          return new ESLVal("sendSuper(").add(ppJExp.apply(indent,dynamics,_v90).add(new ESLVal(")")));
        }
        }
      case "JSendTimeSuper": {
          return new ESLVal("sendTimeSuper($t)");
        }
      case "JSelf": {
          return new ESLVal("getSelf()");
        }
      case "JRef": {ESLVal $312 = _v23.termRef(0);
          ESLVal $311 = _v23.termRef(1);
          
          {ESLVal _v89 = $312;
          
          {ESLVal n = $311;
          
          return ppJExp.apply(indent,dynamics,_v89).add(new ESLVal(".ref(\"").add(n.add(new ESLVal("\")"))));
        }
        }
        }
      case "JRefSuper": {ESLVal $310 = _v23.termRef(0);
          
          {ESLVal n = $310;
          
          return new ESLVal("refSuper(\"").add(n.add(new ESLVal("\")")));
        }
        }
      case "JGrab": {ESLVal $309 = _v23.termRef(0);
          ESLVal $308 = _v23.termRef(1);
          
          {ESLVal es = $309;
          
          {ESLVal c = $308;
          
          return new ESLVal("lock(new Function(new ESLVal(\"grab\"),getSelf()) {").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal apply(ESLVal ...args) { ").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("return ").add(ppJExp.apply(indent,dynamics,c).add(new ESLVal(";").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("}},").add(ppJExps.apply(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")")))))))))));
        }
        }
        }
      case "JTry": {ESLVal $307 = _v23.termRef(0);
          ESLVal $306 = _v23.termRef(1);
          ESLVal $305 = _v23.termRef(2);
          
          {ESLVal _v88 = $307;
          
          {ESLVal n = $306;
          
          {ESLVal c = $305;
          
          return new ESLVal("new Function(new ESLVal(\"try\"),getSelf()) {").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal apply(ESLVal... args) { ").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("try { ").add(nl.apply(indent.add(new ESLVal(6))).add(new ESLVal("return ").add(ppJExp.apply(indent.add(new ESLVal(4)),dynamics,_v88).add(new ESLVal(";").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("} catch(ESLError $exception) {").add(nl.apply(indent.add(new ESLVal(6))).add(new ESLVal("ESLVal ").add(n.add(new ESLVal(" = $exception.value;").add(nl.apply(indent.add(new ESLVal(6))).add(ppJCommand.apply(indent,dynamics,c).add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("}").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("}").add(nl.apply(indent).add(new ESLVal("}.apply()")))))))))))))))))))))));
        }
        }
        }
        }
      case "JProbably": {ESLVal $304 = _v23.termRef(0);
          ESLVal $303 = _v23.termRef(1);
          ESLVal $302 = _v23.termRef(2);
          
          {ESLVal _v87 = $304;
          
          {ESLVal e1 = $303;
          
          {ESLVal e2 = $302;
          
          return new ESLVal("probably(").add(ppJExp.apply(indent,dynamics,_v87).add(new ESLVal(",").add(ppJExp.apply(indent,dynamics,probFun.apply(e1)).add(new ESLVal(",").add(ppJExp.apply(indent,dynamics,probFun.apply(e2)).add(new ESLVal(")")))))));
        }
        }
        }
        }
        default: {ESLVal _v112 = _v23;
          
          return new ESLVal("********** unknown expression: ").add(_v112);
        }
      }
      }
    }
  });
  private static ESLVal ppJCmp = new ESLVal(new Function(new ESLVal("ppJCmp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal c = $args[2];
  { LetRec letrec = new LetRec() {
        ESLVal inner = new ESLVal(new Function(new ESLVal("inner"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v80 = $args[0];
          ESLVal _v81 = $args[1];
          ESLVal _v82 = $args[2];
          {ESLVal _v26 = _v82;
                
                switch(_v26.termName) {
                case "JCmpBind": {ESLVal $410 = _v26.termRef(0);
                  ESLVal $409 = _v26.termRef(1);
                  ESLVal $408 = _v26.termRef(2);
                  
                  {ESLVal n = $410;
                  
                  {ESLVal e = $409;
                  
                  {ESLVal _v84 = $408;
                  
                  return new ESLVal("ESLVal $l").add(_v81.add(new ESLVal(" = ").add(ppJExp.apply(_v80,dynamics,e).add(new ESLVal(";").add(nl.apply(_v80).add(new ESLVal("while(!$l").add(_v81.add(new ESLVal(".isNil()) {").add(nl.apply(_v80.add(new ESLVal(2))).add(new ESLVal("ESLVal ").add(n.add(new ESLVal(" = $l").add(_v81.add(new ESLVal(".head();").add(nl.apply(_v80.add(new ESLVal(2))).add(new ESLVal("$l").add(_v81.add(new ESLVal(" = $l").add(_v81.add(new ESLVal(".tail();").add(nl.apply(_v80.add(new ESLVal(2))).add(inner.apply(_v80.add(new ESLVal(2)),_v81.add($one),_v84).add(nl.apply(_v80).add(new ESLVal("}")))))))))))))))))))))))));
                }
                }
                }
                }
              case "JCmpList": {ESLVal $407 = _v26.termRef(0);
                  
                  {ESLVal e = $407;
                  
                  return new ESLVal("$v.add(").add(ppJExp.apply(_v80,dynamics,e).add(new ESLVal(");")));
                }
                }
              case "JCmpIf": {ESLVal $406 = _v26.termRef(0);
                  ESLVal $405 = _v26.termRef(1);
                  
                  {ESLVal e = $406;
                  
                  {ESLVal _v83 = $405;
                  
                  return new ESLVal("if(").add(ppJExp.apply(_v80,dynamics,e).add(new ESLVal(".boolVal) {").add(inner.apply(_v80,_v81,_v83).add(nl.apply(_v80).add(new ESLVal("}"))))));
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(21380,21981)").add(ESLVal.list(_v26)));
              }
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "inner": return inner;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal inner = letrec.get("inner");
      
        {ESLVal _v27 = c;
        
        switch(_v27.termName) {
        case "JCmpOuter": {ESLVal $413 = _v27.termRef(0);
          ESLVal $412 = _v27.termRef(1);
          ESLVal $411 = _v27.termRef(2);
          
          {ESLVal n = $413;
          
          {ESLVal e = $412;
          
          {ESLVal _v85 = $411;
          
          return new ESLVal("new java.util.function.Function<ESLVal,ESLVal>() {").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal apply(ESLVal $l0) {").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("ESLVal $a = $nil;").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("while(!$l0.isNil()) { ").add(nl.apply(indent.add(new ESLVal(6))).add(new ESLVal("ESLVal ").add(n.add(new ESLVal(" = $l0.head();").add(nl.apply(indent.add(new ESLVal(6))).add(new ESLVal("$l0 = $l0.tail();").add(nl.apply(indent.add(new ESLVal(6))).add(inner.apply(indent,$one,_v85).add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("}").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("return $a;").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("}}.apply(").add(ppJExp.apply(indent,dynamics,e).add(new ESLVal(")")))))))))))))))))))))))))));
        }
        }
        }
        }
        default: {ESLVal _v86 = _v27;
          
          return new ESLVal("// Illegal Comprehension ").add(_v86);
        }
      }
      }}
      
    }
  });
  private static ESLVal ppBehaviourParent = new ESLVal(new Function(new ESLVal("ppBehaviourParent"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal e = $args[2];
  {ESLVal _v28 = e;
        
        switch(_v28.termName) {
        case "JApply": {ESLVal $415 = _v28.termRef(0);
          ESLVal $414 = _v28.termRef(1);
          
          {ESLVal op = $415;
          
          {ESLVal args = $414;
          
          return new ESLVal("getParent(getSelf(),").add(ppJExp.apply(indent,dynamics,op).add(new ESLVal(",").add(ppJExps.apply(indent,dynamics,args,new ESLVal(",")).add(new ESLVal(")")))));
        }
        }
        }
        default: {ESLVal _v79 = _v28;
          
          return ppJExp.apply(indent,dynamics,_v79);
        }
      }
      }
    }
  });
  private static ESLVal probFun = new ESLVal(new Function(new ESLVal("probFun"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  return new ESLVal("JFun",new ESLVal("JConstExp",new ESLVal("JConstStr",new ESLVal("probFun"))),ESLVal.list(),$null,new ESLVal("JReturn",e));
    }
  });
  private static ESLVal ppJFun = new ESLVal(new Function(new ESLVal("ppJFun"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal n = $args[2];
  ESLVal args = $args[3];
  ESLVal t = $args[4];
  ESLVal body = $args[5];
  {ESLVal freeDynamics = dynamicVarsJCommand.apply(body);
        ESLVal argNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v29 = $qualArg;
                
                switch(_v29.termName) {
                case "JDec": {ESLVal $417 = _v29.termRef(0);
                  ESLVal $416 = _v29.termRef(1);
                  
                  {ESLVal _v75 = $417;
                  
                  {ESLVal _v76 = $416;
                  
                  return ESLVal.list(ESLVal.list(_v75));
                }
                }
                }
                default: {ESLVal _0 = _v29;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(args).flatten().flatten();
        
        {ESLVal boundDynamics = new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal d = $l0.head();
                $l0 = $l0.tail();
                if(member.apply(d,freeDynamics).boolVal) {$v.add(d);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(argNames);
        
        {ESLVal dom = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v30 = $qualArg;
                
                switch(_v30.termName) {
                case "JDec": {ESLVal $419 = _v30.termRef(0);
                  ESLVal $418 = _v30.termRef(1);
                  
                  {ESLVal _v77 = $419;
                  
                  {ESLVal _v78 = $418;
                  
                  return ESLVal.list(ESLVal.list(_v78));
                }
                }
                }
                default: {ESLVal _0 = _v30;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(args).flatten().flatten();
        ESLVal ran = t;
        
        return new ESLVal("new ESLVal(new Function(").add(ppJExp.apply(indent,dynamics,n).add(new ESLVal(",getSelf()) {").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal apply(ESLVal... $args) {").add(nl.apply(indent.add(new ESLVal(4))).add(ppFunArgs.apply(indent,$zero,args,boundDynamics).add(ppJCommand.apply(indent.add(new ESLVal(4)),boundDynamics.add(new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal d = $l0.head();
              $l0 = $l0.tail();
              if(member.apply(d,argNames).not().boolVal) {$v.add(d);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(dynamics)),body).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("}").add(nl.apply(indent).add(new ESLVal("})"))))))))))));
      }
      }
      }
    }
  });
  private static ESLVal ppFunArgs = new ESLVal(new Function(new ESLVal("ppFunArgs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal i = $args[1];
  ESLVal args = $args[2];
  ESLVal dynamicArgs = $args[3];
  {ESLVal _v31 = args;
        
        if(_v31.isCons())
        {ESLVal $420 = _v31.head();
          ESLVal $421 = _v31.tail();
          
          switch($420.termName) {
          case "JDec": {ESLVal $423 = $420.termRef(0);
            ESLVal $422 = $420.termRef(1);
            
            {ESLVal n = $423;
            
            {ESLVal t = $422;
            
            {ESLVal _v71 = $421;
            
            if(member.apply(n,dynamicArgs).boolVal)
            return new ESLVal("ESLVal[] ").add(n.add(new ESLVal(" = new ESLVal[]{$args[").add(i.add(new ESLVal("]};").add(nl.apply(indent).add(ppFunArgs.apply(indent,i.add($one),_v71,dynamicArgs)))))));
            else
              {ESLVal _v72 = $423;
                
                {ESLVal _v73 = $422;
                
                {ESLVal _v74 = $421;
                
                return new ESLVal("ESLVal ").add(_v72.add(new ESLVal(" = $args[").add(i.add(new ESLVal("];").add(nl.apply(indent).add(ppFunArgs.apply(indent,i.add($one),_v74,dynamicArgs)))))));
              }
              }
              }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(23965,24359)").add(ESLVal.list(_v31)));
        }
        }
      else if(_v31.isNil())
        return new ESLVal("");
      else return error(new ESLVal("case error at Pos(23965,24359)").add(ESLVal.list(_v31)));
      }
    }
  });
  private static ESLVal ppJCommand = new ESLVal(new Function(new ESLVal("ppJCommand"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal c = $args[2];
  {ESLVal _v32 = c;
        
        switch(_v32.termName) {
        case "JIfCommand": {ESLVal $459 = _v32.termRef(0);
          ESLVal $458 = _v32.termRef(1);
          ESLVal $457 = _v32.termRef(2);
          
          {ESLVal e = $459;
          
          {ESLVal c1 = $458;
          
          {ESLVal c2 = $457;
          
          return new ESLVal("if(").add(ppJExp.apply(indent,dynamics,e).add(new ESLVal(".boolVal)").add(nl.apply(indent.add(new ESLVal(2))).add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,c1).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("else").add(nl.apply(indent.add(new ESLVal(4))).add(ppJCommand.apply(indent.add(new ESLVal(4)),dynamics,c2)))))))));
        }
        }
        }
        }
      case "JReturn": {ESLVal $454 = _v32.termRef(0);
          
          switch($454.termName) {
          case "JCommandExp": {ESLVal $456 = $454.termRef(0);
            ESLVal $455 = $454.termRef(1);
            
            {ESLVal _v69 = $456;
            
            {ESLVal t = $455;
            
            return ppJCommand.apply(indent,dynamics,_v69);
          }
          }
          }
          default: {ESLVal e = $454;
            
            return new ESLVal("return ").add(ppJExp.apply(indent.add(new ESLVal(2)),dynamics,e).add(new ESLVal(";")));
          }
        }
        }
      case "JCaseList": {ESLVal $453 = _v32.termRef(0);
          ESLVal $452 = _v32.termRef(1);
          ESLVal $451 = _v32.termRef(2);
          ESLVal $450 = _v32.termRef(3);
          
          {ESLVal l = $453;
          
          {ESLVal cons = $452;
          
          {ESLVal nil = $451;
          
          {ESLVal alt = $450;
          
          return new ESLVal("if(").add(ppJExp.apply(indent,dynamics,l).add(new ESLVal(".isCons())").add(nl.apply(indent.add(new ESLVal(2))).add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,cons).add(nl.apply(indent).add(new ESLVal("else if(").add(ppJExp.apply(indent,dynamics,l).add(new ESLVal(".isNil())").add(nl.apply(indent.add(new ESLVal(2))).add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,nil).add(nl.apply(indent).add(new ESLVal("else ").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,alt))))))))))))));
        }
        }
        }
        }
        }
      case "JCaseTerm": {ESLVal $449 = _v32.termRef(0);
          ESLVal $448 = _v32.termRef(1);
          ESLVal $447 = _v32.termRef(2);
          
          {ESLVal e = $449;
          
          {ESLVal arms = $448;
          
          {ESLVal alt = $447;
          
          return new ESLVal("switch(").add(ppJExp.apply(indent,dynamics,e).add(new ESLVal(".termName) {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v40 = $qualArg;
                
                switch(_v40.termName) {
                case "JTArm": {ESLVal $480 = _v40.termRef(0);
                  ESLVal $479 = _v40.termRef(1);
                  ESLVal $478 = _v40.termRef(2);
                  
                  {ESLVal n = $480;
                  
                  {ESLVal i = $479;
                  
                  {ESLVal _v68 = $478;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("case \"").add(n.add(new ESLVal("\": ").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,_v68))))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v40;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten()).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("default: ").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,alt).add(nl.apply(indent).add(new ESLVal("}"))))))))));
        }
        }
        }
        }
      case "JCaseInt": {ESLVal $446 = _v32.termRef(0);
          ESLVal $445 = _v32.termRef(1);
          ESLVal $444 = _v32.termRef(2);
          
          {ESLVal e = $446;
          
          {ESLVal arms = $445;
          
          {ESLVal alt = $444;
          
          return new ESLVal("switch(").add(ppJExp.apply(indent,dynamics,e).add(new ESLVal(".intVal) {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v39 = $qualArg;
                
                switch(_v39.termName) {
                case "JIArm": {ESLVal $477 = _v39.termRef(0);
                  ESLVal $476 = _v39.termRef(1);
                  
                  {ESLVal n = $477;
                  
                  {ESLVal _v67 = $476;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("case ").add(n.add(new ESLVal(": ").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,_v67))))));
                }
                }
                }
                default: {ESLVal _0 = _v39;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten()).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("default: ").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,alt).add(nl.apply(indent).add(new ESLVal("}"))))))))));
        }
        }
        }
        }
      case "JCaseStr": {ESLVal $443 = _v32.termRef(0);
          ESLVal $442 = _v32.termRef(1);
          ESLVal $441 = _v32.termRef(2);
          
          {ESLVal e = $443;
          
          {ESLVal arms = $442;
          
          {ESLVal alt = $441;
          
          return new ESLVal("switch(").add(ppJExp.apply(indent,dynamics,e).add(new ESLVal(".strVal) {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v38 = $qualArg;
                
                switch(_v38.termName) {
                case "JSArm": {ESLVal $475 = _v38.termRef(0);
                  ESLVal $474 = _v38.termRef(1);
                  
                  {ESLVal s = $475;
                  
                  {ESLVal _v66 = $474;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("case \"").add(s.add(new ESLVal("\": ").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,_v66))))));
                }
                }
                }
                default: {ESLVal _0 = _v38;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten()).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("default: ").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,alt).add(nl.apply(indent).add(new ESLVal("}"))))))))));
        }
        }
        }
        }
      case "JCaseBool": {ESLVal $440 = _v32.termRef(0);
          ESLVal $439 = _v32.termRef(1);
          ESLVal $438 = _v32.termRef(2);
          
          {ESLVal e = $440;
          
          {ESLVal arms = $439;
          
          {ESLVal alt = $438;
          
          return new ESLVal("switch(").add(ppJExp.apply(indent,dynamics,e).add(new ESLVal(".boolVal ? 1 : 0) {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v37 = $qualArg;
                
                switch(_v37.termName) {
                case "JBArm": {ESLVal $473 = _v37.termRef(0);
                  ESLVal $472 = _v37.termRef(1);
                  
                  {ESLVal b = $473;
                  
                  {ESLVal _v65 = $472;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("case ").add(((Supplier<ESLVal>)() -> { 
                    if(b.boolVal)
                      return $one;
                      else
                        return $zero;
                  }).get().add(new ESLVal(": ").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,_v65))))));
                }
                }
                }
                default: {ESLVal _0 = _v37;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten()).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("default: ").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,alt).add(nl.apply(indent).add(new ESLVal("}"))))))))));
        }
        }
        }
        }
      case "JLet": {ESLVal $437 = _v32.termRef(0);
          ESLVal $436 = _v32.termRef(1);
          
          {ESLVal bs = $437;
          
          {ESLVal _v64 = $436;
          
          {ESLVal boundVars = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v36 = $qualArg;
                  
                  switch(_v36.termName) {
                  case "JField": {ESLVal $471 = _v36.termRef(0);
                    ESLVal $470 = _v36.termRef(1);
                    ESLVal $469 = _v36.termRef(2);
                    
                    {ESLVal n = $471;
                    
                    {ESLVal t = $470;
                    
                    {ESLVal e = $469;
                    
                    return ESLVal.list(ESLVal.list(n));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v36;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(bs).flatten().flatten();
          ESLVal dynamicVars = dynamicVarsJCommand.apply(_v64);
          
          {ESLVal boundDynamicVars = filter.apply(new ESLVal(new Function(new ESLVal("fun136"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal s = $args[0];
            return member.apply(s,dynamicVars);
              }
            }),boundVars);
          
          return new ESLVal("{").add(ppJFields.apply(indent.add(new ESLVal(2)),dynamics.add(boundDynamicVars),bs).add(nl.apply(indent.add(new ESLVal(2))).add(ppJCommand.apply(indent,dynamics.add(boundDynamicVars),_v64).add(nl.apply(indent).add(new ESLVal("}"))))));
        }
        }
        }
        }
        }
      case "JLetRec": {ESLVal $435 = _v32.termRef(0);
          ESLVal $434 = _v32.termRef(1);
          
          {ESLVal bs = $435;
          
          {ESLVal _v63 = $434;
          
          return new ESLVal("{ LetRec letrec = new LetRec() {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJFields.apply(indent.add(new ESLVal(2)),dynamics,bs).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal get(String name) {").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("switch(name) {").add(nl.apply(indent.add(new ESLVal(6))).add(ppJoin.apply(indent.add(new ESLVal(6)),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v34 = $qualArg;
                
                switch(_v34.termName) {
                case "JField": {ESLVal $465 = _v34.termRef(0);
                  ESLVal $464 = _v34.termRef(1);
                  ESLVal $463 = _v34.termRef(2);
                  
                  {ESLVal n = $465;
                  
                  {ESLVal t = $464;
                  
                  {ESLVal e = $463;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("case \"").add(n.add(new ESLVal("\": return ").add(n.add(new ESLVal(";").add(nl.apply(indent.add(new ESLVal(6))))))))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v34;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(bs).flatten().flatten()).add(nl.apply(indent.add(new ESLVal(6))).add(new ESLVal("default: throw new Error(\"cannot find letrec binding\");").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("}").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("}").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("};").add(nl.apply(indent).add(ppJoin.apply(indent,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v35 = $qualArg;
                
                switch(_v35.termName) {
                case "JField": {ESLVal $468 = _v35.termRef(0);
                  ESLVal $467 = _v35.termRef(1);
                  ESLVal $466 = _v35.termRef(2);
                  
                  {ESLVal n = $468;
                  
                  {ESLVal t = $467;
                  
                  {ESLVal e = $466;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("ESLVal ").add(n.add(new ESLVal(" = letrec.get(\"").add(n.add(new ESLVal("\");").add(nl.apply(indent))))))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v35;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(bs).flatten().flatten()).add(nl.apply(indent.add(new ESLVal(2))).add(ppJCommand.apply(indent,dynamics,_v63).add(new ESLVal("}").add(nl.apply(indent)))))))))))))))))))))));
        }
        }
        }
      case "JPLet": {ESLVal $433 = _v32.termRef(0);
          ESLVal $432 = _v32.termRef(1);
          
          {ESLVal bs = $433;
          
          {ESLVal _v62 = $432;
          
          {ESLVal boundVars = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v33 = $qualArg;
                  
                  switch(_v33.termName) {
                  case "JField": {ESLVal $462 = _v33.termRef(0);
                    ESLVal $461 = _v33.termRef(1);
                    ESLVal $460 = _v33.termRef(2);
                    
                    {ESLVal n = $462;
                    
                    {ESLVal t = $461;
                    
                    {ESLVal e = $460;
                    
                    return ESLVal.list(ESLVal.list(n));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v33;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(bs).flatten().flatten();
          ESLVal dynamicVars = dynamicVarsJCommand.apply(_v62);
          
          {ESLVal boundDynamicVars = filter.apply(new ESLVal(new Function(new ESLVal("fun137"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal s = $args[0];
            return member.apply(s,dynamicVars);
              }
            }),boundVars);
          
          return new ESLVal("{").add(ppJParFields.apply(indent.add(new ESLVal(2)),dynamics.add(boundDynamicVars),bs).add(nl.apply(indent.add(new ESLVal(2))).add(ppJCommand.apply(indent,dynamics.add(boundDynamicVars),_v62).add(nl.apply(indent).add(new ESLVal("}"))))));
        }
        }
        }
        }
        }
      case "JBlock": {ESLVal $431 = _v32.termRef(0);
          
          {ESLVal cs = $431;
          
          return new ESLVal("{").add(ppJoin.apply(indent,new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal c = $l0.head();
                $l0 = $l0.tail();
                $v.add(ppJCommand.apply(indent,dynamics,c));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(cs)).add(new ESLVal("}")));
        }
        }
      case "JUpdate": {ESLVal $430 = _v32.termRef(0);
          ESLVal $429 = _v32.termRef(1);
          
          {ESLVal n = $430;
          
          {ESLVal e = $429;
          
          if(member.apply(n,dynamics).boolVal)
          return n.add(new ESLVal("[0] = ").add(ppJExp.apply(indent,dynamics,e).add(new ESLVal(";"))));
          else
            {ESLVal _v60 = $430;
              
              {ESLVal _v61 = $429;
              
              return _v60.add(new ESLVal(" = ").add(ppJExp.apply(indent,dynamics,_v61).add(new ESLVal(";"))));
            }
            }
        }
        }
        }
      case "JFor": {ESLVal $428 = _v32.termRef(0);
          ESLVal $427 = _v32.termRef(1);
          ESLVal $426 = _v32.termRef(2);
          ESLVal $425 = _v32.termRef(3);
          
          {ESLVal listName = $428;
          
          {ESLVal varName = $427;
          
          {ESLVal e = $426;
          
          {ESLVal _v59 = $425;
          
          return new ESLVal("{").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("ESLVal ").add(listName.add(new ESLVal(" = ").add(ppJExp.apply(indent.add(new ESLVal(2)),dynamics,e).add(new ESLVal(";").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("while(").add(listName.add(new ESLVal(".isCons()) {").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("ESLVal ").add(varName.add(new ESLVal(" = ").add(listName.add(new ESLVal(".headVal;").add(nl.apply(indent.add(new ESLVal(4))).add(ppJCommand.apply(indent.add(new ESLVal(4)),dynamics,_v59).add(nl.apply(indent.add(new ESLVal(4))).add(listName.add(new ESLVal(" = ").add(listName.add(new ESLVal(".tailVal;").add(new ESLVal("}").add(nl.apply(indent).add(new ESLVal("}")))))))))))))))))))))))))));
        }
        }
        }
        }
        }
      case "JStatement": {ESLVal $424 = _v32.termRef(0);
          
          {ESLVal e = $424;
          
          return ppJExp.apply(indent,dynamics,e).add(new ESLVal(";"));
        }
        }
        default: {ESLVal _v70 = _v32;
          
          return new ESLVal("******* unknown command: ").add(_v70);
        }
      }
      }
    }
  });
  private static ESLVal ppJParFields = new ESLVal(new Function(new ESLVal("ppJParFields"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal bs = $args[2];
  { LetRec letrec = new LetRec() {
        ESLVal vals = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v41 = $qualArg;
                
                switch(_v41.termName) {
                case "JField": {ESLVal $483 = _v41.termRef(0);
                  ESLVal $482 = _v41.termRef(1);
                  ESLVal $481 = _v41.termRef(2);
                  
                  {ESLVal n = $483;
                  
                  {ESLVal t = $482;
                  
                  {ESLVal e = $481;
                  
                  return ESLVal.list(ESLVal.list(e));
                }
                }
                }
                }
                default: {ESLVal _0 = _v41;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(bs).flatten().flatten();
        ESLVal names = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v42 = $qualArg;
                
                switch(_v42.termName) {
                case "JField": {ESLVal $486 = _v42.termRef(0);
                  ESLVal $485 = _v42.termRef(1);
                  ESLVal $484 = _v42.termRef(2);
                  
                  {ESLVal n = $486;
                  
                  {ESLVal t = $485;
                  
                  {ESLVal e = $484;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                default: {ESLVal _0 = _v42;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(bs).flatten().flatten();
        ESLVal doVals = new ESLVal(new Function(new ESLVal("doVals"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal vals = $args[0];
          {ESLVal _v43 = vals;
                
                if(_v43.isCons())
                {ESLVal $487 = _v43.head();
                  ESLVal $488 = _v43.tail();
                  
                  if($488.isCons())
                  {ESLVal $489 = $488.head();
                    ESLVal $490 = $488.tail();
                    
                    {ESLVal v = $487;
                    
                    {ESLVal vs = $488;
                    
                    return new ESLVal("() -> ").add(ppJExp.apply(indent,dynamics,v).add(new ESLVal(",").add(doVals.apply(vs))));
                  }
                  }
                  }
                else if($488.isNil())
                  {ESLVal v = $487;
                    
                    return new ESLVal("() -> ").add(ppJExp.apply(indent,dynamics,v));
                  }
                else {ESLVal v = $487;
                    
                    {ESLVal vs = $488;
                    
                    return new ESLVal("() -> ").add(ppJExp.apply(indent,dynamics,v).add(new ESLVal(",").add(doVals.apply(vs))));
                  }
                  }
                }
              else if(_v43.isNil())
                return new ESLVal("");
              else return error(new ESLVal("case error at Pos(29480,29643)").add(ESLVal.list(_v43)));
              }
            }
          });
        ESLVal bindNames = new ESLVal(new Function(new ESLVal("bindNames"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal ns = $args[0];
          ESLVal i = $args[1];
          {ESLVal _v44 = ns;
                
                if(_v44.isCons())
                {ESLVal $491 = _v44.head();
                  ESLVal $492 = _v44.tail();
                  
                  {ESLVal n = $491;
                  
                  {ESLVal _v56 = $492;
                  
                  if(member.apply(n,dynamics).boolVal)
                  return new ESLVal("ESLVal[] ").add(n.add(new ESLVal("= new ESLVal[]{$p[").add(i.add(new ESLVal("]};").add(nl.apply(indent).add(bindNames.apply(_v56,i.add($one))))))));
                  else
                    {ESLVal _v57 = $491;
                      
                      {ESLVal _v58 = $492;
                      
                      return new ESLVal("ESLVal ").add(_v57.add(new ESLVal("= $p[").add(i.add(new ESLVal("];").add(nl.apply(indent).add(bindNames.apply(_v58,i.add($one))))))));
                    }
                    }
                }
                }
                }
              else if(_v44.isNil())
                return new ESLVal("");
              else return error(new ESLVal("case error at Pos(29689,29939)").add(ESLVal.list(_v44)));
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "vals": return vals;
            
            case "names": return names;
            
            case "doVals": return doVals;
            
            case "bindNames": return bindNames;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal vals = letrec.get("vals");
      
      ESLVal names = letrec.get("names");
      
      ESLVal doVals = letrec.get("doVals");
      
      ESLVal bindNames = letrec.get("bindNames");
      
        return new ESLVal("ESLVal[] $p = plet(new Supplier[]{").add(doVals.apply(vals).add(new ESLVal("});").add(nl.apply(indent).add(bindNames.apply(names,$zero)))));}
      
    }
  });
  private static ESLVal ppJFields = new ESLVal(new Function(new ESLVal("ppJFields"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal bs = $args[2];
  {ESLVal _v45 = bs;
        
        if(_v45.isCons())
        {ESLVal $493 = _v45.head();
          ESLVal $494 = _v45.tail();
          
          {ESLVal f = $493;
          
          {ESLVal _v55 = $494;
          
          return ppFieldDef.apply(indent,dynamics,f).add(nl.apply(indent).add(ppJFields.apply(indent,dynamics,_v55)));
        }
        }
        }
      else if(_v45.isNil())
        return new ESLVal("");
      else return error(new ESLVal("case error at Pos(30108,30258)").add(ESLVal.list(_v45)));
      }
    }
  });
  private static ESLVal ppFieldDef = new ESLVal(new Function(new ESLVal("ppFieldDef"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal f = $args[2];
  {ESLVal _v46 = f;
        
        switch(_v46.termName) {
        case "JField": {ESLVal $497 = _v46.termRef(0);
          ESLVal $496 = _v46.termRef(1);
          ESLVal $495 = _v46.termRef(2);
          
          {ESLVal n = $497;
          
          {ESLVal t = $496;
          
          {ESLVal e = $495;
          
          if(member.apply(n,dynamics).boolVal)
          return new ESLVal("ESLVal[] ").add(n.add(new ESLVal(" = new ESLVal[]{").add(ppJExp.apply(indent.add(new ESLVal(2)),dynamics,e).add(new ESLVal("};")))));
          else
            {ESLVal _v52 = $497;
              
              {ESLVal _v53 = $496;
              
              {ESLVal _v54 = $495;
              
              return new ESLVal("ESLVal ").add(_v52.add(new ESLVal(" = ").add(ppJExp.apply(indent.add(new ESLVal(2)),dynamics,_v54).add(new ESLVal(";")))));
            }
            }
            }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(30322,30576)").add(ESLVal.list(_v46)));
      }
      }
    }
  });
  private static ESLVal ppJTerm = new ESLVal(new Function(new ESLVal("ppJTerm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal n = $args[2];
  ESLVal es = $args[3];
  {ESLVal _v47 = es;
        
        if(_v47.isCons())
        {ESLVal $498 = _v47.head();
          ESLVal $499 = _v47.tail();
          
          {ESLVal _v50 = _v47;
          
          return new ESLVal("new Term(\"").add(n.add(new ESLVal("\",").add(ppJExps.apply(indent,dynamics,_v50,new ESLVal(",")).add(new ESLVal(")")))));
        }
        }
      else if(_v47.isNil())
        return new ESLVal("new Term(\"").add(n.add(new ESLVal("\")")));
      else {ESLVal _v51 = _v47;
          
          return new ESLVal("new Term(\"").add(n.add(new ESLVal("\",").add(ppJExps.apply(indent,dynamics,_v51,new ESLVal(",")).add(new ESLVal(")")))));
        }
      }
    }
  });
  private static ESLVal ppJListExp = new ESLVal(new Function(new ESLVal("ppJListExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal t = $args[2];
  ESLVal es = $args[3];
  return new ESLVal("ESLVal.list(").add(ppJExps.apply(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")")));
    }
  });
  private static ESLVal ppJSetExp = new ESLVal(new Function(new ESLVal("ppJSetExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal t = $args[2];
  ESLVal es = $args[3];
  return new ESLVal("ESLVal.set(").add(ppJExps.apply(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")")));
    }
  });
  private static ESLVal ppJBagExp = new ESLVal(new Function(new ESLVal("ppJBagExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal t = $args[2];
  ESLVal es = $args[3];
  return new ESLVal("ESLVal.bag(").add(ppJExps.apply(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")")));
    }
  });
  public static ESLVal main = new ESLVal(new Function(new ESLVal("main"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      return new ESLVal(new BehaviourAdapter(true,getSelf(),new ESLVal("main")) {
          
          public ESLVal handle(ESLVal $m) {{ESLVal _v49 = $m;
            
            return error(new ESLVal("case error at Pos(0,0)").add(ESLVal.list(_v49)));
          }}
          public ESLVal get(String name) {
            switch(name) {
              
              default: throw new Error("ref illegal " + self + "." + name);
            }
          }
        public void handleTime(ESLVal $t) {
          {ESLVal t = $t;
            
            if($true.boolVal)
            {new Function(new ESLVal("try"),getSelf()) {
              public ESLVal apply(ESLVal... args) { 
                try { 
                  return print.apply(ppExp.apply($zero,parse.apply(new ESLVal("esl/compiler/test1.esl"))));
                } catch(ESLError $exception) {
                  ESLVal $x = $exception.value;
                  {ESLVal _v48 = $x;
              
              {ESLVal message = _v48;
              
              return print.apply(new ESLVal("PP Error: ").add(message));
            }
            }
                }
              }
            }.apply();
            print.apply(new ESLVal("DONE"));
            stopAll.apply();}
            else
              {}
          }
        }
        public ESLVal init() {
            return $null;
          }
        });
    }
  });
public static void main(String[] args) {
    newActor(main,new ESLVal(new Actor())); 
  }
}