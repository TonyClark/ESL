package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
import static esl.compiler.Types.*;
import static esl.Displays.*;
import java.util.function.Supplier;
public class UnusedVars {
  public static ESLVal getSelf() { return $null; }
  private static ESLVal resetWarnings = new ESLVal(new Function(new ESLVal("resetWarnings"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      return setWarnings.apply(ESLVal.list());
    }
  });
  private static ESLVal getWarnings = new ESLVal(new Function(new ESLVal("getWarnings"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      return edb.ref("getProperty").apply(new ESLVal("$WARNINGS"));
    }
  });
  private static ESLVal setWarnings = new ESLVal(new Function(new ESLVal("setWarnings"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal warnings = $args[0];
  return edb.ref("setProperty").apply(new ESLVal("$WARNINGS"),warnings);
    }
  });
  private static ESLVal addWarning = new ESLVal(new Function(new ESLVal("addWarning"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal message = $args[1];
  return setWarnings.apply(getWarnings.apply().cons(new ESLVal("Warning",l,message)));
    }
  });
  public static ESLVal checkUnusedVars = new ESLVal(new Function(new ESLVal("checkUnusedVars"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal path = $args[0];
  ESLVal module = $args[1];
  return walkAST.apply(module);
    }
  });
  private static ESLVal walkArm = new ESLVal(new Function(new ESLVal("walkArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal x = $args[0];
  {ESLVal _v1 = x;
        
        switch(_v1.termName) {
        case "BArm": {ESLVal $9 = _v1.termRef(0);
          ESLVal $8 = _v1.termRef(1);
          ESLVal $7 = _v1.termRef(2);
          ESLVal $6 = _v1.termRef(3);
          
          {ESLVal v0 = $9;
          
          {ESLVal v1 = $8;
          
          {ESLVal v2 = $7;
          
          {ESLVal v3 = $6;
          
          {{
          ESLVal _v2 = v1;
          while(_v2.isCons()) {
            ESLVal p = _v2.headVal;
            walkPattern.apply(p);
            _v2 = _v2.tailVal;}
        }
        walkAST.apply(v2);
        return walkAST.apply(v3);}
        }
        }
        }
        }
        }
      case "LArm": {ESLVal $5 = _v1.termRef(0);
          ESLVal $4 = _v1.termRef(1);
          ESLVal $3 = _v1.termRef(2);
          ESLVal $2 = _v1.termRef(3);
          ESLVal $1 = _v1.termRef(4);
          
          {ESLVal v0 = $5;
          
          {ESLVal v1 = $4;
          
          {ESLVal v2 = $3;
          
          {ESLVal v3 = $2;
          
          {ESLVal v4 = $1;
          
          return $null;
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(488,702)").add(ESLVal.list(_v1)));
      }
      }
    }
  });
  private static ESLVal walkPattern = new ESLVal(new Function(new ESLVal("walkPattern"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal x = $args[0];
  {ESLVal _v3 = x;
        
        switch(_v3.termName) {
        case "PAdd": {ESLVal $41 = _v3.termRef(0);
          ESLVal $40 = _v3.termRef(1);
          ESLVal $39 = _v3.termRef(2);
          
          {ESLVal v0 = $41;
          
          {ESLVal v1 = $40;
          
          {ESLVal v2 = $39;
          
          {walkPattern.apply(v1);
        return walkPattern.apply(v2);}
        }
        }
        }
        }
      case "PApplyType": {ESLVal $38 = _v3.termRef(0);
          ESLVal $37 = _v3.termRef(1);
          ESLVal $36 = _v3.termRef(2);
          
          {ESLVal v0 = $38;
          
          {ESLVal v1 = $37;
          
          {ESLVal v2 = $36;
          
          return walkPattern.apply(v1);
        }
        }
        }
        }
      case "PBagCons": {ESLVal $35 = _v3.termRef(0);
          ESLVal $34 = _v3.termRef(1);
          ESLVal $33 = _v3.termRef(2);
          
          {ESLVal v0 = $35;
          
          {ESLVal v1 = $34;
          
          {ESLVal v2 = $33;
          
          {walkPattern.apply(v1);
        return walkPattern.apply(v2);}
        }
        }
        }
        }
      case "PBool": {ESLVal $32 = _v3.termRef(0);
          ESLVal $31 = _v3.termRef(1);
          
          {ESLVal v0 = $32;
          
          {ESLVal v1 = $31;
          
          return $null;
        }
        }
        }
      case "PCons": {ESLVal $30 = _v3.termRef(0);
          ESLVal $29 = _v3.termRef(1);
          ESLVal $28 = _v3.termRef(2);
          
          {ESLVal v0 = $30;
          
          {ESLVal v1 = $29;
          
          {ESLVal v2 = $28;
          
          {walkPattern.apply(v1);
        return walkPattern.apply(v2);}
        }
        }
        }
        }
      case "PEmptyBag": {ESLVal $27 = _v3.termRef(0);
          
          {ESLVal v0 = $27;
          
          return $null;
        }
        }
      case "PEmptySet": {ESLVal $26 = _v3.termRef(0);
          
          {ESLVal v0 = $26;
          
          return $null;
        }
        }
      case "PInt": {ESLVal $25 = _v3.termRef(0);
          ESLVal $24 = _v3.termRef(1);
          
          {ESLVal v0 = $25;
          
          {ESLVal v1 = $24;
          
          return $null;
        }
        }
        }
      case "PNil": {ESLVal $23 = _v3.termRef(0);
          
          {ESLVal v0 = $23;
          
          return $null;
        }
        }
      case "PNull": {ESLVal $22 = _v3.termRef(0);
          
          {ESLVal v0 = $22;
          
          return $null;
        }
        }
      case "PSetCons": {ESLVal $21 = _v3.termRef(0);
          ESLVal $20 = _v3.termRef(1);
          ESLVal $19 = _v3.termRef(2);
          
          {ESLVal v0 = $21;
          
          {ESLVal v1 = $20;
          
          {ESLVal v2 = $19;
          
          {walkPattern.apply(v1);
        return walkPattern.apply(v2);}
        }
        }
        }
        }
      case "PStr": {ESLVal $18 = _v3.termRef(0);
          ESLVal $17 = _v3.termRef(1);
          
          {ESLVal v0 = $18;
          
          {ESLVal v1 = $17;
          
          return $null;
        }
        }
        }
      case "PTerm": {ESLVal $16 = _v3.termRef(0);
          ESLVal $15 = _v3.termRef(1);
          ESLVal $14 = _v3.termRef(2);
          ESLVal $13 = _v3.termRef(3);
          
          {ESLVal v0 = $16;
          
          {ESLVal v1 = $15;
          
          {ESLVal v2 = $14;
          
          {ESLVal v3 = $13;
          
          {{
          ESLVal _v4 = v3;
          while(_v4.isCons()) {
            ESLVal p = _v4.headVal;
            walkPattern.apply(p);
            _v4 = _v4.tailVal;}
        }
        return $null;}
        }
        }
        }
        }
        }
      case "PVar": {ESLVal $12 = _v3.termRef(0);
          ESLVal $11 = _v3.termRef(1);
          ESLVal $10 = _v3.termRef(2);
          
          {ESLVal v0 = $12;
          
          {ESLVal v1 = $11;
          
          {ESLVal v2 = $10;
          
          return $null;
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(745,1589)").add(ESLVal.list(_v3)));
      }
      }
    }
  });
  private static ESLVal walkTDec = new ESLVal(new Function(new ESLVal("walkTDec"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d = $args[0];
  {ESLVal _v5 = d;
        
        switch(_v5.termName) {
        case "Dec": {ESLVal $45 = _v5.termRef(0);
          ESLVal $44 = _v5.termRef(1);
          ESLVal $43 = _v5.termRef(2);
          ESLVal $42 = _v5.termRef(3);
          
          {ESLVal v0 = $45;
          
          {ESLVal v1 = $44;
          
          {ESLVal v2 = $43;
          
          {ESLVal v3 = $42;
          
          return $null;
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(1621,1687)").add(ESLVal.list(_v5)));
      }
      }
    }
  });
  private static ESLVal walkTBind = new ESLVal(new Function(new ESLVal("walkTBind"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal b = $args[0];
  {ESLVal _v6 = b;
        
        switch(_v6.termName) {
        case "TypeBind": {ESLVal $71 = _v6.termRef(0);
          ESLVal $70 = _v6.termRef(1);
          ESLVal $69 = _v6.termRef(2);
          ESLVal $68 = _v6.termRef(3);
          
          {ESLVal v0 = $71;
          
          {ESLVal v1 = $70;
          
          {ESLVal v2 = $69;
          
          {ESLVal v3 = $68;
          
          return walkAST.apply(v3);
        }
        }
        }
        }
        }
      case "CnstrBind": {ESLVal $67 = _v6.termRef(0);
          ESLVal $66 = _v6.termRef(1);
          ESLVal $65 = _v6.termRef(2);
          ESLVal $64 = _v6.termRef(3);
          
          {ESLVal v0 = $67;
          
          {ESLVal v1 = $66;
          
          {ESLVal v2 = $65;
          
          {ESLVal v3 = $64;
          
          return walkAST.apply(v3);
        }
        }
        }
        }
        }
      case "FunBind": {ESLVal $63 = _v6.termRef(0);
          ESLVal $62 = _v6.termRef(1);
          ESLVal $61 = _v6.termRef(2);
          ESLVal $60 = _v6.termRef(3);
          ESLVal $59 = _v6.termRef(4);
          ESLVal $58 = _v6.termRef(5);
          ESLVal $57 = _v6.termRef(6);
          
          {ESLVal v0 = $63;
          
          {ESLVal v1 = $62;
          
          {ESLVal v2 = $61;
          
          {ESLVal v3 = $60;
          
          {ESLVal v4 = $59;
          
          {ESLVal v5 = $58;
          
          {ESLVal v6 = $57;
          
          {walkAST.apply(v5);
        return walkAST.apply(v6);}
        }
        }
        }
        }
        }
        }
        }
        }
      case "FunBinds": {ESLVal $56 = _v6.termRef(0);
          ESLVal $55 = _v6.termRef(1);
          
          {ESLVal v0 = $56;
          
          {ESLVal v1 = $55;
          
          return $null;
        }
        }
        }
      case "Binding": {ESLVal $54 = _v6.termRef(0);
          ESLVal $53 = _v6.termRef(1);
          ESLVal $52 = _v6.termRef(2);
          ESLVal $51 = _v6.termRef(3);
          ESLVal $50 = _v6.termRef(4);
          
          {ESLVal v0 = $54;
          
          {ESLVal v1 = $53;
          
          {ESLVal v2 = $52;
          
          {ESLVal v3 = $51;
          
          {ESLVal v4 = $50;
          
          return walkAST.apply(v4);
        }
        }
        }
        }
        }
        }
      case "DataBind": {ESLVal $49 = _v6.termRef(0);
          ESLVal $48 = _v6.termRef(1);
          ESLVal $47 = _v6.termRef(2);
          ESLVal $46 = _v6.termRef(3);
          
          {ESLVal v0 = $49;
          
          {ESLVal v1 = $48;
          
          {ESLVal v2 = $47;
          
          {ESLVal v3 = $46;
          
          return walkAST.apply(v3);
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(1720,2218)").add(ESLVal.list(_v6)));
      }
      }
    }
  });
  private static ESLVal walkQualifier = new ESLVal(new Function(new ESLVal("walkQualifier"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal x = $args[0];
  {ESLVal _v7 = x;
        
        switch(_v7.termName) {
        case "BQual": {ESLVal $76 = _v7.termRef(0);
          ESLVal $75 = _v7.termRef(1);
          ESLVal $74 = _v7.termRef(2);
          
          {ESLVal v0 = $76;
          
          {ESLVal v1 = $75;
          
          {ESLVal v2 = $74;
          
          {walkPattern.apply(v1);
        return walkAST.apply(v2);}
        }
        }
        }
        }
      case "PQual": {ESLVal $73 = _v7.termRef(0);
          ESLVal $72 = _v7.termRef(1);
          
          {ESLVal v0 = $73;
          
          {ESLVal v1 = $72;
          
          return walkAST.apply(v1);
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(2265,2426)").add(ESLVal.list(_v7)));
      }
      }
    }
  });
  private static ESLVal walkDRef = new ESLVal(new Function(new ESLVal("walkDRef"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal x = $args[0];
  {ESLVal _v8 = x;
        
        switch(_v8.termName) {
        case "VarDynamicRef": {ESLVal $81 = _v8.termRef(0);
          ESLVal $80 = _v8.termRef(1);
          
          {ESLVal v0 = $81;
          
          {ESLVal v1 = $80;
          
          return walkAST.apply(v1);
        }
        }
        }
      case "ActorDynamicRef": {ESLVal $79 = _v8.termRef(0);
          ESLVal $78 = _v8.termRef(1);
          ESLVal $77 = _v8.termRef(2);
          
          {ESLVal v0 = $79;
          
          {ESLVal v1 = $78;
          
          {ESLVal v2 = $77;
          
          return walkAST.apply(v1);
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(2460,2584)").add(ESLVal.list(_v8)));
      }
      }
    }
  });
  private static ESLVal walkAST = new ESLVal(new Function(new ESLVal("walkAST"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal x = $args[0];
  {ESLVal _v9 = x;
        
        switch(_v9.termName) {
        case "ActExp": {ESLVal $226 = _v9.termRef(0);
          ESLVal $225 = _v9.termRef(1);
          ESLVal $224 = _v9.termRef(2);
          ESLVal $223 = _v9.termRef(3);
          ESLVal $222 = _v9.termRef(4);
          ESLVal $221 = _v9.termRef(5);
          ESLVal $220 = _v9.termRef(6);
          ESLVal $219 = _v9.termRef(7);
          
          {ESLVal v0 = $226;
          
          {ESLVal v1 = $225;
          
          {ESLVal v2 = $224;
          
          {ESLVal v3 = $223;
          
          {ESLVal v4 = $222;
          
          {ESLVal v5 = $221;
          
          {ESLVal v6 = $220;
          
          {ESLVal v7 = $219;
          
          {{
          ESLVal _v30 = v2;
          while(_v30.isCons()) {
            ESLVal d = _v30.headVal;
            walkTDec.apply(d);
            _v30 = _v30.tailVal;}
        }
        walkAST.apply(v4);
        {
          ESLVal _v31 = v5;
          while(_v31.isCons()) {
            ESLVal b = _v31.headVal;
            walkTBind.apply(b);
            _v31 = _v31.tailVal;}
        }
        walkAST.apply(v6);
        {{
          ESLVal _v32 = v7;
          while(_v32.isCons()) {
            ESLVal a = _v32.headVal;
            walkArm.apply(a);
            _v32 = _v32.tailVal;}
        }
        return $null;}}
        }
        }
        }
        }
        }
        }
        }
        }
        }
      case "Apply": {ESLVal $218 = _v9.termRef(0);
          ESLVal $217 = _v9.termRef(1);
          ESLVal $216 = _v9.termRef(2);
          
          {ESLVal v0 = $218;
          
          {ESLVal v1 = $217;
          
          {ESLVal v2 = $216;
          
          {walkAST.apply(v1);
        {{
          ESLVal _v29 = v2;
          while(_v29.isCons()) {
            ESLVal e = _v29.headVal;
            walkAST.apply(e);
            _v29 = _v29.tailVal;}
        }
        return $null;}}
        }
        }
        }
        }
      case "ApplyTypeExp": {ESLVal $215 = _v9.termRef(0);
          ESLVal $214 = _v9.termRef(1);
          ESLVal $213 = _v9.termRef(2);
          
          {ESLVal v0 = $215;
          
          {ESLVal v1 = $214;
          
          {ESLVal v2 = $213;
          
          return walkAST.apply(v1);
        }
        }
        }
        }
      case "ArrayRef": {ESLVal $212 = _v9.termRef(0);
          ESLVal $211 = _v9.termRef(1);
          ESLVal $210 = _v9.termRef(2);
          
          {ESLVal v0 = $212;
          
          {ESLVal v1 = $211;
          
          {ESLVal v2 = $210;
          
          {walkAST.apply(v1);
        return walkAST.apply(v2);}
        }
        }
        }
        }
      case "ArrayUpdate": {ESLVal $209 = _v9.termRef(0);
          ESLVal $208 = _v9.termRef(1);
          ESLVal $207 = _v9.termRef(2);
          ESLVal $206 = _v9.termRef(3);
          
          {ESLVal v0 = $209;
          
          {ESLVal v1 = $208;
          
          {ESLVal v2 = $207;
          
          {ESLVal v3 = $206;
          
          {walkAST.apply(v1);
        walkAST.apply(v2);
        return walkAST.apply(v3);}
        }
        }
        }
        }
        }
      case "BagExp": {ESLVal $205 = _v9.termRef(0);
          ESLVal $204 = _v9.termRef(1);
          
          {ESLVal v0 = $205;
          
          {ESLVal v1 = $204;
          
          {{
          ESLVal _v28 = v1;
          while(_v28.isCons()) {
            ESLVal e = _v28.headVal;
            walkAST.apply(e);
            _v28 = _v28.tailVal;}
        }
        return $null;}
        }
        }
        }
      case "Become": {ESLVal $203 = _v9.termRef(0);
          ESLVal $202 = _v9.termRef(1);
          
          {ESLVal v0 = $203;
          
          {ESLVal v1 = $202;
          
          return walkAST.apply(v1);
        }
        }
        }
      case "BinExp": {ESLVal $201 = _v9.termRef(0);
          ESLVal $200 = _v9.termRef(1);
          ESLVal $199 = _v9.termRef(2);
          ESLVal $198 = _v9.termRef(3);
          
          {ESLVal v0 = $201;
          
          {ESLVal v1 = $200;
          
          {ESLVal v2 = $199;
          
          {ESLVal v3 = $198;
          
          {walkAST.apply(v1);
        return walkAST.apply(v3);}
        }
        }
        }
        }
        }
      case "Block": {ESLVal $197 = _v9.termRef(0);
          ESLVal $196 = _v9.termRef(1);
          
          {ESLVal v0 = $197;
          
          {ESLVal v1 = $196;
          
          {{
          ESLVal _v27 = v1;
          while(_v27.isCons()) {
            ESLVal e = _v27.headVal;
            walkAST.apply(e);
            _v27 = _v27.tailVal;}
        }
        return $null;}
        }
        }
        }
      case "BoolExp": {ESLVal $195 = _v9.termRef(0);
          ESLVal $194 = _v9.termRef(1);
          
          {ESLVal v0 = $195;
          
          {ESLVal v1 = $194;
          
          return $null;
        }
        }
        }
      case "Case": {ESLVal $193 = _v9.termRef(0);
          ESLVal $192 = _v9.termRef(1);
          ESLVal $191 = _v9.termRef(2);
          ESLVal $190 = _v9.termRef(3);
          
          {ESLVal v0 = $193;
          
          {ESLVal v1 = $192;
          
          {ESLVal v2 = $191;
          
          {ESLVal v3 = $190;
          
          {{
          ESLVal _v24 = v1;
          while(_v24.isCons()) {
            ESLVal d = _v24.headVal;
            walkTDec.apply(d);
            _v24 = _v24.tailVal;}
        }
        {
          ESLVal _v25 = v2;
          while(_v25.isCons()) {
            ESLVal e = _v25.headVal;
            walkAST.apply(e);
            _v25 = _v25.tailVal;}
        }
        {{
          ESLVal _v26 = v3;
          while(_v26.isCons()) {
            ESLVal a = _v26.headVal;
            walkArm.apply(a);
            _v26 = _v26.tailVal;}
        }
        return $null;}}
        }
        }
        }
        }
        }
      case "Cmp": {ESLVal $189 = _v9.termRef(0);
          ESLVal $188 = _v9.termRef(1);
          ESLVal $187 = _v9.termRef(2);
          
          {ESLVal v0 = $189;
          
          {ESLVal v1 = $188;
          
          {ESLVal v2 = $187;
          
          {walkAST.apply(v1);
        {{
          ESLVal _v23 = v2;
          while(_v23.isCons()) {
            ESLVal q = _v23.headVal;
            walkQualifier.apply(q);
            _v23 = _v23.tailVal;}
        }
        return $null;}}
        }
        }
        }
        }
      case "Cons": {ESLVal $186 = _v9.termRef(0);
          ESLVal $185 = _v9.termRef(1);
          
          {ESLVal v0 = $186;
          
          {ESLVal v1 = $185;
          
          {walkAST.apply(v0);
        return walkAST.apply(v1);}
        }
        }
        }
      case "For": {ESLVal $184 = _v9.termRef(0);
          ESLVal $183 = _v9.termRef(1);
          ESLVal $182 = _v9.termRef(2);
          ESLVal $181 = _v9.termRef(3);
          
          {ESLVal v0 = $184;
          
          {ESLVal v1 = $183;
          
          {ESLVal v2 = $182;
          
          {ESLVal v3 = $181;
          
          {walkPattern.apply(v1);
        walkAST.apply(v2);
        return walkAST.apply(v3);}
        }
        }
        }
        }
        }
      case "FunExp": {ESLVal $180 = _v9.termRef(0);
          ESLVal $179 = _v9.termRef(1);
          ESLVal $178 = _v9.termRef(2);
          ESLVal $177 = _v9.termRef(3);
          ESLVal $176 = _v9.termRef(4);
          
          {ESLVal v0 = $180;
          
          {ESLVal v1 = $179;
          
          {ESLVal v2 = $178;
          
          {ESLVal v3 = $177;
          
          {ESLVal v4 = $176;
          
          {walkAST.apply(v1);
        {
          ESLVal _v22 = v2;
          while(_v22.isCons()) {
            ESLVal d = _v22.headVal;
            walkTDec.apply(d);
            _v22 = _v22.tailVal;}
        }
        return walkAST.apply(v4);}
        }
        }
        }
        }
        }
        }
      case "Grab": {ESLVal $175 = _v9.termRef(0);
          ESLVal $174 = _v9.termRef(1);
          ESLVal $173 = _v9.termRef(2);
          
          {ESLVal v0 = $175;
          
          {ESLVal v1 = $174;
          
          {ESLVal v2 = $173;
          
          {{
          ESLVal _v21 = v1;
          while(_v21.isCons()) {
            ESLVal d = _v21.headVal;
            walkDRef.apply(d);
            _v21 = _v21.tailVal;}
        }
        return walkAST.apply(v2);}
        }
        }
        }
        }
      case "If": {ESLVal $172 = _v9.termRef(0);
          ESLVal $171 = _v9.termRef(1);
          ESLVal $170 = _v9.termRef(2);
          ESLVal $169 = _v9.termRef(3);
          
          {ESLVal v0 = $172;
          
          {ESLVal v1 = $171;
          
          {ESLVal v2 = $170;
          
          {ESLVal v3 = $169;
          
          {walkAST.apply(v1);
        walkAST.apply(v2);
        return walkAST.apply(v3);}
        }
        }
        }
        }
        }
      case "IntExp": {ESLVal $168 = _v9.termRef(0);
          ESLVal $167 = _v9.termRef(1);
          
          {ESLVal v0 = $168;
          
          {ESLVal v1 = $167;
          
          return $null;
        }
        }
        }
      case "FloatExp": {ESLVal $166 = _v9.termRef(0);
          ESLVal $165 = _v9.termRef(1);
          
          {ESLVal v0 = $166;
          
          {ESLVal v1 = $165;
          
          return $null;
        }
        }
        }
      case "Fold": {ESLVal $164 = _v9.termRef(0);
          ESLVal $163 = _v9.termRef(1);
          ESLVal $162 = _v9.termRef(2);
          
          {ESLVal v0 = $164;
          
          {ESLVal v1 = $163;
          
          {ESLVal v2 = $162;
          
          return walkAST.apply(v2);
        }
        }
        }
        }
      case "Head": {ESLVal $161 = _v9.termRef(0);
          
          {ESLVal v0 = $161;
          
          return walkAST.apply(v0);
        }
        }
      case "Let": {ESLVal $160 = _v9.termRef(0);
          ESLVal $159 = _v9.termRef(1);
          ESLVal $158 = _v9.termRef(2);
          
          {ESLVal v0 = $160;
          
          {ESLVal v1 = $159;
          
          {ESLVal v2 = $158;
          
          {{
          ESLVal _v20 = v1;
          while(_v20.isCons()) {
            ESLVal b = _v20.headVal;
            walkTBind.apply(b);
            _v20 = _v20.tailVal;}
        }
        return walkAST.apply(v2);}
        }
        }
        }
        }
      case "Letrec": {ESLVal $157 = _v9.termRef(0);
          ESLVal $156 = _v9.termRef(1);
          ESLVal $155 = _v9.termRef(2);
          
          {ESLVal v0 = $157;
          
          {ESLVal v1 = $156;
          
          {ESLVal v2 = $155;
          
          {{
          ESLVal _v19 = v1;
          while(_v19.isCons()) {
            ESLVal b = _v19.headVal;
            walkTBind.apply(b);
            _v19 = _v19.tailVal;}
        }
        return walkAST.apply(v2);}
        }
        }
        }
        }
      case "List": {ESLVal $154 = _v9.termRef(0);
          ESLVal $153 = _v9.termRef(1);
          
          {ESLVal v0 = $154;
          
          {ESLVal v1 = $153;
          
          {{
          ESLVal _v18 = v1;
          while(_v18.isCons()) {
            ESLVal e = _v18.headVal;
            walkAST.apply(e);
            _v18 = _v18.tailVal;}
        }
        return $null;}
        }
        }
        }
      case "Module": {ESLVal $152 = _v9.termRef(0);
          ESLVal $151 = _v9.termRef(1);
          ESLVal $150 = _v9.termRef(2);
          ESLVal $149 = _v9.termRef(3);
          ESLVal $148 = _v9.termRef(4);
          ESLVal $147 = _v9.termRef(5);
          ESLVal $146 = _v9.termRef(6);
          
          {ESLVal v0 = $152;
          
          {ESLVal v1 = $151;
          
          {ESLVal v2 = $150;
          
          {ESLVal v3 = $149;
          
          {ESLVal v4 = $148;
          
          {ESLVal v5 = $147;
          
          {ESLVal v6 = $146;
          
          {{
          ESLVal _v17 = v6;
          while(_v17.isCons()) {
            ESLVal b = _v17.headVal;
            walkTBind.apply(b);
            _v17 = _v17.tailVal;}
        }
        return $null;}
        }
        }
        }
        }
        }
        }
        }
        }
      case "New": {ESLVal $145 = _v9.termRef(0);
          ESLVal $144 = _v9.termRef(1);
          ESLVal $143 = _v9.termRef(2);
          
          {ESLVal v0 = $145;
          
          {ESLVal v1 = $144;
          
          {ESLVal v2 = $143;
          
          {walkAST.apply(v1);
        {{
          ESLVal _v16 = v2;
          while(_v16.isCons()) {
            ESLVal e = _v16.headVal;
            walkAST.apply(e);
            _v16 = _v16.tailVal;}
        }
        return $null;}}
        }
        }
        }
        }
      case "NewArray": {ESLVal $142 = _v9.termRef(0);
          ESLVal $141 = _v9.termRef(1);
          ESLVal $140 = _v9.termRef(2);
          
          {ESLVal v0 = $142;
          
          {ESLVal v1 = $141;
          
          {ESLVal v2 = $140;
          
          return walkAST.apply(v2);
        }
        }
        }
        }
      case "NewJava": {ESLVal $139 = _v9.termRef(0);
          ESLVal $138 = _v9.termRef(1);
          ESLVal $137 = _v9.termRef(2);
          ESLVal $136 = _v9.termRef(3);
          
          {ESLVal v0 = $139;
          
          {ESLVal v1 = $138;
          
          {ESLVal v2 = $137;
          
          {ESLVal v3 = $136;
          
          {{
          ESLVal _v15 = v3;
          while(_v15.isCons()) {
            ESLVal e = _v15.headVal;
            walkAST.apply(e);
            _v15 = _v15.tailVal;}
        }
        return $null;}
        }
        }
        }
        }
        }
      case "NewTable": {ESLVal $135 = _v9.termRef(0);
          ESLVal $134 = _v9.termRef(1);
          ESLVal $133 = _v9.termRef(2);
          
          {ESLVal v0 = $135;
          
          {ESLVal v1 = $134;
          
          {ESLVal v2 = $133;
          
          return $null;
        }
        }
        }
        }
      case "Not": {ESLVal $132 = _v9.termRef(0);
          ESLVal $131 = _v9.termRef(1);
          
          {ESLVal v0 = $132;
          
          {ESLVal v1 = $131;
          
          return walkAST.apply(v1);
        }
        }
        }
      case "Now": {ESLVal $130 = _v9.termRef(0);
          
          {ESLVal v0 = $130;
          
          return $null;
        }
        }
      case "NullExp": {ESLVal $129 = _v9.termRef(0);
          
          {ESLVal v0 = $129;
          
          return $null;
        }
        }
      case "PLet": {ESLVal $128 = _v9.termRef(0);
          ESLVal $127 = _v9.termRef(1);
          ESLVal $126 = _v9.termRef(2);
          
          {ESLVal v0 = $128;
          
          {ESLVal v1 = $127;
          
          {ESLVal v2 = $126;
          
          {{
          ESLVal _v14 = v1;
          while(_v14.isCons()) {
            ESLVal b = _v14.headVal;
            walkTBind.apply(b);
            _v14 = _v14.tailVal;}
        }
        return walkAST.apply(v2);}
        }
        }
        }
        }
      case "Probably": {ESLVal $125 = _v9.termRef(0);
          ESLVal $124 = _v9.termRef(1);
          ESLVal $123 = _v9.termRef(2);
          ESLVal $122 = _v9.termRef(3);
          ESLVal $121 = _v9.termRef(4);
          
          {ESLVal v0 = $125;
          
          {ESLVal v1 = $124;
          
          {ESLVal v2 = $123;
          
          {ESLVal v3 = $122;
          
          {ESLVal v4 = $121;
          
          {walkAST.apply(v1);
        walkAST.apply(v3);
        return walkAST.apply(v4);}
        }
        }
        }
        }
        }
        }
      case "Record": {ESLVal $120 = _v9.termRef(0);
          ESLVal $119 = _v9.termRef(1);
          
          {ESLVal v0 = $120;
          
          {ESLVal v1 = $119;
          
          {{
          ESLVal _v13 = v1;
          while(_v13.isCons()) {
            ESLVal b = _v13.headVal;
            walkTBind.apply(b);
            _v13 = _v13.tailVal;}
        }
        return $null;}
        }
        }
        }
      case "RefSuper": {ESLVal $118 = _v9.termRef(0);
          ESLVal $117 = _v9.termRef(1);
          
          {ESLVal v0 = $118;
          
          {ESLVal v1 = $117;
          
          return $null;
        }
        }
        }
      case "Ref": {ESLVal $116 = _v9.termRef(0);
          ESLVal $115 = _v9.termRef(1);
          ESLVal $114 = _v9.termRef(2);
          
          {ESLVal v0 = $116;
          
          {ESLVal v1 = $115;
          
          {ESLVal v2 = $114;
          
          return walkAST.apply(v1);
        }
        }
        }
        }
      case "Self": {ESLVal $113 = _v9.termRef(0);
          
          {ESLVal v0 = $113;
          
          return $null;
        }
        }
      case "Send": {ESLVal $112 = _v9.termRef(0);
          ESLVal $111 = _v9.termRef(1);
          ESLVal $110 = _v9.termRef(2);
          
          {ESLVal v0 = $112;
          
          {ESLVal v1 = $111;
          
          {ESLVal v2 = $110;
          
          {walkAST.apply(v1);
        return walkAST.apply(v2);}
        }
        }
        }
        }
      case "SendSuper": {ESLVal $109 = _v9.termRef(0);
          ESLVal $108 = _v9.termRef(1);
          
          {ESLVal v0 = $109;
          
          {ESLVal v1 = $108;
          
          return walkAST.apply(v1);
        }
        }
        }
      case "SendTimeSuper": {ESLVal $107 = _v9.termRef(0);
          
          {ESLVal v0 = $107;
          
          return $null;
        }
        }
      case "SetExp": {ESLVal $106 = _v9.termRef(0);
          ESLVal $105 = _v9.termRef(1);
          
          {ESLVal v0 = $106;
          
          {ESLVal v1 = $105;
          
          {{
          ESLVal _v12 = v1;
          while(_v12.isCons()) {
            ESLVal e = _v12.headVal;
            walkAST.apply(e);
            _v12 = _v12.tailVal;}
        }
        return $null;}
        }
        }
        }
      case "StrExp": {ESLVal $104 = _v9.termRef(0);
          ESLVal $103 = _v9.termRef(1);
          
          {ESLVal v0 = $104;
          
          {ESLVal v1 = $103;
          
          return $null;
        }
        }
        }
      case "Tail": {ESLVal $102 = _v9.termRef(0);
          
          {ESLVal v0 = $102;
          
          return walkAST.apply(v0);
        }
        }
      case "Term": {ESLVal $101 = _v9.termRef(0);
          ESLVal $100 = _v9.termRef(1);
          ESLVal $99 = _v9.termRef(2);
          ESLVal $98 = _v9.termRef(3);
          
          {ESLVal v0 = $101;
          
          {ESLVal v1 = $100;
          
          {ESLVal v2 = $99;
          
          {ESLVal v3 = $98;
          
          {{
          ESLVal _v11 = v3;
          while(_v11.isCons()) {
            ESLVal termArg = _v11.headVal;
            walkAST.apply(termArg);
            _v11 = _v11.tailVal;}
        }
        return $null;}
        }
        }
        }
        }
        }
      case "TermRef": {ESLVal $97 = _v9.termRef(0);
          ESLVal $96 = _v9.termRef(1);
          
          {ESLVal v0 = $97;
          
          {ESLVal v1 = $96;
          
          return walkAST.apply(v0);
        }
        }
        }
      case "Throw": {ESLVal $95 = _v9.termRef(0);
          ESLVal $94 = _v9.termRef(1);
          ESLVal $93 = _v9.termRef(2);
          
          {ESLVal v0 = $95;
          
          {ESLVal v1 = $94;
          
          {ESLVal v2 = $93;
          
          return walkAST.apply(v2);
        }
        }
        }
        }
      case "Try": {ESLVal $92 = _v9.termRef(0);
          ESLVal $91 = _v9.termRef(1);
          ESLVal $90 = _v9.termRef(2);
          
          {ESLVal v0 = $92;
          
          {ESLVal v1 = $91;
          
          {ESLVal v2 = $90;
          
          {walkAST.apply(v1);
        {{
          ESLVal _v10 = v2;
          while(_v10.isCons()) {
            ESLVal a = _v10.headVal;
            walkArm.apply(a);
            _v10 = _v10.tailVal;}
        }
        return $null;}}
        }
        }
        }
        }
      case "Update": {ESLVal $89 = _v9.termRef(0);
          ESLVal $88 = _v9.termRef(1);
          ESLVal $87 = _v9.termRef(2);
          
          {ESLVal v0 = $89;
          
          {ESLVal v1 = $88;
          
          {ESLVal v2 = $87;
          
          return walkAST.apply(v2);
        }
        }
        }
        }
      case "Unfold": {ESLVal $86 = _v9.termRef(0);
          ESLVal $85 = _v9.termRef(1);
          ESLVal $84 = _v9.termRef(2);
          
          {ESLVal v0 = $86;
          
          {ESLVal v1 = $85;
          
          {ESLVal v2 = $84;
          
          return walkAST.apply(v2);
        }
        }
        }
        }
      case "Var": {ESLVal $83 = _v9.termRef(0);
          ESLVal $82 = _v9.termRef(1);
          
          {ESLVal v0 = $83;
          
          {ESLVal v1 = $82;
          
          return $null;
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(2617,6649)").add(ESLVal.list(_v9)));
      }
      }
    }
  });
public static void main(String[] args) {
  }
}