package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
// import static esl.Lists.*;
import static esl.compiler.Types.*;
import static esl.compiler.PpExp.*;
import java.util.function.Supplier;
public class Cases {
  public static ESLVal getSelf() { return $null; }
  private static ESLVal loc0 = new ESLVal("Pos",$zero,$zero);
  private static ESLVal voidType = new ESLVal("VoidType",loc0);
  private static ESLVal varCounter = $zero;
  private static ESLVal newVar = new ESLVal(new Function(new ESLVal("newVar"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      {varCounter = varCounter.add($one);
      return new ESLVal("$").add(varCounter);}
    }
  });
  private static ESLVal translateArms = new ESLVal(new Function(new ESLVal("translateArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal as = $args[0];
  {ESLVal _v2290 = as;
        
        if(_v2290.isCons())
        {ESLVal $2984 = _v2290.head();
          ESLVal $2985 = _v2290.tail();
          
          switch($2984.termName) {
          case "BArm": {ESLVal $2989 = $2984.termRef(0);
            ESLVal $2988 = $2984.termRef(1);
            ESLVal $2987 = $2984.termRef(2);
            ESLVal $2986 = $2984.termRef(3);
            
            {ESLVal l = $2989;
            
            {ESLVal ps = $2988;
            
            {ESLVal g = $2987;
            
            {ESLVal e = $2986;
            
            {ESLVal _v2356 = $2985;
            
            return translateArms.apply(_v2356).cons(new ESLVal("LArm",l,ps,$nil,g,e));
          }
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(1889,2030)").add(ESLVal.list(_v2290)));
        }
        }
      else if(_v2290.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(1889,2030)").add(ESLVal.list(_v2290)));
      }
    }
  });
  private static ESLVal newVars = new ESLVal(new Function(new ESLVal("newVars"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal n = $args[0];
  if(n.eql($zero).boolVal)
        return ESLVal.list();
        else
          return newVars.apply(n.sub($one)).cons(newVar.apply());
    }
  });
  public static ESLVal translateCases = new ESLVal(new Function(new ESLVal("translateCases"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal exp = $args[0];
  {ESLVal _v2291 = exp;
        
        switch(_v2291.termName) {
        case "Module": {ESLVal $3111 = _v2291.termRef(0);
          ESLVal $3110 = _v2291.termRef(1);
          ESLVal $3109 = _v2291.termRef(2);
          ESLVal $3108 = _v2291.termRef(3);
          ESLVal $3107 = _v2291.termRef(4);
          ESLVal $3106 = _v2291.termRef(5);
          ESLVal $3105 = _v2291.termRef(6);
          
          {ESLVal path = $3111;
          
          {ESLVal name = $3110;
          
          {ESLVal exports = $3109;
          
          {ESLVal imports = $3108;
          
          {ESLVal x = $3107;
          
          {ESLVal y = $3106;
          
          {ESLVal defs = $3105;
          
          return new ESLVal("Module",path,name,exports,imports,x,y,new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal d = $l0.head();
                $l0 = $l0.tail();
                $v.add(translateDef.apply(d));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(mergeFunDefs.apply(defs)));
        }
        }
        }
        }
        }
        }
        }
        }
      case "FunExp": {ESLVal $3104 = _v2291.termRef(0);
          ESLVal $3103 = _v2291.termRef(1);
          ESLVal $3102 = _v2291.termRef(2);
          ESLVal $3101 = _v2291.termRef(3);
          ESLVal $3100 = _v2291.termRef(4);
          
          {ESLVal l = $3104;
          
          {ESLVal n = $3103;
          
          {ESLVal args = $3102;
          
          {ESLVal t = $3101;
          
          {ESLVal e = $3100;
          
          return new ESLVal("FunExp",l,n,args,t,translateCases.apply(e));
        }
        }
        }
        }
        }
        }
      case "StrExp": {ESLVal $3099 = _v2291.termRef(0);
          ESLVal $3098 = _v2291.termRef(1);
          
          {ESLVal l = $3099;
          
          {ESLVal v = $3098;
          
          return exp;
        }
        }
        }
      case "IntExp": {ESLVal $3097 = _v2291.termRef(0);
          ESLVal $3096 = _v2291.termRef(1);
          
          {ESLVal l = $3097;
          
          {ESLVal v = $3096;
          
          return exp;
        }
        }
        }
      case "BoolExp": {ESLVal $3095 = _v2291.termRef(0);
          ESLVal $3094 = _v2291.termRef(1);
          
          {ESLVal l = $3095;
          
          {ESLVal v = $3094;
          
          return exp;
        }
        }
        }
      case "BagExp": {ESLVal $3093 = _v2291.termRef(0);
          ESLVal $3092 = _v2291.termRef(1);
          
          {ESLVal l = $3093;
          
          {ESLVal es = $3092;
          
          return new ESLVal("BagExp",l,new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal e = $l0.head();
                $l0 = $l0.tail();
                $v.add(translateCases.apply(e));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(es));
        }
        }
        }
      case "NullExp": {ESLVal $3091 = _v2291.termRef(0);
          
          {ESLVal l = $3091;
          
          return exp;
        }
        }
      case "FloatExp": {ESLVal $3090 = _v2291.termRef(0);
          ESLVal $3089 = _v2291.termRef(1);
          
          {ESLVal l = $3090;
          
          {ESLVal f = $3089;
          
          return exp;
        }
        }
        }
      case "Term": {ESLVal $3088 = _v2291.termRef(0);
          ESLVal $3087 = _v2291.termRef(1);
          ESLVal $3086 = _v2291.termRef(2);
          ESLVal $3085 = _v2291.termRef(3);
          
          {ESLVal l = $3088;
          
          {ESLVal n = $3087;
          
          {ESLVal ts = $3086;
          
          {ESLVal es = $3085;
          
          return new ESLVal("Term",l,n,ts,new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal e = $l0.head();
                $l0 = $l0.tail();
                $v.add(translateCases.apply(e));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(es));
        }
        }
        }
        }
        }
      case "List": {ESLVal $3084 = _v2291.termRef(0);
          ESLVal $3083 = _v2291.termRef(1);
          
          {ESLVal l = $3084;
          
          {ESLVal es = $3083;
          
          return new ESLVal("List",l,new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal e = $l0.head();
                $l0 = $l0.tail();
                $v.add(translateCases.apply(e));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(es));
        }
        }
        }
      case "Block": {ESLVal $3082 = _v2291.termRef(0);
          ESLVal $3081 = _v2291.termRef(1);
          
          {ESLVal l = $3082;
          
          {ESLVal es = $3081;
          
          return new ESLVal("Block",l,new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal e = $l0.head();
                $l0 = $l0.tail();
                $v.add(translateCases.apply(e));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(es));
        }
        }
        }
      case "Apply": {ESLVal $3080 = _v2291.termRef(0);
          ESLVal $3079 = _v2291.termRef(1);
          ESLVal $3078 = _v2291.termRef(2);
          
          {ESLVal l = $3080;
          
          {ESLVal op = $3079;
          
          {ESLVal args = $3078;
          
          return new ESLVal("Apply",l,translateCases.apply(op),new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal e = $l0.head();
                $l0 = $l0.tail();
                $v.add(translateCases.apply(e));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(args));
        }
        }
        }
        }
      case "ApplyTypeExp": {ESLVal $3077 = _v2291.termRef(0);
          ESLVal $3076 = _v2291.termRef(1);
          ESLVal $3075 = _v2291.termRef(2);
          
          {ESLVal l = $3077;
          
          {ESLVal op = $3076;
          
          {ESLVal args = $3075;
          
          return new ESLVal("ApplyTypeExp",l,translateCases.apply(op),args);
        }
        }
        }
        }
      case "Case": {ESLVal $3074 = _v2291.termRef(0);
          ESLVal $3073 = _v2291.termRef(1);
          ESLVal $3072 = _v2291.termRef(2);
          ESLVal $3071 = _v2291.termRef(3);
          
          {ESLVal l = $3074;
          
          {ESLVal ds = $3073;
          
          {ESLVal es = $3072;
          
          {ESLVal as = $3071;
          
          return compileCase.apply(l,es,translateArms.apply(as),new ESLVal("CaseError",l,new ESLVal("List",l,es)));
        }
        }
        }
        }
        }
      case "BinExp": {ESLVal $3070 = _v2291.termRef(0);
          ESLVal $3069 = _v2291.termRef(1);
          ESLVal $3068 = _v2291.termRef(2);
          ESLVal $3067 = _v2291.termRef(3);
          
          {ESLVal l = $3070;
          
          {ESLVal e1 = $3069;
          
          {ESLVal op = $3068;
          
          {ESLVal e2 = $3067;
          
          return new ESLVal("BinExp",l,translateCases.apply(e1),op,translateCases.apply(e2));
        }
        }
        }
        }
        }
      case "For": {ESLVal $3066 = _v2291.termRef(0);
          ESLVal $3065 = _v2291.termRef(1);
          ESLVal $3064 = _v2291.termRef(2);
          ESLVal $3063 = _v2291.termRef(3);
          
          {ESLVal l = $3066;
          
          {ESLVal p = $3065;
          
          {ESLVal e1 = $3064;
          
          {ESLVal e2 = $3063;
          
          return new ESLVal("For",l,p,translateCases.apply(e1),translateCases.apply(e2));
        }
        }
        }
        }
        }
      case "Throw": {ESLVal $3062 = _v2291.termRef(0);
          ESLVal $3061 = _v2291.termRef(1);
          ESLVal $3060 = _v2291.termRef(2);
          
          {ESLVal l = $3062;
          
          {ESLVal t = $3061;
          
          {ESLVal e = $3060;
          
          return new ESLVal("Throw",l,t,translateCases.apply(e));
        }
        }
        }
        }
      case "Try": {ESLVal $3059 = _v2291.termRef(0);
          ESLVal $3058 = _v2291.termRef(1);
          ESLVal $3057 = _v2291.termRef(2);
          
          {ESLVal l = $3059;
          
          {ESLVal e = $3058;
          
          {ESLVal as = $3057;
          
          return new ESLVal("Try",l,translateCases.apply(e),new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal a = $l0.head();
                $l0 = $l0.tail();
                $v.add(translateArm.apply(a));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(as));
        }
        }
        }
        }
      case "ActExp": {ESLVal $3056 = _v2291.termRef(0);
          ESLVal $3055 = _v2291.termRef(1);
          ESLVal $3054 = _v2291.termRef(2);
          ESLVal $3053 = _v2291.termRef(3);
          ESLVal $3052 = _v2291.termRef(4);
          ESLVal $3051 = _v2291.termRef(5);
          ESLVal $3050 = _v2291.termRef(6);
          ESLVal $3049 = _v2291.termRef(7);
          
          {ESLVal l = $3056;
          
          {ESLVal n = $3055;
          
          {ESLVal args = $3054;
          
          {ESLVal x = $3053;
          
          {ESLVal spec = $3052;
          
          {ESLVal locals = $3051;
          
          {ESLVal init = $3050;
          
          {ESLVal handlers = $3049;
          
          return new ESLVal("ActExp",l,n,args,x,spec,new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal b = $l0.head();
                $l0 = $l0.tail();
                $v.add(translateDef.apply(b));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(locals),translateCases.apply(init),new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal h = $l0.head();
                $l0 = $l0.tail();
                $v.add(translateArm.apply(h));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(handlers));
        }
        }
        }
        }
        }
        }
        }
        }
        }
      case "If": {ESLVal $3048 = _v2291.termRef(0);
          ESLVal $3047 = _v2291.termRef(1);
          ESLVal $3046 = _v2291.termRef(2);
          ESLVal $3045 = _v2291.termRef(3);
          
          {ESLVal l = $3048;
          
          {ESLVal e1 = $3047;
          
          {ESLVal e2 = $3046;
          
          {ESLVal e3 = $3045;
          
          return new ESLVal("If",l,translateCases.apply(e1),translateCases.apply(e2),translateCases.apply(e3));
        }
        }
        }
        }
        }
      case "Self": {ESLVal $3044 = _v2291.termRef(0);
          
          {ESLVal l = $3044;
          
          return exp;
        }
        }
      case "Update": {ESLVal $3043 = _v2291.termRef(0);
          ESLVal $3042 = _v2291.termRef(1);
          ESLVal $3041 = _v2291.termRef(2);
          
          {ESLVal l = $3043;
          
          {ESLVal n = $3042;
          
          {ESLVal e = $3041;
          
          return new ESLVal("Update",l,n,translateCases.apply(e));
        }
        }
        }
        }
      case "Ref": {ESLVal $3040 = _v2291.termRef(0);
          ESLVal $3039 = _v2291.termRef(1);
          ESLVal $3038 = _v2291.termRef(2);
          
          {ESLVal l = $3040;
          
          {ESLVal e = $3039;
          
          {ESLVal n = $3038;
          
          return new ESLVal("Ref",l,translateCases.apply(e),n);
        }
        }
        }
        }
      case "Var": {ESLVal $3037 = _v2291.termRef(0);
          ESLVal $3036 = _v2291.termRef(1);
          
          {ESLVal l = $3037;
          
          {ESLVal n = $3036;
          
          return exp;
        }
        }
        }
      case "Send": {ESLVal $3035 = _v2291.termRef(0);
          ESLVal $3034 = _v2291.termRef(1);
          ESLVal $3033 = _v2291.termRef(2);
          
          {ESLVal l = $3035;
          
          {ESLVal target = $3034;
          
          {ESLVal message = $3033;
          
          return new ESLVal("Send",l,translateCases.apply(target),translateCases.apply(message));
        }
        }
        }
        }
      case "SendTimeSuper": {ESLVal $3032 = _v2291.termRef(0);
          
          {ESLVal l = $3032;
          
          return new ESLVal("SendTimeSuper",l);
        }
        }
      case "SendSuper": {ESLVal $3031 = _v2291.termRef(0);
          ESLVal $3030 = _v2291.termRef(1);
          
          {ESLVal l = $3031;
          
          {ESLVal e = $3030;
          
          return new ESLVal("SendSuper",l,translateCases.apply(e));
        }
        }
        }
      case "SetExp": {ESLVal $3029 = _v2291.termRef(0);
          ESLVal $3028 = _v2291.termRef(1);
          
          {ESLVal l = $3029;
          
          {ESLVal es = $3028;
          
          return new ESLVal("SetExp",l,new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal e = $l0.head();
                $l0 = $l0.tail();
                $v.add(translateCases.apply(e));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(es));
        }
        }
        }
      case "Cmp": {ESLVal $3027 = _v2291.termRef(0);
          ESLVal $3026 = _v2291.termRef(1);
          ESLVal $3025 = _v2291.termRef(2);
          
          {ESLVal l = $3027;
          
          {ESLVal e = $3026;
          
          {ESLVal qs = $3025;
          
          return new ESLVal("Cmp",l,translateCases.apply(e),new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal q = $l0.head();
                $l0 = $l0.tail();
                $v.add(translateQual.apply(q));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(qs));
        }
        }
        }
        }
      case "New": {ESLVal $3024 = _v2291.termRef(0);
          ESLVal $3023 = _v2291.termRef(1);
          ESLVal $3022 = _v2291.termRef(2);
          
          {ESLVal l = $3024;
          
          {ESLVal b = $3023;
          
          {ESLVal args = $3022;
          
          return new ESLVal("New",l,translateCases.apply(b),new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal e = $l0.head();
                $l0 = $l0.tail();
                $v.add(translateCases.apply(e));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(args));
        }
        }
        }
        }
      case "NewJava": {ESLVal $3021 = _v2291.termRef(0);
          ESLVal $3020 = _v2291.termRef(1);
          ESLVal $3019 = _v2291.termRef(2);
          ESLVal $3018 = _v2291.termRef(3);
          
          {ESLVal l = $3021;
          
          {ESLVal className = $3020;
          
          {ESLVal t = $3019;
          
          {ESLVal args = $3018;
          
          return new ESLVal("NewJava",l,className,t,new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal e = $l0.head();
                $l0 = $l0.tail();
                $v.add(translateCases.apply(e));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(args));
        }
        }
        }
        }
        }
      case "Let": {ESLVal $3017 = _v2291.termRef(0);
          ESLVal $3016 = _v2291.termRef(1);
          ESLVal $3015 = _v2291.termRef(2);
          
          {ESLVal l = $3017;
          
          {ESLVal bs = $3016;
          
          {ESLVal e = $3015;
          
          return new ESLVal("Let",l,new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal b = $l0.head();
                $l0 = $l0.tail();
                $v.add(translateDef.apply(b));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(bs),translateCases.apply(e));
        }
        }
        }
        }
      case "Letrec": {ESLVal $3014 = _v2291.termRef(0);
          ESLVal $3013 = _v2291.termRef(1);
          ESLVal $3012 = _v2291.termRef(2);
          
          {ESLVal l = $3014;
          
          {ESLVal bs = $3013;
          
          {ESLVal e = $3012;
          
          return new ESLVal("Letrec",l,new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal b = $l0.head();
                $l0 = $l0.tail();
                $v.add(translateDef.apply(b));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(bs),translateCases.apply(e));
        }
        }
        }
        }
      case "Grab": {ESLVal $3011 = _v2291.termRef(0);
          ESLVal $3010 = _v2291.termRef(1);
          ESLVal $3009 = _v2291.termRef(2);
          
          {ESLVal l = $3011;
          
          {ESLVal rs = $3010;
          
          {ESLVal e = $3009;
          
          return new ESLVal("Grab",l,rs,translateCases.apply(e));
        }
        }
        }
        }
      case "PLet": {ESLVal $3008 = _v2291.termRef(0);
          ESLVal $3007 = _v2291.termRef(1);
          ESLVal $3006 = _v2291.termRef(2);
          
          {ESLVal l = $3008;
          
          {ESLVal bs = $3007;
          
          {ESLVal e = $3006;
          
          return new ESLVal("PLet",l,new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal b = $l0.head();
                $l0 = $l0.tail();
                $v.add(translateDef.apply(b));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(bs),translateCases.apply(e));
        }
        }
        }
        }
      case "Probably": {ESLVal $3005 = _v2291.termRef(0);
          ESLVal $3004 = _v2291.termRef(1);
          ESLVal $3003 = _v2291.termRef(2);
          ESLVal $3002 = _v2291.termRef(3);
          ESLVal $3001 = _v2291.termRef(4);
          
          {ESLVal l = $3005;
          
          {ESLVal p = $3004;
          
          {ESLVal t = $3003;
          
          {ESLVal e1 = $3002;
          
          {ESLVal e2 = $3001;
          
          return new ESLVal("Probably",l,translateCases.apply(p),t,translateCases.apply(e1),translateCases.apply(e2));
        }
        }
        }
        }
        }
        }
      case "Not": {ESLVal $3000 = _v2291.termRef(0);
          ESLVal $2999 = _v2291.termRef(1);
          
          {ESLVal l = $3000;
          
          {ESLVal e = $2999;
          
          return new ESLVal("Not",l,translateCases.apply(e));
        }
        }
        }
      case "Fold": {ESLVal $2998 = _v2291.termRef(0);
          ESLVal $2997 = _v2291.termRef(1);
          ESLVal $2996 = _v2291.termRef(2);
          
          {ESLVal l = $2998;
          
          {ESLVal t = $2997;
          
          {ESLVal e = $2996;
          
          return new ESLVal("Fold",l,t,translateCases.apply(e));
        }
        }
        }
        }
      case "Unfold": {ESLVal $2995 = _v2291.termRef(0);
          ESLVal $2994 = _v2291.termRef(1);
          ESLVal $2993 = _v2291.termRef(2);
          
          {ESLVal l = $2995;
          
          {ESLVal t = $2994;
          
          {ESLVal e = $2993;
          
          return new ESLVal("Unfold",l,t,translateCases.apply(e));
        }
        }
        }
        }
      case "Now": {ESLVal $2992 = _v2291.termRef(0);
          
          {ESLVal l = $2992;
          
          return exp;
        }
        }
      case "Become": {ESLVal $2991 = _v2291.termRef(0);
          ESLVal $2990 = _v2291.termRef(1);
          
          {ESLVal l = $2991;
          
          {ESLVal e = $2990;
          
          return new ESLVal("Become",l,translateCases.apply(e));
        }
        }
        }
        default: {ESLVal x = _v2291;
          
          return error(exp);
        }
      }
      }
    }
  });
  private static ESLVal armPatterns = new ESLVal(new Function(new ESLVal("armPatterns"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arm = $args[0];
  {ESLVal _v2292 = arm;
        
        switch(_v2292.termName) {
        case "LArm": {ESLVal $3116 = _v2292.termRef(0);
          ESLVal $3115 = _v2292.termRef(1);
          ESLVal $3114 = _v2292.termRef(2);
          ESLVal $3113 = _v2292.termRef(3);
          ESLVal $3112 = _v2292.termRef(4);
          
          {ESLVal l = $3116;
          
          {ESLVal ps = $3115;
          
          {ESLVal bs = $3114;
          
          {ESLVal g = $3113;
          
          {ESLVal e = $3112;
          
          return ps;
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(8442,8522)").add(ESLVal.list(_v2292)));
      }
      }
    }
  });
  private static ESLVal armBody = new ESLVal(new Function(new ESLVal("armBody"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arm = $args[0];
  {ESLVal _v2293 = arm;
        
        switch(_v2293.termName) {
        case "LArm": {ESLVal $3121 = _v2293.termRef(0);
          ESLVal $3120 = _v2293.termRef(1);
          ESLVal $3119 = _v2293.termRef(2);
          ESLVal $3118 = _v2293.termRef(3);
          ESLVal $3117 = _v2293.termRef(4);
          
          {ESLVal l = $3121;
          
          {ESLVal ps = $3120;
          
          {ESLVal bs = $3119;
          
          {ESLVal g = $3118;
          
          {ESLVal e = $3117;
          
          return e;
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(8551,8630)").add(ESLVal.list(_v2293)));
      }
      }
    }
  });
  private static ESLVal armGuard = new ESLVal(new Function(new ESLVal("armGuard"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arm = $args[0];
  {ESLVal _v2294 = arm;
        
        switch(_v2294.termName) {
        case "LArm": {ESLVal $3126 = _v2294.termRef(0);
          ESLVal $3125 = _v2294.termRef(1);
          ESLVal $3124 = _v2294.termRef(2);
          ESLVal $3123 = _v2294.termRef(3);
          ESLVal $3122 = _v2294.termRef(4);
          
          {ESLVal l = $3126;
          
          {ESLVal ps = $3125;
          
          {ESLVal bs = $3124;
          
          {ESLVal g = $3123;
          
          {ESLVal e = $3122;
          
          return g;
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(8660,8739)").add(ESLVal.list(_v2294)));
      }
      }
    }
  });
  private static ESLVal setArmBody = new ESLVal(new Function(new ESLVal("setArmBody"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arm = $args[0];
  ESLVal e = $args[1];
  {ESLVal _v2295 = arm;
        
        switch(_v2295.termName) {
        case "LArm": {ESLVal $3131 = _v2295.termRef(0);
          ESLVal $3130 = _v2295.termRef(1);
          ESLVal $3129 = _v2295.termRef(2);
          ESLVal $3128 = _v2295.termRef(3);
          ESLVal $3127 = _v2295.termRef(4);
          
          {ESLVal l = $3131;
          
          {ESLVal ps = $3130;
          
          {ESLVal bs = $3129;
          
          {ESLVal g = $3128;
          
          {ESLVal old = $3127;
          
          return new ESLVal("LArm",l,ps,bs,g,e);
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(8778,8875)").add(ESLVal.list(_v2295)));
      }
      }
    }
  });
  private static ESLVal setArmPatterns = new ESLVal(new Function(new ESLVal("setArmPatterns"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arm = $args[0];
  ESLVal ps = $args[1];
  {ESLVal _v2296 = arm;
        
        switch(_v2296.termName) {
        case "LArm": {ESLVal $3136 = _v2296.termRef(0);
          ESLVal $3135 = _v2296.termRef(1);
          ESLVal $3134 = _v2296.termRef(2);
          ESLVal $3133 = _v2296.termRef(3);
          ESLVal $3132 = _v2296.termRef(4);
          
          {ESLVal l = $3136;
          
          {ESLVal old = $3135;
          
          {ESLVal bs = $3134;
          
          {ESLVal g = $3133;
          
          {ESLVal e = $3132;
          
          return new ESLVal("LArm",l,ps,bs,g,e);
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(8925,9022)").add(ESLVal.list(_v2296)));
      }
      }
    }
  });
  private static ESLVal addArmBindings = new ESLVal(new Function(new ESLVal("addArmBindings"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arm = $args[0];
  ESLVal newBS = $args[1];
  {ESLVal _v2297 = arm;
        
        switch(_v2297.termName) {
        case "LArm": {ESLVal $3141 = _v2297.termRef(0);
          ESLVal $3140 = _v2297.termRef(1);
          ESLVal $3139 = _v2297.termRef(2);
          ESLVal $3138 = _v2297.termRef(3);
          ESLVal $3137 = _v2297.termRef(4);
          
          {ESLVal l = $3141;
          
          {ESLVal ps = $3140;
          
          {ESLVal bs = $3139;
          
          {ESLVal g = $3138;
          
          {ESLVal e = $3137;
          
          return new ESLVal("LArm",l,ps,bs.add(ESLVal.list(newBS)),g,e);
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(9073,9178)").add(ESLVal.list(_v2297)));
      }
      }
    }
  });
  private static ESLVal isPVar = new ESLVal(new Function(new ESLVal("isPVar"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2298 = p;
        
        switch(_v2298.termName) {
        case "PVar": {ESLVal $3144 = _v2298.termRef(0);
          ESLVal $3143 = _v2298.termRef(1);
          ESLVal $3142 = _v2298.termRef(2);
          
          {ESLVal l = $3144;
          
          {ESLVal n = $3143;
          
          {ESLVal t = $3142;
          
          return $true;
        }
        }
        }
        }
        default: {ESLVal _v2355 = _v2298;
          
          return $false;
        }
      }
      }
    }
  });
  private static ESLVal isPInt = new ESLVal(new Function(new ESLVal("isPInt"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2299 = p;
        
        switch(_v2299.termName) {
        case "PInt": {ESLVal $3146 = _v2299.termRef(0);
          ESLVal $3145 = _v2299.termRef(1);
          
          {ESLVal l = $3146;
          
          {ESLVal n = $3145;
          
          return $true;
        }
        }
        }
        default: {ESLVal _v2354 = _v2299;
          
          return $false;
        }
      }
      }
    }
  });
  private static ESLVal isPStr = new ESLVal(new Function(new ESLVal("isPStr"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2300 = p;
        
        switch(_v2300.termName) {
        case "PStr": {ESLVal $3148 = _v2300.termRef(0);
          ESLVal $3147 = _v2300.termRef(1);
          
          {ESLVal l = $3148;
          
          {ESLVal n = $3147;
          
          return $true;
        }
        }
        }
        default: {ESLVal _v2353 = _v2300;
          
          return $false;
        }
      }
      }
    }
  });
  private static ESLVal isPBool = new ESLVal(new Function(new ESLVal("isPBool"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2301 = p;
        
        switch(_v2301.termName) {
        case "PBool": {ESLVal $3150 = _v2301.termRef(0);
          ESLVal $3149 = _v2301.termRef(1);
          
          {ESLVal l = $3150;
          
          {ESLVal b = $3149;
          
          return $true;
        }
        }
        }
        default: {ESLVal _v2352 = _v2301;
          
          return $false;
        }
      }
      }
    }
  });
  private static ESLVal isPTerm = new ESLVal(new Function(new ESLVal("isPTerm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2302 = p;
        
        switch(_v2302.termName) {
        case "PTerm": {ESLVal $3154 = _v2302.termRef(0);
          ESLVal $3153 = _v2302.termRef(1);
          ESLVal $3152 = _v2302.termRef(2);
          ESLVal $3151 = _v2302.termRef(3);
          
          {ESLVal l = $3154;
          
          {ESLVal n = $3153;
          
          {ESLVal ts = $3152;
          
          {ESLVal ps = $3151;
          
          return $true;
        }
        }
        }
        }
        }
        default: {ESLVal _v2351 = _v2302;
          
          return $false;
        }
      }
      }
    }
  });
  private static ESLVal isPCons = new ESLVal(new Function(new ESLVal("isPCons"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2303 = p;
        
        switch(_v2303.termName) {
        case "PCons": {ESLVal $3157 = _v2303.termRef(0);
          ESLVal $3156 = _v2303.termRef(1);
          ESLVal $3155 = _v2303.termRef(2);
          
          {ESLVal l = $3157;
          
          {ESLVal h = $3156;
          
          {ESLVal t = $3155;
          
          return $true;
        }
        }
        }
        }
        default: {ESLVal _v2350 = _v2303;
          
          return $false;
        }
      }
      }
    }
  });
  private static ESLVal isPNil = new ESLVal(new Function(new ESLVal("isPNil"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2304 = p;
        
        switch(_v2304.termName) {
        case "PNil": {ESLVal $3162 = _v2304.termRef(0);
          
          {ESLVal l = $3162;
          
          return $true;
        }
        }
      case "PApplyType": {ESLVal $3160 = _v2304.termRef(0);
          ESLVal $3159 = _v2304.termRef(1);
          ESLVal $3158 = _v2304.termRef(2);
          
          switch($3159.termName) {
          case "PNil": {ESLVal $3161 = $3159.termRef(0);
            
            {ESLVal l1 = $3160;
            
            {ESLVal l2 = $3161;
            
            {ESLVal ts = $3158;
            
            return $true;
          }
          }
          }
          }
          default: {ESLVal _v2348 = _v2304;
            
            return $false;
          }
        }
        }
        default: {ESLVal _v2349 = _v2304;
          
          return $false;
        }
      }
      }
    }
  });
  private static ESLVal isPList = new ESLVal(new Function(new ESLVal("isPList"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  return isPCons.apply(p).or(isPNil.apply(p));
    }
  });
  private static ESLVal isPNonDetList = new ESLVal(new Function(new ESLVal("isPNonDetList"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  return isPAdd.apply(p);
    }
  });
  private static ESLVal isPSetCons = new ESLVal(new Function(new ESLVal("isPSetCons"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2305 = p;
        
        switch(_v2305.termName) {
        case "PSetCons": {ESLVal $3165 = _v2305.termRef(0);
          ESLVal $3164 = _v2305.termRef(1);
          ESLVal $3163 = _v2305.termRef(2);
          
          {ESLVal l = $3165;
          
          {ESLVal p1 = $3164;
          
          {ESLVal p2 = $3163;
          
          return $true;
        }
        }
        }
        }
        default: {ESLVal _v2347 = _v2305;
          
          return $false;
        }
      }
      }
    }
  });
  private static ESLVal isPEmptySet = new ESLVal(new Function(new ESLVal("isPEmptySet"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2306 = p;
        
        switch(_v2306.termName) {
        case "PEmptySet": {ESLVal $3166 = _v2306.termRef(0);
          
          {ESLVal l = $3166;
          
          return $true;
        }
        }
        default: {ESLVal _v2346 = _v2306;
          
          return $false;
        }
      }
      }
    }
  });
  private static ESLVal isPAdd = new ESLVal(new Function(new ESLVal("isPAdd"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2307 = p;
        
        switch(_v2307.termName) {
        case "PAdd": {ESLVal $3169 = _v2307.termRef(0);
          ESLVal $3168 = _v2307.termRef(1);
          ESLVal $3167 = _v2307.termRef(2);
          
          {ESLVal l = $3169;
          
          {ESLVal p1 = $3168;
          
          {ESLVal p2 = $3167;
          
          return $true;
        }
        }
        }
        }
        default: {ESLVal _v2345 = _v2307;
          
          return $false;
        }
      }
      }
    }
  });
  private static ESLVal isPSet = new ESLVal(new Function(new ESLVal("isPSet"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  return isPSetCons.apply(p).or(isPEmptySet.apply(p));
    }
  });
  private static ESLVal pTermName = new ESLVal(new Function(new ESLVal("pTermName"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2308 = p;
        
        switch(_v2308.termName) {
        case "PTerm": {ESLVal $3173 = _v2308.termRef(0);
          ESLVal $3172 = _v2308.termRef(1);
          ESLVal $3171 = _v2308.termRef(2);
          ESLVal $3170 = _v2308.termRef(3);
          
          {ESLVal l = $3173;
          
          {ESLVal n = $3172;
          
          {ESLVal ts = $3171;
          
          {ESLVal ps = $3170;
          
          return n;
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(10558,10626)").add(ESLVal.list(_v2308)));
      }
      }
    }
  });
  private static ESLVal pTermArgs = new ESLVal(new Function(new ESLVal("pTermArgs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2309 = p;
        
        switch(_v2309.termName) {
        case "PTerm": {ESLVal $3177 = _v2309.termRef(0);
          ESLVal $3176 = _v2309.termRef(1);
          ESLVal $3175 = _v2309.termRef(2);
          ESLVal $3174 = _v2309.termRef(3);
          
          {ESLVal l = $3177;
          
          {ESLVal n = $3176;
          
          {ESLVal ts = $3175;
          
          {ESLVal ps = $3174;
          
          return ps;
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(10666,10735)").add(ESLVal.list(_v2309)));
      }
      }
    }
  });
  private static ESLVal pVarName = new ESLVal(new Function(new ESLVal("pVarName"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2310 = p;
        
        switch(_v2310.termName) {
        case "PVar": {ESLVal $3180 = _v2310.termRef(0);
          ESLVal $3179 = _v2310.termRef(1);
          ESLVal $3178 = _v2310.termRef(2);
          
          {ESLVal l = $3180;
          
          {ESLVal n = $3179;
          
          {ESLVal t = $3178;
          
          return n;
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(10768,10818)").add(ESLVal.list(_v2310)));
      }
      }
    }
  });
  private static ESLVal pConsHead = new ESLVal(new Function(new ESLVal("pConsHead"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2311 = p;
        
        switch(_v2311.termName) {
        case "PCons": {ESLVal $3183 = _v2311.termRef(0);
          ESLVal $3182 = _v2311.termRef(1);
          ESLVal $3181 = _v2311.termRef(2);
          
          {ESLVal l = $3183;
          
          {ESLVal h = $3182;
          
          {ESLVal t = $3181;
          
          return h;
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(10856,10914)").add(ESLVal.list(_v2311)));
      }
      }
    }
  });
  private static ESLVal pConsTail = new ESLVal(new Function(new ESLVal("pConsTail"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2312 = p;
        
        switch(_v2312.termName) {
        case "PCons": {ESLVal $3186 = _v2312.termRef(0);
          ESLVal $3185 = _v2312.termRef(1);
          ESLVal $3184 = _v2312.termRef(2);
          
          {ESLVal l = $3186;
          
          {ESLVal h = $3185;
          
          {ESLVal t = $3184;
          
          return t;
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(10952,11010)").add(ESLVal.list(_v2312)));
      }
      }
    }
  });
  private static ESLVal pSetConsHead = new ESLVal(new Function(new ESLVal("pSetConsHead"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2313 = p;
        
        switch(_v2313.termName) {
        case "PSetCons": {ESLVal $3189 = _v2313.termRef(0);
          ESLVal $3188 = _v2313.termRef(1);
          ESLVal $3187 = _v2313.termRef(2);
          
          {ESLVal l = $3189;
          
          {ESLVal h = $3188;
          
          {ESLVal t = $3187;
          
          return h;
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(11051,11112)").add(ESLVal.list(_v2313)));
      }
      }
    }
  });
  private static ESLVal pSetConsTail = new ESLVal(new Function(new ESLVal("pSetConsTail"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2314 = p;
        
        switch(_v2314.termName) {
        case "PSetCons": {ESLVal $3192 = _v2314.termRef(0);
          ESLVal $3191 = _v2314.termRef(1);
          ESLVal $3190 = _v2314.termRef(2);
          
          {ESLVal l = $3192;
          
          {ESLVal h = $3191;
          
          {ESLVal t = $3190;
          
          return t;
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(11153,11214)").add(ESLVal.list(_v2314)));
      }
      }
    }
  });
  private static ESLVal pAddLeft = new ESLVal(new Function(new ESLVal("pAddLeft"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2315 = p;
        
        switch(_v2315.termName) {
        case "PAdd": {ESLVal $3195 = _v2315.termRef(0);
          ESLVal $3194 = _v2315.termRef(1);
          ESLVal $3193 = _v2315.termRef(2);
          
          {ESLVal l = $3195;
          
          {ESLVal left = $3194;
          
          {ESLVal right = $3193;
          
          return left;
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(11250,11317)").add(ESLVal.list(_v2315)));
      }
      }
    }
  });
  private static ESLVal pAddRight = new ESLVal(new Function(new ESLVal("pAddRight"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2316 = p;
        
        switch(_v2316.termName) {
        case "PAdd": {ESLVal $3198 = _v2316.termRef(0);
          ESLVal $3197 = _v2316.termRef(1);
          ESLVal $3196 = _v2316.termRef(2);
          
          {ESLVal l = $3198;
          
          {ESLVal left = $3197;
          
          {ESLVal right = $3196;
          
          return right;
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(11354,11422)").add(ESLVal.list(_v2316)));
      }
      }
    }
  });
  private static ESLVal pIntValue = new ESLVal(new Function(new ESLVal("pIntValue"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2317 = p;
        
        switch(_v2317.termName) {
        case "PInt": {ESLVal $3200 = _v2317.termRef(0);
          ESLVal $3199 = _v2317.termRef(1);
          
          {ESLVal l = $3200;
          
          {ESLVal n = $3199;
          
          return n;
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(11456,11498)").add(ESLVal.list(_v2317)));
      }
      }
    }
  });
  private static ESLVal pStrValue = new ESLVal(new Function(new ESLVal("pStrValue"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2318 = p;
        
        switch(_v2318.termName) {
        case "PStr": {ESLVal $3202 = _v2318.termRef(0);
          ESLVal $3201 = _v2318.termRef(1);
          
          {ESLVal l = $3202;
          
          {ESLVal n = $3201;
          
          return n;
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(11532,11574)").add(ESLVal.list(_v2318)));
      }
      }
    }
  });
  private static ESLVal pBoolValue = new ESLVal(new Function(new ESLVal("pBoolValue"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2319 = p;
        
        switch(_v2319.termName) {
        case "PBool": {ESLVal $3204 = _v2319.termRef(0);
          ESLVal $3203 = _v2319.termRef(1);
          
          {ESLVal l = $3204;
          
          {ESLVal b = $3203;
          
          return b;
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(11610,11655)").add(ESLVal.list(_v2319)));
      }
      }
    }
  });
  private static ESLVal isEmptyPatterns = new ESLVal(new Function(new ESLVal("isEmptyPatterns"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  return forall.apply(new ESLVal(new Function(new ESLVal("fun404"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return length.apply(armPatterns.apply(a)).eql($zero);
          }
        }),arms);
    }
  });
  private static ESLVal isFirstColumnVars = new ESLVal(new Function(new ESLVal("isFirstColumnVars"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  return forall.apply(new ESLVal(new Function(new ESLVal("fun405"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPVar.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms);
    }
  });
  private static ESLVal isFirstColumnInts = new ESLVal(new Function(new ESLVal("isFirstColumnInts"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  return forall.apply(new ESLVal(new Function(new ESLVal("fun406"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPInt.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms);
    }
  });
  private static ESLVal isFirstColumnStrs = new ESLVal(new Function(new ESLVal("isFirstColumnStrs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  return forall.apply(new ESLVal(new Function(new ESLVal("fun407"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPStr.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms);
    }
  });
  private static ESLVal isFirstColumnBools = new ESLVal(new Function(new ESLVal("isFirstColumnBools"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  return forall.apply(new ESLVal(new Function(new ESLVal("fun408"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPBool.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms);
    }
  });
  private static ESLVal isFirstColumnCnstrs = new ESLVal(new Function(new ESLVal("isFirstColumnCnstrs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  return forall.apply(new ESLVal(new Function(new ESLVal("fun409"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPTerm.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms);
    }
  });
  private static ESLVal isFirstColumnSets = new ESLVal(new Function(new ESLVal("isFirstColumnSets"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  return forall.apply(new ESLVal(new Function(new ESLVal("fun410"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPSet.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms);
    }
  });
  private static ESLVal isFirstColumnNonDetLists = new ESLVal(new Function(new ESLVal("isFirstColumnNonDetLists"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  return forall.apply(new ESLVal(new Function(new ESLVal("fun411"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPNonDetList.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms);
    }
  });
  private static ESLVal isFirstColumnLists = new ESLVal(new Function(new ESLVal("isFirstColumnLists"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  {ESLVal isList = new ESLVal(new Function(new ESLVal("isList"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal a = $args[0];
          return isPCons.apply(head.apply(armPatterns.apply(a))).or(isPNil.apply(head.apply(armPatterns.apply(a))));
            }
          });
        
        return forall.apply(isList,arms);
      }
    }
  });
  private static ESLVal dropPattern = new ESLVal(new Function(new ESLVal("dropPattern"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arm = $args[0];
  return setArmPatterns.apply(arm,tail.apply(armPatterns.apply(arm)));
    }
  });
  private static ESLVal firstVarNames = new ESLVal(new Function(new ESLVal("firstVarNames"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  return map.apply(new ESLVal(new Function(new ESLVal("fun412"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return pVarName.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms);
    }
  });
  private static ESLVal sharedCnstr = new ESLVal(new Function(new ESLVal("sharedCnstr"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  return pTermName.apply(head.apply(armPatterns.apply(head.apply(arms))));
    }
  });
  private static ESLVal sharedInt = new ESLVal(new Function(new ESLVal("sharedInt"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  return pIntValue.apply(head.apply(armPatterns.apply(head.apply(arms))));
    }
  });
  private static ESLVal sharedStr = new ESLVal(new Function(new ESLVal("sharedStr"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  return pStrValue.apply(head.apply(armPatterns.apply(head.apply(arms))));
    }
  });
  private static ESLVal sharedBool = new ESLVal(new Function(new ESLVal("sharedBool"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  return pBoolValue.apply(head.apply(armPatterns.apply(head.apply(arms))));
    }
  });
  private static ESLVal bindVarsBody = new ESLVal(new Function(new ESLVal("bindVarsBody"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  ESLVal vNames = $args[1];
  return new ESLVal(new Function(new ESLVal("fun413"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal arms = $args[0];
        { LetRec letrec = new LetRec() {
              ESLVal bind = new ESLVal(new Function(new ESLVal("bind"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal _v2339 = $args[0];
                ESLVal _v2340 = $args[1];
                {ESLVal _v2320 = _v2339;
                      ESLVal _v2321 = _v2340;
                      
                      if(_v2320.isCons())
                      {ESLVal $3205 = _v2320.head();
                        ESLVal $3206 = _v2320.tail();
                        
                        if(_v2321.isCons())
                        {ESLVal $3207 = _v2321.head();
                          ESLVal $3208 = _v2321.tail();
                          
                          {ESLVal a = $3205;
                          
                          {ESLVal _v2341 = $3206;
                          
                          {ESLVal v = $3207;
                          
                          {ESLVal _v2342 = $3208;
                          
                          {ESLVal _v2322 = e;
                          
                          switch(_v2322.termName) {
                          case "Var": {ESLVal $3212 = _v2322.termRef(0);
                            ESLVal $3211 = _v2322.termRef(1);
                            
                            {ESLVal l = $3212;
                            
                            {ESLVal n = $3211;
                            
                            if(n.eql(v).boolVal)
                            return bind.apply(_v2341,_v2342).cons(a);
                            else
                              {ESLVal _v2343 = _v2322;
                                
                                return bind.apply(_v2341,_v2342).cons(addArmBindings.apply(a,ESLVal.list(new ESLVal("Binding",loc0,v,voidType,voidType,_v2343))));
                              }
                          }
                          }
                          }
                          default: {ESLVal _v2344 = _v2322;
                            
                            return bind.apply(_v2341,_v2342).cons(addArmBindings.apply(a,ESLVal.list(new ESLVal("Binding",loc0,v,voidType,voidType,_v2344))));
                          }
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                      else if(_v2321.isNil())
                        return error(new ESLVal("case error at Pos(13825,14135)").add(ESLVal.list(_v2320,_v2321)));
                      else return error(new ESLVal("case error at Pos(13825,14135)").add(ESLVal.list(_v2320,_v2321)));
                      }
                    else if(_v2320.isNil())
                      if(_v2321.isCons())
                        {ESLVal $3209 = _v2321.head();
                          ESLVal $3210 = _v2321.tail();
                          
                          return error(new ESLVal("case error at Pos(13825,14135)").add(ESLVal.list(_v2320,_v2321)));
                        }
                      else if(_v2321.isNil())
                        return $nil;
                      else return error(new ESLVal("case error at Pos(13825,14135)").add(ESLVal.list(_v2320,_v2321)));
                    else return error(new ESLVal("case error at Pos(13825,14135)").add(ESLVal.list(_v2320,_v2321)));
                    }
                  }
                });
              
              public ESLVal get(String name) {
                switch(name) {
                  case "bind": return bind;
                  
                  default: throw new Error("cannot find letrec binding");
                }
                }
              };
            ESLVal bind = letrec.get("bind");
            
              return bind.apply(arms,vNames);}
            
          }
        });
    }
  });
  private static ESLVal bindVars = new ESLVal(new Function(new ESLVal("bindVars"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  ESLVal arms = $args[1];
  return bindVarsBody.apply(e,firstVarNames.apply(arms)).apply(map.apply(dropPattern,arms));
    }
  });
  private static ESLVal cnstrArms = new ESLVal(new Function(new ESLVal("cnstrArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal c = $args[0];
  ESLVal arms = $args[1];
  return filter.apply(new ESLVal(new Function(new ESLVal("fun414"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return pTermName.apply(head.apply(armPatterns.apply(a))).eql(c);
          }
        }),arms);
    }
  });
  private static ESLVal intArms = new ESLVal(new Function(new ESLVal("intArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal n = $args[0];
  ESLVal arms = $args[1];
  return filter.apply(new ESLVal(new Function(new ESLVal("fun415"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return pIntValue.apply(head.apply(armPatterns.apply(a))).eql(n);
          }
        }),arms);
    }
  });
  private static ESLVal strArms = new ESLVal(new Function(new ESLVal("strArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal s = $args[0];
  ESLVal arms = $args[1];
  return filter.apply(new ESLVal(new Function(new ESLVal("fun416"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return pStrValue.apply(head.apply(armPatterns.apply(a))).eql(s);
          }
        }),arms);
    }
  });
  private static ESLVal boolArms = new ESLVal(new Function(new ESLVal("boolArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal b = $args[0];
  ESLVal arms = $args[1];
  return filter.apply(new ESLVal(new Function(new ESLVal("fun417"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return pBoolValue.apply(head.apply(armPatterns.apply(a))).eql(b);
          }
        }),arms);
    }
  });
  private static ESLVal fieldBindings = new ESLVal(new Function(new ESLVal("fieldBindings"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  ESLVal names = $args[1];
  return new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal n = $l0.head();
              $l0 = $l0.tail();
              $v.add(new ESLVal("Binding",loc0,n,voidType,voidType,new ESLVal("TermRef",e,indexOf.apply(n,names))));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(names);
    }
  });
  private static ESLVal explodeCnstr = new ESLVal(new Function(new ESLVal("explodeCnstr"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal a = $args[0];
  return setArmPatterns.apply(a,pTermArgs.apply(head.apply(armPatterns.apply(a))).add(tail.apply(armPatterns.apply(a))));
    }
  });
  private static ESLVal explodeCons = new ESLVal(new Function(new ESLVal("explodeCons"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal a = $args[0];
  return setArmPatterns.apply(a,ESLVal.list(pConsHead.apply(head.apply(armPatterns.apply(a))),pConsTail.apply(head.apply(armPatterns.apply(a)))).add(tail.apply(armPatterns.apply(a))));
    }
  });
  private static ESLVal explodeSetCons = new ESLVal(new Function(new ESLVal("explodeSetCons"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal a = $args[0];
  return setArmPatterns.apply(a,ESLVal.list(pSetConsHead.apply(head.apply(armPatterns.apply(a))),pSetConsTail.apply(head.apply(armPatterns.apply(a)))).add(tail.apply(armPatterns.apply(a))));
    }
  });
  private static ESLVal explodeAdd = new ESLVal(new Function(new ESLVal("explodeAdd"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal a = $args[0];
  return setArmPatterns.apply(a,ESLVal.list(pAddLeft.apply(head.apply(armPatterns.apply(a))),pAddRight.apply(head.apply(armPatterns.apply(a)))).add(tail.apply(armPatterns.apply(a))));
    }
  });
  private static ESLVal cnstrArm = new ESLVal(new Function(new ESLVal("cnstrArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal e = $args[1];
  ESLVal es = $args[2];
  ESLVal arms = $args[3];
  ESLVal alt = $args[4];
  {ESLVal names = newVars.apply(length.apply(pTermArgs.apply(head.apply(armPatterns.apply(head.apply(arms))))));
        
        return new ESLVal("Let",loc0,fieldBindings.apply(e,names),compileCase.apply(l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal n = $l0.head();
              $l0 = $l0.tail();
              $v.add(new ESLVal("Var",loc0,n));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(names).add(es),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal a = $l0.head();
              $l0 = $l0.tail();
              $v.add(explodeCnstr.apply(a));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(arms),alt));
      }
    }
  });
  private static ESLVal processCnstrs = new ESLVal(new Function(new ESLVal("processCnstrs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  {ESLVal cnstrs = removeDups.apply(map.apply(pTermName,map.apply(head,map.apply(armPatterns,arms))));
        
        {ESLVal armss = map.apply(new ESLVal(new Function(new ESLVal("fun418"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal c = $args[0];
          return cnstrArms.apply(c,arms);
            }
          }),cnstrs);
        
        return new ESLVal("CaseTerm",l,head.apply(es),createTArms.apply(l,armss,es,alt),alt);
      }
      }
    }
  });
  private static ESLVal createTArms = new ESLVal(new Function(new ESLVal("createTArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal armss = $args[1];
  ESLVal es = $args[2];
  ESLVal alt = $args[3];
  {ESLVal _v2323 = armss;
        
        if(_v2323.isCons())
        {ESLVal $3213 = _v2323.head();
          ESLVal $3214 = _v2323.tail();
          
          {ESLVal as = $3213;
          
          {ESLVal _v2338 = $3214;
          
          return createTArms.apply(l,_v2338,es,alt).cons(new ESLVal("TArm",sharedCnstr.apply(as),cnstrArm.apply(l,head.apply(es),tail.apply(es),as,alt)));
        }
        }
        }
      else if(_v2323.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(16496,16676)").add(ESLVal.list(_v2323)));
      }
    }
  });
  private static ESLVal processConsArms = new ESLVal(new Function(new ESLVal("processConsArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal loc = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  {ESLVal l = head.apply(es);
        ESLVal hn = newVar.apply();
        ESLVal tn = newVar.apply();
        
        {ESLVal hp = new ESLVal("PVar",loc0,hn,voidType);
        ESLVal tp = new ESLVal("PVar",loc0,tn,voidType);
        ESLVal hv = new ESLVal("Var",loc0,hn);
        ESLVal tv = new ESLVal("Var",loc0,tn);
        
        return new ESLVal("Let",loc0,ESLVal.list(new ESLVal("Binding",loc0,hn,voidType,voidType,new ESLVal("Head",l)),new ESLVal("Binding",loc0,tn,voidType,voidType,new ESLVal("Tail",l))),compileCase.apply(loc,ESLVal.list(hv,tv).add(tail.apply(es)),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal a = $l0.head();
              $l0 = $l0.tail();
              $v.add(explodeCons.apply(a));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(arms),alt));
      }
      }
    }
  });
  private static ESLVal processLists = new ESLVal(new Function(new ESLVal("processLists"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  {ESLVal consArms = filter.apply(new ESLVal(new Function(new ESLVal("fun419"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal a = $args[0];
          return isPCons.apply(head.apply(armPatterns.apply(a)));
            }
          }),arms);
        ESLVal nilArms = map.apply(dropPattern,filter.apply(new ESLVal(new Function(new ESLVal("fun420"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal a = $args[0];
          return isPNil.apply(head.apply(armPatterns.apply(a)));
            }
          }),arms));
        
        return new ESLVal("CaseList",l,head.apply(es),processConsArms.apply(l,es,consArms,alt),compileCase.apply(l,tail.apply(es),nilArms,alt),alt);
      }
    }
  });
  private static ESLVal processSetArms = new ESLVal(new Function(new ESLVal("processSetArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arm = $args[2];
  {ESLVal _v2324 = head.apply(armPatterns.apply(arm));
        
        switch(_v2324.termName) {
        case "PEmptySet": {ESLVal $3221 = _v2324.termRef(0);
          
          {ESLVal pl = $3221;
          
          {ESLVal fail = newVar.apply();
          
          return new ESLVal("Term",l,new ESLVal("$empty"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("emptyset")),ESLVal.list(new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase.apply(l,es,ESLVal.list(dropPattern.apply(arm)),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
        }
        }
        }
      case "PSetCons": {ESLVal $3220 = _v2324.termRef(0);
          ESLVal $3219 = _v2324.termRef(1);
          ESLVal $3218 = _v2324.termRef(2);
          
          {ESLVal pl = $3220;
          
          {ESLVal p1 = $3219;
          
          {ESLVal p2 = $3218;
          
          {ESLVal fail = newVar.apply();
          ESLVal element = newVar.apply();
          ESLVal rest = newVar.apply();
          
          return new ESLVal("Term",l,new ESLVal("$cons"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("setcons")),ESLVal.list(new ESLVal("Dec",l,element,$null,$null),new ESLVal("Dec",l,rest,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase.apply(l,ESLVal.list(new ESLVal("Var",l,element),new ESLVal("Var",l,rest)).add(es),ESLVal.list(explodeSetCons.apply(arm)),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
        }
        }
        }
        }
        }
      case "PAdd": {ESLVal $3217 = _v2324.termRef(0);
          ESLVal $3216 = _v2324.termRef(1);
          ESLVal $3215 = _v2324.termRef(2);
          
          {ESLVal pl = $3217;
          
          {ESLVal p1 = $3216;
          
          {ESLVal p2 = $3215;
          
          {ESLVal fail = newVar.apply();
          ESLVal left = newVar.apply();
          ESLVal right = newVar.apply();
          
          return new ESLVal("Term",l,new ESLVal("$add"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("setadd")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase.apply(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,right)).add(es),ESLVal.list(explodeAdd.apply(arm)),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(17621,18742)").add(ESLVal.list(_v2324)));
      }
      }
    }
  });
  private static ESLVal processNonDetListArms = new ESLVal(new Function(new ESLVal("processNonDetListArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arm = $args[2];
  {ESLVal _v2325 = head.apply(armPatterns.apply(arm));
        
        switch(_v2325.termName) {
        case "PNil": {ESLVal $3250 = _v2325.termRef(0);
          
          {ESLVal pl = $3250;
          
          {ESLVal fail = newVar.apply();
          
          return new ESLVal("Term",l,new ESLVal("$empty"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("nil")),ESLVal.list(new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase.apply(l,es,ESLVal.list(dropPattern.apply(arm)),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
        }
        }
        }
      case "PCons": {ESLVal $3249 = _v2325.termRef(0);
          ESLVal $3248 = _v2325.termRef(1);
          ESLVal $3247 = _v2325.termRef(2);
          
          {ESLVal pl = $3249;
          
          {ESLVal p1 = $3248;
          
          {ESLVal p2 = $3247;
          
          {ESLVal fail = newVar.apply();
          ESLVal element = newVar.apply();
          ESLVal rest = newVar.apply();
          
          return new ESLVal("Term",l,new ESLVal("$cons"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("cons")),ESLVal.list(new ESLVal("Dec",l,element,$null,$null),new ESLVal("Dec",l,rest,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase.apply(l,ESLVal.list(new ESLVal("Var",l,element),new ESLVal("Var",l,rest)).add(es),ESLVal.list(explodeCons.apply(arm)),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
        }
        }
        }
        }
        }
      case "PAdd": {ESLVal $3224 = _v2325.termRef(0);
          ESLVal $3223 = _v2325.termRef(1);
          ESLVal $3222 = _v2325.termRef(2);
          
          switch($3223.termName) {
          case "PCons": {ESLVal $3245 = $3223.termRef(0);
            ESLVal $3244 = $3223.termRef(1);
            ESLVal $3243 = $3223.termRef(2);
            
            switch($3243.termName) {
            case "PNil": {ESLVal $3246 = $3243.termRef(0);
              
              {ESLVal l1 = $3224;
              
              {ESLVal l2 = $3245;
              
              {ESLVal p1 = $3244;
              
              {ESLVal l3 = $3246;
              
              {ESLVal p2 = $3222;
              
              {ESLVal fail = newVar.apply();
              ESLVal left = newVar.apply();
              ESLVal right = newVar.apply();
              ESLVal newArm = setArmPatterns.apply(arm,ESLVal.list(p1,p2).add(tail.apply(armPatterns.apply(arm))));
              
              return new ESLVal("Term",l,new ESLVal("$selectLeft"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase.apply(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
            }
            }
            }
            }
            }
            }
            }
            default: switch($3222.termName) {
              case "PCons": {ESLVal $3234 = $3222.termRef(0);
                ESLVal $3233 = $3222.termRef(1);
                ESLVal $3232 = $3222.termRef(2);
                
                switch($3232.termName) {
                case "PNil": {ESLVal $3235 = $3232.termRef(0);
                  
                  {ESLVal l1 = $3224;
                  
                  {ESLVal p1 = $3223;
                  
                  {ESLVal l2 = $3234;
                  
                  {ESLVal p2 = $3233;
                  
                  {ESLVal l3 = $3235;
                  
                  {ESLVal fail = newVar.apply();
                  ESLVal left = newVar.apply();
                  ESLVal right = newVar.apply();
                  ESLVal newArm = setArmPatterns.apply(arm,ESLVal.list(p1,p2).add(tail.apply(armPatterns.apply(arm))));
                  
                  return new ESLVal("Term",l,new ESLVal("$selectRight"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase.apply(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
                }
                }
                }
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2325)));
              }
              }
            case "PAdd": {ESLVal $3227 = $3222.termRef(0);
                ESLVal $3226 = $3222.termRef(1);
                ESLVal $3225 = $3222.termRef(2);
                
                switch($3226.termName) {
                case "PCons": {ESLVal $3230 = $3226.termRef(0);
                  ESLVal $3229 = $3226.termRef(1);
                  ESLVal $3228 = $3226.termRef(2);
                  
                  switch($3228.termName) {
                  case "PNil": {ESLVal $3231 = $3228.termRef(0);
                    
                    {ESLVal l1 = $3224;
                    
                    {ESLVal p1 = $3223;
                    
                    {ESLVal l2 = $3227;
                    
                    {ESLVal l3 = $3230;
                    
                    {ESLVal p2 = $3229;
                    
                    {ESLVal l4 = $3231;
                    
                    {ESLVal p3 = $3225;
                    
                    {ESLVal fail = newVar.apply();
                    ESLVal left = newVar.apply();
                    ESLVal mid = newVar.apply();
                    ESLVal right = newVar.apply();
                    ESLVal newArm = setArmPatterns.apply(arm,ESLVal.list(p1,p2,p3).add(tail.apply(armPatterns.apply(arm))));
                    
                    return new ESLVal("Term",l,new ESLVal("$selectMid"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,mid,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase.apply(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,mid),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2325)));
                }
                }
                default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2325)));
              }
              }
              default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2325)));
            }
          }
          }
        case "PAdd": {ESLVal $3238 = $3223.termRef(0);
            ESLVal $3237 = $3223.termRef(1);
            ESLVal $3236 = $3223.termRef(2);
            
            switch($3236.termName) {
            case "PCons": {ESLVal $3241 = $3236.termRef(0);
              ESLVal $3240 = $3236.termRef(1);
              ESLVal $3239 = $3236.termRef(2);
              
              switch($3239.termName) {
              case "PNil": {ESLVal $3242 = $3239.termRef(0);
                
                {ESLVal l1 = $3224;
                
                {ESLVal l2 = $3238;
                
                {ESLVal p1 = $3237;
                
                {ESLVal l3 = $3241;
                
                {ESLVal p2 = $3240;
                
                {ESLVal l4 = $3242;
                
                {ESLVal p3 = $3222;
                
                {ESLVal fail = newVar.apply();
                ESLVal left = newVar.apply();
                ESLVal mid = newVar.apply();
                ESLVal right = newVar.apply();
                ESLVal newArm = setArmPatterns.apply(arm,ESLVal.list(p1,p2,p3).add(armPatterns.apply(arm)));
                
                return new ESLVal("Term",l,new ESLVal("$selectMid"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,mid,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase.apply(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,mid),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
              }
              }
              }
              }
              }
              }
              }
              }
              }
              default: switch($3222.termName) {
                case "PCons": {ESLVal $3234 = $3222.termRef(0);
                  ESLVal $3233 = $3222.termRef(1);
                  ESLVal $3232 = $3222.termRef(2);
                  
                  switch($3232.termName) {
                  case "PNil": {ESLVal $3235 = $3232.termRef(0);
                    
                    {ESLVal l1 = $3224;
                    
                    {ESLVal p1 = $3223;
                    
                    {ESLVal l2 = $3234;
                    
                    {ESLVal p2 = $3233;
                    
                    {ESLVal l3 = $3235;
                    
                    {ESLVal fail = newVar.apply();
                    ESLVal left = newVar.apply();
                    ESLVal right = newVar.apply();
                    ESLVal newArm = setArmPatterns.apply(arm,ESLVal.list(p1,p2).add(tail.apply(armPatterns.apply(arm))));
                    
                    return new ESLVal("Term",l,new ESLVal("$selectRight"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase.apply(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2325)));
                }
                }
              case "PAdd": {ESLVal $3227 = $3222.termRef(0);
                  ESLVal $3226 = $3222.termRef(1);
                  ESLVal $3225 = $3222.termRef(2);
                  
                  switch($3226.termName) {
                  case "PCons": {ESLVal $3230 = $3226.termRef(0);
                    ESLVal $3229 = $3226.termRef(1);
                    ESLVal $3228 = $3226.termRef(2);
                    
                    switch($3228.termName) {
                    case "PNil": {ESLVal $3231 = $3228.termRef(0);
                      
                      {ESLVal l1 = $3224;
                      
                      {ESLVal p1 = $3223;
                      
                      {ESLVal l2 = $3227;
                      
                      {ESLVal l3 = $3230;
                      
                      {ESLVal p2 = $3229;
                      
                      {ESLVal l4 = $3231;
                      
                      {ESLVal p3 = $3225;
                      
                      {ESLVal fail = newVar.apply();
                      ESLVal left = newVar.apply();
                      ESLVal mid = newVar.apply();
                      ESLVal right = newVar.apply();
                      ESLVal newArm = setArmPatterns.apply(arm,ESLVal.list(p1,p2,p3).add(tail.apply(armPatterns.apply(arm))));
                      
                      return new ESLVal("Term",l,new ESLVal("$selectMid"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,mid,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase.apply(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,mid),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2325)));
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2325)));
                }
                }
                default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2325)));
              }
            }
            }
            default: switch($3222.termName) {
              case "PCons": {ESLVal $3234 = $3222.termRef(0);
                ESLVal $3233 = $3222.termRef(1);
                ESLVal $3232 = $3222.termRef(2);
                
                switch($3232.termName) {
                case "PNil": {ESLVal $3235 = $3232.termRef(0);
                  
                  {ESLVal l1 = $3224;
                  
                  {ESLVal p1 = $3223;
                  
                  {ESLVal l2 = $3234;
                  
                  {ESLVal p2 = $3233;
                  
                  {ESLVal l3 = $3235;
                  
                  {ESLVal fail = newVar.apply();
                  ESLVal left = newVar.apply();
                  ESLVal right = newVar.apply();
                  ESLVal newArm = setArmPatterns.apply(arm,ESLVal.list(p1,p2).add(tail.apply(armPatterns.apply(arm))));
                  
                  return new ESLVal("Term",l,new ESLVal("$selectRight"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase.apply(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
                }
                }
                }
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2325)));
              }
              }
            case "PAdd": {ESLVal $3227 = $3222.termRef(0);
                ESLVal $3226 = $3222.termRef(1);
                ESLVal $3225 = $3222.termRef(2);
                
                switch($3226.termName) {
                case "PCons": {ESLVal $3230 = $3226.termRef(0);
                  ESLVal $3229 = $3226.termRef(1);
                  ESLVal $3228 = $3226.termRef(2);
                  
                  switch($3228.termName) {
                  case "PNil": {ESLVal $3231 = $3228.termRef(0);
                    
                    {ESLVal l1 = $3224;
                    
                    {ESLVal p1 = $3223;
                    
                    {ESLVal l2 = $3227;
                    
                    {ESLVal l3 = $3230;
                    
                    {ESLVal p2 = $3229;
                    
                    {ESLVal l4 = $3231;
                    
                    {ESLVal p3 = $3225;
                    
                    {ESLVal fail = newVar.apply();
                    ESLVal left = newVar.apply();
                    ESLVal mid = newVar.apply();
                    ESLVal right = newVar.apply();
                    ESLVal newArm = setArmPatterns.apply(arm,ESLVal.list(p1,p2,p3).add(tail.apply(armPatterns.apply(arm))));
                    
                    return new ESLVal("Term",l,new ESLVal("$selectMid"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,mid,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase.apply(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,mid),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2325)));
                }
                }
                default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2325)));
              }
              }
              default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2325)));
            }
          }
          }
          default: switch($3222.termName) {
            case "PCons": {ESLVal $3234 = $3222.termRef(0);
              ESLVal $3233 = $3222.termRef(1);
              ESLVal $3232 = $3222.termRef(2);
              
              switch($3232.termName) {
              case "PNil": {ESLVal $3235 = $3232.termRef(0);
                
                {ESLVal l1 = $3224;
                
                {ESLVal p1 = $3223;
                
                {ESLVal l2 = $3234;
                
                {ESLVal p2 = $3233;
                
                {ESLVal l3 = $3235;
                
                {ESLVal fail = newVar.apply();
                ESLVal left = newVar.apply();
                ESLVal right = newVar.apply();
                ESLVal newArm = setArmPatterns.apply(arm,ESLVal.list(p1,p2).add(tail.apply(armPatterns.apply(arm))));
                
                return new ESLVal("Term",l,new ESLVal("$selectRight"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase.apply(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
              }
              }
              }
              }
              }
              }
              }
              default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2325)));
            }
            }
          case "PAdd": {ESLVal $3227 = $3222.termRef(0);
              ESLVal $3226 = $3222.termRef(1);
              ESLVal $3225 = $3222.termRef(2);
              
              switch($3226.termName) {
              case "PCons": {ESLVal $3230 = $3226.termRef(0);
                ESLVal $3229 = $3226.termRef(1);
                ESLVal $3228 = $3226.termRef(2);
                
                switch($3228.termName) {
                case "PNil": {ESLVal $3231 = $3228.termRef(0);
                  
                  {ESLVal l1 = $3224;
                  
                  {ESLVal p1 = $3223;
                  
                  {ESLVal l2 = $3227;
                  
                  {ESLVal l3 = $3230;
                  
                  {ESLVal p2 = $3229;
                  
                  {ESLVal l4 = $3231;
                  
                  {ESLVal p3 = $3225;
                  
                  {ESLVal fail = newVar.apply();
                  ESLVal left = newVar.apply();
                  ESLVal mid = newVar.apply();
                  ESLVal right = newVar.apply();
                  ESLVal newArm = setArmPatterns.apply(arm,ESLVal.list(p1,p2,p3).add(tail.apply(armPatterns.apply(arm))));
                  
                  return new ESLVal("Term",l,new ESLVal("$selectMid"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,mid,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase.apply(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,mid),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
                }
                }
                }
                }
                }
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2325)));
              }
              }
              default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2325)));
            }
            }
            default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2325)));
          }
        }
        }
        default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2325)));
      }
      }
    }
  });
  private static ESLVal processInts = new ESLVal(new Function(new ESLVal("processInts"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  {ESLVal ints = removeDups.apply(map.apply(pIntValue,map.apply(head,map.apply(armPatterns,arms))));
        
        {ESLVal armss = map.apply(new ESLVal(new Function(new ESLVal("fun421"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal c = $args[0];
          return intArms.apply(c,arms);
            }
          }),ints);
        
        return new ESLVal("CaseInt",l,head.apply(es),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal as = $l0.head();
              $l0 = $l0.tail();
              $v.add(new ESLVal("IArm",sharedInt.apply(as),compileCase.apply(l,tail.apply(es),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal a = $l0.head();
              $l0 = $l0.tail();
              $v.add(dropPattern.apply(a));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(as),alt)));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(armss),alt);
      }
      }
    }
  });
  private static ESLVal processStrs = new ESLVal(new Function(new ESLVal("processStrs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  {ESLVal strs = removeDups.apply(map.apply(pStrValue,map.apply(head,map.apply(armPatterns,arms))));
        
        {ESLVal armss = map.apply(new ESLVal(new Function(new ESLVal("fun422"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal c = $args[0];
          return strArms.apply(c,arms);
            }
          }),strs);
        
        return new ESLVal("CaseStr",l,head.apply(es),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal as = $l0.head();
              $l0 = $l0.tail();
              $v.add(new ESLVal("SArm",sharedStr.apply(as),compileCase.apply(l,tail.apply(es),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal a = $l0.head();
              $l0 = $l0.tail();
              $v.add(dropPattern.apply(a));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(as),alt)));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(armss),alt);
      }
      }
    }
  });
  private static ESLVal processBools = new ESLVal(new Function(new ESLVal("processBools"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  {ESLVal bools = removeDups.apply(map.apply(pBoolValue,map.apply(head,map.apply(armPatterns,arms))));
        
        {ESLVal armss = map.apply(new ESLVal(new Function(new ESLVal("fun423"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal c = $args[0];
          return boolArms.apply(c,arms);
            }
          }),bools);
        
        return new ESLVal("CaseBool",l,head.apply(es),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal as = $l0.head();
              $l0 = $l0.tail();
              $v.add(new ESLVal("BoolArm",sharedBool.apply(as),compileCase.apply(l,tail.apply(es),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal a = $l0.head();
              $l0 = $l0.tail();
              $v.add(dropPattern.apply(a));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(as),alt)));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(armss),alt);
      }
      }
    }
  });
  private static ESLVal processSets = new ESLVal(new Function(new ESLVal("processSets"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  {ESLVal f = new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("setFail")),ESLVal.list(),$null,alt);
        
        return new ESLVal("CaseSet",l,head.apply(es),new ESLVal("List",l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal a = $l0.head();
              $l0 = $l0.tail();
              $v.add(processSetArms.apply(l,tail.apply(es),a));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(arms)),f);
      }
    }
  });
  private static ESLVal processNonDetLists = new ESLVal(new Function(new ESLVal("processNonDetLists"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  {print.apply(new ESLVal("process nondet lists ").add(es.add(new ESLVal(" ").add(arms))));
      {ESLVal f = new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("listFail")),ESLVal.list(),$null,alt);
        
        return new ESLVal("CaseAdd",l,head.apply(es),new ESLVal("List",l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal a = $l0.head();
              $l0 = $l0.tail();
              $v.add(processNonDetListArms.apply(l,tail.apply(es),a));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(arms)),f);
      }}
    }
  });
  private static ESLVal splitTerms = new ESLVal(new Function(new ESLVal("splitTerms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  return compileCase.apply(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun424"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPTerm.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),compileCase.apply(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun425"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPTerm.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),alt));
    }
  });
  private static ESLVal splitLists = new ESLVal(new Function(new ESLVal("splitLists"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  return compileCase.apply(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun426"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPList.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),compileCase.apply(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun427"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPList.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),alt));
    }
  });
  private static ESLVal splitAdd = new ESLVal(new Function(new ESLVal("splitAdd"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  return compileCase.apply(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun428"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPAdd.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),compileCase.apply(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun429"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPAdd.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),alt));
    }
  });
  private static ESLVal splitSets = new ESLVal(new Function(new ESLVal("splitSets"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  return compileCase.apply(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun430"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPSet.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),compileCase.apply(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun431"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPSet.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),alt));
    }
  });
  private static ESLVal splitInts = new ESLVal(new Function(new ESLVal("splitInts"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  return compileCase.apply(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun432"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPInt.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),compileCase.apply(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun433"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPInt.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),alt));
    }
  });
  private static ESLVal splitStrs = new ESLVal(new Function(new ESLVal("splitStrs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  return compileCase.apply(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun434"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPStr.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),compileCase.apply(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun435"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPStr.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),alt));
    }
  });
  private static ESLVal splitBools = new ESLVal(new Function(new ESLVal("splitBools"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  return compileCase.apply(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun436"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPBool.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),compileCase.apply(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun437"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPBool.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),alt));
    }
  });
  private static ESLVal splitVars = new ESLVal(new Function(new ESLVal("splitVars"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  return compileCase.apply(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun438"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPVar.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),compileCase.apply(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun439"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPVar.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),alt));
    }
  });
  private static ESLVal splitCase = new ESLVal(new Function(new ESLVal("splitCase"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  {ESLVal firstPatterns = map.apply(head,map.apply(armPatterns,arms));
        
        {ESLVal nonVarPatterns = filter.apply(new ESLVal(new Function(new ESLVal("fun440"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal p = $args[0];
          return isPVar.apply(p).not();
            }
          }),firstPatterns);
        
        if(isPTerm.apply(head.apply(nonVarPatterns)).boolVal)
        return splitTerms.apply(l,es,arms,alt);
        else
          if(isPList.apply(head.apply(nonVarPatterns)).boolVal)
            return splitLists.apply(l,es,arms,alt);
            else
              if(isPSet.apply(head.apply(nonVarPatterns)).boolVal)
                return splitSets.apply(l,es,arms,alt);
                else
                  if(isPInt.apply(head.apply(nonVarPatterns)).boolVal)
                    return splitInts.apply(l,es,arms,alt);
                    else
                      if(isPStr.apply(head.apply(nonVarPatterns)).boolVal)
                        return splitStrs.apply(l,es,arms,alt);
                        else
                          if(isPBool.apply(head.apply(nonVarPatterns)).boolVal)
                            return splitBools.apply(l,es,arms,alt);
                            else
                              if(isPVar.apply(head.apply(firstPatterns)).boolVal)
                                return splitVars.apply(l,es,arms,alt);
                                else
                                  if(isPAdd.apply(head.apply(firstPatterns)).boolVal)
                                    return splitAdd.apply(l,es,arms,alt);
                                    else
                                      return error(new ESLVal("unknown split case: ").add(arms));
      }
      }
    }
  });
  private static ESLVal compileCase = new ESLVal(new Function(new ESLVal("compileCase"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  if(arms.eql($nil).boolVal)
        return alt;
        else
          if(isEmptyPatterns.apply(arms).boolVal)
            return foldArms.apply(l,arms,alt);
            else
              if(isFirstColumnVars.apply(arms).boolVal)
                return compileCase.apply(l,tail.apply(es),bindVars.apply(head.apply(es),arms),alt);
                else
                  if(isFirstColumnCnstrs.apply(arms).boolVal)
                    return processCnstrs.apply(l,es,arms,alt);
                    else
                      if(isFirstColumnLists.apply(arms).boolVal)
                        return processLists.apply(l,es,arms,alt);
                        else
                          if(isFirstColumnInts.apply(arms).boolVal)
                            return processInts.apply(l,es,arms,alt);
                            else
                              if(isFirstColumnBools.apply(arms).boolVal)
                                return processBools.apply(l,es,arms,alt);
                                else
                                  if(isFirstColumnStrs.apply(arms).boolVal)
                                    return processStrs.apply(l,es,arms,alt);
                                    else
                                      if(isFirstColumnSets.apply(arms).boolVal)
                                        return processSets.apply(l,es,arms,alt);
                                        else
                                          if(isFirstColumnNonDetLists.apply(arms).boolVal)
                                            return processNonDetLists.apply(l,es,arms,alt);
                                            else
                                              return splitCase.apply(l,es,arms,alt);
    }
  });
  private static ESLVal foldArms = new ESLVal(new Function(new ESLVal("foldArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal arms = $args[1];
  ESLVal alt = $args[2];
  {ESLVal _v2326 = arms;
        
        if(_v2326.isCons())
        {ESLVal $3251 = _v2326.head();
          ESLVal $3252 = _v2326.tail();
          
          switch($3251.termName) {
          case "LArm": {ESLVal $3257 = $3251.termRef(0);
            ESLVal $3256 = $3251.termRef(1);
            ESLVal $3255 = $3251.termRef(2);
            ESLVal $3254 = $3251.termRef(3);
            ESLVal $3253 = $3251.termRef(4);
            
            if($3256.isCons())
            {ESLVal $3258 = $3256.head();
              ESLVal $3259 = $3256.tail();
              
              return error(new ESLVal("case error at Pos(27421,27577)").add(ESLVal.list(_v2326)));
            }
          else if($3256.isNil())
            {ESLVal al = $3257;
              
              {ESLVal bs = $3255;
              
              {ESLVal g = $3254;
              
              {ESLVal e = $3253;
              
              {ESLVal _v2337 = $3252;
              
              return foldArm.apply(al,bs,g,e,foldArms.apply(l,_v2337,alt));
            }
            }
            }
            }
            }
          else return error(new ESLVal("case error at Pos(27421,27577)").add(ESLVal.list(_v2326)));
          }
          default: return error(new ESLVal("case error at Pos(27421,27577)").add(ESLVal.list(_v2326)));
        }
        }
      else if(_v2326.isNil())
        return alt;
      else return error(new ESLVal("case error at Pos(27421,27577)").add(ESLVal.list(_v2326)));
      }
    }
  });
  private static ESLVal foldArm = new ESLVal(new Function(new ESLVal("foldArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal bss = $args[1];
  ESLVal g = $args[2];
  ESLVal e = $args[3];
  ESLVal alt = $args[4];
  {ESLVal _v2327 = bss;
        
        if(_v2327.isCons())
        {ESLVal $3260 = _v2327.head();
          ESLVal $3261 = _v2327.tail();
          
          {ESLVal bs = $3260;
          
          {ESLVal _v2334 = $3261;
          
          return new ESLVal("Let",l,bs,foldArm.apply(l,_v2334,g,e,alt));
        }
        }
        }
      else if(_v2327.isNil())
        {ESLVal _v2328 = g;
          
          switch(_v2328.termName) {
          case "BoolExp": {ESLVal $3263 = _v2328.termRef(0);
            ESLVal $3262 = _v2328.termRef(1);
            
            switch($3262.boolVal ? 1 : 0) {
            case 1: {ESLVal bl = $3263;
              
              return e;
            }
            default: {ESLVal _v2335 = _v2328;
              
              return new ESLVal("If",l,_v2335,e,alt);
            }
          }
          }
          default: {ESLVal _v2336 = _v2328;
            
            return new ESLVal("If",l,_v2336,e,alt);
          }
        }
        }
      else return error(new ESLVal("case error at Pos(27642,27842)").add(ESLVal.list(_v2327)));
      }
    }
  });
  private static ESLVal translateQual = new ESLVal(new Function(new ESLVal("translateQual"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal q = $args[0];
  {ESLVal _v2329 = q;
        
        switch(_v2329.termName) {
        case "BQual": {ESLVal $3268 = _v2329.termRef(0);
          ESLVal $3267 = _v2329.termRef(1);
          ESLVal $3266 = _v2329.termRef(2);
          
          {ESLVal l = $3268;
          
          {ESLVal p = $3267;
          
          {ESLVal e = $3266;
          
          return new ESLVal("BQual",l,p,translateCases.apply(e));
        }
        }
        }
        }
      case "PQual": {ESLVal $3265 = _v2329.termRef(0);
          ESLVal $3264 = _v2329.termRef(1);
          
          {ESLVal l = $3265;
          
          {ESLVal p = $3264;
          
          return new ESLVal("PQual",l,translateCases.apply(p));
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(27894,28031)").add(ESLVal.list(_v2329)));
      }
      }
    }
  });
  private static ESLVal translateArm = new ESLVal(new Function(new ESLVal("translateArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal a = $args[0];
  {ESLVal _v2330 = a;
        
        switch(_v2330.termName) {
        case "LArm": {ESLVal $3273 = _v2330.termRef(0);
          ESLVal $3272 = _v2330.termRef(1);
          ESLVal $3271 = _v2330.termRef(2);
          ESLVal $3270 = _v2330.termRef(3);
          ESLVal $3269 = _v2330.termRef(4);
          
          {ESLVal l = $3273;
          
          {ESLVal ps = $3272;
          
          {ESLVal bs = $3271;
          
          {ESLVal guard = $3270;
          
          {ESLVal e = $3269;
          
          return new ESLVal("LArm",l,ps,bs,translateCases.apply(guard),translateCases.apply(e));
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(28070,28203)").add(ESLVal.list(_v2330)));
      }
      }
    }
  });
  private static ESLVal translateDef = new ESLVal(new Function(new ESLVal("translateDef"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal b = $args[0];
  {ESLVal _v2331 = b;
        
        switch(_v2331.termName) {
        case "Binding": {ESLVal $3297 = _v2331.termRef(0);
          ESLVal $3296 = _v2331.termRef(1);
          ESLVal $3295 = _v2331.termRef(2);
          ESLVal $3294 = _v2331.termRef(3);
          ESLVal $3293 = _v2331.termRef(4);
          
          {ESLVal l = $3297;
          
          {ESLVal name = $3296;
          
          {ESLVal t = $3295;
          
          {ESLVal st = $3294;
          
          {ESLVal value = $3293;
          
          return new ESLVal("Binding",l,name,t,st,translateCases.apply(value));
        }
        }
        }
        }
        }
        }
      case "TypeBind": {ESLVal $3292 = _v2331.termRef(0);
          ESLVal $3291 = _v2331.termRef(1);
          ESLVal $3290 = _v2331.termRef(2);
          ESLVal $3289 = _v2331.termRef(3);
          
          {ESLVal l = $3292;
          
          {ESLVal name = $3291;
          
          {ESLVal t = $3290;
          
          {ESLVal ignore = $3289;
          
          return b;
        }
        }
        }
        }
        }
      case "DataBind": {ESLVal $3288 = _v2331.termRef(0);
          ESLVal $3287 = _v2331.termRef(1);
          ESLVal $3286 = _v2331.termRef(2);
          ESLVal $3285 = _v2331.termRef(3);
          
          {ESLVal l = $3288;
          
          {ESLVal name = $3287;
          
          {ESLVal t = $3286;
          
          {ESLVal ignore = $3285;
          
          return b;
        }
        }
        }
        }
        }
      case "FunBind": {ESLVal $3284 = _v2331.termRef(0);
          ESLVal $3283 = _v2331.termRef(1);
          ESLVal $3282 = _v2331.termRef(2);
          ESLVal $3281 = _v2331.termRef(3);
          ESLVal $3280 = _v2331.termRef(4);
          ESLVal $3279 = _v2331.termRef(5);
          ESLVal $3278 = _v2331.termRef(6);
          
          {ESLVal l = $3284;
          
          {ESLVal n = $3283;
          
          {ESLVal args = $3282;
          
          {ESLVal t = $3281;
          
          {ESLVal st = $3280;
          
          {ESLVal body = $3279;
          
          {ESLVal guard = $3278;
          
          return new ESLVal("FunBind",l,n,args,t,st,translateCases.apply(body),translateCases.apply(guard));
        }
        }
        }
        }
        }
        }
        }
        }
      case "CnstrBind": {ESLVal $3277 = _v2331.termRef(0);
          ESLVal $3276 = _v2331.termRef(1);
          ESLVal $3275 = _v2331.termRef(2);
          ESLVal $3274 = _v2331.termRef(3);
          
          {ESLVal l = $3277;
          
          {ESLVal name = $3276;
          
          {ESLVal t = $3275;
          
          {ESLVal ignore = $3274;
          
          return b;
        }
        }
        }
        }
        }
        default: {ESLVal x = _v2331;
          
          return error(x);
        }
      }
      }
    }
  });
  private static ESLVal pterm = new ESLVal(new Function(new ESLVal("pterm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal n = $args[0];
  ESLVal ps = $args[1];
  return new ESLVal("PTerm",loc0,n,$nil,ps);
    }
  });
  private static ESLVal pvar = new ESLVal(new Function(new ESLVal("pvar"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal n = $args[0];
  return new ESLVal("PVar",loc0,n,voidType);
    }
  });
  private static ESLVal var = new ESLVal(new Function(new ESLVal("var"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal n = $args[0];
  return new ESLVal("Var",loc0,n);
    }
  });
  private static ESLVal pcons = new ESLVal(new Function(new ESLVal("pcons"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal h = $args[0];
  ESLVal t = $args[1];
  return new ESLVal("PCons",loc0,h,t);
    }
  });
  private static ESLVal case0 = new ESLVal("Case",new ESLVal("Pos",$zero,$zero),$nil,ESLVal.list(new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("x")),new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("y"))),ESLVal.list(new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PVar",loc0,new ESLVal("xx"),voidType),new ESLVal("PVar",loc0,new ESLVal("yy"),voidType)),new ESLVal("BoolExp",loc0,$true),new ESLVal("Var",loc0,new ESLVal("OK")))));
  private static ESLVal case1 = new ESLVal("Case",new ESLVal("Pos",$zero,$zero),$nil,ESLVal.list(new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("x")),new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("y"))),ESLVal.list(new ESLVal("BArm",loc0,ESLVal.list(pterm.apply(new ESLVal("A"),ESLVal.list(pterm.apply(new ESLVal("B"),ESLVal.list(pvar.apply(new ESLVal("v0")))),pvar.apply(new ESLVal("v1")),pvar.apply(new ESLVal("v2")))),pterm.apply(new ESLVal("C"),ESLVal.list())),new ESLVal("BoolExp",loc0,$true),new ESLVal("Var",loc0,new ESLVal("OK1"))),new ESLVal("BArm",loc0,ESLVal.list(pvar.apply(new ESLVal("v0")),pterm.apply(new ESLVal("C"),ESLVal.list())),new ESLVal("BoolExp",loc0,$true),new ESLVal("Var",loc0,new ESLVal("OK2")))));
  private static ESLVal case2 = new ESLVal("Case",loc0,$nil,ESLVal.list(var.apply(new ESLVal("l"))),ESLVal.list(new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PNil",loc0)),var.apply(new ESLVal("g1")),var.apply(new ESLVal("M1"))),new ESLVal("BArm",loc0,ESLVal.list(pcons.apply(pterm.apply(new ESLVal("One"),ESLVal.list()),pvar.apply(new ESLVal("rest1")))),var.apply(new ESLVal("g1")),var.apply(new ESLVal("M1"))),new ESLVal("BArm",loc0,ESLVal.list(pcons.apply(pterm.apply(new ESLVal("Succ"),ESLVal.list(pterm.apply(new ESLVal("One"),ESLVal.list()))),pvar.apply(new ESLVal("rest2")))),var.apply(new ESLVal("g2")),var.apply(new ESLVal("M2"))),new ESLVal("BArm",loc0,ESLVal.list(pcons.apply(pterm.apply(new ESLVal("Infinity"),ESLVal.list()),new ESLVal("PNil",loc0))),var.apply(new ESLVal("g3")),var.apply(new ESLVal("M3")))));
  private static ESLVal case3 = new ESLVal("Case",loc0,$nil,ESLVal.list(var.apply(new ESLVal("x")),var.apply(new ESLVal("y"))),ESLVal.list(new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PInt",loc0,$zero),new ESLVal("PInt",loc0,$one)),var.apply(new ESLVal("g1")),var.apply(new ESLVal("M1"))),new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PInt",loc0,$one),new ESLVal("PInt",loc0,$zero)),var.apply(new ESLVal("g2")),var.apply(new ESLVal("M2"))),new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PInt",loc0,$zero),pvar.apply(new ESLVal("x"))),var.apply(new ESLVal("g3")),var.apply(new ESLVal("M3"))),new ESLVal("BArm",loc0,ESLVal.list(pvar.apply(new ESLVal("x")),new ESLVal("PInt",loc0,$one)),var.apply(new ESLVal("g4")),var.apply(new ESLVal("M4")))));
  private static ESLVal case4 = new ESLVal("Case",loc0,$nil,ESLVal.list(var.apply(new ESLVal("x")),var.apply(new ESLVal("y"))),ESLVal.list(new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PStr",loc0,new ESLVal("one")),new ESLVal("PInt",loc0,$one)),var.apply(new ESLVal("g1")),var.apply(new ESLVal("M1"))),new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PStr",loc0,new ESLVal("one")),new ESLVal("PInt",loc0,$zero)),var.apply(new ESLVal("g2")),var.apply(new ESLVal("M2"))),new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PStr",loc0,new ESLVal("two")),pvar.apply(new ESLVal("x"))),var.apply(new ESLVal("g3")),var.apply(new ESLVal("M3"))),new ESLVal("BArm",loc0,ESLVal.list(pvar.apply(new ESLVal("x")),new ESLVal("PInt",loc0,$one)),var.apply(new ESLVal("g4")),var.apply(new ESLVal("M4")))));
  private static ESLVal case5 = new ESLVal("Case",loc0,$nil,ESLVal.list(var.apply(new ESLVal("x")),var.apply(new ESLVal("y"))),ESLVal.list(new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PStr",loc0,new ESLVal("one")),new ESLVal("PInt",loc0,$one)),var.apply(new ESLVal("g1")),var.apply(new ESLVal("M1"))),new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PStr",loc0,new ESLVal("one")),new ESLVal("PInt",loc0,$zero)),var.apply(new ESLVal("g2")),var.apply(new ESLVal("M2"))),new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PStr",loc0,new ESLVal("two")),pvar.apply(new ESLVal("x"))),var.apply(new ESLVal("g3")),var.apply(new ESLVal("M3"))),new ESLVal("BArm",loc0,ESLVal.list(pvar.apply(new ESLVal("x")),new ESLVal("PInt",loc0,$one)),var.apply(new ESLVal("g4")),var.apply(new ESLVal("M4"))),new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PBool",loc0,$true),new ESLVal("PInt",loc0,$one)),var.apply(new ESLVal("g4")),var.apply(new ESLVal("M4")))));
  private static ESLVal case6 = new ESLVal("Case",loc0,$nil,ESLVal.list(var.apply(new ESLVal("x"))),ESLVal.list(new ESLVal("BArm",loc0,ESLVal.list(pterm.apply(new ESLVal("A"),ESLVal.list(new ESLVal("PInt",loc0,$one)))),var.apply(new ESLVal("g1")),var.apply(new ESLVal("M1")))));
  public static ESLVal main = new ESLVal(new Function(new ESLVal("main"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      return new ESLVal(new BehaviourAdapter(true,getSelf(),new ESLVal("main")) {
          
          public ESLVal handle(ESLVal $m) {{ESLVal _v2333 = $m;
            
            return error(new ESLVal("case error at Pos(0,0)").add(ESLVal.list(_v2333)));
          }}
          public ESLVal get(String name) {
            switch(name) {
              
              default: throw new Error("ref illegal " + self + "." + name);
            }
          }
        public void handleTime(ESLVal $t) {
          {ESLVal n = $t;
            
            if($true.boolVal)
            {new Function(new ESLVal("try"),getSelf()) {
              public ESLVal apply(ESLVal... args) { 
                try { 
                  return ((Supplier<ESLVal>)() -> { 
                  {print.apply(ppExp.apply($zero,translateCases.apply(case0)));
                  print.apply(ppExp.apply($zero,translateCases.apply(case1)));
                  print.apply(ppExp.apply($zero,translateCases.apply(case2)));
                  print.apply(ppExp.apply($zero,translateCases.apply(case3)));
                  print.apply(ppExp.apply($zero,translateCases.apply(case4)));
                  print.apply(ppExp.apply($zero,translateCases.apply(case5)));
                  return print.apply(ppExp.apply($zero,translateCases.apply(case6)));}
                }).get();
                } catch(ESLError $exception) {
                  ESLVal $x = $exception.value;
                  {ESLVal _v2332 = $x;
              
              {ESLVal x = _v2332;
              
              return print.apply(x);
            }
            }
                }
              }
            }.apply();
            stopAll.apply();}
            else
              {}
          }
        }
        public ESLVal init() {
            return $null;
          }
        });
    }
  });
public static void main(String[] args) {
    newActor(main,new ESLVal(new Actor())); 
  }
}