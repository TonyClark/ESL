package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
import static esl.Tables.*;
// import static esl.Lists.*;
import static esl.compiler.Cases.*;
import static esl.compiler.Types.*;
import java.util.function.Supplier;
public class ToJava {
  public static ESLVal getSelf() { return $null; }
  private static ESLVal defToField = new ESLVal(new Function(new ESLVal("defToField"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d = $args[0];
  {ESLVal _v68 = d;
        
        switch(_v68.termName) {
        case "Binding": {ESLVal $522 = _v68.termRef(0);
          ESLVal $521 = _v68.termRef(1);
          ESLVal $520 = _v68.termRef(2);
          ESLVal $519 = _v68.termRef(3);
          ESLVal $518 = _v68.termRef(4);
          
          {ESLVal l = $522;
          
          {ESLVal n = $521;
          
          {ESLVal t = $520;
          
          {ESLVal st = $519;
          
          {ESLVal e = $518;
          
          return new ESLVal("JField",n,$null,expToJExp.apply(e));
        }
        }
        }
        }
        }
        }
      case "FunBind": {ESLVal $515 = _v68.termRef(0);
          ESLVal $514 = _v68.termRef(1);
          ESLVal $513 = _v68.termRef(2);
          ESLVal $512 = _v68.termRef(3);
          ESLVal $511 = _v68.termRef(4);
          ESLVal $510 = _v68.termRef(5);
          ESLVal $509 = _v68.termRef(6);
          
          switch($509.termName) {
          case "BoolExp": {ESLVal $517 = $509.termRef(0);
            ESLVal $516 = $509.termRef(1);
            
            switch($516.boolVal ? 1 : 0) {
            case 1: {ESLVal l = $515;
              
              {ESLVal n = $514;
              
              {ESLVal args = $513;
              
              {ESLVal t = $512;
              
              {ESLVal st = $511;
              
              {ESLVal e = $510;
              
              {ESLVal bl = $517;
              
              {ESLVal formals = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal $qualArg = $args[0];
                {ESLVal _v69 = $qualArg;
                      
                      switch(_v69.termName) {
                      case "PVar": {ESLVal $525 = _v69.termRef(0);
                        ESLVal $524 = _v69.termRef(1);
                        ESLVal $523 = _v69.termRef(2);
                        
                        {ESLVal _v149 = $525;
                        
                        {ESLVal _v150 = $524;
                        
                        {ESLVal _v151 = $523;
                        
                        return ESLVal.list(ESLVal.list(new ESLVal("Dec",_v149,_v150,_v151,st)));
                      }
                      }
                      }
                      }
                      default: {ESLVal _0 = _v69;
                        
                        return ESLVal.list();
                      }
                    }
                    }
                  }
                }).map(args).flatten().flatten();
              
              return new ESLVal("JField",n,$null,expToJExp.apply(new ESLVal("FunExp",l,new ESLVal("StrExp",l,n),formals,t,e)));
            }
            }
            }
            }
            }
            }
            }
            }
            default: {ESLVal l = $515;
              
              {ESLVal n = $514;
              
              {ESLVal args = $513;
              
              {ESLVal t = $512;
              
              {ESLVal st = $511;
              
              {ESLVal e = $510;
              
              {ESLVal g = $509;
              
              {ESLVal formals = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal $qualArg = $args[0];
                {ESLVal _v70 = $qualArg;
                      
                      switch(_v70.termName) {
                      case "PVar": {ESLVal $528 = _v70.termRef(0);
                        ESLVal $527 = _v70.termRef(1);
                        ESLVal $526 = _v70.termRef(2);
                        
                        {ESLVal _v152 = $528;
                        
                        {ESLVal _v153 = $527;
                        
                        {ESLVal _v154 = $526;
                        
                        return ESLVal.list(ESLVal.list(new ESLVal("Dec",_v152,_v153,_v154,st)));
                      }
                      }
                      }
                      }
                      default: {ESLVal _0 = _v70;
                        
                        return ESLVal.list();
                      }
                    }
                    }
                  }
                }).map(args).flatten().flatten();
              
              return new ESLVal("JField",n,$null,expToJExp.apply(new ESLVal("FunExp",l,new ESLVal("StrExp",l,n),formals,t,new ESLVal("If",l,g,e,new ESLVal("Throw",l,t,new ESLVal("StrExp",l,new ESLVal("guard failed for ").add(n)))))));
            }
            }
            }
            }
            }
            }
            }
            }
          }
          }
          default: {ESLVal l = $515;
            
            {ESLVal n = $514;
            
            {ESLVal args = $513;
            
            {ESLVal t = $512;
            
            {ESLVal st = $511;
            
            {ESLVal e = $510;
            
            {ESLVal g = $509;
            
            {ESLVal formals = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v71 = $qualArg;
                    
                    switch(_v71.termName) {
                    case "PVar": {ESLVal $531 = _v71.termRef(0);
                      ESLVal $530 = _v71.termRef(1);
                      ESLVal $529 = _v71.termRef(2);
                      
                      {ESLVal _v155 = $531;
                      
                      {ESLVal _v156 = $530;
                      
                      {ESLVal _v157 = $529;
                      
                      return ESLVal.list(ESLVal.list(new ESLVal("Dec",_v155,_v156,_v157,st)));
                    }
                    }
                    }
                    }
                    default: {ESLVal _0 = _v71;
                      
                      return ESLVal.list();
                    }
                  }
                  }
                }
              }).map(args).flatten().flatten();
            
            return new ESLVal("JField",n,$null,expToJExp.apply(new ESLVal("FunExp",l,new ESLVal("StrExp",l,n),formals,t,new ESLVal("If",l,g,e,new ESLVal("Throw",l,t,new ESLVal("StrExp",l,new ESLVal("guard failed for ").add(n)))))));
          }
          }
          }
          }
          }
          }
          }
          }
        }
        }
        default: return error(new ESLVal("case error at Pos(172,825)").add(ESLVal.list(_v68)));
      }
      }
    }
  });
  private static ESLVal decToJDec = new ESLVal(new Function(new ESLVal("decToJDec"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d = $args[0];
  {ESLVal _v67 = d;
        
        switch(_v67.termName) {
        case "Dec": {ESLVal $508 = _v67.termRef(0);
          ESLVal $507 = _v67.termRef(1);
          ESLVal $506 = _v67.termRef(2);
          ESLVal $505 = _v67.termRef(3);
          
          {ESLVal l = $508;
          
          {ESLVal n = $507;
          
          {ESLVal t = $506;
          
          {ESLVal st = $505;
          
          return new ESLVal("JDec",n,$null);
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(869,945)").add(ESLVal.list(_v67)));
      }
      }
    }
  });
  private static ESLVal expsToJCommands = new ESLVal(new Function(new ESLVal("expsToJCommands"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal cs = $args[0];
  ESLVal isLast = $args[1];
  {ESLVal _v66 = cs;
        
        if(_v66.isCons())
        {ESLVal $501 = _v66.head();
          ESLVal $502 = _v66.tail();
          
          if($502.isCons())
          {ESLVal $503 = $502.head();
            ESLVal $504 = $502.tail();
            
            {ESLVal c = $501;
            
            {ESLVal _v147 = $502;
            
            return expsToJCommands.apply(_v147,isLast).cons(expToJCommand.apply(c,$false));
          }
          }
          }
        else if($502.isNil())
          {ESLVal c = $501;
            
            return ESLVal.list(expToJCommand.apply(c,isLast));
          }
        else {ESLVal c = $501;
            
            {ESLVal _v148 = $502;
            
            return expsToJCommands.apply(_v148,isLast).cons(expToJCommand.apply(c,$false));
          }
          }
        }
      else if(_v66.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(1004,1164)").add(ESLVal.list(_v66)));
      }
    }
  });
  private static ESLVal expToJCommand = new ESLVal(new Function(new ESLVal("expToJCommand"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal c = $args[0];
  ESLVal isLast = $args[1];
  {ESLVal _v59 = c;
        
        switch(_v59.termName) {
        case "Block": {ESLVal $496 = _v59.termRef(0);
          ESLVal $495 = _v59.termRef(1);
          
          if($495.isCons())
          {ESLVal $497 = $495.head();
            ESLVal $498 = $495.tail();
            
            if($498.isCons())
            {ESLVal $499 = $498.head();
              ESLVal $500 = $498.tail();
              
              {ESLVal l = $496;
              
              {ESLVal es = $495;
              
              return new ESLVal("JBlock",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v63 = $qualArg;
                    
                    {ESLVal e = _v63;
                    
                    return ESLVal.list(ESLVal.list(expToJCommand.apply(e,$false)));
                  }
                  }
                }
              }).map(butlast.apply(es)).flatten().flatten().add(ESLVal.list(expToJCommand.apply(last.apply(es),isLast))));
            }
            }
            }
          else if($498.isNil())
            {ESLVal l = $496;
              
              {ESLVal e = $497;
              
              return expToJCommand.apply(e,isLast);
            }
            }
          else {ESLVal l = $496;
              
              {ESLVal es = $495;
              
              return new ESLVal("JBlock",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v64 = $qualArg;
                    
                    {ESLVal e = _v64;
                    
                    return ESLVal.list(ESLVal.list(expToJCommand.apply(e,$false)));
                  }
                  }
                }
              }).map(butlast.apply(es)).flatten().flatten().add(ESLVal.list(expToJCommand.apply(last.apply(es),isLast))));
            }
            }
          }
        else if($495.isNil())
          {ESLVal l = $496;
            
            if(isLast.boolVal)
            return new ESLVal("JReturn",new ESLVal("JNull",new ESLVal[]{}));
            else
              {ESLVal _v145 = $496;
                
                return new ESLVal("JBlock",$nil);
              }
          }
        else {ESLVal l = $496;
            
            {ESLVal es = $495;
            
            return new ESLVal("JBlock",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v65 = $qualArg;
                  
                  {ESLVal e = _v65;
                  
                  return ESLVal.list(ESLVal.list(expToJCommand.apply(e,$false)));
                }
                }
              }
            }).map(butlast.apply(es)).flatten().flatten().add(ESLVal.list(expToJCommand.apply(last.apply(es),isLast))));
          }
          }
        }
      case "Update": {ESLVal $494 = _v59.termRef(0);
          ESLVal $493 = _v59.termRef(1);
          ESLVal $492 = _v59.termRef(2);
          
          {ESLVal l = $494;
          
          {ESLVal n = $493;
          
          {ESLVal e = $492;
          
          if(isLast.boolVal)
          return new ESLVal("JBlock",ESLVal.list(new ESLVal("JUpdate",n,expToJExp.apply(e)),new ESLVal("JReturn",new ESLVal("JNull",new ESLVal[]{}))));
          else
            {ESLVal _v142 = $494;
              
              {ESLVal _v143 = $493;
              
              {ESLVal _v144 = $492;
              
              return new ESLVal("JUpdate",_v143,expToJExp.apply(_v144));
            }
            }
            }
        }
        }
        }
        }
      case "If": {ESLVal $491 = _v59.termRef(0);
          ESLVal $490 = _v59.termRef(1);
          ESLVal $489 = _v59.termRef(2);
          ESLVal $488 = _v59.termRef(3);
          
          {ESLVal l = $491;
          
          {ESLVal e1 = $490;
          
          {ESLVal e2 = $489;
          
          {ESLVal e3 = $488;
          
          return new ESLVal("JIfCommand",expToJExp.apply(e1),expToJCommand.apply(e2,isLast),expToJCommand.apply(e3,isLast));
        }
        }
        }
        }
        }
      case "CaseList": {ESLVal $487 = _v59.termRef(0);
          ESLVal $486 = _v59.termRef(1);
          ESLVal $485 = _v59.termRef(2);
          ESLVal $484 = _v59.termRef(3);
          ESLVal $483 = _v59.termRef(4);
          
          {ESLVal l = $487;
          
          {ESLVal e = $486;
          
          {ESLVal cons = $485;
          
          {ESLVal nil = $484;
          
          {ESLVal alt = $483;
          
          return new ESLVal("JCaseList",expToJExp.apply(e),expToJCommand.apply(cons,isLast),expToJCommand.apply(nil,isLast),expToJCommand.apply(alt,isLast));
        }
        }
        }
        }
        }
        }
      case "CaseTerm": {ESLVal $482 = _v59.termRef(0);
          ESLVal $481 = _v59.termRef(1);
          ESLVal $480 = _v59.termRef(2);
          ESLVal $479 = _v59.termRef(3);
          
          {ESLVal l = $482;
          
          {ESLVal e = $481;
          
          {ESLVal arms = $480;
          
          {ESLVal alt = $479;
          
          return new ESLVal("JCaseTerm",expToJExp.apply(e),termArmsToJTermArms.apply(arms,isLast),expToJCommand.apply(alt,isLast));
        }
        }
        }
        }
        }
      case "CaseInt": {ESLVal $478 = _v59.termRef(0);
          ESLVal $477 = _v59.termRef(1);
          ESLVal $476 = _v59.termRef(2);
          ESLVal $475 = _v59.termRef(3);
          
          {ESLVal l = $478;
          
          {ESLVal e = $477;
          
          {ESLVal arms = $476;
          
          {ESLVal alt = $475;
          
          return new ESLVal("JCaseInt",expToJExp.apply(e),intArmsToJIntArms.apply(arms,isLast),expToJCommand.apply(alt,isLast));
        }
        }
        }
        }
        }
      case "CaseStr": {ESLVal $474 = _v59.termRef(0);
          ESLVal $473 = _v59.termRef(1);
          ESLVal $472 = _v59.termRef(2);
          ESLVal $471 = _v59.termRef(3);
          
          {ESLVal l = $474;
          
          {ESLVal e = $473;
          
          {ESLVal arms = $472;
          
          {ESLVal alt = $471;
          
          return new ESLVal("JCaseStr",expToJExp.apply(e),strArmsToJStrArms.apply(arms,isLast),expToJCommand.apply(alt,isLast));
        }
        }
        }
        }
        }
      case "CaseBool": {ESLVal $470 = _v59.termRef(0);
          ESLVal $469 = _v59.termRef(1);
          ESLVal $468 = _v59.termRef(2);
          ESLVal $467 = _v59.termRef(3);
          
          {ESLVal l = $470;
          
          {ESLVal e = $469;
          
          {ESLVal arms = $468;
          
          {ESLVal alt = $467;
          
          return new ESLVal("JCaseBool",expToJExp.apply(e),boolArmsToJBoolArms.apply(arms,isLast),expToJCommand.apply(alt,isLast));
        }
        }
        }
        }
        }
      case "Let": {ESLVal $466 = _v59.termRef(0);
          ESLVal $465 = _v59.termRef(1);
          ESLVal $464 = _v59.termRef(2);
          
          {ESLVal l = $466;
          
          {ESLVal bs = $465;
          
          {ESLVal e = $464;
          
          return new ESLVal("JLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v62 = $qualArg;
                
                {ESLVal b = _v62;
                
                return ESLVal.list(ESLVal.list(defToField.apply(b)));
              }
              }
            }
          }).map(bs).flatten().flatten(),expToJCommand.apply(e,isLast));
        }
        }
        }
        }
      case "Letrec": {ESLVal $463 = _v59.termRef(0);
          ESLVal $462 = _v59.termRef(1);
          ESLVal $461 = _v59.termRef(2);
          
          {ESLVal l = $463;
          
          {ESLVal bs = $462;
          
          {ESLVal e = $461;
          
          return new ESLVal("JLetRec",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v61 = $qualArg;
                
                {ESLVal b = _v61;
                
                return ESLVal.list(ESLVal.list(defToField.apply(b)));
              }
              }
            }
          }).map(bs).flatten().flatten(),expToJCommand.apply(e,$true));
        }
        }
        }
        }
      case "For": {ESLVal $457 = _v59.termRef(0);
          ESLVal $456 = _v59.termRef(1);
          ESLVal $455 = _v59.termRef(2);
          ESLVal $454 = _v59.termRef(3);
          
          switch($456.termName) {
          case "PVar": {ESLVal $460 = $456.termRef(0);
            ESLVal $459 = $456.termRef(1);
            ESLVal $458 = $456.termRef(2);
            
            {ESLVal l1 = $457;
            
            {ESLVal l2 = $460;
            
            {ESLVal n = $459;
            
            {ESLVal t = $458;
            
            {ESLVal e = $455;
            
            {ESLVal b = $454;
            
            if(isLast.boolVal)
            return new ESLVal("JBlock",ESLVal.list(new ESLVal("JFor",newName.apply(),n,expToJExp.apply(e),expToJCommand.apply(b,$false)),new ESLVal("JReturn",new ESLVal("JNull",new ESLVal[]{}))));
            else
              {ESLVal _v136 = $457;
                
                {ESLVal _v137 = $460;
                
                {ESLVal _v138 = $459;
                
                {ESLVal _v139 = $458;
                
                {ESLVal _v140 = $455;
                
                {ESLVal _v141 = $454;
                
                return new ESLVal("JFor",newName.apply(),_v138,expToJExp.apply(_v140),expToJCommand.apply(_v141,$false));
              }
              }
              }
              }
              }
              }
          }
          }
          }
          }
          }
          }
          }
          default: {ESLVal l = $457;
            
            {ESLVal p = $456;
            
            {ESLVal e = $455;
            
            {ESLVal b = $454;
            
            {ESLVal opName = newName.apply();
            ESLVal varName = newName.apply();
            
            return expToJCommand.apply(new ESLVal("For",l,new ESLVal("PVar",l,varName,$null),e,new ESLVal("Let",l,ESLVal.list(new ESLVal("Binding",l,opName,$null,$null,new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("forp")),ESLVal.list(),$null,new ESLVal("Case",l,$nil,ESLVal.list(new ESLVal("Var",l,varName)),ESLVal.list(new ESLVal("BArm",l,ESLVal.list(p),new ESLVal("BoolExp",l,$true),b),new ESLVal("BArm",l,ESLVal.list(new ESLVal("PVar",l,new ESLVal("$$$"),$null)),new ESLVal("BoolExp",l,$true),new ESLVal("Block",l,ESLVal.list()))))))),new ESLVal("Apply",l,new ESLVal("Var",l,opName),ESLVal.list()))),isLast);
          }
          }
          }
          }
          }
        }
        }
      case "PLet": {ESLVal $453 = _v59.termRef(0);
          ESLVal $452 = _v59.termRef(1);
          ESLVal $451 = _v59.termRef(2);
          
          {ESLVal l = $453;
          
          {ESLVal bs = $452;
          
          {ESLVal e = $451;
          
          return new ESLVal("JPLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v60 = $qualArg;
                
                {ESLVal b = _v60;
                
                return ESLVal.list(ESLVal.list(defToField.apply(b)));
              }
              }
            }
          }).map(bs).flatten().flatten(),expToJCommand.apply(e,isLast));
        }
        }
        }
        }
        default: {ESLVal e = _v59;
          
          if(isLast.boolVal)
          return new ESLVal("JReturn",expToJExp.apply(e));
          else
            {ESLVal _v146 = _v59;
              
              return new ESLVal("JStatement",expToJExp.apply(_v146));
            }
        }
      }
      }
    }
  });
  private static ESLVal expsToJExps = new ESLVal(new Function(new ESLVal("expsToJExps"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal es = $args[0];
  return map.apply(new ESLVal(new Function(new ESLVal("fun2948"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal e = $args[0];
        return expToJExp.apply(e);
          }
        }),es);
    }
  });
  private static ESLVal termArmsToJTermArms = new ESLVal(new Function(new ESLVal("termArmsToJTermArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  ESLVal isLast = $args[1];
  {ESLVal _v58 = arms;
        
        if(_v58.isCons())
        {ESLVal $447 = _v58.head();
          ESLVal $448 = _v58.tail();
          
          switch($447.termName) {
          case "TArm": {ESLVal $450 = $447.termRef(0);
            ESLVal $449 = $447.termRef(1);
            
            {ESLVal n = $450;
            
            {ESLVal e = $449;
            
            {ESLVal _v135 = $448;
            
            return termArmsToJTermArms.apply(_v135,isLast).cons(new ESLVal("JTArm",n,$zero,expToJCommand.apply(e,isLast)));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(4366,4535)").add(ESLVal.list(_v58)));
        }
        }
      else if(_v58.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(4366,4535)").add(ESLVal.list(_v58)));
      }
    }
  });
  private static ESLVal intArmsToJIntArms = new ESLVal(new Function(new ESLVal("intArmsToJIntArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  ESLVal isLast = $args[1];
  {ESLVal _v57 = arms;
        
        if(_v57.isCons())
        {ESLVal $443 = _v57.head();
          ESLVal $444 = _v57.tail();
          
          switch($443.termName) {
          case "IArm": {ESLVal $446 = $443.termRef(0);
            ESLVal $445 = $443.termRef(1);
            
            {ESLVal n = $446;
            
            {ESLVal e = $445;
            
            {ESLVal _v134 = $444;
            
            return intArmsToJIntArms.apply(_v134,isLast).cons(new ESLVal("JIArm",n,expToJCommand.apply(e,isLast)));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(4604,4768)").add(ESLVal.list(_v57)));
        }
        }
      else if(_v57.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(4604,4768)").add(ESLVal.list(_v57)));
      }
    }
  });
  private static ESLVal strArmsToJStrArms = new ESLVal(new Function(new ESLVal("strArmsToJStrArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  ESLVal isLast = $args[1];
  {ESLVal _v56 = arms;
        
        if(_v56.isCons())
        {ESLVal $439 = _v56.head();
          ESLVal $440 = _v56.tail();
          
          switch($439.termName) {
          case "SArm": {ESLVal $442 = $439.termRef(0);
            ESLVal $441 = $439.termRef(1);
            
            {ESLVal s = $442;
            
            {ESLVal e = $441;
            
            {ESLVal _v133 = $440;
            
            return strArmsToJStrArms.apply(_v133,isLast).cons(new ESLVal("JSArm",s,expToJCommand.apply(e,isLast)));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(4837,5001)").add(ESLVal.list(_v56)));
        }
        }
      else if(_v56.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(4837,5001)").add(ESLVal.list(_v56)));
      }
    }
  });
  private static ESLVal boolArmsToJBoolArms = new ESLVal(new Function(new ESLVal("boolArmsToJBoolArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  ESLVal isLast = $args[1];
  {ESLVal _v55 = arms;
        
        if(_v55.isCons())
        {ESLVal $435 = _v55.head();
          ESLVal $436 = _v55.tail();
          
          switch($435.termName) {
          case "BoolArm": {ESLVal $438 = $435.termRef(0);
            ESLVal $437 = $435.termRef(1);
            
            {ESLVal b = $438;
            
            {ESLVal e = $437;
            
            {ESLVal _v132 = $436;
            
            return boolArmsToJBoolArms.apply(_v132,isLast).cons(new ESLVal("JBArm",b,expToJCommand.apply(e,isLast)));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(5076,5249)").add(ESLVal.list(_v55)));
        }
        }
      else if(_v55.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(5076,5249)").add(ESLVal.list(_v55)));
      }
    }
  });
  private static ESLVal opToJOp = new ESLVal(new Function(new ESLVal("opToJOp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal op = $args[0];
  {ESLVal _v54 = op;
        
        switch(_v54.strVal) {
        case "@": return new ESLVal("at");
      case "+": return new ESLVal("add");
      case "-": return new ESLVal("sub");
      case "*": return new ESLVal("mul");
      case "/": return new ESLVal("div");
      case "%": return new ESLVal("mod");
      case ">": return new ESLVal("gre");
      case ">=": return new ESLVal("greql");
      case "<": return new ESLVal("less");
      case "<=": return new ESLVal("lesseql");
      case "=": return new ESLVal("eql");
      case "<>": return new ESLVal("neql");
      case ":": return new ESLVal("cons");
      case "..": return new ESLVal("to");
      case "or": return new ESLVal("or");
      case "and": return new ESLVal("and");
      case "andalso": return new ESLVal("andalso");
      case "orelse": return new ESLVal("orelse");
        default: return error(new ESLVal("case error at Pos(5277,5646)").add(ESLVal.list(_v54)));
      }
      }
    }
  });
  private static ESLVal caseToJExp = new ESLVal(new Function(new ESLVal("caseToJExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  {ESLVal bindings = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v51 = $qualArg;
                
                {ESLVal e = _v51;
                
                return ESLVal.list(ESLVal.list(new ESLVal("Binding",l,newName.apply(),$null,$null,e)));
              }
              }
            }
          }).map(es).flatten().flatten();
        
        {ESLVal names = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v52 = $qualArg;
                
                switch(_v52.termName) {
                case "Binding": {ESLVal $434 = _v52.termRef(0);
                  ESLVal $433 = _v52.termRef(1);
                  ESLVal $432 = _v52.termRef(2);
                  ESLVal $431 = _v52.termRef(3);
                  ESLVal $430 = _v52.termRef(4);
                  
                  {ESLVal _v131 = $434;
                  
                  {ESLVal n = $433;
                  
                  {ESLVal dt = $432;
                  
                  {ESLVal t = $431;
                  
                  {ESLVal e = $430;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _0 = _v52;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(bindings).flatten().flatten();
        
        return expToJExp.apply(new ESLVal("Let",l,bindings,translateCases.apply(new ESLVal("Case",l,ESLVal.list(),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v53 = $qualArg;
              
              {ESLVal n = _v53;
              
              return ESLVal.list(ESLVal.list(new ESLVal("Var",l,n)));
            }
            }
          }
        }).map(names).flatten().flatten(),arms))));
      }
      }
    }
  });
  private static ESLVal expToJExp = new ESLVal(new Function(new ESLVal("expToJExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  {ESLVal _v48 = e;
        
        switch(_v48.termName) {
        case "ArrayUpdate": {ESLVal $424 = _v48.termRef(0);
          ESLVal $423 = _v48.termRef(1);
          ESLVal $422 = _v48.termRef(2);
          ESLVal $421 = _v48.termRef(3);
          
          {ESLVal l = $424;
          
          {ESLVal a = $423;
          
          {ESLVal i = $422;
          
          {ESLVal v = $421;
          
          return new ESLVal("JArrayUpdate",expToJExp.apply(a),expToJExp.apply(i),expToJExp.apply(v));
        }
        }
        }
        }
        }
      case "ArrayRef": {ESLVal $420 = _v48.termRef(0);
          ESLVal $419 = _v48.termRef(1);
          ESLVal $418 = _v48.termRef(2);
          
          {ESLVal l = $420;
          
          {ESLVal a = $419;
          
          {ESLVal i = $418;
          
          return new ESLVal("JArrayRef",expToJExp.apply(a),expToJExp.apply(i));
        }
        }
        }
        }
      case "IntExp": {ESLVal $417 = _v48.termRef(0);
          ESLVal $416 = _v48.termRef(1);
          
          {ESLVal l = $417;
          
          {ESLVal n = $416;
          
          return new ESLVal("JConstExp",new ESLVal("JConstInt",n));
        }
        }
        }
      case "StrExp": {ESLVal $415 = _v48.termRef(0);
          ESLVal $414 = _v48.termRef(1);
          
          {ESLVal l = $415;
          
          {ESLVal s = $414;
          
          return new ESLVal("JConstExp",new ESLVal("JConstStr",s));
        }
        }
        }
      case "BoolExp": {ESLVal $413 = _v48.termRef(0);
          ESLVal $412 = _v48.termRef(1);
          
          {ESLVal l = $413;
          
          {ESLVal b = $412;
          
          return new ESLVal("JConstExp",new ESLVal("JConstBool",b));
        }
        }
        }
      case "FloatExp": {ESLVal $411 = _v48.termRef(0);
          ESLVal $410 = _v48.termRef(1);
          
          {ESLVal l = $411;
          
          {ESLVal f = $410;
          
          return new ESLVal("JConstExp",new ESLVal("JConstDouble",f));
        }
        }
        }
      case "ApplyTypeExp": {ESLVal $396 = _v48.termRef(0);
          ESLVal $395 = _v48.termRef(1);
          ESLVal $394 = _v48.termRef(2);
          
          switch($395.termName) {
          case "List": {ESLVal $403 = $395.termRef(0);
            ESLVal $402 = $395.termRef(1);
            
            if($402.isCons())
            {ESLVal $404 = $402.head();
              ESLVal $405 = $402.tail();
              
              {ESLVal l = $396;
              
              {ESLVal _v124 = $395;
              
              {ESLVal ts = $394;
              
              return expToJExp.apply(_v124);
            }
            }
            }
            }
          else if($402.isNil())
            if($394.isCons())
              {ESLVal $406 = $394.head();
                ESLVal $407 = $394.tail();
                
                if($407.isCons())
                {ESLVal $408 = $407.head();
                  ESLVal $409 = $407.tail();
                  
                  {ESLVal l = $396;
                  
                  {ESLVal _v125 = $395;
                  
                  {ESLVal ts = $394;
                  
                  return expToJExp.apply(_v125);
                }
                }
                }
                }
              else if($407.isNil())
                {ESLVal l1 = $396;
                  
                  {ESLVal l2 = $403;
                  
                  {ESLVal t = $406;
                  
                  return new ESLVal("JNil",$null);
                }
                }
                }
              else {ESLVal l = $396;
                  
                  {ESLVal _v126 = $395;
                  
                  {ESLVal ts = $394;
                  
                  return expToJExp.apply(_v126);
                }
                }
                }
              }
            else if($394.isNil())
              {ESLVal l = $396;
                
                {ESLVal _v127 = $395;
                
                {ESLVal ts = $394;
                
                return expToJExp.apply(_v127);
              }
              }
              }
            else {ESLVal l = $396;
                
                {ESLVal _v128 = $395;
                
                {ESLVal ts = $394;
                
                return expToJExp.apply(_v128);
              }
              }
              }
          else {ESLVal l = $396;
              
              {ESLVal _v129 = $395;
              
              {ESLVal ts = $394;
              
              return expToJExp.apply(_v129);
            }
            }
            }
          }
        case "NullExp": {ESLVal $397 = $395.termRef(0);
            
            if($394.isCons())
            {ESLVal $398 = $394.head();
              ESLVal $399 = $394.tail();
              
              if($399.isCons())
              {ESLVal $400 = $399.head();
                ESLVal $401 = $399.tail();
                
                {ESLVal l = $396;
                
                {ESLVal _v120 = $395;
                
                {ESLVal ts = $394;
                
                return expToJExp.apply(_v120);
              }
              }
              }
              }
            else if($399.isNil())
              {ESLVal l1 = $396;
                
                {ESLVal l2 = $397;
                
                {ESLVal t = $398;
                
                return new ESLVal("JNull",new ESLVal[]{});
              }
              }
              }
            else {ESLVal l = $396;
                
                {ESLVal _v121 = $395;
                
                {ESLVal ts = $394;
                
                return expToJExp.apply(_v121);
              }
              }
              }
            }
          else if($394.isNil())
            {ESLVal l = $396;
              
              {ESLVal _v122 = $395;
              
              {ESLVal ts = $394;
              
              return expToJExp.apply(_v122);
            }
            }
            }
          else {ESLVal l = $396;
              
              {ESLVal _v123 = $395;
              
              {ESLVal ts = $394;
              
              return expToJExp.apply(_v123);
            }
            }
            }
          }
          default: {ESLVal l = $396;
            
            {ESLVal _v130 = $395;
            
            {ESLVal ts = $394;
            
            return expToJExp.apply(_v130);
          }
          }
          }
        }
        }
      case "List": {ESLVal $393 = _v48.termRef(0);
          ESLVal $392 = _v48.termRef(1);
          
          {ESLVal l = $393;
          
          {ESLVal es = $392;
          
          return new ESLVal("JList",$null,expsToJExps.apply(es));
        }
        }
        }
      case "SetExp": {ESLVal $391 = _v48.termRef(0);
          ESLVal $390 = _v48.termRef(1);
          
          {ESLVal l = $391;
          
          {ESLVal es = $390;
          
          return new ESLVal("JSet",$null,expsToJExps.apply(es));
        }
        }
        }
      case "BagExp": {ESLVal $389 = _v48.termRef(0);
          ESLVal $388 = _v48.termRef(1);
          
          {ESLVal l = $389;
          
          {ESLVal es = $388;
          
          return new ESLVal("JBag",$null,expsToJExps.apply(es));
        }
        }
        }
      case "Term": {ESLVal $387 = _v48.termRef(0);
          ESLVal $386 = _v48.termRef(1);
          ESLVal $385 = _v48.termRef(2);
          ESLVal $384 = _v48.termRef(3);
          
          {ESLVal l = $387;
          
          {ESLVal n = $386;
          
          {ESLVal ts = $385;
          
          {ESLVal es = $384;
          
          return new ESLVal("JTerm",n,expsToJExps.apply(es));
        }
        }
        }
        }
        }
      case "Case": {ESLVal $383 = _v48.termRef(0);
          ESLVal $382 = _v48.termRef(1);
          ESLVal $381 = _v48.termRef(2);
          ESLVal $380 = _v48.termRef(3);
          
          {ESLVal l = $383;
          
          {ESLVal ds = $382;
          
          {ESLVal es = $381;
          
          {ESLVal arms = $380;
          
          return caseToJExp.apply(l,es,arms);
        }
        }
        }
        }
        }
      case "CaseAdd": {ESLVal $379 = _v48.termRef(0);
          ESLVal $378 = _v48.termRef(1);
          ESLVal $377 = _v48.termRef(2);
          ESLVal $376 = _v48.termRef(3);
          
          {ESLVal l = $379;
          
          {ESLVal s = $378;
          
          {ESLVal handler = $377;
          
          {ESLVal fail = $376;
          
          return expToJExp.apply(new ESLVal("Apply",l,new ESLVal("Var",l,new ESLVal("$ndCase")),ESLVal.list(s,handler,fail)));
        }
        }
        }
        }
        }
      case "CaseList": {ESLVal $375 = _v48.termRef(0);
          ESLVal $374 = _v48.termRef(1);
          ESLVal $373 = _v48.termRef(2);
          ESLVal $372 = _v48.termRef(3);
          ESLVal $371 = _v48.termRef(4);
          
          {ESLVal l = $375;
          
          {ESLVal list = $374;
          
          {ESLVal cons = $373;
          
          {ESLVal nil = $372;
          
          {ESLVal alt = $371;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
        }
        }
      case "CaseTerm": {ESLVal $370 = _v48.termRef(0);
          ESLVal $369 = _v48.termRef(1);
          ESLVal $368 = _v48.termRef(2);
          ESLVal $367 = _v48.termRef(3);
          
          {ESLVal l = $370;
          
          {ESLVal list = $369;
          
          {ESLVal arms = $368;
          
          {ESLVal alt = $367;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
        }
      case "CaseStr": {ESLVal $366 = _v48.termRef(0);
          ESLVal $365 = _v48.termRef(1);
          ESLVal $364 = _v48.termRef(2);
          ESLVal $363 = _v48.termRef(3);
          
          {ESLVal l = $366;
          
          {ESLVal s = $365;
          
          {ESLVal arms = $364;
          
          {ESLVal alt = $363;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
        }
      case "CaseBool": {ESLVal $362 = _v48.termRef(0);
          ESLVal $361 = _v48.termRef(1);
          ESLVal $360 = _v48.termRef(2);
          ESLVal $359 = _v48.termRef(3);
          
          {ESLVal l = $362;
          
          {ESLVal s = $361;
          
          {ESLVal arms = $360;
          
          {ESLVal alt = $359;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
        }
      case "CaseSet": {ESLVal $358 = _v48.termRef(0);
          ESLVal $357 = _v48.termRef(1);
          ESLVal $356 = _v48.termRef(2);
          ESLVal $355 = _v48.termRef(3);
          
          {ESLVal l = $358;
          
          {ESLVal s = $357;
          
          {ESLVal handler = $356;
          
          {ESLVal fail = $355;
          
          return expToJExp.apply(new ESLVal("Apply",l,new ESLVal("Var",l,new ESLVal("$ndCase")),ESLVal.list(s,handler,fail)));
        }
        }
        }
        }
        }
      case "Head": {ESLVal $354 = _v48.termRef(0);
          
          {ESLVal _v119 = $354;
          
          return new ESLVal("JHead",expToJExp.apply(_v119));
        }
        }
      case "Tail": {ESLVal $353 = _v48.termRef(0);
          
          {ESLVal _v118 = $353;
          
          return new ESLVal("JTail",expToJExp.apply(_v118));
        }
        }
      case "CaseError": {ESLVal $352 = _v48.termRef(0);
          ESLVal $351 = _v48.termRef(1);
          
          {ESLVal l = $352;
          
          {ESLVal _v117 = $351;
          
          return new ESLVal("JError",new ESLVal("JBinExp",new ESLVal("JConstExp",new ESLVal("JConstStr",new ESLVal("case error at ").add(l))),new ESLVal("add"),expToJExp.apply(_v117)));
        }
        }
        }
      case "NullExp": {ESLVal $350 = _v48.termRef(0);
          
          {ESLVal l = $350;
          
          return new ESLVal("JNull",new ESLVal[]{});
        }
        }
      case "Var": {ESLVal $349 = _v48.termRef(0);
          ESLVal $348 = _v48.termRef(1);
          
          {ESLVal l = $349;
          
          {ESLVal n = $348;
          
          return new ESLVal("JVar",n,$null);
        }
        }
        }
      case "Let": {ESLVal $347 = _v48.termRef(0);
          ESLVal $346 = _v48.termRef(1);
          ESLVal $345 = _v48.termRef(2);
          
          {ESLVal l = $347;
          
          {ESLVal bs = $346;
          
          {ESLVal body = $345;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
      case "Letrec": {ESLVal $344 = _v48.termRef(0);
          ESLVal $343 = _v48.termRef(1);
          ESLVal $342 = _v48.termRef(2);
          
          {ESLVal l = $344;
          
          {ESLVal bs = $343;
          
          {ESLVal body = $342;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
      case "Throw": {ESLVal $341 = _v48.termRef(0);
          ESLVal $340 = _v48.termRef(1);
          ESLVal $339 = _v48.termRef(2);
          
          {ESLVal l = $341;
          
          {ESLVal t = $340;
          
          {ESLVal _v116 = $339;
          
          return new ESLVal("JError",expToJExp.apply(_v116));
        }
        }
        }
        }
      case "Apply": {ESLVal $338 = _v48.termRef(0);
          ESLVal $337 = _v48.termRef(1);
          ESLVal $336 = _v48.termRef(2);
          
          {ESLVal l = $338;
          
          {ESLVal op = $337;
          
          {ESLVal args = $336;
          
          return new ESLVal("JApply",expToJExp.apply(op),expsToJExps.apply(args));
        }
        }
        }
        }
      case "BinExp": {ESLVal $335 = _v48.termRef(0);
          ESLVal $334 = _v48.termRef(1);
          ESLVal $333 = _v48.termRef(2);
          ESLVal $332 = _v48.termRef(3);
          
          {ESLVal l = $335;
          
          {ESLVal e1 = $334;
          
          {ESLVal op = $333;
          
          {ESLVal e2 = $332;
          
          return new ESLVal("JBinExp",expToJExp.apply(e1),opToJOp.apply(op),expToJExp.apply(e2));
        }
        }
        }
        }
        }
      case "Become": {ESLVal $328 = _v48.termRef(0);
          ESLVal $327 = _v48.termRef(1);
          
          switch($327.termName) {
          case "Apply": {ESLVal $331 = $327.termRef(0);
            ESLVal $330 = $327.termRef(1);
            ESLVal $329 = $327.termRef(2);
            
            {ESLVal l = $328;
            
            {ESLVal al = $331;
            
            {ESLVal b = $330;
            
            {ESLVal args = $329;
            
            return new ESLVal("JBecome",expToJExp.apply(b),expsToJExps.apply(args));
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(6004,14469)").add(ESLVal.list(_v48)));
        }
        }
      case "Block": {ESLVal $322 = _v48.termRef(0);
          ESLVal $321 = _v48.termRef(1);
          
          if($321.isCons())
          {ESLVal $323 = $321.head();
            ESLVal $324 = $321.tail();
            
            if($324.isCons())
            {ESLVal $325 = $324.head();
              ESLVal $326 = $324.tail();
              
              {ESLVal l = $322;
              
              {ESLVal es = $321;
              
              return new ESLVal("JCommandExp",new ESLVal("JBlock",expsToJCommands.apply(es,$true)),$null);
            }
            }
            }
          else if($324.isNil())
            {ESLVal l = $322;
              
              {ESLVal _v115 = $323;
              
              return expToJExp.apply(_v115);
            }
            }
          else {ESLVal l = $322;
              
              {ESLVal es = $321;
              
              return new ESLVal("JCommandExp",new ESLVal("JBlock",expsToJCommands.apply(es,$true)),$null);
            }
            }
          }
        else if($321.isNil())
          {ESLVal l = $322;
            
            return new ESLVal("JNull",new ESLVal[]{});
          }
        else {ESLVal l = $322;
            
            {ESLVal es = $321;
            
            return new ESLVal("JCommandExp",new ESLVal("JBlock",expsToJCommands.apply(es,$true)),$null);
          }
          }
        }
      case "If": {ESLVal $320 = _v48.termRef(0);
          ESLVal $319 = _v48.termRef(1);
          ESLVal $318 = _v48.termRef(2);
          ESLVal $317 = _v48.termRef(3);
          
          {ESLVal l = $320;
          
          {ESLVal e1 = $319;
          
          {ESLVal e2 = $318;
          
          {ESLVal e3 = $317;
          
          return new ESLVal("JCommandExp",new ESLVal("JIfCommand",expToJExp.apply(e1),expToJCommand.apply(e2,$true),expToJCommand.apply(e3,$true)),$null);
        }
        }
        }
        }
        }
      case "FunExp": {ESLVal $316 = _v48.termRef(0);
          ESLVal $315 = _v48.termRef(1);
          ESLVal $314 = _v48.termRef(2);
          ESLVal $313 = _v48.termRef(3);
          ESLVal $312 = _v48.termRef(4);
          
          {ESLVal l = $316;
          
          {ESLVal n = $315;
          
          {ESLVal args = $314;
          
          {ESLVal t = $313;
          
          {ESLVal body = $312;
          
          return new ESLVal("JFun",expToJExp.apply(n),map.apply(new ESLVal(new Function(new ESLVal("fun2949"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal d = $args[0];
          return decToJDec.apply(d);
            }
          }),args),new ESLVal("JFunType",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v50 = $qualArg;
                
                {ESLVal a = _v50;
                
                return ESLVal.list(ESLVal.list($null));
              }
              }
            }
          }).map(args).flatten().flatten(),$null),expToJCommand.apply(body,$true));
        }
        }
        }
        }
        }
        }
      case "TermRef": {ESLVal $311 = _v48.termRef(0);
          ESLVal $310 = _v48.termRef(1);
          
          {ESLVal _v114 = $311;
          
          {ESLVal i = $310;
          
          return new ESLVal("JTermRef",expToJExp.apply(_v114),i);
        }
        }
        }
      case "Cmp": {ESLVal $309 = _v48.termRef(0);
          ESLVal $308 = _v48.termRef(1);
          ESLVal $307 = _v48.termRef(2);
          
          {ESLVal l = $309;
          
          {ESLVal _v113 = $308;
          
          {ESLVal qs = $307;
          
          return cmpToJExp.apply(_v113,qs);
        }
        }
        }
        }
      case "Not": {ESLVal $306 = _v48.termRef(0);
          ESLVal $305 = _v48.termRef(1);
          
          {ESLVal l = $306;
          
          {ESLVal _v112 = $305;
          
          return new ESLVal("JNot",expToJExp.apply(_v112));
        }
        }
        }
      case "New": {ESLVal $304 = _v48.termRef(0);
          ESLVal $303 = _v48.termRef(1);
          ESLVal $302 = _v48.termRef(2);
          
          {ESLVal l = $304;
          
          {ESLVal b = $303;
          
          {ESLVal args = $302;
          
          return new ESLVal("JNew",expToJExp.apply(b),expsToJExps.apply(args));
        }
        }
        }
        }
      case "NewArray": {ESLVal $301 = _v48.termRef(0);
          ESLVal $300 = _v48.termRef(1);
          ESLVal $299 = _v48.termRef(2);
          
          {ESLVal l = $301;
          
          {ESLVal t = $300;
          
          {ESLVal i = $299;
          
          return new ESLVal("JNewArray",expToJExp.apply(i));
        }
        }
        }
        }
      case "NewJava": {ESLVal $298 = _v48.termRef(0);
          ESLVal $297 = _v48.termRef(1);
          ESLVal $296 = _v48.termRef(2);
          ESLVal $295 = _v48.termRef(3);
          
          {ESLVal l = $298;
          
          {ESLVal n = $297;
          
          {ESLVal t = $296;
          
          {ESLVal args = $295;
          
          return new ESLVal("JNewJava",n,expsToJExps.apply(args));
        }
        }
        }
        }
        }
      case "NewTable": {ESLVal $294 = _v48.termRef(0);
          ESLVal $293 = _v48.termRef(1);
          ESLVal $292 = _v48.termRef(2);
          
          {ESLVal l = $294;
          
          {ESLVal key = $293;
          
          {ESLVal value = $292;
          
          return new ESLVal("JNewTable",new ESLVal[]{});
        }
        }
        }
        }
      case "Record": {ESLVal $291 = _v48.termRef(0);
          ESLVal $290 = _v48.termRef(1);
          
          {ESLVal l = $291;
          
          {ESLVal fs = $290;
          
          return new ESLVal("JRecord",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v49 = $qualArg;
                
                switch(_v49.termName) {
                case "Binding": {ESLVal $429 = _v49.termRef(0);
                  ESLVal $428 = _v49.termRef(1);
                  ESLVal $427 = _v49.termRef(2);
                  ESLVal $426 = _v49.termRef(3);
                  ESLVal $425 = _v49.termRef(4);
                  
                  {ESLVal bl = $429;
                  
                  {ESLVal n = $428;
                  
                  {ESLVal t = $427;
                  
                  {ESLVal dt = $426;
                  
                  {ESLVal _v111 = $425;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",n,$null,expToJExp.apply(_v111))));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _0 = _v49;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten());
        }
        }
        }
      case "Send": {ESLVal $285 = _v48.termRef(0);
          ESLVal $284 = _v48.termRef(1);
          ESLVal $283 = _v48.termRef(2);
          
          switch($283.termName) {
          case "Term": {ESLVal $289 = $283.termRef(0);
            ESLVal $288 = $283.termRef(1);
            ESLVal $287 = $283.termRef(2);
            ESLVal $286 = $283.termRef(3);
            
            {ESLVal l = $285;
            
            {ESLVal a = $284;
            
            {ESLVal lt = $289;
            
            {ESLVal n = $288;
            
            {ESLVal ts = $287;
            
            {ESLVal es = $286;
            
            return new ESLVal("JSend",expToJExp.apply(a),n,expsToJExps.apply(es));
          }
          }
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(6004,14469)").add(ESLVal.list(_v48)));
        }
        }
      case "SendTimeSuper": {ESLVal $282 = _v48.termRef(0);
          
          {ESLVal l = $282;
          
          return new ESLVal("JSendTimeSuper",new ESLVal[]{});
        }
        }
      case "SendSuper": {ESLVal $281 = _v48.termRef(0);
          ESLVal $280 = _v48.termRef(1);
          
          {ESLVal l = $281;
          
          {ESLVal _v110 = $280;
          
          return new ESLVal("JSendSuper",expToJExp.apply(_v110));
        }
        }
        }
      case "Self": {ESLVal $279 = _v48.termRef(0);
          
          {ESLVal l = $279;
          
          return new ESLVal("JSelf",new ESLVal[]{});
        }
        }
      case "Fold": {ESLVal $278 = _v48.termRef(0);
          ESLVal $277 = _v48.termRef(1);
          ESLVal $276 = _v48.termRef(2);
          
          {ESLVal l = $278;
          
          {ESLVal t = $277;
          
          {ESLVal _v109 = $276;
          
          return expToJExp.apply(_v109);
        }
        }
        }
        }
      case "Now": {ESLVal $275 = _v48.termRef(0);
          
          {ESLVal l = $275;
          
          return new ESLVal("JNow",new ESLVal[]{});
        }
        }
      case "Ref": {ESLVal $274 = _v48.termRef(0);
          ESLVal $273 = _v48.termRef(1);
          ESLVal $272 = _v48.termRef(2);
          
          {ESLVal l = $274;
          
          {ESLVal _v108 = $273;
          
          {ESLVal n = $272;
          
          return new ESLVal("JRef",expToJExp.apply(_v108),n);
        }
        }
        }
        }
      case "RefSuper": {ESLVal $271 = _v48.termRef(0);
          ESLVal $270 = _v48.termRef(1);
          
          {ESLVal l = $271;
          
          {ESLVal n = $270;
          
          return new ESLVal("JRefSuper",n);
        }
        }
        }
      case "For": {ESLVal $269 = _v48.termRef(0);
          ESLVal $268 = _v48.termRef(1);
          ESLVal $267 = _v48.termRef(2);
          ESLVal $266 = _v48.termRef(3);
          
          {ESLVal l1 = $269;
          
          {ESLVal p = $268;
          
          {ESLVal l2 = $267;
          
          {ESLVal c = $266;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
        }
      case "Grab": {ESLVal $265 = _v48.termRef(0);
          ESLVal $264 = _v48.termRef(1);
          ESLVal $263 = _v48.termRef(2);
          
          {ESLVal l = $265;
          
          {ESLVal refs = $264;
          
          {ESLVal _v107 = $263;
          
          return new ESLVal("JGrab",refsToJExps.apply(refs),expToJExp.apply(_v107));
        }
        }
        }
        }
      case "Update": {ESLVal $262 = _v48.termRef(0);
          ESLVal $261 = _v48.termRef(1);
          ESLVal $260 = _v48.termRef(2);
          
          {ESLVal l = $262;
          
          {ESLVal n = $261;
          
          {ESLVal v = $260;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
      case "Probably": {ESLVal $259 = _v48.termRef(0);
          ESLVal $258 = _v48.termRef(1);
          ESLVal $257 = _v48.termRef(2);
          ESLVal $256 = _v48.termRef(3);
          ESLVal $255 = _v48.termRef(4);
          
          {ESLVal l = $259;
          
          {ESLVal _v106 = $258;
          
          {ESLVal t = $257;
          
          {ESLVal e1 = $256;
          
          {ESLVal e2 = $255;
          
          return new ESLVal("JProbably",expToJExp.apply(_v106),expToJExp.apply(e1),expToJExp.apply(e2));
        }
        }
        }
        }
        }
        }
      case "Try": {ESLVal $254 = _v48.termRef(0);
          ESLVal $253 = _v48.termRef(1);
          ESLVal $252 = _v48.termRef(2);
          
          {ESLVal l = $254;
          
          {ESLVal _v105 = $253;
          
          {ESLVal arms = $252;
          
          return new ESLVal("JTry",expToJExp.apply(_v105),new ESLVal("$x"),expToJCommand.apply(new ESLVal("Case",l,$nil,ESLVal.list(new ESLVal("Var",l,new ESLVal("$x"))),arms),$true));
        }
        }
        }
        }
      case "ActExp": {ESLVal $251 = _v48.termRef(0);
          ESLVal $250 = _v48.termRef(1);
          ESLVal $249 = _v48.termRef(2);
          ESLVal $248 = _v48.termRef(3);
          ESLVal $247 = _v48.termRef(4);
          ESLVal $246 = _v48.termRef(5);
          ESLVal $245 = _v48.termRef(6);
          ESLVal $244 = _v48.termRef(7);
          
          {ESLVal l = $251;
          
          {ESLVal name = $250;
          
          {ESLVal decs = $249;
          
          {ESLVal exports = $248;
          
          {ESLVal parent = $247;
          
          {ESLVal defs = $246;
          
          {ESLVal init = $245;
          
          {ESLVal arms = $244;
          
          return actToJava.apply(name,decs,exports,parent,defs,init,arms);
        }
        }
        }
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(6004,14469)").add(ESLVal.list(_v48)));
      }
      }
    }
  });
  private static ESLVal refsToJExps = new ESLVal(new Function(new ESLVal("refsToJExps"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal refs = $args[0];
  {ESLVal _v47 = refs;
        
        if(_v47.isCons())
        {ESLVal $235 = _v47.head();
          ESLVal $236 = _v47.tail();
          
          switch($235.termName) {
          case "VarDynamicRef": {ESLVal $241 = $235.termRef(0);
            ESLVal $240 = $235.termRef(1);
            
            switch($240.termName) {
            case "Var": {ESLVal $243 = $240.termRef(0);
              ESLVal $242 = $240.termRef(1);
              
              {ESLVal l = $241;
              
              {ESLVal vl = $243;
              
              {ESLVal n = $242;
              
              {ESLVal _v104 = $236;
              
              return refsToJExps.apply(_v104).cons(new ESLVal("JVar",n,$null));
            }
            }
            }
            }
            }
            default: return error(new ESLVal("case error at Pos(14512,14753)").add(ESLVal.list(_v47)));
          }
          }
        case "ActorDynamicRef": {ESLVal $239 = $235.termRef(0);
            ESLVal $238 = $235.termRef(1);
            ESLVal $237 = $235.termRef(2);
            
            {ESLVal l = $239;
            
            {ESLVal e = $238;
            
            {ESLVal n = $237;
            
            {ESLVal _v103 = $236;
            
            return refsToJExps.apply(_v103).cons(new ESLVal("JRef",expToJExp.apply(e),n));
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(14512,14753)").add(ESLVal.list(_v47)));
        }
        }
      else if(_v47.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(14512,14753)").add(ESLVal.list(_v47)));
      }
    }
  });
  private static ESLVal actToJava = new ESLVal(new Function(new ESLVal("actToJava"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal name = $args[0];
  ESLVal decs = $args[1];
  ESLVal exports = $args[2];
  ESLVal parent = $args[3];
  ESLVal defs = $args[4];
  ESLVal init = $args[5];
  ESLVal arms = $args[6];
  if(parent.eql($null).boolVal)
        return simpleActToJava.apply(name,decs,exports,defs,init,arms);
        else
          return extendedActToJava.apply(name,decs,exports,parent,defs,init,arms);
    }
  });
  private static ESLVal simpleActToJava = new ESLVal(new Function(new ESLVal("simpleActToJava"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal name = $args[0];
  ESLVal decs = $args[1];
  ESLVal exports = $args[2];
  ESLVal defs = $args[3];
  ESLVal init = $args[4];
  ESLVal arms = $args[5];
  {ESLVal timeArms = select.apply(isTimeArm,arms);
        
        {ESLVal nonTimeArms = reject.apply(isTimeArm,arms);
        
        {ESLVal timeCommand = ((Supplier<ESLVal>)() -> { 
            if(timeArms.eql(ESLVal.list()).boolVal)
              return new ESLVal("JBlock",ESLVal.list());
              else
                return timeArmsToJCommand.apply(timeArms);
          }).get();
        
        {ESLVal f = new ESLVal("FunExp",new ESLVal("Pos",$zero,$zero),name,ESLVal.list(new ESLVal("Dec",new ESLVal("Pos",$zero,$zero),new ESLVal("$m"),$null,$null)),new ESLVal("VoidType",new ESLVal("Pos",$zero,$zero)),new ESLVal("Case",new ESLVal("Pos",$zero,$zero),$nil,ESLVal.list(new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("$m"))),nonTimeArms));
        
        return new ESLVal("JBehaviour",exports,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v46 = $qualArg;
              
              {ESLVal b = _v46;
              
              return ESLVal.list(ESLVal.list(defToField.apply(b)));
            }
            }
          }
        }).map(defs).flatten().flatten(),expToJExp.apply(init),expToJExp.apply(f),timeCommand);
      }
      }
      }
      }
    }
  });
  private static ESLVal extendedActToJava = new ESLVal(new Function(new ESLVal("extendedActToJava"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal name = $args[0];
  ESLVal decs = $args[1];
  ESLVal exports = $args[2];
  ESLVal parent = $args[3];
  ESLVal defs = $args[4];
  ESLVal init = $args[5];
  ESLVal arms = $args[6];
  {ESLVal p0 = new ESLVal("Pos",$zero,$zero);
        
        {ESLVal timeSuper = new ESLVal("BArm",p0,ESLVal.list(new ESLVal("PTerm",p0,new ESLVal("Time"),ESLVal.list(),ESLVal.list(new ESLVal("PVar",p0,new ESLVal("$"),$null)))),new ESLVal("BoolExp",p0,$true),new ESLVal("SendTimeSuper",p0));
        
        {ESLVal timeArms = select.apply(isTimeArm,arms).add(ESLVal.list(timeSuper));
        
        {ESLVal messageSuper = new ESLVal("BArm",p0,ESLVal.list(new ESLVal("PVar",p0,new ESLVal("$m"),$null)),new ESLVal("BoolExp",p0,$true),new ESLVal("Block",p0,ESLVal.list(new ESLVal("SendSuper",p0,new ESLVal("Var",p0,new ESLVal("$m"))),new ESLVal("NullExp",p0))));
        
        {ESLVal nonTimeArms = reject.apply(isTimeArm,arms).add(ESLVal.list(messageSuper));
        
        {ESLVal timeCommand = ((Supplier<ESLVal>)() -> { 
            if(timeArms.eql(ESLVal.list()).boolVal)
              return new ESLVal("JBlock",ESLVal.list());
              else
                return timeArmsToJCommand.apply(timeArms);
          }).get();
        
        {ESLVal f = new ESLVal("FunExp",new ESLVal("Pos",$zero,$zero),name,ESLVal.list(new ESLVal("Dec",new ESLVal("Pos",$zero,$zero),new ESLVal("$m"),$null,$null)),new ESLVal("VoidType",new ESLVal("Pos",$zero,$zero)),new ESLVal("Case",new ESLVal("Pos",$zero,$zero),$nil,ESLVal.list(new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("$m"))),nonTimeArms));
        
        return new ESLVal("JExtendedBehaviour",exports,expToJExp.apply(parent),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v45 = $qualArg;
              
              {ESLVal b = _v45;
              
              return ESLVal.list(ESLVal.list(defToField.apply(b)));
            }
            }
          }
        }).map(defs).flatten().flatten(),expToJExp.apply(init),expToJExp.apply(f),timeCommand);
      }
      }
      }
      }
      }
      }
      }
    }
  });
  private static ESLVal isTimeArm = new ESLVal(new Function(new ESLVal("isTimeArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal a = $args[0];
  {ESLVal _v44 = a;
        
        switch(_v44.termName) {
        case "BArm": {ESLVal $226 = _v44.termRef(0);
          ESLVal $225 = _v44.termRef(1);
          ESLVal $224 = _v44.termRef(2);
          ESLVal $223 = _v44.termRef(3);
          
          if($225.isCons())
          {ESLVal $227 = $225.head();
            ESLVal $228 = $225.tail();
            
            switch($227.termName) {
            case "PTerm": {ESLVal $232 = $227.termRef(0);
              ESLVal $231 = $227.termRef(1);
              ESLVal $230 = $227.termRef(2);
              ESLVal $229 = $227.termRef(3);
              
              switch($231.strVal) {
              case "Time": if($228.isCons())
                {ESLVal $233 = $228.head();
                  ESLVal $234 = $228.tail();
                  
                  {ESLVal _v96 = _v44;
                  
                  return $false;
                }
                }
              else if($228.isNil())
                {ESLVal l = $226;
                  
                  {ESLVal pl = $232;
                  
                  {ESLVal ts = $230;
                  
                  {ESLVal ps = $229;
                  
                  {ESLVal g = $224;
                  
                  {ESLVal e = $223;
                  
                  return $true;
                }
                }
                }
                }
                }
                }
              else {ESLVal _v97 = _v44;
                  
                  return $false;
                }
              default: {ESLVal _v98 = _v44;
                
                return $false;
              }
            }
            }
            default: {ESLVal _v99 = _v44;
              
              return $false;
            }
          }
          }
        else if($225.isNil())
          {ESLVal _v100 = _v44;
            
            return $false;
          }
        else {ESLVal _v101 = _v44;
            
            return $false;
          }
        }
        default: {ESLVal _v102 = _v44;
          
          return $false;
        }
      }
      }
    }
  });
  private static ESLVal timeArmsToJCommand = new ESLVal(new Function(new ESLVal("timeArmsToJCommand"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  {ESLVal _v43 = arms;
        
        if(_v43.isCons())
        {ESLVal $192 = _v43.head();
          ESLVal $193 = _v43.tail();
          
          switch($192.termName) {
          case "BArm": {ESLVal $197 = $192.termRef(0);
            ESLVal $196 = $192.termRef(1);
            ESLVal $195 = $192.termRef(2);
            ESLVal $194 = $192.termRef(3);
            
            if($196.isCons())
            {ESLVal $198 = $196.head();
              ESLVal $199 = $196.tail();
              
              switch($198.termName) {
              case "PTerm": {ESLVal $203 = $198.termRef(0);
                ESLVal $202 = $198.termRef(1);
                ESLVal $201 = $198.termRef(2);
                ESLVal $200 = $198.termRef(3);
                
                switch($202.strVal) {
                case "Time": if($201.isCons())
                  {ESLVal $204 = $201.head();
                    ESLVal $205 = $201.tail();
                    
                    return error(new ESLVal("case error at Pos(16854,17384)").add(ESLVal.list(_v43)));
                  }
                else if($201.isNil())
                  if($200.isCons())
                    {ESLVal $206 = $200.head();
                      ESLVal $207 = $200.tail();
                      
                      switch($206.termName) {
                      case "PVar": {ESLVal $218 = $206.termRef(0);
                        ESLVal $217 = $206.termRef(1);
                        ESLVal $216 = $206.termRef(2);
                        
                        if($207.isCons())
                        {ESLVal $219 = $207.head();
                          ESLVal $220 = $207.tail();
                          
                          return error(new ESLVal("case error at Pos(16854,17384)").add(ESLVal.list(_v43)));
                        }
                      else if($207.isNil())
                        if($199.isCons())
                          {ESLVal $221 = $199.head();
                            ESLVal $222 = $199.tail();
                            
                            return error(new ESLVal("case error at Pos(16854,17384)").add(ESLVal.list(_v43)));
                          }
                        else if($199.isNil())
                          {ESLVal l = $197;
                            
                            {ESLVal tl = $203;
                            
                            {ESLVal vl = $218;
                            
                            {ESLVal n = $217;
                            
                            {ESLVal t = $216;
                            
                            {ESLVal g = $195;
                            
                            {ESLVal e = $194;
                            
                            {ESLVal _v95 = $193;
                            
                            return new ESLVal("JLet",ESLVal.list(new ESLVal("JField",n,$null,new ESLVal("JVar",new ESLVal("$t"),$null))),new ESLVal("JIfCommand",expToJExp.apply(g),expToJCommand.apply(e,$false),timeArmsToJCommand.apply(_v95)));
                          }
                          }
                          }
                          }
                          }
                          }
                          }
                          }
                        else return error(new ESLVal("case error at Pos(16854,17384)").add(ESLVal.list(_v43)));
                      else return error(new ESLVal("case error at Pos(16854,17384)").add(ESLVal.list(_v43)));
                      }
                    case "PInt": {ESLVal $209 = $206.termRef(0);
                        ESLVal $208 = $206.termRef(1);
                        
                        if($207.isCons())
                        {ESLVal $210 = $207.head();
                          ESLVal $211 = $207.tail();
                          
                          return error(new ESLVal("case error at Pos(16854,17384)").add(ESLVal.list(_v43)));
                        }
                      else if($207.isNil())
                        if($199.isCons())
                          {ESLVal $212 = $199.head();
                            ESLVal $213 = $199.tail();
                            
                            return error(new ESLVal("case error at Pos(16854,17384)").add(ESLVal.list(_v43)));
                          }
                        else if($199.isNil())
                          switch($195.termName) {
                            case "BoolExp": {ESLVal $215 = $195.termRef(0);
                              ESLVal $214 = $195.termRef(1);
                              
                              switch($214.boolVal ? 1 : 0) {
                              case 1: {ESLVal l = $197;
                                
                                {ESLVal tl = $203;
                                
                                {ESLVal vl = $209;
                                
                                {ESLVal n = $208;
                                
                                {ESLVal bl = $215;
                                
                                {ESLVal e = $194;
                                
                                {ESLVal _v94 = $193;
                                
                                return new ESLVal("JIfCommand",new ESLVal("JBinExp",new ESLVal("JVar",new ESLVal("$t"),$null),new ESLVal("eq"),new ESLVal("JConstExp",new ESLVal("JConstInt",n))),expToJCommand.apply(e,$false),timeArmsToJCommand.apply(_v94));
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              default: return error(new ESLVal("case error at Pos(16854,17384)").add(ESLVal.list(_v43)));
                            }
                            }
                            default: return error(new ESLVal("case error at Pos(16854,17384)").add(ESLVal.list(_v43)));
                          }
                        else return error(new ESLVal("case error at Pos(16854,17384)").add(ESLVal.list(_v43)));
                      else return error(new ESLVal("case error at Pos(16854,17384)").add(ESLVal.list(_v43)));
                      }
                      default: return error(new ESLVal("case error at Pos(16854,17384)").add(ESLVal.list(_v43)));
                    }
                    }
                  else if($200.isNil())
                    return error(new ESLVal("case error at Pos(16854,17384)").add(ESLVal.list(_v43)));
                  else return error(new ESLVal("case error at Pos(16854,17384)").add(ESLVal.list(_v43)));
                else return error(new ESLVal("case error at Pos(16854,17384)").add(ESLVal.list(_v43)));
                default: return error(new ESLVal("case error at Pos(16854,17384)").add(ESLVal.list(_v43)));
              }
              }
              default: return error(new ESLVal("case error at Pos(16854,17384)").add(ESLVal.list(_v43)));
            }
            }
          else if($196.isNil())
            return error(new ESLVal("case error at Pos(16854,17384)").add(ESLVal.list(_v43)));
          else return error(new ESLVal("case error at Pos(16854,17384)").add(ESLVal.list(_v43)));
          }
          default: return error(new ESLVal("case error at Pos(16854,17384)").add(ESLVal.list(_v43)));
        }
        }
      else if(_v43.isNil())
        return new ESLVal("JBlock",ESLVal.list());
      else return error(new ESLVal("case error at Pos(16854,17384)").add(ESLVal.list(_v43)));
      }
    }
  });
  private static ESLVal cmpToJExp = new ESLVal(new Function(new ESLVal("cmpToJExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  ESLVal qs = $args[1];
  {ESLVal _v42 = qs;
        
        if(_v42.isCons())
        {ESLVal $185 = _v42.head();
          ESLVal $186 = _v42.tail();
          
          switch($185.termName) {
          case "BQual": {ESLVal $191 = $185.termRef(0);
            ESLVal $190 = $185.termRef(1);
            ESLVal $189 = $185.termRef(2);
            
            {ESLVal l = $191;
            
            {ESLVal p = $190;
            
            {ESLVal v = $189;
            
            {ESLVal _v93 = $186;
            
            {ESLVal f = new ESLVal("FunExp",new ESLVal("Pos",$zero,$zero),new ESLVal("StrExp",new ESLVal("Pos",$zero,$zero),new ESLVal("qual")),ESLVal.list(new ESLVal("Dec",new ESLVal("Pos",$zero,$zero),new ESLVal("$qualArg"),$null,$null)),$null,new ESLVal("Case",new ESLVal("Pos",$zero,$zero),ESLVal.list(),ESLVal.list(new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("$qualArg"))),ESLVal.list(new ESLVal("BArm",new ESLVal("Pos",$zero,$zero),ESLVal.list(p),new ESLVal("BoolExp",new ESLVal("Pos",$zero,$zero),$true),new ESLVal("List",new ESLVal("Pos",$zero,$zero),ESLVal.list(new ESLVal("Cmp",new ESLVal("Pos",$zero,$zero),e,_v93)))),new ESLVal("BArm",new ESLVal("Pos",$zero,$zero),ESLVal.list(new ESLVal("PVar",new ESLVal("Pos",$zero,$zero),new ESLVal("_0"),$null)),new ESLVal("BoolExp",new ESLVal("Pos",$zero,$zero),$true),new ESLVal("List",new ESLVal("Pos",$zero,$zero),$nil)))));
            
            return new ESLVal("JFlatten",new ESLVal("JFlatten",new ESLVal("JMapFun",expToJExp.apply(f),expToJExp.apply(v))));
          }
          }
          }
          }
          }
          }
        case "PQual": {ESLVal $188 = $185.termRef(0);
            ESLVal $187 = $185.termRef(1);
            
            {ESLVal l = $188;
            
            {ESLVal p = $187;
            
            {ESLVal _v92 = $186;
            
            return new ESLVal("JIfExp",expToJExp.apply(p),cmpToJExp.apply(e,_v92),new ESLVal("JNil",$null));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(17431,18099)").add(ESLVal.list(_v42)));
        }
        }
      else if(_v42.isNil())
        return new ESLVal("JList",$null,ESLVal.list(expToJExp.apply(e)));
      else return error(new ESLVal("case error at Pos(17431,18099)").add(ESLVal.list(_v42)));
      }
    }
  });
  public static ESLVal moduleToJava = new ESLVal(new Function(new ESLVal("moduleToJava"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal module = $args[0];
  {ESLVal _v40 = module;
        
        switch(_v40.termName) {
        case "Module": {ESLVal $184 = _v40.termRef(0);
          ESLVal $183 = _v40.termRef(1);
          ESLVal $182 = _v40.termRef(2);
          ESLVal $181 = _v40.termRef(3);
          ESLVal $180 = _v40.termRef(4);
          ESLVal $179 = _v40.termRef(5);
          ESLVal $178 = _v40.termRef(6);
          
          {ESLVal path = $184;
          
          {ESLVal name = $183;
          
          {ESLVal exports = $182;
          
          {ESLVal imports = $181;
          
          {ESLVal x = $180;
          
          {ESLVal y = $179;
          
          {ESLVal defs = $178;
          
          return renameJVarsModule.apply(new ESLVal("JModule",name,exports,imports,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v41 = $qualArg;
                
                {ESLVal d = _v41;
                
                return ESLVal.list((isBinding.apply(d).or(isFunBind.apply(d)).boolVal) ? (ESLVal.list(defToField.apply(d))) : ($nil));
              }
              }
            }
          }).map(expandFunDefs.apply(mergeFunDefs.apply(defs))).flatten().flatten()));
        }
        }
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(18137,18410)").add(ESLVal.list(_v40)));
      }
      }
    }
  });
  private static ESLVal renameJVarsModule = new ESLVal(new Function(new ESLVal("renameJVarsModule"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal m = $args[0];
  {ESLVal _v37 = m;
        
        switch(_v37.termName) {
        case "JModule": {ESLVal $171 = _v37.termRef(0);
          ESLVal $170 = _v37.termRef(1);
          ESLVal $169 = _v37.termRef(2);
          ESLVal $168 = _v37.termRef(3);
          
          {ESLVal name = $171;
          
          {ESLVal exports = $170;
          
          {ESLVal imports = $169;
          
          {ESLVal fs = $168;
          
          {ESLVal fieldNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v38 = $qualArg;
                  
                  switch(_v38.termName) {
                  case "JField": {ESLVal $174 = _v38.termRef(0);
                    ESLVal $173 = _v38.termRef(1);
                    ESLVal $172 = _v38.termRef(2);
                    
                    {ESLVal n = $174;
                    
                    {ESLVal t = $173;
                    
                    {ESLVal e = $172;
                    
                    return ESLVal.list(ESLVal.list(n));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v38;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(fs).flatten().flatten();
          
          return new ESLVal("JModule",name,exports,imports,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v39 = $qualArg;
                
                switch(_v39.termName) {
                case "JField": {ESLVal $177 = _v39.termRef(0);
                  ESLVal $176 = _v39.termRef(1);
                  ESLVal $175 = _v39.termRef(2);
                  
                  {ESLVal n = $177;
                  
                  {ESLVal t = $176;
                  
                  {ESLVal e = $175;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(e,fieldNames,emptyTable))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v39;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten());
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(18450,18757)").add(ESLVal.list(_v37)));
      }
      }
    }
  });
  private static ESLVal renameJVarsExp = new ESLVal(new Function(new ESLVal("renameJVarsExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  ESLVal vars = $args[1];
  ESLVal env = $args[2];
  {ESLVal _v20 = e;
        
        switch(_v20.termName) {
        case "JFun": {ESLVal $156 = _v20.termRef(0);
          ESLVal $155 = _v20.termRef(1);
          ESLVal $154 = _v20.termRef(2);
          ESLVal $153 = _v20.termRef(3);
          
          {ESLVal v0 = $156;
          
          {ESLVal v1 = $155;
          
          {ESLVal v2 = $154;
          
          {ESLVal v3 = $153;
          
          {ESLVal boundNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v34 = $qualArg;
                  
                  switch(_v34.termName) {
                  case "JDec": {ESLVal $167 = _v34.termRef(0);
                    ESLVal $166 = _v34.termRef(1);
                    
                    {ESLVal n = $167;
                    
                    {ESLVal t = $166;
                    
                    return ESLVal.list(ESLVal.list(n));
                  }
                  }
                  }
                  default: {ESLVal _0 = _v34;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v1).flatten().flatten();
          
          if(exists.apply(new ESLVal(new Function(new ESLVal("fun2950"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal n = $args[0];
        return member.apply(n,boundNames);
          }
        }),vars).boolVal)
          {ESLVal newNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v35 = $qualArg;
                    
                    {ESLVal n = _v35;
                    
                    return ESLVal.list(ESLVal.list(newName.apply()));
                  }
                  }
                }
              }).map(boundNames).flatten().flatten();
            
            {ESLVal env1 = addEntries.apply(boundNames,newNames,env);
            
            return new ESLVal("JFun",v0,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v36 = $qualArg;
                  
                  {ESLVal n = _v36;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JDec",n,$null)));
                }
                }
              }
            }).map(newNames).flatten().flatten(),v2,renameJVarsCommand.apply(v3,boundNames.add(vars),env1));
          }
          }
          else
            return new ESLVal("JFun",v0,v1,v2,renameJVarsCommand.apply(v3,boundNames.add(vars),env));
        }
        }
        }
        }
        }
        }
      case "JApply": {ESLVal $152 = _v20.termRef(0);
          ESLVal $151 = _v20.termRef(1);
          
          {ESLVal v0 = $152;
          
          {ESLVal v1 = $151;
          
          return new ESLVal("JApply",renameJVarsExp.apply(v0,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v33 = $qualArg;
                
                {ESLVal v = _v33;
                
                return ESLVal.list(ESLVal.list(renameJVarsExp.apply(v,vars,env)));
              }
              }
            }
          }).map(v1).flatten().flatten());
        }
        }
        }
      case "JArrayRef": {ESLVal $150 = _v20.termRef(0);
          ESLVal $149 = _v20.termRef(1);
          
          {ESLVal a = $150;
          
          {ESLVal i = $149;
          
          return new ESLVal("JArrayRef",renameJVarsExp.apply(a,vars,env),renameJVarsExp.apply(i,vars,env));
        }
        }
        }
      case "JArrayUpdate": {ESLVal $148 = _v20.termRef(0);
          ESLVal $147 = _v20.termRef(1);
          ESLVal $146 = _v20.termRef(2);
          
          {ESLVal a = $148;
          
          {ESLVal i = $147;
          
          {ESLVal v = $146;
          
          return new ESLVal("JArrayUpdate",renameJVarsExp.apply(a,vars,env),renameJVarsExp.apply(i,vars,env),renameJVarsExp.apply(v,vars,env));
        }
        }
        }
        }
      case "JBecome": {ESLVal $145 = _v20.termRef(0);
          ESLVal $144 = _v20.termRef(1);
          
          {ESLVal _v91 = $145;
          
          {ESLVal es = $144;
          
          return new ESLVal("JBecome",renameJVarsExp.apply(_v91,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v32 = $qualArg;
                
                {ESLVal v = _v32;
                
                return ESLVal.list(ESLVal.list(renameJVarsExp.apply(v,vars,env)));
              }
              }
            }
          }).map(es).flatten().flatten());
        }
        }
        }
      case "JBinExp": {ESLVal $143 = _v20.termRef(0);
          ESLVal $142 = _v20.termRef(1);
          ESLVal $141 = _v20.termRef(2);
          
          {ESLVal v0 = $143;
          
          {ESLVal v1 = $142;
          
          {ESLVal v2 = $141;
          
          return new ESLVal("JBinExp",renameJVarsExp.apply(v0,vars,env),v1,renameJVarsExp.apply(v2,vars,env));
        }
        }
        }
        }
      case "JCommandExp": {ESLVal $140 = _v20.termRef(0);
          ESLVal $139 = _v20.termRef(1);
          
          {ESLVal v0 = $140;
          
          {ESLVal v1 = $139;
          
          return new ESLVal("JCommandExp",renameJVarsCommand.apply(v0,vars,env),v1);
        }
        }
        }
      case "JIfExp": {ESLVal $138 = _v20.termRef(0);
          ESLVal $137 = _v20.termRef(1);
          ESLVal $136 = _v20.termRef(2);
          
          {ESLVal v0 = $138;
          
          {ESLVal v1 = $137;
          
          {ESLVal v2 = $136;
          
          return new ESLVal("JIfExp",renameJVarsExp.apply(v0,vars,env),renameJVarsExp.apply(v1,vars,env),renameJVarsExp.apply(v2,vars,env));
        }
        }
        }
        }
      case "JConstExp": {ESLVal $135 = _v20.termRef(0);
          
          {ESLVal v0 = $135;
          
          return e;
        }
        }
      case "JTerm": {ESLVal $134 = _v20.termRef(0);
          ESLVal $133 = _v20.termRef(1);
          
          {ESLVal v0 = $134;
          
          {ESLVal v1 = $133;
          
          return new ESLVal("JTerm",v0,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v31 = $qualArg;
                
                {ESLVal v = _v31;
                
                return ESLVal.list(ESLVal.list(renameJVarsExp.apply(v,vars,env)));
              }
              }
            }
          }).map(v1).flatten().flatten());
        }
        }
        }
      case "JTermRef": {ESLVal $132 = _v20.termRef(0);
          ESLVal $131 = _v20.termRef(1);
          
          {ESLVal v0 = $132;
          
          {ESLVal v1 = $131;
          
          return new ESLVal("JTermRef",renameJVarsExp.apply(v0,vars,env),v1);
        }
        }
        }
      case "JList": {ESLVal $130 = _v20.termRef(0);
          ESLVal $129 = _v20.termRef(1);
          
          {ESLVal v0 = $130;
          
          {ESLVal v1 = $129;
          
          return new ESLVal("JList",v0,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v30 = $qualArg;
                
                {ESLVal v = _v30;
                
                return ESLVal.list(ESLVal.list(renameJVarsExp.apply(v,vars,env)));
              }
              }
            }
          }).map(v1).flatten().flatten());
        }
        }
        }
      case "JSet": {ESLVal $128 = _v20.termRef(0);
          ESLVal $127 = _v20.termRef(1);
          
          {ESLVal v0 = $128;
          
          {ESLVal v1 = $127;
          
          return new ESLVal("JSet",v0,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v29 = $qualArg;
                
                {ESLVal v = _v29;
                
                return ESLVal.list(ESLVal.list(renameJVarsExp.apply(v,vars,env)));
              }
              }
            }
          }).map(v1).flatten().flatten());
        }
        }
        }
      case "JBag": {ESLVal $126 = _v20.termRef(0);
          ESLVal $125 = _v20.termRef(1);
          
          {ESLVal v0 = $126;
          
          {ESLVal v1 = $125;
          
          return new ESLVal("JBag",v0,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v28 = $qualArg;
                
                {ESLVal v = _v28;
                
                return ESLVal.list(ESLVal.list(renameJVarsExp.apply(v,vars,env)));
              }
              }
            }
          }).map(v1).flatten().flatten());
        }
        }
        }
      case "JNil": {ESLVal $124 = _v20.termRef(0);
          
          {ESLVal v0 = $124;
          
          return e;
        }
        }
      case "JNow": {
          return e;
        }
      case "JVar": {ESLVal $123 = _v20.termRef(0);
          ESLVal $122 = _v20.termRef(1);
          
          {ESLVal v0 = $123;
          
          {ESLVal v1 = $122;
          
          if(hasEntry.apply(v0,env).boolVal)
          return new ESLVal("JVar",lookup.apply(v0,env),v1);
          else
            return e;
        }
        }
        }
      case "JNull": {
          return e;
        }
      case "JError": {ESLVal $121 = _v20.termRef(0);
          
          {ESLVal v0 = $121;
          
          return new ESLVal("JError",renameJVarsExp.apply(v0,vars,env));
        }
        }
      case "JHead": {ESLVal $120 = _v20.termRef(0);
          
          {ESLVal v0 = $120;
          
          return new ESLVal("JHead",renameJVarsExp.apply(v0,vars,env));
        }
        }
      case "JTail": {ESLVal $119 = _v20.termRef(0);
          
          {ESLVal v0 = $119;
          
          return new ESLVal("JTail",renameJVarsExp.apply(v0,vars,env));
        }
        }
      case "JCastp": {ESLVal $118 = _v20.termRef(0);
          ESLVal $117 = _v20.termRef(1);
          ESLVal $116 = _v20.termRef(2);
          
          {ESLVal v0 = $118;
          
          {ESLVal v1 = $117;
          
          {ESLVal v2 = $116;
          
          return new ESLVal("JCastp",v0,v1,renameJVarsExp.apply(v2,vars,env));
        }
        }
        }
        }
      case "JCast": {ESLVal $115 = _v20.termRef(0);
          ESLVal $114 = _v20.termRef(1);
          
          {ESLVal v0 = $115;
          
          {ESLVal v1 = $114;
          
          return new ESLVal("JCast",v0,renameJVarsExp.apply(v1,vars,env));
        }
        }
        }
      case "JNot": {ESLVal $113 = _v20.termRef(0);
          
          {ESLVal _v90 = $113;
          
          return new ESLVal("JNot",renameJVarsExp.apply(_v90,vars,env));
        }
        }
      case "JNew": {ESLVal $112 = _v20.termRef(0);
          ESLVal $111 = _v20.termRef(1);
          
          {ESLVal b = $112;
          
          {ESLVal args = $111;
          
          return new ESLVal("JNew",renameJVarsExp.apply(b,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v27 = $qualArg;
                
                {ESLVal a = _v27;
                
                return ESLVal.list(ESLVal.list(renameJVarsExp.apply(a,vars,env)));
              }
              }
            }
          }).map(args).flatten().flatten());
        }
        }
        }
      case "JNewArray": {ESLVal $110 = _v20.termRef(0);
          
          {ESLVal b = $110;
          
          return new ESLVal("JNewArray",renameJVarsExp.apply(b,vars,env));
        }
        }
      case "JNewJava": {ESLVal $109 = _v20.termRef(0);
          ESLVal $108 = _v20.termRef(1);
          
          {ESLVal n = $109;
          
          {ESLVal args = $108;
          
          return new ESLVal("JNewJava",n,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v26 = $qualArg;
                
                {ESLVal a = _v26;
                
                return ESLVal.list(ESLVal.list(renameJVarsExp.apply(a,vars,env)));
              }
              }
            }
          }).map(args).flatten().flatten());
        }
        }
        }
      case "JNewTable": {
          return new ESLVal("JNewTable",new ESLVal[]{});
        }
      case "JMapFun": {ESLVal $107 = _v20.termRef(0);
          ESLVal $106 = _v20.termRef(1);
          
          {ESLVal f = $107;
          
          {ESLVal l = $106;
          
          return new ESLVal("JMapFun",renameJVarsExp.apply(f,vars,env),renameJVarsExp.apply(l,vars,env));
        }
        }
        }
      case "JRecord": {ESLVal $105 = _v20.termRef(0);
          
          {ESLVal fs = $105;
          
          return new ESLVal("JRecord",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v25 = $qualArg;
                
                switch(_v25.termName) {
                case "JField": {ESLVal $165 = _v25.termRef(0);
                  ESLVal $164 = _v25.termRef(1);
                  ESLVal $163 = _v25.termRef(2);
                  
                  {ESLVal n = $165;
                  
                  {ESLVal t = $164;
                  
                  {ESLVal _v89 = $163;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(_v89,vars,env))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v25;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten());
        }
        }
      case "JFlatten": {ESLVal $104 = _v20.termRef(0);
          
          {ESLVal _v88 = $104;
          
          return new ESLVal("JFlatten",renameJVarsExp.apply(_v88,vars,env));
        }
        }
      case "JSend": {ESLVal $103 = _v20.termRef(0);
          ESLVal $102 = _v20.termRef(1);
          ESLVal $101 = _v20.termRef(2);
          
          {ESLVal _v86 = $103;
          
          {ESLVal n = $102;
          
          {ESLVal es = $101;
          
          return new ESLVal("JSend",renameJVarsExp.apply(_v86,vars,env),n,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v24 = $qualArg;
                
                {ESLVal _v87 = _v24;
                
                return ESLVal.list(ESLVal.list(renameJVarsExp.apply(_v87,vars,env)));
              }
              }
            }
          }).map(es).flatten().flatten());
        }
        }
        }
        }
      case "JSendSuper": {ESLVal $100 = _v20.termRef(0);
          
          {ESLVal _v85 = $100;
          
          return new ESLVal("JSendSuper",renameJVarsExp.apply(_v85,vars,env));
        }
        }
      case "JSendTimeSuper": {
          return new ESLVal("JSendTimeSuper",new ESLVal[]{});
        }
      case "JSelf": {
          return new ESLVal("JSelf",new ESLVal[]{});
        }
      case "JRef": {ESLVal $99 = _v20.termRef(0);
          ESLVal $98 = _v20.termRef(1);
          
          {ESLVal _v84 = $99;
          
          {ESLVal n = $98;
          
          return new ESLVal("JRef",renameJVarsExp.apply(_v84,vars,env),n);
        }
        }
        }
      case "JRefSuper": {ESLVal $97 = _v20.termRef(0);
          
          {ESLVal n = $97;
          
          return new ESLVal("JRefSuper",n);
        }
        }
      case "JBehaviour": {ESLVal $96 = _v20.termRef(0);
          ESLVal $95 = _v20.termRef(1);
          ESLVal $94 = _v20.termRef(2);
          ESLVal $93 = _v20.termRef(3);
          ESLVal $92 = _v20.termRef(4);
          
          {ESLVal es = $96;
          
          {ESLVal fs = $95;
          
          {ESLVal init = $94;
          
          {ESLVal handler = $93;
          
          {ESLVal time = $92;
          
          return new ESLVal("JBehaviour",es,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v23 = $qualArg;
                
                switch(_v23.termName) {
                case "JField": {ESLVal $162 = _v23.termRef(0);
                  ESLVal $161 = _v23.termRef(1);
                  ESLVal $160 = _v23.termRef(2);
                  
                  {ESLVal n = $162;
                  
                  {ESLVal t = $161;
                  
                  {ESLVal _v83 = $160;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(_v83,vars,env))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v23;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten(),renameJVarsExp.apply(init,vars,env),renameJVarsExp.apply(handler,vars,env),renameJVarsCommand.apply(time,vars,env));
        }
        }
        }
        }
        }
        }
      case "JExtendedBehaviour": {ESLVal $91 = _v20.termRef(0);
          ESLVal $90 = _v20.termRef(1);
          ESLVal $89 = _v20.termRef(2);
          ESLVal $88 = _v20.termRef(3);
          ESLVal $87 = _v20.termRef(4);
          ESLVal $86 = _v20.termRef(5);
          
          {ESLVal es = $91;
          
          {ESLVal parent = $90;
          
          {ESLVal fs = $89;
          
          {ESLVal init = $88;
          
          {ESLVal handler = $87;
          
          {ESLVal time = $86;
          
          return new ESLVal("JExtendedBehaviour",es,renameJVarsExp.apply(parent,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v22 = $qualArg;
                
                switch(_v22.termName) {
                case "JField": {ESLVal $159 = _v22.termRef(0);
                  ESLVal $158 = _v22.termRef(1);
                  ESLVal $157 = _v22.termRef(2);
                  
                  {ESLVal n = $159;
                  
                  {ESLVal t = $158;
                  
                  {ESLVal _v82 = $157;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(_v82,vars,env))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v22;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten(),renameJVarsExp.apply(init,vars,env),renameJVarsExp.apply(handler,vars,env),renameJVarsCommand.apply(time,vars,env));
        }
        }
        }
        }
        }
        }
        }
      case "JTry": {ESLVal $85 = _v20.termRef(0);
          ESLVal $84 = _v20.termRef(1);
          ESLVal $83 = _v20.termRef(2);
          
          {ESLVal _v81 = $85;
          
          {ESLVal n = $84;
          
          {ESLVal c = $83;
          
          return new ESLVal("JTry",renameJVarsExp.apply(_v81,vars,env),n,renameJVarsCommand.apply(c,vars,env));
        }
        }
        }
        }
      case "JProbably": {ESLVal $82 = _v20.termRef(0);
          ESLVal $81 = _v20.termRef(1);
          ESLVal $80 = _v20.termRef(2);
          
          {ESLVal _v80 = $82;
          
          {ESLVal e1 = $81;
          
          {ESLVal e2 = $80;
          
          return new ESLVal("JProbably",renameJVarsExp.apply(_v80,vars,env),renameJVarsExp.apply(e1,vars,env),renameJVarsExp.apply(e2,vars,env));
        }
        }
        }
        }
      case "JGrab": {ESLVal $79 = _v20.termRef(0);
          ESLVal $78 = _v20.termRef(1);
          
          {ESLVal es = $79;
          
          {ESLVal c = $78;
          
          return new ESLVal("JGrab",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v21 = $qualArg;
                
                {ESLVal _v79 = _v21;
                
                return ESLVal.list(ESLVal.list(renameJVarsExp.apply(_v79,vars,env)));
              }
              }
            }
          }).map(es).flatten().flatten(),renameJVarsExp.apply(c,vars,env));
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(18827,23412)").add(ESLVal.list(_v20)));
      }
      }
    }
  });
  private static ESLVal nameCount = $zero;
  private static ESLVal newName = new ESLVal(new Function(new ESLVal("newName"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      {nameCount = nameCount.add($one);
      return new ESLVal("_v").add(nameCount);}
    }
  });
  private static ESLVal renameJVarsCommand = new ESLVal(new Function(new ESLVal("renameJVarsCommand"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal c = $args[0];
  ESLVal vars = $args[1];
  ESLVal env = $args[2];
  {ESLVal _v2 = c;
        
        switch(_v2.termName) {
        case "JBlock": {ESLVal $41 = _v2.termRef(0);
          
          {ESLVal v0 = $41;
          
          return new ESLVal("JBlock",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v19 = $qualArg;
                
                {ESLVal _v78 = _v19;
                
                return ESLVal.list(ESLVal.list(renameJVarsCommand.apply(_v78,vars,env)));
              }
              }
            }
          }).map(v0).flatten().flatten());
        }
        }
      case "JReturn": {ESLVal $40 = _v2.termRef(0);
          
          {ESLVal v0 = $40;
          
          return new ESLVal("JReturn",renameJVarsExp.apply(v0,vars,env));
        }
        }
      case "JSwitch": {ESLVal $39 = _v2.termRef(0);
          ESLVal $38 = _v2.termRef(1);
          ESLVal $37 = _v2.termRef(2);
          
          {ESLVal v0 = $39;
          
          {ESLVal v1 = $38;
          
          {ESLVal v2 = $37;
          
          return error(new ESLVal("jswitch should not occur"));
        }
        }
        }
        }
      case "JSwitchList": {ESLVal $36 = _v2.termRef(0);
          ESLVal $35 = _v2.termRef(1);
          ESLVal $34 = _v2.termRef(2);
          ESLVal $33 = _v2.termRef(3);
          
          {ESLVal v0 = $36;
          
          {ESLVal v1 = $35;
          
          {ESLVal v2 = $34;
          
          {ESLVal v3 = $33;
          
          return new ESLVal("JSwitchList",renameJVarsExp.apply(v0,vars,env),renameJVarsCommand.apply(v1,vars,env),renameJVarsCommand.apply(v2,vars,env),renameJVarsCommand.apply(v3,vars,env));
        }
        }
        }
        }
        }
      case "JIfCommand": {ESLVal $32 = _v2.termRef(0);
          ESLVal $31 = _v2.termRef(1);
          ESLVal $30 = _v2.termRef(2);
          
          {ESLVal v0 = $32;
          
          {ESLVal v1 = $31;
          
          {ESLVal v2 = $30;
          
          return new ESLVal("JIfCommand",renameJVarsExp.apply(v0,vars,env),renameJVarsCommand.apply(v1,vars,env),renameJVarsCommand.apply(v2,vars,env));
        }
        }
        }
        }
      case "JCaseList": {ESLVal $29 = _v2.termRef(0);
          ESLVal $28 = _v2.termRef(1);
          ESLVal $27 = _v2.termRef(2);
          ESLVal $26 = _v2.termRef(3);
          
          {ESLVal v0 = $29;
          
          {ESLVal v1 = $28;
          
          {ESLVal v2 = $27;
          
          {ESLVal v3 = $26;
          
          return new ESLVal("JCaseList",renameJVarsExp.apply(v0,vars,env),renameJVarsCommand.apply(v1,vars,env),renameJVarsCommand.apply(v2,vars,env),renameJVarsCommand.apply(v3,vars,env));
        }
        }
        }
        }
        }
      case "JCaseInt": {ESLVal $25 = _v2.termRef(0);
          ESLVal $24 = _v2.termRef(1);
          ESLVal $23 = _v2.termRef(2);
          
          {ESLVal e = $25;
          
          {ESLVal arms = $24;
          
          {ESLVal alt = $23;
          
          return new ESLVal("JCaseInt",renameJVarsExp.apply(e,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v18 = $qualArg;
                
                switch(_v18.termName) {
                case "JIArm": {ESLVal $77 = _v18.termRef(0);
                  ESLVal $76 = _v18.termRef(1);
                  
                  {ESLVal n = $77;
                  
                  {ESLVal _v77 = $76;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JIArm",n,renameJVarsCommand.apply(_v77,vars,env))));
                }
                }
                }
                default: {ESLVal _0 = _v18;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten(),renameJVarsCommand.apply(alt,vars,env));
        }
        }
        }
        }
      case "JCaseStr": {ESLVal $22 = _v2.termRef(0);
          ESLVal $21 = _v2.termRef(1);
          ESLVal $20 = _v2.termRef(2);
          
          {ESLVal e = $22;
          
          {ESLVal arms = $21;
          
          {ESLVal alt = $20;
          
          return new ESLVal("JCaseStr",renameJVarsExp.apply(e,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v17 = $qualArg;
                
                switch(_v17.termName) {
                case "JSArm": {ESLVal $75 = _v17.termRef(0);
                  ESLVal $74 = _v17.termRef(1);
                  
                  {ESLVal s = $75;
                  
                  {ESLVal _v76 = $74;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JSArm",s,renameJVarsCommand.apply(_v76,vars,env))));
                }
                }
                }
                default: {ESLVal _0 = _v17;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten(),renameJVarsCommand.apply(alt,vars,env));
        }
        }
        }
        }
      case "JCaseBool": {ESLVal $19 = _v2.termRef(0);
          ESLVal $18 = _v2.termRef(1);
          ESLVal $17 = _v2.termRef(2);
          
          {ESLVal e = $19;
          
          {ESLVal arms = $18;
          
          {ESLVal alt = $17;
          
          return new ESLVal("JCaseBool",renameJVarsExp.apply(e,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v16 = $qualArg;
                
                switch(_v16.termName) {
                case "JBArm": {ESLVal $73 = _v16.termRef(0);
                  ESLVal $72 = _v16.termRef(1);
                  
                  {ESLVal b = $73;
                  
                  {ESLVal _v75 = $72;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JBArm",b,renameJVarsCommand.apply(_v75,vars,env))));
                }
                }
                }
                default: {ESLVal _0 = _v16;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten(),renameJVarsCommand.apply(alt,vars,env));
        }
        }
        }
        }
      case "JCaseTerm": {ESLVal $16 = _v2.termRef(0);
          ESLVal $15 = _v2.termRef(1);
          ESLVal $14 = _v2.termRef(2);
          
          {ESLVal e = $16;
          
          {ESLVal arms = $15;
          
          {ESLVal alt = $14;
          
          return new ESLVal("JCaseTerm",renameJVarsExp.apply(e,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v15 = $qualArg;
                
                switch(_v15.termName) {
                case "JTArm": {ESLVal $71 = _v15.termRef(0);
                  ESLVal $70 = _v15.termRef(1);
                  ESLVal $69 = _v15.termRef(2);
                  
                  {ESLVal n = $71;
                  
                  {ESLVal i = $70;
                  
                  {ESLVal _v74 = $69;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JTArm",n,i,renameJVarsCommand.apply(_v74,vars,env))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v15;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten(),renameJVarsCommand.apply(alt,vars,env));
        }
        }
        }
        }
      case "JLet": {ESLVal $13 = _v2.termRef(0);
          ESLVal $12 = _v2.termRef(1);
          
          {ESLVal v0 = $13;
          
          {ESLVal v1 = $12;
          
          {ESLVal boundNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v11 = $qualArg;
                  
                  switch(_v11.termName) {
                  case "JField": {ESLVal $62 = _v11.termRef(0);
                    ESLVal $61 = _v11.termRef(1);
                    ESLVal $60 = _v11.termRef(2);
                    
                    {ESLVal n = $62;
                    
                    {ESLVal t = $61;
                    
                    {ESLVal e = $60;
                    
                    return ESLVal.list(ESLVal.list(n));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v11;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten();
          
          if(exists.apply(new ESLVal(new Function(new ESLVal("fun2951"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal n = $args[0];
        return member.apply(n,vars);
          }
        }),boundNames).boolVal)
          {ESLVal newNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v12 = $qualArg;
                    
                    {ESLVal n = _v12;
                    
                    return ESLVal.list(ESLVal.list(newName.apply()));
                  }
                  }
                }
              }).map(boundNames).flatten().flatten();
            
            {ESLVal env1 = addEntries.apply(boundNames,newNames,env);
            
            return new ESLVal("JLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v13 = $qualArg;
                  
                  switch(_v13.termName) {
                  case "JField": {ESLVal $65 = _v13.termRef(0);
                    ESLVal $64 = _v13.termRef(1);
                    ESLVal $63 = _v13.termRef(2);
                    
                    {ESLVal n = $65;
                    
                    {ESLVal t = $64;
                    
                    {ESLVal e = $63;
                    
                    return ESLVal.list(ESLVal.list(new ESLVal("JField",lookup.apply(n,env1),t,renameJVarsExp.apply(e,vars,env))));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v13;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten(),renameJVarsCommand.apply(v1,boundNames.add(vars),env1));
          }
          }
          else
            return new ESLVal("JLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v14 = $qualArg;
                    
                    switch(_v14.termName) {
                    case "JField": {ESLVal $68 = _v14.termRef(0);
                      ESLVal $67 = _v14.termRef(1);
                      ESLVal $66 = _v14.termRef(2);
                      
                      {ESLVal n = $68;
                      
                      {ESLVal t = $67;
                      
                      {ESLVal e = $66;
                      
                      return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(e,vars,env))));
                    }
                    }
                    }
                    }
                    default: {ESLVal _0 = _v14;
                      
                      return ESLVal.list();
                    }
                  }
                  }
                }
              }).map(v0).flatten().flatten(),renameJVarsCommand.apply(v1,boundNames.add(vars),env));
        }
        }
        }
        }
      case "JPLet": {ESLVal $11 = _v2.termRef(0);
          ESLVal $10 = _v2.termRef(1);
          
          {ESLVal v0 = $11;
          
          {ESLVal v1 = $10;
          
          {ESLVal boundNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v7 = $qualArg;
                  
                  switch(_v7.termName) {
                  case "JField": {ESLVal $53 = _v7.termRef(0);
                    ESLVal $52 = _v7.termRef(1);
                    ESLVal $51 = _v7.termRef(2);
                    
                    {ESLVal n = $53;
                    
                    {ESLVal t = $52;
                    
                    {ESLVal e = $51;
                    
                    return ESLVal.list(ESLVal.list(n));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v7;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten();
          
          if(exists.apply(new ESLVal(new Function(new ESLVal("fun2952"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal n = $args[0];
        return member.apply(n,vars);
          }
        }),boundNames).boolVal)
          {ESLVal newNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v8 = $qualArg;
                    
                    {ESLVal n = _v8;
                    
                    return ESLVal.list(ESLVal.list(newName.apply()));
                  }
                  }
                }
              }).map(boundNames).flatten().flatten();
            
            {ESLVal env1 = addEntries.apply(boundNames,newNames,env);
            
            return new ESLVal("JPLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v9 = $qualArg;
                  
                  switch(_v9.termName) {
                  case "JField": {ESLVal $56 = _v9.termRef(0);
                    ESLVal $55 = _v9.termRef(1);
                    ESLVal $54 = _v9.termRef(2);
                    
                    {ESLVal n = $56;
                    
                    {ESLVal t = $55;
                    
                    {ESLVal e = $54;
                    
                    return ESLVal.list(ESLVal.list(new ESLVal("JField",lookup.apply(n,env1),t,renameJVarsExp.apply(e,vars,env))));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v9;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten(),renameJVarsCommand.apply(v1,boundNames.add(vars),env1));
          }
          }
          else
            return new ESLVal("JPLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v10 = $qualArg;
                    
                    switch(_v10.termName) {
                    case "JField": {ESLVal $59 = _v10.termRef(0);
                      ESLVal $58 = _v10.termRef(1);
                      ESLVal $57 = _v10.termRef(2);
                      
                      {ESLVal n = $59;
                      
                      {ESLVal t = $58;
                      
                      {ESLVal e = $57;
                      
                      return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(e,vars,env))));
                    }
                    }
                    }
                    }
                    default: {ESLVal _0 = _v10;
                      
                      return ESLVal.list();
                    }
                  }
                  }
                }
              }).map(v0).flatten().flatten(),renameJVarsCommand.apply(v1,boundNames.add(vars),env));
        }
        }
        }
        }
      case "JLetRec": {ESLVal $9 = _v2.termRef(0);
          ESLVal $8 = _v2.termRef(1);
          
          {ESLVal v0 = $9;
          
          {ESLVal v1 = $8;
          
          {ESLVal boundNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v3 = $qualArg;
                  
                  switch(_v3.termName) {
                  case "JField": {ESLVal $44 = _v3.termRef(0);
                    ESLVal $43 = _v3.termRef(1);
                    ESLVal $42 = _v3.termRef(2);
                    
                    {ESLVal n = $44;
                    
                    {ESLVal t = $43;
                    
                    {ESLVal e = $42;
                    
                    return ESLVal.list(ESLVal.list(n));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v3;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten();
          
          if(exists.apply(new ESLVal(new Function(new ESLVal("fun2953"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal n = $args[0];
        return member.apply(n,vars);
          }
        }),boundNames).boolVal)
          {ESLVal newNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v4 = $qualArg;
                    
                    {ESLVal n = _v4;
                    
                    return ESLVal.list(ESLVal.list(newName.apply()));
                  }
                  }
                }
              }).map(boundNames).flatten().flatten();
            
            {ESLVal _v73 = addEntries.apply(boundNames,newNames,env);
            
            return new ESLVal("JLetRec",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v5 = $qualArg;
                  
                  switch(_v5.termName) {
                  case "JField": {ESLVal $47 = _v5.termRef(0);
                    ESLVal $46 = _v5.termRef(1);
                    ESLVal $45 = _v5.termRef(2);
                    
                    {ESLVal n = $47;
                    
                    {ESLVal t = $46;
                    
                    {ESLVal e = $45;
                    
                    return ESLVal.list(ESLVal.list(new ESLVal("JField",lookup.apply(n,_v73),t,renameJVarsExp.apply(e,vars,_v73))));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v5;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten(),renameJVarsCommand.apply(v1,boundNames.add(vars),_v73));
          }
          }
          else
            return new ESLVal("JLetRec",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v6 = $qualArg;
                    
                    switch(_v6.termName) {
                    case "JField": {ESLVal $50 = _v6.termRef(0);
                      ESLVal $49 = _v6.termRef(1);
                      ESLVal $48 = _v6.termRef(2);
                      
                      {ESLVal n = $50;
                      
                      {ESLVal t = $49;
                      
                      {ESLVal e = $48;
                      
                      return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(e,vars,env))));
                    }
                    }
                    }
                    }
                    default: {ESLVal _0 = _v6;
                      
                      return ESLVal.list();
                    }
                  }
                  }
                }
              }).map(v0).flatten().flatten(),renameJVarsCommand.apply(v1,boundNames.add(vars),env));
        }
        }
        }
        }
      case "JStatement": {ESLVal $7 = _v2.termRef(0);
          
          {ESLVal e = $7;
          
          return new ESLVal("JStatement",renameJVarsExp.apply(e,vars,env));
        }
        }
      case "JUpdate": {ESLVal $6 = _v2.termRef(0);
          ESLVal $5 = _v2.termRef(1);
          
          {ESLVal name = $6;
          
          {ESLVal value = $5;
          
          if(hasEntry.apply(name,env).boolVal)
          return new ESLVal("JUpdate",lookup.apply(name,env),renameJVarsExp.apply(value,vars,env));
          else
            {ESLVal v0 = $6;
              
              {ESLVal v1 = $5;
              
              return new ESLVal("JUpdate",v0,renameJVarsExp.apply(v1,vars,env));
            }
            }
        }
        }
        }
      case "JFor": {ESLVal $4 = _v2.termRef(0);
          ESLVal $3 = _v2.termRef(1);
          ESLVal $2 = _v2.termRef(2);
          ESLVal $1 = _v2.termRef(3);
          
          {ESLVal l = $4;
          
          {ESLVal n = $3;
          
          {ESLVal e = $2;
          
          {ESLVal _v72 = $1;
          
          return new ESLVal("JFor",l,n,renameJVarsExp.apply(e,vars,env),renameJVarsCommand.apply(_v72,vars,env));
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(23653,28061)").add(ESLVal.list(_v2)));
      }
      }
    }
  });
  public static ESLVal main = new ESLVal(new Function(new ESLVal("main"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      return new ESLVal(new BehaviourAdapter(true,getSelf(),new ESLVal("main")) {
          
          public ESLVal handle(ESLVal $m) {{ESLVal _v1 = $m;
            
            return error(new ESLVal("case error at Pos(0,0)").add(ESLVal.list(_v1)));
          }}
          public ESLVal get(String name) {
            switch(name) {
              
              default: throw new Error("ref illegal " + self + "." + name);
            }
          }
        public void handleTime(ESLVal $t) {
          {ESLVal n = $t;
            
            if($true.boolVal)
            {print.apply(new ESLVal("").add(emptyTable));
            stopAll.apply();}
            else
              {}
          }
        }
        public ESLVal init() {
            return $null;
          }
        });
    }
  });
public static void main(String[] args) {
    newActor(main,new ESLVal(new Actor())); 
  }
}