package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
// import static esl.Lists.*;
import java.util.function.Supplier;
public class Types {
  public static ESLVal getSelf() { return $null; }
  public static ESLVal locStart = new ESLVal(new Function(new ESLVal("locStart"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  {ESLVal _v78 = l;
        
        switch(_v78.termName) {
        case "Pos": {ESLVal $661 = _v78.termRef(0);
          ESLVal $660 = _v78.termRef(1);
          
          {ESLVal start = $661;
          
          {ESLVal end = $660;
          
          return start;
        }
        }
        }
      case "TypedLoc": {ESLVal $659 = _v78.termRef(0);
          ESLVal $658 = _v78.termRef(1);
          ESLVal $657 = _v78.termRef(2);
          
          {ESLVal t = $659;
          
          {ESLVal start = $658;
          
          {ESLVal end = $657;
          
          return start;
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(5784,5868)").add(ESLVal.list(_v78)));
      }
      }
    }
  });
  public static ESLVal locEnd = new ESLVal(new Function(new ESLVal("locEnd"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  {ESLVal _v77 = l;
        
        switch(_v77.termName) {
        case "Pos": {ESLVal $656 = _v77.termRef(0);
          ESLVal $655 = _v77.termRef(1);
          
          {ESLVal start = $656;
          
          {ESLVal end = $655;
          
          return end;
        }
        }
        }
      case "TypedLoc": {ESLVal $654 = _v77.termRef(0);
          ESLVal $653 = _v77.termRef(1);
          ESLVal $652 = _v77.termRef(2);
          
          {ESLVal t = $654;
          
          {ESLVal start = $653;
          
          {ESLVal end = $652;
          
          return end;
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(5895,5975)").add(ESLVal.list(_v77)));
      }
      }
    }
  });
  public static ESLVal decName = new ESLVal(new Function(new ESLVal("decName"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d = $args[0];
  {ESLVal _v76 = d;
        
        switch(_v76.termName) {
        case "Dec": {ESLVal $651 = _v76.termRef(0);
          ESLVal $650 = _v76.termRef(1);
          ESLVal $649 = _v76.termRef(2);
          ESLVal $648 = _v76.termRef(3);
          
          {ESLVal l = $651;
          
          {ESLVal n = $650;
          
          {ESLVal t = $649;
          
          {ESLVal dt = $648;
          
          return n;
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(6297,6419)").add(ESLVal.list(_v76)));
      }
      }
    }
  });
  public static ESLVal decLoc = new ESLVal(new Function(new ESLVal("decLoc"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d = $args[0];
  {ESLVal _v75 = d;
        
        switch(_v75.termName) {
        case "Dec": {ESLVal $647 = _v75.termRef(0);
          ESLVal $646 = _v75.termRef(1);
          ESLVal $645 = _v75.termRef(2);
          ESLVal $644 = _v75.termRef(3);
          
          {ESLVal l = $647;
          
          {ESLVal n = $646;
          
          {ESLVal t = $645;
          
          {ESLVal dt = $644;
          
          return l;
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(6523,6581)").add(ESLVal.list(_v75)));
      }
      }
    }
  });
  public static ESLVal decType = new ESLVal(new Function(new ESLVal("decType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d = $args[0];
  {ESLVal _v74 = d;
        
        switch(_v74.termName) {
        case "Dec": {ESLVal $643 = _v74.termRef(0);
          ESLVal $642 = _v74.termRef(1);
          ESLVal $641 = _v74.termRef(2);
          ESLVal $640 = _v74.termRef(3);
          
          {ESLVal l = $643;
          
          {ESLVal n = $642;
          
          {ESLVal t = $641;
          
          {ESLVal dt = $640;
          
          return t;
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(6681,6739)").add(ESLVal.list(_v74)));
      }
      }
    }
  });
  public static ESLVal isStrType = new ESLVal(new Function(new ESLVal("isStrType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v73 = t;
        
        switch(_v73.termName) {
        case "StrType": {ESLVal $639 = _v73.termRef(0);
          
          {ESLVal l = $639;
          
          return $true;
        }
        }
        default: {ESLVal _v596 = _v73;
          
          return $false;
        }
      }
      }
    }
  });
  public static ESLVal isIntType = new ESLVal(new Function(new ESLVal("isIntType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v72 = t;
        
        switch(_v72.termName) {
        case "IntType": {ESLVal $638 = _v72.termRef(0);
          
          {ESLVal l = $638;
          
          return $true;
        }
        }
        default: {ESLVal _v595 = _v72;
          
          return $false;
        }
      }
      }
    }
  });
  public static ESLVal isNumType = new ESLVal(new Function(new ESLVal("isNumType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v71 = t;
        
        switch(_v71.termName) {
        case "IntType": {ESLVal $637 = _v71.termRef(0);
          
          {ESLVal l = $637;
          
          return $true;
        }
        }
      case "FloatType": {ESLVal $636 = _v71.termRef(0);
          
          {ESLVal l = $636;
          
          return $true;
        }
        }
        default: {ESLVal _v594 = _v71;
          
          return $false;
        }
      }
      }
    }
  });
  public static ESLVal isBoolType = new ESLVal(new Function(new ESLVal("isBoolType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v70 = t;
        
        switch(_v70.termName) {
        case "BoolType": {ESLVal $635 = _v70.termRef(0);
          
          {ESLVal l = $635;
          
          return $true;
        }
        }
        default: {ESLVal _v593 = _v70;
          
          return $false;
        }
      }
      }
    }
  });
  public static ESLVal isFloatType = new ESLVal(new Function(new ESLVal("isFloatType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v69 = t;
        
        switch(_v69.termName) {
        case "FloatType": {ESLVal $634 = _v69.termRef(0);
          
          {ESLVal l = $634;
          
          return $true;
        }
        }
        default: {ESLVal _v592 = _v69;
          
          return $false;
        }
      }
      }
    }
  });
  public static ESLVal typeEqual = new ESLVal(new Function(new ESLVal("typeEqual"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t1 = $args[0];
  ESLVal t2 = $args[1];
  {ESLVal b = typeEqual1.apply(t1,t2);
        
        return b;
      }
    }
  });
  public static ESLVal typeEqual1 = new ESLVal(new Function(new ESLVal("typeEqual1"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t1 = $args[0];
  ESLVal t2 = $args[1];
  if(t1.eql(t2).boolVal)
        return $true;
        else
          {ESLVal _v68 = t1;
            ESLVal _v67 = t2;
            
            switch(_v68.termName) {
            case "ArrayType": {ESLVal $631 = _v68.termRef(0);
              ESLVal $630 = _v68.termRef(1);
              
              switch(_v67.termName) {
              case "ArrayType": {ESLVal $633 = _v67.termRef(0);
                ESLVal $632 = _v67.termRef(1);
                
                {ESLVal l1 = $631;
                
                {ESLVal _v568 = $630;
                
                {ESLVal l2 = $633;
                
                {ESLVal _v569 = $632;
                
                return typeEqual.apply(_v568,_v569);
              }
              }
              }
              }
              }
              default: switch(_v67.termName) {
                case "ApplyTypeFun": {ESLVal $505 = _v67.termRef(0);
                  ESLVal $504 = _v67.termRef(1);
                  ESLVal $503 = _v67.termRef(2);
                  
                  {ESLVal _v578 = _v68;
                  
                  {ESLVal l = $505;
                  
                  {ESLVal op = $504;
                  
                  {ESLVal args = $503;
                  
                  return typeEqual.apply(_v578,applyTypeFun.apply(l,forceType.apply(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $502 = _v67.termRef(0);
                  ESLVal $501 = _v67.termRef(1);
                  ESLVal $500 = _v67.termRef(2);
                  ESLVal $499 = _v67.termRef(3);
                  
                  {ESLVal _v576 = _v68;
                  
                  {ESLVal l2 = $502;
                  
                  {ESLVal _v577 = $501;
                  
                  {ESLVal ds2 = $500;
                  
                  {ESLVal ms2 = $499;
                  
                  return typeEqual.apply(_v576,flattenAct.apply(l2,_v577,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $498 = _v67.termRef(0);
                  
                  {ESLVal t = _v68;
                  
                  {ESLVal l1 = $498;
                  
                  return $true;
                }
                }
                }
              case "TermType": {ESLVal $497 = _v67.termRef(0);
                  ESLVal $496 = _v67.termRef(1);
                  ESLVal $495 = _v67.termRef(2);
                  
                  {ESLVal _v575 = _v68;
                  
                  {ESLVal l2 = $497;
                  
                  {ESLVal n2 = $496;
                  
                  {ESLVal args2 = $495;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $494 = _v67.termRef(0);
                  
                  {ESLVal _v574 = _v68;
                  
                  {ESLVal f = $494;
                  
                  return typeEqual.apply(_v574,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $493 = _v67.termRef(0);
                  ESLVal $492 = _v67.termRef(1);
                  ESLVal $491 = _v67.termRef(2);
                  
                  {ESLVal _v572 = _v68;
                  
                  {ESLVal l2 = $493;
                  
                  {ESLVal n2 = $492;
                  
                  {ESLVal _v573 = $491;
                  
                  return typeEqual.apply(_v572,substType.apply(new ESLVal("RecType",l2,n2,_v573),n2,_v573));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $490 = _v67.termRef(0);
                  ESLVal $489 = _v67.termRef(1);
                  ESLVal $488 = _v67.termRef(2);
                  
                  {ESLVal _v570 = _v68;
                  
                  {ESLVal l1 = $490;
                  
                  {ESLVal ns2 = $489;
                  
                  {ESLVal _v571 = $488;
                  
                  return typeEqual.apply(_v570,_v571);
                }
                }
                }
                }
                }
                default: {ESLVal _v579 = _v68;
                  
                  {ESLVal _v580 = _v67;
                  
                  return $false;
                }
                }
              }
            }
            }
          case "ActType": {ESLVal $626 = _v68.termRef(0);
              ESLVal $625 = _v68.termRef(1);
              ESLVal $624 = _v68.termRef(2);
              
              switch(_v67.termName) {
              case "ActType": {ESLVal $629 = _v67.termRef(0);
                ESLVal $628 = _v67.termRef(1);
                ESLVal $627 = _v67.termRef(2);
                
                {ESLVal l1 = $626;
                
                {ESLVal exports1 = $625;
                
                {ESLVal handlers1 = $624;
                
                {ESLVal l2 = $629;
                
                {ESLVal exports2 = $628;
                
                {ESLVal handlers2 = $627;
                
                return actEqual.apply(exports1,exports2,handlers1,handlers2);
              }
              }
              }
              }
              }
              }
              }
              default: switch(_v67.termName) {
                case "ApplyTypeFun": {ESLVal $505 = _v67.termRef(0);
                  ESLVal $504 = _v67.termRef(1);
                  ESLVal $503 = _v67.termRef(2);
                  
                  {ESLVal _v565 = _v68;
                  
                  {ESLVal l = $505;
                  
                  {ESLVal op = $504;
                  
                  {ESLVal args = $503;
                  
                  return typeEqual.apply(_v565,applyTypeFun.apply(l,forceType.apply(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $502 = _v67.termRef(0);
                  ESLVal $501 = _v67.termRef(1);
                  ESLVal $500 = _v67.termRef(2);
                  ESLVal $499 = _v67.termRef(3);
                  
                  {ESLVal _v563 = _v68;
                  
                  {ESLVal l2 = $502;
                  
                  {ESLVal _v564 = $501;
                  
                  {ESLVal ds2 = $500;
                  
                  {ESLVal ms2 = $499;
                  
                  return typeEqual.apply(_v563,flattenAct.apply(l2,_v564,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $498 = _v67.termRef(0);
                  
                  {ESLVal t = _v68;
                  
                  {ESLVal l1 = $498;
                  
                  return $true;
                }
                }
                }
              case "TermType": {ESLVal $497 = _v67.termRef(0);
                  ESLVal $496 = _v67.termRef(1);
                  ESLVal $495 = _v67.termRef(2);
                  
                  {ESLVal _v562 = _v68;
                  
                  {ESLVal l2 = $497;
                  
                  {ESLVal n2 = $496;
                  
                  {ESLVal args2 = $495;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $494 = _v67.termRef(0);
                  
                  {ESLVal _v561 = _v68;
                  
                  {ESLVal f = $494;
                  
                  return typeEqual.apply(_v561,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $493 = _v67.termRef(0);
                  ESLVal $492 = _v67.termRef(1);
                  ESLVal $491 = _v67.termRef(2);
                  
                  {ESLVal _v559 = _v68;
                  
                  {ESLVal l2 = $493;
                  
                  {ESLVal n2 = $492;
                  
                  {ESLVal _v560 = $491;
                  
                  return typeEqual.apply(_v559,substType.apply(new ESLVal("RecType",l2,n2,_v560),n2,_v560));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $490 = _v67.termRef(0);
                  ESLVal $489 = _v67.termRef(1);
                  ESLVal $488 = _v67.termRef(2);
                  
                  {ESLVal _v557 = _v68;
                  
                  {ESLVal l1 = $490;
                  
                  {ESLVal ns2 = $489;
                  
                  {ESLVal _v558 = $488;
                  
                  return typeEqual.apply(_v557,_v558);
                }
                }
                }
                }
                }
                default: {ESLVal _v566 = _v68;
                  
                  {ESLVal _v567 = _v67;
                  
                  return $false;
                }
                }
              }
            }
            }
          case "ApplyTypeFun": {ESLVal $620 = _v68.termRef(0);
              ESLVal $619 = _v68.termRef(1);
              ESLVal $618 = _v68.termRef(2);
              
              switch(_v67.termName) {
              case "ApplyTypeFun": {ESLVal $623 = _v67.termRef(0);
                ESLVal $622 = _v67.termRef(1);
                ESLVal $621 = _v67.termRef(2);
                
                {ESLVal l1 = $620;
                
                {ESLVal op1 = $619;
                
                {ESLVal args1 = $618;
                
                {ESLVal l2 = $623;
                
                {ESLVal op2 = $622;
                
                {ESLVal args2 = $621;
                
                return typeEqual.apply(op1,op2).and(typesEqual.apply(args1,args2));
              }
              }
              }
              }
              }
              }
              }
              default: {ESLVal l = $620;
                
                {ESLVal op = $619;
                
                {ESLVal args = $618;
                
                {ESLVal _v556 = _v67;
                
                return typeEqual.apply(applyTypeFun.apply(l,forceType.apply(op),args),_v556);
              }
              }
              }
              }
            }
            }
          case "ExtendedAct": {ESLVal $617 = _v68.termRef(0);
              ESLVal $616 = _v68.termRef(1);
              ESLVal $615 = _v68.termRef(2);
              ESLVal $614 = _v68.termRef(3);
              
              {ESLVal l1 = $617;
              
              {ESLVal _v554 = $616;
              
              {ESLVal ds1 = $615;
              
              {ESLVal ms1 = $614;
              
              {ESLVal _v555 = _v67;
              
              return typeEqual.apply(flattenAct.apply(l1,_v554,ds1,ms1),_v555);
            }
            }
            }
            }
            }
            }
          case "BoolType": {ESLVal $612 = _v68.termRef(0);
              
              switch(_v67.termName) {
              case "BoolType": {ESLVal $613 = _v67.termRef(0);
                
                {ESLVal l1 = $612;
                
                {ESLVal l2 = $613;
                
                return $true;
              }
              }
              }
              default: switch(_v67.termName) {
                case "ApplyTypeFun": {ESLVal $505 = _v67.termRef(0);
                  ESLVal $504 = _v67.termRef(1);
                  ESLVal $503 = _v67.termRef(2);
                  
                  {ESLVal _v551 = _v68;
                  
                  {ESLVal l = $505;
                  
                  {ESLVal op = $504;
                  
                  {ESLVal args = $503;
                  
                  return typeEqual.apply(_v551,applyTypeFun.apply(l,forceType.apply(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $502 = _v67.termRef(0);
                  ESLVal $501 = _v67.termRef(1);
                  ESLVal $500 = _v67.termRef(2);
                  ESLVal $499 = _v67.termRef(3);
                  
                  {ESLVal _v549 = _v68;
                  
                  {ESLVal l2 = $502;
                  
                  {ESLVal _v550 = $501;
                  
                  {ESLVal ds2 = $500;
                  
                  {ESLVal ms2 = $499;
                  
                  return typeEqual.apply(_v549,flattenAct.apply(l2,_v550,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $498 = _v67.termRef(0);
                  
                  {ESLVal t = _v68;
                  
                  {ESLVal l1 = $498;
                  
                  return $true;
                }
                }
                }
              case "TermType": {ESLVal $497 = _v67.termRef(0);
                  ESLVal $496 = _v67.termRef(1);
                  ESLVal $495 = _v67.termRef(2);
                  
                  {ESLVal _v548 = _v68;
                  
                  {ESLVal l2 = $497;
                  
                  {ESLVal n2 = $496;
                  
                  {ESLVal args2 = $495;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $494 = _v67.termRef(0);
                  
                  {ESLVal _v547 = _v68;
                  
                  {ESLVal f = $494;
                  
                  return typeEqual.apply(_v547,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $493 = _v67.termRef(0);
                  ESLVal $492 = _v67.termRef(1);
                  ESLVal $491 = _v67.termRef(2);
                  
                  {ESLVal _v545 = _v68;
                  
                  {ESLVal l2 = $493;
                  
                  {ESLVal n2 = $492;
                  
                  {ESLVal _v546 = $491;
                  
                  return typeEqual.apply(_v545,substType.apply(new ESLVal("RecType",l2,n2,_v546),n2,_v546));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $490 = _v67.termRef(0);
                  ESLVal $489 = _v67.termRef(1);
                  ESLVal $488 = _v67.termRef(2);
                  
                  {ESLVal _v543 = _v68;
                  
                  {ESLVal l1 = $490;
                  
                  {ESLVal ns2 = $489;
                  
                  {ESLVal _v544 = $488;
                  
                  return typeEqual.apply(_v543,_v544);
                }
                }
                }
                }
                }
                default: {ESLVal _v552 = _v68;
                  
                  {ESLVal _v553 = _v67;
                  
                  return $false;
                }
                }
              }
            }
            }
          case "FloatType": {ESLVal $610 = _v68.termRef(0);
              
              switch(_v67.termName) {
              case "FloatType": {ESLVal $611 = _v67.termRef(0);
                
                {ESLVal l1 = $610;
                
                {ESLVal l2 = $611;
                
                return $true;
              }
              }
              }
              default: switch(_v67.termName) {
                case "ApplyTypeFun": {ESLVal $505 = _v67.termRef(0);
                  ESLVal $504 = _v67.termRef(1);
                  ESLVal $503 = _v67.termRef(2);
                  
                  {ESLVal _v540 = _v68;
                  
                  {ESLVal l = $505;
                  
                  {ESLVal op = $504;
                  
                  {ESLVal args = $503;
                  
                  return typeEqual.apply(_v540,applyTypeFun.apply(l,forceType.apply(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $502 = _v67.termRef(0);
                  ESLVal $501 = _v67.termRef(1);
                  ESLVal $500 = _v67.termRef(2);
                  ESLVal $499 = _v67.termRef(3);
                  
                  {ESLVal _v538 = _v68;
                  
                  {ESLVal l2 = $502;
                  
                  {ESLVal _v539 = $501;
                  
                  {ESLVal ds2 = $500;
                  
                  {ESLVal ms2 = $499;
                  
                  return typeEqual.apply(_v538,flattenAct.apply(l2,_v539,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $498 = _v67.termRef(0);
                  
                  {ESLVal t = _v68;
                  
                  {ESLVal l1 = $498;
                  
                  return $true;
                }
                }
                }
              case "TermType": {ESLVal $497 = _v67.termRef(0);
                  ESLVal $496 = _v67.termRef(1);
                  ESLVal $495 = _v67.termRef(2);
                  
                  {ESLVal _v537 = _v68;
                  
                  {ESLVal l2 = $497;
                  
                  {ESLVal n2 = $496;
                  
                  {ESLVal args2 = $495;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $494 = _v67.termRef(0);
                  
                  {ESLVal _v536 = _v68;
                  
                  {ESLVal f = $494;
                  
                  return typeEqual.apply(_v536,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $493 = _v67.termRef(0);
                  ESLVal $492 = _v67.termRef(1);
                  ESLVal $491 = _v67.termRef(2);
                  
                  {ESLVal _v534 = _v68;
                  
                  {ESLVal l2 = $493;
                  
                  {ESLVal n2 = $492;
                  
                  {ESLVal _v535 = $491;
                  
                  return typeEqual.apply(_v534,substType.apply(new ESLVal("RecType",l2,n2,_v535),n2,_v535));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $490 = _v67.termRef(0);
                  ESLVal $489 = _v67.termRef(1);
                  ESLVal $488 = _v67.termRef(2);
                  
                  {ESLVal _v532 = _v68;
                  
                  {ESLVal l1 = $490;
                  
                  {ESLVal ns2 = $489;
                  
                  {ESLVal _v533 = $488;
                  
                  return typeEqual.apply(_v532,_v533);
                }
                }
                }
                }
                }
                default: {ESLVal _v541 = _v68;
                  
                  {ESLVal _v542 = _v67;
                  
                  return $false;
                }
                }
              }
            }
            }
          case "IntType": {ESLVal $608 = _v68.termRef(0);
              
              switch(_v67.termName) {
              case "IntType": {ESLVal $609 = _v67.termRef(0);
                
                {ESLVal l1 = $608;
                
                {ESLVal l2 = $609;
                
                return $true;
              }
              }
              }
              default: switch(_v67.termName) {
                case "ApplyTypeFun": {ESLVal $505 = _v67.termRef(0);
                  ESLVal $504 = _v67.termRef(1);
                  ESLVal $503 = _v67.termRef(2);
                  
                  {ESLVal _v529 = _v68;
                  
                  {ESLVal l = $505;
                  
                  {ESLVal op = $504;
                  
                  {ESLVal args = $503;
                  
                  return typeEqual.apply(_v529,applyTypeFun.apply(l,forceType.apply(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $502 = _v67.termRef(0);
                  ESLVal $501 = _v67.termRef(1);
                  ESLVal $500 = _v67.termRef(2);
                  ESLVal $499 = _v67.termRef(3);
                  
                  {ESLVal _v527 = _v68;
                  
                  {ESLVal l2 = $502;
                  
                  {ESLVal _v528 = $501;
                  
                  {ESLVal ds2 = $500;
                  
                  {ESLVal ms2 = $499;
                  
                  return typeEqual.apply(_v527,flattenAct.apply(l2,_v528,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $498 = _v67.termRef(0);
                  
                  {ESLVal t = _v68;
                  
                  {ESLVal l1 = $498;
                  
                  return $true;
                }
                }
                }
              case "TermType": {ESLVal $497 = _v67.termRef(0);
                  ESLVal $496 = _v67.termRef(1);
                  ESLVal $495 = _v67.termRef(2);
                  
                  {ESLVal _v526 = _v68;
                  
                  {ESLVal l2 = $497;
                  
                  {ESLVal n2 = $496;
                  
                  {ESLVal args2 = $495;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $494 = _v67.termRef(0);
                  
                  {ESLVal _v525 = _v68;
                  
                  {ESLVal f = $494;
                  
                  return typeEqual.apply(_v525,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $493 = _v67.termRef(0);
                  ESLVal $492 = _v67.termRef(1);
                  ESLVal $491 = _v67.termRef(2);
                  
                  {ESLVal _v523 = _v68;
                  
                  {ESLVal l2 = $493;
                  
                  {ESLVal n2 = $492;
                  
                  {ESLVal _v524 = $491;
                  
                  return typeEqual.apply(_v523,substType.apply(new ESLVal("RecType",l2,n2,_v524),n2,_v524));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $490 = _v67.termRef(0);
                  ESLVal $489 = _v67.termRef(1);
                  ESLVal $488 = _v67.termRef(2);
                  
                  {ESLVal _v521 = _v68;
                  
                  {ESLVal l1 = $490;
                  
                  {ESLVal ns2 = $489;
                  
                  {ESLVal _v522 = $488;
                  
                  return typeEqual.apply(_v521,_v522);
                }
                }
                }
                }
                }
                default: {ESLVal _v530 = _v68;
                  
                  {ESLVal _v531 = _v67;
                  
                  return $false;
                }
                }
              }
            }
            }
          case "ListType": {ESLVal $594 = _v68.termRef(0);
              ESLVal $593 = _v68.termRef(1);
              
              switch(_v67.termName) {
              case "ListType": {ESLVal $607 = _v67.termRef(0);
                ESLVal $606 = _v67.termRef(1);
                
                {ESLVal l1 = $594;
                
                {ESLVal _v508 = $593;
                
                {ESLVal l2 = $607;
                
                {ESLVal _v509 = $606;
                
                return typeEqual.apply(_v508,_v509);
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $597 = _v67.termRef(0);
                ESLVal $596 = _v67.termRef(1);
                ESLVal $595 = _v67.termRef(2);
                
                if($596.isCons())
                {ESLVal $598 = $596.head();
                  ESLVal $599 = $596.tail();
                  
                  if($599.isCons())
                  {ESLVal $600 = $599.head();
                    ESLVal $601 = $599.tail();
                    
                    switch(_v67.termName) {
                    case "ApplyTypeFun": {ESLVal $505 = _v67.termRef(0);
                      ESLVal $504 = _v67.termRef(1);
                      ESLVal $503 = _v67.termRef(2);
                      
                      {ESLVal _v433 = _v68;
                      
                      {ESLVal l = $505;
                      
                      {ESLVal op = $504;
                      
                      {ESLVal args = $503;
                      
                      return typeEqual.apply(_v433,applyTypeFun.apply(l,forceType.apply(op),args));
                    }
                    }
                    }
                    }
                    }
                  case "ExtendedAct": {ESLVal $502 = _v67.termRef(0);
                      ESLVal $501 = _v67.termRef(1);
                      ESLVal $500 = _v67.termRef(2);
                      ESLVal $499 = _v67.termRef(3);
                      
                      {ESLVal _v431 = _v68;
                      
                      {ESLVal l2 = $502;
                      
                      {ESLVal _v432 = $501;
                      
                      {ESLVal ds2 = $500;
                      
                      {ESLVal ms2 = $499;
                      
                      return typeEqual.apply(_v431,flattenAct.apply(l2,_v432,ds2,ms2));
                    }
                    }
                    }
                    }
                    }
                    }
                  case "VoidType": {ESLVal $498 = _v67.termRef(0);
                      
                      {ESLVal t = _v68;
                      
                      {ESLVal l1 = $498;
                      
                      return $true;
                    }
                    }
                    }
                  case "TermType": {ESLVal $497 = _v67.termRef(0);
                      ESLVal $496 = _v67.termRef(1);
                      ESLVal $495 = _v67.termRef(2);
                      
                      {ESLVal _v430 = _v68;
                      
                      {ESLVal l2 = $497;
                      
                      {ESLVal n2 = $496;
                      
                      {ESLVal args2 = $495;
                      
                      return $false;
                    }
                    }
                    }
                    }
                    }
                  case "TypeClosure": {ESLVal $494 = _v67.termRef(0);
                      
                      {ESLVal _v429 = _v68;
                      
                      {ESLVal f = $494;
                      
                      return typeEqual.apply(_v429,f.apply());
                    }
                    }
                    }
                  case "RecType": {ESLVal $493 = _v67.termRef(0);
                      ESLVal $492 = _v67.termRef(1);
                      ESLVal $491 = _v67.termRef(2);
                      
                      {ESLVal _v427 = _v68;
                      
                      {ESLVal l2 = $493;
                      
                      {ESLVal n2 = $492;
                      
                      {ESLVal _v428 = $491;
                      
                      return typeEqual.apply(_v427,substType.apply(new ESLVal("RecType",l2,n2,_v428),n2,_v428));
                    }
                    }
                    }
                    }
                    }
                  case "ForallType": {ESLVal $490 = _v67.termRef(0);
                      ESLVal $489 = _v67.termRef(1);
                      ESLVal $488 = _v67.termRef(2);
                      
                      {ESLVal _v425 = _v68;
                      
                      {ESLVal l1 = $490;
                      
                      {ESLVal ns2 = $489;
                      
                      {ESLVal _v426 = $488;
                      
                      return typeEqual.apply(_v425,_v426);
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal _v434 = _v68;
                      
                      {ESLVal _v435 = _v67;
                      
                      return $false;
                    }
                    }
                  }
                  }
                else if($599.isNil())
                  switch($595.termName) {
                    case "ListType": {ESLVal $603 = $595.termRef(0);
                      ESLVal $602 = $595.termRef(1);
                      
                      switch($602.termName) {
                      case "VarType": {ESLVal $605 = $602.termRef(0);
                        ESLVal $604 = $602.termRef(1);
                        
                        {ESLVal l1 = $594;
                        
                        {ESLVal _v436 = $593;
                        
                        {ESLVal l2 = $597;
                        
                        {ESLVal v1 = $598;
                        
                        {ESLVal l3 = $603;
                        
                        {ESLVal l4 = $605;
                        
                        {ESLVal v2 = $604;
                        
                        if(v1.eql(v2).boolVal)
                        return $true;
                        else
                          switch(_v67.termName) {
                            case "ApplyTypeFun": {ESLVal $505 = _v67.termRef(0);
                              ESLVal $504 = _v67.termRef(1);
                              ESLVal $503 = _v67.termRef(2);
                              
                              {ESLVal _v450 = _v68;
                              
                              {ESLVal l = $505;
                              
                              {ESLVal op = $504;
                              
                              {ESLVal args = $503;
                              
                              return typeEqual.apply(_v450,applyTypeFun.apply(l,forceType.apply(op),args));
                            }
                            }
                            }
                            }
                            }
                          case "ExtendedAct": {ESLVal $502 = _v67.termRef(0);
                              ESLVal $501 = _v67.termRef(1);
                              ESLVal $500 = _v67.termRef(2);
                              ESLVal $499 = _v67.termRef(3);
                              
                              {ESLVal _v447 = _v68;
                              
                              {ESLVal _v448 = $502;
                              
                              {ESLVal _v449 = $501;
                              
                              {ESLVal ds2 = $500;
                              
                              {ESLVal ms2 = $499;
                              
                              return typeEqual.apply(_v447,flattenAct.apply(_v448,_v449,ds2,ms2));
                            }
                            }
                            }
                            }
                            }
                            }
                          case "VoidType": {ESLVal $498 = _v67.termRef(0);
                              
                              {ESLVal t = _v68;
                              
                              {ESLVal _v446 = $498;
                              
                              return $true;
                            }
                            }
                            }
                          case "TermType": {ESLVal $497 = _v67.termRef(0);
                              ESLVal $496 = _v67.termRef(1);
                              ESLVal $495 = _v67.termRef(2);
                              
                              {ESLVal _v444 = _v68;
                              
                              {ESLVal _v445 = $497;
                              
                              {ESLVal n2 = $496;
                              
                              {ESLVal args2 = $495;
                              
                              return $false;
                            }
                            }
                            }
                            }
                            }
                          case "TypeClosure": {ESLVal $494 = _v67.termRef(0);
                              
                              {ESLVal _v443 = _v68;
                              
                              {ESLVal f = $494;
                              
                              return typeEqual.apply(_v443,f.apply());
                            }
                            }
                            }
                          case "RecType": {ESLVal $493 = _v67.termRef(0);
                              ESLVal $492 = _v67.termRef(1);
                              ESLVal $491 = _v67.termRef(2);
                              
                              {ESLVal _v440 = _v68;
                              
                              {ESLVal _v441 = $493;
                              
                              {ESLVal n2 = $492;
                              
                              {ESLVal _v442 = $491;
                              
                              return typeEqual.apply(_v440,substType.apply(new ESLVal("RecType",_v441,n2,_v442),n2,_v442));
                            }
                            }
                            }
                            }
                            }
                          case "ForallType": {ESLVal $490 = _v67.termRef(0);
                              ESLVal $489 = _v67.termRef(1);
                              ESLVal $488 = _v67.termRef(2);
                              
                              {ESLVal _v437 = _v68;
                              
                              {ESLVal _v438 = $490;
                              
                              {ESLVal ns2 = $489;
                              
                              {ESLVal _v439 = $488;
                              
                              return typeEqual.apply(_v437,_v439);
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v451 = _v68;
                              
                              {ESLVal _v452 = _v67;
                              
                              return $false;
                            }
                            }
                          }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      default: switch(_v67.termName) {
                        case "ApplyTypeFun": {ESLVal $505 = _v67.termRef(0);
                          ESLVal $504 = _v67.termRef(1);
                          ESLVal $503 = _v67.termRef(2);
                          
                          {ESLVal _v461 = _v68;
                          
                          {ESLVal l = $505;
                          
                          {ESLVal op = $504;
                          
                          {ESLVal args = $503;
                          
                          return typeEqual.apply(_v461,applyTypeFun.apply(l,forceType.apply(op),args));
                        }
                        }
                        }
                        }
                        }
                      case "ExtendedAct": {ESLVal $502 = _v67.termRef(0);
                          ESLVal $501 = _v67.termRef(1);
                          ESLVal $500 = _v67.termRef(2);
                          ESLVal $499 = _v67.termRef(3);
                          
                          {ESLVal _v459 = _v68;
                          
                          {ESLVal l2 = $502;
                          
                          {ESLVal _v460 = $501;
                          
                          {ESLVal ds2 = $500;
                          
                          {ESLVal ms2 = $499;
                          
                          return typeEqual.apply(_v459,flattenAct.apply(l2,_v460,ds2,ms2));
                        }
                        }
                        }
                        }
                        }
                        }
                      case "VoidType": {ESLVal $498 = _v67.termRef(0);
                          
                          {ESLVal t = _v68;
                          
                          {ESLVal l1 = $498;
                          
                          return $true;
                        }
                        }
                        }
                      case "TermType": {ESLVal $497 = _v67.termRef(0);
                          ESLVal $496 = _v67.termRef(1);
                          ESLVal $495 = _v67.termRef(2);
                          
                          {ESLVal _v458 = _v68;
                          
                          {ESLVal l2 = $497;
                          
                          {ESLVal n2 = $496;
                          
                          {ESLVal args2 = $495;
                          
                          return $false;
                        }
                        }
                        }
                        }
                        }
                      case "TypeClosure": {ESLVal $494 = _v67.termRef(0);
                          
                          {ESLVal _v457 = _v68;
                          
                          {ESLVal f = $494;
                          
                          return typeEqual.apply(_v457,f.apply());
                        }
                        }
                        }
                      case "RecType": {ESLVal $493 = _v67.termRef(0);
                          ESLVal $492 = _v67.termRef(1);
                          ESLVal $491 = _v67.termRef(2);
                          
                          {ESLVal _v455 = _v68;
                          
                          {ESLVal l2 = $493;
                          
                          {ESLVal n2 = $492;
                          
                          {ESLVal _v456 = $491;
                          
                          return typeEqual.apply(_v455,substType.apply(new ESLVal("RecType",l2,n2,_v456),n2,_v456));
                        }
                        }
                        }
                        }
                        }
                      case "ForallType": {ESLVal $490 = _v67.termRef(0);
                          ESLVal $489 = _v67.termRef(1);
                          ESLVal $488 = _v67.termRef(2);
                          
                          {ESLVal _v453 = _v68;
                          
                          {ESLVal l1 = $490;
                          
                          {ESLVal ns2 = $489;
                          
                          {ESLVal _v454 = $488;
                          
                          return typeEqual.apply(_v453,_v454);
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal _v462 = _v68;
                          
                          {ESLVal _v463 = _v67;
                          
                          return $false;
                        }
                        }
                      }
                    }
                    }
                    default: switch(_v67.termName) {
                      case "ApplyTypeFun": {ESLVal $505 = _v67.termRef(0);
                        ESLVal $504 = _v67.termRef(1);
                        ESLVal $503 = _v67.termRef(2);
                        
                        {ESLVal _v472 = _v68;
                        
                        {ESLVal l = $505;
                        
                        {ESLVal op = $504;
                        
                        {ESLVal args = $503;
                        
                        return typeEqual.apply(_v472,applyTypeFun.apply(l,forceType.apply(op),args));
                      }
                      }
                      }
                      }
                      }
                    case "ExtendedAct": {ESLVal $502 = _v67.termRef(0);
                        ESLVal $501 = _v67.termRef(1);
                        ESLVal $500 = _v67.termRef(2);
                        ESLVal $499 = _v67.termRef(3);
                        
                        {ESLVal _v470 = _v68;
                        
                        {ESLVal l2 = $502;
                        
                        {ESLVal _v471 = $501;
                        
                        {ESLVal ds2 = $500;
                        
                        {ESLVal ms2 = $499;
                        
                        return typeEqual.apply(_v470,flattenAct.apply(l2,_v471,ds2,ms2));
                      }
                      }
                      }
                      }
                      }
                      }
                    case "VoidType": {ESLVal $498 = _v67.termRef(0);
                        
                        {ESLVal t = _v68;
                        
                        {ESLVal l1 = $498;
                        
                        return $true;
                      }
                      }
                      }
                    case "TermType": {ESLVal $497 = _v67.termRef(0);
                        ESLVal $496 = _v67.termRef(1);
                        ESLVal $495 = _v67.termRef(2);
                        
                        {ESLVal _v469 = _v68;
                        
                        {ESLVal l2 = $497;
                        
                        {ESLVal n2 = $496;
                        
                        {ESLVal args2 = $495;
                        
                        return $false;
                      }
                      }
                      }
                      }
                      }
                    case "TypeClosure": {ESLVal $494 = _v67.termRef(0);
                        
                        {ESLVal _v468 = _v68;
                        
                        {ESLVal f = $494;
                        
                        return typeEqual.apply(_v468,f.apply());
                      }
                      }
                      }
                    case "RecType": {ESLVal $493 = _v67.termRef(0);
                        ESLVal $492 = _v67.termRef(1);
                        ESLVal $491 = _v67.termRef(2);
                        
                        {ESLVal _v466 = _v68;
                        
                        {ESLVal l2 = $493;
                        
                        {ESLVal n2 = $492;
                        
                        {ESLVal _v467 = $491;
                        
                        return typeEqual.apply(_v466,substType.apply(new ESLVal("RecType",l2,n2,_v467),n2,_v467));
                      }
                      }
                      }
                      }
                      }
                    case "ForallType": {ESLVal $490 = _v67.termRef(0);
                        ESLVal $489 = _v67.termRef(1);
                        ESLVal $488 = _v67.termRef(2);
                        
                        {ESLVal _v464 = _v68;
                        
                        {ESLVal l1 = $490;
                        
                        {ESLVal ns2 = $489;
                        
                        {ESLVal _v465 = $488;
                        
                        return typeEqual.apply(_v464,_v465);
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal _v473 = _v68;
                        
                        {ESLVal _v474 = _v67;
                        
                        return $false;
                      }
                      }
                    }
                  }
                else switch(_v67.termName) {
                    case "ApplyTypeFun": {ESLVal $505 = _v67.termRef(0);
                      ESLVal $504 = _v67.termRef(1);
                      ESLVal $503 = _v67.termRef(2);
                      
                      {ESLVal _v483 = _v68;
                      
                      {ESLVal l = $505;
                      
                      {ESLVal op = $504;
                      
                      {ESLVal args = $503;
                      
                      return typeEqual.apply(_v483,applyTypeFun.apply(l,forceType.apply(op),args));
                    }
                    }
                    }
                    }
                    }
                  case "ExtendedAct": {ESLVal $502 = _v67.termRef(0);
                      ESLVal $501 = _v67.termRef(1);
                      ESLVal $500 = _v67.termRef(2);
                      ESLVal $499 = _v67.termRef(3);
                      
                      {ESLVal _v481 = _v68;
                      
                      {ESLVal l2 = $502;
                      
                      {ESLVal _v482 = $501;
                      
                      {ESLVal ds2 = $500;
                      
                      {ESLVal ms2 = $499;
                      
                      return typeEqual.apply(_v481,flattenAct.apply(l2,_v482,ds2,ms2));
                    }
                    }
                    }
                    }
                    }
                    }
                  case "VoidType": {ESLVal $498 = _v67.termRef(0);
                      
                      {ESLVal t = _v68;
                      
                      {ESLVal l1 = $498;
                      
                      return $true;
                    }
                    }
                    }
                  case "TermType": {ESLVal $497 = _v67.termRef(0);
                      ESLVal $496 = _v67.termRef(1);
                      ESLVal $495 = _v67.termRef(2);
                      
                      {ESLVal _v480 = _v68;
                      
                      {ESLVal l2 = $497;
                      
                      {ESLVal n2 = $496;
                      
                      {ESLVal args2 = $495;
                      
                      return $false;
                    }
                    }
                    }
                    }
                    }
                  case "TypeClosure": {ESLVal $494 = _v67.termRef(0);
                      
                      {ESLVal _v479 = _v68;
                      
                      {ESLVal f = $494;
                      
                      return typeEqual.apply(_v479,f.apply());
                    }
                    }
                    }
                  case "RecType": {ESLVal $493 = _v67.termRef(0);
                      ESLVal $492 = _v67.termRef(1);
                      ESLVal $491 = _v67.termRef(2);
                      
                      {ESLVal _v477 = _v68;
                      
                      {ESLVal l2 = $493;
                      
                      {ESLVal n2 = $492;
                      
                      {ESLVal _v478 = $491;
                      
                      return typeEqual.apply(_v477,substType.apply(new ESLVal("RecType",l2,n2,_v478),n2,_v478));
                    }
                    }
                    }
                    }
                    }
                  case "ForallType": {ESLVal $490 = _v67.termRef(0);
                      ESLVal $489 = _v67.termRef(1);
                      ESLVal $488 = _v67.termRef(2);
                      
                      {ESLVal _v475 = _v68;
                      
                      {ESLVal l1 = $490;
                      
                      {ESLVal ns2 = $489;
                      
                      {ESLVal _v476 = $488;
                      
                      return typeEqual.apply(_v475,_v476);
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal _v484 = _v68;
                      
                      {ESLVal _v485 = _v67;
                      
                      return $false;
                    }
                    }
                  }
                }
              else if($596.isNil())
                switch(_v67.termName) {
                  case "ApplyTypeFun": {ESLVal $505 = _v67.termRef(0);
                    ESLVal $504 = _v67.termRef(1);
                    ESLVal $503 = _v67.termRef(2);
                    
                    {ESLVal _v494 = _v68;
                    
                    {ESLVal l = $505;
                    
                    {ESLVal op = $504;
                    
                    {ESLVal args = $503;
                    
                    return typeEqual.apply(_v494,applyTypeFun.apply(l,forceType.apply(op),args));
                  }
                  }
                  }
                  }
                  }
                case "ExtendedAct": {ESLVal $502 = _v67.termRef(0);
                    ESLVal $501 = _v67.termRef(1);
                    ESLVal $500 = _v67.termRef(2);
                    ESLVal $499 = _v67.termRef(3);
                    
                    {ESLVal _v492 = _v68;
                    
                    {ESLVal l2 = $502;
                    
                    {ESLVal _v493 = $501;
                    
                    {ESLVal ds2 = $500;
                    
                    {ESLVal ms2 = $499;
                    
                    return typeEqual.apply(_v492,flattenAct.apply(l2,_v493,ds2,ms2));
                  }
                  }
                  }
                  }
                  }
                  }
                case "VoidType": {ESLVal $498 = _v67.termRef(0);
                    
                    {ESLVal t = _v68;
                    
                    {ESLVal l1 = $498;
                    
                    return $true;
                  }
                  }
                  }
                case "TermType": {ESLVal $497 = _v67.termRef(0);
                    ESLVal $496 = _v67.termRef(1);
                    ESLVal $495 = _v67.termRef(2);
                    
                    {ESLVal _v491 = _v68;
                    
                    {ESLVal l2 = $497;
                    
                    {ESLVal n2 = $496;
                    
                    {ESLVal args2 = $495;
                    
                    return $false;
                  }
                  }
                  }
                  }
                  }
                case "TypeClosure": {ESLVal $494 = _v67.termRef(0);
                    
                    {ESLVal _v490 = _v68;
                    
                    {ESLVal f = $494;
                    
                    return typeEqual.apply(_v490,f.apply());
                  }
                  }
                  }
                case "RecType": {ESLVal $493 = _v67.termRef(0);
                    ESLVal $492 = _v67.termRef(1);
                    ESLVal $491 = _v67.termRef(2);
                    
                    {ESLVal _v488 = _v68;
                    
                    {ESLVal l2 = $493;
                    
                    {ESLVal n2 = $492;
                    
                    {ESLVal _v489 = $491;
                    
                    return typeEqual.apply(_v488,substType.apply(new ESLVal("RecType",l2,n2,_v489),n2,_v489));
                  }
                  }
                  }
                  }
                  }
                case "ForallType": {ESLVal $490 = _v67.termRef(0);
                    ESLVal $489 = _v67.termRef(1);
                    ESLVal $488 = _v67.termRef(2);
                    
                    {ESLVal _v486 = _v68;
                    
                    {ESLVal l1 = $490;
                    
                    {ESLVal ns2 = $489;
                    
                    {ESLVal _v487 = $488;
                    
                    return typeEqual.apply(_v486,_v487);
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v495 = _v68;
                    
                    {ESLVal _v496 = _v67;
                    
                    return $false;
                  }
                  }
                }
              else switch(_v67.termName) {
                  case "ApplyTypeFun": {ESLVal $505 = _v67.termRef(0);
                    ESLVal $504 = _v67.termRef(1);
                    ESLVal $503 = _v67.termRef(2);
                    
                    {ESLVal _v505 = _v68;
                    
                    {ESLVal l = $505;
                    
                    {ESLVal op = $504;
                    
                    {ESLVal args = $503;
                    
                    return typeEqual.apply(_v505,applyTypeFun.apply(l,forceType.apply(op),args));
                  }
                  }
                  }
                  }
                  }
                case "ExtendedAct": {ESLVal $502 = _v67.termRef(0);
                    ESLVal $501 = _v67.termRef(1);
                    ESLVal $500 = _v67.termRef(2);
                    ESLVal $499 = _v67.termRef(3);
                    
                    {ESLVal _v503 = _v68;
                    
                    {ESLVal l2 = $502;
                    
                    {ESLVal _v504 = $501;
                    
                    {ESLVal ds2 = $500;
                    
                    {ESLVal ms2 = $499;
                    
                    return typeEqual.apply(_v503,flattenAct.apply(l2,_v504,ds2,ms2));
                  }
                  }
                  }
                  }
                  }
                  }
                case "VoidType": {ESLVal $498 = _v67.termRef(0);
                    
                    {ESLVal t = _v68;
                    
                    {ESLVal l1 = $498;
                    
                    return $true;
                  }
                  }
                  }
                case "TermType": {ESLVal $497 = _v67.termRef(0);
                    ESLVal $496 = _v67.termRef(1);
                    ESLVal $495 = _v67.termRef(2);
                    
                    {ESLVal _v502 = _v68;
                    
                    {ESLVal l2 = $497;
                    
                    {ESLVal n2 = $496;
                    
                    {ESLVal args2 = $495;
                    
                    return $false;
                  }
                  }
                  }
                  }
                  }
                case "TypeClosure": {ESLVal $494 = _v67.termRef(0);
                    
                    {ESLVal _v501 = _v68;
                    
                    {ESLVal f = $494;
                    
                    return typeEqual.apply(_v501,f.apply());
                  }
                  }
                  }
                case "RecType": {ESLVal $493 = _v67.termRef(0);
                    ESLVal $492 = _v67.termRef(1);
                    ESLVal $491 = _v67.termRef(2);
                    
                    {ESLVal _v499 = _v68;
                    
                    {ESLVal l2 = $493;
                    
                    {ESLVal n2 = $492;
                    
                    {ESLVal _v500 = $491;
                    
                    return typeEqual.apply(_v499,substType.apply(new ESLVal("RecType",l2,n2,_v500),n2,_v500));
                  }
                  }
                  }
                  }
                  }
                case "ForallType": {ESLVal $490 = _v67.termRef(0);
                    ESLVal $489 = _v67.termRef(1);
                    ESLVal $488 = _v67.termRef(2);
                    
                    {ESLVal _v497 = _v68;
                    
                    {ESLVal l1 = $490;
                    
                    {ESLVal ns2 = $489;
                    
                    {ESLVal _v498 = $488;
                    
                    return typeEqual.apply(_v497,_v498);
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v506 = _v68;
                    
                    {ESLVal _v507 = _v67;
                    
                    return $false;
                  }
                  }
                }
              }
              default: switch(_v67.termName) {
                case "ApplyTypeFun": {ESLVal $505 = _v67.termRef(0);
                  ESLVal $504 = _v67.termRef(1);
                  ESLVal $503 = _v67.termRef(2);
                  
                  {ESLVal _v518 = _v68;
                  
                  {ESLVal l = $505;
                  
                  {ESLVal op = $504;
                  
                  {ESLVal args = $503;
                  
                  return typeEqual.apply(_v518,applyTypeFun.apply(l,forceType.apply(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $502 = _v67.termRef(0);
                  ESLVal $501 = _v67.termRef(1);
                  ESLVal $500 = _v67.termRef(2);
                  ESLVal $499 = _v67.termRef(3);
                  
                  {ESLVal _v516 = _v68;
                  
                  {ESLVal l2 = $502;
                  
                  {ESLVal _v517 = $501;
                  
                  {ESLVal ds2 = $500;
                  
                  {ESLVal ms2 = $499;
                  
                  return typeEqual.apply(_v516,flattenAct.apply(l2,_v517,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $498 = _v67.termRef(0);
                  
                  {ESLVal t = _v68;
                  
                  {ESLVal l1 = $498;
                  
                  return $true;
                }
                }
                }
              case "TermType": {ESLVal $497 = _v67.termRef(0);
                  ESLVal $496 = _v67.termRef(1);
                  ESLVal $495 = _v67.termRef(2);
                  
                  {ESLVal _v515 = _v68;
                  
                  {ESLVal l2 = $497;
                  
                  {ESLVal n2 = $496;
                  
                  {ESLVal args2 = $495;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $494 = _v67.termRef(0);
                  
                  {ESLVal _v514 = _v68;
                  
                  {ESLVal f = $494;
                  
                  return typeEqual.apply(_v514,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $493 = _v67.termRef(0);
                  ESLVal $492 = _v67.termRef(1);
                  ESLVal $491 = _v67.termRef(2);
                  
                  {ESLVal _v512 = _v68;
                  
                  {ESLVal l2 = $493;
                  
                  {ESLVal n2 = $492;
                  
                  {ESLVal _v513 = $491;
                  
                  return typeEqual.apply(_v512,substType.apply(new ESLVal("RecType",l2,n2,_v513),n2,_v513));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $490 = _v67.termRef(0);
                  ESLVal $489 = _v67.termRef(1);
                  ESLVal $488 = _v67.termRef(2);
                  
                  {ESLVal _v510 = _v68;
                  
                  {ESLVal l1 = $490;
                  
                  {ESLVal ns2 = $489;
                  
                  {ESLVal _v511 = $488;
                  
                  return typeEqual.apply(_v510,_v511);
                }
                }
                }
                }
                }
                default: {ESLVal _v519 = _v68;
                  
                  {ESLVal _v520 = _v67;
                  
                  return $false;
                }
                }
              }
            }
            }
          case "BagType": {ESLVal $590 = _v68.termRef(0);
              ESLVal $589 = _v68.termRef(1);
              
              switch(_v67.termName) {
              case "BagType": {ESLVal $592 = _v67.termRef(0);
                ESLVal $591 = _v67.termRef(1);
                
                {ESLVal l1 = $590;
                
                {ESLVal _v412 = $589;
                
                {ESLVal l2 = $592;
                
                {ESLVal _v413 = $591;
                
                return typeEqual.apply(_v412,_v413);
              }
              }
              }
              }
              }
              default: switch(_v67.termName) {
                case "ApplyTypeFun": {ESLVal $505 = _v67.termRef(0);
                  ESLVal $504 = _v67.termRef(1);
                  ESLVal $503 = _v67.termRef(2);
                  
                  {ESLVal _v422 = _v68;
                  
                  {ESLVal l = $505;
                  
                  {ESLVal op = $504;
                  
                  {ESLVal args = $503;
                  
                  return typeEqual.apply(_v422,applyTypeFun.apply(l,forceType.apply(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $502 = _v67.termRef(0);
                  ESLVal $501 = _v67.termRef(1);
                  ESLVal $500 = _v67.termRef(2);
                  ESLVal $499 = _v67.termRef(3);
                  
                  {ESLVal _v420 = _v68;
                  
                  {ESLVal l2 = $502;
                  
                  {ESLVal _v421 = $501;
                  
                  {ESLVal ds2 = $500;
                  
                  {ESLVal ms2 = $499;
                  
                  return typeEqual.apply(_v420,flattenAct.apply(l2,_v421,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $498 = _v67.termRef(0);
                  
                  {ESLVal t = _v68;
                  
                  {ESLVal l1 = $498;
                  
                  return $true;
                }
                }
                }
              case "TermType": {ESLVal $497 = _v67.termRef(0);
                  ESLVal $496 = _v67.termRef(1);
                  ESLVal $495 = _v67.termRef(2);
                  
                  {ESLVal _v419 = _v68;
                  
                  {ESLVal l2 = $497;
                  
                  {ESLVal n2 = $496;
                  
                  {ESLVal args2 = $495;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $494 = _v67.termRef(0);
                  
                  {ESLVal _v418 = _v68;
                  
                  {ESLVal f = $494;
                  
                  return typeEqual.apply(_v418,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $493 = _v67.termRef(0);
                  ESLVal $492 = _v67.termRef(1);
                  ESLVal $491 = _v67.termRef(2);
                  
                  {ESLVal _v416 = _v68;
                  
                  {ESLVal l2 = $493;
                  
                  {ESLVal n2 = $492;
                  
                  {ESLVal _v417 = $491;
                  
                  return typeEqual.apply(_v416,substType.apply(new ESLVal("RecType",l2,n2,_v417),n2,_v417));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $490 = _v67.termRef(0);
                  ESLVal $489 = _v67.termRef(1);
                  ESLVal $488 = _v67.termRef(2);
                  
                  {ESLVal _v414 = _v68;
                  
                  {ESLVal l1 = $490;
                  
                  {ESLVal ns2 = $489;
                  
                  {ESLVal _v415 = $488;
                  
                  return typeEqual.apply(_v414,_v415);
                }
                }
                }
                }
                }
                default: {ESLVal _v423 = _v68;
                  
                  {ESLVal _v424 = _v67;
                  
                  return $false;
                }
                }
              }
            }
            }
          case "SetType": {ESLVal $575 = _v68.termRef(0);
              ESLVal $574 = _v68.termRef(1);
              
              switch(_v67.termName) {
              case "SetType": {ESLVal $588 = _v67.termRef(0);
                ESLVal $587 = _v67.termRef(1);
                
                {ESLVal l1 = $575;
                
                {ESLVal _v399 = $574;
                
                {ESLVal l2 = $588;
                
                {ESLVal _v400 = $587;
                
                return typeEqual.apply(_v399,_v400);
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $578 = _v67.termRef(0);
                ESLVal $577 = _v67.termRef(1);
                ESLVal $576 = _v67.termRef(2);
                
                if($577.isCons())
                {ESLVal $579 = $577.head();
                  ESLVal $580 = $577.tail();
                  
                  if($580.isCons())
                  {ESLVal $581 = $580.head();
                    ESLVal $582 = $580.tail();
                    
                    switch(_v67.termName) {
                    case "ApplyTypeFun": {ESLVal $505 = _v67.termRef(0);
                      ESLVal $504 = _v67.termRef(1);
                      ESLVal $503 = _v67.termRef(2);
                      
                      {ESLVal _v324 = _v68;
                      
                      {ESLVal l = $505;
                      
                      {ESLVal op = $504;
                      
                      {ESLVal args = $503;
                      
                      return typeEqual.apply(_v324,applyTypeFun.apply(l,forceType.apply(op),args));
                    }
                    }
                    }
                    }
                    }
                  case "ExtendedAct": {ESLVal $502 = _v67.termRef(0);
                      ESLVal $501 = _v67.termRef(1);
                      ESLVal $500 = _v67.termRef(2);
                      ESLVal $499 = _v67.termRef(3);
                      
                      {ESLVal _v322 = _v68;
                      
                      {ESLVal l2 = $502;
                      
                      {ESLVal _v323 = $501;
                      
                      {ESLVal ds2 = $500;
                      
                      {ESLVal ms2 = $499;
                      
                      return typeEqual.apply(_v322,flattenAct.apply(l2,_v323,ds2,ms2));
                    }
                    }
                    }
                    }
                    }
                    }
                  case "VoidType": {ESLVal $498 = _v67.termRef(0);
                      
                      {ESLVal t = _v68;
                      
                      {ESLVal l1 = $498;
                      
                      return $true;
                    }
                    }
                    }
                  case "TermType": {ESLVal $497 = _v67.termRef(0);
                      ESLVal $496 = _v67.termRef(1);
                      ESLVal $495 = _v67.termRef(2);
                      
                      {ESLVal _v321 = _v68;
                      
                      {ESLVal l2 = $497;
                      
                      {ESLVal n2 = $496;
                      
                      {ESLVal args2 = $495;
                      
                      return $false;
                    }
                    }
                    }
                    }
                    }
                  case "TypeClosure": {ESLVal $494 = _v67.termRef(0);
                      
                      {ESLVal _v320 = _v68;
                      
                      {ESLVal f = $494;
                      
                      return typeEqual.apply(_v320,f.apply());
                    }
                    }
                    }
                  case "RecType": {ESLVal $493 = _v67.termRef(0);
                      ESLVal $492 = _v67.termRef(1);
                      ESLVal $491 = _v67.termRef(2);
                      
                      {ESLVal _v318 = _v68;
                      
                      {ESLVal l2 = $493;
                      
                      {ESLVal n2 = $492;
                      
                      {ESLVal _v319 = $491;
                      
                      return typeEqual.apply(_v318,substType.apply(new ESLVal("RecType",l2,n2,_v319),n2,_v319));
                    }
                    }
                    }
                    }
                    }
                  case "ForallType": {ESLVal $490 = _v67.termRef(0);
                      ESLVal $489 = _v67.termRef(1);
                      ESLVal $488 = _v67.termRef(2);
                      
                      {ESLVal _v316 = _v68;
                      
                      {ESLVal l1 = $490;
                      
                      {ESLVal ns2 = $489;
                      
                      {ESLVal _v317 = $488;
                      
                      return typeEqual.apply(_v316,_v317);
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal _v325 = _v68;
                      
                      {ESLVal _v326 = _v67;
                      
                      return $false;
                    }
                    }
                  }
                  }
                else if($580.isNil())
                  switch($576.termName) {
                    case "SetType": {ESLVal $584 = $576.termRef(0);
                      ESLVal $583 = $576.termRef(1);
                      
                      switch($583.termName) {
                      case "VarType": {ESLVal $586 = $583.termRef(0);
                        ESLVal $585 = $583.termRef(1);
                        
                        {ESLVal l1 = $575;
                        
                        {ESLVal _v327 = $574;
                        
                        {ESLVal l2 = $578;
                        
                        {ESLVal v1 = $579;
                        
                        {ESLVal l3 = $584;
                        
                        {ESLVal l4 = $586;
                        
                        {ESLVal v2 = $585;
                        
                        if(v1.eql(v2).boolVal)
                        return $true;
                        else
                          switch(_v67.termName) {
                            case "ApplyTypeFun": {ESLVal $505 = _v67.termRef(0);
                              ESLVal $504 = _v67.termRef(1);
                              ESLVal $503 = _v67.termRef(2);
                              
                              {ESLVal _v341 = _v68;
                              
                              {ESLVal l = $505;
                              
                              {ESLVal op = $504;
                              
                              {ESLVal args = $503;
                              
                              return typeEqual.apply(_v341,applyTypeFun.apply(l,forceType.apply(op),args));
                            }
                            }
                            }
                            }
                            }
                          case "ExtendedAct": {ESLVal $502 = _v67.termRef(0);
                              ESLVal $501 = _v67.termRef(1);
                              ESLVal $500 = _v67.termRef(2);
                              ESLVal $499 = _v67.termRef(3);
                              
                              {ESLVal _v338 = _v68;
                              
                              {ESLVal _v339 = $502;
                              
                              {ESLVal _v340 = $501;
                              
                              {ESLVal ds2 = $500;
                              
                              {ESLVal ms2 = $499;
                              
                              return typeEqual.apply(_v338,flattenAct.apply(_v339,_v340,ds2,ms2));
                            }
                            }
                            }
                            }
                            }
                            }
                          case "VoidType": {ESLVal $498 = _v67.termRef(0);
                              
                              {ESLVal t = _v68;
                              
                              {ESLVal _v337 = $498;
                              
                              return $true;
                            }
                            }
                            }
                          case "TermType": {ESLVal $497 = _v67.termRef(0);
                              ESLVal $496 = _v67.termRef(1);
                              ESLVal $495 = _v67.termRef(2);
                              
                              {ESLVal _v335 = _v68;
                              
                              {ESLVal _v336 = $497;
                              
                              {ESLVal n2 = $496;
                              
                              {ESLVal args2 = $495;
                              
                              return $false;
                            }
                            }
                            }
                            }
                            }
                          case "TypeClosure": {ESLVal $494 = _v67.termRef(0);
                              
                              {ESLVal _v334 = _v68;
                              
                              {ESLVal f = $494;
                              
                              return typeEqual.apply(_v334,f.apply());
                            }
                            }
                            }
                          case "RecType": {ESLVal $493 = _v67.termRef(0);
                              ESLVal $492 = _v67.termRef(1);
                              ESLVal $491 = _v67.termRef(2);
                              
                              {ESLVal _v331 = _v68;
                              
                              {ESLVal _v332 = $493;
                              
                              {ESLVal n2 = $492;
                              
                              {ESLVal _v333 = $491;
                              
                              return typeEqual.apply(_v331,substType.apply(new ESLVal("RecType",_v332,n2,_v333),n2,_v333));
                            }
                            }
                            }
                            }
                            }
                          case "ForallType": {ESLVal $490 = _v67.termRef(0);
                              ESLVal $489 = _v67.termRef(1);
                              ESLVal $488 = _v67.termRef(2);
                              
                              {ESLVal _v328 = _v68;
                              
                              {ESLVal _v329 = $490;
                              
                              {ESLVal ns2 = $489;
                              
                              {ESLVal _v330 = $488;
                              
                              return typeEqual.apply(_v328,_v330);
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v342 = _v68;
                              
                              {ESLVal _v343 = _v67;
                              
                              return $false;
                            }
                            }
                          }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      default: switch(_v67.termName) {
                        case "ApplyTypeFun": {ESLVal $505 = _v67.termRef(0);
                          ESLVal $504 = _v67.termRef(1);
                          ESLVal $503 = _v67.termRef(2);
                          
                          {ESLVal _v352 = _v68;
                          
                          {ESLVal l = $505;
                          
                          {ESLVal op = $504;
                          
                          {ESLVal args = $503;
                          
                          return typeEqual.apply(_v352,applyTypeFun.apply(l,forceType.apply(op),args));
                        }
                        }
                        }
                        }
                        }
                      case "ExtendedAct": {ESLVal $502 = _v67.termRef(0);
                          ESLVal $501 = _v67.termRef(1);
                          ESLVal $500 = _v67.termRef(2);
                          ESLVal $499 = _v67.termRef(3);
                          
                          {ESLVal _v350 = _v68;
                          
                          {ESLVal l2 = $502;
                          
                          {ESLVal _v351 = $501;
                          
                          {ESLVal ds2 = $500;
                          
                          {ESLVal ms2 = $499;
                          
                          return typeEqual.apply(_v350,flattenAct.apply(l2,_v351,ds2,ms2));
                        }
                        }
                        }
                        }
                        }
                        }
                      case "VoidType": {ESLVal $498 = _v67.termRef(0);
                          
                          {ESLVal t = _v68;
                          
                          {ESLVal l1 = $498;
                          
                          return $true;
                        }
                        }
                        }
                      case "TermType": {ESLVal $497 = _v67.termRef(0);
                          ESLVal $496 = _v67.termRef(1);
                          ESLVal $495 = _v67.termRef(2);
                          
                          {ESLVal _v349 = _v68;
                          
                          {ESLVal l2 = $497;
                          
                          {ESLVal n2 = $496;
                          
                          {ESLVal args2 = $495;
                          
                          return $false;
                        }
                        }
                        }
                        }
                        }
                      case "TypeClosure": {ESLVal $494 = _v67.termRef(0);
                          
                          {ESLVal _v348 = _v68;
                          
                          {ESLVal f = $494;
                          
                          return typeEqual.apply(_v348,f.apply());
                        }
                        }
                        }
                      case "RecType": {ESLVal $493 = _v67.termRef(0);
                          ESLVal $492 = _v67.termRef(1);
                          ESLVal $491 = _v67.termRef(2);
                          
                          {ESLVal _v346 = _v68;
                          
                          {ESLVal l2 = $493;
                          
                          {ESLVal n2 = $492;
                          
                          {ESLVal _v347 = $491;
                          
                          return typeEqual.apply(_v346,substType.apply(new ESLVal("RecType",l2,n2,_v347),n2,_v347));
                        }
                        }
                        }
                        }
                        }
                      case "ForallType": {ESLVal $490 = _v67.termRef(0);
                          ESLVal $489 = _v67.termRef(1);
                          ESLVal $488 = _v67.termRef(2);
                          
                          {ESLVal _v344 = _v68;
                          
                          {ESLVal l1 = $490;
                          
                          {ESLVal ns2 = $489;
                          
                          {ESLVal _v345 = $488;
                          
                          return typeEqual.apply(_v344,_v345);
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal _v353 = _v68;
                          
                          {ESLVal _v354 = _v67;
                          
                          return $false;
                        }
                        }
                      }
                    }
                    }
                    default: switch(_v67.termName) {
                      case "ApplyTypeFun": {ESLVal $505 = _v67.termRef(0);
                        ESLVal $504 = _v67.termRef(1);
                        ESLVal $503 = _v67.termRef(2);
                        
                        {ESLVal _v363 = _v68;
                        
                        {ESLVal l = $505;
                        
                        {ESLVal op = $504;
                        
                        {ESLVal args = $503;
                        
                        return typeEqual.apply(_v363,applyTypeFun.apply(l,forceType.apply(op),args));
                      }
                      }
                      }
                      }
                      }
                    case "ExtendedAct": {ESLVal $502 = _v67.termRef(0);
                        ESLVal $501 = _v67.termRef(1);
                        ESLVal $500 = _v67.termRef(2);
                        ESLVal $499 = _v67.termRef(3);
                        
                        {ESLVal _v361 = _v68;
                        
                        {ESLVal l2 = $502;
                        
                        {ESLVal _v362 = $501;
                        
                        {ESLVal ds2 = $500;
                        
                        {ESLVal ms2 = $499;
                        
                        return typeEqual.apply(_v361,flattenAct.apply(l2,_v362,ds2,ms2));
                      }
                      }
                      }
                      }
                      }
                      }
                    case "VoidType": {ESLVal $498 = _v67.termRef(0);
                        
                        {ESLVal t = _v68;
                        
                        {ESLVal l1 = $498;
                        
                        return $true;
                      }
                      }
                      }
                    case "TermType": {ESLVal $497 = _v67.termRef(0);
                        ESLVal $496 = _v67.termRef(1);
                        ESLVal $495 = _v67.termRef(2);
                        
                        {ESLVal _v360 = _v68;
                        
                        {ESLVal l2 = $497;
                        
                        {ESLVal n2 = $496;
                        
                        {ESLVal args2 = $495;
                        
                        return $false;
                      }
                      }
                      }
                      }
                      }
                    case "TypeClosure": {ESLVal $494 = _v67.termRef(0);
                        
                        {ESLVal _v359 = _v68;
                        
                        {ESLVal f = $494;
                        
                        return typeEqual.apply(_v359,f.apply());
                      }
                      }
                      }
                    case "RecType": {ESLVal $493 = _v67.termRef(0);
                        ESLVal $492 = _v67.termRef(1);
                        ESLVal $491 = _v67.termRef(2);
                        
                        {ESLVal _v357 = _v68;
                        
                        {ESLVal l2 = $493;
                        
                        {ESLVal n2 = $492;
                        
                        {ESLVal _v358 = $491;
                        
                        return typeEqual.apply(_v357,substType.apply(new ESLVal("RecType",l2,n2,_v358),n2,_v358));
                      }
                      }
                      }
                      }
                      }
                    case "ForallType": {ESLVal $490 = _v67.termRef(0);
                        ESLVal $489 = _v67.termRef(1);
                        ESLVal $488 = _v67.termRef(2);
                        
                        {ESLVal _v355 = _v68;
                        
                        {ESLVal l1 = $490;
                        
                        {ESLVal ns2 = $489;
                        
                        {ESLVal _v356 = $488;
                        
                        return typeEqual.apply(_v355,_v356);
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal _v364 = _v68;
                        
                        {ESLVal _v365 = _v67;
                        
                        return $false;
                      }
                      }
                    }
                  }
                else switch(_v67.termName) {
                    case "ApplyTypeFun": {ESLVal $505 = _v67.termRef(0);
                      ESLVal $504 = _v67.termRef(1);
                      ESLVal $503 = _v67.termRef(2);
                      
                      {ESLVal _v374 = _v68;
                      
                      {ESLVal l = $505;
                      
                      {ESLVal op = $504;
                      
                      {ESLVal args = $503;
                      
                      return typeEqual.apply(_v374,applyTypeFun.apply(l,forceType.apply(op),args));
                    }
                    }
                    }
                    }
                    }
                  case "ExtendedAct": {ESLVal $502 = _v67.termRef(0);
                      ESLVal $501 = _v67.termRef(1);
                      ESLVal $500 = _v67.termRef(2);
                      ESLVal $499 = _v67.termRef(3);
                      
                      {ESLVal _v372 = _v68;
                      
                      {ESLVal l2 = $502;
                      
                      {ESLVal _v373 = $501;
                      
                      {ESLVal ds2 = $500;
                      
                      {ESLVal ms2 = $499;
                      
                      return typeEqual.apply(_v372,flattenAct.apply(l2,_v373,ds2,ms2));
                    }
                    }
                    }
                    }
                    }
                    }
                  case "VoidType": {ESLVal $498 = _v67.termRef(0);
                      
                      {ESLVal t = _v68;
                      
                      {ESLVal l1 = $498;
                      
                      return $true;
                    }
                    }
                    }
                  case "TermType": {ESLVal $497 = _v67.termRef(0);
                      ESLVal $496 = _v67.termRef(1);
                      ESLVal $495 = _v67.termRef(2);
                      
                      {ESLVal _v371 = _v68;
                      
                      {ESLVal l2 = $497;
                      
                      {ESLVal n2 = $496;
                      
                      {ESLVal args2 = $495;
                      
                      return $false;
                    }
                    }
                    }
                    }
                    }
                  case "TypeClosure": {ESLVal $494 = _v67.termRef(0);
                      
                      {ESLVal _v370 = _v68;
                      
                      {ESLVal f = $494;
                      
                      return typeEqual.apply(_v370,f.apply());
                    }
                    }
                    }
                  case "RecType": {ESLVal $493 = _v67.termRef(0);
                      ESLVal $492 = _v67.termRef(1);
                      ESLVal $491 = _v67.termRef(2);
                      
                      {ESLVal _v368 = _v68;
                      
                      {ESLVal l2 = $493;
                      
                      {ESLVal n2 = $492;
                      
                      {ESLVal _v369 = $491;
                      
                      return typeEqual.apply(_v368,substType.apply(new ESLVal("RecType",l2,n2,_v369),n2,_v369));
                    }
                    }
                    }
                    }
                    }
                  case "ForallType": {ESLVal $490 = _v67.termRef(0);
                      ESLVal $489 = _v67.termRef(1);
                      ESLVal $488 = _v67.termRef(2);
                      
                      {ESLVal _v366 = _v68;
                      
                      {ESLVal l1 = $490;
                      
                      {ESLVal ns2 = $489;
                      
                      {ESLVal _v367 = $488;
                      
                      return typeEqual.apply(_v366,_v367);
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal _v375 = _v68;
                      
                      {ESLVal _v376 = _v67;
                      
                      return $false;
                    }
                    }
                  }
                }
              else if($577.isNil())
                switch(_v67.termName) {
                  case "ApplyTypeFun": {ESLVal $505 = _v67.termRef(0);
                    ESLVal $504 = _v67.termRef(1);
                    ESLVal $503 = _v67.termRef(2);
                    
                    {ESLVal _v385 = _v68;
                    
                    {ESLVal l = $505;
                    
                    {ESLVal op = $504;
                    
                    {ESLVal args = $503;
                    
                    return typeEqual.apply(_v385,applyTypeFun.apply(l,forceType.apply(op),args));
                  }
                  }
                  }
                  }
                  }
                case "ExtendedAct": {ESLVal $502 = _v67.termRef(0);
                    ESLVal $501 = _v67.termRef(1);
                    ESLVal $500 = _v67.termRef(2);
                    ESLVal $499 = _v67.termRef(3);
                    
                    {ESLVal _v383 = _v68;
                    
                    {ESLVal l2 = $502;
                    
                    {ESLVal _v384 = $501;
                    
                    {ESLVal ds2 = $500;
                    
                    {ESLVal ms2 = $499;
                    
                    return typeEqual.apply(_v383,flattenAct.apply(l2,_v384,ds2,ms2));
                  }
                  }
                  }
                  }
                  }
                  }
                case "VoidType": {ESLVal $498 = _v67.termRef(0);
                    
                    {ESLVal t = _v68;
                    
                    {ESLVal l1 = $498;
                    
                    return $true;
                  }
                  }
                  }
                case "TermType": {ESLVal $497 = _v67.termRef(0);
                    ESLVal $496 = _v67.termRef(1);
                    ESLVal $495 = _v67.termRef(2);
                    
                    {ESLVal _v382 = _v68;
                    
                    {ESLVal l2 = $497;
                    
                    {ESLVal n2 = $496;
                    
                    {ESLVal args2 = $495;
                    
                    return $false;
                  }
                  }
                  }
                  }
                  }
                case "TypeClosure": {ESLVal $494 = _v67.termRef(0);
                    
                    {ESLVal _v381 = _v68;
                    
                    {ESLVal f = $494;
                    
                    return typeEqual.apply(_v381,f.apply());
                  }
                  }
                  }
                case "RecType": {ESLVal $493 = _v67.termRef(0);
                    ESLVal $492 = _v67.termRef(1);
                    ESLVal $491 = _v67.termRef(2);
                    
                    {ESLVal _v379 = _v68;
                    
                    {ESLVal l2 = $493;
                    
                    {ESLVal n2 = $492;
                    
                    {ESLVal _v380 = $491;
                    
                    return typeEqual.apply(_v379,substType.apply(new ESLVal("RecType",l2,n2,_v380),n2,_v380));
                  }
                  }
                  }
                  }
                  }
                case "ForallType": {ESLVal $490 = _v67.termRef(0);
                    ESLVal $489 = _v67.termRef(1);
                    ESLVal $488 = _v67.termRef(2);
                    
                    {ESLVal _v377 = _v68;
                    
                    {ESLVal l1 = $490;
                    
                    {ESLVal ns2 = $489;
                    
                    {ESLVal _v378 = $488;
                    
                    return typeEqual.apply(_v377,_v378);
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v386 = _v68;
                    
                    {ESLVal _v387 = _v67;
                    
                    return $false;
                  }
                  }
                }
              else switch(_v67.termName) {
                  case "ApplyTypeFun": {ESLVal $505 = _v67.termRef(0);
                    ESLVal $504 = _v67.termRef(1);
                    ESLVal $503 = _v67.termRef(2);
                    
                    {ESLVal _v396 = _v68;
                    
                    {ESLVal l = $505;
                    
                    {ESLVal op = $504;
                    
                    {ESLVal args = $503;
                    
                    return typeEqual.apply(_v396,applyTypeFun.apply(l,forceType.apply(op),args));
                  }
                  }
                  }
                  }
                  }
                case "ExtendedAct": {ESLVal $502 = _v67.termRef(0);
                    ESLVal $501 = _v67.termRef(1);
                    ESLVal $500 = _v67.termRef(2);
                    ESLVal $499 = _v67.termRef(3);
                    
                    {ESLVal _v394 = _v68;
                    
                    {ESLVal l2 = $502;
                    
                    {ESLVal _v395 = $501;
                    
                    {ESLVal ds2 = $500;
                    
                    {ESLVal ms2 = $499;
                    
                    return typeEqual.apply(_v394,flattenAct.apply(l2,_v395,ds2,ms2));
                  }
                  }
                  }
                  }
                  }
                  }
                case "VoidType": {ESLVal $498 = _v67.termRef(0);
                    
                    {ESLVal t = _v68;
                    
                    {ESLVal l1 = $498;
                    
                    return $true;
                  }
                  }
                  }
                case "TermType": {ESLVal $497 = _v67.termRef(0);
                    ESLVal $496 = _v67.termRef(1);
                    ESLVal $495 = _v67.termRef(2);
                    
                    {ESLVal _v393 = _v68;
                    
                    {ESLVal l2 = $497;
                    
                    {ESLVal n2 = $496;
                    
                    {ESLVal args2 = $495;
                    
                    return $false;
                  }
                  }
                  }
                  }
                  }
                case "TypeClosure": {ESLVal $494 = _v67.termRef(0);
                    
                    {ESLVal _v392 = _v68;
                    
                    {ESLVal f = $494;
                    
                    return typeEqual.apply(_v392,f.apply());
                  }
                  }
                  }
                case "RecType": {ESLVal $493 = _v67.termRef(0);
                    ESLVal $492 = _v67.termRef(1);
                    ESLVal $491 = _v67.termRef(2);
                    
                    {ESLVal _v390 = _v68;
                    
                    {ESLVal l2 = $493;
                    
                    {ESLVal n2 = $492;
                    
                    {ESLVal _v391 = $491;
                    
                    return typeEqual.apply(_v390,substType.apply(new ESLVal("RecType",l2,n2,_v391),n2,_v391));
                  }
                  }
                  }
                  }
                  }
                case "ForallType": {ESLVal $490 = _v67.termRef(0);
                    ESLVal $489 = _v67.termRef(1);
                    ESLVal $488 = _v67.termRef(2);
                    
                    {ESLVal _v388 = _v68;
                    
                    {ESLVal l1 = $490;
                    
                    {ESLVal ns2 = $489;
                    
                    {ESLVal _v389 = $488;
                    
                    return typeEqual.apply(_v388,_v389);
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v397 = _v68;
                    
                    {ESLVal _v398 = _v67;
                    
                    return $false;
                  }
                  }
                }
              }
              default: switch(_v67.termName) {
                case "ApplyTypeFun": {ESLVal $505 = _v67.termRef(0);
                  ESLVal $504 = _v67.termRef(1);
                  ESLVal $503 = _v67.termRef(2);
                  
                  {ESLVal _v409 = _v68;
                  
                  {ESLVal l = $505;
                  
                  {ESLVal op = $504;
                  
                  {ESLVal args = $503;
                  
                  return typeEqual.apply(_v409,applyTypeFun.apply(l,forceType.apply(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $502 = _v67.termRef(0);
                  ESLVal $501 = _v67.termRef(1);
                  ESLVal $500 = _v67.termRef(2);
                  ESLVal $499 = _v67.termRef(3);
                  
                  {ESLVal _v407 = _v68;
                  
                  {ESLVal l2 = $502;
                  
                  {ESLVal _v408 = $501;
                  
                  {ESLVal ds2 = $500;
                  
                  {ESLVal ms2 = $499;
                  
                  return typeEqual.apply(_v407,flattenAct.apply(l2,_v408,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $498 = _v67.termRef(0);
                  
                  {ESLVal t = _v68;
                  
                  {ESLVal l1 = $498;
                  
                  return $true;
                }
                }
                }
              case "TermType": {ESLVal $497 = _v67.termRef(0);
                  ESLVal $496 = _v67.termRef(1);
                  ESLVal $495 = _v67.termRef(2);
                  
                  {ESLVal _v406 = _v68;
                  
                  {ESLVal l2 = $497;
                  
                  {ESLVal n2 = $496;
                  
                  {ESLVal args2 = $495;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $494 = _v67.termRef(0);
                  
                  {ESLVal _v405 = _v68;
                  
                  {ESLVal f = $494;
                  
                  return typeEqual.apply(_v405,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $493 = _v67.termRef(0);
                  ESLVal $492 = _v67.termRef(1);
                  ESLVal $491 = _v67.termRef(2);
                  
                  {ESLVal _v403 = _v68;
                  
                  {ESLVal l2 = $493;
                  
                  {ESLVal n2 = $492;
                  
                  {ESLVal _v404 = $491;
                  
                  return typeEqual.apply(_v403,substType.apply(new ESLVal("RecType",l2,n2,_v404),n2,_v404));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $490 = _v67.termRef(0);
                  ESLVal $489 = _v67.termRef(1);
                  ESLVal $488 = _v67.termRef(2);
                  
                  {ESLVal _v401 = _v68;
                  
                  {ESLVal l1 = $490;
                  
                  {ESLVal ns2 = $489;
                  
                  {ESLVal _v402 = $488;
                  
                  return typeEqual.apply(_v401,_v402);
                }
                }
                }
                }
                }
                default: {ESLVal _v410 = _v68;
                  
                  {ESLVal _v411 = _v67;
                  
                  return $false;
                }
                }
              }
            }
            }
          case "StrType": {ESLVal $572 = _v68.termRef(0);
              
              switch(_v67.termName) {
              case "StrType": {ESLVal $573 = _v67.termRef(0);
                
                {ESLVal l1 = $572;
                
                {ESLVal l2 = $573;
                
                return $true;
              }
              }
              }
              default: switch(_v67.termName) {
                case "ApplyTypeFun": {ESLVal $505 = _v67.termRef(0);
                  ESLVal $504 = _v67.termRef(1);
                  ESLVal $503 = _v67.termRef(2);
                  
                  {ESLVal _v313 = _v68;
                  
                  {ESLVal l = $505;
                  
                  {ESLVal op = $504;
                  
                  {ESLVal args = $503;
                  
                  return typeEqual.apply(_v313,applyTypeFun.apply(l,forceType.apply(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $502 = _v67.termRef(0);
                  ESLVal $501 = _v67.termRef(1);
                  ESLVal $500 = _v67.termRef(2);
                  ESLVal $499 = _v67.termRef(3);
                  
                  {ESLVal _v311 = _v68;
                  
                  {ESLVal l2 = $502;
                  
                  {ESLVal _v312 = $501;
                  
                  {ESLVal ds2 = $500;
                  
                  {ESLVal ms2 = $499;
                  
                  return typeEqual.apply(_v311,flattenAct.apply(l2,_v312,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $498 = _v67.termRef(0);
                  
                  {ESLVal t = _v68;
                  
                  {ESLVal l1 = $498;
                  
                  return $true;
                }
                }
                }
              case "TermType": {ESLVal $497 = _v67.termRef(0);
                  ESLVal $496 = _v67.termRef(1);
                  ESLVal $495 = _v67.termRef(2);
                  
                  {ESLVal _v310 = _v68;
                  
                  {ESLVal l2 = $497;
                  
                  {ESLVal n2 = $496;
                  
                  {ESLVal args2 = $495;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $494 = _v67.termRef(0);
                  
                  {ESLVal _v309 = _v68;
                  
                  {ESLVal f = $494;
                  
                  return typeEqual.apply(_v309,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $493 = _v67.termRef(0);
                  ESLVal $492 = _v67.termRef(1);
                  ESLVal $491 = _v67.termRef(2);
                  
                  {ESLVal _v307 = _v68;
                  
                  {ESLVal l2 = $493;
                  
                  {ESLVal n2 = $492;
                  
                  {ESLVal _v308 = $491;
                  
                  return typeEqual.apply(_v307,substType.apply(new ESLVal("RecType",l2,n2,_v308),n2,_v308));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $490 = _v67.termRef(0);
                  ESLVal $489 = _v67.termRef(1);
                  ESLVal $488 = _v67.termRef(2);
                  
                  {ESLVal _v305 = _v68;
                  
                  {ESLVal l1 = $490;
                  
                  {ESLVal ns2 = $489;
                  
                  {ESLVal _v306 = $488;
                  
                  return typeEqual.apply(_v305,_v306);
                }
                }
                }
                }
                }
                default: {ESLVal _v314 = _v68;
                  
                  {ESLVal _v315 = _v67;
                  
                  return $false;
                }
                }
              }
            }
            }
          case "VoidType": {ESLVal $571 = _v68.termRef(0);
              
              {ESLVal l1 = $571;
              
              {ESLVal t = _v67;
              
              return $true;
            }
            }
            }
          case "FieldType": {ESLVal $567 = _v68.termRef(0);
              ESLVal $566 = _v68.termRef(1);
              ESLVal $565 = _v68.termRef(2);
              
              switch(_v67.termName) {
              case "FieldType": {ESLVal $570 = _v67.termRef(0);
                ESLVal $569 = _v67.termRef(1);
                ESLVal $568 = _v67.termRef(2);
                
                {ESLVal l1 = $567;
                
                {ESLVal n1 = $566;
                
                {ESLVal _v292 = $565;
                
                {ESLVal l2 = $570;
                
                {ESLVal n2 = $569;
                
                {ESLVal _v293 = $568;
                
                return n1.eql(n2).and(typeEqual.apply(_v292,_v293));
              }
              }
              }
              }
              }
              }
              }
              default: switch(_v67.termName) {
                case "ApplyTypeFun": {ESLVal $505 = _v67.termRef(0);
                  ESLVal $504 = _v67.termRef(1);
                  ESLVal $503 = _v67.termRef(2);
                  
                  {ESLVal _v302 = _v68;
                  
                  {ESLVal l = $505;
                  
                  {ESLVal op = $504;
                  
                  {ESLVal args = $503;
                  
                  return typeEqual.apply(_v302,applyTypeFun.apply(l,forceType.apply(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $502 = _v67.termRef(0);
                  ESLVal $501 = _v67.termRef(1);
                  ESLVal $500 = _v67.termRef(2);
                  ESLVal $499 = _v67.termRef(3);
                  
                  {ESLVal _v300 = _v68;
                  
                  {ESLVal l2 = $502;
                  
                  {ESLVal _v301 = $501;
                  
                  {ESLVal ds2 = $500;
                  
                  {ESLVal ms2 = $499;
                  
                  return typeEqual.apply(_v300,flattenAct.apply(l2,_v301,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $498 = _v67.termRef(0);
                  
                  {ESLVal t = _v68;
                  
                  {ESLVal l1 = $498;
                  
                  return $true;
                }
                }
                }
              case "TermType": {ESLVal $497 = _v67.termRef(0);
                  ESLVal $496 = _v67.termRef(1);
                  ESLVal $495 = _v67.termRef(2);
                  
                  {ESLVal _v299 = _v68;
                  
                  {ESLVal l2 = $497;
                  
                  {ESLVal n2 = $496;
                  
                  {ESLVal args2 = $495;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $494 = _v67.termRef(0);
                  
                  {ESLVal _v298 = _v68;
                  
                  {ESLVal f = $494;
                  
                  return typeEqual.apply(_v298,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $493 = _v67.termRef(0);
                  ESLVal $492 = _v67.termRef(1);
                  ESLVal $491 = _v67.termRef(2);
                  
                  {ESLVal _v296 = _v68;
                  
                  {ESLVal l2 = $493;
                  
                  {ESLVal n2 = $492;
                  
                  {ESLVal _v297 = $491;
                  
                  return typeEqual.apply(_v296,substType.apply(new ESLVal("RecType",l2,n2,_v297),n2,_v297));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $490 = _v67.termRef(0);
                  ESLVal $489 = _v67.termRef(1);
                  ESLVal $488 = _v67.termRef(2);
                  
                  {ESLVal _v294 = _v68;
                  
                  {ESLVal l1 = $490;
                  
                  {ESLVal ns2 = $489;
                  
                  {ESLVal _v295 = $488;
                  
                  return typeEqual.apply(_v294,_v295);
                }
                }
                }
                }
                }
                default: {ESLVal _v303 = _v68;
                  
                  {ESLVal _v304 = _v67;
                  
                  return $false;
                }
                }
              }
            }
            }
          case "TableType": {ESLVal $561 = _v68.termRef(0);
              ESLVal $560 = _v68.termRef(1);
              ESLVal $559 = _v68.termRef(2);
              
              switch(_v67.termName) {
              case "TableType": {ESLVal $564 = _v67.termRef(0);
                ESLVal $563 = _v67.termRef(1);
                ESLVal $562 = _v67.termRef(2);
                
                {ESLVal l1 = $561;
                
                {ESLVal k1 = $560;
                
                {ESLVal v1 = $559;
                
                {ESLVal l2 = $564;
                
                {ESLVal k2 = $563;
                
                {ESLVal v2 = $562;
                
                return typeEqual.apply(k1,k2).and(typeEqual.apply(v1,v2));
              }
              }
              }
              }
              }
              }
              }
              default: switch(_v67.termName) {
                case "ApplyTypeFun": {ESLVal $505 = _v67.termRef(0);
                  ESLVal $504 = _v67.termRef(1);
                  ESLVal $503 = _v67.termRef(2);
                  
                  {ESLVal _v289 = _v68;
                  
                  {ESLVal l = $505;
                  
                  {ESLVal op = $504;
                  
                  {ESLVal args = $503;
                  
                  return typeEqual.apply(_v289,applyTypeFun.apply(l,forceType.apply(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $502 = _v67.termRef(0);
                  ESLVal $501 = _v67.termRef(1);
                  ESLVal $500 = _v67.termRef(2);
                  ESLVal $499 = _v67.termRef(3);
                  
                  {ESLVal _v287 = _v68;
                  
                  {ESLVal l2 = $502;
                  
                  {ESLVal _v288 = $501;
                  
                  {ESLVal ds2 = $500;
                  
                  {ESLVal ms2 = $499;
                  
                  return typeEqual.apply(_v287,flattenAct.apply(l2,_v288,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $498 = _v67.termRef(0);
                  
                  {ESLVal t = _v68;
                  
                  {ESLVal l1 = $498;
                  
                  return $true;
                }
                }
                }
              case "TermType": {ESLVal $497 = _v67.termRef(0);
                  ESLVal $496 = _v67.termRef(1);
                  ESLVal $495 = _v67.termRef(2);
                  
                  {ESLVal _v286 = _v68;
                  
                  {ESLVal l2 = $497;
                  
                  {ESLVal n2 = $496;
                  
                  {ESLVal args2 = $495;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $494 = _v67.termRef(0);
                  
                  {ESLVal _v285 = _v68;
                  
                  {ESLVal f = $494;
                  
                  return typeEqual.apply(_v285,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $493 = _v67.termRef(0);
                  ESLVal $492 = _v67.termRef(1);
                  ESLVal $491 = _v67.termRef(2);
                  
                  {ESLVal _v283 = _v68;
                  
                  {ESLVal l2 = $493;
                  
                  {ESLVal n2 = $492;
                  
                  {ESLVal _v284 = $491;
                  
                  return typeEqual.apply(_v283,substType.apply(new ESLVal("RecType",l2,n2,_v284),n2,_v284));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $490 = _v67.termRef(0);
                  ESLVal $489 = _v67.termRef(1);
                  ESLVal $488 = _v67.termRef(2);
                  
                  {ESLVal _v281 = _v68;
                  
                  {ESLVal l1 = $490;
                  
                  {ESLVal ns2 = $489;
                  
                  {ESLVal _v282 = $488;
                  
                  return typeEqual.apply(_v281,_v282);
                }
                }
                }
                }
                }
                default: {ESLVal _v290 = _v68;
                  
                  {ESLVal _v291 = _v67;
                  
                  return $false;
                }
                }
              }
            }
            }
          case "TermType": {ESLVal $555 = _v68.termRef(0);
              ESLVal $554 = _v68.termRef(1);
              ESLVal $553 = _v68.termRef(2);
              
              switch(_v67.termName) {
              case "TermType": {ESLVal $558 = _v67.termRef(0);
                ESLVal $557 = _v67.termRef(1);
                ESLVal $556 = _v67.termRef(2);
                
                {ESLVal l1 = $555;
                
                {ESLVal n1 = $554;
                
                {ESLVal args1 = $553;
                
                {ESLVal l2 = $558;
                
                {ESLVal n2 = $557;
                
                {ESLVal args2 = $556;
                
                if(n1.eql(n2).boolVal)
                return typesEqual.apply(args1,args2);
                else
                  return $false;
              }
              }
              }
              }
              }
              }
              }
              default: {ESLVal l1 = $555;
                
                {ESLVal n1 = $554;
                
                {ESLVal args1 = $553;
                
                {ESLVal _v280 = _v67;
                
                return $false;
              }
              }
              }
              }
            }
            }
          case "FunType": {ESLVal $549 = _v68.termRef(0);
              ESLVal $548 = _v68.termRef(1);
              ESLVal $547 = _v68.termRef(2);
              
              switch(_v67.termName) {
              case "FunType": {ESLVal $552 = _v67.termRef(0);
                ESLVal $551 = _v67.termRef(1);
                ESLVal $550 = _v67.termRef(2);
                
                {ESLVal l1 = $549;
                
                {ESLVal d1 = $548;
                
                {ESLVal r1 = $547;
                
                {ESLVal l2 = $552;
                
                {ESLVal d2 = $551;
                
                {ESLVal r2 = $550;
                
                return typeEqual.apply(r1,r2).and(typesEqual.apply(d1,d2));
              }
              }
              }
              }
              }
              }
              }
              default: switch(_v67.termName) {
                case "ApplyTypeFun": {ESLVal $505 = _v67.termRef(0);
                  ESLVal $504 = _v67.termRef(1);
                  ESLVal $503 = _v67.termRef(2);
                  
                  {ESLVal _v277 = _v68;
                  
                  {ESLVal l = $505;
                  
                  {ESLVal op = $504;
                  
                  {ESLVal args = $503;
                  
                  return typeEqual.apply(_v277,applyTypeFun.apply(l,forceType.apply(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $502 = _v67.termRef(0);
                  ESLVal $501 = _v67.termRef(1);
                  ESLVal $500 = _v67.termRef(2);
                  ESLVal $499 = _v67.termRef(3);
                  
                  {ESLVal _v275 = _v68;
                  
                  {ESLVal l2 = $502;
                  
                  {ESLVal _v276 = $501;
                  
                  {ESLVal ds2 = $500;
                  
                  {ESLVal ms2 = $499;
                  
                  return typeEqual.apply(_v275,flattenAct.apply(l2,_v276,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $498 = _v67.termRef(0);
                  
                  {ESLVal t = _v68;
                  
                  {ESLVal l1 = $498;
                  
                  return $true;
                }
                }
                }
              case "TermType": {ESLVal $497 = _v67.termRef(0);
                  ESLVal $496 = _v67.termRef(1);
                  ESLVal $495 = _v67.termRef(2);
                  
                  {ESLVal _v274 = _v68;
                  
                  {ESLVal l2 = $497;
                  
                  {ESLVal n2 = $496;
                  
                  {ESLVal args2 = $495;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $494 = _v67.termRef(0);
                  
                  {ESLVal _v273 = _v68;
                  
                  {ESLVal f = $494;
                  
                  return typeEqual.apply(_v273,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $493 = _v67.termRef(0);
                  ESLVal $492 = _v67.termRef(1);
                  ESLVal $491 = _v67.termRef(2);
                  
                  {ESLVal _v271 = _v68;
                  
                  {ESLVal l2 = $493;
                  
                  {ESLVal n2 = $492;
                  
                  {ESLVal _v272 = $491;
                  
                  return typeEqual.apply(_v271,substType.apply(new ESLVal("RecType",l2,n2,_v272),n2,_v272));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $490 = _v67.termRef(0);
                  ESLVal $489 = _v67.termRef(1);
                  ESLVal $488 = _v67.termRef(2);
                  
                  {ESLVal _v269 = _v68;
                  
                  {ESLVal l1 = $490;
                  
                  {ESLVal ns2 = $489;
                  
                  {ESLVal _v270 = $488;
                  
                  return typeEqual.apply(_v269,_v270);
                }
                }
                }
                }
                }
                default: {ESLVal _v278 = _v68;
                  
                  {ESLVal _v279 = _v67;
                  
                  return $false;
                }
                }
              }
            }
            }
          case "TypeClosure": {ESLVal $546 = _v68.termRef(0);
              
              {ESLVal f = $546;
              
              {ESLVal _v268 = _v67;
              
              return typeEqual.apply(f.apply(),_v268);
            }
            }
            }
          case "RecordType": {ESLVal $543 = _v68.termRef(0);
              ESLVal $542 = _v68.termRef(1);
              
              switch(_v67.termName) {
              case "RecordType": {ESLVal $545 = _v67.termRef(0);
                ESLVal $544 = _v67.termRef(1);
                
                {ESLVal l1 = $543;
                
                {ESLVal fs1 = $542;
                
                {ESLVal l2 = $545;
                
                {ESLVal fs2 = $544;
                
                return recordTypeEqual.apply(fs1,fs2);
              }
              }
              }
              }
              }
              default: switch(_v67.termName) {
                case "ApplyTypeFun": {ESLVal $505 = _v67.termRef(0);
                  ESLVal $504 = _v67.termRef(1);
                  ESLVal $503 = _v67.termRef(2);
                  
                  {ESLVal _v265 = _v68;
                  
                  {ESLVal l = $505;
                  
                  {ESLVal op = $504;
                  
                  {ESLVal args = $503;
                  
                  return typeEqual.apply(_v265,applyTypeFun.apply(l,forceType.apply(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $502 = _v67.termRef(0);
                  ESLVal $501 = _v67.termRef(1);
                  ESLVal $500 = _v67.termRef(2);
                  ESLVal $499 = _v67.termRef(3);
                  
                  {ESLVal _v263 = _v68;
                  
                  {ESLVal l2 = $502;
                  
                  {ESLVal _v264 = $501;
                  
                  {ESLVal ds2 = $500;
                  
                  {ESLVal ms2 = $499;
                  
                  return typeEqual.apply(_v263,flattenAct.apply(l2,_v264,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $498 = _v67.termRef(0);
                  
                  {ESLVal t = _v68;
                  
                  {ESLVal l1 = $498;
                  
                  return $true;
                }
                }
                }
              case "TermType": {ESLVal $497 = _v67.termRef(0);
                  ESLVal $496 = _v67.termRef(1);
                  ESLVal $495 = _v67.termRef(2);
                  
                  {ESLVal _v262 = _v68;
                  
                  {ESLVal l2 = $497;
                  
                  {ESLVal n2 = $496;
                  
                  {ESLVal args2 = $495;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $494 = _v67.termRef(0);
                  
                  {ESLVal _v261 = _v68;
                  
                  {ESLVal f = $494;
                  
                  return typeEqual.apply(_v261,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $493 = _v67.termRef(0);
                  ESLVal $492 = _v67.termRef(1);
                  ESLVal $491 = _v67.termRef(2);
                  
                  {ESLVal _v259 = _v68;
                  
                  {ESLVal l2 = $493;
                  
                  {ESLVal n2 = $492;
                  
                  {ESLVal _v260 = $491;
                  
                  return typeEqual.apply(_v259,substType.apply(new ESLVal("RecType",l2,n2,_v260),n2,_v260));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $490 = _v67.termRef(0);
                  ESLVal $489 = _v67.termRef(1);
                  ESLVal $488 = _v67.termRef(2);
                  
                  {ESLVal _v257 = _v68;
                  
                  {ESLVal l1 = $490;
                  
                  {ESLVal ns2 = $489;
                  
                  {ESLVal _v258 = $488;
                  
                  return typeEqual.apply(_v257,_v258);
                }
                }
                }
                }
                }
                default: {ESLVal _v266 = _v68;
                  
                  {ESLVal _v267 = _v67;
                  
                  return $false;
                }
                }
              }
            }
            }
          case "RecType": {ESLVal $538 = _v68.termRef(0);
              ESLVal $537 = _v68.termRef(1);
              ESLVal $536 = _v68.termRef(2);
              
              switch(_v67.termName) {
              case "RecType": {ESLVal $541 = _v67.termRef(0);
                ESLVal $540 = _v67.termRef(1);
                ESLVal $539 = _v67.termRef(2);
                
                {ESLVal l1 = $538;
                
                {ESLVal n1 = $537;
                
                {ESLVal _v249 = $536;
                
                {ESLVal l2 = $541;
                
                {ESLVal n2 = $540;
                
                {ESLVal _v250 = $539;
                
                if(n1.eql(n2).boolVal)
                return typeEqual.apply(_v249,_v250);
                else
                  {ESLVal _v251 = $538;
                    
                    {ESLVal _v252 = $537;
                    
                    {ESLVal _v253 = $536;
                    
                    {ESLVal _v254 = _v67;
                    
                    return typeEqual.apply(substType.apply(new ESLVal("RecType",_v251,_v252,_v253),_v252,_v253),_v254);
                  }
                  }
                  }
                  }
              }
              }
              }
              }
              }
              }
              }
              default: {ESLVal l1 = $538;
                
                {ESLVal n1 = $537;
                
                {ESLVal _v255 = $536;
                
                {ESLVal _v256 = _v67;
                
                return typeEqual.apply(substType.apply(new ESLVal("RecType",l1,n1,_v255),n1,_v255),_v256);
              }
              }
              }
              }
            }
            }
          case "UnionType": {ESLVal $533 = _v68.termRef(0);
              ESLVal $532 = _v68.termRef(1);
              
              switch(_v67.termName) {
              case "UnionType": {ESLVal $535 = _v67.termRef(0);
                ESLVal $534 = _v67.termRef(1);
                
                {ESLVal l1 = $533;
                
                {ESLVal terms1 = $532;
                
                {ESLVal l2 = $535;
                
                {ESLVal terms2 = $534;
                
                return typeSetEqual.apply(terms1,terms2);
              }
              }
              }
              }
              }
              default: switch(_v67.termName) {
                case "ApplyTypeFun": {ESLVal $505 = _v67.termRef(0);
                  ESLVal $504 = _v67.termRef(1);
                  ESLVal $503 = _v67.termRef(2);
                  
                  {ESLVal _v246 = _v68;
                  
                  {ESLVal l = $505;
                  
                  {ESLVal op = $504;
                  
                  {ESLVal args = $503;
                  
                  return typeEqual.apply(_v246,applyTypeFun.apply(l,forceType.apply(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $502 = _v67.termRef(0);
                  ESLVal $501 = _v67.termRef(1);
                  ESLVal $500 = _v67.termRef(2);
                  ESLVal $499 = _v67.termRef(3);
                  
                  {ESLVal _v244 = _v68;
                  
                  {ESLVal l2 = $502;
                  
                  {ESLVal _v245 = $501;
                  
                  {ESLVal ds2 = $500;
                  
                  {ESLVal ms2 = $499;
                  
                  return typeEqual.apply(_v244,flattenAct.apply(l2,_v245,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $498 = _v67.termRef(0);
                  
                  {ESLVal t = _v68;
                  
                  {ESLVal l1 = $498;
                  
                  return $true;
                }
                }
                }
              case "TermType": {ESLVal $497 = _v67.termRef(0);
                  ESLVal $496 = _v67.termRef(1);
                  ESLVal $495 = _v67.termRef(2);
                  
                  {ESLVal _v243 = _v68;
                  
                  {ESLVal l2 = $497;
                  
                  {ESLVal n2 = $496;
                  
                  {ESLVal args2 = $495;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $494 = _v67.termRef(0);
                  
                  {ESLVal _v242 = _v68;
                  
                  {ESLVal f = $494;
                  
                  return typeEqual.apply(_v242,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $493 = _v67.termRef(0);
                  ESLVal $492 = _v67.termRef(1);
                  ESLVal $491 = _v67.termRef(2);
                  
                  {ESLVal _v240 = _v68;
                  
                  {ESLVal l2 = $493;
                  
                  {ESLVal n2 = $492;
                  
                  {ESLVal _v241 = $491;
                  
                  return typeEqual.apply(_v240,substType.apply(new ESLVal("RecType",l2,n2,_v241),n2,_v241));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $490 = _v67.termRef(0);
                  ESLVal $489 = _v67.termRef(1);
                  ESLVal $488 = _v67.termRef(2);
                  
                  {ESLVal _v238 = _v68;
                  
                  {ESLVal l1 = $490;
                  
                  {ESLVal ns2 = $489;
                  
                  {ESLVal _v239 = $488;
                  
                  return typeEqual.apply(_v238,_v239);
                }
                }
                }
                }
                }
                default: {ESLVal _v247 = _v68;
                  
                  {ESLVal _v248 = _v67;
                  
                  return $false;
                }
                }
              }
            }
            }
          case "VarType": {ESLVal $529 = _v68.termRef(0);
              ESLVal $528 = _v68.termRef(1);
              
              switch(_v67.termName) {
              case "VarType": {ESLVal $531 = _v67.termRef(0);
                ESLVal $530 = _v67.termRef(1);
                
                {ESLVal l1 = $529;
                
                {ESLVal n1 = $528;
                
                {ESLVal l2 = $531;
                
                {ESLVal n2 = $530;
                
                return n1.eql(n2);
              }
              }
              }
              }
              }
              default: switch(_v67.termName) {
                case "ApplyTypeFun": {ESLVal $505 = _v67.termRef(0);
                  ESLVal $504 = _v67.termRef(1);
                  ESLVal $503 = _v67.termRef(2);
                  
                  {ESLVal _v235 = _v68;
                  
                  {ESLVal l = $505;
                  
                  {ESLVal op = $504;
                  
                  {ESLVal args = $503;
                  
                  return typeEqual.apply(_v235,applyTypeFun.apply(l,forceType.apply(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $502 = _v67.termRef(0);
                  ESLVal $501 = _v67.termRef(1);
                  ESLVal $500 = _v67.termRef(2);
                  ESLVal $499 = _v67.termRef(3);
                  
                  {ESLVal _v233 = _v68;
                  
                  {ESLVal l2 = $502;
                  
                  {ESLVal _v234 = $501;
                  
                  {ESLVal ds2 = $500;
                  
                  {ESLVal ms2 = $499;
                  
                  return typeEqual.apply(_v233,flattenAct.apply(l2,_v234,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $498 = _v67.termRef(0);
                  
                  {ESLVal t = _v68;
                  
                  {ESLVal l1 = $498;
                  
                  return $true;
                }
                }
                }
              case "TermType": {ESLVal $497 = _v67.termRef(0);
                  ESLVal $496 = _v67.termRef(1);
                  ESLVal $495 = _v67.termRef(2);
                  
                  {ESLVal _v232 = _v68;
                  
                  {ESLVal l2 = $497;
                  
                  {ESLVal n2 = $496;
                  
                  {ESLVal args2 = $495;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $494 = _v67.termRef(0);
                  
                  {ESLVal _v231 = _v68;
                  
                  {ESLVal f = $494;
                  
                  return typeEqual.apply(_v231,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $493 = _v67.termRef(0);
                  ESLVal $492 = _v67.termRef(1);
                  ESLVal $491 = _v67.termRef(2);
                  
                  {ESLVal _v229 = _v68;
                  
                  {ESLVal l2 = $493;
                  
                  {ESLVal n2 = $492;
                  
                  {ESLVal _v230 = $491;
                  
                  return typeEqual.apply(_v229,substType.apply(new ESLVal("RecType",l2,n2,_v230),n2,_v230));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $490 = _v67.termRef(0);
                  ESLVal $489 = _v67.termRef(1);
                  ESLVal $488 = _v67.termRef(2);
                  
                  {ESLVal _v227 = _v68;
                  
                  {ESLVal l1 = $490;
                  
                  {ESLVal ns2 = $489;
                  
                  {ESLVal _v228 = $488;
                  
                  return typeEqual.apply(_v227,_v228);
                }
                }
                }
                }
                }
                default: {ESLVal _v236 = _v68;
                  
                  {ESLVal _v237 = _v67;
                  
                  return $false;
                }
                }
              }
            }
            }
          case "ForallType": {ESLVal $508 = _v68.termRef(0);
              ESLVal $507 = _v68.termRef(1);
              ESLVal $506 = _v68.termRef(2);
              
              if($507.isCons())
              {ESLVal $512 = $507.head();
                ESLVal $513 = $507.tail();
                
                if($513.isCons())
                {ESLVal $514 = $513.head();
                  ESLVal $515 = $513.tail();
                  
                  switch(_v67.termName) {
                  case "ForallType": {ESLVal $511 = _v67.termRef(0);
                    ESLVal $510 = _v67.termRef(1);
                    ESLVal $509 = _v67.termRef(2);
                    
                    {ESLVal l1 = $508;
                    
                    {ESLVal ns1 = $507;
                    
                    {ESLVal _v175 = $506;
                    
                    {ESLVal l2 = $511;
                    
                    {ESLVal ns2 = $510;
                    
                    {ESLVal _v176 = $509;
                    
                    return ns1.eql(ns2).and(typeEqual.apply(_v175,_v176));
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal l1 = $508;
                    
                    {ESLVal ns1 = $507;
                    
                    {ESLVal _v177 = $506;
                    
                    {ESLVal _v178 = _v67;
                    
                    return typeEqual.apply(_v177,_v178);
                  }
                  }
                  }
                  }
                }
                }
              else if($513.isNil())
                switch($506.termName) {
                  case "ListType": {ESLVal $523 = $506.termRef(0);
                    ESLVal $522 = $506.termRef(1);
                    
                    switch($522.termName) {
                    case "VarType": {ESLVal $525 = $522.termRef(0);
                      ESLVal $524 = $522.termRef(1);
                      
                      switch(_v67.termName) {
                      case "ListType": {ESLVal $527 = _v67.termRef(0);
                        ESLVal $526 = _v67.termRef(1);
                        
                        {ESLVal l2 = $508;
                        
                        {ESLVal v1 = $512;
                        
                        {ESLVal l3 = $523;
                        
                        {ESLVal l4 = $525;
                        
                        {ESLVal v2 = $524;
                        
                        {ESLVal l1 = $527;
                        
                        {ESLVal _v195 = $526;
                        
                        if(v1.eql(v2).boolVal)
                        return $true;
                        else
                          switch(_v67.termName) {
                            case "ForallType": {ESLVal $511 = _v67.termRef(0);
                              ESLVal $510 = _v67.termRef(1);
                              ESLVal $509 = _v67.termRef(2);
                              
                              {ESLVal _v196 = $508;
                              
                              {ESLVal ns1 = $507;
                              
                              {ESLVal _v197 = $506;
                              
                              {ESLVal _v198 = $511;
                              
                              {ESLVal ns2 = $510;
                              
                              {ESLVal _v199 = $509;
                              
                              return ns1.eql(ns2).and(typeEqual.apply(_v197,_v199));
                            }
                            }
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v200 = $508;
                              
                              {ESLVal ns1 = $507;
                              
                              {ESLVal _v201 = $506;
                              
                              {ESLVal _v202 = _v67;
                              
                              return typeEqual.apply(_v201,_v202);
                            }
                            }
                            }
                            }
                          }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      default: switch(_v67.termName) {
                        case "ForallType": {ESLVal $511 = _v67.termRef(0);
                          ESLVal $510 = _v67.termRef(1);
                          ESLVal $509 = _v67.termRef(2);
                          
                          {ESLVal l1 = $508;
                          
                          {ESLVal ns1 = $507;
                          
                          {ESLVal _v203 = $506;
                          
                          {ESLVal l2 = $511;
                          
                          {ESLVal ns2 = $510;
                          
                          {ESLVal _v204 = $509;
                          
                          return ns1.eql(ns2).and(typeEqual.apply(_v203,_v204));
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal l1 = $508;
                          
                          {ESLVal ns1 = $507;
                          
                          {ESLVal _v205 = $506;
                          
                          {ESLVal _v206 = _v67;
                          
                          return typeEqual.apply(_v205,_v206);
                        }
                        }
                        }
                        }
                      }
                    }
                    }
                    default: switch(_v67.termName) {
                      case "ForallType": {ESLVal $511 = _v67.termRef(0);
                        ESLVal $510 = _v67.termRef(1);
                        ESLVal $509 = _v67.termRef(2);
                        
                        {ESLVal l1 = $508;
                        
                        {ESLVal ns1 = $507;
                        
                        {ESLVal _v207 = $506;
                        
                        {ESLVal l2 = $511;
                        
                        {ESLVal ns2 = $510;
                        
                        {ESLVal _v208 = $509;
                        
                        return ns1.eql(ns2).and(typeEqual.apply(_v207,_v208));
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal l1 = $508;
                        
                        {ESLVal ns1 = $507;
                        
                        {ESLVal _v209 = $506;
                        
                        {ESLVal _v210 = _v67;
                        
                        return typeEqual.apply(_v209,_v210);
                      }
                      }
                      }
                      }
                    }
                  }
                  }
                case "SetType": {ESLVal $517 = $506.termRef(0);
                    ESLVal $516 = $506.termRef(1);
                    
                    switch($516.termName) {
                    case "VarType": {ESLVal $519 = $516.termRef(0);
                      ESLVal $518 = $516.termRef(1);
                      
                      switch(_v67.termName) {
                      case "SetType": {ESLVal $521 = _v67.termRef(0);
                        ESLVal $520 = _v67.termRef(1);
                        
                        {ESLVal l2 = $508;
                        
                        {ESLVal v1 = $512;
                        
                        {ESLVal l3 = $517;
                        
                        {ESLVal l4 = $519;
                        
                        {ESLVal v2 = $518;
                        
                        {ESLVal l1 = $521;
                        
                        {ESLVal _v179 = $520;
                        
                        if(v1.eql(v2).boolVal)
                        return $true;
                        else
                          switch(_v67.termName) {
                            case "ForallType": {ESLVal $511 = _v67.termRef(0);
                              ESLVal $510 = _v67.termRef(1);
                              ESLVal $509 = _v67.termRef(2);
                              
                              {ESLVal _v180 = $508;
                              
                              {ESLVal ns1 = $507;
                              
                              {ESLVal _v181 = $506;
                              
                              {ESLVal _v182 = $511;
                              
                              {ESLVal ns2 = $510;
                              
                              {ESLVal _v183 = $509;
                              
                              return ns1.eql(ns2).and(typeEqual.apply(_v181,_v183));
                            }
                            }
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v184 = $508;
                              
                              {ESLVal ns1 = $507;
                              
                              {ESLVal _v185 = $506;
                              
                              {ESLVal _v186 = _v67;
                              
                              return typeEqual.apply(_v185,_v186);
                            }
                            }
                            }
                            }
                          }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      default: switch(_v67.termName) {
                        case "ForallType": {ESLVal $511 = _v67.termRef(0);
                          ESLVal $510 = _v67.termRef(1);
                          ESLVal $509 = _v67.termRef(2);
                          
                          {ESLVal l1 = $508;
                          
                          {ESLVal ns1 = $507;
                          
                          {ESLVal _v187 = $506;
                          
                          {ESLVal l2 = $511;
                          
                          {ESLVal ns2 = $510;
                          
                          {ESLVal _v188 = $509;
                          
                          return ns1.eql(ns2).and(typeEqual.apply(_v187,_v188));
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal l1 = $508;
                          
                          {ESLVal ns1 = $507;
                          
                          {ESLVal _v189 = $506;
                          
                          {ESLVal _v190 = _v67;
                          
                          return typeEqual.apply(_v189,_v190);
                        }
                        }
                        }
                        }
                      }
                    }
                    }
                    default: switch(_v67.termName) {
                      case "ForallType": {ESLVal $511 = _v67.termRef(0);
                        ESLVal $510 = _v67.termRef(1);
                        ESLVal $509 = _v67.termRef(2);
                        
                        {ESLVal l1 = $508;
                        
                        {ESLVal ns1 = $507;
                        
                        {ESLVal _v191 = $506;
                        
                        {ESLVal l2 = $511;
                        
                        {ESLVal ns2 = $510;
                        
                        {ESLVal _v192 = $509;
                        
                        return ns1.eql(ns2).and(typeEqual.apply(_v191,_v192));
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal l1 = $508;
                        
                        {ESLVal ns1 = $507;
                        
                        {ESLVal _v193 = $506;
                        
                        {ESLVal _v194 = _v67;
                        
                        return typeEqual.apply(_v193,_v194);
                      }
                      }
                      }
                      }
                    }
                  }
                  }
                  default: switch(_v67.termName) {
                    case "ForallType": {ESLVal $511 = _v67.termRef(0);
                      ESLVal $510 = _v67.termRef(1);
                      ESLVal $509 = _v67.termRef(2);
                      
                      {ESLVal l1 = $508;
                      
                      {ESLVal ns1 = $507;
                      
                      {ESLVal _v211 = $506;
                      
                      {ESLVal l2 = $511;
                      
                      {ESLVal ns2 = $510;
                      
                      {ESLVal _v212 = $509;
                      
                      return ns1.eql(ns2).and(typeEqual.apply(_v211,_v212));
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal l1 = $508;
                      
                      {ESLVal ns1 = $507;
                      
                      {ESLVal _v213 = $506;
                      
                      {ESLVal _v214 = _v67;
                      
                      return typeEqual.apply(_v213,_v214);
                    }
                    }
                    }
                    }
                  }
                }
              else switch(_v67.termName) {
                  case "ForallType": {ESLVal $511 = _v67.termRef(0);
                    ESLVal $510 = _v67.termRef(1);
                    ESLVal $509 = _v67.termRef(2);
                    
                    {ESLVal l1 = $508;
                    
                    {ESLVal ns1 = $507;
                    
                    {ESLVal _v215 = $506;
                    
                    {ESLVal l2 = $511;
                    
                    {ESLVal ns2 = $510;
                    
                    {ESLVal _v216 = $509;
                    
                    return ns1.eql(ns2).and(typeEqual.apply(_v215,_v216));
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal l1 = $508;
                    
                    {ESLVal ns1 = $507;
                    
                    {ESLVal _v217 = $506;
                    
                    {ESLVal _v218 = _v67;
                    
                    return typeEqual.apply(_v217,_v218);
                  }
                  }
                  }
                  }
                }
              }
            else if($507.isNil())
              switch(_v67.termName) {
                case "ForallType": {ESLVal $511 = _v67.termRef(0);
                  ESLVal $510 = _v67.termRef(1);
                  ESLVal $509 = _v67.termRef(2);
                  
                  {ESLVal l1 = $508;
                  
                  {ESLVal ns1 = $507;
                  
                  {ESLVal _v219 = $506;
                  
                  {ESLVal l2 = $511;
                  
                  {ESLVal ns2 = $510;
                  
                  {ESLVal _v220 = $509;
                  
                  return ns1.eql(ns2).and(typeEqual.apply(_v219,_v220));
                }
                }
                }
                }
                }
                }
                }
                default: {ESLVal l1 = $508;
                  
                  {ESLVal ns1 = $507;
                  
                  {ESLVal _v221 = $506;
                  
                  {ESLVal _v222 = _v67;
                  
                  return typeEqual.apply(_v221,_v222);
                }
                }
                }
                }
              }
            else switch(_v67.termName) {
                case "ForallType": {ESLVal $511 = _v67.termRef(0);
                  ESLVal $510 = _v67.termRef(1);
                  ESLVal $509 = _v67.termRef(2);
                  
                  {ESLVal l1 = $508;
                  
                  {ESLVal ns1 = $507;
                  
                  {ESLVal _v223 = $506;
                  
                  {ESLVal l2 = $511;
                  
                  {ESLVal ns2 = $510;
                  
                  {ESLVal _v224 = $509;
                  
                  return ns1.eql(ns2).and(typeEqual.apply(_v223,_v224));
                }
                }
                }
                }
                }
                }
                }
                default: {ESLVal l1 = $508;
                  
                  {ESLVal ns1 = $507;
                  
                  {ESLVal _v225 = $506;
                  
                  {ESLVal _v226 = _v67;
                  
                  return typeEqual.apply(_v225,_v226);
                }
                }
                }
                }
              }
            }
            default: switch(_v67.termName) {
              case "ApplyTypeFun": {ESLVal $505 = _v67.termRef(0);
                ESLVal $504 = _v67.termRef(1);
                ESLVal $503 = _v67.termRef(2);
                
                {ESLVal _v589 = _v68;
                
                {ESLVal l = $505;
                
                {ESLVal op = $504;
                
                {ESLVal args = $503;
                
                return typeEqual.apply(_v589,applyTypeFun.apply(l,forceType.apply(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $502 = _v67.termRef(0);
                ESLVal $501 = _v67.termRef(1);
                ESLVal $500 = _v67.termRef(2);
                ESLVal $499 = _v67.termRef(3);
                
                {ESLVal _v587 = _v68;
                
                {ESLVal l2 = $502;
                
                {ESLVal _v588 = $501;
                
                {ESLVal ds2 = $500;
                
                {ESLVal ms2 = $499;
                
                return typeEqual.apply(_v587,flattenAct.apply(l2,_v588,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $498 = _v67.termRef(0);
                
                {ESLVal t = _v68;
                
                {ESLVal l1 = $498;
                
                return $true;
              }
              }
              }
            case "TermType": {ESLVal $497 = _v67.termRef(0);
                ESLVal $496 = _v67.termRef(1);
                ESLVal $495 = _v67.termRef(2);
                
                {ESLVal _v586 = _v68;
                
                {ESLVal l2 = $497;
                
                {ESLVal n2 = $496;
                
                {ESLVal args2 = $495;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $494 = _v67.termRef(0);
                
                {ESLVal _v585 = _v68;
                
                {ESLVal f = $494;
                
                return typeEqual.apply(_v585,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $493 = _v67.termRef(0);
                ESLVal $492 = _v67.termRef(1);
                ESLVal $491 = _v67.termRef(2);
                
                {ESLVal _v583 = _v68;
                
                {ESLVal l2 = $493;
                
                {ESLVal n2 = $492;
                
                {ESLVal _v584 = $491;
                
                return typeEqual.apply(_v583,substType.apply(new ESLVal("RecType",l2,n2,_v584),n2,_v584));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $490 = _v67.termRef(0);
                ESLVal $489 = _v67.termRef(1);
                ESLVal $488 = _v67.termRef(2);
                
                {ESLVal _v581 = _v68;
                
                {ESLVal l1 = $490;
                
                {ESLVal ns2 = $489;
                
                {ESLVal _v582 = $488;
                
                return typeEqual.apply(_v581,_v582);
              }
              }
              }
              }
              }
              default: {ESLVal _v590 = _v68;
                
                {ESLVal _v591 = _v67;
                
                return $false;
              }
              }
            }
          }
          }
    }
  });
  public static ESLVal subType = new ESLVal(new Function(new ESLVal("subType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal sub = $args[0];
  ESLVal parent = $args[1];
  if(sub.eql(parent).boolVal)
        return $true;
        else
          {ESLVal _v66 = sub;
            ESLVal _v65 = parent;
            
            switch(_v66.termName) {
            case "ActType": {ESLVal $484 = _v66.termRef(0);
              ESLVal $483 = _v66.termRef(1);
              ESLVal $482 = _v66.termRef(2);
              
              switch(_v65.termName) {
              case "ActType": {ESLVal $487 = _v65.termRef(0);
                ESLVal $486 = _v65.termRef(1);
                ESLVal $485 = _v65.termRef(2);
                
                {ESLVal l1 = $484;
                
                {ESLVal exports1 = $483;
                
                {ESLVal handlers1 = $482;
                
                {ESLVal l2 = $487;
                
                {ESLVal exports2 = $486;
                
                {ESLVal handlers2 = $485;
                
                return actSubType.apply(exports1,exports2,handlers1,handlers2);
              }
              }
              }
              }
              }
              }
              }
              default: switch(_v65.termName) {
                case "ExtendedAct": {ESLVal $390 = _v65.termRef(0);
                  ESLVal $389 = _v65.termRef(1);
                  ESLVal $388 = _v65.termRef(2);
                  ESLVal $387 = _v65.termRef(3);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal l2 = $390;
                  
                  {ESLVal t2 = $389;
                  
                  {ESLVal ds2 = $388;
                  
                  {ESLVal ms2 = $387;
                  
                  return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $386 = _v65.termRef(0);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal f = $386;
                  
                  return subType.apply(t1,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $385 = _v65.termRef(0);
                  ESLVal $384 = _v65.termRef(1);
                  ESLVal $383 = _v65.termRef(2);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal l2 = $385;
                  
                  {ESLVal n2 = $384;
                  
                  {ESLVal t2 = $383;
                  
                  return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $382 = _v65.termRef(0);
                  ESLVal $381 = _v65.termRef(1);
                  ESLVal $380 = _v65.termRef(2);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal l1 = $382;
                  
                  {ESLVal ns2 = $381;
                  
                  {ESLVal t2 = $380;
                  
                  return subType.apply(t1,t2);
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v66;
                  
                  {ESLVal t2 = _v65;
                  
                  return typeEqual.apply(t1,t2);
                }
                }
              }
            }
            }
          case "ExtendedAct": {ESLVal $481 = _v66.termRef(0);
              ESLVal $480 = _v66.termRef(1);
              ESLVal $479 = _v66.termRef(2);
              ESLVal $478 = _v66.termRef(3);
              
              {ESLVal l1 = $481;
              
              {ESLVal t1 = $480;
              
              {ESLVal ds1 = $479;
              
              {ESLVal ms1 = $478;
              
              {ESLVal t2 = _v65;
              
              return subType.apply(flattenAct.apply(l1,t1,ds1,ms1),t2);
            }
            }
            }
            }
            }
            }
          case "ListType": {ESLVal $464 = _v66.termRef(0);
              ESLVal $463 = _v66.termRef(1);
              
              switch(_v65.termName) {
              case "ListType": {ESLVal $477 = _v65.termRef(0);
                ESLVal $476 = _v65.termRef(1);
                
                {ESLVal l1 = $464;
                
                {ESLVal t1 = $463;
                
                {ESLVal l2 = $477;
                
                {ESLVal t2 = $476;
                
                return subType.apply(t1,t2);
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $467 = _v65.termRef(0);
                ESLVal $466 = _v65.termRef(1);
                ESLVal $465 = _v65.termRef(2);
                
                if($466.isCons())
                {ESLVal $468 = $466.head();
                  ESLVal $469 = $466.tail();
                  
                  if($469.isCons())
                  {ESLVal $470 = $469.head();
                    ESLVal $471 = $469.tail();
                    
                    switch(_v65.termName) {
                    case "ExtendedAct": {ESLVal $390 = _v65.termRef(0);
                      ESLVal $389 = _v65.termRef(1);
                      ESLVal $388 = _v65.termRef(2);
                      ESLVal $387 = _v65.termRef(3);
                      
                      {ESLVal t1 = _v66;
                      
                      {ESLVal l2 = $390;
                      
                      {ESLVal t2 = $389;
                      
                      {ESLVal ds2 = $388;
                      
                      {ESLVal ms2 = $387;
                      
                      return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                    }
                    }
                    }
                    }
                    }
                    }
                  case "TypeClosure": {ESLVal $386 = _v65.termRef(0);
                      
                      {ESLVal t1 = _v66;
                      
                      {ESLVal f = $386;
                      
                      return subType.apply(t1,f.apply());
                    }
                    }
                    }
                  case "RecType": {ESLVal $385 = _v65.termRef(0);
                      ESLVal $384 = _v65.termRef(1);
                      ESLVal $383 = _v65.termRef(2);
                      
                      {ESLVal t1 = _v66;
                      
                      {ESLVal l2 = $385;
                      
                      {ESLVal n2 = $384;
                      
                      {ESLVal t2 = $383;
                      
                      return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                    }
                    }
                    }
                    }
                    }
                  case "ForallType": {ESLVal $382 = _v65.termRef(0);
                      ESLVal $381 = _v65.termRef(1);
                      ESLVal $380 = _v65.termRef(2);
                      
                      {ESLVal t1 = _v66;
                      
                      {ESLVal l1 = $382;
                      
                      {ESLVal ns2 = $381;
                      
                      {ESLVal t2 = $380;
                      
                      return subType.apply(t1,t2);
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal t1 = _v66;
                      
                      {ESLVal t2 = _v65;
                      
                      return typeEqual.apply(t1,t2);
                    }
                    }
                  }
                  }
                else if($469.isNil())
                  switch($465.termName) {
                    case "ListType": {ESLVal $473 = $465.termRef(0);
                      ESLVal $472 = $465.termRef(1);
                      
                      switch($472.termName) {
                      case "VarType": {ESLVal $475 = $472.termRef(0);
                        ESLVal $474 = $472.termRef(1);
                        
                        {ESLVal l1 = $464;
                        
                        {ESLVal t1 = $463;
                        
                        {ESLVal l2 = $467;
                        
                        {ESLVal v1 = $468;
                        
                        {ESLVal l3 = $473;
                        
                        {ESLVal l4 = $475;
                        
                        {ESLVal v2 = $474;
                        
                        if(v1.eql(v2).boolVal)
                        return $true;
                        else
                          switch(_v65.termName) {
                            case "ExtendedAct": {ESLVal $390 = _v65.termRef(0);
                              ESLVal $389 = _v65.termRef(1);
                              ESLVal $388 = _v65.termRef(2);
                              ESLVal $387 = _v65.termRef(3);
                              
                              {ESLVal _v172 = _v66;
                              
                              {ESLVal _v173 = $390;
                              
                              {ESLVal t2 = $389;
                              
                              {ESLVal ds2 = $388;
                              
                              {ESLVal ms2 = $387;
                              
                              return subType.apply(_v172,flattenAct.apply(_v173,t2,ds2,ms2));
                            }
                            }
                            }
                            }
                            }
                            }
                          case "TypeClosure": {ESLVal $386 = _v65.termRef(0);
                              
                              {ESLVal _v171 = _v66;
                              
                              {ESLVal f = $386;
                              
                              return subType.apply(_v171,f.apply());
                            }
                            }
                            }
                          case "RecType": {ESLVal $385 = _v65.termRef(0);
                              ESLVal $384 = _v65.termRef(1);
                              ESLVal $383 = _v65.termRef(2);
                              
                              {ESLVal _v169 = _v66;
                              
                              {ESLVal _v170 = $385;
                              
                              {ESLVal n2 = $384;
                              
                              {ESLVal t2 = $383;
                              
                              return subType.apply(_v169,substType.apply(new ESLVal("RecType",_v170,n2,t2),n2,t2));
                            }
                            }
                            }
                            }
                            }
                          case "ForallType": {ESLVal $382 = _v65.termRef(0);
                              ESLVal $381 = _v65.termRef(1);
                              ESLVal $380 = _v65.termRef(2);
                              
                              {ESLVal _v167 = _v66;
                              
                              {ESLVal _v168 = $382;
                              
                              {ESLVal ns2 = $381;
                              
                              {ESLVal t2 = $380;
                              
                              return subType.apply(_v167,t2);
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v174 = _v66;
                              
                              {ESLVal t2 = _v65;
                              
                              return typeEqual.apply(_v174,t2);
                            }
                            }
                          }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      default: switch(_v65.termName) {
                        case "ExtendedAct": {ESLVal $390 = _v65.termRef(0);
                          ESLVal $389 = _v65.termRef(1);
                          ESLVal $388 = _v65.termRef(2);
                          ESLVal $387 = _v65.termRef(3);
                          
                          {ESLVal t1 = _v66;
                          
                          {ESLVal l2 = $390;
                          
                          {ESLVal t2 = $389;
                          
                          {ESLVal ds2 = $388;
                          
                          {ESLVal ms2 = $387;
                          
                          return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                        }
                        }
                        }
                        }
                        }
                        }
                      case "TypeClosure": {ESLVal $386 = _v65.termRef(0);
                          
                          {ESLVal t1 = _v66;
                          
                          {ESLVal f = $386;
                          
                          return subType.apply(t1,f.apply());
                        }
                        }
                        }
                      case "RecType": {ESLVal $385 = _v65.termRef(0);
                          ESLVal $384 = _v65.termRef(1);
                          ESLVal $383 = _v65.termRef(2);
                          
                          {ESLVal t1 = _v66;
                          
                          {ESLVal l2 = $385;
                          
                          {ESLVal n2 = $384;
                          
                          {ESLVal t2 = $383;
                          
                          return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                        }
                        }
                        }
                        }
                        }
                      case "ForallType": {ESLVal $382 = _v65.termRef(0);
                          ESLVal $381 = _v65.termRef(1);
                          ESLVal $380 = _v65.termRef(2);
                          
                          {ESLVal t1 = _v66;
                          
                          {ESLVal l1 = $382;
                          
                          {ESLVal ns2 = $381;
                          
                          {ESLVal t2 = $380;
                          
                          return subType.apply(t1,t2);
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal t1 = _v66;
                          
                          {ESLVal t2 = _v65;
                          
                          return typeEqual.apply(t1,t2);
                        }
                        }
                      }
                    }
                    }
                    default: switch(_v65.termName) {
                      case "ExtendedAct": {ESLVal $390 = _v65.termRef(0);
                        ESLVal $389 = _v65.termRef(1);
                        ESLVal $388 = _v65.termRef(2);
                        ESLVal $387 = _v65.termRef(3);
                        
                        {ESLVal t1 = _v66;
                        
                        {ESLVal l2 = $390;
                        
                        {ESLVal t2 = $389;
                        
                        {ESLVal ds2 = $388;
                        
                        {ESLVal ms2 = $387;
                        
                        return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                      }
                      }
                      }
                      }
                      }
                      }
                    case "TypeClosure": {ESLVal $386 = _v65.termRef(0);
                        
                        {ESLVal t1 = _v66;
                        
                        {ESLVal f = $386;
                        
                        return subType.apply(t1,f.apply());
                      }
                      }
                      }
                    case "RecType": {ESLVal $385 = _v65.termRef(0);
                        ESLVal $384 = _v65.termRef(1);
                        ESLVal $383 = _v65.termRef(2);
                        
                        {ESLVal t1 = _v66;
                        
                        {ESLVal l2 = $385;
                        
                        {ESLVal n2 = $384;
                        
                        {ESLVal t2 = $383;
                        
                        return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                      }
                      }
                      }
                      }
                      }
                    case "ForallType": {ESLVal $382 = _v65.termRef(0);
                        ESLVal $381 = _v65.termRef(1);
                        ESLVal $380 = _v65.termRef(2);
                        
                        {ESLVal t1 = _v66;
                        
                        {ESLVal l1 = $382;
                        
                        {ESLVal ns2 = $381;
                        
                        {ESLVal t2 = $380;
                        
                        return subType.apply(t1,t2);
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal t1 = _v66;
                        
                        {ESLVal t2 = _v65;
                        
                        return typeEqual.apply(t1,t2);
                      }
                      }
                    }
                  }
                else switch(_v65.termName) {
                    case "ExtendedAct": {ESLVal $390 = _v65.termRef(0);
                      ESLVal $389 = _v65.termRef(1);
                      ESLVal $388 = _v65.termRef(2);
                      ESLVal $387 = _v65.termRef(3);
                      
                      {ESLVal t1 = _v66;
                      
                      {ESLVal l2 = $390;
                      
                      {ESLVal t2 = $389;
                      
                      {ESLVal ds2 = $388;
                      
                      {ESLVal ms2 = $387;
                      
                      return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                    }
                    }
                    }
                    }
                    }
                    }
                  case "TypeClosure": {ESLVal $386 = _v65.termRef(0);
                      
                      {ESLVal t1 = _v66;
                      
                      {ESLVal f = $386;
                      
                      return subType.apply(t1,f.apply());
                    }
                    }
                    }
                  case "RecType": {ESLVal $385 = _v65.termRef(0);
                      ESLVal $384 = _v65.termRef(1);
                      ESLVal $383 = _v65.termRef(2);
                      
                      {ESLVal t1 = _v66;
                      
                      {ESLVal l2 = $385;
                      
                      {ESLVal n2 = $384;
                      
                      {ESLVal t2 = $383;
                      
                      return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                    }
                    }
                    }
                    }
                    }
                  case "ForallType": {ESLVal $382 = _v65.termRef(0);
                      ESLVal $381 = _v65.termRef(1);
                      ESLVal $380 = _v65.termRef(2);
                      
                      {ESLVal t1 = _v66;
                      
                      {ESLVal l1 = $382;
                      
                      {ESLVal ns2 = $381;
                      
                      {ESLVal t2 = $380;
                      
                      return subType.apply(t1,t2);
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal t1 = _v66;
                      
                      {ESLVal t2 = _v65;
                      
                      return typeEqual.apply(t1,t2);
                    }
                    }
                  }
                }
              else if($466.isNil())
                switch(_v65.termName) {
                  case "ExtendedAct": {ESLVal $390 = _v65.termRef(0);
                    ESLVal $389 = _v65.termRef(1);
                    ESLVal $388 = _v65.termRef(2);
                    ESLVal $387 = _v65.termRef(3);
                    
                    {ESLVal t1 = _v66;
                    
                    {ESLVal l2 = $390;
                    
                    {ESLVal t2 = $389;
                    
                    {ESLVal ds2 = $388;
                    
                    {ESLVal ms2 = $387;
                    
                    return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                  }
                  }
                  }
                  }
                  }
                  }
                case "TypeClosure": {ESLVal $386 = _v65.termRef(0);
                    
                    {ESLVal t1 = _v66;
                    
                    {ESLVal f = $386;
                    
                    return subType.apply(t1,f.apply());
                  }
                  }
                  }
                case "RecType": {ESLVal $385 = _v65.termRef(0);
                    ESLVal $384 = _v65.termRef(1);
                    ESLVal $383 = _v65.termRef(2);
                    
                    {ESLVal t1 = _v66;
                    
                    {ESLVal l2 = $385;
                    
                    {ESLVal n2 = $384;
                    
                    {ESLVal t2 = $383;
                    
                    return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                  }
                  }
                  }
                  }
                  }
                case "ForallType": {ESLVal $382 = _v65.termRef(0);
                    ESLVal $381 = _v65.termRef(1);
                    ESLVal $380 = _v65.termRef(2);
                    
                    {ESLVal t1 = _v66;
                    
                    {ESLVal l1 = $382;
                    
                    {ESLVal ns2 = $381;
                    
                    {ESLVal t2 = $380;
                    
                    return subType.apply(t1,t2);
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal t1 = _v66;
                    
                    {ESLVal t2 = _v65;
                    
                    return typeEqual.apply(t1,t2);
                  }
                  }
                }
              else switch(_v65.termName) {
                  case "ExtendedAct": {ESLVal $390 = _v65.termRef(0);
                    ESLVal $389 = _v65.termRef(1);
                    ESLVal $388 = _v65.termRef(2);
                    ESLVal $387 = _v65.termRef(3);
                    
                    {ESLVal t1 = _v66;
                    
                    {ESLVal l2 = $390;
                    
                    {ESLVal t2 = $389;
                    
                    {ESLVal ds2 = $388;
                    
                    {ESLVal ms2 = $387;
                    
                    return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                  }
                  }
                  }
                  }
                  }
                  }
                case "TypeClosure": {ESLVal $386 = _v65.termRef(0);
                    
                    {ESLVal t1 = _v66;
                    
                    {ESLVal f = $386;
                    
                    return subType.apply(t1,f.apply());
                  }
                  }
                  }
                case "RecType": {ESLVal $385 = _v65.termRef(0);
                    ESLVal $384 = _v65.termRef(1);
                    ESLVal $383 = _v65.termRef(2);
                    
                    {ESLVal t1 = _v66;
                    
                    {ESLVal l2 = $385;
                    
                    {ESLVal n2 = $384;
                    
                    {ESLVal t2 = $383;
                    
                    return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                  }
                  }
                  }
                  }
                  }
                case "ForallType": {ESLVal $382 = _v65.termRef(0);
                    ESLVal $381 = _v65.termRef(1);
                    ESLVal $380 = _v65.termRef(2);
                    
                    {ESLVal t1 = _v66;
                    
                    {ESLVal l1 = $382;
                    
                    {ESLVal ns2 = $381;
                    
                    {ESLVal t2 = $380;
                    
                    return subType.apply(t1,t2);
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal t1 = _v66;
                    
                    {ESLVal t2 = _v65;
                    
                    return typeEqual.apply(t1,t2);
                  }
                  }
                }
              }
              default: switch(_v65.termName) {
                case "ExtendedAct": {ESLVal $390 = _v65.termRef(0);
                  ESLVal $389 = _v65.termRef(1);
                  ESLVal $388 = _v65.termRef(2);
                  ESLVal $387 = _v65.termRef(3);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal l2 = $390;
                  
                  {ESLVal t2 = $389;
                  
                  {ESLVal ds2 = $388;
                  
                  {ESLVal ms2 = $387;
                  
                  return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $386 = _v65.termRef(0);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal f = $386;
                  
                  return subType.apply(t1,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $385 = _v65.termRef(0);
                  ESLVal $384 = _v65.termRef(1);
                  ESLVal $383 = _v65.termRef(2);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal l2 = $385;
                  
                  {ESLVal n2 = $384;
                  
                  {ESLVal t2 = $383;
                  
                  return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $382 = _v65.termRef(0);
                  ESLVal $381 = _v65.termRef(1);
                  ESLVal $380 = _v65.termRef(2);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal l1 = $382;
                  
                  {ESLVal ns2 = $381;
                  
                  {ESLVal t2 = $380;
                  
                  return subType.apply(t1,t2);
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v66;
                  
                  {ESLVal t2 = _v65;
                  
                  return typeEqual.apply(t1,t2);
                }
                }
              }
            }
            }
          case "BagType": {ESLVal $460 = _v66.termRef(0);
              ESLVal $459 = _v66.termRef(1);
              
              switch(_v65.termName) {
              case "BagType": {ESLVal $462 = _v65.termRef(0);
                ESLVal $461 = _v65.termRef(1);
                
                {ESLVal l1 = $460;
                
                {ESLVal t1 = $459;
                
                {ESLVal l2 = $462;
                
                {ESLVal t2 = $461;
                
                return subType.apply(t1,t2);
              }
              }
              }
              }
              }
              default: switch(_v65.termName) {
                case "ExtendedAct": {ESLVal $390 = _v65.termRef(0);
                  ESLVal $389 = _v65.termRef(1);
                  ESLVal $388 = _v65.termRef(2);
                  ESLVal $387 = _v65.termRef(3);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal l2 = $390;
                  
                  {ESLVal t2 = $389;
                  
                  {ESLVal ds2 = $388;
                  
                  {ESLVal ms2 = $387;
                  
                  return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $386 = _v65.termRef(0);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal f = $386;
                  
                  return subType.apply(t1,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $385 = _v65.termRef(0);
                  ESLVal $384 = _v65.termRef(1);
                  ESLVal $383 = _v65.termRef(2);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal l2 = $385;
                  
                  {ESLVal n2 = $384;
                  
                  {ESLVal t2 = $383;
                  
                  return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $382 = _v65.termRef(0);
                  ESLVal $381 = _v65.termRef(1);
                  ESLVal $380 = _v65.termRef(2);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal l1 = $382;
                  
                  {ESLVal ns2 = $381;
                  
                  {ESLVal t2 = $380;
                  
                  return subType.apply(t1,t2);
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v66;
                  
                  {ESLVal t2 = _v65;
                  
                  return typeEqual.apply(t1,t2);
                }
                }
              }
            }
            }
          case "SetType": {ESLVal $445 = _v66.termRef(0);
              ESLVal $444 = _v66.termRef(1);
              
              switch(_v65.termName) {
              case "SetType": {ESLVal $458 = _v65.termRef(0);
                ESLVal $457 = _v65.termRef(1);
                
                {ESLVal l1 = $445;
                
                {ESLVal t1 = $444;
                
                {ESLVal l2 = $458;
                
                {ESLVal t2 = $457;
                
                return subType.apply(t1,t2);
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $448 = _v65.termRef(0);
                ESLVal $447 = _v65.termRef(1);
                ESLVal $446 = _v65.termRef(2);
                
                if($447.isCons())
                {ESLVal $449 = $447.head();
                  ESLVal $450 = $447.tail();
                  
                  if($450.isCons())
                  {ESLVal $451 = $450.head();
                    ESLVal $452 = $450.tail();
                    
                    switch(_v65.termName) {
                    case "ExtendedAct": {ESLVal $390 = _v65.termRef(0);
                      ESLVal $389 = _v65.termRef(1);
                      ESLVal $388 = _v65.termRef(2);
                      ESLVal $387 = _v65.termRef(3);
                      
                      {ESLVal t1 = _v66;
                      
                      {ESLVal l2 = $390;
                      
                      {ESLVal t2 = $389;
                      
                      {ESLVal ds2 = $388;
                      
                      {ESLVal ms2 = $387;
                      
                      return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                    }
                    }
                    }
                    }
                    }
                    }
                  case "TypeClosure": {ESLVal $386 = _v65.termRef(0);
                      
                      {ESLVal t1 = _v66;
                      
                      {ESLVal f = $386;
                      
                      return subType.apply(t1,f.apply());
                    }
                    }
                    }
                  case "RecType": {ESLVal $385 = _v65.termRef(0);
                      ESLVal $384 = _v65.termRef(1);
                      ESLVal $383 = _v65.termRef(2);
                      
                      {ESLVal t1 = _v66;
                      
                      {ESLVal l2 = $385;
                      
                      {ESLVal n2 = $384;
                      
                      {ESLVal t2 = $383;
                      
                      return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                    }
                    }
                    }
                    }
                    }
                  case "ForallType": {ESLVal $382 = _v65.termRef(0);
                      ESLVal $381 = _v65.termRef(1);
                      ESLVal $380 = _v65.termRef(2);
                      
                      {ESLVal t1 = _v66;
                      
                      {ESLVal l1 = $382;
                      
                      {ESLVal ns2 = $381;
                      
                      {ESLVal t2 = $380;
                      
                      return subType.apply(t1,t2);
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal t1 = _v66;
                      
                      {ESLVal t2 = _v65;
                      
                      return typeEqual.apply(t1,t2);
                    }
                    }
                  }
                  }
                else if($450.isNil())
                  switch($446.termName) {
                    case "SetType": {ESLVal $454 = $446.termRef(0);
                      ESLVal $453 = $446.termRef(1);
                      
                      switch($453.termName) {
                      case "VarType": {ESLVal $456 = $453.termRef(0);
                        ESLVal $455 = $453.termRef(1);
                        
                        {ESLVal l1 = $445;
                        
                        {ESLVal t1 = $444;
                        
                        {ESLVal l2 = $448;
                        
                        {ESLVal v1 = $449;
                        
                        {ESLVal l3 = $454;
                        
                        {ESLVal l4 = $456;
                        
                        {ESLVal v2 = $455;
                        
                        if(v1.eql(v2).boolVal)
                        return $true;
                        else
                          switch(_v65.termName) {
                            case "ExtendedAct": {ESLVal $390 = _v65.termRef(0);
                              ESLVal $389 = _v65.termRef(1);
                              ESLVal $388 = _v65.termRef(2);
                              ESLVal $387 = _v65.termRef(3);
                              
                              {ESLVal _v164 = _v66;
                              
                              {ESLVal _v165 = $390;
                              
                              {ESLVal t2 = $389;
                              
                              {ESLVal ds2 = $388;
                              
                              {ESLVal ms2 = $387;
                              
                              return subType.apply(_v164,flattenAct.apply(_v165,t2,ds2,ms2));
                            }
                            }
                            }
                            }
                            }
                            }
                          case "TypeClosure": {ESLVal $386 = _v65.termRef(0);
                              
                              {ESLVal _v163 = _v66;
                              
                              {ESLVal f = $386;
                              
                              return subType.apply(_v163,f.apply());
                            }
                            }
                            }
                          case "RecType": {ESLVal $385 = _v65.termRef(0);
                              ESLVal $384 = _v65.termRef(1);
                              ESLVal $383 = _v65.termRef(2);
                              
                              {ESLVal _v161 = _v66;
                              
                              {ESLVal _v162 = $385;
                              
                              {ESLVal n2 = $384;
                              
                              {ESLVal t2 = $383;
                              
                              return subType.apply(_v161,substType.apply(new ESLVal("RecType",_v162,n2,t2),n2,t2));
                            }
                            }
                            }
                            }
                            }
                          case "ForallType": {ESLVal $382 = _v65.termRef(0);
                              ESLVal $381 = _v65.termRef(1);
                              ESLVal $380 = _v65.termRef(2);
                              
                              {ESLVal _v159 = _v66;
                              
                              {ESLVal _v160 = $382;
                              
                              {ESLVal ns2 = $381;
                              
                              {ESLVal t2 = $380;
                              
                              return subType.apply(_v159,t2);
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v166 = _v66;
                              
                              {ESLVal t2 = _v65;
                              
                              return typeEqual.apply(_v166,t2);
                            }
                            }
                          }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      default: switch(_v65.termName) {
                        case "ExtendedAct": {ESLVal $390 = _v65.termRef(0);
                          ESLVal $389 = _v65.termRef(1);
                          ESLVal $388 = _v65.termRef(2);
                          ESLVal $387 = _v65.termRef(3);
                          
                          {ESLVal t1 = _v66;
                          
                          {ESLVal l2 = $390;
                          
                          {ESLVal t2 = $389;
                          
                          {ESLVal ds2 = $388;
                          
                          {ESLVal ms2 = $387;
                          
                          return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                        }
                        }
                        }
                        }
                        }
                        }
                      case "TypeClosure": {ESLVal $386 = _v65.termRef(0);
                          
                          {ESLVal t1 = _v66;
                          
                          {ESLVal f = $386;
                          
                          return subType.apply(t1,f.apply());
                        }
                        }
                        }
                      case "RecType": {ESLVal $385 = _v65.termRef(0);
                          ESLVal $384 = _v65.termRef(1);
                          ESLVal $383 = _v65.termRef(2);
                          
                          {ESLVal t1 = _v66;
                          
                          {ESLVal l2 = $385;
                          
                          {ESLVal n2 = $384;
                          
                          {ESLVal t2 = $383;
                          
                          return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                        }
                        }
                        }
                        }
                        }
                      case "ForallType": {ESLVal $382 = _v65.termRef(0);
                          ESLVal $381 = _v65.termRef(1);
                          ESLVal $380 = _v65.termRef(2);
                          
                          {ESLVal t1 = _v66;
                          
                          {ESLVal l1 = $382;
                          
                          {ESLVal ns2 = $381;
                          
                          {ESLVal t2 = $380;
                          
                          return subType.apply(t1,t2);
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal t1 = _v66;
                          
                          {ESLVal t2 = _v65;
                          
                          return typeEqual.apply(t1,t2);
                        }
                        }
                      }
                    }
                    }
                    default: switch(_v65.termName) {
                      case "ExtendedAct": {ESLVal $390 = _v65.termRef(0);
                        ESLVal $389 = _v65.termRef(1);
                        ESLVal $388 = _v65.termRef(2);
                        ESLVal $387 = _v65.termRef(3);
                        
                        {ESLVal t1 = _v66;
                        
                        {ESLVal l2 = $390;
                        
                        {ESLVal t2 = $389;
                        
                        {ESLVal ds2 = $388;
                        
                        {ESLVal ms2 = $387;
                        
                        return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                      }
                      }
                      }
                      }
                      }
                      }
                    case "TypeClosure": {ESLVal $386 = _v65.termRef(0);
                        
                        {ESLVal t1 = _v66;
                        
                        {ESLVal f = $386;
                        
                        return subType.apply(t1,f.apply());
                      }
                      }
                      }
                    case "RecType": {ESLVal $385 = _v65.termRef(0);
                        ESLVal $384 = _v65.termRef(1);
                        ESLVal $383 = _v65.termRef(2);
                        
                        {ESLVal t1 = _v66;
                        
                        {ESLVal l2 = $385;
                        
                        {ESLVal n2 = $384;
                        
                        {ESLVal t2 = $383;
                        
                        return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                      }
                      }
                      }
                      }
                      }
                    case "ForallType": {ESLVal $382 = _v65.termRef(0);
                        ESLVal $381 = _v65.termRef(1);
                        ESLVal $380 = _v65.termRef(2);
                        
                        {ESLVal t1 = _v66;
                        
                        {ESLVal l1 = $382;
                        
                        {ESLVal ns2 = $381;
                        
                        {ESLVal t2 = $380;
                        
                        return subType.apply(t1,t2);
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal t1 = _v66;
                        
                        {ESLVal t2 = _v65;
                        
                        return typeEqual.apply(t1,t2);
                      }
                      }
                    }
                  }
                else switch(_v65.termName) {
                    case "ExtendedAct": {ESLVal $390 = _v65.termRef(0);
                      ESLVal $389 = _v65.termRef(1);
                      ESLVal $388 = _v65.termRef(2);
                      ESLVal $387 = _v65.termRef(3);
                      
                      {ESLVal t1 = _v66;
                      
                      {ESLVal l2 = $390;
                      
                      {ESLVal t2 = $389;
                      
                      {ESLVal ds2 = $388;
                      
                      {ESLVal ms2 = $387;
                      
                      return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                    }
                    }
                    }
                    }
                    }
                    }
                  case "TypeClosure": {ESLVal $386 = _v65.termRef(0);
                      
                      {ESLVal t1 = _v66;
                      
                      {ESLVal f = $386;
                      
                      return subType.apply(t1,f.apply());
                    }
                    }
                    }
                  case "RecType": {ESLVal $385 = _v65.termRef(0);
                      ESLVal $384 = _v65.termRef(1);
                      ESLVal $383 = _v65.termRef(2);
                      
                      {ESLVal t1 = _v66;
                      
                      {ESLVal l2 = $385;
                      
                      {ESLVal n2 = $384;
                      
                      {ESLVal t2 = $383;
                      
                      return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                    }
                    }
                    }
                    }
                    }
                  case "ForallType": {ESLVal $382 = _v65.termRef(0);
                      ESLVal $381 = _v65.termRef(1);
                      ESLVal $380 = _v65.termRef(2);
                      
                      {ESLVal t1 = _v66;
                      
                      {ESLVal l1 = $382;
                      
                      {ESLVal ns2 = $381;
                      
                      {ESLVal t2 = $380;
                      
                      return subType.apply(t1,t2);
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal t1 = _v66;
                      
                      {ESLVal t2 = _v65;
                      
                      return typeEqual.apply(t1,t2);
                    }
                    }
                  }
                }
              else if($447.isNil())
                switch(_v65.termName) {
                  case "ExtendedAct": {ESLVal $390 = _v65.termRef(0);
                    ESLVal $389 = _v65.termRef(1);
                    ESLVal $388 = _v65.termRef(2);
                    ESLVal $387 = _v65.termRef(3);
                    
                    {ESLVal t1 = _v66;
                    
                    {ESLVal l2 = $390;
                    
                    {ESLVal t2 = $389;
                    
                    {ESLVal ds2 = $388;
                    
                    {ESLVal ms2 = $387;
                    
                    return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                  }
                  }
                  }
                  }
                  }
                  }
                case "TypeClosure": {ESLVal $386 = _v65.termRef(0);
                    
                    {ESLVal t1 = _v66;
                    
                    {ESLVal f = $386;
                    
                    return subType.apply(t1,f.apply());
                  }
                  }
                  }
                case "RecType": {ESLVal $385 = _v65.termRef(0);
                    ESLVal $384 = _v65.termRef(1);
                    ESLVal $383 = _v65.termRef(2);
                    
                    {ESLVal t1 = _v66;
                    
                    {ESLVal l2 = $385;
                    
                    {ESLVal n2 = $384;
                    
                    {ESLVal t2 = $383;
                    
                    return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                  }
                  }
                  }
                  }
                  }
                case "ForallType": {ESLVal $382 = _v65.termRef(0);
                    ESLVal $381 = _v65.termRef(1);
                    ESLVal $380 = _v65.termRef(2);
                    
                    {ESLVal t1 = _v66;
                    
                    {ESLVal l1 = $382;
                    
                    {ESLVal ns2 = $381;
                    
                    {ESLVal t2 = $380;
                    
                    return subType.apply(t1,t2);
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal t1 = _v66;
                    
                    {ESLVal t2 = _v65;
                    
                    return typeEqual.apply(t1,t2);
                  }
                  }
                }
              else switch(_v65.termName) {
                  case "ExtendedAct": {ESLVal $390 = _v65.termRef(0);
                    ESLVal $389 = _v65.termRef(1);
                    ESLVal $388 = _v65.termRef(2);
                    ESLVal $387 = _v65.termRef(3);
                    
                    {ESLVal t1 = _v66;
                    
                    {ESLVal l2 = $390;
                    
                    {ESLVal t2 = $389;
                    
                    {ESLVal ds2 = $388;
                    
                    {ESLVal ms2 = $387;
                    
                    return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                  }
                  }
                  }
                  }
                  }
                  }
                case "TypeClosure": {ESLVal $386 = _v65.termRef(0);
                    
                    {ESLVal t1 = _v66;
                    
                    {ESLVal f = $386;
                    
                    return subType.apply(t1,f.apply());
                  }
                  }
                  }
                case "RecType": {ESLVal $385 = _v65.termRef(0);
                    ESLVal $384 = _v65.termRef(1);
                    ESLVal $383 = _v65.termRef(2);
                    
                    {ESLVal t1 = _v66;
                    
                    {ESLVal l2 = $385;
                    
                    {ESLVal n2 = $384;
                    
                    {ESLVal t2 = $383;
                    
                    return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                  }
                  }
                  }
                  }
                  }
                case "ForallType": {ESLVal $382 = _v65.termRef(0);
                    ESLVal $381 = _v65.termRef(1);
                    ESLVal $380 = _v65.termRef(2);
                    
                    {ESLVal t1 = _v66;
                    
                    {ESLVal l1 = $382;
                    
                    {ESLVal ns2 = $381;
                    
                    {ESLVal t2 = $380;
                    
                    return subType.apply(t1,t2);
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal t1 = _v66;
                    
                    {ESLVal t2 = _v65;
                    
                    return typeEqual.apply(t1,t2);
                  }
                  }
                }
              }
              default: switch(_v65.termName) {
                case "ExtendedAct": {ESLVal $390 = _v65.termRef(0);
                  ESLVal $389 = _v65.termRef(1);
                  ESLVal $388 = _v65.termRef(2);
                  ESLVal $387 = _v65.termRef(3);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal l2 = $390;
                  
                  {ESLVal t2 = $389;
                  
                  {ESLVal ds2 = $388;
                  
                  {ESLVal ms2 = $387;
                  
                  return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $386 = _v65.termRef(0);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal f = $386;
                  
                  return subType.apply(t1,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $385 = _v65.termRef(0);
                  ESLVal $384 = _v65.termRef(1);
                  ESLVal $383 = _v65.termRef(2);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal l2 = $385;
                  
                  {ESLVal n2 = $384;
                  
                  {ESLVal t2 = $383;
                  
                  return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $382 = _v65.termRef(0);
                  ESLVal $381 = _v65.termRef(1);
                  ESLVal $380 = _v65.termRef(2);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal l1 = $382;
                  
                  {ESLVal ns2 = $381;
                  
                  {ESLVal t2 = $380;
                  
                  return subType.apply(t1,t2);
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v66;
                  
                  {ESLVal t2 = _v65;
                  
                  return typeEqual.apply(t1,t2);
                }
                }
              }
            }
            }
          case "TermType": {ESLVal $440 = _v66.termRef(0);
              ESLVal $439 = _v66.termRef(1);
              ESLVal $438 = _v66.termRef(2);
              
              switch(_v65.termName) {
              case "TermType": {ESLVal $443 = _v65.termRef(0);
                ESLVal $442 = _v65.termRef(1);
                ESLVal $441 = _v65.termRef(2);
                
                {ESLVal l1 = $440;
                
                {ESLVal n1 = $439;
                
                {ESLVal args1 = $438;
                
                {ESLVal l2 = $443;
                
                {ESLVal n2 = $442;
                
                {ESLVal args2 = $441;
                
                if(n1.eql(n2).boolVal)
                return subTypes.apply(args1,args2);
                else
                  return $false;
              }
              }
              }
              }
              }
              }
              }
              default: switch(_v65.termName) {
                case "ExtendedAct": {ESLVal $390 = _v65.termRef(0);
                  ESLVal $389 = _v65.termRef(1);
                  ESLVal $388 = _v65.termRef(2);
                  ESLVal $387 = _v65.termRef(3);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal l2 = $390;
                  
                  {ESLVal t2 = $389;
                  
                  {ESLVal ds2 = $388;
                  
                  {ESLVal ms2 = $387;
                  
                  return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $386 = _v65.termRef(0);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal f = $386;
                  
                  return subType.apply(t1,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $385 = _v65.termRef(0);
                  ESLVal $384 = _v65.termRef(1);
                  ESLVal $383 = _v65.termRef(2);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal l2 = $385;
                  
                  {ESLVal n2 = $384;
                  
                  {ESLVal t2 = $383;
                  
                  return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $382 = _v65.termRef(0);
                  ESLVal $381 = _v65.termRef(1);
                  ESLVal $380 = _v65.termRef(2);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal l1 = $382;
                  
                  {ESLVal ns2 = $381;
                  
                  {ESLVal t2 = $380;
                  
                  return subType.apply(t1,t2);
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v66;
                  
                  {ESLVal t2 = _v65;
                  
                  return typeEqual.apply(t1,t2);
                }
                }
              }
            }
            }
          case "FunType": {ESLVal $434 = _v66.termRef(0);
              ESLVal $433 = _v66.termRef(1);
              ESLVal $432 = _v66.termRef(2);
              
              switch(_v65.termName) {
              case "FunType": {ESLVal $437 = _v65.termRef(0);
                ESLVal $436 = _v65.termRef(1);
                ESLVal $435 = _v65.termRef(2);
                
                {ESLVal l1 = $434;
                
                {ESLVal d1 = $433;
                
                {ESLVal r1 = $432;
                
                {ESLVal l2 = $437;
                
                {ESLVal d2 = $436;
                
                {ESLVal r2 = $435;
                
                return subType.apply(r1,r2).and(subTypes.apply(d2,d1));
              }
              }
              }
              }
              }
              }
              }
              default: switch(_v65.termName) {
                case "ExtendedAct": {ESLVal $390 = _v65.termRef(0);
                  ESLVal $389 = _v65.termRef(1);
                  ESLVal $388 = _v65.termRef(2);
                  ESLVal $387 = _v65.termRef(3);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal l2 = $390;
                  
                  {ESLVal t2 = $389;
                  
                  {ESLVal ds2 = $388;
                  
                  {ESLVal ms2 = $387;
                  
                  return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $386 = _v65.termRef(0);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal f = $386;
                  
                  return subType.apply(t1,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $385 = _v65.termRef(0);
                  ESLVal $384 = _v65.termRef(1);
                  ESLVal $383 = _v65.termRef(2);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal l2 = $385;
                  
                  {ESLVal n2 = $384;
                  
                  {ESLVal t2 = $383;
                  
                  return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $382 = _v65.termRef(0);
                  ESLVal $381 = _v65.termRef(1);
                  ESLVal $380 = _v65.termRef(2);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal l1 = $382;
                  
                  {ESLVal ns2 = $381;
                  
                  {ESLVal t2 = $380;
                  
                  return subType.apply(t1,t2);
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v66;
                  
                  {ESLVal t2 = _v65;
                  
                  return typeEqual.apply(t1,t2);
                }
                }
              }
            }
            }
          case "TypeClosure": {ESLVal $431 = _v66.termRef(0);
              
              {ESLVal f = $431;
              
              {ESLVal t2 = _v65;
              
              return subType.apply(f.apply(),t2);
            }
            }
            }
          case "RecordType": {ESLVal $428 = _v66.termRef(0);
              ESLVal $427 = _v66.termRef(1);
              
              switch(_v65.termName) {
              case "RecordType": {ESLVal $430 = _v65.termRef(0);
                ESLVal $429 = _v65.termRef(1);
                
                {ESLVal l1 = $428;
                
                {ESLVal fs1 = $427;
                
                {ESLVal l2 = $430;
                
                {ESLVal fs2 = $429;
                
                return recordSubType.apply(fs1,fs2);
              }
              }
              }
              }
              }
              default: switch(_v65.termName) {
                case "ExtendedAct": {ESLVal $390 = _v65.termRef(0);
                  ESLVal $389 = _v65.termRef(1);
                  ESLVal $388 = _v65.termRef(2);
                  ESLVal $387 = _v65.termRef(3);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal l2 = $390;
                  
                  {ESLVal t2 = $389;
                  
                  {ESLVal ds2 = $388;
                  
                  {ESLVal ms2 = $387;
                  
                  return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $386 = _v65.termRef(0);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal f = $386;
                  
                  return subType.apply(t1,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $385 = _v65.termRef(0);
                  ESLVal $384 = _v65.termRef(1);
                  ESLVal $383 = _v65.termRef(2);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal l2 = $385;
                  
                  {ESLVal n2 = $384;
                  
                  {ESLVal t2 = $383;
                  
                  return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $382 = _v65.termRef(0);
                  ESLVal $381 = _v65.termRef(1);
                  ESLVal $380 = _v65.termRef(2);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal l1 = $382;
                  
                  {ESLVal ns2 = $381;
                  
                  {ESLVal t2 = $380;
                  
                  return subType.apply(t1,t2);
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v66;
                  
                  {ESLVal t2 = _v65;
                  
                  return typeEqual.apply(t1,t2);
                }
                }
              }
            }
            }
          case "RecType": {ESLVal $423 = _v66.termRef(0);
              ESLVal $422 = _v66.termRef(1);
              ESLVal $421 = _v66.termRef(2);
              
              switch(_v65.termName) {
              case "RecType": {ESLVal $426 = _v65.termRef(0);
                ESLVal $425 = _v65.termRef(1);
                ESLVal $424 = _v65.termRef(2);
                
                {ESLVal l1 = $423;
                
                {ESLVal n1 = $422;
                
                {ESLVal t1 = $421;
                
                {ESLVal l2 = $426;
                
                {ESLVal n2 = $425;
                
                {ESLVal t2 = $424;
                
                if(n1.eql(n2).boolVal)
                return subType.apply(t1,t2);
                else
                  {ESLVal _v155 = $423;
                    
                    {ESLVal _v156 = $422;
                    
                    {ESLVal _v157 = $421;
                    
                    {ESLVal _v158 = _v65;
                    
                    return subType.apply(substType.apply(new ESLVal("RecType",_v155,_v156,_v157),_v156,_v157),_v158);
                  }
                  }
                  }
                  }
              }
              }
              }
              }
              }
              }
              }
              default: {ESLVal l1 = $423;
                
                {ESLVal n1 = $422;
                
                {ESLVal t1 = $421;
                
                {ESLVal t2 = _v65;
                
                return subType.apply(substType.apply(new ESLVal("RecType",l1,n1,t1),n1,t1),t2);
              }
              }
              }
              }
            }
            }
          case "UnionType": {ESLVal $418 = _v66.termRef(0);
              ESLVal $417 = _v66.termRef(1);
              
              switch(_v65.termName) {
              case "UnionType": {ESLVal $420 = _v65.termRef(0);
                ESLVal $419 = _v65.termRef(1);
                
                {ESLVal l1 = $418;
                
                {ESLVal terms1 = $417;
                
                {ESLVal l2 = $420;
                
                {ESLVal terms2 = $419;
                
                return subTypes.apply(terms1,terms2);
              }
              }
              }
              }
              }
              default: switch(_v65.termName) {
                case "ExtendedAct": {ESLVal $390 = _v65.termRef(0);
                  ESLVal $389 = _v65.termRef(1);
                  ESLVal $388 = _v65.termRef(2);
                  ESLVal $387 = _v65.termRef(3);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal l2 = $390;
                  
                  {ESLVal t2 = $389;
                  
                  {ESLVal ds2 = $388;
                  
                  {ESLVal ms2 = $387;
                  
                  return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $386 = _v65.termRef(0);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal f = $386;
                  
                  return subType.apply(t1,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $385 = _v65.termRef(0);
                  ESLVal $384 = _v65.termRef(1);
                  ESLVal $383 = _v65.termRef(2);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal l2 = $385;
                  
                  {ESLVal n2 = $384;
                  
                  {ESLVal t2 = $383;
                  
                  return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $382 = _v65.termRef(0);
                  ESLVal $381 = _v65.termRef(1);
                  ESLVal $380 = _v65.termRef(2);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal l1 = $382;
                  
                  {ESLVal ns2 = $381;
                  
                  {ESLVal t2 = $380;
                  
                  return subType.apply(t1,t2);
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v66;
                  
                  {ESLVal t2 = _v65;
                  
                  return typeEqual.apply(t1,t2);
                }
                }
              }
            }
            }
          case "VarType": {ESLVal $414 = _v66.termRef(0);
              ESLVal $413 = _v66.termRef(1);
              
              switch(_v65.termName) {
              case "VarType": {ESLVal $416 = _v65.termRef(0);
                ESLVal $415 = _v65.termRef(1);
                
                {ESLVal l1 = $414;
                
                {ESLVal n1 = $413;
                
                {ESLVal l2 = $416;
                
                {ESLVal n2 = $415;
                
                return n1.eql(n2);
              }
              }
              }
              }
              }
              default: switch(_v65.termName) {
                case "ExtendedAct": {ESLVal $390 = _v65.termRef(0);
                  ESLVal $389 = _v65.termRef(1);
                  ESLVal $388 = _v65.termRef(2);
                  ESLVal $387 = _v65.termRef(3);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal l2 = $390;
                  
                  {ESLVal t2 = $389;
                  
                  {ESLVal ds2 = $388;
                  
                  {ESLVal ms2 = $387;
                  
                  return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $386 = _v65.termRef(0);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal f = $386;
                  
                  return subType.apply(t1,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $385 = _v65.termRef(0);
                  ESLVal $384 = _v65.termRef(1);
                  ESLVal $383 = _v65.termRef(2);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal l2 = $385;
                  
                  {ESLVal n2 = $384;
                  
                  {ESLVal t2 = $383;
                  
                  return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $382 = _v65.termRef(0);
                  ESLVal $381 = _v65.termRef(1);
                  ESLVal $380 = _v65.termRef(2);
                  
                  {ESLVal t1 = _v66;
                  
                  {ESLVal l1 = $382;
                  
                  {ESLVal ns2 = $381;
                  
                  {ESLVal t2 = $380;
                  
                  return subType.apply(t1,t2);
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v66;
                  
                  {ESLVal t2 = _v65;
                  
                  return typeEqual.apply(t1,t2);
                }
                }
              }
            }
            }
          case "ForallType": {ESLVal $393 = _v66.termRef(0);
              ESLVal $392 = _v66.termRef(1);
              ESLVal $391 = _v66.termRef(2);
              
              if($392.isCons())
              {ESLVal $397 = $392.head();
                ESLVal $398 = $392.tail();
                
                if($398.isCons())
                {ESLVal $399 = $398.head();
                  ESLVal $400 = $398.tail();
                  
                  switch(_v65.termName) {
                  case "ForallType": {ESLVal $396 = _v65.termRef(0);
                    ESLVal $395 = _v65.termRef(1);
                    ESLVal $394 = _v65.termRef(2);
                    
                    {ESLVal l1 = $393;
                    
                    {ESLVal ns1 = $392;
                    
                    {ESLVal t1 = $391;
                    
                    {ESLVal l2 = $396;
                    
                    {ESLVal ns2 = $395;
                    
                    {ESLVal t2 = $394;
                    
                    return ns1.eql(ns2).and(subType.apply(t1,t2));
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal l1 = $393;
                    
                    {ESLVal ns1 = $392;
                    
                    {ESLVal t1 = $391;
                    
                    {ESLVal t2 = _v65;
                    
                    return subType.apply(t1,t2);
                  }
                  }
                  }
                  }
                }
                }
              else if($398.isNil())
                switch($391.termName) {
                  case "ListType": {ESLVal $408 = $391.termRef(0);
                    ESLVal $407 = $391.termRef(1);
                    
                    switch($407.termName) {
                    case "VarType": {ESLVal $410 = $407.termRef(0);
                      ESLVal $409 = $407.termRef(1);
                      
                      switch(_v65.termName) {
                      case "ListType": {ESLVal $412 = _v65.termRef(0);
                        ESLVal $411 = _v65.termRef(1);
                        
                        {ESLVal l2 = $393;
                        
                        {ESLVal v1 = $397;
                        
                        {ESLVal l3 = $408;
                        
                        {ESLVal l4 = $410;
                        
                        {ESLVal v2 = $409;
                        
                        {ESLVal l1 = $412;
                        
                        {ESLVal t1 = $411;
                        
                        if(v1.eql(v2).boolVal)
                        return $true;
                        else
                          switch(_v65.termName) {
                            case "ForallType": {ESLVal $396 = _v65.termRef(0);
                              ESLVal $395 = _v65.termRef(1);
                              ESLVal $394 = _v65.termRef(2);
                              
                              {ESLVal _v150 = $393;
                              
                              {ESLVal ns1 = $392;
                              
                              {ESLVal _v151 = $391;
                              
                              {ESLVal _v152 = $396;
                              
                              {ESLVal ns2 = $395;
                              
                              {ESLVal t2 = $394;
                              
                              return ns1.eql(ns2).and(subType.apply(_v151,t2));
                            }
                            }
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v153 = $393;
                              
                              {ESLVal ns1 = $392;
                              
                              {ESLVal _v154 = $391;
                              
                              {ESLVal t2 = _v65;
                              
                              return subType.apply(_v154,t2);
                            }
                            }
                            }
                            }
                          }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      default: switch(_v65.termName) {
                        case "ForallType": {ESLVal $396 = _v65.termRef(0);
                          ESLVal $395 = _v65.termRef(1);
                          ESLVal $394 = _v65.termRef(2);
                          
                          {ESLVal l1 = $393;
                          
                          {ESLVal ns1 = $392;
                          
                          {ESLVal t1 = $391;
                          
                          {ESLVal l2 = $396;
                          
                          {ESLVal ns2 = $395;
                          
                          {ESLVal t2 = $394;
                          
                          return ns1.eql(ns2).and(subType.apply(t1,t2));
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal l1 = $393;
                          
                          {ESLVal ns1 = $392;
                          
                          {ESLVal t1 = $391;
                          
                          {ESLVal t2 = _v65;
                          
                          return subType.apply(t1,t2);
                        }
                        }
                        }
                        }
                      }
                    }
                    }
                    default: switch(_v65.termName) {
                      case "ForallType": {ESLVal $396 = _v65.termRef(0);
                        ESLVal $395 = _v65.termRef(1);
                        ESLVal $394 = _v65.termRef(2);
                        
                        {ESLVal l1 = $393;
                        
                        {ESLVal ns1 = $392;
                        
                        {ESLVal t1 = $391;
                        
                        {ESLVal l2 = $396;
                        
                        {ESLVal ns2 = $395;
                        
                        {ESLVal t2 = $394;
                        
                        return ns1.eql(ns2).and(subType.apply(t1,t2));
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal l1 = $393;
                        
                        {ESLVal ns1 = $392;
                        
                        {ESLVal t1 = $391;
                        
                        {ESLVal t2 = _v65;
                        
                        return subType.apply(t1,t2);
                      }
                      }
                      }
                      }
                    }
                  }
                  }
                case "SetType": {ESLVal $402 = $391.termRef(0);
                    ESLVal $401 = $391.termRef(1);
                    
                    switch($401.termName) {
                    case "VarType": {ESLVal $404 = $401.termRef(0);
                      ESLVal $403 = $401.termRef(1);
                      
                      switch(_v65.termName) {
                      case "SetType": {ESLVal $406 = _v65.termRef(0);
                        ESLVal $405 = _v65.termRef(1);
                        
                        {ESLVal l2 = $393;
                        
                        {ESLVal v1 = $397;
                        
                        {ESLVal l3 = $402;
                        
                        {ESLVal l4 = $404;
                        
                        {ESLVal v2 = $403;
                        
                        {ESLVal l1 = $406;
                        
                        {ESLVal t1 = $405;
                        
                        if(v1.eql(v2).boolVal)
                        return $true;
                        else
                          switch(_v65.termName) {
                            case "ForallType": {ESLVal $396 = _v65.termRef(0);
                              ESLVal $395 = _v65.termRef(1);
                              ESLVal $394 = _v65.termRef(2);
                              
                              {ESLVal _v145 = $393;
                              
                              {ESLVal ns1 = $392;
                              
                              {ESLVal _v146 = $391;
                              
                              {ESLVal _v147 = $396;
                              
                              {ESLVal ns2 = $395;
                              
                              {ESLVal t2 = $394;
                              
                              return ns1.eql(ns2).and(subType.apply(_v146,t2));
                            }
                            }
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v148 = $393;
                              
                              {ESLVal ns1 = $392;
                              
                              {ESLVal _v149 = $391;
                              
                              {ESLVal t2 = _v65;
                              
                              return subType.apply(_v149,t2);
                            }
                            }
                            }
                            }
                          }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      default: switch(_v65.termName) {
                        case "ForallType": {ESLVal $396 = _v65.termRef(0);
                          ESLVal $395 = _v65.termRef(1);
                          ESLVal $394 = _v65.termRef(2);
                          
                          {ESLVal l1 = $393;
                          
                          {ESLVal ns1 = $392;
                          
                          {ESLVal t1 = $391;
                          
                          {ESLVal l2 = $396;
                          
                          {ESLVal ns2 = $395;
                          
                          {ESLVal t2 = $394;
                          
                          return ns1.eql(ns2).and(subType.apply(t1,t2));
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal l1 = $393;
                          
                          {ESLVal ns1 = $392;
                          
                          {ESLVal t1 = $391;
                          
                          {ESLVal t2 = _v65;
                          
                          return subType.apply(t1,t2);
                        }
                        }
                        }
                        }
                      }
                    }
                    }
                    default: switch(_v65.termName) {
                      case "ForallType": {ESLVal $396 = _v65.termRef(0);
                        ESLVal $395 = _v65.termRef(1);
                        ESLVal $394 = _v65.termRef(2);
                        
                        {ESLVal l1 = $393;
                        
                        {ESLVal ns1 = $392;
                        
                        {ESLVal t1 = $391;
                        
                        {ESLVal l2 = $396;
                        
                        {ESLVal ns2 = $395;
                        
                        {ESLVal t2 = $394;
                        
                        return ns1.eql(ns2).and(subType.apply(t1,t2));
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal l1 = $393;
                        
                        {ESLVal ns1 = $392;
                        
                        {ESLVal t1 = $391;
                        
                        {ESLVal t2 = _v65;
                        
                        return subType.apply(t1,t2);
                      }
                      }
                      }
                      }
                    }
                  }
                  }
                  default: switch(_v65.termName) {
                    case "ForallType": {ESLVal $396 = _v65.termRef(0);
                      ESLVal $395 = _v65.termRef(1);
                      ESLVal $394 = _v65.termRef(2);
                      
                      {ESLVal l1 = $393;
                      
                      {ESLVal ns1 = $392;
                      
                      {ESLVal t1 = $391;
                      
                      {ESLVal l2 = $396;
                      
                      {ESLVal ns2 = $395;
                      
                      {ESLVal t2 = $394;
                      
                      return ns1.eql(ns2).and(subType.apply(t1,t2));
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal l1 = $393;
                      
                      {ESLVal ns1 = $392;
                      
                      {ESLVal t1 = $391;
                      
                      {ESLVal t2 = _v65;
                      
                      return subType.apply(t1,t2);
                    }
                    }
                    }
                    }
                  }
                }
              else switch(_v65.termName) {
                  case "ForallType": {ESLVal $396 = _v65.termRef(0);
                    ESLVal $395 = _v65.termRef(1);
                    ESLVal $394 = _v65.termRef(2);
                    
                    {ESLVal l1 = $393;
                    
                    {ESLVal ns1 = $392;
                    
                    {ESLVal t1 = $391;
                    
                    {ESLVal l2 = $396;
                    
                    {ESLVal ns2 = $395;
                    
                    {ESLVal t2 = $394;
                    
                    return ns1.eql(ns2).and(subType.apply(t1,t2));
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal l1 = $393;
                    
                    {ESLVal ns1 = $392;
                    
                    {ESLVal t1 = $391;
                    
                    {ESLVal t2 = _v65;
                    
                    return subType.apply(t1,t2);
                  }
                  }
                  }
                  }
                }
              }
            else if($392.isNil())
              switch(_v65.termName) {
                case "ForallType": {ESLVal $396 = _v65.termRef(0);
                  ESLVal $395 = _v65.termRef(1);
                  ESLVal $394 = _v65.termRef(2);
                  
                  {ESLVal l1 = $393;
                  
                  {ESLVal ns1 = $392;
                  
                  {ESLVal t1 = $391;
                  
                  {ESLVal l2 = $396;
                  
                  {ESLVal ns2 = $395;
                  
                  {ESLVal t2 = $394;
                  
                  return ns1.eql(ns2).and(subType.apply(t1,t2));
                }
                }
                }
                }
                }
                }
                }
                default: {ESLVal l1 = $393;
                  
                  {ESLVal ns1 = $392;
                  
                  {ESLVal t1 = $391;
                  
                  {ESLVal t2 = _v65;
                  
                  return subType.apply(t1,t2);
                }
                }
                }
                }
              }
            else switch(_v65.termName) {
                case "ForallType": {ESLVal $396 = _v65.termRef(0);
                  ESLVal $395 = _v65.termRef(1);
                  ESLVal $394 = _v65.termRef(2);
                  
                  {ESLVal l1 = $393;
                  
                  {ESLVal ns1 = $392;
                  
                  {ESLVal t1 = $391;
                  
                  {ESLVal l2 = $396;
                  
                  {ESLVal ns2 = $395;
                  
                  {ESLVal t2 = $394;
                  
                  return ns1.eql(ns2).and(subType.apply(t1,t2));
                }
                }
                }
                }
                }
                }
                }
                default: {ESLVal l1 = $393;
                  
                  {ESLVal ns1 = $392;
                  
                  {ESLVal t1 = $391;
                  
                  {ESLVal t2 = _v65;
                  
                  return subType.apply(t1,t2);
                }
                }
                }
                }
              }
            }
            default: switch(_v65.termName) {
              case "ExtendedAct": {ESLVal $390 = _v65.termRef(0);
                ESLVal $389 = _v65.termRef(1);
                ESLVal $388 = _v65.termRef(2);
                ESLVal $387 = _v65.termRef(3);
                
                {ESLVal t1 = _v66;
                
                {ESLVal l2 = $390;
                
                {ESLVal t2 = $389;
                
                {ESLVal ds2 = $388;
                
                {ESLVal ms2 = $387;
                
                return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $386 = _v65.termRef(0);
                
                {ESLVal t1 = _v66;
                
                {ESLVal f = $386;
                
                return subType.apply(t1,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $385 = _v65.termRef(0);
                ESLVal $384 = _v65.termRef(1);
                ESLVal $383 = _v65.termRef(2);
                
                {ESLVal t1 = _v66;
                
                {ESLVal l2 = $385;
                
                {ESLVal n2 = $384;
                
                {ESLVal t2 = $383;
                
                return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $382 = _v65.termRef(0);
                ESLVal $381 = _v65.termRef(1);
                ESLVal $380 = _v65.termRef(2);
                
                {ESLVal t1 = _v66;
                
                {ESLVal l1 = $382;
                
                {ESLVal ns2 = $381;
                
                {ESLVal t2 = $380;
                
                return subType.apply(t1,t2);
              }
              }
              }
              }
              }
              default: {ESLVal t1 = _v66;
                
                {ESLVal t2 = _v65;
                
                return typeEqual.apply(t1,t2);
              }
              }
            }
          }
          }
    }
  });
  public static ESLVal flattenAct = new ESLVal(new Function(new ESLVal("flattenAct"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l1 = $args[0];
  ESLVal t = $args[1];
  ESLVal ds1 = $args[2];
  ESLVal ms1 = $args[3];
  {ESLVal _v64 = t;
        
        switch(_v64.termName) {
        case "ActType": {ESLVal $379 = _v64.termRef(0);
          ESLVal $378 = _v64.termRef(1);
          ESLVal $377 = _v64.termRef(2);
          
          {ESLVal l2 = $379;
          
          {ESLVal ds2 = $378;
          
          {ESLVal ms2 = $377;
          
          return new ESLVal("ActType",l1,ds1.add(ds2),ms1.add(ms2));
        }
        }
        }
        }
      case "ExtendedAct": {ESLVal $376 = _v64.termRef(0);
          ESLVal $375 = _v64.termRef(1);
          ESLVal $374 = _v64.termRef(2);
          ESLVal $373 = _v64.termRef(3);
          
          {ESLVal l2 = $376;
          
          {ESLVal _v143 = $375;
          
          {ESLVal ds2 = $374;
          
          {ESLVal ms2 = $373;
          
          return flattenAct.apply(l1,flattenAct.apply(l2,_v143,ds2,ms2),ds1,ms1);
        }
        }
        }
        }
        }
      case "TypeClosure": {ESLVal $372 = _v64.termRef(0);
          
          {ESLVal f = $372;
          
          return flattenAct.apply(l1,f.apply(),ds1,ms1);
        }
        }
      case "RecType": {ESLVal $371 = _v64.termRef(0);
          ESLVal $370 = _v64.termRef(1);
          ESLVal $369 = _v64.termRef(2);
          
          {ESLVal l2 = $371;
          
          {ESLVal n = $370;
          
          {ESLVal b = $369;
          
          return flattenAct.apply(l1,substType.apply(t,n,b),ds1,ms1);
        }
        }
        }
        }
        default: {ESLVal _v144 = _v64;
          
          return error(new ESLVal("TypeError",l1,new ESLVal("unknown type for flatten ").add(_v144)));
        }
      }
      }
    }
  });
  public static ESLVal actEqual = new ESLVal(new Function(new ESLVal("actEqual"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal exports1 = $args[0];
  ESLVal exports2 = $args[1];
  ESLVal handlers1 = $args[2];
  ESLVal handlers2 = $args[3];
  return forall.apply(new ESLVal(new Function(new ESLVal("fun17995"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal d1 = $args[0];
        return exists.apply(new ESLVal(new Function(new ESLVal("fun17996"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal d2 = $args[0];
              return equalDec.apply(d1,d2);
                }
              }),exports2);
          }
        }),exports1).and(forall.apply(new ESLVal(new Function(new ESLVal("fun17997"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal d1 = $args[0];
        return exists.apply(new ESLVal(new Function(new ESLVal("fun17998"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal d2 = $args[0];
              return equalDec.apply(d1,d2);
                }
              }),exports1);
          }
        }),exports2).and(forall.apply(new ESLVal(new Function(new ESLVal("fun17999"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal m1 = $args[0];
        return exists.apply(new ESLVal(new Function(new ESLVal("fun18000"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal m2 = $args[0];
              return equalMessage.apply(m1,m2);
                }
              }),handlers2);
          }
        }),handlers1).and(forall.apply(new ESLVal(new Function(new ESLVal("fun18001"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal m1 = $args[0];
        return exists.apply(new ESLVal(new Function(new ESLVal("fun18002"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal m2 = $args[0];
              return equalMessage.apply(m1,m2);
                }
              }),handlers1);
          }
        }),handlers2))));
    }
  });
  public static ESLVal actSubType = new ESLVal(new Function(new ESLVal("actSubType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal exports1 = $args[0];
  ESLVal exports2 = $args[1];
  ESLVal handlers1 = $args[2];
  ESLVal handlers2 = $args[3];
  return forall.apply(new ESLVal(new Function(new ESLVal("fun18003"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal d2 = $args[0];
        return exists.apply(new ESLVal(new Function(new ESLVal("fun18004"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal d1 = $args[0];
              return decSubType.apply(d1,d2);
                }
              }),exports1);
          }
        }),exports2).and(forall.apply(new ESLVal(new Function(new ESLVal("fun18005"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal m2 = $args[0];
        return exists.apply(new ESLVal(new Function(new ESLVal("fun18006"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal m1 = $args[0];
              return messSubType.apply(m1,m2);
                }
              }),handlers1);
          }
        }),handlers2));
    }
  });
  public static ESLVal equalDec = new ESLVal(new Function(new ESLVal("equalDec"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d1 = $args[0];
  ESLVal d2 = $args[1];
  {ESLVal _v63 = d1;
        ESLVal _v62 = d2;
        
        switch(_v63.termName) {
        case "Dec": {ESLVal $364 = _v63.termRef(0);
          ESLVal $363 = _v63.termRef(1);
          ESLVal $362 = _v63.termRef(2);
          ESLVal $361 = _v63.termRef(3);
          
          switch(_v62.termName) {
          case "Dec": {ESLVal $368 = _v62.termRef(0);
            ESLVal $367 = _v62.termRef(1);
            ESLVal $366 = _v62.termRef(2);
            ESLVal $365 = _v62.termRef(3);
            
            {ESLVal l1 = $364;
            
            {ESLVal n1 = $363;
            
            {ESLVal t1 = $362;
            
            {ESLVal st1 = $361;
            
            {ESLVal l2 = $368;
            
            {ESLVal n2 = $367;
            
            {ESLVal t2 = $366;
            
            {ESLVal st2 = $365;
            
            return n1.eql(n2).and(typeEqual.apply(t1,t2));
          }
          }
          }
          }
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(19758,19889)").add(ESLVal.list(_v63,_v62)));
        }
        }
        default: return error(new ESLVal("case error at Pos(19758,19889)").add(ESLVal.list(_v63,_v62)));
      }
      }
    }
  });
  public static ESLVal decSubType = new ESLVal(new Function(new ESLVal("decSubType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d1 = $args[0];
  ESLVal d2 = $args[1];
  {ESLVal _v61 = d1;
        ESLVal _v60 = d2;
        
        switch(_v61.termName) {
        case "Dec": {ESLVal $356 = _v61.termRef(0);
          ESLVal $355 = _v61.termRef(1);
          ESLVal $354 = _v61.termRef(2);
          ESLVal $353 = _v61.termRef(3);
          
          switch(_v60.termName) {
          case "Dec": {ESLVal $360 = _v60.termRef(0);
            ESLVal $359 = _v60.termRef(1);
            ESLVal $358 = _v60.termRef(2);
            ESLVal $357 = _v60.termRef(3);
            
            {ESLVal l1 = $356;
            
            {ESLVal n1 = $355;
            
            {ESLVal t1 = $354;
            
            {ESLVal st1 = $353;
            
            {ESLVal l2 = $360;
            
            {ESLVal n2 = $359;
            
            {ESLVal t2 = $358;
            
            {ESLVal st2 = $357;
            
            return n1.eql(n2).and(subType.apply(t1,t2));
          }
          }
          }
          }
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(19933,20062)").add(ESLVal.list(_v61,_v60)));
        }
        }
        default: return error(new ESLVal("case error at Pos(19933,20062)").add(ESLVal.list(_v61,_v60)));
      }
      }
    }
  });
  public static ESLVal equalMessage = new ESLVal(new Function(new ESLVal("equalMessage"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal m1 = $args[0];
  ESLVal m2 = $args[1];
  {ESLVal _v59 = m1;
        ESLVal _v58 = m2;
        
        switch(_v59.termName) {
        case "MessageType": {ESLVal $350 = _v59.termRef(0);
          ESLVal $349 = _v59.termRef(1);
          
          switch(_v58.termName) {
          case "MessageType": {ESLVal $352 = _v58.termRef(0);
            ESLVal $351 = _v58.termRef(1);
            
            {ESLVal l1 = $350;
            
            {ESLVal ts1 = $349;
            
            {ESLVal l2 = $352;
            
            {ESLVal ts2 = $351;
            
            return typesEqual.apply(ts1,ts2);
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(20108,20218)").add(ESLVal.list(_v59,_v58)));
        }
        }
        default: return error(new ESLVal("case error at Pos(20108,20218)").add(ESLVal.list(_v59,_v58)));
      }
      }
    }
  });
  public static ESLVal messSubType = new ESLVal(new Function(new ESLVal("messSubType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal m1 = $args[0];
  ESLVal m2 = $args[1];
  {ESLVal _v57 = m1;
        ESLVal _v56 = m2;
        
        switch(_v57.termName) {
        case "MessageType": {ESLVal $346 = _v57.termRef(0);
          ESLVal $345 = _v57.termRef(1);
          
          switch(_v56.termName) {
          case "MessageType": {ESLVal $348 = _v56.termRef(0);
            ESLVal $347 = _v56.termRef(1);
            
            {ESLVal l1 = $346;
            
            {ESLVal ts1 = $345;
            
            {ESLVal l2 = $348;
            
            {ESLVal ts2 = $347;
            
            return subTypes.apply(ts1,ts2);
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(20263,20371)").add(ESLVal.list(_v57,_v56)));
        }
        }
        default: return error(new ESLVal("case error at Pos(20263,20371)").add(ESLVal.list(_v57,_v56)));
      }
      }
    }
  });
  public static ESLVal recordTypeEqual = new ESLVal(new Function(new ESLVal("recordTypeEqual"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal fields1 = $args[0];
  ESLVal fields2 = $args[1];
  return forall.apply(new ESLVal(new Function(new ESLVal("fun18007"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal t1 = $args[0];
        return exists.apply(new ESLVal(new Function(new ESLVal("fun18008"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal t2 = $args[0];
              return decName.apply(t1).eql(decName.apply(t2)).and(typeEqual.apply(decType.apply(t1),decType.apply(t2)));
                }
              }),fields2);
          }
        }),fields1).and(forall.apply(new ESLVal(new Function(new ESLVal("fun18009"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal t1 = $args[0];
        return exists.apply(new ESLVal(new Function(new ESLVal("fun18010"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal t2 = $args[0];
              return decName.apply(t1).eql(decName.apply(t2)).and(typeEqual.apply(decType.apply(t1),decType.apply(t2)));
                }
              }),fields1);
          }
        }),fields2));
    }
  });
  public static ESLVal recordSubType = new ESLVal(new Function(new ESLVal("recordSubType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal fields1 = $args[0];
  ESLVal fields2 = $args[1];
  return forall.apply(new ESLVal(new Function(new ESLVal("fun18011"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal t2 = $args[0];
        return exists.apply(new ESLVal(new Function(new ESLVal("fun18012"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal t1 = $args[0];
              return decName.apply(t1).eql(decName.apply(t2)).and(subType.apply(decType.apply(t1),decType.apply(t2)));
                }
              }),fields1);
          }
        }),fields2);
    }
  });
  public static ESLVal applyTypeFun = new ESLVal(new Function(new ESLVal("applyTypeFun"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal op = $args[1];
  ESLVal args = $args[2];
  {ESLVal _v55 = op;
        
        switch(_v55.termName) {
        case "RecType": {ESLVal $344 = _v55.termRef(0);
          ESLVal $343 = _v55.termRef(1);
          ESLVal $342 = _v55.termRef(2);
          
          {ESLVal lr = $344;
          
          {ESLVal n = $343;
          
          {ESLVal t = $342;
          
          return applyTypeFun.apply(l,unfoldType.apply(lr,n,t),args);
        }
        }
        }
        }
      case "TypeFun": {ESLVal $341 = _v55.termRef(0);
          ESLVal $340 = _v55.termRef(1);
          ESLVal $339 = _v55.termRef(2);
          
          {ESLVal _v141 = $341;
          
          {ESLVal names = $340;
          
          {ESLVal t = $339;
          
          if(length.apply(args).eql(length.apply(names)).boolVal)
          return substTypeEnv.apply(zipTypeEnv.apply(names,args),t);
          else
            return error(new ESLVal("TypeError",_v141,new ESLVal("type fun expects ").add(length.apply(names).add(new ESLVal(" args, but supplied with ").add(length.apply(args))))));
        }
        }
        }
        }
        default: {ESLVal _v142 = _v55;
          
          return error(new ESLVal("TypeError",l,new ESLVal("expecting a type function: ").add(_v142)));
        }
      }
      }
    }
  });
  public static ESLVal unfoldType = new ESLVal(new Function(new ESLVal("unfoldType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal n = $args[1];
  ESLVal t = $args[2];
  return substType.apply(new ESLVal("RecType",l,n,t),n,t);
    }
  });
  public static ESLVal forceType = new ESLVal(new Function(new ESLVal("forceType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v54 = t;
        
        switch(_v54.termName) {
        case "TypeClosure": {ESLVal $338 = _v54.termRef(0);
          
          {ESLVal f = $338;
          
          return forceType.apply(f.apply());
        }
        }
        default: {ESLVal _v140 = _v54;
          
          return _v140;
        }
      }
      }
    }
  });
  public static ESLVal typesEqual = new ESLVal(new Function(new ESLVal("typesEqual"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal ts1 = $args[0];
  ESLVal ts2 = $args[1];
  {ESLVal _v53 = ts1;
        ESLVal _v52 = ts2;
        
        if(_v53.isCons())
        {ESLVal $332 = _v53.head();
          ESLVal $333 = _v53.tail();
          
          if(_v52.isCons())
          {ESLVal $334 = _v52.head();
            ESLVal $335 = _v52.tail();
            
            {ESLVal t1 = $332;
            
            {ESLVal _v133 = $333;
            
            {ESLVal t2 = $334;
            
            {ESLVal _v134 = $335;
            
            return typeEqual.apply(t1,t2).and(typesEqual.apply(_v133,_v134));
          }
          }
          }
          }
          }
        else if(_v52.isNil())
          if(_v52.isCons())
            {ESLVal $330 = _v52.head();
              ESLVal $331 = _v52.tail();
              
              return error(new ESLVal("case error at Pos(21677,21887)").add(ESLVal.list(_v53,_v52)));
            }
          else if(_v52.isNil())
            {ESLVal _v135 = _v53;
              
              return $false;
            }
          else return error(new ESLVal("case error at Pos(21677,21887)").add(ESLVal.list(_v53,_v52)));
        else if(_v52.isCons())
            {ESLVal $330 = _v52.head();
              ESLVal $331 = _v52.tail();
              
              return error(new ESLVal("case error at Pos(21677,21887)").add(ESLVal.list(_v53,_v52)));
            }
          else if(_v52.isNil())
            {ESLVal _v136 = _v53;
              
              return $false;
            }
          else return error(new ESLVal("case error at Pos(21677,21887)").add(ESLVal.list(_v53,_v52)));
        }
      else if(_v53.isNil())
        if(_v52.isCons())
          {ESLVal $336 = _v52.head();
            ESLVal $337 = _v52.tail();
            
            {ESLVal _v137 = _v52;
            
            return $false;
          }
          }
        else if(_v52.isNil())
          return $true;
        else {ESLVal _v138 = _v52;
            
            return $false;
          }
      else if(_v52.isCons())
          {ESLVal $330 = _v52.head();
            ESLVal $331 = _v52.tail();
            
            return error(new ESLVal("case error at Pos(21677,21887)").add(ESLVal.list(_v53,_v52)));
          }
        else if(_v52.isNil())
          {ESLVal _v139 = _v53;
            
            return $false;
          }
        else return error(new ESLVal("case error at Pos(21677,21887)").add(ESLVal.list(_v53,_v52)));
      }
    }
  });
  public static ESLVal subTypes = new ESLVal(new Function(new ESLVal("subTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal ts1 = $args[0];
  ESLVal ts2 = $args[1];
  {ESLVal _v51 = ts1;
        ESLVal _v50 = ts2;
        
        if(_v51.isCons())
        {ESLVal $324 = _v51.head();
          ESLVal $325 = _v51.tail();
          
          if(_v50.isCons())
          {ESLVal $326 = _v50.head();
            ESLVal $327 = _v50.tail();
            
            {ESLVal t1 = $324;
            
            {ESLVal _v126 = $325;
            
            {ESLVal t2 = $326;
            
            {ESLVal _v127 = $327;
            
            return subType.apply(t1,t2).and(subTypes.apply(_v126,_v127));
          }
          }
          }
          }
          }
        else if(_v50.isNil())
          if(_v50.isCons())
            {ESLVal $322 = _v50.head();
              ESLVal $323 = _v50.tail();
              
              return error(new ESLVal("case error at Pos(21933,22139)").add(ESLVal.list(_v51,_v50)));
            }
          else if(_v50.isNil())
            {ESLVal _v128 = _v51;
              
              return $false;
            }
          else return error(new ESLVal("case error at Pos(21933,22139)").add(ESLVal.list(_v51,_v50)));
        else if(_v50.isCons())
            {ESLVal $322 = _v50.head();
              ESLVal $323 = _v50.tail();
              
              return error(new ESLVal("case error at Pos(21933,22139)").add(ESLVal.list(_v51,_v50)));
            }
          else if(_v50.isNil())
            {ESLVal _v129 = _v51;
              
              return $false;
            }
          else return error(new ESLVal("case error at Pos(21933,22139)").add(ESLVal.list(_v51,_v50)));
        }
      else if(_v51.isNil())
        if(_v50.isCons())
          {ESLVal $328 = _v50.head();
            ESLVal $329 = _v50.tail();
            
            {ESLVal _v130 = _v50;
            
            return $false;
          }
          }
        else if(_v50.isNil())
          return $true;
        else {ESLVal _v131 = _v50;
            
            return $false;
          }
      else if(_v50.isCons())
          {ESLVal $322 = _v50.head();
            ESLVal $323 = _v50.tail();
            
            return error(new ESLVal("case error at Pos(21933,22139)").add(ESLVal.list(_v51,_v50)));
          }
        else if(_v50.isNil())
          {ESLVal _v132 = _v51;
            
            return $false;
          }
        else return error(new ESLVal("case error at Pos(21933,22139)").add(ESLVal.list(_v51,_v50)));
      }
    }
  });
  public static ESLVal typeSetEqual = new ESLVal(new Function(new ESLVal("typeSetEqual"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal types1 = $args[0];
  ESLVal types2 = $args[1];
  return typeSubset.apply(types1,types2).and(typeSubset.apply(types2,types1));
    }
  });
  public static ESLVal typeSubset = new ESLVal(new Function(new ESLVal("typeSubset"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal sub = $args[0];
  ESLVal sup = $args[1];
  {ESLVal _v49 = sub;
        
        if(_v49.isCons())
        {ESLVal $320 = _v49.head();
          ESLVal $321 = _v49.tail();
          
          {ESLVal t = $320;
          
          {ESLVal _v125 = $321;
          
          return typeMember.apply(t,sup).and(typeSubset.apply(_v125,sup));
        }
        }
        }
      else if(_v49.isNil())
        return $true;
      else return error(new ESLVal("case error at Pos(22299,22405)").add(ESLVal.list(_v49)));
      }
    }
  });
  public static ESLVal typeMember = new ESLVal(new Function(new ESLVal("typeMember"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  ESLVal types = $args[1];
  {ESLVal _v48 = types;
        
        if(_v48.isCons())
        {ESLVal $318 = _v48.head();
          ESLVal $319 = _v48.tail();
          
          {ESLVal tt = $318;
          
          {ESLVal _v122 = $319;
          
          if(typeEqual.apply(t,tt).boolVal)
          return $true;
          else
            {ESLVal _v123 = $318;
              
              {ESLVal _v124 = $319;
              
              return typeMember.apply(t,_v124);
            }
            }
        }
        }
        }
      else if(_v48.isNil())
        return $false;
      else return error(new ESLVal("case error at Pos(22451,22598)").add(ESLVal.list(_v48)));
      }
    }
  });
  public static ESLVal substTypes = new ESLVal(new Function(new ESLVal("substTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal newType = $args[0];
  ESLVal n = $args[1];
  ESLVal oldTypes = $args[2];
  {ESLVal _v47 = oldTypes;
        
        if(_v47.isCons())
        {ESLVal $316 = _v47.head();
          ESLVal $317 = _v47.tail();
          
          {ESLVal t = $316;
          
          {ESLVal ts = $317;
          
          return substTypes.apply(newType,n,ts).cons(substType.apply(newType,n,t));
        }
        }
        }
      else if(_v47.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(22750,22870)").add(ESLVal.list(_v47)));
      }
    }
  });
  public static ESLVal substType = new ESLVal(new Function(new ESLVal("substType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal newType = $args[0];
  ESLVal n = $args[1];
  ESLVal oldType = $args[2];
  {ESLVal _v41 = oldType;
        
        switch(_v41.termName) {
        case "ApplyType": {ESLVal $311 = _v41.termRef(0);
          ESLVal $310 = _v41.termRef(1);
          ESLVal $309 = _v41.termRef(2);
          
          {ESLVal l = $311;
          
          {ESLVal m = $310;
          
          {ESLVal types = $309;
          
          if(m.eql(n).boolVal)
          return new ESLVal("ApplyTypeFun",l,newType,substTypes.apply(newType,n,types));
          else
            return new ESLVal("ApplyType",l,m,substTypes.apply(newType,n,types));
        }
        }
        }
        }
      case "ApplyTypeFun": {ESLVal $308 = _v41.termRef(0);
          ESLVal $307 = _v41.termRef(1);
          ESLVal $306 = _v41.termRef(2);
          
          {ESLVal l = $308;
          
          {ESLVal op = $307;
          
          {ESLVal args = $306;
          
          return new ESLVal("ApplyTypeFun",l,substType.apply(newType,n,op),substTypes.apply(newType,n,args));
        }
        }
        }
        }
      case "ActType": {ESLVal $305 = _v41.termRef(0);
          ESLVal $304 = _v41.termRef(1);
          ESLVal $303 = _v41.termRef(2);
          
          {ESLVal l = $305;
          
          {ESLVal decs = $304;
          
          {ESLVal handlers = $303;
          
          return new ESLVal("ActType",l,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v45 = $qualArg;
                
                {ESLVal d = _v45;
                
                return ESLVal.list(ESLVal.list(substDec.apply(newType,n,d)));
              }
              }
            }
          }).map(decs).flatten().flatten(),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v46 = $qualArg;
                
                {ESLVal m = _v46;
                
                return ESLVal.list(ESLVal.list(substMType.apply(newType,n,m)));
              }
              }
            }
          }).map(handlers).flatten().flatten());
        }
        }
        }
        }
      case "ArrayType": {ESLVal $302 = _v41.termRef(0);
          ESLVal $301 = _v41.termRef(1);
          
          {ESLVal l = $302;
          
          {ESLVal t = $301;
          
          return new ESLVal("ArrayType",l,substType.apply(newType,n,t));
        }
        }
        }
      case "BoolType": {ESLVal $300 = _v41.termRef(0);
          
          {ESLVal l = $300;
          
          return oldType;
        }
        }
      case "ExtendedAct": {ESLVal $299 = _v41.termRef(0);
          ESLVal $298 = _v41.termRef(1);
          ESLVal $297 = _v41.termRef(2);
          ESLVal $296 = _v41.termRef(3);
          
          {ESLVal l = $299;
          
          {ESLVal parent = $298;
          
          {ESLVal decs = $297;
          
          {ESLVal ms = $296;
          
          return new ESLVal("ExtendedAct",l,substType.apply(newType,n,parent),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v43 = $qualArg;
                
                {ESLVal d = _v43;
                
                return ESLVal.list(ESLVal.list(substDec.apply(newType,n,d)));
              }
              }
            }
          }).map(decs).flatten().flatten(),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v44 = $qualArg;
                
                {ESLVal m = _v44;
                
                return ESLVal.list(ESLVal.list(substMType.apply(newType,n,m)));
              }
              }
            }
          }).map(ms).flatten().flatten());
        }
        }
        }
        }
        }
      case "FloatType": {ESLVal $295 = _v41.termRef(0);
          
          {ESLVal l = $295;
          
          return oldType;
        }
        }
      case "ForallType": {ESLVal $294 = _v41.termRef(0);
          ESLVal $293 = _v41.termRef(1);
          ESLVal $292 = _v41.termRef(2);
          
          {ESLVal l = $294;
          
          {ESLVal ns = $293;
          
          {ESLVal t = $292;
          
          if(member.apply(n,ns).boolVal)
          return oldType;
          else
            return new ESLVal("ForallType",l,ns,substType.apply(newType,n,t));
        }
        }
        }
        }
      case "FunType": {ESLVal $291 = _v41.termRef(0);
          ESLVal $290 = _v41.termRef(1);
          ESLVal $289 = _v41.termRef(2);
          
          {ESLVal l = $291;
          
          {ESLVal d = $290;
          
          {ESLVal r = $289;
          
          return new ESLVal("FunType",l,substTypes.apply(newType,n,d),substType.apply(newType,n,r));
        }
        }
        }
        }
      case "IntType": {ESLVal $288 = _v41.termRef(0);
          
          {ESLVal l = $288;
          
          return oldType;
        }
        }
      case "ListType": {ESLVal $287 = _v41.termRef(0);
          ESLVal $286 = _v41.termRef(1);
          
          {ESLVal l = $287;
          
          {ESLVal t = $286;
          
          return new ESLVal("ListType",l,substType.apply(newType,n,t));
        }
        }
        }
      case "NullType": {ESLVal $285 = _v41.termRef(0);
          
          {ESLVal l = $285;
          
          return oldType;
        }
        }
      case "RecordType": {ESLVal $284 = _v41.termRef(0);
          ESLVal $283 = _v41.termRef(1);
          
          {ESLVal l = $284;
          
          {ESLVal fs = $283;
          
          return new ESLVal("RecordType",l,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v42 = $qualArg;
                
                switch(_v42.termName) {
                case "Dec": {ESLVal $315 = _v42.termRef(0);
                  ESLVal $314 = _v42.termRef(1);
                  ESLVal $313 = _v42.termRef(2);
                  ESLVal $312 = _v42.termRef(3);
                  
                  {ESLVal dl = $315;
                  
                  {ESLVal _v121 = $314;
                  
                  {ESLVal t = $313;
                  
                  {ESLVal dt = $312;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("Dec",dl,_v121,substType.apply(newType,_v121,t),dt)));
                }
                }
                }
                }
                }
                default: {ESLVal _0 = _v42;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten());
        }
        }
        }
      case "RecType": {ESLVal $282 = _v41.termRef(0);
          ESLVal $281 = _v41.termRef(1);
          ESLVal $280 = _v41.termRef(2);
          
          {ESLVal l = $282;
          
          {ESLVal a = $281;
          
          {ESLVal t = $280;
          
          if(n.eql(a).boolVal)
          return oldType;
          else
            return new ESLVal("RecType",l,a,substType.apply(newType,n,t));
        }
        }
        }
        }
      case "SetType": {ESLVal $279 = _v41.termRef(0);
          ESLVal $278 = _v41.termRef(1);
          
          {ESLVal l = $279;
          
          {ESLVal t = $278;
          
          return new ESLVal("SetType",l,substType.apply(newType,n,t));
        }
        }
        }
      case "StrType": {ESLVal $277 = _v41.termRef(0);
          
          {ESLVal l = $277;
          
          return oldType;
        }
        }
      case "TableType": {ESLVal $276 = _v41.termRef(0);
          ESLVal $275 = _v41.termRef(1);
          ESLVal $274 = _v41.termRef(2);
          
          {ESLVal l = $276;
          
          {ESLVal k = $275;
          
          {ESLVal v = $274;
          
          return new ESLVal("TableType",l,substType.apply(newType,n,k),substType.apply(newType,n,v));
        }
        }
        }
        }
      case "TermType": {ESLVal $273 = _v41.termRef(0);
          ESLVal $272 = _v41.termRef(1);
          ESLVal $271 = _v41.termRef(2);
          
          {ESLVal l = $273;
          
          {ESLVal f = $272;
          
          {ESLVal ts = $271;
          
          return new ESLVal("TermType",l,f,substTypes.apply(newType,n,ts));
        }
        }
        }
        }
      case "TypeClosure": {ESLVal $270 = _v41.termRef(0);
          
          {ESLVal f = $270;
          
          return oldType;
        }
        }
      case "TypeFun": {ESLVal $269 = _v41.termRef(0);
          ESLVal $268 = _v41.termRef(1);
          ESLVal $267 = _v41.termRef(2);
          
          {ESLVal l = $269;
          
          {ESLVal ns = $268;
          
          {ESLVal t = $267;
          
          if(member.apply(n,ns).boolVal)
          return oldType;
          else
            return new ESLVal("TypeFun",l,ns,substType.apply(newType,n,t));
        }
        }
        }
        }
      case "UnfoldType": {ESLVal $266 = _v41.termRef(0);
          ESLVal $265 = _v41.termRef(1);
          
          {ESLVal l = $266;
          
          {ESLVal t = $265;
          
          return new ESLVal("UnfoldType",l,substType.apply(newType,n,t));
        }
        }
        }
      case "UnionType": {ESLVal $264 = _v41.termRef(0);
          ESLVal $263 = _v41.termRef(1);
          
          {ESLVal l = $264;
          
          {ESLVal ts = $263;
          
          return new ESLVal("UnionType",l,substTypes.apply(newType,n,ts));
        }
        }
        }
      case "VarType": {ESLVal $262 = _v41.termRef(0);
          ESLVal $261 = _v41.termRef(1);
          
          {ESLVal l = $262;
          
          {ESLVal name = $261;
          
          if(name.eql(n).boolVal)
          return newType;
          else
            return oldType;
        }
        }
        }
      case "VoidType": {ESLVal $260 = _v41.termRef(0);
          
          {ESLVal l = $260;
          
          return oldType;
        }
        }
      case "UnionRef": {ESLVal $259 = _v41.termRef(0);
          ESLVal $258 = _v41.termRef(1);
          ESLVal $257 = _v41.termRef(2);
          
          {ESLVal l = $259;
          
          {ESLVal t = $258;
          
          {ESLVal name = $257;
          
          return new ESLVal("UnionRef",l,substType.apply(newType,n,t),name);
        }
        }
        }
        }
        default: {ESLVal x = _v41;
          
          return error(x);
        }
      }
      }
    }
  });
  public static ESLVal substTypesEnv = new ESLVal(new Function(new ESLVal("substTypesEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal env = $args[0];
  ESLVal types = $args[1];
  {ESLVal _v40 = types;
        
        if(_v40.isCons())
        {ESLVal $255 = _v40.head();
          ESLVal $256 = _v40.tail();
          
          {ESLVal t = $255;
          
          {ESLVal ts = $256;
          
          return substTypesEnv.apply(env,ts).cons(substTypeEnv.apply(env,t));
        }
        }
        }
      else if(_v40.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(25352,25463)").add(ESLVal.list(_v40)));
      }
    }
  });
  public static ESLVal substTypeEnv = new ESLVal(new Function(new ESLVal("substTypeEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal env = $args[0];
  ESLVal oldType = $args[1];
  {ESLVal _v30 = oldType;
        
        switch(_v30.termName) {
        case "ApplyType": {ESLVal $250 = _v30.termRef(0);
          ESLVal $249 = _v30.termRef(1);
          ESLVal $248 = _v30.termRef(2);
          
          {ESLVal l = $250;
          
          {ESLVal n = $249;
          
          {ESLVal types = $248;
          
          {ESLVal op = lookupType.apply(n,env);
          
          if(op.eql($null).boolVal)
          return new ESLVal("ApplyType",l,n,substTypesEnv.apply(env,types));
          else
            return new ESLVal("ApplyTypeFun",l,op,substTypesEnv.apply(env,types));
        }
        }
        }
        }
        }
      case "ApplyTypeFun": {ESLVal $247 = _v30.termRef(0);
          ESLVal $246 = _v30.termRef(1);
          ESLVal $245 = _v30.termRef(2);
          
          {ESLVal l = $247;
          
          {ESLVal op = $246;
          
          {ESLVal args = $245;
          
          return new ESLVal("ApplyTypeFun",l,substTypeEnv.apply(env,op),substTypesEnv.apply(env,args));
        }
        }
        }
        }
      case "ActType": {ESLVal $244 = _v30.termRef(0);
          ESLVal $243 = _v30.termRef(1);
          ESLVal $242 = _v30.termRef(2);
          
          {ESLVal l = $244;
          
          {ESLVal decs = $243;
          
          {ESLVal handlers = $242;
          
          return new ESLVal("ActType",l,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v38 = $qualArg;
                
                {ESLVal d = _v38;
                
                return ESLVal.list(ESLVal.list(substDecEnv.apply(env,d)));
              }
              }
            }
          }).map(decs).flatten().flatten(),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v39 = $qualArg;
                
                {ESLVal m = _v39;
                
                return ESLVal.list(ESLVal.list(substMTypeEnv.apply(env,m)));
              }
              }
            }
          }).map(handlers).flatten().flatten());
        }
        }
        }
        }
      case "ExtendedAct": {ESLVal $241 = _v30.termRef(0);
          ESLVal $240 = _v30.termRef(1);
          ESLVal $239 = _v30.termRef(2);
          ESLVal $238 = _v30.termRef(3);
          
          {ESLVal l = $241;
          
          {ESLVal parent = $240;
          
          {ESLVal decs = $239;
          
          {ESLVal handlers = $238;
          
          return new ESLVal("ExtendedAct",l,substTypeEnv.apply(env,parent),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v36 = $qualArg;
                
                {ESLVal d = _v36;
                
                return ESLVal.list(ESLVal.list(substDecEnv.apply(env,d)));
              }
              }
            }
          }).map(decs).flatten().flatten(),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v37 = $qualArg;
                
                {ESLVal m = _v37;
                
                return ESLVal.list(ESLVal.list(substMTypeEnv.apply(env,m)));
              }
              }
            }
          }).map(handlers).flatten().flatten());
        }
        }
        }
        }
        }
      case "ArrayType": {ESLVal $237 = _v30.termRef(0);
          ESLVal $236 = _v30.termRef(1);
          
          {ESLVal l = $237;
          
          {ESLVal t = $236;
          
          return new ESLVal("ArrayType",l,substTypeEnv.apply(env,t));
        }
        }
        }
      case "BoolType": {ESLVal $235 = _v30.termRef(0);
          
          {ESLVal l = $235;
          
          return oldType;
        }
        }
      case "FloatType": {ESLVal $234 = _v30.termRef(0);
          
          {ESLVal l = $234;
          
          return oldType;
        }
        }
      case "ForallType": {ESLVal $233 = _v30.termRef(0);
          ESLVal $232 = _v30.termRef(1);
          ESLVal $231 = _v30.termRef(2);
          
          {ESLVal l = $233;
          
          {ESLVal ns = $232;
          
          {ESLVal t = $231;
          
          return new ESLVal("ForallType",l,ns,substTypeEnv.apply(removeFromDom.apply(env,ns),t));
        }
        }
        }
        }
      case "FieldType": {ESLVal $230 = _v30.termRef(0);
          ESLVal $229 = _v30.termRef(1);
          ESLVal $228 = _v30.termRef(2);
          
          {ESLVal l = $230;
          
          {ESLVal n = $229;
          
          {ESLVal t = $228;
          
          return new ESLVal("FieldType",l,n,substTypeEnv.apply(env,t));
        }
        }
        }
        }
      case "FunType": {ESLVal $227 = _v30.termRef(0);
          ESLVal $226 = _v30.termRef(1);
          ESLVal $225 = _v30.termRef(2);
          
          {ESLVal l = $227;
          
          {ESLVal d = $226;
          
          {ESLVal r = $225;
          
          return new ESLVal("FunType",l,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v35 = $qualArg;
                
                {ESLVal t = _v35;
                
                return ESLVal.list(ESLVal.list(substTypeEnv.apply(env,t)));
              }
              }
            }
          }).map(d).flatten().flatten(),substTypeEnv.apply(env,r));
        }
        }
        }
        }
      case "TaggedFunType": {ESLVal $224 = _v30.termRef(0);
          ESLVal $223 = _v30.termRef(1);
          ESLVal $222 = _v30.termRef(2);
          ESLVal $221 = _v30.termRef(3);
          
          {ESLVal l = $224;
          
          {ESLVal d = $223;
          
          {ESLVal p = $222;
          
          {ESLVal r = $221;
          
          return new ESLVal("FunType",l,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v34 = $qualArg;
                
                {ESLVal t = _v34;
                
                return ESLVal.list(ESLVal.list(substTypeEnv.apply(env,t)));
              }
              }
            }
          }).map(d).flatten().flatten(),substTypeEnv.apply(env,r));
        }
        }
        }
        }
        }
      case "IntType": {ESLVal $220 = _v30.termRef(0);
          
          {ESLVal l = $220;
          
          return oldType;
        }
        }
      case "ListType": {ESLVal $219 = _v30.termRef(0);
          ESLVal $218 = _v30.termRef(1);
          
          {ESLVal l = $219;
          
          {ESLVal t = $218;
          
          return new ESLVal("ListType",l,substTypeEnv.apply(env,t));
        }
        }
        }
      case "SetType": {ESLVal $217 = _v30.termRef(0);
          ESLVal $216 = _v30.termRef(1);
          
          {ESLVal l = $217;
          
          {ESLVal t = $216;
          
          return new ESLVal("SetType",l,substTypeEnv.apply(env,t));
        }
        }
        }
      case "BagType": {ESLVal $215 = _v30.termRef(0);
          ESLVal $214 = _v30.termRef(1);
          
          {ESLVal l = $215;
          
          {ESLVal t = $214;
          
          return new ESLVal("BagType",l,substTypeEnv.apply(env,t));
        }
        }
        }
      case "NullType": {ESLVal $213 = _v30.termRef(0);
          
          {ESLVal l = $213;
          
          return oldType;
        }
        }
      case "RecType": {ESLVal $212 = _v30.termRef(0);
          ESLVal $211 = _v30.termRef(1);
          ESLVal $210 = _v30.termRef(2);
          
          {ESLVal l = $212;
          
          {ESLVal a = $211;
          
          {ESLVal t = $210;
          
          return new ESLVal("RecType",l,a,substTypeEnv.apply(removeFromDom.apply(env,ESLVal.list(a)),t));
        }
        }
        }
        }
      case "RecordType": {ESLVal $209 = _v30.termRef(0);
          ESLVal $208 = _v30.termRef(1);
          
          {ESLVal l = $209;
          
          {ESLVal fs = $208;
          
          return new ESLVal("RecordType",l,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v33 = $qualArg;
                
                switch(_v33.termName) {
                case "Dec": {ESLVal $254 = _v33.termRef(0);
                  ESLVal $253 = _v33.termRef(1);
                  ESLVal $252 = _v33.termRef(2);
                  ESLVal $251 = _v33.termRef(3);
                  
                  {ESLVal dl = $254;
                  
                  {ESLVal n = $253;
                  
                  {ESLVal t = $252;
                  
                  {ESLVal dt = $251;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("Dec",dl,n,substTypeEnv.apply(env,t),dt)));
                }
                }
                }
                }
                }
                default: {ESLVal _0 = _v33;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten());
        }
        }
        }
      case "StrType": {ESLVal $207 = _v30.termRef(0);
          
          {ESLVal l = $207;
          
          return oldType;
        }
        }
      case "TableType": {ESLVal $206 = _v30.termRef(0);
          ESLVal $205 = _v30.termRef(1);
          ESLVal $204 = _v30.termRef(2);
          
          {ESLVal l = $206;
          
          {ESLVal k = $205;
          
          {ESLVal v = $204;
          
          return new ESLVal("TableType",l,substTypeEnv.apply(env,k),substTypeEnv.apply(env,v));
        }
        }
        }
        }
      case "TermType": {ESLVal $203 = _v30.termRef(0);
          ESLVal $202 = _v30.termRef(1);
          ESLVal $201 = _v30.termRef(2);
          
          {ESLVal l = $203;
          
          {ESLVal f = $202;
          
          {ESLVal ts = $201;
          
          return new ESLVal("TermType",l,f,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v32 = $qualArg;
                
                {ESLVal t = _v32;
                
                return ESLVal.list(ESLVal.list(substTypeEnv.apply(env,t)));
              }
              }
            }
          }).map(ts).flatten().flatten());
        }
        }
        }
        }
      case "TypeClosure": {ESLVal $200 = _v30.termRef(0);
          
          {ESLVal f = $200;
          
          return oldType;
        }
        }
      case "TypeFun": {ESLVal $199 = _v30.termRef(0);
          ESLVal $198 = _v30.termRef(1);
          ESLVal $197 = _v30.termRef(2);
          
          {ESLVal l = $199;
          
          {ESLVal ns = $198;
          
          {ESLVal t = $197;
          
          return new ESLVal("TypeFun",l,ns,substTypeEnv.apply(removeFromDom.apply(env,ns),t));
        }
        }
        }
        }
      case "UnfoldType": {ESLVal $196 = _v30.termRef(0);
          ESLVal $195 = _v30.termRef(1);
          
          {ESLVal l = $196;
          
          {ESLVal t = $195;
          
          return new ESLVal("UnfoldType",l,substTypeEnv.apply(env,t));
        }
        }
        }
      case "UnionType": {ESLVal $194 = _v30.termRef(0);
          ESLVal $193 = _v30.termRef(1);
          
          {ESLVal l = $194;
          
          {ESLVal ts = $193;
          
          return new ESLVal("UnionType",l,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v31 = $qualArg;
                
                {ESLVal t = _v31;
                
                return ESLVal.list(ESLVal.list(substTypeEnv.apply(env,t)));
              }
              }
            }
          }).map(ts).flatten().flatten());
        }
        }
        }
      case "VarType": {ESLVal $192 = _v30.termRef(0);
          ESLVal $191 = _v30.termRef(1);
          
          {ESLVal l = $192;
          
          {ESLVal name = $191;
          
          if(member.apply(name,typeEnvDom.apply(env)).boolVal)
          return lookupType.apply(name,env);
          else
            return oldType;
        }
        }
        }
      case "VoidType": {ESLVal $190 = _v30.termRef(0);
          
          {ESLVal l = $190;
          
          return oldType;
        }
        }
      case "UnionRef": {ESLVal $189 = _v30.termRef(0);
          ESLVal $188 = _v30.termRef(1);
          ESLVal $187 = _v30.termRef(2);
          
          {ESLVal l = $189;
          
          {ESLVal t = $188;
          
          {ESLVal name = $187;
          
          return new ESLVal("UnionRef",l,substTypeEnv.apply(env,t),name);
        }
        }
        }
        }
        default: {ESLVal x = _v30;
          
          return error(oldType);
        }
      }
      }
    }
  });
  public static ESLVal zipTypeEnv = new ESLVal(new Function(new ESLVal("zipTypeEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal ns = $args[0];
  ESLVal ts = $args[1];
  {ESLVal _v29 = ns;
        ESLVal _v28 = ts;
        
        if(_v29.isCons())
        {ESLVal $181 = _v29.head();
          ESLVal $182 = _v29.tail();
          
          if(_v28.isCons())
          {ESLVal $183 = _v28.head();
            ESLVal $184 = _v28.tail();
            
            {ESLVal n = $181;
            
            {ESLVal _v119 = $182;
            
            {ESLVal t = $183;
            
            {ESLVal _v120 = $184;
            
            return zipTypeEnv.apply(_v119,_v120).cons(new ESLVal("Map",n,t));
          }
          }
          }
          }
          }
        else if(_v28.isNil())
          return error(new ESLVal("case error at Pos(28209,28330)").add(ESLVal.list(_v29,_v28)));
        else return error(new ESLVal("case error at Pos(28209,28330)").add(ESLVal.list(_v29,_v28)));
        }
      else if(_v29.isNil())
        if(_v28.isCons())
          {ESLVal $185 = _v28.head();
            ESLVal $186 = _v28.tail();
            
            return error(new ESLVal("case error at Pos(28209,28330)").add(ESLVal.list(_v29,_v28)));
          }
        else if(_v28.isNil())
          return $nil;
        else return error(new ESLVal("case error at Pos(28209,28330)").add(ESLVal.list(_v29,_v28)));
      else return error(new ESLVal("case error at Pos(28209,28330)").add(ESLVal.list(_v29,_v28)));
      }
    }
  });
  public static ESLVal lookupType = new ESLVal(new Function(new ESLVal("lookupType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal name = $args[0];
  ESLVal env = $args[1];
  {ESLVal _v27 = env;
        
        if(_v27.isCons())
        {ESLVal $177 = _v27.head();
          ESLVal $178 = _v27.tail();
          
          switch($177.termName) {
          case "Map": {ESLVal $180 = $177.termRef(0);
            ESLVal $179 = $177.termRef(1);
            
            {ESLVal n = $180;
            
            {ESLVal t = $179;
            
            {ESLVal e = $178;
            
            if(n.eql(name).boolVal)
            return t;
            else
              {ESLVal m = $177;
                
                {ESLVal _v118 = $178;
                
                return lookupType.apply(name,_v118);
              }
              }
          }
          }
          }
          }
          default: {ESLVal m = $177;
            
            {ESLVal e = $178;
            
            return lookupType.apply(name,e);
          }
          }
        }
        }
      else if(_v27.isNil())
        return $null;
      else return error(new ESLVal("case error at Pos(28376,28513)").add(ESLVal.list(_v27)));
      }
    }
  });
  public static ESLVal typeEnvDom = new ESLVal(new Function(new ESLVal("typeEnvDom"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  {ESLVal _v26 = e;
        
        if(_v26.isCons())
        {ESLVal $173 = _v26.head();
          ESLVal $174 = _v26.tail();
          
          switch($173.termName) {
          case "Map": {ESLVal $176 = $173.termRef(0);
            ESLVal $175 = $173.termRef(1);
            
            {ESLVal n = $176;
            
            {ESLVal t = $175;
            
            {ESLVal x = $174;
            
            return typeEnvDom.apply(x).cons(n);
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(28548,28637)").add(ESLVal.list(_v26)));
        }
        }
      else if(_v26.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(28548,28637)").add(ESLVal.list(_v26)));
      }
    }
  });
  public static ESLVal removeFromDom = new ESLVal(new Function(new ESLVal("removeFromDom"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  ESLVal ns = $args[1];
  {ESLVal _v25 = e;
        
        if(_v25.isCons())
        {ESLVal $169 = _v25.head();
          ESLVal $170 = _v25.tail();
          
          switch($169.termName) {
          case "Map": {ESLVal $172 = $169.termRef(0);
            ESLVal $171 = $169.termRef(1);
            
            {ESLVal n = $172;
            
            {ESLVal t = $171;
            
            {ESLVal _v114 = $170;
            
            if(member.apply(n,ns).boolVal)
            return removeFromDom.apply(_v114,ns);
            else
              {ESLVal _v115 = $172;
                
                {ESLVal _v116 = $171;
                
                {ESLVal _v117 = $170;
                
                return removeFromDom.apply(_v117,ns).cons(new ESLVal("Map",_v115,_v116));
              }
              }
              }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(28684,28866)").add(ESLVal.list(_v25)));
        }
        }
      else if(_v25.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(28684,28866)").add(ESLVal.list(_v25)));
      }
    }
  });
  public static ESLVal restrictTypeEnv = new ESLVal(new Function(new ESLVal("restrictTypeEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  ESLVal ns = $args[1];
  {ESLVal _v24 = e;
        
        if(_v24.isCons())
        {ESLVal $165 = _v24.head();
          ESLVal $166 = _v24.tail();
          
          switch($165.termName) {
          case "Map": {ESLVal $168 = $165.termRef(0);
            ESLVal $167 = $165.termRef(1);
            
            {ESLVal n = $168;
            
            {ESLVal t = $167;
            
            {ESLVal _v110 = $166;
            
            if(member.apply(n,ns).not().boolVal)
            return restrictTypeEnv.apply(_v110,ns);
            else
              {ESLVal _v111 = $168;
                
                {ESLVal _v112 = $167;
                
                {ESLVal _v113 = $166;
                
                return restrictTypeEnv.apply(_v113,ns).cons(new ESLVal("Map",_v111,_v112));
              }
              }
              }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(28915,29106)").add(ESLVal.list(_v24)));
        }
        }
      else if(_v24.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(28915,29106)").add(ESLVal.list(_v24)));
      }
    }
  });
  public static ESLVal typeEnvRan = new ESLVal(new Function(new ESLVal("typeEnvRan"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  {ESLVal _v23 = e;
        
        if(_v23.isCons())
        {ESLVal $161 = _v23.head();
          ESLVal $162 = _v23.tail();
          
          switch($161.termName) {
          case "Map": {ESLVal $164 = $161.termRef(0);
            ESLVal $163 = $161.termRef(1);
            
            {ESLVal n = $164;
            
            {ESLVal t = $163;
            
            {ESLVal x = $162;
            
            return typeEnvRan.apply(x).cons(t);
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(29142,29233)").add(ESLVal.list(_v23)));
        }
        }
      else if(_v23.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(29142,29233)").add(ESLVal.list(_v23)));
      }
    }
  });
  public static ESLVal allEqualTypes = new ESLVal(new Function(new ESLVal("allEqualTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t1 = $args[0];
  ESLVal ts = $args[1];
  {ESLVal _v22 = ts;
        
        if(_v22.isCons())
        {ESLVal $159 = _v22.head();
          ESLVal $160 = _v22.tail();
          
          {ESLVal t2 = $159;
          
          {ESLVal _v107 = $160;
          
          if(typeEqual.apply(t1,t2).boolVal)
          return allEqualTypes.apply(t1,_v107);
          else
            {ESLVal _v108 = _v22;
              
              return $false;
            }
        }
        }
        }
      else if(_v22.isNil())
        return $true;
      else {ESLVal _v109 = _v22;
          
          return $false;
        }
      }
    }
  });
  public static ESLVal substDec = new ESLVal(new Function(new ESLVal("substDec"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal newType = $args[0];
  ESLVal n = $args[1];
  ESLVal d = $args[2];
  {ESLVal _v21 = d;
        
        switch(_v21.termName) {
        case "Dec": {ESLVal $158 = _v21.termRef(0);
          ESLVal $157 = _v21.termRef(1);
          ESLVal $156 = _v21.termRef(2);
          ESLVal $155 = _v21.termRef(3);
          
          {ESLVal l = $158;
          
          {ESLVal name = $157;
          
          {ESLVal t = $156;
          
          {ESLVal st = $155;
          
          return new ESLVal("Dec",l,name,substType.apply(newType,n,t),st);
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(29466,29563)").add(ESLVal.list(_v21)));
      }
      }
    }
  });
  public static ESLVal substDecEnv = new ESLVal(new Function(new ESLVal("substDecEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal env = $args[0];
  ESLVal d = $args[1];
  {ESLVal _v20 = d;
        
        switch(_v20.termName) {
        case "Dec": {ESLVal $154 = _v20.termRef(0);
          ESLVal $153 = _v20.termRef(1);
          ESLVal $152 = _v20.termRef(2);
          ESLVal $151 = _v20.termRef(3);
          
          {ESLVal l = $154;
          
          {ESLVal name = $153;
          
          {ESLVal t = $152;
          
          {ESLVal st = $151;
          
          return new ESLVal("Dec",l,name,substTypeEnv.apply(env,t),st);
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(29608,29702)").add(ESLVal.list(_v20)));
      }
      }
    }
  });
  public static ESLVal substMType = new ESLVal(new Function(new ESLVal("substMType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal newType = $args[0];
  ESLVal n = $args[1];
  ESLVal m = $args[2];
  {ESLVal _v18 = m;
        
        switch(_v18.termName) {
        case "MessageType": {ESLVal $150 = _v18.termRef(0);
          ESLVal $149 = _v18.termRef(1);
          
          {ESLVal l = $150;
          
          {ESLVal ts = $149;
          
          return new ESLVal("MessageType",l,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v19 = $qualArg;
                
                {ESLVal t = _v19;
                
                return ESLVal.list(ESLVal.list(substType.apply(newType,n,t)));
              }
              }
            }
          }).map(ts).flatten().flatten());
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(29762,29870)").add(ESLVal.list(_v18)));
      }
      }
    }
  });
  public static ESLVal substMTypeEnv = new ESLVal(new Function(new ESLVal("substMTypeEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal env = $args[0];
  ESLVal m = $args[1];
  {ESLVal _v16 = m;
        
        switch(_v16.termName) {
        case "MessageType": {ESLVal $148 = _v16.termRef(0);
          ESLVal $147 = _v16.termRef(1);
          
          {ESLVal l = $148;
          
          {ESLVal ts = $147;
          
          return new ESLVal("MessageType",l,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v17 = $qualArg;
                
                {ESLVal t = _v17;
                
                return ESLVal.list(ESLVal.list(substTypeEnv.apply(env,t)));
              }
              }
            }
          }).map(ts).flatten().flatten());
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(29922,30027)").add(ESLVal.list(_v16)));
      }
      }
    }
  });
  public static ESLVal patternNames = new ESLVal(new Function(new ESLVal("patternNames"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal x = $args[0];
  {ESLVal _v13 = x;
        
        switch(_v13.termName) {
        case "PAdd": {ESLVal $146 = _v13.termRef(0);
          ESLVal $145 = _v13.termRef(1);
          ESLVal $144 = _v13.termRef(2);
          
          {ESLVal l = $146;
          
          {ESLVal p1 = $145;
          
          {ESLVal p2 = $144;
          
          return patternNames.apply(p1).add(patternNames.apply(p2));
        }
        }
        }
        }
      case "PVar": {ESLVal $143 = _v13.termRef(0);
          ESLVal $142 = _v13.termRef(1);
          ESLVal $141 = _v13.termRef(2);
          
          {ESLVal v0 = $143;
          
          {ESLVal v1 = $142;
          
          {ESLVal v2 = $141;
          
          return ESLVal.list(v1);
        }
        }
        }
        }
      case "PTerm": {ESLVal $140 = _v13.termRef(0);
          ESLVal $139 = _v13.termRef(1);
          ESLVal $138 = _v13.termRef(2);
          ESLVal $137 = _v13.termRef(3);
          
          {ESLVal v0 = $140;
          
          {ESLVal v1 = $139;
          
          {ESLVal v2 = $138;
          
          {ESLVal v3 = $137;
          
          return new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v14 = $qualArg;
                
                {ESLVal p = _v14;
                
                return ESLVal.list(new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal _v106 = $args[0];
                {ESLVal _v15 = _v106;
                      
                      {ESLVal n = _v15;
                      
                      return ESLVal.list(ESLVal.list(n));
                    }
                    }
                  }
                }).map(patternNames.apply(p)).flatten().flatten());
              }
              }
            }
          }).map(v3).flatten().flatten();
        }
        }
        }
        }
        }
      case "PApplyType": {ESLVal $136 = _v13.termRef(0);
          ESLVal $135 = _v13.termRef(1);
          ESLVal $134 = _v13.termRef(2);
          
          {ESLVal v0 = $136;
          
          {ESLVal v1 = $135;
          
          {ESLVal v2 = $134;
          
          return patternNames.apply(v1);
        }
        }
        }
        }
      case "PNil": {ESLVal $133 = _v13.termRef(0);
          
          {ESLVal v0 = $133;
          
          return ESLVal.list();
        }
        }
      case "PNull": {ESLVal $132 = _v13.termRef(0);
          
          {ESLVal v0 = $132;
          
          return ESLVal.list();
        }
        }
      case "PInt": {ESLVal $131 = _v13.termRef(0);
          ESLVal $130 = _v13.termRef(1);
          
          {ESLVal v0 = $131;
          
          {ESLVal v1 = $130;
          
          return ESLVal.list();
        }
        }
        }
      case "PStr": {ESLVal $129 = _v13.termRef(0);
          ESLVal $128 = _v13.termRef(1);
          
          {ESLVal v0 = $129;
          
          {ESLVal v1 = $128;
          
          return ESLVal.list();
        }
        }
        }
      case "PBool": {ESLVal $127 = _v13.termRef(0);
          ESLVal $126 = _v13.termRef(1);
          
          {ESLVal v0 = $127;
          
          {ESLVal v1 = $126;
          
          return ESLVal.list();
        }
        }
        }
      case "PCons": {ESLVal $125 = _v13.termRef(0);
          ESLVal $124 = _v13.termRef(1);
          ESLVal $123 = _v13.termRef(2);
          
          {ESLVal v0 = $125;
          
          {ESLVal v1 = $124;
          
          {ESLVal v2 = $123;
          
          return patternNames.apply(v1).add(patternNames.apply(v2));
        }
        }
        }
        }
      case "PBagCons": {ESLVal $122 = _v13.termRef(0);
          ESLVal $121 = _v13.termRef(1);
          ESLVal $120 = _v13.termRef(2);
          
          {ESLVal v0 = $122;
          
          {ESLVal v1 = $121;
          
          {ESLVal v2 = $120;
          
          return patternNames.apply(v1).add(patternNames.apply(v2));
        }
        }
        }
        }
      case "PEmptyBag": {ESLVal $119 = _v13.termRef(0);
          
          {ESLVal v0 = $119;
          
          return ESLVal.list();
        }
        }
      case "PSetCons": {ESLVal $118 = _v13.termRef(0);
          ESLVal $117 = _v13.termRef(1);
          ESLVal $116 = _v13.termRef(2);
          
          {ESLVal v0 = $118;
          
          {ESLVal v1 = $117;
          
          {ESLVal v2 = $116;
          
          return patternNames.apply(v1).add(patternNames.apply(v2));
        }
        }
        }
        }
      case "PEmptySet": {ESLVal $115 = _v13.termRef(0);
          
          {ESLVal v0 = $115;
          
          return ESLVal.list();
        }
        }
        default: return error(new ESLVal("case error at Pos(30404,31184)").add(ESLVal.list(_v13)));
      }
      }
    }
  });
  public static ESLVal mergeFunDefs = new ESLVal(new Function(new ESLVal("mergeFunDefs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal defs = $args[0];
  LetRec letrec = new LetRec() {
        ESLVal getFunCases = new ESLVal(new Function(new ESLVal("getFunCases"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v99 = $args[0];
          ESLVal _v98 = $args[1];
          {ESLVal _v11 = _v98;
                
                if(_v11.isCons())
                {ESLVal $97 = _v11.head();
                  ESLVal $98 = _v11.tail();
                  
                  switch($97.termName) {
                  case "FunBind": {ESLVal $105 = $97.termRef(0);
                    ESLVal $104 = $97.termRef(1);
                    ESLVal $103 = $97.termRef(2);
                    ESLVal $102 = $97.termRef(3);
                    ESLVal $101 = $97.termRef(4);
                    ESLVal $100 = $97.termRef(5);
                    ESLVal $99 = $97.termRef(6);
                    
                    {ESLVal l = $105;
                    
                    {ESLVal n0 = $104;
                    
                    {ESLVal args = $103;
                    
                    {ESLVal t = $102;
                    
                    {ESLVal dt = $101;
                    
                    {ESLVal e = $100;
                    
                    {ESLVal g = $99;
                    
                    {ESLVal _v100 = $98;
                    
                    if(_v99.eql(n0).boolVal)
                    return getFunCases.apply(_v99,_v100).cons(new ESLVal("FunCase",l,args,t,g,e));
                    else
                      {ESLVal def = $97;
                        
                        {ESLVal _v101 = $98;
                        
                        return getFunCases.apply(_v99,_v101);
                      }
                      }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal def = $97;
                    
                    {ESLVal _v102 = $98;
                    
                    return getFunCases.apply(_v99,_v102);
                  }
                  }
                }
                }
              else if(_v11.isNil())
                return ESLVal.list();
              else return error(new ESLVal("case error at Pos(31563,31740)").add(ESLVal.list(_v11)));
              }
            }
          });
        ESLVal removeFunCases = new ESLVal(new Function(new ESLVal("removeFunCases"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v94 = $args[0];
          ESLVal _v93 = $args[1];
          {ESLVal _v10 = _v93;
                
                if(_v10.isCons())
                {ESLVal $88 = _v10.head();
                  ESLVal $89 = _v10.tail();
                  
                  switch($88.termName) {
                  case "FunBind": {ESLVal $96 = $88.termRef(0);
                    ESLVal $95 = $88.termRef(1);
                    ESLVal $94 = $88.termRef(2);
                    ESLVal $93 = $88.termRef(3);
                    ESLVal $92 = $88.termRef(4);
                    ESLVal $91 = $88.termRef(5);
                    ESLVal $90 = $88.termRef(6);
                    
                    {ESLVal l = $96;
                    
                    {ESLVal n0 = $95;
                    
                    {ESLVal args = $94;
                    
                    {ESLVal t = $93;
                    
                    {ESLVal dt = $92;
                    
                    {ESLVal e = $91;
                    
                    {ESLVal g = $90;
                    
                    {ESLVal _v95 = $89;
                    
                    if(_v94.eql(n0).boolVal)
                    return removeFunCases.apply(_v94,_v95);
                    else
                      {ESLVal def = $88;
                        
                        {ESLVal _v96 = $89;
                        
                        return removeFunCases.apply(_v94,_v96).cons(def);
                      }
                      }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal def = $88;
                    
                    {ESLVal _v97 = $89;
                    
                    return removeFunCases.apply(_v94,_v97).cons(def);
                  }
                  }
                }
                }
              else if(_v10.isNil())
                return ESLVal.list();
              else return error(new ESLVal("case error at Pos(31799,31964)").add(ESLVal.list(_v10)));
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "getFunCases": return getFunCases;
            
            case "removeFunCases": return removeFunCases;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal getFunCases = letrec.get("getFunCases");
      
      ESLVal removeFunCases = letrec.get("removeFunCases");
      
        {ESLVal _v12 = defs;
        
        if(_v12.isCons())
        {ESLVal $106 = _v12.head();
          ESLVal $107 = _v12.tail();
          
          switch($106.termName) {
          case "FunBind": {ESLVal $114 = $106.termRef(0);
            ESLVal $113 = $106.termRef(1);
            ESLVal $112 = $106.termRef(2);
            ESLVal $111 = $106.termRef(3);
            ESLVal $110 = $106.termRef(4);
            ESLVal $109 = $106.termRef(5);
            ESLVal $108 = $106.termRef(6);
            
            {ESLVal l = $114;
            
            {ESLVal n = $113;
            
            {ESLVal args = $112;
            
            {ESLVal t = $111;
            
            {ESLVal dt = $110;
            
            {ESLVal e = $109;
            
            {ESLVal g = $108;
            
            {ESLVal _v103 = $107;
            
            {ESLVal cases = getFunCases.apply(n,_v103);
            
            if(cases.eql(ESLVal.list()).boolVal)
            return mergeFunDefs.apply(_v103).cons(new ESLVal("FunBind",l,n,args,t,dt,e,g));
            else
              {ESLVal _v104 = removeFunCases.apply(n,_v103);
                
                return mergeFunDefs.apply(_v104).cons(new ESLVal("FunBinds",n,cases.cons(new ESLVal("FunCase",l,args,t,g,e))));
              }
          }
          }
          }
          }
          }
          }
          }
          }
          }
          }
          default: {ESLVal def = $106;
            
            {ESLVal _v105 = $107;
            
            return mergeFunDefs.apply(_v105).cons(def);
          }
          }
        }
        }
      else if(_v12.isNil())
        return ESLVal.list();
      else return error(new ESLVal("case error at Pos(31976,32396)").add(ESLVal.list(_v12)));
      }
      
    }
  });
  public static ESLVal expandFunDefs = new ESLVal(new Function(new ESLVal("expandFunDefs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal defs = $args[0];
  {ESLVal _v5 = defs;
        
        if(_v5.isCons())
        {ESLVal $72 = _v5.head();
          ESLVal $73 = _v5.tail();
          
          switch($72.termName) {
          case "FunBinds": {ESLVal $75 = $72.termRef(0);
            ESLVal $74 = $72.termRef(1);
            
            if($74.isCons())
            {ESLVal $76 = $74.head();
              ESLVal $77 = $74.tail();
              
              switch($76.termName) {
              case "FunCase": {ESLVal $82 = $76.termRef(0);
                ESLVal $81 = $76.termRef(1);
                ESLVal $80 = $76.termRef(2);
                ESLVal $79 = $76.termRef(3);
                ESLVal $78 = $76.termRef(4);
                
                {ESLVal n = $75;
                
                {ESLVal l = $82;
                
                {ESLVal args = $81;
                
                {ESLVal t = $80;
                
                {ESLVal g = $79;
                
                {ESLVal e = $78;
                
                {ESLVal cases = $77;
                
                {ESLVal _v81 = $73;
                
                {ESLVal names = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      ESLVal $qualArg = $args[0];
                  {ESLVal _v6 = $qualArg;
                        
                        {ESLVal i = _v6;
                        
                        return ESLVal.list(ESLVal.list(new ESLVal("$").add(i)));
                      }
                      }
                    }
                  }).map($zero.to(length.apply(args))).flatten().flatten();
                
                return expandFunDefs.apply(_v81).cons(new ESLVal("Binding",l,n,t,t,new ESLVal("FunExp",l,new ESLVal("StrExp",l,n),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal $qualArg = $args[0];
                {ESLVal _v7 = $qualArg;
                      
                      {ESLVal _v88 = _v7;
                      
                      return ESLVal.list(ESLVal.list(new ESLVal("Dec",l,_v88,$null,$null)));
                    }
                    }
                  }
                }).map(names).flatten().flatten(),t,new ESLVal("Case",l,ESLVal.list(),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal $qualArg = $args[0];
                {ESLVal _v8 = $qualArg;
                      
                      {ESLVal _v87 = _v8;
                      
                      return ESLVal.list(ESLVal.list(new ESLVal("Var",l,_v87)));
                    }
                    }
                  }
                }).map(names).flatten().flatten(),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal $qualArg = $args[0];
                {ESLVal _v9 = $qualArg;
                      
                      switch(_v9.termName) {
                      case "FunCase": {ESLVal $87 = _v9.termRef(0);
                        ESLVal $86 = _v9.termRef(1);
                        ESLVal $85 = _v9.termRef(2);
                        ESLVal $84 = _v9.termRef(3);
                        ESLVal $83 = _v9.termRef(4);
                        
                        {ESLVal _v82 = $87;
                        
                        {ESLVal _v83 = $86;
                        
                        {ESLVal _v84 = $85;
                        
                        {ESLVal _v85 = $84;
                        
                        {ESLVal _v86 = $83;
                        
                        return ESLVal.list(ESLVal.list(new ESLVal("BArm",_v82,_v83,_v85,_v86)));
                      }
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal _0 = _v9;
                        
                        return ESLVal.list();
                      }
                    }
                    }
                  }
                }).map(cases.cons(new ESLVal("FunCase",l,args,t,g,e))).flatten().flatten()))));
              }
              }
              }
              }
              }
              }
              }
              }
              }
              }
              default: {ESLVal d = $72;
                
                {ESLVal _v89 = $73;
                
                return expandFunDefs.apply(_v89).cons(d);
              }
              }
            }
            }
          else if($74.isNil())
            {ESLVal d = $72;
              
              {ESLVal _v90 = $73;
              
              return expandFunDefs.apply(_v90).cons(d);
            }
            }
          else {ESLVal d = $72;
              
              {ESLVal _v91 = $73;
              
              return expandFunDefs.apply(_v91).cons(d);
            }
            }
          }
          default: {ESLVal d = $72;
            
            {ESLVal _v92 = $73;
            
            return expandFunDefs.apply(_v92).cons(d);
          }
          }
        }
        }
      else if(_v5.isNil())
        return ESLVal.list();
      else return error(new ESLVal("case error at Pos(32444,32900)").add(ESLVal.list(_v5)));
      }
    }
  });
  public static ESLVal isBinding = new ESLVal(new Function(new ESLVal("isBinding"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal b = $args[0];
  {ESLVal _v4 = b;
        
        switch(_v4.termName) {
        case "Binding": {ESLVal $71 = _v4.termRef(0);
          ESLVal $70 = _v4.termRef(1);
          ESLVal $69 = _v4.termRef(2);
          ESLVal $68 = _v4.termRef(3);
          ESLVal $67 = _v4.termRef(4);
          
          {ESLVal l = $71;
          
          {ESLVal n = $70;
          
          {ESLVal t = $69;
          
          {ESLVal st = $68;
          
          {ESLVal e = $67;
          
          return $true;
        }
        }
        }
        }
        }
        }
        default: {ESLVal _v80 = _v4;
          
          return $false;
        }
      }
      }
    }
  });
  public static ESLVal isFunBind = new ESLVal(new Function(new ESLVal("isFunBind"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal b = $args[0];
  {ESLVal _v3 = b;
        
        switch(_v3.termName) {
        case "FunBind": {ESLVal $66 = _v3.termRef(0);
          ESLVal $65 = _v3.termRef(1);
          ESLVal $64 = _v3.termRef(2);
          ESLVal $63 = _v3.termRef(3);
          ESLVal $62 = _v3.termRef(4);
          ESLVal $61 = _v3.termRef(5);
          ESLVal $60 = _v3.termRef(6);
          
          {ESLVal l = $66;
          
          {ESLVal n = $65;
          
          {ESLVal args = $64;
          
          {ESLVal t = $63;
          
          {ESLVal st = $62;
          
          {ESLVal g = $61;
          
          {ESLVal e = $60;
          
          return $true;
        }
        }
        }
        }
        }
        }
        }
        }
        default: {ESLVal _v79 = _v3;
          
          return $false;
        }
      }
      }
    }
  });
  public static ESLVal bindingName = new ESLVal(new Function(new ESLVal("bindingName"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal b = $args[0];
  {ESLVal _v2 = b;
        
        switch(_v2.termName) {
        case "TypeBind": {ESLVal $59 = _v2.termRef(0);
          ESLVal $58 = _v2.termRef(1);
          ESLVal $57 = _v2.termRef(2);
          ESLVal $56 = _v2.termRef(3);
          
          {ESLVal v0 = $59;
          
          {ESLVal v1 = $58;
          
          {ESLVal v2 = $57;
          
          {ESLVal v3 = $56;
          
          return v1;
        }
        }
        }
        }
        }
      case "CnstrBind": {ESLVal $55 = _v2.termRef(0);
          ESLVal $54 = _v2.termRef(1);
          ESLVal $53 = _v2.termRef(2);
          ESLVal $52 = _v2.termRef(3);
          
          {ESLVal v0 = $55;
          
          {ESLVal v1 = $54;
          
          {ESLVal v2 = $53;
          
          {ESLVal v3 = $52;
          
          return v1;
        }
        }
        }
        }
        }
      case "FunBind": {ESLVal $51 = _v2.termRef(0);
          ESLVal $50 = _v2.termRef(1);
          ESLVal $49 = _v2.termRef(2);
          ESLVal $48 = _v2.termRef(3);
          ESLVal $47 = _v2.termRef(4);
          ESLVal $46 = _v2.termRef(5);
          ESLVal $45 = _v2.termRef(6);
          
          {ESLVal v0 = $51;
          
          {ESLVal v1 = $50;
          
          {ESLVal v2 = $49;
          
          {ESLVal v3 = $48;
          
          {ESLVal v4 = $47;
          
          {ESLVal v5 = $46;
          
          {ESLVal v6 = $45;
          
          return v1;
        }
        }
        }
        }
        }
        }
        }
        }
      case "FunBinds": {ESLVal $44 = _v2.termRef(0);
          ESLVal $43 = _v2.termRef(1);
          
          {ESLVal n = $44;
          
          {ESLVal cases = $43;
          
          return n;
        }
        }
        }
      case "Binding": {ESLVal $42 = _v2.termRef(0);
          ESLVal $41 = _v2.termRef(1);
          ESLVal $40 = _v2.termRef(2);
          ESLVal $39 = _v2.termRef(3);
          ESLVal $38 = _v2.termRef(4);
          
          {ESLVal v0 = $42;
          
          {ESLVal v1 = $41;
          
          {ESLVal v2 = $40;
          
          {ESLVal v3 = $39;
          
          {ESLVal v4 = $38;
          
          return v1;
        }
        }
        }
        }
        }
        }
      case "DataBind": {ESLVal $37 = _v2.termRef(0);
          ESLVal $36 = _v2.termRef(1);
          ESLVal $35 = _v2.termRef(2);
          ESLVal $34 = _v2.termRef(3);
          
          {ESLVal v0 = $37;
          
          {ESLVal v1 = $36;
          
          {ESLVal v2 = $35;
          
          {ESLVal v3 = $34;
          
          return v1;
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(33210,33559)").add(ESLVal.list(_v2)));
      }
      }
    }
  });
  public static ESLVal bindingLoc = new ESLVal(new Function(new ESLVal("bindingLoc"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal b = $args[0];
  {ESLVal _v1 = b;
        
        switch(_v1.termName) {
        case "TypeBind": {ESLVal $33 = _v1.termRef(0);
          ESLVal $32 = _v1.termRef(1);
          ESLVal $31 = _v1.termRef(2);
          ESLVal $30 = _v1.termRef(3);
          
          {ESLVal v0 = $33;
          
          {ESLVal v1 = $32;
          
          {ESLVal v2 = $31;
          
          {ESLVal v3 = $30;
          
          return v0;
        }
        }
        }
        }
        }
      case "CnstrBind": {ESLVal $29 = _v1.termRef(0);
          ESLVal $28 = _v1.termRef(1);
          ESLVal $27 = _v1.termRef(2);
          ESLVal $26 = _v1.termRef(3);
          
          {ESLVal v0 = $29;
          
          {ESLVal v1 = $28;
          
          {ESLVal v2 = $27;
          
          {ESLVal v3 = $26;
          
          return v0;
        }
        }
        }
        }
        }
      case "FunBind": {ESLVal $25 = _v1.termRef(0);
          ESLVal $24 = _v1.termRef(1);
          ESLVal $23 = _v1.termRef(2);
          ESLVal $22 = _v1.termRef(3);
          ESLVal $21 = _v1.termRef(4);
          ESLVal $20 = _v1.termRef(5);
          ESLVal $19 = _v1.termRef(6);
          
          {ESLVal v0 = $25;
          
          {ESLVal v1 = $24;
          
          {ESLVal v2 = $23;
          
          {ESLVal v3 = $22;
          
          {ESLVal v4 = $21;
          
          {ESLVal v5 = $20;
          
          {ESLVal v6 = $19;
          
          return v0;
        }
        }
        }
        }
        }
        }
        }
        }
      case "FunBinds": {ESLVal $11 = _v1.termRef(0);
          ESLVal $10 = _v1.termRef(1);
          
          if($10.isCons())
          {ESLVal $12 = $10.head();
            ESLVal $13 = $10.tail();
            
            switch($12.termName) {
            case "FunCase": {ESLVal $18 = $12.termRef(0);
              ESLVal $17 = $12.termRef(1);
              ESLVal $16 = $12.termRef(2);
              ESLVal $15 = $12.termRef(3);
              ESLVal $14 = $12.termRef(4);
              
              {ESLVal n = $11;
              
              {ESLVal l = $18;
              
              {ESLVal args = $17;
              
              {ESLVal t = $16;
              
              {ESLVal g = $15;
              
              {ESLVal e = $14;
              
              {ESLVal cases = $13;
              
              return l;
            }
            }
            }
            }
            }
            }
            }
            }
            default: return error(new ESLVal("case error at Pos(33591,33962)").add(ESLVal.list(_v1)));
          }
          }
        else if($10.isNil())
          return error(new ESLVal("case error at Pos(33591,33962)").add(ESLVal.list(_v1)));
        else return error(new ESLVal("case error at Pos(33591,33962)").add(ESLVal.list(_v1)));
        }
      case "Binding": {ESLVal $9 = _v1.termRef(0);
          ESLVal $8 = _v1.termRef(1);
          ESLVal $7 = _v1.termRef(2);
          ESLVal $6 = _v1.termRef(3);
          ESLVal $5 = _v1.termRef(4);
          
          {ESLVal v0 = $9;
          
          {ESLVal v1 = $8;
          
          {ESLVal v2 = $7;
          
          {ESLVal v3 = $6;
          
          {ESLVal v4 = $5;
          
          return v0;
        }
        }
        }
        }
        }
        }
      case "DataBind": {ESLVal $4 = _v1.termRef(0);
          ESLVal $3 = _v1.termRef(1);
          ESLVal $2 = _v1.termRef(2);
          ESLVal $1 = _v1.termRef(3);
          
          {ESLVal v0 = $4;
          
          {ESLVal v1 = $3;
          
          {ESLVal v2 = $2;
          
          {ESLVal v3 = $1;
          
          return v0;
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(33591,33962)").add(ESLVal.list(_v1)));
      }
      }
    }
  });
public static void main(String[] args) {
  }
}