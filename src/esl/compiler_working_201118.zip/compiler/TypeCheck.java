package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
// import static esl.Lists.*;
import static esl.compiler.Types.*;
import static esl.Tables.*;
import java.util.function.Supplier;
public class TypeCheck {
  public static ESLVal getSelf() { return $null; }
  private static ESLVal ppPattern = new ESLVal(new Function(new ESLVal("ppPattern"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v129 = p;
        
        switch(_v129.termName) {
        case "PAdd": {ESLVal $860 = _v129.termRef(0);
          ESLVal $859 = _v129.termRef(1);
          ESLVal $858 = _v129.termRef(2);
          
          {ESLVal l = $860;
          
          {ESLVal p1 = $859;
          
          {ESLVal p2 = $858;
          
          return ppPattern.apply(p1).add(new ESLVal(" + ").add(ppPattern.apply(p2)));
        }
        }
        }
        }
      case "PVar": {ESLVal $857 = _v129.termRef(0);
          ESLVal $856 = _v129.termRef(1);
          ESLVal $855 = _v129.termRef(2);
          
          {ESLVal l = $857;
          
          {ESLVal n = $856;
          
          {ESLVal t = $855;
          
          return n;
        }
        }
        }
        }
      case "PTerm": {ESLVal $852 = _v129.termRef(0);
          ESLVal $851 = _v129.termRef(1);
          ESLVal $850 = _v129.termRef(2);
          ESLVal $849 = _v129.termRef(3);
          
          if($850.isCons())
          {ESLVal $853 = $850.head();
            ESLVal $854 = $850.tail();
            
            {ESLVal l = $852;
            
            {ESLVal n = $851;
            
            {ESLVal ts = $850;
            
            {ESLVal ps = $849;
            
            return n.add(ppTypes.apply(ts,ESLVal.list()).add(new ESLVal("").add(ppPatterns.apply(ps))));
          }
          }
          }
          }
          }
        else if($850.isNil())
          {ESLVal l = $852;
            
            {ESLVal n = $851;
            
            {ESLVal ps = $849;
            
            return n.add(ppPatterns.apply(ps));
          }
          }
          }
        else {ESLVal l = $852;
            
            {ESLVal n = $851;
            
            {ESLVal ts = $850;
            
            {ESLVal ps = $849;
            
            return n.add(ppTypes.apply(ts,ESLVal.list()).add(new ESLVal("").add(ppPatterns.apply(ps))));
          }
          }
          }
          }
        }
      case "PApplyType": {ESLVal $848 = _v129.termRef(0);
          ESLVal $847 = _v129.termRef(1);
          ESLVal $846 = _v129.termRef(2);
          
          {ESLVal l = $848;
          
          {ESLVal _v1069 = $847;
          
          {ESLVal ts = $846;
          
          return ppPattern.apply(_v1069).add(ppTypes.apply(ts,ESLVal.list()));
        }
        }
        }
        }
      case "PNil": {ESLVal $845 = _v129.termRef(0);
          
          {ESLVal l = $845;
          
          return new ESLVal("[]");
        }
        }
      case "PEmptySet": {ESLVal $844 = _v129.termRef(0);
          
          {ESLVal l = $844;
          
          return new ESLVal("Set{}");
        }
        }
      case "PEmptyBag": {ESLVal $843 = _v129.termRef(0);
          
          {ESLVal l = $843;
          
          return new ESLVal("Bag{}");
        }
        }
      case "PInt": {ESLVal $842 = _v129.termRef(0);
          ESLVal $841 = _v129.termRef(1);
          
          {ESLVal l = $842;
          
          {ESLVal n = $841;
          
          return new ESLVal("").add(n);
        }
        }
        }
      case "PBool": {ESLVal $840 = _v129.termRef(0);
          ESLVal $839 = _v129.termRef(1);
          
          {ESLVal l = $840;
          
          {ESLVal b = $839;
          
          return new ESLVal("").add(b);
        }
        }
        }
      case "PStr": {ESLVal $838 = _v129.termRef(0);
          ESLVal $837 = _v129.termRef(1);
          
          {ESLVal l = $838;
          
          {ESLVal s = $837;
          
          return s;
        }
        }
        }
      case "PCons": {ESLVal $836 = _v129.termRef(0);
          ESLVal $835 = _v129.termRef(1);
          ESLVal $834 = _v129.termRef(2);
          
          {ESLVal l = $836;
          
          {ESLVal h = $835;
          
          {ESLVal t = $834;
          
          return ppPattern.apply(h).add(new ESLVal(":").add(ppPattern.apply(t)));
        }
        }
        }
        }
      case "PSetCons": {ESLVal $833 = _v129.termRef(0);
          ESLVal $832 = _v129.termRef(1);
          ESLVal $831 = _v129.termRef(2);
          
          {ESLVal l = $833;
          
          {ESLVal p1 = $832;
          
          {ESLVal p2 = $831;
          
          return new ESLVal("Set{").add(ppPattern.apply(p1).add(new ESLVal(" | ").add(ppPattern.apply(p2).add(new ESLVal("}")))));
        }
        }
        }
        }
      case "PBagCons": {ESLVal $830 = _v129.termRef(0);
          ESLVal $829 = _v129.termRef(1);
          ESLVal $828 = _v129.termRef(2);
          
          {ESLVal l = $830;
          
          {ESLVal p1 = $829;
          
          {ESLVal p2 = $828;
          
          return new ESLVal("Bag{").add(ppPattern.apply(p1).add(new ESLVal(" | ").add(ppPattern.apply(p2).add(new ESLVal("}")))));
        }
        }
        }
        }
        default: {ESLVal _v1070 = _v129;
          
          return new ESLVal("<unknown: ").add(_v1070.add(new ESLVal(">")));
        }
      }
      }
    }
  });
  private static ESLVal ppPatterns = new ESLVal(new Function(new ESLVal("ppPatterns"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal ps = $args[0];
  return map.apply(ppPattern,ps);
    }
  });
  private static ESLVal p0 = new ESLVal("Pos",$zero,$zero);
  private static ESLVal actType0 = new ESLVal("ActType",p0,ESLVal.list(),ESLVal.list());
  private static ESLVal contentType = new ESLVal("UnionType",p0,ESLVal.list(new ESLVal("TermType",p0,new ESLVal("RawText"),ESLVal.list(new ESLVal("StrType",p0))),new ESLVal("TermType",p0,new ESLVal("ESLSource"),ESLVal.list(new ESLVal("StrType",p0),new ESLVal("StrType",p0))),new ESLVal("TermType",p0,new ESLVal("JavaSource"),ESLVal.list(new ESLVal("StrType",p0),new ESLVal("StrType",p0),new ESLVal("StrType",p0)))));
  private static ESLVal editMessage = new ESLVal("MessageType",p0,ESLVal.list(new ESLVal("TermType",p0,new ESLVal("Edit"),ESLVal.list(contentType))));
  private static ESLVal env0 = ESLVal.list(new ESLVal("Map",new ESLVal("edb"),new ESLVal("ActType",p0,ESLVal.list(new ESLVal("Dec",p0,new ESLVal("button"),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("StrType",p0),new ESLVal("StrType",p0),new ESLVal("StrType",p0),new ESLVal("StrType",p0),new ESLVal("FunType",p0,ESLVal.list(),new ESLVal("VoidType",p0))),new ESLVal("VoidType",p0)),$null),new ESLVal("Dec",p0,new ESLVal("display"),new ESLVal("ForallType",p0,ESLVal.list(new ESLVal("T")),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("StrType",p0),new ESLVal("VarType",p0,new ESLVal("T"))),new ESLVal("VarType",p0,new ESLVal("T")))),$null)),ESLVal.list(editMessage))),new ESLVal("Map",new ESLVal("kill"),new ESLVal("ForallType",p0,ESLVal.list(new ESLVal("T")),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("VarType",p0,new ESLVal("T"))),new ESLVal("VoidType",p0)))),new ESLVal("Map",new ESLVal("print"),new ESLVal("ForallType",p0,ESLVal.list(new ESLVal("T")),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("VarType",p0,new ESLVal("T"))),new ESLVal("VoidType",p0)))),new ESLVal("Map",new ESLVal("parse"),new ESLVal("ForallType",p0,ESLVal.list(new ESLVal("T")),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("StrType",p0)),new ESLVal("VarType",p0,new ESLVal("T"))))),new ESLVal("Map",new ESLVal("random"),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("IntType",p0)),new ESLVal("IntType",p0))),new ESLVal("Map",new ESLVal("wait"),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("IntType",p0)),new ESLVal("VoidType",p0))),new ESLVal("Map",new ESLVal("stopAll"),new ESLVal("FunType",p0,ESLVal.list(),new ESLVal("VoidType",p0))),new ESLVal("Map",new ESLVal("isqrt"),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("IntType",p0)),new ESLVal("FloatType",p0))),new ESLVal("Map",new ESLVal("builtin"),new ESLVal("ForallType",p0,ESLVal.list(new ESLVal("T")),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("StrType",p0),new ESLVal("StrType",p0),new ESLVal("IntType",p0)),new ESLVal("VarType",p0,new ESLVal("T"))))));
  private static ESLVal cnstrEnv0 = ESLVal.list(new ESLVal("Map",new ESLVal("Time"),new ESLVal("UnionType",p0,ESLVal.list(new ESLVal("TermType",p0,new ESLVal("Time"),ESLVal.list(new ESLVal("IntType",p0)))))));
  private static ESLVal tenv0 = ESLVal.list(new ESLVal("Map",new ESLVal("EditType"),contentType),new ESLVal("Map",new ESLVal("Time"),new ESLVal("UnionType",p0,ESLVal.list(new ESLVal("TermType",p0,new ESLVal("Time"),ESLVal.list(new ESLVal("IntType",p0)))))),new ESLVal("Map",new ESLVal("Point"),new ESLVal("UnionType",p0,ESLVal.list(new ESLVal("TermType",p0,new ESLVal("Point"),ESLVal.list(new ESLVal("IntType",p0),new ESLVal("IntType",p0)))))));
  private static ESLVal ppTypeEnv = new ESLVal(new Function(new ESLVal("ppTypeEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal env = $args[0];
  {ESLVal[] s = new ESLVal[]{new ESLVal("[")};
        
        {{
        ESLVal _v127 = env;
        while(_v127.isCons()) {
          ESLVal _v126 = _v127.headVal;
          {ESLVal _v125 = new ESLVal(new Function(new ESLVal("forp"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  {ESLVal _v128 = _v126;
                    
                    switch(_v128.termName) {
                    case "Map": {ESLVal $827 = _v128.termRef(0);
                      ESLVal $826 = _v128.termRef(1);
                      
                      {ESLVal n = $827;
                      
                      {ESLVal t = $826;
                      
                      {s[0] = s[0].add(n.add(new ESLVal("->").add(ppType.apply(t,env).add(new ESLVal(",")))));
                    return $null;}
                    }
                    }
                    }
                    default: {ESLVal $$$ = _v128;
                      
                      return $null;
                    }
                  }
                  }
                }
              });
            
            _v125.apply();
          }
          _v127 = _v127.tailVal;}
      }
      return s[0].add(new ESLVal("]"));}
      }
    }
  });
  private static ESLVal ppTypes = new ESLVal(new Function(new ESLVal("ppTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal ts = $args[0];
  ESLVal env = $args[1];
  return map.apply(ppType0.apply(env),ts);
    }
  });
  private static ESLVal getTypeName = new ESLVal(new Function(new ESLVal("getTypeName"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t0 = $args[0];
  ESLVal env = $args[1];
  {ESLVal[] name = new ESLVal[]{$null};
        
        {{
        ESLVal _v123 = env;
        while(_v123.isCons()) {
          ESLVal _v122 = _v123.headVal;
          {ESLVal _v121 = new ESLVal(new Function(new ESLVal("forp"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  {ESLVal _v124 = _v122;
                    
                    switch(_v124.termName) {
                    case "Map": {ESLVal $825 = _v124.termRef(0);
                      ESLVal $824 = _v124.termRef(1);
                      
                      {ESLVal n = $825;
                      
                      {ESLVal t = $824;
                      
                      if(typeEqual.apply(t0,t).boolVal)
                      {name[0] = n;
                      return $null;}
                      else
                        return $null;
                    }
                    }
                    }
                    default: {ESLVal $$$ = _v124;
                      
                      return $null;
                    }
                  }
                  }
                }
              });
            
            _v121.apply();
          }
          _v123 = _v123.tailVal;}
      }
      return name[0];}
      }
    }
  });
  private static ESLVal ppType0 = new ESLVal(new Function(new ESLVal("ppType0"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal env = $args[0];
  return new ESLVal(new Function(new ESLVal("fun504"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal t = $args[0];
        return ppType.apply(t,env);
          }
        });
    }
  });
  private static ESLVal ppHandlers = new ESLVal(new Function(new ESLVal("ppHandlers"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal handlers = $args[0];
  ESLVal env = $args[1];
  {ESLVal _v120 = handlers;
        
        if(_v120.isCons())
        {ESLVal $818 = _v120.head();
          ESLVal $819 = _v120.tail();
          
          switch($818.termName) {
          case "MessageType": {ESLVal $821 = $818.termRef(0);
            ESLVal $820 = $818.termRef(1);
            
            if($820.isCons())
            {ESLVal $822 = $820.head();
              ESLVal $823 = $820.tail();
              
              {ESLVal l = $821;
              
              {ESLVal t = $822;
              
              {ESLVal ts = $823;
              
              {ESLVal hs = $819;
              
              return ppType.apply(t,env).add(new ESLVal("; ").add(ppHandlers.apply(hs,env)));
            }
            }
            }
            }
            }
          else if($820.isNil())
            return error(new ESLVal("case error at Pos(5351,5485)").add(ESLVal.list(_v120)));
          else return error(new ESLVal("case error at Pos(5351,5485)").add(ESLVal.list(_v120)));
          }
          default: return error(new ESLVal("case error at Pos(5351,5485)").add(ESLVal.list(_v120)));
        }
        }
      else if(_v120.isNil())
        return new ESLVal("");
      else return error(new ESLVal("case error at Pos(5351,5485)").add(ESLVal.list(_v120)));
      }
    }
  });
  private static ESLVal ppDecs = new ESLVal(new Function(new ESLVal("ppDecs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal decs = $args[0];
  ESLVal env = $args[1];
  {ESLVal _v119 = decs;
        
        if(_v119.isCons())
        {ESLVal $812 = _v119.head();
          ESLVal $813 = _v119.tail();
          
          switch($812.termName) {
          case "Dec": {ESLVal $817 = $812.termRef(0);
            ESLVal $816 = $812.termRef(1);
            ESLVal $815 = $812.termRef(2);
            ESLVal $814 = $812.termRef(3);
            
            {ESLVal l = $817;
            
            {ESLVal n = $816;
            
            {ESLVal t = $815;
            
            {ESLVal d = $814;
            
            {ESLVal _v1068 = $813;
            
            return n.add(new ESLVal("::").add(ppType.apply(t,env).add(new ESLVal("; ").add(ppDecs.apply(_v1068,env)))));
          }
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(5526,5640)").add(ESLVal.list(_v119)));
        }
        }
      else if(_v119.isNil())
        return new ESLVal("");
      else return error(new ESLVal("case error at Pos(5526,5640)").add(ESLVal.list(_v119)));
      }
    }
  });
  private static ESLVal ppType = new ESLVal(new Function(new ESLVal("ppType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  ESLVal env = $args[1];
  if(getTypeName.apply(t,env).neql($null).boolVal)
        return getTypeName.apply(t,env);
        else
          {ESLVal _v118 = t;
            
            switch(_v118.termName) {
            case "ActType": {ESLVal $811 = _v118.termRef(0);
              ESLVal $810 = _v118.termRef(1);
              ESLVal $809 = _v118.termRef(2);
              
              {ESLVal l = $811;
              
              {ESLVal decs = $810;
              
              {ESLVal handlers = $809;
              
              return new ESLVal("Act { ").add(ppHandlers.apply(handlers,env).add(new ESLVal(" }")));
            }
            }
            }
            }
          case "ApplyType": {ESLVal $808 = _v118.termRef(0);
              ESLVal $807 = _v118.termRef(1);
              ESLVal $806 = _v118.termRef(2);
              
              {ESLVal l = $808;
              
              {ESLVal n = $807;
              
              {ESLVal args = $806;
              
              return n.add(map.apply(ppType0.apply(env),args));
            }
            }
            }
            }
          case "ApplyTypeFun": {ESLVal $805 = _v118.termRef(0);
              ESLVal $804 = _v118.termRef(1);
              ESLVal $803 = _v118.termRef(2);
              
              {ESLVal l = $805;
              
              {ESLVal op = $804;
              
              {ESLVal args = $803;
              
              return ppType.apply(op,env).add(map.apply(ppType0.apply(env),args));
            }
            }
            }
            }
          case "ArrayType": {ESLVal $802 = _v118.termRef(0);
              ESLVal $801 = _v118.termRef(1);
              
              {ESLVal l = $802;
              
              {ESLVal _v1067 = $801;
              
              return new ESLVal("Array[").add(ppType.apply(_v1067,env).add(new ESLVal("]")));
            }
            }
            }
          case "BagType": {ESLVal $800 = _v118.termRef(0);
              ESLVal $799 = _v118.termRef(1);
              
              {ESLVal l = $800;
              
              {ESLVal _v1066 = $799;
              
              return new ESLVal("Set{").add(ppType.apply(_v1066,env).add(new ESLVal("}")));
            }
            }
            }
          case "BoolType": {ESLVal $798 = _v118.termRef(0);
              
              {ESLVal l = $798;
              
              return new ESLVal("Bool");
            }
            }
          case "ExtendedAct": {ESLVal $797 = _v118.termRef(0);
              ESLVal $796 = _v118.termRef(1);
              ESLVal $795 = _v118.termRef(2);
              ESLVal $794 = _v118.termRef(3);
              
              {ESLVal l = $797;
              
              {ESLVal parent = $796;
              
              {ESLVal decs = $795;
              
              {ESLVal handlers = $794;
              
              return new ESLVal("Act extends ").add(ppType.apply(parent,env).add(new ESLVal(" { ").add(ppHandlers.apply(handlers,env).add(new ESLVal(" }")))));
            }
            }
            }
            }
            }
          case "FloatType": {ESLVal $793 = _v118.termRef(0);
              
              {ESLVal l = $793;
              
              return new ESLVal("Float");
            }
            }
          case "FieldType": {ESLVal $792 = _v118.termRef(0);
              ESLVal $791 = _v118.termRef(1);
              ESLVal $790 = _v118.termRef(2);
              
              {ESLVal l = $792;
              
              {ESLVal n = $791;
              
              {ESLVal _v1065 = $790;
              
              return n.add(new ESLVal("::").add(ppType.apply(_v1065,env)));
            }
            }
            }
            }
          case "ForallType": {ESLVal $789 = _v118.termRef(0);
              ESLVal $788 = _v118.termRef(1);
              ESLVal $787 = _v118.termRef(2);
              
              {ESLVal l = $789;
              
              {ESLVal ns = $788;
              
              {ESLVal _v1064 = $787;
              
              return new ESLVal("Forall").add(ns.add(new ESLVal(".").add(ppType.apply(_v1064,env))));
            }
            }
            }
            }
          case "FunType": {ESLVal $786 = _v118.termRef(0);
              ESLVal $785 = _v118.termRef(1);
              ESLVal $784 = _v118.termRef(2);
              
              {ESLVal l = $786;
              
              {ESLVal d = $785;
              
              {ESLVal r = $784;
              
              return map.apply(ppType0.apply(env),d).add(new ESLVal("->").add(ppType.apply(r,env)));
            }
            }
            }
            }
          case "TaggedFunType": {ESLVal $783 = _v118.termRef(0);
              ESLVal $782 = _v118.termRef(1);
              ESLVal $781 = _v118.termRef(2);
              ESLVal $780 = _v118.termRef(3);
              
              {ESLVal l = $783;
              
              {ESLVal d = $782;
              
              {ESLVal p = $781;
              
              {ESLVal r = $780;
              
              return map.apply(ppType0.apply(env),d).add(new ESLVal("->").add(ppType.apply(r,env)));
            }
            }
            }
            }
            }
          case "IntType": {ESLVal $779 = _v118.termRef(0);
              
              {ESLVal l = $779;
              
              return new ESLVal("Int");
            }
            }
          case "ListType": {ESLVal $778 = _v118.termRef(0);
              ESLVal $777 = _v118.termRef(1);
              
              {ESLVal l = $778;
              
              {ESLVal _v1063 = $777;
              
              return new ESLVal("[").add(ppType.apply(_v1063,env).add(new ESLVal("]")));
            }
            }
            }
          case "NullType": {ESLVal $776 = _v118.termRef(0);
              
              {ESLVal l = $776;
              
              return new ESLVal("Null");
            }
            }
          case "RecType": {ESLVal $775 = _v118.termRef(0);
              ESLVal $774 = _v118.termRef(1);
              ESLVal $773 = _v118.termRef(2);
              
              {ESLVal l = $775;
              
              {ESLVal n = $774;
              
              {ESLVal _v1062 = $773;
              
              return new ESLVal("rec ").add(n.add(new ESLVal(".").add(ppType.apply(_v1062,env))));
            }
            }
            }
            }
          case "RecordType": {ESLVal $772 = _v118.termRef(0);
              ESLVal $771 = _v118.termRef(1);
              
              {ESLVal l = $772;
              
              {ESLVal fs = $771;
              
              return new ESLVal("{").add(ppDecs.apply(fs,env).add(new ESLVal("}")));
            }
            }
            }
          case "SetType": {ESLVal $770 = _v118.termRef(0);
              ESLVal $769 = _v118.termRef(1);
              
              {ESLVal l = $770;
              
              {ESLVal _v1061 = $769;
              
              return new ESLVal("Set{").add(ppType.apply(_v1061,env).add(new ESLVal("}")));
            }
            }
            }
          case "StrType": {ESLVal $768 = _v118.termRef(0);
              
              {ESLVal l = $768;
              
              return new ESLVal("Str");
            }
            }
          case "TableType": {ESLVal $767 = _v118.termRef(0);
              ESLVal $766 = _v118.termRef(1);
              ESLVal $765 = _v118.termRef(2);
              
              {ESLVal l = $767;
              
              {ESLVal k = $766;
              
              {ESLVal v = $765;
              
              return new ESLVal("Hash[").add(ppType.apply(k,env).add(new ESLVal(",").add(ppType.apply(v,env).add(new ESLVal("]")))));
            }
            }
            }
            }
          case "TermType": {ESLVal $764 = _v118.termRef(0);
              ESLVal $763 = _v118.termRef(1);
              ESLVal $762 = _v118.termRef(2);
              
              {ESLVal l = $764;
              
              {ESLVal n = $763;
              
              {ESLVal ts = $762;
              
              return n.add(map.apply(ppType0.apply(env),ts));
            }
            }
            }
            }
          case "TypeFun": {ESLVal $761 = _v118.termRef(0);
              ESLVal $760 = _v118.termRef(1);
              ESLVal $759 = _v118.termRef(2);
              
              {ESLVal l = $761;
              
              {ESLVal ns = $760;
              
              {ESLVal _v1060 = $759;
              
              return new ESLVal("Fun").add(ns.add(new ESLVal(".").add(ppType.apply(_v1060,env))));
            }
            }
            }
            }
          case "UnfoldType": {ESLVal $758 = _v118.termRef(0);
              ESLVal $757 = _v118.termRef(1);
              
              {ESLVal l = $758;
              
              {ESLVal _v1059 = $757;
              
              return new ESLVal("unfold ").add(ppType.apply(_v1059,env));
            }
            }
            }
          case "UnionType": {ESLVal $756 = _v118.termRef(0);
              ESLVal $755 = _v118.termRef(1);
              
              {ESLVal l = $756;
              
              {ESLVal ts = $755;
              
              return new ESLVal("union ").add(map.apply(ppType0.apply(env),ts));
            }
            }
            }
          case "VarType": {ESLVal $754 = _v118.termRef(0);
              ESLVal $753 = _v118.termRef(1);
              
              {ESLVal l = $754;
              
              {ESLVal n = $753;
              
              return n;
            }
            }
            }
          case "VoidType": {ESLVal $752 = _v118.termRef(0);
              
              {ESLVal l = $752;
              
              return new ESLVal("Void");
            }
            }
          case "UnionRef": {ESLVal $751 = _v118.termRef(0);
              ESLVal $750 = _v118.termRef(1);
              ESLVal $749 = _v118.termRef(2);
              
              {ESLVal l = $751;
              
              {ESLVal _v1058 = $750;
              
              {ESLVal n = $749;
              
              return ppType.apply(_v1058,env).add(new ESLVal(".").add(n));
            }
            }
            }
            }
          case "TypeClosure": {ESLVal $748 = _v118.termRef(0);
              
              {ESLVal f = $748;
              
              return f.add(new ESLVal(""));
            }
            }
            default: {ESLVal x = _v118;
              
              return new ESLVal("<unknown ").add(x.add(new ESLVal(">")));
            }
          }
          }
    }
  });
  private static ESLVal typeEnv = new ESLVal(new Function(new ESLVal("typeEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal defs = $args[0];
  {ESLVal _v117 = defs;
        
        if(_v117.isCons())
        {ESLVal $738 = _v117.head();
          ESLVal $739 = _v117.tail();
          
          switch($738.termName) {
          case "TypeBind": {ESLVal $747 = $738.termRef(0);
            ESLVal $746 = $738.termRef(1);
            ESLVal $745 = $738.termRef(2);
            ESLVal $744 = $738.termRef(3);
            
            {ESLVal l = $747;
            
            {ESLVal n = $746;
            
            {ESLVal t = $745;
            
            {ESLVal e = $744;
            
            {ESLVal ds = $739;
            
            return typeEnv.apply(ds).cons(new ESLVal("Map",n,t));
          }
          }
          }
          }
          }
          }
        case "DataBind": {ESLVal $743 = $738.termRef(0);
            ESLVal $742 = $738.termRef(1);
            ESLVal $741 = $738.termRef(2);
            ESLVal $740 = $738.termRef(3);
            
            {ESLVal l = $743;
            
            {ESLVal n = $742;
            
            {ESLVal t = $741;
            
            {ESLVal e = $740;
            
            {ESLVal ds = $739;
            
            return typeEnv.apply(ds).cons(new ESLVal("Map",n,t));
          }
          }
          }
          }
          }
          }
          default: {ESLVal b = $738;
            
            {ESLVal ds = $739;
            
            return typeEnv.apply(ds);
          }
          }
        }
        }
      else if(_v117.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(7713,7956)").add(ESLVal.list(_v117)));
      }
    }
  });
  private static ESLVal cnstrEnv = new ESLVal(new Function(new ESLVal("cnstrEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal defs = $args[0];
  ESLVal env = $args[1];
  {ESLVal _v116 = defs;
        
        if(_v116.isCons())
        {ESLVal $721 = _v116.head();
          ESLVal $722 = _v116.tail();
          
          switch($721.termName) {
          case "TypeBind": {ESLVal $730 = $721.termRef(0);
            ESLVal $729 = $721.termRef(1);
            ESLVal $728 = $721.termRef(2);
            ESLVal $727 = $721.termRef(3);
            
            switch($728.termName) {
            case "RecType": {ESLVal $735 = $728.termRef(0);
              ESLVal $734 = $728.termRef(1);
              ESLVal $733 = $728.termRef(2);
              
              switch($733.termName) {
              case "UnionType": {ESLVal $737 = $733.termRef(0);
                ESLVal $736 = $733.termRef(1);
                
                {ESLVal l = $730;
                
                {ESLVal n = $729;
                
                {ESLVal ll = $735;
                
                {ESLVal m = $734;
                
                {ESLVal lll = $737;
                
                {ESLVal ts = $736;
                
                {ESLVal e = $727;
                
                {ESLVal ds = $722;
                
                return getConstructors.apply(l,lookupType.apply(n,env),lookupType.apply(n,env)).add(cnstrEnv.apply(ds,env));
              }
              }
              }
              }
              }
              }
              }
              }
              }
              default: {ESLVal l = $730;
                
                {ESLVal n = $729;
                
                {ESLVal t = $728;
                
                {ESLVal e = $727;
                
                {ESLVal ds = $722;
                
                return cnstrEnv.apply(ds,env);
              }
              }
              }
              }
              }
            }
            }
          case "UnionType": {ESLVal $732 = $728.termRef(0);
              ESLVal $731 = $728.termRef(1);
              
              {ESLVal l = $730;
              
              {ESLVal n = $729;
              
              {ESLVal lll = $732;
              
              {ESLVal ts = $731;
              
              {ESLVal e = $727;
              
              {ESLVal ds = $722;
              
              return getConstructors.apply(l,lookupType.apply(n,env),lookupType.apply(n,env)).add(cnstrEnv.apply(ds,env));
            }
            }
            }
            }
            }
            }
            }
            default: {ESLVal l = $730;
              
              {ESLVal n = $729;
              
              {ESLVal t = $728;
              
              {ESLVal e = $727;
              
              {ESLVal ds = $722;
              
              return cnstrEnv.apply(ds,env);
            }
            }
            }
            }
            }
          }
          }
        case "DataBind": {ESLVal $726 = $721.termRef(0);
            ESLVal $725 = $721.termRef(1);
            ESLVal $724 = $721.termRef(2);
            ESLVal $723 = $721.termRef(3);
            
            {ESLVal l = $726;
            
            {ESLVal n = $725;
            
            {ESLVal t = $724;
            
            {ESLVal e = $723;
            
            {ESLVal ds = $722;
            
            return getConstructors.apply(l,lookupType.apply(n,env),lookupType.apply(n,env)).add(cnstrEnv.apply(ds,env));
          }
          }
          }
          }
          }
          }
          default: {ESLVal b = $721;
            
            {ESLVal ds = $722;
            
            return cnstrEnv.apply(ds,env);
          }
          }
        }
        }
      else if(_v116.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(8088,8721)").add(ESLVal.list(_v116)));
      }
    }
  });
  private static ESLVal getConstructors = new ESLVal(new Function(new ESLVal("getConstructors"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal dataType = $args[1];
  ESLVal t = $args[2];
  {ESLVal _v114 = t;
        
        switch(_v114.termName) {
        case "RecType": {ESLVal $717 = _v114.termRef(0);
          ESLVal $716 = _v114.termRef(1);
          ESLVal $715 = _v114.termRef(2);
          
          {ESLVal _v1055 = $717;
          
          {ESLVal n = $716;
          
          {ESLVal _v1056 = $715;
          
          return getConstructors.apply(_v1055,dataType,_v1056);
        }
        }
        }
        }
      case "TypeFun": {ESLVal $714 = _v114.termRef(0);
          ESLVal $713 = _v114.termRef(1);
          ESLVal $712 = _v114.termRef(2);
          
          {ESLVal _v1053 = $714;
          
          {ESLVal ns = $713;
          
          {ESLVal _v1054 = $712;
          
          return getConstructors.apply(_v1053,dataType,_v1054);
        }
        }
        }
        }
      case "UnionType": {ESLVal $711 = _v114.termRef(0);
          ESLVal $710 = _v114.termRef(1);
          
          {ESLVal _v1050 = $711;
          
          {ESLVal ts = $710;
          
          return map.apply(new ESLVal(new Function(new ESLVal("fun505"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1051 = $args[0];
          {ESLVal _v115 = _v1051;
                
                switch(_v115.termName) {
                case "TermType": {ESLVal $720 = _v115.termRef(0);
                  ESLVal $719 = _v115.termRef(1);
                  ESLVal $718 = _v115.termRef(2);
                  
                  {ESLVal _v1052 = $720;
                  
                  {ESLVal n = $719;
                  
                  {ESLVal tts = $718;
                  
                  return new ESLVal("Map",n,dataType);
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(9240,9306)").add(ESLVal.list(_v115)));
              }
              }
            }
          }),ts);
        }
        }
        }
        default: {ESLVal _v1057 = _v114;
          
          return error(new ESLVal("TypeError",l,new ESLVal("cannot extract constructors from ").add(ppType.apply(_v1057,ESLVal.list()))));
        }
      }
      }
    }
  });
  private static ESLVal checkFreeTypes = new ESLVal(new Function(new ESLVal("checkFreeTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  {ESLVal dom = typeEnvDom.apply(e);
        ESLVal ran = typeEnvRan.apply(e);
        
        {ESLVal freeNames = removeAll.apply(dom,flatten.apply(map.apply(typeFV,ran)));
        
        if(freeNames.eql($nil).boolVal)
        return $null;
        else
          return error(new ESLVal("TypeError",new ESLVal("Pos",$zero,$zero),new ESLVal("Unbound Types: ").add(freeNames)));
      }
      }
    }
  });
  private static ESLVal checkSingletonTypes = new ESLVal(new Function(new ESLVal("checkSingletonTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  {ESLVal _v113 = e;
        
        if(_v113.isCons())
        {ESLVal $706 = _v113.head();
          ESLVal $707 = _v113.tail();
          
          switch($706.termName) {
          case "Map": {ESLVal $709 = $706.termRef(0);
            ESLVal $708 = $706.termRef(1);
            
            {ESLVal n = $709;
            
            {ESLVal t = $708;
            
            {ESLVal _v1049 = $707;
            
            if(member.apply(n,typeEnvDom.apply(_v1049)).boolVal)
            return error(new ESLVal("TypeError",new ESLVal("Pos",$zero,$zero),new ESLVal("Duplicate type name: ").add(n)));
            else
              return checkSingletonTypes.apply(_v1049);
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(10010,10231)").add(ESLVal.list(_v113)));
        }
        }
      else if(_v113.isNil())
        return $null;
      else return error(new ESLVal("case error at Pos(10010,10231)").add(ESLVal.list(_v113)));
      }
    }
  });
  private static ESLVal checkSingletonConstructors = new ESLVal(new Function(new ESLVal("checkSingletonConstructors"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  {ESLVal _v112 = e;
        
        if(_v112.isCons())
        {ESLVal $702 = _v112.head();
          ESLVal $703 = _v112.tail();
          
          switch($702.termName) {
          case "Map": {ESLVal $705 = $702.termRef(0);
            ESLVal $704 = $702.termRef(1);
            
            {ESLVal n = $705;
            
            {ESLVal t = $704;
            
            {ESLVal _v1048 = $703;
            
            if(member.apply(n,typeEnvDom.apply(_v1048)).boolVal)
            return error(new ESLVal("Duplicate constructor name: ").add(n));
            else
              return checkSingletonConstructors.apply(_v1048);
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(10337,10552)").add(ESLVal.list(_v112)));
        }
        }
      else if(_v112.isNil())
        return $null;
      else return error(new ESLVal("case error at Pos(10337,10552)").add(ESLVal.list(_v112)));
      }
    }
  });
  private static ESLVal valueDefs = new ESLVal(new Function(new ESLVal("valueDefs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal defs = $args[0];
  {ESLVal _v111 = defs;
        
        if(_v111.isCons())
        {ESLVal $688 = _v111.head();
          ESLVal $689 = _v111.tail();
          
          switch($688.termName) {
          case "TypeBind": {ESLVal $701 = $688.termRef(0);
            ESLVal $700 = $688.termRef(1);
            ESLVal $699 = $688.termRef(2);
            ESLVal $698 = $688.termRef(3);
            
            {ESLVal l = $701;
            
            {ESLVal n = $700;
            
            {ESLVal t = $699;
            
            {ESLVal e = $698;
            
            {ESLVal ds = $689;
            
            return valueDefs.apply(ds);
          }
          }
          }
          }
          }
          }
        case "DataBind": {ESLVal $697 = $688.termRef(0);
            ESLVal $696 = $688.termRef(1);
            ESLVal $695 = $688.termRef(2);
            ESLVal $694 = $688.termRef(3);
            
            {ESLVal l1 = $697;
            
            {ESLVal n = $696;
            
            {ESLVal t = $695;
            
            {ESLVal e = $694;
            
            {ESLVal ds = $689;
            
            return valueDefs.apply(ds);
          }
          }
          }
          }
          }
          }
        case "CnstrBind": {ESLVal $693 = $688.termRef(0);
            ESLVal $692 = $688.termRef(1);
            ESLVal $691 = $688.termRef(2);
            ESLVal $690 = $688.termRef(3);
            
            {ESLVal l1 = $693;
            
            {ESLVal n = $692;
            
            {ESLVal t = $691;
            
            {ESLVal e = $690;
            
            {ESLVal ds = $689;
            
            return valueDefs.apply(ds);
          }
          }
          }
          }
          }
          }
          default: {ESLVal b = $688;
            
            {ESLVal ds = $689;
            
            return valueDefs.apply(ds).cons(b);
          }
          }
        }
        }
      else if(_v111.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(10593,10903)").add(ESLVal.list(_v111)));
      }
    }
  });
  private static ESLVal valueDefsToTEnv = new ESLVal(new Function(new ESLVal("valueDefsToTEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1047 = $args[0];
  ESLVal _v1046 = $args[1];
  ESLVal _v1045 = $args[2];
  ESLVal _v1044 = $args[3];
  ESLVal _v1043 = $args[4];
  {ESLVal _v110 = _v1047;
        
        if(_v110.isCons())
        {ESLVal $665 = _v110.head();
          ESLVal $666 = _v110.tail();
          
          switch($665.termName) {
          case "FunBinds": {ESLVal $680 = $665.termRef(0);
            ESLVal $679 = $665.termRef(1);
            
            if($679.isCons())
            {ESLVal $681 = $679.head();
              ESLVal $682 = $679.tail();
              
              switch($681.termName) {
              case "FunCase": {ESLVal $687 = $681.termRef(0);
                ESLVal $686 = $681.termRef(1);
                ESLVal $685 = $681.termRef(2);
                ESLVal $684 = $681.termRef(3);
                ESLVal $683 = $681.termRef(4);
                
                {ESLVal n = $680;
                
                {ESLVal l = $687;
                
                {ESLVal args = $686;
                
                {ESLVal t = $685;
                
                {ESLVal g = $684;
                
                {ESLVal e = $683;
                
                {ESLVal cases = $682;
                
                {ESLVal ds = $666;
                
                return valueDefsToTEnv.apply(ds,_v1046,_v1045,_v1044,_v1043).cons(new ESLVal("Map",n,substTypeEnv.apply(_v1043,t)));
              }
              }
              }
              }
              }
              }
              }
              }
              }
              default: return error(new ESLVal("case error at Pos(11010,11543)").add(ESLVal.list(_v110)));
            }
            }
          else if($679.isNil())
            return error(new ESLVal("case error at Pos(11010,11543)").add(ESLVal.list(_v110)));
          else return error(new ESLVal("case error at Pos(11010,11543)").add(ESLVal.list(_v110)));
          }
        case "FunBind": {ESLVal $678 = $665.termRef(0);
            ESLVal $677 = $665.termRef(1);
            ESLVal $676 = $665.termRef(2);
            ESLVal $675 = $665.termRef(3);
            ESLVal $674 = $665.termRef(4);
            ESLVal $673 = $665.termRef(5);
            ESLVal $672 = $665.termRef(6);
            
            {ESLVal l = $678;
            
            {ESLVal n = $677;
            
            {ESLVal ps = $676;
            
            {ESLVal t = $675;
            
            {ESLVal st = $674;
            
            {ESLVal b = $673;
            
            {ESLVal g = $672;
            
            {ESLVal ds = $666;
            
            return valueDefsToTEnv.apply(ds,_v1046,_v1045,_v1044,_v1043).cons(new ESLVal("Map",n,substTypeEnv.apply(_v1043,t)));
          }
          }
          }
          }
          }
          }
          }
          }
          }
        case "Binding": {ESLVal $671 = $665.termRef(0);
            ESLVal $670 = $665.termRef(1);
            ESLVal $669 = $665.termRef(2);
            ESLVal $668 = $665.termRef(3);
            ESLVal $667 = $665.termRef(4);
            
            {ESLVal l = $671;
            
            {ESLVal n = $670;
            
            {ESLVal t = $669;
            
            {ESLVal st = $668;
            
            {ESLVal e = $667;
            
            {ESLVal ds = $666;
            
            return valueDefsToTEnv.apply(ds,_v1046,_v1045,_v1044,_v1043).cons(new ESLVal("Map",n,substTypeEnv.apply(_v1043,t)));
          }
          }
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(11010,11543)").add(ESLVal.list(_v110)));
        }
        }
      else if(_v110.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(11010,11543)").add(ESLVal.list(_v110)));
      }
    }
  });
  public static ESLVal typeCheckModule = new ESLVal(new Function(new ESLVal("typeCheckModule"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal path = $args[0];
  {print.apply(new ESLVal("[ type check ").add(path.add(new ESLVal("]"))));
      return typeCheckModuleInternal.apply(path,emptyTable,new ESLVal(new Function(new ESLVal("fun506"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1042 = $args[0];
        ESLVal _v1041 = $args[1];
        ESLVal _v1040 = $args[2];
        ESLVal _v1039 = $args[3];
        return $null;
          }
        }));}
    }
  });
  private static ESLVal typeCheckModuleInternal = new ESLVal(new Function(new ESLVal("typeCheckModuleInternal"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal path = $args[0];
  ESLVal cache = $args[1];
  ESLVal handler = $args[2];
  if(hasEntry.apply(path,cache).boolVal)
        {ESLVal _v109 = lookup.apply(path,cache);
          
          switch(_v109.termName) {
          case "Typed": {ESLVal $664 = _v109.termRef(0);
            ESLVal $663 = _v109.termRef(1);
            ESLVal $662 = _v109.termRef(2);
            ESLVal $661 = _v109.termRef(3);
            
            {ESLVal m = $664;
            
            {ESLVal vEnv = $663;
            
            {ESLVal cEnv = $662;
            
            {ESLVal tEnv = $661;
            
            return handler.apply(cache,vEnv,cEnv,tEnv);
          }
          }
          }
          }
          }
        case "Undefined": {
            return error(new ESLVal("recursive reference to ").add(path));
          }
          default: return error(new ESLVal("case error at Pos(12012,12246)").add(ESLVal.list(_v109)));
        }
        }
        else
          {ESLVal m = parse.apply(path);
            
            return typeCheckModuleCache.apply(m,addEntry.apply(path,new ESLVal("Undefined",new ESLVal[]{}),cache),new ESLVal(new Function(new ESLVal("fun507"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v1038 = $args[0];
            ESLVal _v1037 = $args[1];
            ESLVal _v1036 = $args[2];
            ESLVal _v1035 = $args[3];
            return handler.apply(addEntry.apply(path,new ESLVal("Typed",m,_v1037,_v1036,_v1035),_v1038),_v1037,_v1036,_v1035);
              }
            }));
          }
    }
  });
  public static ESLVal typeCheckEntryPoint = new ESLVal(new Function(new ESLVal("typeCheckEntryPoint"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal module = $args[0];
  return typeCheckModuleCache.apply(module,emptyTable,new ESLVal(new Function(new ESLVal("fun508"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1034 = $args[0];
        ESLVal _v1033 = $args[1];
        ESLVal _v1032 = $args[2];
        ESLVal _v1031 = $args[3];
        return $null;
          }
        }));
    }
  });
  private static ESLVal typeCheckModuleCache = new ESLVal(new Function(new ESLVal("typeCheckModuleCache"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal module = $args[0];
  ESLVal cache = $args[1];
  ESLVal handler = $args[2];
  return typeCheckModule0.apply(module,cache,new ESLVal(new Function(new ESLVal("fun509"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1030 = $args[0];
        ESLVal _v1029 = $args[1];
        ESLVal _v1028 = $args[2];
        ESLVal _v1027 = $args[3];
        {ESLVal _v108 = module;
              
              switch(_v108.termName) {
              case "Module": {ESLVal $660 = _v108.termRef(0);
                ESLVal $659 = _v108.termRef(1);
                ESLVal $658 = _v108.termRef(2);
                ESLVal $657 = _v108.termRef(3);
                ESLVal $656 = _v108.termRef(4);
                ESLVal $655 = _v108.termRef(5);
                ESLVal $654 = _v108.termRef(6);
                
                {ESLVal path = $660;
                
                {ESLVal name = $659;
                
                {ESLVal exports = $658;
                
                {ESLVal imports = $657;
                
                {ESLVal x = $656;
                
                {ESLVal y = $655;
                
                {ESLVal defs = $654;
                
                return handler.apply(_v1030,restrictTypeEnv.apply(_v1029,exports),restrictTypeEnv.apply(_v1028,exports),restrictTypeEnv.apply(_v1027,exports));
              }
              }
              }
              }
              }
              }
              }
              }
              default: return error(new ESLVal("case error at Pos(12988,13246)").add(ESLVal.list(_v108)));
            }
            }
          }
        }));
    }
  });
  private static ESLVal typeCheckModule0 = new ESLVal(new Function(new ESLVal("typeCheckModule0"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal module = $args[0];
  ESLVal cache = $args[1];
  ESLVal handler = $args[2];
  LetRec letrec = new LetRec() {
        ESLVal _v1005 = new ESLVal(new Function(new ESLVal("processImports"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1016 = $args[0];
          ESLVal _v1015 = $args[1];
          ESLVal _v1014 = $args[2];
          {ESLVal _v107 = _v1016;
                
                if(_v107.isCons())
                {ESLVal $652 = _v107.head();
                  ESLVal $653 = _v107.tail();
                  
                  {ESLVal path = $652;
                  
                  {ESLVal _v1017 = $653;
                  
                  {ESLVal _v1018 = _v1017;
                  
                  return typeCheckModuleInternal.apply(path,_v1015,new ESLVal(new Function(new ESLVal("fun510"),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      ESLVal _v1022 = $args[0];
                  ESLVal _v1021 = $args[1];
                  ESLVal _v1020 = $args[2];
                  ESLVal _v1019 = $args[3];
                  return _v1005.apply(_v1018,_v1022,new ESLVal(new Function(new ESLVal("fun511"),getSelf()) {
                          public ESLVal apply(ESLVal... $args) {
                            ESLVal _v1026 = $args[0];
                        ESLVal _v1025 = $args[1];
                        ESLVal _v1024 = $args[2];
                        ESLVal _v1023 = $args[3];
                        return _v1014.apply(_v1026,_v1025.add(_v1021),_v1024.add(_v1020),_v1023.add(_v1019));
                          }
                        }));
                    }
                  }));
                }
                }
                }
                }
              else if(_v107.isNil())
                return _v1014.apply(_v1015,$nil,$nil,$nil);
              else return error(new ESLVal("case error at Pos(13626,14183)").add(ESLVal.list(_v107)));
              }
            }
          });
        ESLVal _v1004 = new ESLVal(new Function(new ESLVal("main"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              {ESLVal _v106 = module;
                
                switch(_v106.termName) {
                case "Module": {ESLVal $651 = _v106.termRef(0);
                  ESLVal $650 = _v106.termRef(1);
                  ESLVal $649 = _v106.termRef(2);
                  ESLVal $648 = _v106.termRef(3);
                  ESLVal $647 = _v106.termRef(4);
                  ESLVal $646 = _v106.termRef(5);
                  ESLVal $645 = _v106.termRef(6);
                  
                  {ESLVal path = $651;
                  
                  {ESLVal name = $650;
                  
                  {ESLVal exports = $649;
                  
                  {ESLVal imports = $648;
                  
                  {ESLVal x = $647;
                  
                  {ESLVal y = $646;
                  
                  {ESLVal defs = $645;
                  
                  return _v1005.apply(imports,cache,new ESLVal(new Function(new ESLVal("fun512"),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      ESLVal _v1009 = $args[0];
                  ESLVal _v1008 = $args[1];
                  ESLVal _v1007 = $args[2];
                  ESLVal _v1006 = $args[3];
                  {ESLVal _v1011 = typeEnv.apply(defs);
                        ESLVal _v1010 = mergeFunDefs.apply(defs);
                        
                        {checkDupBindings.apply(_v1010);
                      checkFreeTypes.apply(_v1011.add(_v1006.add(tenv0)));
                      checkSingletonTypes.apply(_v1011);
                      {ESLVal _v1012 = recTypes.apply(_v1011.add(_v1006.add(tenv0)));
                        
                        {ESLVal _v1013 = cnstrEnv.apply(_v1010,_v1012).add(_v1007.add(cnstrEnv0));
                        
                        {checkSingletonConstructors.apply(_v1013);
                      {ESLVal valueEnv = typeCheckValues.apply(valueDefs.apply(_v1010),new ESLVal("NullType",p0),_v1008,_v1012,_v1013);
                        
                        return handler.apply(_v1009,valueEnv,_v1013,_v1012);
                      }}
                      }
                      }}
                      }
                    }
                  }));
                }
                }
                }
                }
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(14212,15754)").add(ESLVal.list(_v106)));
              }
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "_v1005": return _v1005;
            
            case "_v1004": return _v1004;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal _v1005 = letrec.get("_v1005");
      
      ESLVal _v1004 = letrec.get("_v1004");
      
        return _v1004.apply();
      
    }
  });
  private static ESLVal typeCheckValues = new ESLVal(new Function(new ESLVal("typeCheckValues"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1003 = $args[0];
  ESLVal _v1002 = $args[1];
  ESLVal _v1001 = $args[2];
  ESLVal _v1000 = $args[3];
  ESLVal _v999 = $args[4];
  {ESLVal valueEnv = valueDefsToTEnv.apply(_v1003,_v1002,$nil,_v999,_v1000).add(_v1001.add(env0));
        
        {{
        ESLVal _v105 = _v1003;
        while(_v105.isCons()) {
          ESLVal def = _v105.headVal;
          typeCheckDef.apply(def,_v1002,valueEnv,valueEnv,_v999,_v1000);
          _v105 = _v105.tailVal;}
      }
      return valueEnv;}
      }
    }
  });
  private static ESLVal genericize = new ESLVal(new Function(new ESLVal("genericize"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal t = $args[1];
  if(length.apply(typeFV.apply(t)).eql($zero).boolVal)
        return t;
        else
          return new ESLVal("ForallType",l,typeFV.apply(t),t);
    }
  });
  private static ESLVal checkPatterns = new ESLVal(new Function(new ESLVal("checkPatterns"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal ps = $args[1];
  {ESLVal names = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v103 = $qualArg;
                
                {ESLVal p = _v103;
                
                return ESLVal.list(new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal _v998 = $args[0];
                {ESLVal _v104 = _v998;
                      
                      {ESLVal n = _v104;
                      
                      return ESLVal.list(ESLVal.list(n));
                    }
                    }
                  }
                }).map(patternNames.apply(p)).flatten().flatten());
              }
              }
            }
          }).map(ps).flatten().flatten();
        
        if(removeDups.apply(names).neql(names).boolVal)
        return error(new ESLVal("TypeError",l,new ESLVal("duplicate pattern variables")));
        else
          return $null;
      }
    }
  });
  private static ESLVal typeCheckDef = new ESLVal(new Function(new ESLVal("typeCheckDef"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v979 = $args[0];
  ESLVal _v978 = $args[1];
  ESLVal _v977 = $args[2];
  ESLVal _v976 = $args[3];
  ESLVal _v975 = $args[4];
  ESLVal _v974 = $args[5];
  {ESLVal _v95 = _v979;
        
        switch(_v95.termName) {
        case "FunBinds": {ESLVal $617 = _v95.termRef(0);
          ESLVal $616 = _v95.termRef(1);
          
          {ESLVal n = $617;
          
          {ESLVal cases = $616;
          
          LetRec letrec = new LetRec() {
          ESLVal checkArities = new ESLVal(new Function(new ESLVal("checkArities"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v996 = $args[0];
            ESLVal _v995 = $args[1];
            {ESLVal _v102 = _v996;
                  
                  if(_v102.isCons())
                  {ESLVal $638 = _v102.head();
                    ESLVal $639 = _v102.tail();
                    
                    switch($638.termName) {
                    case "FunCase": {ESLVal $644 = $638.termRef(0);
                      ESLVal $643 = $638.termRef(1);
                      ESLVal $642 = $638.termRef(2);
                      ESLVal $641 = $638.termRef(3);
                      ESLVal $640 = $638.termRef(4);
                      
                      {ESLVal l = $644;
                      
                      {ESLVal args = $643;
                      
                      {ESLVal t = $642;
                      
                      {ESLVal g = $641;
                      
                      {ESLVal e = $640;
                      
                      {ESLVal _v997 = $639;
                      
                      if(_v995.eql(new ESLVal(-1)).or(length.apply(args).eql(_v995)).boolVal)
                      return checkArities.apply(_v997,length.apply(args));
                      else
                        return error(new ESLVal("TypeError",l,new ESLVal("inconsistent overloaded arity")));
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: return error(new ESLVal("case error at Pos(16961,17250)").add(ESLVal.list(_v102)));
                  }
                  }
                else if(_v102.isNil())
                  return $null;
                else return error(new ESLVal("case error at Pos(16961,17250)").add(ESLVal.list(_v102)));
                }
              }
            });
          ESLVal checkLoneVars = new ESLVal(new Function(new ESLVal("checkLoneVars"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v993 = $args[0];
            {ESLVal _v100 = _v993;
                  
                  if(_v100.isCons())
                  {ESLVal $631 = _v100.head();
                    ESLVal $632 = _v100.tail();
                    
                    switch($631.termName) {
                    case "FunCase": {ESLVal $637 = $631.termRef(0);
                      ESLVal $636 = $631.termRef(1);
                      ESLVal $635 = $631.termRef(2);
                      ESLVal $634 = $631.termRef(3);
                      ESLVal $633 = $631.termRef(4);
                      
                      {ESLVal l = $637;
                      
                      {ESLVal args = $636;
                      
                      {ESLVal t = $635;
                      
                      {ESLVal g = $634;
                      
                      {ESLVal e = $633;
                      
                      {ESLVal _v994 = $632;
                      
                      {{
                      ESLVal _v101 = args;
                      while(_v101.isCons()) {
                        ESLVal arg = _v101.headVal;
                        checkLoneVar.apply(arg);
                        _v101 = _v101.tailVal;}
                    }
                    return checkLoneVars.apply(_v994);}
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: return error(new ESLVal("case error at Pos(17309,17544)").add(ESLVal.list(_v100)));
                  }
                  }
                else if(_v100.isNil())
                  return $null;
                else return error(new ESLVal("case error at Pos(17309,17544)").add(ESLVal.list(_v100)));
                }
              }
            });
          ESLVal checkLoneVar = new ESLVal(new Function(new ESLVal("checkLoneVar"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal p = $args[0];
            {ESLVal _v99 = p;
                  
                  switch(_v99.termName) {
                  case "PVar": {ESLVal $629 = _v99.termRef(0);
                    ESLVal $628 = _v99.termRef(1);
                    ESLVal $627 = _v99.termRef(2);
                    
                    switch($627.termName) {
                    case "VoidType": {ESLVal $630 = $627.termRef(0);
                      
                      {ESLVal l = $629;
                      
                      {ESLVal _v990 = $628;
                      
                      {ESLVal tl = $630;
                      
                      return error(new ESLVal("TypeError",l,new ESLVal("top level variables should be typed.")));
                    }
                    }
                    }
                    }
                    default: {ESLVal _v991 = _v99;
                      
                      return $null;
                    }
                  }
                  }
                  default: {ESLVal _v992 = _v99;
                    
                    return $null;
                  }
                }
                }
              }
            });
          
          public ESLVal get(String name) {
            switch(name) {
              case "checkArities": return checkArities;
              
              case "checkLoneVars": return checkLoneVars;
              
              case "checkLoneVar": return checkLoneVar;
              
              default: throw new Error("cannot find letrec binding");
            }
            }
          };
        ESLVal checkArities = letrec.get("checkArities");
        
        ESLVal checkLoneVars = letrec.get("checkLoneVars");
        
        ESLVal checkLoneVar = letrec.get("checkLoneVar");
        
          {checkArities.apply(cases,new ESLVal(-1));
        return checkLoneVars.apply(cases);}
        
        }
        }
        }
      case "FunBind": {ESLVal $615 = _v95.termRef(0);
          ESLVal $614 = _v95.termRef(1);
          ESLVal $613 = _v95.termRef(2);
          ESLVal $612 = _v95.termRef(3);
          ESLVal $611 = _v95.termRef(4);
          ESLVal $610 = _v95.termRef(5);
          ESLVal $609 = _v95.termRef(6);
          
          {ESLVal l = $615;
          
          {ESLVal n = $614;
          
          {ESLVal ps = $613;
          
          {ESLVal t = $612;
          
          {ESLVal st = $611;
          
          {ESLVal b = $610;
          
          {ESLVal g = $609;
          
          {checkPatterns.apply(l,ps);
        {ESLVal argTypes = map.apply(new ESLVal(new Function(new ESLVal("fun513"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal p = $args[0];
            {ESLVal _v97 = p;
                  
                  switch(_v97.termName) {
                  case "PVar": {ESLVal $623 = _v97.termRef(0);
                    ESLVal $622 = _v97.termRef(1);
                    ESLVal $621 = _v97.termRef(2);
                    
                    {ESLVal _v984 = $623;
                    
                    {ESLVal _v985 = $622;
                    
                    {ESLVal _v986 = $621;
                    
                    return substTypeEnv.apply(_v974,_v986);
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(18176,18242)").add(ESLVal.list(_v97)));
                }
                }
              }
            }),ps);
          ESLVal argNames = map.apply(new ESLVal(new Function(new ESLVal("fun514"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal p = $args[0];
            {ESLVal _v96 = p;
                  
                  switch(_v96.termName) {
                  case "PVar": {ESLVal $620 = _v96.termRef(0);
                    ESLVal $619 = _v96.termRef(1);
                    ESLVal $618 = _v96.termRef(2);
                    
                    {ESLVal _v981 = $620;
                    
                    {ESLVal _v982 = $619;
                    
                    {ESLVal _v983 = $618;
                    
                    return _v982;
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(18314,18358)").add(ESLVal.list(_v96)));
                }
                }
              }
            }),ps);
          
          {ESLVal bodyType = guardedExpType.apply(l,g,b,_v978,zipTypeEnv.apply(argNames,argTypes).add(_v977),_v975,_v974);
          
          {ESLVal fType = ((Supplier<ESLVal>)() -> { 
              {ESLVal _v98 = t;
                
                switch(_v98.termName) {
                case "ForallType": {ESLVal $626 = _v98.termRef(0);
                  ESLVal $625 = _v98.termRef(1);
                  ESLVal $624 = _v98.termRef(2);
                  
                  {ESLVal _v987 = $626;
                  
                  {ESLVal ns = $625;
                  
                  {ESLVal _v988 = $624;
                  
                  return genericize.apply(_v987,new ESLVal("FunType",_v987,argTypes,bodyType));
                }
                }
                }
                }
                default: {ESLVal _v989 = _v98;
                  
                  return new ESLVal("FunType",l,argTypes,bodyType);
                }
              }
              }
            }).get();
          ESLVal dType = substTypeEnv.apply(_v974,t);
          
          if(subType.apply(fType,dType).boolVal)
          return $null;
          else
            return error(new ESLVal("TypeError",l,new ESLVal("type of ").add(n.add(new ESLVal("::").add(ppType.apply(fType,_v974).add(new ESLVal(" does not match declaration ").add(ppType.apply(dType,_v974))))))));
        }
        }
        }}
        }
        }
        }
        }
        }
        }
        }
        }
      case "Binding": {ESLVal $608 = _v95.termRef(0);
          ESLVal $607 = _v95.termRef(1);
          ESLVal $606 = _v95.termRef(2);
          ESLVal $605 = _v95.termRef(3);
          ESLVal $604 = _v95.termRef(4);
          
          {ESLVal l = $608;
          
          {ESLVal n = $607;
          
          {ESLVal dt = $606;
          
          {ESLVal st = $605;
          
          {ESLVal e = $604;
          
          {ESLVal valueType = expType.apply(e,_v978,_v977,_v975,_v974);
          
          {ESLVal valueFV = typeFV.apply(valueType);
          ESLVal declaredType = lookupType.apply(n,_v976);
          
          {ESLVal _v980 = ((Supplier<ESLVal>)() -> { 
              if(valueFV.eql($nil).boolVal)
                return valueType;
                else
                  return new ESLVal("ForallType",l,valueFV,valueType);
            }).get();
          
          if(subType.apply(_v980,declaredType).boolVal)
          return $null;
          else
            return error(new ESLVal("TypeError",l,new ESLVal("type of ").add(n.add(new ESLVal(" ").add(ppType.apply(_v980,_v974).add(new ESLVal(" does not match declared type = ").add(ppType.apply(declaredType,_v974))))))));
        }
        }
        }
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(16842,19765)").add(ESLVal.list(_v95)));
      }
      }
    }
  });
  private static ESLVal guardedExpType = new ESLVal(new Function(new ESLVal("guardedExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v973 = $args[0];
  ESLVal _v972 = $args[1];
  ESLVal _v971 = $args[2];
  ESLVal _v970 = $args[3];
  ESLVal _v969 = $args[4];
  ESLVal _v968 = $args[5];
  ESLVal _v967 = $args[6];
  {ESLVal bt = expType.apply(_v972,_v970,_v969,_v968,_v967);
        
        if(isBoolType.apply(bt).boolVal)
        return expType.apply(_v971,_v970,_v969,_v968,_v967);
        else
          return error(new ESLVal("TypeError",_v973,new ESLVal("guarded expression requires a boolean value: ").add(ppType.apply(bt,_v967))));
      }
    }
  });
  private static ESLVal expType = new ESLVal(new Function(new ESLVal("expType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v949 = $args[0];
  ESLVal _v948 = $args[1];
  ESLVal _v947 = $args[2];
  ESLVal _v946 = $args[3];
  ESLVal _v945 = $args[4];
  {ESLVal _v93 = _v949;
        
        switch(_v93.termName) {
        case "ActExp": {ESLVal $603 = _v93.termRef(0);
          ESLVal $602 = _v93.termRef(1);
          ESLVal $601 = _v93.termRef(2);
          ESLVal $600 = _v93.termRef(3);
          ESLVal $599 = _v93.termRef(4);
          ESLVal $598 = _v93.termRef(5);
          ESLVal $597 = _v93.termRef(6);
          ESLVal $596 = _v93.termRef(7);
          
          {ESLVal l = $603;
          
          {ESLVal n = $602;
          
          {ESLVal args = $601;
          
          {ESLVal exports = $600;
          
          {ESLVal parent = $599;
          
          {ESLVal bindings = $598;
          
          {ESLVal init = $597;
          
          {ESLVal arms = $596;
          
          return actType.apply(l,n,args,parent,exports,bindings,init,arms,_v948,_v947,_v946,_v945);
        }
        }
        }
        }
        }
        }
        }
        }
        }
      case "Apply": {ESLVal $595 = _v93.termRef(0);
          ESLVal $594 = _v93.termRef(1);
          ESLVal $593 = _v93.termRef(2);
          
          {ESLVal l = $595;
          
          {ESLVal op = $594;
          
          {ESLVal args = $593;
          
          return applyType.apply(l,op,args,_v948,_v947,_v946,_v945);
        }
        }
        }
        }
      case "ApplyTypeExp": {ESLVal $592 = _v93.termRef(0);
          ESLVal $591 = _v93.termRef(1);
          ESLVal $590 = _v93.termRef(2);
          
          {ESLVal l = $592;
          
          {ESLVal _v966 = $591;
          
          {ESLVal ts = $590;
          
          return applyTypeExp.apply(l,_v966,ts,_v948,_v947,_v946,_v945);
        }
        }
        }
        }
      case "ArrayUpdate": {ESLVal $589 = _v93.termRef(0);
          ESLVal $588 = _v93.termRef(1);
          ESLVal $587 = _v93.termRef(2);
          ESLVal $586 = _v93.termRef(3);
          
          {ESLVal l = $589;
          
          {ESLVal a = $588;
          
          {ESLVal i = $587;
          
          {ESLVal v = $586;
          
          return arrayUpdateType.apply(l,a,i,v,_v948,_v947,_v946,_v945);
        }
        }
        }
        }
        }
      case "ArrayRef": {ESLVal $585 = _v93.termRef(0);
          ESLVal $584 = _v93.termRef(1);
          ESLVal $583 = _v93.termRef(2);
          
          {ESLVal l = $585;
          
          {ESLVal a = $584;
          
          {ESLVal i = $583;
          
          return arrayRefType.apply(l,a,i,_v948,_v947,_v946,_v945);
        }
        }
        }
        }
      case "BagExp": {ESLVal $582 = _v93.termRef(0);
          ESLVal $581 = _v93.termRef(1);
          
          {ESLVal l = $582;
          
          {ESLVal es = $581;
          
          return bagType.apply(l,es,_v948,_v947,_v946,_v945);
        }
        }
        }
      case "Become": {ESLVal $580 = _v93.termRef(0);
          ESLVal $579 = _v93.termRef(1);
          
          {ESLVal l = $580;
          
          {ESLVal _v965 = $579;
          
          return becomeType.apply(l,_v965,_v948,_v947,_v946,_v945);
        }
        }
        }
      case "BinExp": {ESLVal $578 = _v93.termRef(0);
          ESLVal $577 = _v93.termRef(1);
          ESLVal $576 = _v93.termRef(2);
          ESLVal $575 = _v93.termRef(3);
          
          {ESLVal l = $578;
          
          {ESLVal e1 = $577;
          
          {ESLVal op = $576;
          
          {ESLVal e2 = $575;
          
          return binExpType.apply(l,e1,op,e2,_v948,_v947,_v946,_v945);
        }
        }
        }
        }
        }
      case "Block": {ESLVal $574 = _v93.termRef(0);
          ESLVal $573 = _v93.termRef(1);
          
          {ESLVal l = $574;
          
          {ESLVal es = $573;
          
          return blockType.apply(l,es,_v948,_v947,_v946,_v945);
        }
        }
        }
      case "BoolExp": {ESLVal $572 = _v93.termRef(0);
          ESLVal $571 = _v93.termRef(1);
          
          {ESLVal l = $572;
          
          {ESLVal b = $571;
          
          return new ESLVal("BoolType",l);
        }
        }
        }
      case "Case": {ESLVal $570 = _v93.termRef(0);
          ESLVal $569 = _v93.termRef(1);
          ESLVal $568 = _v93.termRef(2);
          ESLVal $567 = _v93.termRef(3);
          
          {ESLVal l = $570;
          
          {ESLVal decs = $569;
          
          {ESLVal es = $568;
          
          {ESLVal arms = $567;
          
          return caseType.apply(l,es,arms,_v948,_v947,_v946,_v945);
        }
        }
        }
        }
        }
      case "Cmp": {ESLVal $566 = _v93.termRef(0);
          ESLVal $565 = _v93.termRef(1);
          ESLVal $564 = _v93.termRef(2);
          
          {ESLVal l = $566;
          
          {ESLVal _v964 = $565;
          
          {ESLVal qs = $564;
          
          return cmpType.apply(l,_v964,qs,_v948,_v947,_v946,_v945);
        }
        }
        }
        }
      case "Grab": {ESLVal $563 = _v93.termRef(0);
          ESLVal $562 = _v93.termRef(1);
          ESLVal $561 = _v93.termRef(2);
          
          {ESLVal l = $563;
          
          {ESLVal refs = $562;
          
          {ESLVal _v963 = $561;
          
          return expType.apply(_v963,_v948,_v947,_v946,_v945);
        }
        }
        }
        }
      case "FloatExp": {ESLVal $560 = _v93.termRef(0);
          ESLVal $559 = _v93.termRef(1);
          
          {ESLVal l = $560;
          
          {ESLVal f = $559;
          
          return new ESLVal("FloatType",l);
        }
        }
        }
      case "Fold": {ESLVal $558 = _v93.termRef(0);
          ESLVal $557 = _v93.termRef(1);
          ESLVal $556 = _v93.termRef(2);
          
          {ESLVal l = $558;
          
          {ESLVal t = $557;
          
          {ESLVal _v962 = $556;
          
          return foldType.apply(l,t,_v962,_v948,_v947,_v946,_v945);
        }
        }
        }
        }
      case "For": {ESLVal $555 = _v93.termRef(0);
          ESLVal $554 = _v93.termRef(1);
          ESLVal $553 = _v93.termRef(2);
          ESLVal $552 = _v93.termRef(3);
          
          {ESLVal l = $555;
          
          {ESLVal p = $554;
          
          {ESLVal list = $553;
          
          {ESLVal _v961 = $552;
          
          return forType.apply(l,p,list,_v961,_v948,_v947,_v946,_v945);
        }
        }
        }
        }
        }
      case "FunExp": {ESLVal $551 = _v93.termRef(0);
          ESLVal $550 = _v93.termRef(1);
          ESLVal $549 = _v93.termRef(2);
          ESLVal $548 = _v93.termRef(3);
          ESLVal $547 = _v93.termRef(4);
          
          {ESLVal l = $551;
          
          {ESLVal n = $550;
          
          {ESLVal args = $549;
          
          {ESLVal t = $548;
          
          {ESLVal _v960 = $547;
          
          return funType.apply(l,n,args,t,_v960,_v948,_v947,_v946,_v945);
        }
        }
        }
        }
        }
        }
      case "If": {ESLVal $546 = _v93.termRef(0);
          ESLVal $545 = _v93.termRef(1);
          ESLVal $544 = _v93.termRef(2);
          ESLVal $543 = _v93.termRef(3);
          
          {ESLVal l = $546;
          
          {ESLVal e1 = $545;
          
          {ESLVal e2 = $544;
          
          {ESLVal e3 = $543;
          
          return ifType.apply(l,e1,e2,e3,_v948,_v947,_v946,_v945);
        }
        }
        }
        }
        }
      case "IntExp": {ESLVal $542 = _v93.termRef(0);
          ESLVal $541 = _v93.termRef(1);
          
          {ESLVal l = $542;
          
          {ESLVal n = $541;
          
          return new ESLVal("IntType",l);
        }
        }
        }
      case "Let": {ESLVal $540 = _v93.termRef(0);
          ESLVal $539 = _v93.termRef(1);
          ESLVal $538 = _v93.termRef(2);
          
          {ESLVal l = $540;
          
          {ESLVal bs = $539;
          
          {ESLVal _v959 = $538;
          
          return letType.apply(l,bs,_v959,_v948,_v947,_v946,_v945);
        }
        }
        }
        }
      case "Letrec": {ESLVal $537 = _v93.termRef(0);
          ESLVal $536 = _v93.termRef(1);
          ESLVal $535 = _v93.termRef(2);
          
          {ESLVal l = $537;
          
          {ESLVal bs = $536;
          
          {ESLVal _v958 = $535;
          
          return letrecType.apply(l,bs,_v958,_v948,_v947,_v946,_v945);
        }
        }
        }
        }
      case "List": {ESLVal $534 = _v93.termRef(0);
          ESLVal $533 = _v93.termRef(1);
          
          {ESLVal l = $534;
          
          {ESLVal es = $533;
          
          return listType.apply(l,es,_v948,_v947,_v946,_v945);
        }
        }
        }
      case "Now": {ESLVal $532 = _v93.termRef(0);
          
          {ESLVal l = $532;
          
          return new ESLVal("IntType",l);
        }
        }
      case "Probably": {ESLVal $531 = _v93.termRef(0);
          ESLVal $530 = _v93.termRef(1);
          ESLVal $529 = _v93.termRef(2);
          ESLVal $528 = _v93.termRef(3);
          ESLVal $527 = _v93.termRef(4);
          
          {ESLVal l = $531;
          
          {ESLVal p = $530;
          
          {ESLVal t = $529;
          
          {ESLVal e1 = $528;
          
          {ESLVal e2 = $527;
          
          return probablyType.apply(l,p,t,e1,e2,_v948,_v947,_v946,_v945);
        }
        }
        }
        }
        }
        }
      case "PLet": {ESLVal $526 = _v93.termRef(0);
          ESLVal $525 = _v93.termRef(1);
          ESLVal $524 = _v93.termRef(2);
          
          {ESLVal l = $526;
          
          {ESLVal bs = $525;
          
          {ESLVal _v957 = $524;
          
          return letType.apply(l,bs,_v957,_v948,_v947,_v946,_v945);
        }
        }
        }
        }
      case "Record": {ESLVal $523 = _v93.termRef(0);
          ESLVal $522 = _v93.termRef(1);
          
          {ESLVal l = $523;
          
          {ESLVal fields = $522;
          
          return recordType.apply(l,fields,_v948,_v947,_v946,_v945);
        }
        }
        }
      case "Ref": {ESLVal $521 = _v93.termRef(0);
          ESLVal $520 = _v93.termRef(1);
          ESLVal $519 = _v93.termRef(2);
          
          {ESLVal l = $521;
          
          {ESLVal _v956 = $520;
          
          {ESLVal n = $519;
          
          return refType.apply(l,_v956,n,_v948,_v947,_v946,_v945);
        }
        }
        }
        }
      case "RefSuper": {ESLVal $518 = _v93.termRef(0);
          ESLVal $517 = _v93.termRef(1);
          
          {ESLVal l = $518;
          
          {ESLVal n = $517;
          
          return refType.apply(l,new ESLVal("Var",l,new ESLVal("$super")),n,_v948,_v947,_v946,_v945);
        }
        }
        }
      case "Self": {ESLVal $516 = _v93.termRef(0);
          
          {ESLVal l = $516;
          
          return _v948;
        }
        }
      case "Send": {ESLVal $511 = _v93.termRef(0);
          ESLVal $510 = _v93.termRef(1);
          ESLVal $509 = _v93.termRef(2);
          
          switch($509.termName) {
          case "Term": {ESLVal $515 = $509.termRef(0);
            ESLVal $514 = $509.termRef(1);
            ESLVal $513 = $509.termRef(2);
            ESLVal $512 = $509.termRef(3);
            
            {ESLVal l = $511;
            
            {ESLVal target = $510;
            
            {ESLVal tl = $515;
            
            {ESLVal n = $514;
            
            {ESLVal ts = $513;
            
            {ESLVal args = $512;
            
            return sendType.apply(l,target,n,args,_v948,_v947,_v946,_v945);
          }
          }
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(20243,24296)").add(ESLVal.list(_v93)));
        }
        }
      case "SendTimeSuper": {ESLVal $508 = _v93.termRef(0);
          
          {ESLVal l = $508;
          
          return new ESLVal("VoidType",l);
        }
        }
      case "SendSuper": {ESLVal $507 = _v93.termRef(0);
          ESLVal $506 = _v93.termRef(1);
          
          {ESLVal l = $507;
          
          {ESLVal _v955 = $506;
          
          return new ESLVal("VoidType",l);
        }
        }
        }
      case "SetExp": {ESLVal $505 = _v93.termRef(0);
          ESLVal $504 = _v93.termRef(1);
          
          {ESLVal l = $505;
          
          {ESLVal es = $504;
          
          return setType.apply(l,es,_v948,_v947,_v946,_v945);
        }
        }
        }
      case "StrExp": {ESLVal $503 = _v93.termRef(0);
          ESLVal $502 = _v93.termRef(1);
          
          {ESLVal l = $503;
          
          {ESLVal s = $502;
          
          return new ESLVal("StrType",l);
        }
        }
        }
      case "Term": {ESLVal $501 = _v93.termRef(0);
          ESLVal $500 = _v93.termRef(1);
          ESLVal $499 = _v93.termRef(2);
          ESLVal $498 = _v93.termRef(3);
          
          {ESLVal l = $501;
          
          {ESLVal n = $500;
          
          {ESLVal ts = $499;
          
          {ESLVal es = $498;
          
          return termType.apply(l,n,ts,es,_v948,_v947,_v946,_v945);
        }
        }
        }
        }
        }
      case "Throw": {ESLVal $497 = _v93.termRef(0);
          ESLVal $496 = _v93.termRef(1);
          ESLVal $495 = _v93.termRef(2);
          
          {ESLVal l = $497;
          
          {ESLVal t = $496;
          
          {ESLVal _v954 = $495;
          
          return throwType.apply(l,t,_v954,_v948,_v947,_v946,_v945);
        }
        }
        }
        }
      case "Try": {ESLVal $494 = _v93.termRef(0);
          ESLVal $493 = _v93.termRef(1);
          ESLVal $492 = _v93.termRef(2);
          
          {ESLVal l = $494;
          
          {ESLVal _v953 = $493;
          
          {ESLVal arms = $492;
          
          return tryType.apply(l,_v953,arms,_v948,_v947,_v946,_v945);
        }
        }
        }
        }
      case "New": {ESLVal $491 = _v93.termRef(0);
          ESLVal $490 = _v93.termRef(1);
          ESLVal $489 = _v93.termRef(2);
          
          {ESLVal l = $491;
          
          {ESLVal b = $490;
          
          {ESLVal args = $489;
          
          return newType.apply(l,b,args,_v948,_v947,_v946,_v945);
        }
        }
        }
        }
      case "NewArray": {ESLVal $488 = _v93.termRef(0);
          ESLVal $487 = _v93.termRef(1);
          ESLVal $486 = _v93.termRef(2);
          
          {ESLVal l = $488;
          
          {ESLVal t = $487;
          
          {ESLVal i = $486;
          
          return newArrayType.apply(l,t,i,_v948,_v947,_v946,_v945);
        }
        }
        }
        }
      case "NewTable": {ESLVal $485 = _v93.termRef(0);
          ESLVal $484 = _v93.termRef(1);
          ESLVal $483 = _v93.termRef(2);
          
          {ESLVal l = $485;
          
          {ESLVal key = $484;
          
          {ESLVal value = $483;
          
          return new ESLVal("TableType",l,substTypeEnv.apply(_v945,key),substTypeEnv.apply(_v945,value));
        }
        }
        }
        }
      case "NewJava": {ESLVal $482 = _v93.termRef(0);
          ESLVal $481 = _v93.termRef(1);
          ESLVal $480 = _v93.termRef(2);
          ESLVal $479 = _v93.termRef(3);
          
          {ESLVal l = $482;
          
          {ESLVal path = $481;
          
          {ESLVal t = $480;
          
          {ESLVal args = $479;
          
          {{
          ESLVal _v94 = args;
          while(_v94.isCons()) {
            ESLVal a = _v94.headVal;
            expType.apply(a,_v948,_v947,_v946,_v945);
            _v94 = _v94.tailVal;}
        }
        return substTypeEnv.apply(_v945,t);}
        }
        }
        }
        }
        }
      case "Not": {ESLVal $478 = _v93.termRef(0);
          ESLVal $477 = _v93.termRef(1);
          
          {ESLVal l = $478;
          
          {ESLVal _v952 = $477;
          
          return notType.apply(l,_v952,_v948,_v947,_v946,_v945);
        }
        }
        }
      case "NullExp": {ESLVal $476 = _v93.termRef(0);
          
          {ESLVal l = $476;
          
          return new ESLVal("ForallType",l,ESLVal.list(new ESLVal("T")),new ESLVal("VarType",l,new ESLVal("T")));
        }
        }
      case "Unfold": {ESLVal $475 = _v93.termRef(0);
          ESLVal $474 = _v93.termRef(1);
          ESLVal $473 = _v93.termRef(2);
          
          {ESLVal l = $475;
          
          {ESLVal t = $474;
          
          {ESLVal _v951 = $473;
          
          return unfoldTypeExp.apply(l,t,_v951,_v948,_v947,_v946,_v945);
        }
        }
        }
        }
      case "Update": {ESLVal $472 = _v93.termRef(0);
          ESLVal $471 = _v93.termRef(1);
          ESLVal $470 = _v93.termRef(2);
          
          {ESLVal l = $472;
          
          {ESLVal n = $471;
          
          {ESLVal _v950 = $470;
          
          return updateType.apply(l,n,_v950,_v948,_v947,_v946,_v945);
        }
        }
        }
        }
      case "Var": {ESLVal $469 = _v93.termRef(0);
          ESLVal $468 = _v93.termRef(1);
          
          {ESLVal l = $469;
          
          {ESLVal n = $468;
          
          return varType.apply(l,n,_v947);
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(20243,24296)").add(ESLVal.list(_v93)));
      }
      }
    }
  });
  private static ESLVal throwType = new ESLVal(new Function(new ESLVal("throwType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v944 = $args[0];
  ESLVal _v943 = $args[1];
  ESLVal _v942 = $args[2];
  ESLVal _v941 = $args[3];
  ESLVal _v940 = $args[4];
  ESLVal _v939 = $args[5];
  ESLVal _v938 = $args[6];
  {ESLVal valType = expType.apply(_v942,_v941,_v940,_v939,_v938);
        
        return substTypeEnv.apply(_v938,_v943);
      }
    }
  });
  private static ESLVal foldType = new ESLVal(new Function(new ESLVal("foldType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v937 = $args[0];
  ESLVal _v936 = $args[1];
  ESLVal _v935 = $args[2];
  ESLVal _v934 = $args[3];
  ESLVal _v933 = $args[4];
  ESLVal _v932 = $args[5];
  ESLVal _v931 = $args[6];
  {ESLVal eType = expType.apply(_v935,_v934,_v933,_v932,_v931);
        
        if(typeEqual.apply(substTypeEnv.apply(_v931,_v936),eType).boolVal)
        return eType;
        else
          return error(new ESLVal("TypeError",_v937,new ESLVal("fold type ").add(ppType.apply(_v936,_v931).add(new ESLVal(" does not equal ").add(ppType.apply(eType,_v931))))));
      }
    }
  });
  private static ESLVal unfoldTypeExp = new ESLVal(new Function(new ESLVal("unfoldTypeExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v928 = $args[0];
  ESLVal _v927 = $args[1];
  ESLVal _v926 = $args[2];
  ESLVal _v925 = $args[3];
  ESLVal _v924 = $args[4];
  ESLVal _v923 = $args[5];
  ESLVal _v922 = $args[6];
  {ESLVal eType = expType.apply(_v926,_v925,_v924,_v923,_v922);
        ESLVal recType = substTypeEnv.apply(_v922,_v927);
        
        {ESLVal _v92 = recType;
        
        switch(_v92.termName) {
        case "RecType": {ESLVal $467 = _v92.termRef(0);
          ESLVal $466 = _v92.termRef(1);
          ESLVal $465 = _v92.termRef(2);
          
          {ESLVal rl = $467;
          
          {ESLVal n = $466;
          
          {ESLVal _v929 = $465;
          
          if(typeEqual.apply(substType.apply(eType,n,_v929),eType).boolVal)
          return eType;
          else
            return error(new ESLVal("TypeError",_v928,new ESLVal("unfold type ").add(ppType.apply(substType.apply(eType,n,_v929),_v922).add(new ESLVal(" does not equal ").add(ppType.apply(eType,_v922))))));
        }
        }
        }
        }
        default: {ESLVal _v930 = _v92;
          
          return error(new ESLVal("TypeError",_v928,new ESLVal("unfold type expects a rec type").add(ppType.apply(recType,_v922))));
        }
      }
      }
      }
    }
  });
  private static ESLVal arrayUpdateType = new ESLVal(new Function(new ESLVal("arrayUpdateType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v921 = $args[0];
  ESLVal _v920 = $args[1];
  ESLVal _v919 = $args[2];
  ESLVal _v918 = $args[3];
  ESLVal _v917 = $args[4];
  ESLVal _v916 = $args[5];
  ESLVal _v915 = $args[6];
  ESLVal _v914 = $args[7];
  {ESLVal aType = expType.apply(_v920,_v917,_v916,_v915,_v914);
        ESLVal iType = expType.apply(_v919,_v917,_v916,_v915,_v914);
        ESLVal vType = expType.apply(_v918,_v917,_v916,_v915,_v914);
        
        {ESLVal _v91 = aType;
        
        switch(_v91.termName) {
        case "ArrayType": {ESLVal $464 = _v91.termRef(0);
          ESLVal $463 = _v91.termRef(1);
          
          {ESLVal al = $464;
          
          {ESLVal t = $463;
          
          if(isIntType.apply(iType).boolVal)
          if(typeEqual.apply(vType,t).boolVal)
            return aType;
            else
              return error(new ESLVal("TypeError",_v921,new ESLVal("value type ").add(vType.add(new ESLVal(" does not match array type ").add(t)))));
          else
            return error(new ESLVal("TypeError",_v921,new ESLVal("array index should be an integer ").add(_v919)));
        }
        }
        }
        default: {ESLVal t = _v91;
          
          return error(new ESLVal("TypeError",_v921,new ESLVal("expecting an array ").add(aType)));
        }
      }
      }
      }
    }
  });
  private static ESLVal arrayRefType = new ESLVal(new Function(new ESLVal("arrayRefType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v913 = $args[0];
  ESLVal _v912 = $args[1];
  ESLVal _v911 = $args[2];
  ESLVal _v910 = $args[3];
  ESLVal _v909 = $args[4];
  ESLVal _v908 = $args[5];
  ESLVal _v907 = $args[6];
  {ESLVal aType = expType.apply(_v912,_v910,_v909,_v908,_v907);
        ESLVal iType = expType.apply(_v911,_v910,_v909,_v908,_v907);
        
        {ESLVal _v90 = aType;
        
        switch(_v90.termName) {
        case "ArrayType": {ESLVal $462 = _v90.termRef(0);
          ESLVal $461 = _v90.termRef(1);
          
          {ESLVal al = $462;
          
          {ESLVal t = $461;
          
          if(isIntType.apply(iType).boolVal)
          return t;
          else
            return error(new ESLVal("TypeError",_v913,new ESLVal("array index should be an integer ").add(_v911)));
        }
        }
        }
        default: {ESLVal t = _v90;
          
          return error(new ESLVal("TypeError",_v913,new ESLVal("expecting an array ").add(aType)));
        }
      }
      }
      }
    }
  });
  private static ESLVal newArrayType = new ESLVal(new Function(new ESLVal("newArrayType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v906 = $args[0];
  ESLVal _v905 = $args[1];
  ESLVal _v904 = $args[2];
  ESLVal _v903 = $args[3];
  ESLVal _v902 = $args[4];
  ESLVal _v901 = $args[5];
  ESLVal _v900 = $args[6];
  {ESLVal i = expType.apply(_v904,_v903,_v902,_v901,_v900);
        
        if(isIntType.apply(i).boolVal)
        return new ESLVal("ArrayType",_v906,substTypeEnv.apply(_v900,_v905));
        else
          return error(new ESLVal("TypeError",_v906,new ESLVal("expecting an integer type: ").add(i)));
      }
    }
  });
  private static ESLVal becomeType = new ESLVal(new Function(new ESLVal("becomeType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v899 = $args[0];
  ESLVal _v898 = $args[1];
  ESLVal _v897 = $args[2];
  ESLVal _v896 = $args[3];
  ESLVal _v895 = $args[4];
  ESLVal _v894 = $args[5];
  {ESLVal bType = expType.apply(_v898,_v897,_v896,_v895,_v894);
        
        if(typeEqual.apply(bType,_v897).boolVal)
        return bType;
        else
          return error(new ESLVal("TypeError",_v899,new ESLVal("expecting become to match self type: ").add(ppType.apply(bType,_v894).add(new ESLVal(" ").add(ppType.apply(_v897,_v894))))));
      }
    }
  });
  private static ESLVal probablyType = new ESLVal(new Function(new ESLVal("probablyType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v890 = $args[0];
  ESLVal _v889 = $args[1];
  ESLVal _v888 = $args[2];
  ESLVal _v887 = $args[3];
  ESLVal _v886 = $args[4];
  ESLVal _v885 = $args[5];
  ESLVal _v884 = $args[6];
  ESLVal _v883 = $args[7];
  ESLVal _v882 = $args[8];
  {ESLVal pt = expType.apply(_v889,_v885,_v884,_v883,_v882);
        
        if(isIntType.apply(pt).boolVal)
        {ESLVal _v893 = substTypeEnv.apply(_v882,_v888);
          ESLVal _v892 = expType.apply(_v887,_v885,_v884,_v883,_v882);
          ESLVal _v891 = expType.apply(_v886,_v885,_v884,_v883,_v882);
          
          if(typeEqual.apply(_v893,_v892).and(typeEqual.apply(_v893,_v891)).boolVal)
          return _v893;
          else
            return error(new ESLVal("TypeError",_v890,new ESLVal("expecting probably arm types to agree: ").add(ppType.apply(_v892,_v882).add(new ESLVal(" ").add(ppType.apply(_v893,_v882).add(new ESLVal(" ").add(ppType.apply(_v891,_v882))))))));
        }
        else
          return error(new ESLVal("TypeError",_v890,new ESLVal("expecting an integer: ").add(ppType.apply(pt,_v882))));
      }
    }
  });
  private static ESLVal newType = new ESLVal(new Function(new ESLVal("newType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v881 = $args[0];
  ESLVal _v880 = $args[1];
  ESLVal _v879 = $args[2];
  ESLVal _v878 = $args[3];
  ESLVal _v877 = $args[4];
  ESLVal _v876 = $args[5];
  ESLVal _v875 = $args[6];
  return expType.apply(new ESLVal("Apply",_v881,_v880,_v879),_v878,_v877,_v876,_v875);
    }
  });
  private static ESLVal sendType = new ESLVal(new Function(new ESLVal("sendType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v864 = $args[0];
  ESLVal _v863 = $args[1];
  ESLVal _v862 = $args[2];
  ESLVal _v861 = $args[3];
  ESLVal _v860 = $args[4];
  ESLVal _v859 = $args[5];
  ESLVal _v858 = $args[6];
  ESLVal _v857 = $args[7];
  {ESLVal _v87 = typeNF.apply(derefType.apply(expType.apply(_v863,_v860,_v859,_v858,_v857)),_v857);
        
        switch(_v87.termName) {
        case "ActType": {ESLVal $440 = _v87.termRef(0);
          ESLVal $439 = _v87.termRef(1);
          ESLVal $438 = _v87.termRef(2);
          
          {ESLVal al = $440;
          
          {ESLVal exports = $439;
          
          {ESLVal handlers = $438;
          
          LetRec letrec = new LetRec() {
          ESLVal findHandler = new ESLVal(new Function(new ESLVal("findHandler"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v865 = $args[0];
            {ESLVal _v88 = _v865;
                  
                  if(_v88.isCons())
                  {ESLVal $441 = _v88.head();
                    ESLVal $442 = _v88.tail();
                    
                    switch($441.termName) {
                    case "MessageType": {ESLVal $444 = $441.termRef(0);
                      ESLVal $443 = $441.termRef(1);
                      
                      if($443.isCons())
                      {ESLVal $445 = $443.head();
                        ESLVal $446 = $443.tail();
                        
                        switch($445.termName) {
                        case "TermType": {ESLVal $449 = $445.termRef(0);
                          ESLVal $448 = $445.termRef(1);
                          ESLVal $447 = $445.termRef(2);
                          
                          if($446.isCons())
                          {ESLVal $450 = $446.head();
                            ESLVal $451 = $446.tail();
                            
                            {ESLVal m = $441;
                            
                            {ESLVal _v866 = $442;
                            
                            return findHandler.apply(_v866);
                          }
                          }
                          }
                        else if($446.isNil())
                          {ESLVal ml = $444;
                            
                            {ESLVal tl = $449;
                            
                            {ESLVal m = $448;
                            
                            {ESLVal ts = $447;
                            
                            {ESLVal rest = $442;
                            
                            if(m.eql(_v862).boolVal)
                            return head.apply(_v865);
                            else
                              {ESLVal _v867 = $441;
                                
                                {ESLVal _v868 = $442;
                                
                                return findHandler.apply(_v868);
                              }
                              }
                          }
                          }
                          }
                          }
                          }
                        else {ESLVal m = $441;
                            
                            {ESLVal _v869 = $442;
                            
                            return findHandler.apply(_v869);
                          }
                          }
                        }
                        default: {ESLVal m = $441;
                          
                          {ESLVal _v870 = $442;
                          
                          return findHandler.apply(_v870);
                        }
                        }
                      }
                      }
                    else if($443.isNil())
                      {ESLVal m = $441;
                        
                        {ESLVal _v871 = $442;
                        
                        return findHandler.apply(_v871);
                      }
                      }
                    else {ESLVal m = $441;
                        
                        {ESLVal _v872 = $442;
                        
                        return findHandler.apply(_v872);
                      }
                      }
                    }
                    default: {ESLVal m = $441;
                      
                      {ESLVal _v873 = $442;
                      
                      return findHandler.apply(_v873);
                    }
                    }
                  }
                  }
                else if(_v88.isNil())
                  return error(new ESLVal("TypeError",_v864,new ESLVal("cannot find message handler named ").add(_v862)));
                else return error(new ESLVal("case error at Pos(28491,28798)").add(ESLVal.list(_v88)));
                }
              }
            });
          
          public ESLVal get(String name) {
            switch(name) {
              case "findHandler": return findHandler;
              
              default: throw new Error("cannot find letrec binding");
            }
            }
          };
        ESLVal findHandler = letrec.get("findHandler");
        
          {ESLVal _v89 = findHandler.apply(handlers);
          
          switch(_v89.termName) {
          case "MessageType": {ESLVal $453 = _v89.termRef(0);
            ESLVal $452 = _v89.termRef(1);
            
            if($452.isCons())
            {ESLVal $454 = $452.head();
              ESLVal $455 = $452.tail();
              
              switch($454.termName) {
              case "TermType": {ESLVal $458 = $454.termRef(0);
                ESLVal $457 = $454.termRef(1);
                ESLVal $456 = $454.termRef(2);
                
                if($455.isCons())
                {ESLVal $459 = $455.head();
                  ESLVal $460 = $455.tail();
                  
                  {ESLVal m = _v89;
                  
                  return error(new ESLVal("TypeError",_v864,new ESLVal("cannot find message handler named ").add(_v862.add(new ESLVal(" in ").add(handlers)))));
                }
                }
              else if($455.isNil())
                {ESLVal ml = $453;
                  
                  {ESLVal tl = $458;
                  
                  {ESLVal _v874 = $457;
                  
                  {ESLVal ts1 = $456;
                  
                  {ESLVal ts2 = expTypes.apply(_v861,_v860,_v859,_v858,_v857);
                  
                  if(length.apply(ts1).eql(length.apply(ts2)).boolVal)
                  if(subTypes.apply(ts2,ts1).boolVal)
                    {expType.apply(_v863,_v860,_v859,_v858,_v857);
                    return new ESLVal("VoidType",_v864);}
                    else
                      return error(new ESLVal("TypeError",_v864,new ESLVal("message argument types ").add(ppTypes.apply(ts2,_v857).add(new ESLVal(" do not match expected types ").add(ppTypes.apply(ts1,_v857))))));
                  else
                    return error(new ESLVal("TypeError",_v864,new ESLVal("expecting ").add(length.apply(ts1).add(new ESLVal(" args, but received ").add(length.apply(ts2))))));
                }
                }
                }
                }
                }
              else {ESLVal m = _v89;
                  
                  return error(new ESLVal("TypeError",_v864,new ESLVal("cannot find message handler named ").add(_v862.add(new ESLVal(" in ").add(handlers)))));
                }
              }
              default: {ESLVal m = _v89;
                
                return error(new ESLVal("TypeError",_v864,new ESLVal("cannot find message handler named ").add(_v862.add(new ESLVal(" in ").add(handlers)))));
              }
            }
            }
          else if($452.isNil())
            {ESLVal m = _v89;
              
              return error(new ESLVal("TypeError",_v864,new ESLVal("cannot find message handler named ").add(_v862.add(new ESLVal(" in ").add(handlers)))));
            }
          else {ESLVal m = _v89;
              
              return error(new ESLVal("TypeError",_v864,new ESLVal("cannot find message handler named ").add(_v862.add(new ESLVal(" in ").add(handlers)))));
            }
          }
          default: {ESLVal m = _v89;
            
            return error(new ESLVal("TypeError",_v864,new ESLVal("cannot find message handler named ").add(_v862.add(new ESLVal(" in ").add(handlers)))));
          }
        }
        }
        
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(28276,29624)").add(ESLVal.list(_v87)));
      }
      }
    }
  });
  private static ESLVal actType = new ESLVal(new Function(new ESLVal("actType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v814 = $args[0];
  ESLVal _v813 = $args[1];
  ESLVal _v812 = $args[2];
  ESLVal _v811 = $args[3];
  ESLVal _v810 = $args[4];
  ESLVal _v809 = $args[5];
  ESLVal _v808 = $args[6];
  ESLVal _v807 = $args[7];
  ESLVal _v806 = $args[8];
  ESLVal _v805 = $args[9];
  ESLVal _v804 = $args[10];
  ESLVal _v803 = $args[11];
  LetRec letrec = new LetRec() {
        ESLVal findLoc = new ESLVal(new Function(new ESLVal("findLoc"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v847 = $args[0];
          ESLVal _v846 = $args[1];
          {ESLVal _v86 = _v846;
                
                if(_v86.isCons())
                {ESLVal $424 = _v86.head();
                  ESLVal $425 = _v86.tail();
                  
                  switch($424.termName) {
                  case "Binding": {ESLVal $437 = $424.termRef(0);
                    ESLVal $436 = $424.termRef(1);
                    ESLVal $435 = $424.termRef(2);
                    ESLVal $434 = $424.termRef(3);
                    ESLVal $433 = $424.termRef(4);
                    
                    {ESLVal _v851 = $437;
                    
                    {ESLVal m = $436;
                    
                    {ESLVal t = $435;
                    
                    {ESLVal st = $434;
                    
                    {ESLVal e = $433;
                    
                    {ESLVal _v852 = $425;
                    
                    if(m.eql(_v847).boolVal)
                    return _v851;
                    else
                      {ESLVal b = $424;
                        
                        {ESLVal _v853 = $425;
                        
                        return findLoc.apply(_v847,_v853);
                      }
                      }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                case "FunBind": {ESLVal $432 = $424.termRef(0);
                    ESLVal $431 = $424.termRef(1);
                    ESLVal $430 = $424.termRef(2);
                    ESLVal $429 = $424.termRef(3);
                    ESLVal $428 = $424.termRef(4);
                    ESLVal $427 = $424.termRef(5);
                    ESLVal $426 = $424.termRef(6);
                    
                    {ESLVal _v848 = $432;
                    
                    {ESLVal m = $431;
                    
                    {ESLVal ps = $430;
                    
                    {ESLVal t = $429;
                    
                    {ESLVal st = $428;
                    
                    {ESLVal g = $427;
                    
                    {ESLVal e = $426;
                    
                    {ESLVal _v849 = $425;
                    
                    if(m.eql(_v847).boolVal)
                    return _v848;
                    else
                      {ESLVal b = $424;
                        
                        {ESLVal _v850 = $425;
                        
                        return findLoc.apply(_v847,_v850);
                      }
                      }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal b = $424;
                    
                    {ESLVal _v854 = $425;
                    
                    return findLoc.apply(_v847,_v854);
                  }
                  }
                }
                }
              else if(_v86.isNil())
                return p0;
              else return error(new ESLVal("case error at Pos(30134,30438)").add(ESLVal.list(_v86)));
              }
            }
          });
        ESLVal findType = new ESLVal(new Function(new ESLVal("findType"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v838 = $args[0];
          ESLVal _v837 = $args[1];
          {ESLVal _v85 = _v837;
                
                if(_v85.isCons())
                {ESLVal $410 = _v85.head();
                  ESLVal $411 = _v85.tail();
                  
                  switch($410.termName) {
                  case "Binding": {ESLVal $423 = $410.termRef(0);
                    ESLVal $422 = $410.termRef(1);
                    ESLVal $421 = $410.termRef(2);
                    ESLVal $420 = $410.termRef(3);
                    ESLVal $419 = $410.termRef(4);
                    
                    {ESLVal _v842 = $423;
                    
                    {ESLVal m = $422;
                    
                    {ESLVal t = $421;
                    
                    {ESLVal st = $420;
                    
                    {ESLVal e = $419;
                    
                    {ESLVal _v843 = $411;
                    
                    if(m.eql(_v838).boolVal)
                    return substTypeEnv.apply(_v803,t);
                    else
                      {ESLVal b = $410;
                        
                        {ESLVal _v844 = $411;
                        
                        return findType.apply(_v838,_v844);
                      }
                      }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                case "FunBind": {ESLVal $418 = $410.termRef(0);
                    ESLVal $417 = $410.termRef(1);
                    ESLVal $416 = $410.termRef(2);
                    ESLVal $415 = $410.termRef(3);
                    ESLVal $414 = $410.termRef(4);
                    ESLVal $413 = $410.termRef(5);
                    ESLVal $412 = $410.termRef(6);
                    
                    {ESLVal _v839 = $418;
                    
                    {ESLVal m = $417;
                    
                    {ESLVal ps = $416;
                    
                    {ESLVal t = $415;
                    
                    {ESLVal st = $414;
                    
                    {ESLVal g = $413;
                    
                    {ESLVal e = $412;
                    
                    {ESLVal _v840 = $411;
                    
                    if(m.eql(_v838).boolVal)
                    return substTypeEnv.apply(_v803,t);
                    else
                      {ESLVal b = $410;
                        
                        {ESLVal _v841 = $411;
                        
                        return findType.apply(_v838,_v841);
                      }
                      }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal b = $410;
                    
                    {ESLVal _v845 = $411;
                    
                    return findType.apply(_v838,_v845);
                  }
                  }
                }
                }
              else if(_v85.isNil())
                return $null;
              else return error(new ESLVal("case error at Pos(30492,30849)").add(ESLVal.list(_v85)));
              }
            }
          });
        ESLVal decs = new ESLVal(new Function(new ESLVal("decs"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v833 = $args[0];
          {ESLVal _v84 = _v833;
                
                if(_v84.isCons())
                {ESLVal $408 = _v84.head();
                  ESLVal $409 = _v84.tail();
                  
                  {ESLVal m = $408;
                  
                  {ESLVal _v834 = $409;
                  
                  {ESLVal _v836 = findType.apply(m,_v809);
                  ESLVal _v835 = findLoc.apply(m,_v809);
                  
                  if(_v836.eql($null).boolVal)
                  return error(new ESLVal("TypeError",_v835,new ESLVal("cannot find exported name ").add(m)));
                  else
                    return decs.apply(_v834).cons(new ESLVal("Dec",_v835,m,_v836,_v836));
                }
                }
                }
                }
              else if(_v84.isNil())
                return $nil;
              else return error(new ESLVal("case error at Pos(30891,31222)").add(ESLVal.list(_v84)));
              }
            }
          });
        ESLVal getMessageTypes = new ESLVal(new Function(new ESLVal("getMessageTypes"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v830 = $args[0];
          {ESLVal _v83 = _v830;
                
                if(_v83.isCons())
                {ESLVal $402 = _v83.head();
                  ESLVal $403 = _v83.tail();
                  
                  switch($402.termName) {
                  case "BArm": {ESLVal $407 = $402.termRef(0);
                    ESLVal $406 = $402.termRef(1);
                    ESLVal $405 = $402.termRef(2);
                    ESLVal $404 = $402.termRef(3);
                    
                    {ESLVal _v831 = $407;
                    
                    {ESLVal ps = $406;
                    
                    {ESLVal g = $405;
                    
                    {ESLVal e = $404;
                    
                    {ESLVal _v832 = $403;
                    
                    return getMessageTypes.apply(_v832).cons(getMessageType.apply(ps));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(31273,31428)").add(ESLVal.list(_v83)));
                }
                }
              else if(_v83.isNil())
                return $nil;
              else return error(new ESLVal("case error at Pos(31273,31428)").add(ESLVal.list(_v83)));
              }
            }
          });
        ESLVal getMessageType = new ESLVal(new Function(new ESLVal("getMessageType"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal ps = $args[0];
          {ESLVal _v82 = ps;
                
                if(_v82.isCons())
                {ESLVal $394 = _v82.head();
                  ESLVal $395 = _v82.tail();
                  
                  switch($394.termName) {
                  case "PTerm": {ESLVal $399 = $394.termRef(0);
                    ESLVal $398 = $394.termRef(1);
                    ESLVal $397 = $394.termRef(2);
                    ESLVal $396 = $394.termRef(3);
                    
                    if($395.isCons())
                    {ESLVal $400 = $395.head();
                      ESLVal $401 = $395.tail();
                      
                      return error(new ESLVal("case error at Pos(31478,31749)").add(ESLVal.list(_v82)));
                    }
                  else if($395.isNil())
                    {ESLVal pl = $399;
                      
                      {ESLVal termName = $398;
                      
                      {ESLVal targs = $397;
                      
                      {ESLVal _v829 = $396;
                      
                      {ESLVal ts = map.apply(new ESLVal(new Function(new ESLVal("fun515"),getSelf()) {
                          public ESLVal apply(ESLVal... $args) {
                            ESLVal p = $args[0];
                        return getPatternType.apply(_v814,p,_v806,_v805,_v804,_v803);
                          }
                        }),_v829);
                      
                      return new ESLVal("MessageType",pl,ESLVal.list(new ESLVal("TermType",pl,termName,ts)));
                    }
                    }
                    }
                    }
                    }
                  else return error(new ESLVal("case error at Pos(31478,31749)").add(ESLVal.list(_v82)));
                  }
                  default: return error(new ESLVal("case error at Pos(31478,31749)").add(ESLVal.list(_v82)));
                }
                }
              else if(_v82.isNil())
                return error(new ESLVal("case error at Pos(31478,31749)").add(ESLVal.list(_v82)));
              else return error(new ESLVal("case error at Pos(31478,31749)").add(ESLVal.list(_v82)));
              }
            }
          });
        ESLVal typeCheckArms = new ESLVal(new Function(new ESLVal("typeCheckArms"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v826 = $args[0];
          ESLVal _v825 = $args[1];
          ESLVal _v824 = $args[2];
          {ESLVal _v81 = _v826;
                
                if(_v81.isCons())
                {ESLVal $388 = _v81.head();
                  ESLVal $389 = _v81.tail();
                  
                  switch($388.termName) {
                  case "BArm": {ESLVal $393 = $388.termRef(0);
                    ESLVal $392 = $388.termRef(1);
                    ESLVal $391 = $388.termRef(2);
                    ESLVal $390 = $388.termRef(3);
                    
                    {ESLVal _v827 = $393;
                    
                    {ESLVal ps = $392;
                    
                    {ESLVal g = $391;
                    
                    {ESLVal e = $390;
                    
                    {ESLVal _v828 = $389;
                    
                    {typeCheckArm.apply(_v827,ps,g,e,_v825,_v824);
                  return typeCheckArms.apply(_v828,_v825,_v824);}
                  }
                  }
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(31825,32052)").add(ESLVal.list(_v81)));
                }
                }
              else if(_v81.isNil())
                return $null;
              else return error(new ESLVal("case error at Pos(31825,32052)").add(ESLVal.list(_v81)));
              }
            }
          });
        ESLVal typeCheckArm = new ESLVal(new Function(new ESLVal("typeCheckArm"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v820 = $args[0];
          ESLVal _v819 = $args[1];
          ESLVal _v818 = $args[2];
          ESLVal _v817 = $args[3];
          ESLVal _v816 = $args[4];
          ESLVal _v815 = $args[5];
          {ESLVal _v80 = _v819;
                
                if(_v80.isCons())
                {ESLVal $380 = _v80.head();
                  ESLVal $381 = _v80.tail();
                  
                  switch($380.termName) {
                  case "PTerm": {ESLVal $385 = $380.termRef(0);
                    ESLVal $384 = $380.termRef(1);
                    ESLVal $383 = $380.termRef(2);
                    ESLVal $382 = $380.termRef(3);
                    
                    if($381.isCons())
                    {ESLVal $386 = $381.head();
                      ESLVal $387 = $381.tail();
                      
                      return error(new ESLVal("case error at Pos(32151,32600)").add(ESLVal.list(_v80)));
                    }
                  else if($381.isNil())
                    {ESLVal pl = $385;
                      
                      {ESLVal termName = $384;
                      
                      {ESLVal targs = $383;
                      
                      {ESLVal _v821 = $382;
                      
                      {ESLVal ts = map.apply(new ESLVal(new Function(new ESLVal("fun516"),getSelf()) {
                          public ESLVal apply(ESLVal... $args) {
                            ESLVal p = $args[0];
                        return getPatternType.apply(_v820,p,_v816,_v815,_v804,_v803);
                          }
                        }),_v821);
                      
                      {patternTypes.apply(_v820,_v821,ts,_v816,_v815,_v804,_v803,new ESLVal(new Function(new ESLVal("fun517"),getSelf()) {
                      public ESLVal apply(ESLVal... $args) {
                        ESLVal _v823 = $args[0];
                    ESLVal _v822 = $args[1];
                    return expType.apply(_v817,_v816,_v822,_v804,_v803);
                      }
                    }));
                    return $null;}
                    }
                    }
                    }
                    }
                    }
                  else return error(new ESLVal("case error at Pos(32151,32600)").add(ESLVal.list(_v80)));
                  }
                  default: return error(new ESLVal("case error at Pos(32151,32600)").add(ESLVal.list(_v80)));
                }
                }
              else if(_v80.isNil())
                return error(new ESLVal("case error at Pos(32151,32600)").add(ESLVal.list(_v80)));
              else return error(new ESLVal("case error at Pos(32151,32600)").add(ESLVal.list(_v80)));
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "findLoc": return findLoc;
            
            case "findType": return findType;
            
            case "decs": return decs;
            
            case "getMessageTypes": return getMessageTypes;
            
            case "getMessageType": return getMessageType;
            
            case "typeCheckArms": return typeCheckArms;
            
            case "typeCheckArm": return typeCheckArm;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal findLoc = letrec.get("findLoc");
      
      ESLVal findType = letrec.get("findType");
      
      ESLVal decs = letrec.get("decs");
      
      ESLVal getMessageTypes = letrec.get("getMessageTypes");
      
      ESLVal getMessageType = letrec.get("getMessageType");
      
      ESLVal typeCheckArms = letrec.get("typeCheckArms");
      
      ESLVal typeCheckArm = letrec.get("typeCheckArm");
      
        {ESLVal parentType = ((Supplier<ESLVal>)() -> { 
            if(_v811.eql($null).boolVal)
              return actType0;
              else
                return expType.apply(_v811,_v806,_v805,_v804,_v803);
          }).get();
        ESLVal localEnv = parBind.apply(_v809,_v806,_v805,_v804,_v803);
        
        {ESLVal exportedDecs = decs.apply(_v810);
        
        {ESLVal messageTypes = getMessageTypes.apply(_v807);
        
        {ESLVal _v856 = new ESLVal("ExtendedAct",_v814,parentType,exportedDecs,messageTypes);
        ESLVal _v855 = ESLVal.list(new ESLVal("Map",new ESLVal("$super"),parentType));
        
        {typeCheckExports.apply(_v814,exportedDecs,_v809,_v856,localEnv.add(_v805),_v803,_v804);
      typeCheckValues.apply(valueDefs.apply(_v809),_v856,_v855.add(localEnv.add(_v805)),_v803,_v804);
      expType.apply(_v808,_v856,_v855.add(localEnv.add(_v805)),_v804,_v803);
      typeCheckArms.apply(_v807,_v856,_v855.add(localEnv.add(_v805)));
      return _v856;}
      }
      }
      }
      }
      
    }
  });
  private static ESLVal typeCheckExports = new ESLVal(new Function(new ESLVal("typeCheckExports"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v802 = $args[0];
  ESLVal _v801 = $args[1];
  ESLVal _v800 = $args[2];
  ESLVal _v799 = $args[3];
  ESLVal _v798 = $args[4];
  ESLVal _v797 = $args[5];
  ESLVal _v796 = $args[6];
  {{
        ESLVal _v79 = _v801;
        while(_v79.isCons()) {
          ESLVal e = _v79.headVal;
          if(exists.apply(new ESLVal(new Function(new ESLVal("fun518"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal b = $args[0];
          return bindingName.apply(b).eql(decName.apply(e)).and(typeEqual.apply(lookupType.apply(decName.apply(e),_v798),decType.apply(e)));
            }
          }),_v800).boolVal)
            {}
            else
              error(new ESLVal("TypeError",_v802,new ESLVal(" cannot find export for ").add(decName.apply(e))));
          _v79 = _v79.tailVal;}
      }
      return $null;}
    }
  });
  private static ESLVal bTypeExports = new ESLVal(new Function(new ESLVal("bTypeExports"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v78 = t;
        
        switch(_v78.termName) {
        case "ExtendedAct": {ESLVal $379 = _v78.termRef(0);
          ESLVal $378 = _v78.termRef(1);
          ESLVal $377 = _v78.termRef(2);
          ESLVal $376 = _v78.termRef(3);
          
          {ESLVal l = $379;
          
          {ESLVal parent = $378;
          
          {ESLVal exports = $377;
          
          {ESLVal message = $376;
          
          return bTypeExports.apply(parent).add(exports);
        }
        }
        }
        }
        }
      case "ActType": {ESLVal $375 = _v78.termRef(0);
          ESLVal $374 = _v78.termRef(1);
          ESLVal $373 = _v78.termRef(2);
          
          {ESLVal l = $375;
          
          {ESLVal exports = $374;
          
          {ESLVal message = $373;
          
          return exports;
        }
        }
        }
        }
      case "TypeClosure": {ESLVal $372 = _v78.termRef(0);
          
          {ESLVal f = $372;
          
          return bTypeExports.apply(f.apply());
        }
        }
      case "RecType": {ESLVal $371 = _v78.termRef(0);
          ESLVal $370 = _v78.termRef(1);
          ESLVal $369 = _v78.termRef(2);
          
          {ESLVal l = $371;
          
          {ESLVal n = $370;
          
          {ESLVal _v795 = $369;
          
          return bTypeExports.apply(substType.apply(new ESLVal("RecType",l,n,_v795),n,_v795));
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(33996,34406)").add(ESLVal.list(_v78)));
      }
      }
    }
  });
  private static ESLVal cmpType = new ESLVal(new Function(new ESLVal("cmpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v787 = $args[0];
  ESLVal _v786 = $args[1];
  ESLVal _v785 = $args[2];
  ESLVal _v784 = $args[3];
  ESLVal _v783 = $args[4];
  ESLVal _v782 = $args[5];
  ESLVal _v781 = $args[6];
  {ESLVal _v76 = _v785;
        
        if(_v76.isCons())
        {ESLVal $360 = _v76.head();
          ESLVal $361 = _v76.tail();
          
          switch($360.termName) {
          case "BQual": {ESLVal $366 = $360.termRef(0);
            ESLVal $365 = $360.termRef(1);
            ESLVal $364 = $360.termRef(2);
            
            {ESLVal _v790 = $366;
            
            {ESLVal p = $365;
            
            {ESLVal list = $364;
            
            {ESLVal _v791 = $361;
            
            {ESLVal lType = expType.apply(list,_v784,_v783,_v782,_v781);
            
            {ESLVal _v77 = lType;
            
            switch(_v77.termName) {
            case "ListType": {ESLVal $368 = _v77.termRef(0);
              ESLVal $367 = _v77.termRef(1);
              
              {ESLVal ll = $368;
              
              {ESLVal t = $367;
              
              {ESLVal _v792 = _v791;
              
              return patternType.apply(_v790,p,substTypeEnv.apply(_v781,t),_v784,_v783,_v782,_v781,new ESLVal(new Function(new ESLVal("fun519"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal _v794 = $args[0];
              ESLVal _v793 = $args[1];
              return cmpType.apply(_v790,_v786,_v792,_v784,_v793,_v782,_v781);
                }
              }));
            }
            }
            }
            }
            default: {ESLVal t = _v77;
              
              return error(new ESLVal("TypeError",_v790,new ESLVal("qualifier binding expects a list: ").add(ppType.apply(t,_v781))));
            }
          }
          }
          }
          }
          }
          }
          }
          }
        case "PQual": {ESLVal $363 = $360.termRef(0);
            ESLVal $362 = $360.termRef(1);
            
            {ESLVal _v788 = $363;
            
            {ESLVal b = $362;
            
            {ESLVal _v789 = $361;
            
            {ESLVal bType = expType.apply(b,_v784,_v783,_v782,_v781);
            
            if(isBoolType.apply(bType).boolVal)
            return cmpType.apply(_v788,_v786,_v789,_v784,_v783,_v782,_v781);
            else
              return error(new ESLVal("TypeError",_v788,new ESLVal("qualifier expects a boolean type: ").add(ppType.apply(bType,_v781))));
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(34517,35503)").add(ESLVal.list(_v76)));
        }
        }
      else if(_v76.isNil())
        {ESLVal t = expType.apply(_v786,_v784,_v783,_v782,_v781);
          
          return new ESLVal("ListType",_v787,t);
        }
      else return error(new ESLVal("case error at Pos(34517,35503)").add(ESLVal.list(_v76)));
      }
    }
  });
  private static ESLVal updateType = new ESLVal(new Function(new ESLVal("updateType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v780 = $args[0];
  ESLVal _v779 = $args[1];
  ESLVal _v778 = $args[2];
  ESLVal _v777 = $args[3];
  ESLVal _v776 = $args[4];
  ESLVal _v775 = $args[5];
  ESLVal _v774 = $args[6];
  {ESLVal t = lookupType.apply(_v779,_v776);
        
        if(t.eql($null).boolVal)
        return error(new ESLVal("TypeError",_v780,new ESLVal("unbound variable ").add(_v779)));
        else
          {ESLVal valueType = expType.apply(_v778,_v777,_v776,_v775,_v774);
            
            if(typeEqual.apply(valueType,t).boolVal)
            return valueType;
            else
              return error(new ESLVal("TypeError",_v780,new ESLVal("type of variable ").add(_v779.add(new ESLVal("::").add(ppType.apply(t,_v774).add(new ESLVal(" does not agree with value type ").add(ppType.apply(valueType,_v774))))))));
          }
      }
    }
  });
  private static ESLVal letType = new ESLVal(new Function(new ESLVal("letType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v773 = $args[0];
  ESLVal _v772 = $args[1];
  ESLVal _v771 = $args[2];
  ESLVal _v770 = $args[3];
  ESLVal _v769 = $args[4];
  ESLVal _v768 = $args[5];
  ESLVal _v767 = $args[6];
  {ESLVal env = parBind.apply(_v772,_v770,_v769,_v768,_v767);
        
        {{
        ESLVal _v75 = _v772;
        while(_v75.isCons()) {
          ESLVal b = _v75.headVal;
          typeCheckDef.apply(b,_v770,_v769,env.add(_v769),_v768,_v767);
          _v75 = _v75.tailVal;}
      }
      return expType.apply(_v771,_v770,env.add(_v769),_v768,_v767);}
      }
    }
  });
  private static ESLVal letrecType = new ESLVal(new Function(new ESLVal("letrecType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v766 = $args[0];
  ESLVal _v765 = $args[1];
  ESLVal _v764 = $args[2];
  ESLVal _v763 = $args[3];
  ESLVal _v762 = $args[4];
  ESLVal _v761 = $args[5];
  ESLVal _v760 = $args[6];
  {ESLVal env = recBind.apply(_v765,_v763,_v762,_v761,_v760);
        
        {{
        ESLVal _v74 = _v765;
        while(_v74.isCons()) {
          ESLVal b = _v74.headVal;
          typeCheckDef.apply(b,_v763,env.add(_v762),env.add(_v762),_v761,_v760);
          _v74 = _v74.tailVal;}
      }
      return expType.apply(_v764,_v763,env.add(_v762),_v761,_v760);}
      }
    }
  });
  private static ESLVal checkDupBindings = new ESLVal(new Function(new ESLVal("checkDupBindings"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal bs = $args[0];
  {ESLVal _v72 = bs;
        
        if(_v72.isCons())
        {ESLVal $358 = _v72.head();
          ESLVal $359 = _v72.tail();
          
          {ESLVal b = $358;
          
          {ESLVal _v758 = $359;
          
          if(member.apply(bindingName.apply(b),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v73 = $qualArg;
              
              {ESLVal _v759 = _v73;
              
              return ESLVal.list(ESLVal.list(bindingName.apply(_v759)));
            }
            }
          }
        }).map(_v758).flatten().flatten()).boolVal)
          return error(new ESLVal("TypeError",bindingLoc.apply(b),new ESLVal("duplicate definitions for ").add(bindingName.apply(b))));
          else
            return checkDupBindings.apply(_v758);
        }
        }
        }
      else if(_v72.isNil())
        return $null;
      else return error(new ESLVal("case error at Pos(36751,37016)").add(ESLVal.list(_v72)));
      }
    }
  });
  private static ESLVal parBind = new ESLVal(new Function(new ESLVal("parBind"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v757 = $args[0];
  ESLVal _v756 = $args[1];
  ESLVal _v755 = $args[2];
  ESLVal _v754 = $args[3];
  ESLVal _v753 = $args[4];
  {checkDupBindings.apply(_v757);
      return valueDefsToTEnv.apply(valueDefs.apply(_v757),_v756,_v755,_v754,_v753);}
    }
  });
  private static ESLVal recBind = new ESLVal(new Function(new ESLVal("recBind"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v752 = $args[0];
  ESLVal _v751 = $args[1];
  ESLVal _v750 = $args[2];
  ESLVal _v749 = $args[3];
  ESLVal _v748 = $args[4];
  return valueDefsToTEnv.apply(valueDefs.apply(_v752),_v751,_v750,_v749,_v748);
    }
  });
  private static ESLVal caseType = new ESLVal(new Function(new ESLVal("caseType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v747 = $args[0];
  ESLVal _v746 = $args[1];
  ESLVal _v745 = $args[2];
  ESLVal _v744 = $args[3];
  ESLVal _v743 = $args[4];
  ESLVal _v742 = $args[5];
  ESLVal _v741 = $args[6];
  {ESLVal ts1 = expTypes.apply(_v746,_v744,_v743,_v742,_v741);
        
        {ESLVal ts2 = armTypes.apply(_v745,ts1,_v744,_v743,_v742,_v741);
        
        if(allEqualTypes.apply(head.apply(ts2),tail.apply(ts2)).boolVal)
        return head.apply(ts2);
        else
          return error(new ESLVal("TypeError",_v747,new ESLVal("case arm types do not agree: ").add(ppTypes.apply(ts1,_v741).add(new ESLVal(" ").add(ppTypes.apply(ts2,_v741))))));
      }
      }
    }
  });
  private static ESLVal tryType = new ESLVal(new Function(new ESLVal("tryType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v740 = $args[0];
  ESLVal _v739 = $args[1];
  ESLVal _v738 = $args[2];
  ESLVal _v737 = $args[3];
  ESLVal _v736 = $args[4];
  ESLVal _v735 = $args[5];
  ESLVal _v734 = $args[6];
  {ESLVal ts1 = expTypes.apply(ESLVal.list(_v739),_v737,_v736,_v735,_v734);
        
        {ESLVal ts2 = armTypes.apply(_v738,ts1,_v737,_v736,_v735,_v734);
        
        if(allEqualTypes.apply(head.apply(ts2),tail.apply(ts2)).boolVal)
        return head.apply(ts2);
        else
          return error(new ESLVal("TypeError",_v740,new ESLVal("try arm types do not agree: ").add(ppTypes.apply(ts1,_v734).add(new ESLVal(" ").add(ppTypes.apply(ts2,_v734))))));
      }
      }
    }
  });
  private static ESLVal armTypes = new ESLVal(new Function(new ESLVal("armTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v732 = $args[0];
  ESLVal _v731 = $args[1];
  ESLVal _v730 = $args[2];
  ESLVal _v729 = $args[3];
  ESLVal _v728 = $args[4];
  ESLVal _v727 = $args[5];
  {ESLVal _v71 = _v732;
        
        if(_v71.isCons())
        {ESLVal $356 = _v71.head();
          ESLVal $357 = _v71.tail();
          
          {ESLVal a = $356;
          
          {ESLVal _v733 = $357;
          
          return armTypes.apply(_v733,_v731,_v730,_v729,_v728,_v727).cons(armType.apply(a,_v731,_v730,_v729,_v728,_v727));
        }
        }
        }
      else if(_v71.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(38381,38550)").add(ESLVal.list(_v71)));
      }
    }
  });
  private static ESLVal armType = new ESLVal(new Function(new ESLVal("armType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v724 = $args[0];
  ESLVal _v723 = $args[1];
  ESLVal _v722 = $args[2];
  ESLVal _v721 = $args[3];
  ESLVal _v720 = $args[4];
  ESLVal _v719 = $args[5];
  {ESLVal _v70 = _v724;
        
        switch(_v70.termName) {
        case "BArm": {ESLVal $355 = _v70.termRef(0);
          ESLVal $354 = _v70.termRef(1);
          ESLVal $353 = _v70.termRef(2);
          ESLVal $352 = _v70.termRef(3);
          
          {ESLVal l = $355;
          
          {ESLVal ps = $354;
          
          {ESLVal guard = $353;
          
          {ESLVal exp = $352;
          
          {checkPatterns.apply(l,ps);
        if(length.apply(ps).eql(length.apply(_v723)).boolVal)
          return patternTypes.apply(l,ps,_v723,_v722,_v721,_v720,_v719,new ESLVal(new Function(new ESLVal("fun520"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v726 = $args[0];
            ESLVal _v725 = $args[1];
            return guardedExpType.apply(l,guard,exp,_v722,_v725,_v720,_v719);
              }
            }));
          else
            return error(new ESLVal("TypeError",l,new ESLVal("number of patterns ").add(length.apply(ps).add(new ESLVal(" does not match supplied values: ").add(length.apply(_v723))))));}
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(38652,39113)").add(ESLVal.list(_v70)));
      }
      }
    }
  });
  private static ESLVal refType = new ESLVal(new Function(new ESLVal("refType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v689 = $args[0];
  ESLVal _v688 = $args[1];
  ESLVal _v687 = $args[2];
  ESLVal _v686 = $args[3];
  ESLVal _v685 = $args[4];
  ESLVal _v684 = $args[5];
  ESLVal _v683 = $args[6];
  LetRec letrec = new LetRec() {
        ESLVal t = derefType.apply(expType.apply(_v688,_v686,_v685,_v684,_v683));
        ESLVal findExport = new ESLVal(new Function(new ESLVal("findExport"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal decs = $args[0];
          {ESLVal _v68 = decs;
                
                if(_v68.isCons())
                {ESLVal $335 = _v68.head();
                  ESLVal $336 = _v68.tail();
                  
                  switch($335.termName) {
                  case "Dec": {ESLVal $340 = $335.termRef(0);
                    ESLVal $339 = $335.termRef(1);
                    ESLVal $338 = $335.termRef(2);
                    ESLVal $337 = $335.termRef(3);
                    
                    {ESLVal _v695 = $340;
                    
                    {ESLVal m = $339;
                    
                    {ESLVal t = $338;
                    
                    {ESLVal st = $337;
                    
                    {ESLVal _v696 = $336;
                    
                    if(m.eql(_v687).boolVal)
                    return t;
                    else
                      {ESLVal d = $335;
                        
                        {ESLVal _v697 = $336;
                        
                        return findExport.apply(_v697);
                      }
                      }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal d = $335;
                    
                    {ESLVal _v698 = $336;
                    
                    return findExport.apply(_v698);
                  }
                  }
                }
                }
              else if(_v68.isNil())
                return $null;
              else return error(new ESLVal("case error at Pos(39341,39514)").add(ESLVal.list(_v68)));
              }
            }
          });
        ESLVal findField = new ESLVal(new Function(new ESLVal("findField"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal fs = $args[0];
          {ESLVal _v67 = fs;
                
                if(_v67.isCons())
                {ESLVal $329 = _v67.head();
                  ESLVal $330 = _v67.tail();
                  
                  switch($329.termName) {
                  case "Dec": {ESLVal $334 = $329.termRef(0);
                    ESLVal $333 = $329.termRef(1);
                    ESLVal $332 = $329.termRef(2);
                    ESLVal $331 = $329.termRef(3);
                    
                    {ESLVal _v690 = $334;
                    
                    {ESLVal m = $333;
                    
                    {ESLVal t = $332;
                    
                    {ESLVal ds = $331;
                    
                    {ESLVal _v691 = $330;
                    
                    if(m.eql(_v687).boolVal)
                    return t;
                    else
                      {ESLVal _v692 = $329;
                        
                        {ESLVal _v693 = $330;
                        
                        return findField.apply(_v693);
                      }
                      }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal t = $329;
                    
                    {ESLVal _v694 = $330;
                    
                    return findField.apply(_v694);
                  }
                  }
                }
                }
              else if(_v67.isNil())
                return error(new ESLVal("TypeError",_v689,new ESLVal("cannot find field name ").add(_v687)));
              else return error(new ESLVal("case error at Pos(39555,39763)").add(ESLVal.list(_v67)));
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "t": return t;
            
            case "findExport": return findExport;
            
            case "findField": return findField;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal t = letrec.get("t");
      
      ESLVal findExport = letrec.get("findExport");
      
      ESLVal findField = letrec.get("findField");
      
        {ESLVal _v69 = typeNF.apply(t,_v683);
        
        switch(_v69.termName) {
        case "StrType": {ESLVal $351 = _v69.termRef(0);
          
          {ESLVal sl = $351;
          
          if(_v687.eql(new ESLVal("explode")).boolVal)
          return new ESLVal("ListType",sl,new ESLVal("IntType",sl));
          else
            {ESLVal _v716 = $351;
              
              if(_v687.eql(new ESLVal("writeDate")).boolVal)
              return new ESLVal("FloatType",_v716);
              else
                {ESLVal _v717 = _v69;
                  
                  return error(new ESLVal("TypeError",_v689,new ESLVal("expecting a record type, but received ").add(ppType.apply(_v717,_v683))));
                }
            }
        }
        }
      case "TableType": {ESLVal $350 = _v69.termRef(0);
          ESLVal $349 = _v69.termRef(1);
          ESLVal $348 = _v69.termRef(2);
          
          {ESLVal _v702 = $350;
          
          {ESLVal k = $349;
          
          {ESLVal v = $348;
          
          if(_v687.eql(new ESLVal("get")).boolVal)
          return new ESLVal("FunType",_v702,ESLVal.list(k),v);
          else
            {ESLVal _v703 = $350;
              
              {ESLVal _v704 = $349;
              
              {ESLVal _v705 = $348;
              
              if(_v687.eql(new ESLVal("put")).boolVal)
              return new ESLVal("FunType",_v703,ESLVal.list(_v704,_v705),t);
              else
                {ESLVal _v706 = $350;
                  
                  {ESLVal _v707 = $349;
                  
                  {ESLVal _v708 = $348;
                  
                  if(_v687.eql(new ESLVal("keys")).boolVal)
                  return new ESLVal("ListType",_v706,_v707);
                  else
                    {ESLVal _v709 = $350;
                      
                      {ESLVal _v710 = $349;
                      
                      {ESLVal _v711 = $348;
                      
                      if(_v687.eql(new ESLVal("vals")).boolVal)
                      return new ESLVal("ListType",_v709,_v711);
                      else
                        {ESLVal _v712 = $350;
                          
                          {ESLVal _v713 = $349;
                          
                          {ESLVal _v714 = $348;
                          
                          if(_v687.eql(new ESLVal("hasKey")).boolVal)
                          return new ESLVal("FunType",_v712,ESLVal.list(_v713),new ESLVal("BoolType",_v712));
                          else
                            {ESLVal _v715 = _v69;
                              
                              return error(new ESLVal("TypeError",_v712,new ESLVal("expecting a record type, but received ").add(ppType.apply(_v715,_v683))));
                            }
                        }
                        }
                        }
                    }
                    }
                    }
                }
                }
                }
            }
            }
            }
        }
        }
        }
        }
      case "ListType": {ESLVal $347 = _v69.termRef(0);
          ESLVal $346 = _v69.termRef(1);
          
          {ESLVal ll = $347;
          
          {ESLVal _v700 = $346;
          
          if(_v687.eql(new ESLVal("implode")).boolVal)
          return new ESLVal("StrType",ll);
          else
            {ESLVal _v701 = _v69;
              
              return error(new ESLVal("TypeError",_v689,new ESLVal("expecting a record type, but received ").add(ppType.apply(_v701,_v683))));
            }
        }
        }
        }
      case "RecordType": {ESLVal $345 = _v69.termRef(0);
          ESLVal $344 = _v69.termRef(1);
          
          {ESLVal rl = $345;
          
          {ESLVal fs = $344;
          
          return findField.apply(fs);
        }
        }
        }
      case "ActType": {ESLVal $343 = _v69.termRef(0);
          ESLVal $342 = _v69.termRef(1);
          ESLVal $341 = _v69.termRef(2);
          
          {ESLVal al = $343;
          
          {ESLVal exports = $342;
          
          {ESLVal handlers = $341;
          
          {ESLVal _v699 = findExport.apply(exports);
          
          if(_v699.eql($null).boolVal)
          return error(new ESLVal("TypeError",_v689,new ESLVal("behaviour type does not export ").add(_v687)));
          else
            return substTypeEnv.apply(_v683,_v699);
        }
        }
        }
        }
        }
        default: {ESLVal _v718 = _v69;
          
          return error(new ESLVal("TypeError",_v689,new ESLVal("expecting a record type, but received ").add(ppType.apply(_v718,_v683))));
        }
      }
      }
      
    }
  });
  private static ESLVal derefType = new ESLVal(new Function(new ESLVal("derefType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v66 = t;
        
        switch(_v66.termName) {
        case "TypeClosure": {ESLVal $328 = _v66.termRef(0);
          
          {ESLVal f = $328;
          
          return derefType.apply(f.apply());
        }
        }
        default: {ESLVal _v682 = _v66;
          
          return _v682;
        }
      }
      }
    }
  });
  private static ESLVal recordType = new ESLVal(new Function(new ESLVal("recordType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v675 = $args[0];
  ESLVal _v674 = $args[1];
  ESLVal _v673 = $args[2];
  ESLVal _v672 = $args[3];
  ESLVal _v671 = $args[4];
  ESLVal _v670 = $args[5];
  LetRec letrec = new LetRec() {
        ESLVal fieldTypes = new ESLVal(new Function(new ESLVal("fieldTypes"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v676 = $args[0];
          {ESLVal _v65 = _v676;
                
                if(_v65.isCons())
                {ESLVal $321 = _v65.head();
                  ESLVal $322 = _v65.tail();
                  
                  switch($321.termName) {
                  case "Binding": {ESLVal $327 = $321.termRef(0);
                    ESLVal $326 = $321.termRef(1);
                    ESLVal $325 = $321.termRef(2);
                    ESLVal $324 = $321.termRef(3);
                    ESLVal $323 = $321.termRef(4);
                    
                    {ESLVal _v677 = $327;
                    
                    {ESLVal n = $326;
                    
                    {ESLVal t = $325;
                    
                    {ESLVal st = $324;
                    
                    {ESLVal e = $323;
                    
                    {ESLVal _v678 = $322;
                    
                    {ESLVal _v679 = expType.apply(e,_v673,_v672,_v671,_v670);
                    
                    return fieldTypes.apply(_v678).cons(new ESLVal("Dec",_v677,n,_v679,_v679));
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v680 = _v65;
                    
                    return error(new ESLVal("TypeError",_v675,new ESLVal("unknown field representation: ").add(_v680)));
                  }
                }
                }
              else if(_v65.isNil())
                return $nil;
              else {ESLVal _v681 = _v65;
                  
                  return error(new ESLVal("TypeError",_v675,new ESLVal("unknown field representation: ").add(_v681)));
                }
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "fieldTypes": return fieldTypes;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal fieldTypes = letrec.get("fieldTypes");
      
        return new ESLVal("RecordType",_v675,fieldTypes.apply(_v674));
      
    }
  });
  private static ESLVal forType = new ESLVal(new Function(new ESLVal("forType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v665 = $args[0];
  ESLVal _v664 = $args[1];
  ESLVal _v663 = $args[2];
  ESLVal _v662 = $args[3];
  ESLVal _v661 = $args[4];
  ESLVal _v660 = $args[5];
  ESLVal _v659 = $args[6];
  ESLVal _v658 = $args[7];
  {ESLVal _v666 = expType.apply(_v663,_v661,_v660,_v659,_v658);
        
        {ESLVal _v64 = _v666;
        
        switch(_v64.termName) {
        case "ListType": {ESLVal $320 = _v64.termRef(0);
          ESLVal $319 = _v64.termRef(1);
          
          {ESLVal _v667 = $320;
          
          {ESLVal t = $319;
          
          return patternType.apply(_v667,_v664,t,_v661,_v660,_v659,_v658,new ESLVal(new Function(new ESLVal("fun521"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v669 = $args[0];
          ESLVal _v668 = $args[1];
          return expType.apply(_v662,_v661,_v668,_v659,_v658);
            }
          }));
        }
        }
        }
        default: {ESLVal t = _v64;
          
          return error(new ESLVal("TypeError",_v665,new ESLVal("for type expects a list: ").add(_v663)));
        }
      }
      }
      }
    }
  });
  private static ESLVal patternTypes = new ESLVal(new Function(new ESLVal("patternTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v639 = $args[0];
  ESLVal _v638 = $args[1];
  ESLVal _v637 = $args[2];
  ESLVal _v636 = $args[3];
  ESLVal _v635 = $args[4];
  ESLVal _v634 = $args[5];
  ESLVal _v633 = $args[6];
  ESLVal _v632 = $args[7];
  {ESLVal _v63 = _v638;
        ESLVal _v62 = _v637;
        
        if(_v63.isCons())
        {ESLVal $313 = _v63.head();
          ESLVal $314 = _v63.tail();
          
          if(_v62.isCons())
          {ESLVal $315 = _v62.head();
            ESLVal $316 = _v62.tail();
            
            {ESLVal p = $313;
            
            {ESLVal _v640 = $314;
            
            {ESLVal t = $315;
            
            {ESLVal _v641 = $316;
            
            {ESLVal _v643 = _v640;
            ESLVal _v642 = _v641;
            
            return patternType.apply(_v639,p,t,_v636,_v635,_v634,_v633,new ESLVal(new Function(new ESLVal("fun522"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v645 = $args[0];
            ESLVal _v644 = $args[1];
            return patternTypes.apply(_v639,_v643,_v642,_v636,_v644,_v634,_v633,new ESLVal(new Function(new ESLVal("fun523"),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      ESLVal _v647 = $args[0];
                  ESLVal _v646 = $args[1];
                  return _v632.apply(_v647.cons(_v645),_v646);
                    }
                  }));
              }
            }));
          }
          }
          }
          }
          }
          }
        else if(_v62.isNil())
          {ESLVal _v648 = _v63;
            
            {ESLVal _v649 = _v62;
            
            return error(new ESLVal("TypeError",_v639,new ESLVal("somthing wrong with ").add(_v648.add(new ESLVal(" ").add(_v649)))));
          }
          }
        else {ESLVal _v650 = _v63;
            
            {ESLVal _v651 = _v62;
            
            return error(new ESLVal("TypeError",_v639,new ESLVal("somthing wrong with ").add(_v650.add(new ESLVal(" ").add(_v651)))));
          }
          }
        }
      else if(_v63.isNil())
        if(_v62.isCons())
          {ESLVal $317 = _v62.head();
            ESLVal $318 = _v62.tail();
            
            {ESLVal _v652 = _v63;
            
            {ESLVal _v653 = _v62;
            
            return error(new ESLVal("TypeError",_v639,new ESLVal("somthing wrong with ").add(_v652.add(new ESLVal(" ").add(_v653)))));
          }
          }
          }
        else if(_v62.isNil())
          return _v632.apply($nil,_v635);
        else {ESLVal _v654 = _v63;
            
            {ESLVal _v655 = _v62;
            
            return error(new ESLVal("TypeError",_v639,new ESLVal("somthing wrong with ").add(_v654.add(new ESLVal(" ").add(_v655)))));
          }
          }
      else {ESLVal _v656 = _v63;
          
          {ESLVal _v657 = _v62;
          
          return error(new ESLVal("TypeError",_v639,new ESLVal("somthing wrong with ").add(_v656.add(new ESLVal(" ").add(_v657)))));
        }
        }
      }
    }
  });
  private static ESLVal getPatternType = new ESLVal(new Function(new ESLVal("getPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v616 = $args[0];
  ESLVal _v615 = $args[1];
  ESLVal _v614 = $args[2];
  ESLVal _v613 = $args[3];
  ESLVal _v612 = $args[4];
  ESLVal _v611 = $args[5];
  {ESLVal _v61 = _v615;
        
        switch(_v61.termName) {
        case "PApplyType": {ESLVal $312 = _v61.termRef(0);
          ESLVal $311 = _v61.termRef(1);
          ESLVal $310 = _v61.termRef(2);
          
          {ESLVal _v629 = $312;
          
          {ESLVal _v630 = $311;
          
          {ESLVal args = $310;
          
          return error(new ESLVal("should this happen?"));
        }
        }
        }
        }
      case "PBool": {ESLVal $309 = _v61.termRef(0);
          ESLVal $308 = _v61.termRef(1);
          
          {ESLVal _v628 = $309;
          
          {ESLVal b = $308;
          
          return new ESLVal("BoolType",_v628);
        }
        }
        }
      case "PCons": {ESLVal $307 = _v61.termRef(0);
          ESLVal $306 = _v61.termRef(1);
          ESLVal $305 = _v61.termRef(2);
          
          {ESLVal _v627 = $307;
          
          {ESLVal hd = $306;
          
          {ESLVal tl = $305;
          
          return getPatternType.apply(_v627,tl,_v614,_v613,_v612,_v611);
        }
        }
        }
        }
      case "PBagCons": {ESLVal $304 = _v61.termRef(0);
          ESLVal $303 = _v61.termRef(1);
          ESLVal $302 = _v61.termRef(2);
          
          {ESLVal _v626 = $304;
          
          {ESLVal hd = $303;
          
          {ESLVal tl = $302;
          
          return getPatternType.apply(_v626,tl,_v614,_v613,_v612,_v611);
        }
        }
        }
        }
      case "PSetCons": {ESLVal $301 = _v61.termRef(0);
          ESLVal $300 = _v61.termRef(1);
          ESLVal $299 = _v61.termRef(2);
          
          {ESLVal _v625 = $301;
          
          {ESLVal hd = $300;
          
          {ESLVal tl = $299;
          
          return getPatternType.apply(_v625,tl,_v614,_v613,_v612,_v611);
        }
        }
        }
        }
      case "PNil": {ESLVal $298 = _v61.termRef(0);
          
          {ESLVal _v624 = $298;
          
          return new ESLVal("ForallType",_v624,ESLVal.list(new ESLVal("T")),new ESLVal("ListType",_v624,new ESLVal("VarType",_v624,new ESLVal("T"))));
        }
        }
      case "PNull": {ESLVal $297 = _v61.termRef(0);
          
          {ESLVal _v623 = $297;
          
          return new ESLVal("ForallType",_v623,ESLVal.list(new ESLVal("T")),new ESLVal("VarType",_v623,new ESLVal("T")));
        }
        }
      case "PEmptyBag": {ESLVal $296 = _v61.termRef(0);
          
          {ESLVal _v622 = $296;
          
          return new ESLVal("ForallType",_v622,ESLVal.list(new ESLVal("T")),new ESLVal("BagType",_v622,new ESLVal("VarType",_v622,new ESLVal("T"))));
        }
        }
      case "PEmptySet": {ESLVal $295 = _v61.termRef(0);
          
          {ESLVal _v621 = $295;
          
          return new ESLVal("ForallType",_v621,ESLVal.list(new ESLVal("T")),new ESLVal("SetType",_v621,new ESLVal("VarType",_v621,new ESLVal("T"))));
        }
        }
      case "PInt": {ESLVal $294 = _v61.termRef(0);
          ESLVal $293 = _v61.termRef(1);
          
          {ESLVal _v620 = $294;
          
          {ESLVal n = $293;
          
          return new ESLVal("IntType",_v620);
        }
        }
        }
      case "PVar": {ESLVal $292 = _v61.termRef(0);
          ESLVal $291 = _v61.termRef(1);
          ESLVal $290 = _v61.termRef(2);
          
          {ESLVal _v619 = $292;
          
          {ESLVal n = $291;
          
          {ESLVal pt = $290;
          
          return substTypeEnv.apply(_v611,pt);
        }
        }
        }
        }
      case "PStr": {ESLVal $289 = _v61.termRef(0);
          ESLVal $288 = _v61.termRef(1);
          
          {ESLVal _v618 = $289;
          
          {ESLVal s = $288;
          
          return new ESLVal("StrType",_v618);
        }
        }
        }
      case "PTerm": {ESLVal $287 = _v61.termRef(0);
          ESLVal $286 = _v61.termRef(1);
          ESLVal $285 = _v61.termRef(2);
          ESLVal $284 = _v61.termRef(3);
          
          {ESLVal _v617 = $287;
          
          {ESLVal n = $286;
          
          {ESLVal ts = $285;
          
          {ESLVal ps = $284;
          
          return lookupType.apply(n,_v612);
        }
        }
        }
        }
        }
        default: {ESLVal _v631 = _v61;
          
          return error(new ESLVal("TypeError",_v616,new ESLVal("unknown type of pattern: ").add(_v631)));
        }
      }
      }
    }
  });
  private static ESLVal patternType = new ESLVal(new Function(new ESLVal("patternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v588 = $args[0];
  ESLVal _v587 = $args[1];
  ESLVal _v586 = $args[2];
  ESLVal _v585 = $args[3];
  ESLVal _v584 = $args[4];
  ESLVal _v583 = $args[5];
  ESLVal _v582 = $args[6];
  ESLVal _v581 = $args[7];
  {ESLVal _v60 = _v587;
        
        switch(_v60.termName) {
        case "PAdd": {ESLVal $283 = _v60.termRef(0);
          ESLVal $282 = _v60.termRef(1);
          ESLVal $281 = _v60.termRef(2);
          
          {ESLVal _v609 = $283;
          
          {ESLVal p1 = $282;
          
          {ESLVal p2 = $281;
          
          return addPatternType.apply(_v609,p1,p2,_v586,_v585,_v584,_v583,_v582,_v581);
        }
        }
        }
        }
      case "PApplyType": {ESLVal $280 = _v60.termRef(0);
          ESLVal $279 = _v60.termRef(1);
          ESLVal $278 = _v60.termRef(2);
          
          {ESLVal _v607 = $280;
          
          {ESLVal _v608 = $279;
          
          {ESLVal args = $278;
          
          return applyTypePatternType.apply(_v607,_v608,substTypesEnv.apply(_v582,args),_v586,_v585,_v584,_v583,_v582,_v581);
        }
        }
        }
        }
      case "PBool": {ESLVal $277 = _v60.termRef(0);
          ESLVal $276 = _v60.termRef(1);
          
          {ESLVal _v606 = $277;
          
          {ESLVal b = $276;
          
          if(isBoolType.apply(_v586).boolVal)
          return _v581.apply(new ESLVal("BoolType",_v606),_v584);
          else
            return error(new ESLVal("TypeError",_v606,new ESLVal("type mismatch: Bool and ").add(ppType.apply(_v586,_v582))));
        }
        }
        }
      case "PBagCons": {ESLVal $275 = _v60.termRef(0);
          ESLVal $274 = _v60.termRef(1);
          ESLVal $273 = _v60.termRef(2);
          
          {ESLVal _v603 = $275;
          
          {ESLVal hd = $274;
          
          {ESLVal tl = $273;
          
          return bagConsPatternType.apply(_v603,hd,tl,_v586,_v585,_v584,_v583,_v582,new ESLVal(new Function(new ESLVal("fun524"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v605 = $args[0];
          ESLVal _v604 = $args[1];
          return _v581.apply(new ESLVal("ListType",_v603,_v605),_v604);
            }
          }));
        }
        }
        }
        }
      case "PSetCons": {ESLVal $272 = _v60.termRef(0);
          ESLVal $271 = _v60.termRef(1);
          ESLVal $270 = _v60.termRef(2);
          
          {ESLVal _v600 = $272;
          
          {ESLVal hd = $271;
          
          {ESLVal tl = $270;
          
          return setConsPatternType.apply(_v600,hd,tl,_v586,_v585,_v584,_v583,_v582,new ESLVal(new Function(new ESLVal("fun525"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v602 = $args[0];
          ESLVal _v601 = $args[1];
          return _v581.apply(new ESLVal("ListType",_v600,_v602),_v601);
            }
          }));
        }
        }
        }
        }
      case "PCons": {ESLVal $269 = _v60.termRef(0);
          ESLVal $268 = _v60.termRef(1);
          ESLVal $267 = _v60.termRef(2);
          
          {ESLVal _v597 = $269;
          
          {ESLVal hd = $268;
          
          {ESLVal tl = $267;
          
          return consPatternType.apply(_v597,hd,tl,_v586,_v585,_v584,_v583,_v582,new ESLVal(new Function(new ESLVal("fun526"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v599 = $args[0];
          ESLVal _v598 = $args[1];
          return _v581.apply(new ESLVal("ListType",_v597,_v599),_v598);
            }
          }));
        }
        }
        }
        }
      case "PNil": {ESLVal $266 = _v60.termRef(0);
          
          {ESLVal _v596 = $266;
          
          return nilType.apply(_v596,_v586,_v585,_v584,_v583,_v582,_v581);
        }
        }
      case "PNull": {ESLVal $265 = _v60.termRef(0);
          
          {ESLVal _v595 = $265;
          
          return _v581.apply(_v586,_v584);
        }
        }
      case "PEmptyBag": {ESLVal $264 = _v60.termRef(0);
          
          {ESLVal _v594 = $264;
          
          return emptyBagType.apply(_v594,_v586,_v585,_v584,_v583,_v582,_v581);
        }
        }
      case "PEmptySet": {ESLVal $263 = _v60.termRef(0);
          
          {ESLVal _v593 = $263;
          
          return emptySetType.apply(_v593,_v586,_v585,_v584,_v583,_v582,_v581);
        }
        }
      case "PInt": {ESLVal $262 = _v60.termRef(0);
          ESLVal $261 = _v60.termRef(1);
          
          {ESLVal _v592 = $262;
          
          {ESLVal n = $261;
          
          if(isIntType.apply(_v586).boolVal)
          return _v581.apply(new ESLVal("IntType",_v592),_v584);
          else
            return error(new ESLVal("TypeError",_v592,new ESLVal("type mismatch: Int and ").add(ppType.apply(_v586,_v582))));
        }
        }
        }
      case "PVar": {ESLVal $260 = _v60.termRef(0);
          ESLVal $259 = _v60.termRef(1);
          ESLVal $258 = _v60.termRef(2);
          
          {ESLVal _v591 = $260;
          
          {ESLVal n = $259;
          
          {ESLVal pt = $258;
          
          return _v581.apply(_v586,ESLVal.list(new ESLVal("Map",n,_v586)).add(_v584));
        }
        }
        }
        }
      case "PStr": {ESLVal $257 = _v60.termRef(0);
          ESLVal $256 = _v60.termRef(1);
          
          {ESLVal _v590 = $257;
          
          {ESLVal s = $256;
          
          if(isStrType.apply(_v586).boolVal)
          return _v581.apply(new ESLVal("StrType",_v590),_v584);
          else
            return error(new ESLVal("TypeError",_v590,new ESLVal("type mismatch: Str and ").add(ppType.apply(_v586,_v582))));
        }
        }
        }
      case "PTerm": {ESLVal $255 = _v60.termRef(0);
          ESLVal $254 = _v60.termRef(1);
          ESLVal $253 = _v60.termRef(2);
          ESLVal $252 = _v60.termRef(3);
          
          {ESLVal _v589 = $255;
          
          {ESLVal n = $254;
          
          {ESLVal ts = $253;
          
          {ESLVal ps = $252;
          
          return termPatternType.apply(_v589,n,substTypesEnv.apply(_v582,ts),ps,_v586,_v585,_v584,_v583,_v582,_v581);
        }
        }
        }
        }
        }
        default: {ESLVal _v610 = _v60;
          
          return error(new ESLVal("TypeError",_v588,new ESLVal("unknown type of pattern: ").add(_v610)));
        }
      }
      }
    }
  });
  private static ESLVal addPatternType = new ESLVal(new Function(new ESLVal("addPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v551 = $args[0];
  ESLVal _v550 = $args[1];
  ESLVal _v549 = $args[2];
  ESLVal _v548 = $args[3];
  ESLVal _v547 = $args[4];
  ESLVal _v546 = $args[5];
  ESLVal _v545 = $args[6];
  ESLVal _v544 = $args[7];
  ESLVal _v543 = $args[8];
  return patternType.apply(_v551,_v550,_v548,_v547,_v546,_v545,_v544,new ESLVal(new Function(new ESLVal("fun527"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v553 = $args[0];
        ESLVal _v552 = $args[1];
        return patternType.apply(_v551,_v549,_v548,_v547,_v552,_v545,_v544,new ESLVal(new Function(new ESLVal("fun528"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal _v555 = $args[0];
              ESLVal _v554 = $args[1];
              {ESLVal _v57 = _v548;
                    
                    switch(_v57.termName) {
                    case "ListType": {ESLVal $214 = _v57.termRef(0);
                      ESLVal $213 = _v57.termRef(1);
                      
                      {ESLVal tl = $214;
                      
                      {ESLVal t = $213;
                      
                      {ESLVal _v59 = _v550;
                      ESLVal _v58 = _v549;
                      
                      switch(_v59.termName) {
                      case "PCons": {ESLVal $247 = _v59.termRef(0);
                        ESLVal $246 = _v59.termRef(1);
                        ESLVal $245 = _v59.termRef(2);
                        
                        switch($245.termName) {
                        case "PNil": {ESLVal $248 = $245.termRef(0);
                          
                          switch(_v58.termName) {
                          case "PVar": {ESLVal $251 = _v58.termRef(0);
                            ESLVal $250 = _v58.termRef(1);
                            ESLVal $249 = _v58.termRef(2);
                            
                            {ESLVal l1 = $247;
                            
                            {ESLVal p = $246;
                            
                            {ESLVal l3 = $248;
                            
                            {ESLVal l4 = $251;
                            
                            {ESLVal n2 = $250;
                            
                            {ESLVal t2 = $249;
                            
                            return _v543.apply(_v548,_v554);
                          }
                          }
                          }
                          }
                          }
                          }
                          }
                          default: {ESLVal _v575 = _v59;
                            
                            {ESLVal _v576 = _v58;
                            
                            return error(new ESLVal("TypeError",_v551,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                          }
                          }
                        }
                        }
                        default: {ESLVal _v577 = _v59;
                          
                          {ESLVal _v578 = _v58;
                          
                          return error(new ESLVal("TypeError",_v551,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                        }
                        }
                      }
                      }
                    case "PVar": {ESLVal $230 = _v59.termRef(0);
                        ESLVal $229 = _v59.termRef(1);
                        ESLVal $228 = _v59.termRef(2);
                        
                        switch(_v58.termName) {
                        case "PCons": {ESLVal $243 = _v58.termRef(0);
                          ESLVal $242 = _v58.termRef(1);
                          ESLVal $241 = _v58.termRef(2);
                          
                          switch($241.termName) {
                          case "PNil": {ESLVal $244 = $241.termRef(0);
                            
                            {ESLVal l1 = $230;
                            
                            {ESLVal n = $229;
                            
                            {ESLVal _v570 = $228;
                            
                            {ESLVal l2 = $243;
                            
                            {ESLVal p = $242;
                            
                            {ESLVal l3 = $244;
                            
                            return _v543.apply(_v548,_v554);
                          }
                          }
                          }
                          }
                          }
                          }
                          }
                          default: {ESLVal _v571 = _v59;
                            
                            {ESLVal _v572 = _v58;
                            
                            return error(new ESLVal("TypeError",_v551,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                          }
                          }
                        }
                        }
                      case "PAdd": {ESLVal $233 = _v58.termRef(0);
                          ESLVal $232 = _v58.termRef(1);
                          ESLVal $231 = _v58.termRef(2);
                          
                          switch($232.termName) {
                          case "PCons": {ESLVal $236 = $232.termRef(0);
                            ESLVal $235 = $232.termRef(1);
                            ESLVal $234 = $232.termRef(2);
                            
                            switch($234.termName) {
                            case "PNil": {ESLVal $237 = $234.termRef(0);
                              
                              switch($231.termName) {
                              case "PVar": {ESLVal $240 = $231.termRef(0);
                                ESLVal $239 = $231.termRef(1);
                                ESLVal $238 = $231.termRef(2);
                                
                                {ESLVal l1 = $230;
                                
                                {ESLVal n1 = $229;
                                
                                {ESLVal t1 = $228;
                                
                                {ESLVal l2 = $233;
                                
                                {ESLVal l3 = $236;
                                
                                {ESLVal p = $235;
                                
                                {ESLVal l5 = $237;
                                
                                {ESLVal l6 = $240;
                                
                                {ESLVal n3 = $239;
                                
                                {ESLVal t3 = $238;
                                
                                return _v543.apply(_v548,_v554);
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              default: {ESLVal _v564 = _v59;
                                
                                {ESLVal _v565 = _v58;
                                
                                return error(new ESLVal("TypeError",_v551,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                              }
                              }
                            }
                            }
                            default: {ESLVal _v566 = _v59;
                              
                              {ESLVal _v567 = _v58;
                              
                              return error(new ESLVal("TypeError",_v551,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                            }
                            }
                          }
                          }
                          default: {ESLVal _v568 = _v59;
                            
                            {ESLVal _v569 = _v58;
                            
                            return error(new ESLVal("TypeError",_v551,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                          }
                          }
                        }
                        }
                        default: {ESLVal _v573 = _v59;
                          
                          {ESLVal _v574 = _v58;
                          
                          return error(new ESLVal("TypeError",_v551,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                        }
                        }
                      }
                      }
                    case "PAdd": {ESLVal $217 = _v59.termRef(0);
                        ESLVal $216 = _v59.termRef(1);
                        ESLVal $215 = _v59.termRef(2);
                        
                        switch($216.termName) {
                        case "PVar": {ESLVal $220 = $216.termRef(0);
                          ESLVal $219 = $216.termRef(1);
                          ESLVal $218 = $216.termRef(2);
                          
                          switch($215.termName) {
                          case "PCons": {ESLVal $223 = $215.termRef(0);
                            ESLVal $222 = $215.termRef(1);
                            ESLVal $221 = $215.termRef(2);
                            
                            switch($221.termName) {
                            case "PNil": {ESLVal $224 = $221.termRef(0);
                              
                              switch(_v58.termName) {
                              case "PVar": {ESLVal $227 = _v58.termRef(0);
                                ESLVal $226 = _v58.termRef(1);
                                ESLVal $225 = _v58.termRef(2);
                                
                                {ESLVal l1 = $217;
                                
                                {ESLVal l2 = $220;
                                
                                {ESLVal n1 = $219;
                                
                                {ESLVal t1 = $218;
                                
                                {ESLVal l3 = $223;
                                
                                {ESLVal p = $222;
                                
                                {ESLVal l5 = $224;
                                
                                {ESLVal l6 = $227;
                                
                                {ESLVal n3 = $226;
                                
                                {ESLVal t3 = $225;
                                
                                return _v543.apply(_v548,_v554);
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              default: {ESLVal _v556 = _v59;
                                
                                {ESLVal _v557 = _v58;
                                
                                return error(new ESLVal("TypeError",_v551,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                              }
                              }
                            }
                            }
                            default: {ESLVal _v558 = _v59;
                              
                              {ESLVal _v559 = _v58;
                              
                              return error(new ESLVal("TypeError",_v551,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                            }
                            }
                          }
                          }
                          default: {ESLVal _v560 = _v59;
                            
                            {ESLVal _v561 = _v58;
                            
                            return error(new ESLVal("TypeError",_v551,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                          }
                          }
                        }
                        }
                        default: {ESLVal _v562 = _v59;
                          
                          {ESLVal _v563 = _v58;
                          
                          return error(new ESLVal("TypeError",_v551,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                        }
                        }
                      }
                      }
                      default: {ESLVal _v579 = _v59;
                        
                        {ESLVal _v580 = _v58;
                        
                        return error(new ESLVal("TypeError",_v551,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                      }
                      }
                    }
                    }
                    }
                    }
                    }
                  case "TypeClosure": {ESLVal $212 = _v57.termRef(0);
                      
                      {ESLVal g = $212;
                      
                      return addPatternType.apply(_v551,_v550,_v549,g.apply(),_v547,_v554,_v545,_v544,_v543);
                    }
                    }
                    default: {ESLVal t = _v57;
                      
                      return error(new ESLVal("TypeError",_v551,new ESLVal("+ expects lists: ").add(ppType.apply(_v548,_v544))));
                    }
                  }
                  }
                }
              }));
          }
        }));
    }
  });
  private static ESLVal applyTypePatternType = new ESLVal(new Function(new ESLVal("applyTypePatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v538 = $args[0];
  ESLVal _v537 = $args[1];
  ESLVal _v536 = $args[2];
  ESLVal _v535 = $args[3];
  ESLVal _v534 = $args[4];
  ESLVal _v533 = $args[5];
  ESLVal _v532 = $args[6];
  ESLVal _v531 = $args[7];
  ESLVal _v530 = $args[8];
  return patternType.apply(_v538,_v537,_v535,_v534,_v533,_v532,_v531,new ESLVal(new Function(new ESLVal("fun529"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v540 = $args[0];
        ESLVal _v539 = $args[1];
        {ESLVal _v56 = typeNF.apply(_v540,_v531);
              
              switch(_v56.termName) {
              case "TypeFun": {ESLVal $211 = _v56.termRef(0);
                ESLVal $210 = _v56.termRef(1);
                ESLVal $209 = _v56.termRef(2);
                
                {ESLVal fl = $211;
                
                {ESLVal ns = $210;
                
                {ESLVal t = $209;
                
                if(length.apply(_v536).eql(length.apply(ns)).boolVal)
                {ESLVal _v542 = substTypeEnv.apply(zipTypeEnv.apply(ns,_v536).add(_v531),t);
                  
                  if(typeEqual.apply(_v542,_v535).boolVal)
                  return _v530.apply(_v542,_v539);
                  else
                    return error(new ESLVal("TypeError",_v538,new ESLVal("value type ").add(ppType.apply(_v535,_v531).add(new ESLVal(" does not match pattern type ").add(ppType.apply(_v542,_v531).add(new ESLVal(" ").add(ppTypeEnv.apply(_v531))))))));
                }
                else
                  return error(new ESLVal("TypeError",_v538,new ESLVal("expecting ").add(length.apply(ns).add(new ESLVal(" args, but suplied with ").add(length.apply(_v536))))));
              }
              }
              }
              }
            case "ForallType": {ESLVal $208 = _v56.termRef(0);
                ESLVal $207 = _v56.termRef(1);
                ESLVal $206 = _v56.termRef(2);
                
                {ESLVal fl = $208;
                
                {ESLVal ns = $207;
                
                {ESLVal t = $206;
                
                if(length.apply(_v536).eql(length.apply(ns)).boolVal)
                {ESLVal _v541 = substTypeEnv.apply(zipTypeEnv.apply(ns,_v536).add(_v531),t);
                  
                  if(typeEqual.apply(_v541,_v535).boolVal)
                  return _v530.apply(_v541,_v539);
                  else
                    return error(new ESLVal("TypeError",_v538,new ESLVal("value type ").add(ppType.apply(_v535,_v531).add(new ESLVal(" does not match pattern type ").add(ppType.apply(_v541,_v531).add(new ESLVal(" ").add(ppTypeEnv.apply(_v531))))))));
                }
                else
                  return error(new ESLVal("TypeError",_v538,new ESLVal("expecting ").add(length.apply(ns).add(new ESLVal(" args, but suplied with ").add(length.apply(_v536))))));
              }
              }
              }
              }
              default: {ESLVal t = _v56;
                
                return _v530.apply(t,_v539);
              }
            }
            }
          }
        }));
    }
  });
  private static ESLVal termPatternType = new ESLVal(new Function(new ESLVal("termPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v522 = $args[0];
  ESLVal _v521 = $args[1];
  ESLVal _v520 = $args[2];
  ESLVal _v519 = $args[3];
  ESLVal _v518 = $args[4];
  ESLVal _v517 = $args[5];
  ESLVal _v516 = $args[6];
  ESLVal _v515 = $args[7];
  ESLVal _v514 = $args[8];
  ESLVal _v513 = $args[9];
  {ESLVal _v523 = getTermPatternType.apply(_v522,_v521,_v520,_v517,_v516,_v515,_v514);
        
        if(typeEqual.apply(_v523,_v518).boolVal)
        {ESLVal _v54 = typeNF.apply(_v518,_v514);
          
          switch(_v54.termName) {
          case "UnionType": {ESLVal $200 = _v54.termRef(0);
            ESLVal $199 = _v54.termRef(1);
            
            {ESLVal ul = $200;
            
            {ESLVal cs = $199;
            
            LetRec letrec = new LetRec() {
            ESLVal getCnstrArgs = new ESLVal(new Function(new ESLVal("getCnstrArgs"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal _v524 = $args[0];
              {ESLVal _v55 = _v524;
                    
                    if(_v55.isCons())
                    {ESLVal $201 = _v55.head();
                      ESLVal $202 = _v55.tail();
                      
                      switch($201.termName) {
                      case "TermType": {ESLVal $205 = $201.termRef(0);
                        ESLVal $204 = $201.termRef(1);
                        ESLVal $203 = $201.termRef(2);
                        
                        {ESLVal tl = $205;
                        
                        {ESLVal m = $204;
                        
                        {ESLVal args = $203;
                        
                        {ESLVal _v525 = $202;
                        
                        if(m.eql(_v521).boolVal)
                        return args;
                        else
                          {ESLVal t = $201;
                            
                            {ESLVal _v526 = $202;
                            
                            return getCnstrArgs.apply(_v526);
                          }
                          }
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal t = $201;
                        
                        {ESLVal _v527 = $202;
                        
                        return getCnstrArgs.apply(_v527);
                      }
                      }
                    }
                    }
                  else if(_v55.isNil())
                    return error(new ESLVal("TypeError",_v522,new ESLVal("cannot find constructor for ").add(_v521)));
                  else return error(new ESLVal("case error at Pos(48971,49230)").add(ESLVal.list(_v55)));
                  }
                }
              });
            
            public ESLVal get(String name) {
              switch(name) {
                case "getCnstrArgs": return getCnstrArgs;
                
                default: throw new Error("cannot find letrec binding");
              }
              }
            };
          ESLVal getCnstrArgs = letrec.get("getCnstrArgs");
          
            {ESLVal argTypes = getCnstrArgs.apply(cs);
            
            if(length.apply(_v519).eql(length.apply(argTypes)).boolVal)
            return patternTypes.apply(_v522,_v519,argTypes,_v517,_v516,_v515,_v514,new ESLVal(new Function(new ESLVal("fun530"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal _v529 = $args[0];
              ESLVal _v528 = $args[1];
              return _v513.apply(typeNF.apply(_v518,_v514),_v528);
                }
              }));
            else
              return error(new ESLVal("TypeError",_v522,new ESLVal("arity mismatch.")));
          }
          
          }
          }
          }
          default: {ESLVal t = _v54;
            
            return error(new ESLVal("TypeError",_v522,new ESLVal("expecting a data type: ").add(_v518)));
          }
        }
        }
        else
          return error(new ESLVal("TypeError",_v522,new ESLVal("term pattern type ").add(ppType.apply(_v523,_v514).add(new ESLVal(" does not match supplied value type ").add(ppType.apply(_v518,_v514))))));
      }
    }
  });
  private static ESLVal typeNF = new ESLVal(new Function(new ESLVal("typeNF"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v507 = $args[0];
  ESLVal _v506 = $args[1];
  {ESLVal _v51 = substTypeEnv.apply(_v506,_v507);
        
        switch(_v51.termName) {
        case "ApplyTypeFun": {ESLVal $192 = _v51.termRef(0);
          ESLVal $191 = _v51.termRef(1);
          ESLVal $190 = _v51.termRef(2);
          
          {ESLVal l = $192;
          
          {ESLVal op = $191;
          
          {ESLVal args = $190;
          
          {ESLVal _v53 = typeNF.apply(op,_v506);
          
          switch(_v53.termName) {
          case "TypeFun": {ESLVal $198 = _v53.termRef(0);
            ESLVal $197 = _v53.termRef(1);
            ESLVal $196 = _v53.termRef(2);
            
            {ESLVal _v509 = $198;
            
            {ESLVal ns = $197;
            
            {ESLVal _v510 = $196;
            
            if(length.apply(args).eql(length.apply(ns)).boolVal)
            return typeNF.apply(substTypeEnv.apply(zipTypeEnv.apply(ns,args),_v510),_v506);
            else
              return error(new ESLVal("TypeError",_v509,new ESLVal("function arity error")));
          }
          }
          }
          }
          default: {ESLVal _v511 = _v53;
            
            return error(new ESLVal("TypeError",l,new ESLVal("expecting a type function: ").add(ppType.apply(typeNF.apply(op,_v506),_v506))));
          }
        }
        }
        }
        }
        }
        }
      case "TypeClosure": {ESLVal $189 = _v51.termRef(0);
          
          {ESLVal f = $189;
          
          return typeNF.apply(f.apply(),_v506);
        }
        }
      case "RecType": {ESLVal $188 = _v51.termRef(0);
          ESLVal $187 = _v51.termRef(1);
          ESLVal $186 = _v51.termRef(2);
          
          {ESLVal l = $188;
          
          {ESLVal n = $187;
          
          {ESLVal _v508 = $186;
          
          return typeNF.apply(substType.apply(new ESLVal("RecType",l,n,_v508),n,_v508),_v506);
        }
        }
        }
        }
      case "ExtendedAct": {ESLVal $185 = _v51.termRef(0);
          ESLVal $184 = _v51.termRef(1);
          ESLVal $183 = _v51.termRef(2);
          ESLVal $182 = _v51.termRef(3);
          
          {ESLVal l1 = $185;
          
          {ESLVal parent = $184;
          
          {ESLVal decs1 = $183;
          
          {ESLVal ms1 = $182;
          
          {ESLVal _v52 = typeNF.apply(parent,_v506);
          
          switch(_v52.termName) {
          case "ActType": {ESLVal $195 = _v52.termRef(0);
            ESLVal $194 = _v52.termRef(1);
            ESLVal $193 = _v52.termRef(2);
            
            {ESLVal l2 = $195;
            
            {ESLVal decs2 = $194;
            
            {ESLVal ms2 = $193;
            
            return new ESLVal("ActType",l1,decs2.add(decs1),ms2.add(ms1));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(50547,50682)").add(ESLVal.list(_v52)));
        }
        }
        }
        }
        }
        }
        }
        default: {ESLVal _v512 = _v51;
          
          return _v512;
        }
      }
      }
    }
  });
  private static ESLVal getTermPatternType = new ESLVal(new Function(new ESLVal("getTermPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v505 = $args[0];
  ESLVal _v504 = $args[1];
  ESLVal _v503 = $args[2];
  ESLVal _v502 = $args[3];
  ESLVal _v501 = $args[4];
  ESLVal _v500 = $args[5];
  ESLVal _v499 = $args[6];
  {ESLVal t = lookupType.apply(_v504,_v500);
        
        if(t.eql($null).boolVal)
        return error(new ESLVal("TypeError",_v505,new ESLVal("unknown constructor ").add(_v504)));
        else
          if(length.apply(_v503).gre($zero).boolVal)
            return getGenericTermPatternType.apply(_v505,t,_v503,_v502,_v501,_v500,_v499);
            else
              return t;
      }
    }
  });
  private static ESLVal getGenericTermPatternType = new ESLVal(new Function(new ESLVal("getGenericTermPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v496 = $args[0];
  ESLVal _v495 = $args[1];
  ESLVal _v494 = $args[2];
  ESLVal _v493 = $args[3];
  ESLVal _v492 = $args[4];
  ESLVal _v491 = $args[5];
  ESLVal _v490 = $args[6];
  {ESLVal _v50 = _v495;
        
        switch(_v50.termName) {
        case "RecType": {ESLVal $181 = _v50.termRef(0);
          ESLVal $180 = _v50.termRef(1);
          ESLVal $179 = _v50.termRef(2);
          
          {ESLVal rl = $181;
          
          {ESLVal rn = $180;
          
          {ESLVal rt = $179;
          
          return getGenericTermPatternType.apply(_v496,substType.apply(new ESLVal("RecType",rl,rn,rt),rn,rt),_v494,_v493,_v492,_v491,_v490);
        }
        }
        }
        }
      case "TypeFun": {ESLVal $178 = _v50.termRef(0);
          ESLVal $177 = _v50.termRef(1);
          ESLVal $176 = _v50.termRef(2);
          
          {ESLVal al = $178;
          
          {ESLVal ns = $177;
          
          {ESLVal _v497 = $176;
          
          if(length.apply(ns).eql(length.apply(_v494)).boolVal)
          {ESLVal e = zipTypeEnv.apply(ns,_v494);
            
            return substTypeEnv.apply(e.add(_v490),_v497);
          }
          else
            return error(new ESLVal("TypeError",_v496,new ESLVal("generic constructor mismatch")));
        }
        }
        }
        }
        default: {ESLVal _v498 = _v50;
          
          return error(new ESLVal("TypeError",_v496,new ESLVal("expecting a generic type: ").add(ppType.apply(_v498,_v490))));
        }
      }
      }
    }
  });
  private static ESLVal nilType = new ESLVal(new Function(new ESLVal("nilType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v488 = $args[0];
  ESLVal _v487 = $args[1];
  ESLVal _v486 = $args[2];
  ESLVal _v485 = $args[3];
  ESLVal _v484 = $args[4];
  ESLVal _v483 = $args[5];
  ESLVal _v482 = $args[6];
  {ESLVal _v49 = _v487;
        
        switch(_v49.termName) {
        case "ListType": {ESLVal $175 = _v49.termRef(0);
          ESLVal $174 = _v49.termRef(1);
          
          {ESLVal ltl = $175;
          
          {ESLVal et = $174;
          
          return _v482.apply(new ESLVal("ForallType",_v488,ESLVal.list(new ESLVal("T")),new ESLVal("ListType",_v488,new ESLVal("VarType",_v488,new ESLVal("T")))),_v485);
        }
        }
        }
      case "TypeClosure": {ESLVal $173 = _v49.termRef(0);
          
          {ESLVal g = $173;
          
          return nilType.apply(_v488,g.apply(),_v486,_v485,_v484,_v483,_v482);
        }
        }
        default: {ESLVal _v489 = _v49;
          
          return error(new ESLVal("TypeError",_v488,new ESLVal("expecting a list type: ").add(ppType.apply(_v489,_v483))));
        }
      }
      }
    }
  });
  private static ESLVal emptyBagType = new ESLVal(new Function(new ESLVal("emptyBagType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v480 = $args[0];
  ESLVal _v479 = $args[1];
  ESLVal _v478 = $args[2];
  ESLVal _v477 = $args[3];
  ESLVal _v476 = $args[4];
  ESLVal _v475 = $args[5];
  ESLVal _v474 = $args[6];
  {ESLVal _v48 = _v479;
        
        switch(_v48.termName) {
        case "BagType": {ESLVal $172 = _v48.termRef(0);
          ESLVal $171 = _v48.termRef(1);
          
          {ESLVal ltl = $172;
          
          {ESLVal et = $171;
          
          return _v474.apply(new ESLVal("ForallType",_v480,ESLVal.list(new ESLVal("T")),new ESLVal("BagType",_v480,new ESLVal("VarType",_v480,new ESLVal("T")))),_v477);
        }
        }
        }
        default: {ESLVal _v481 = _v48;
          
          return error(new ESLVal("TypeError",_v480,new ESLVal("expecting a bag type: ").add(ppType.apply(_v481,_v475))));
        }
      }
      }
    }
  });
  private static ESLVal emptySetType = new ESLVal(new Function(new ESLVal("emptySetType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v472 = $args[0];
  ESLVal _v471 = $args[1];
  ESLVal _v470 = $args[2];
  ESLVal _v469 = $args[3];
  ESLVal _v468 = $args[4];
  ESLVal _v467 = $args[5];
  ESLVal _v466 = $args[6];
  {ESLVal _v47 = _v471;
        
        switch(_v47.termName) {
        case "SetType": {ESLVal $170 = _v47.termRef(0);
          ESLVal $169 = _v47.termRef(1);
          
          {ESLVal ltl = $170;
          
          {ESLVal et = $169;
          
          return _v466.apply(new ESLVal("ForallType",_v472,ESLVal.list(new ESLVal("T")),new ESLVal("SetType",_v472,new ESLVal("VarType",_v472,new ESLVal("T")))),_v469);
        }
        }
        }
        default: {ESLVal _v473 = _v47;
          
          return error(new ESLVal("TypeError",_v472,new ESLVal("expecting a set type: ").add(ppType.apply(_v473,_v467))));
        }
      }
      }
    }
  });
  private static ESLVal consPatternType = new ESLVal(new Function(new ESLVal("consPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v460 = $args[0];
  ESLVal _v459 = $args[1];
  ESLVal _v458 = $args[2];
  ESLVal _v457 = $args[3];
  ESLVal _v456 = $args[4];
  ESLVal _v455 = $args[5];
  ESLVal _v454 = $args[6];
  ESLVal _v453 = $args[7];
  ESLVal _v452 = $args[8];
  {ESLVal _v46 = _v457;
        
        switch(_v46.termName) {
        case "ListType": {ESLVal $168 = _v46.termRef(0);
          ESLVal $167 = _v46.termRef(1);
          
          {ESLVal ltl = $168;
          
          {ESLVal et = $167;
          
          return patternType.apply(_v460,_v459,substTypeEnv.apply(_v453,et),_v456,_v455,_v454,_v453,new ESLVal(new Function(new ESLVal("fun531"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v462 = $args[0];
          ESLVal _v461 = $args[1];
          return patternType.apply(_v460,_v458,_v457,_v456,_v461,_v454,_v453,new ESLVal(new Function(new ESLVal("fun532"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal _v464 = $args[0];
                ESLVal _v463 = $args[1];
                return _v452.apply(_v462,_v463);
                  }
                }));
            }
          }));
        }
        }
        }
      case "TypeClosure": {ESLVal $166 = _v46.termRef(0);
          
          {ESLVal g = $166;
          
          return consPatternType.apply(_v460,_v459,_v458,g.apply(),_v456,_v455,_v454,_v453,_v452);
        }
        }
        default: {ESLVal _v465 = _v46;
          
          return error(new ESLVal("TypeError",_v460,new ESLVal("expecting a list type: ").add(ppType.apply(_v465,_v453))));
        }
      }
      }
    }
  });
  private static ESLVal bagConsPatternType = new ESLVal(new Function(new ESLVal("bagConsPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v446 = $args[0];
  ESLVal _v445 = $args[1];
  ESLVal _v444 = $args[2];
  ESLVal _v443 = $args[3];
  ESLVal _v442 = $args[4];
  ESLVal _v441 = $args[5];
  ESLVal _v440 = $args[6];
  ESLVal _v439 = $args[7];
  ESLVal _v438 = $args[8];
  {ESLVal _v45 = _v443;
        
        switch(_v45.termName) {
        case "BagType": {ESLVal $165 = _v45.termRef(0);
          ESLVal $164 = _v45.termRef(1);
          
          {ESLVal ltl = $165;
          
          {ESLVal et = $164;
          
          return patternType.apply(_v446,_v445,substTypeEnv.apply(_v439,et),_v442,_v441,_v440,_v439,new ESLVal(new Function(new ESLVal("fun533"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v448 = $args[0];
          ESLVal _v447 = $args[1];
          return patternType.apply(_v446,_v444,_v443,_v442,_v447,_v440,_v439,new ESLVal(new Function(new ESLVal("fun534"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal _v450 = $args[0];
                ESLVal _v449 = $args[1];
                return _v438.apply(_v448,_v449);
                  }
                }));
            }
          }));
        }
        }
        }
        default: {ESLVal _v451 = _v45;
          
          return error(new ESLVal("TypeError",_v446,new ESLVal("expecting a bag type: ").add(ppType.apply(_v451,_v439))));
        }
      }
      }
    }
  });
  private static ESLVal setConsPatternType = new ESLVal(new Function(new ESLVal("setConsPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v432 = $args[0];
  ESLVal _v431 = $args[1];
  ESLVal _v430 = $args[2];
  ESLVal _v429 = $args[3];
  ESLVal _v428 = $args[4];
  ESLVal _v427 = $args[5];
  ESLVal _v426 = $args[6];
  ESLVal _v425 = $args[7];
  ESLVal _v424 = $args[8];
  {ESLVal _v44 = _v429;
        
        switch(_v44.termName) {
        case "SetType": {ESLVal $163 = _v44.termRef(0);
          ESLVal $162 = _v44.termRef(1);
          
          {ESLVal ltl = $163;
          
          {ESLVal et = $162;
          
          return patternType.apply(_v432,_v431,substTypeEnv.apply(_v425,et),_v428,_v427,_v426,_v425,new ESLVal(new Function(new ESLVal("fun535"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v434 = $args[0];
          ESLVal _v433 = $args[1];
          return patternType.apply(_v432,_v430,_v429,_v428,_v433,_v426,_v425,new ESLVal(new Function(new ESLVal("fun536"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal _v436 = $args[0];
                ESLVal _v435 = $args[1];
                return _v424.apply(_v434,_v435);
                  }
                }));
            }
          }));
        }
        }
        }
        default: {ESLVal _v437 = _v44;
          
          return error(new ESLVal("TypeError",_v432,new ESLVal("expecting a set type: ").add(ppType.apply(_v437,_v425))));
        }
      }
      }
    }
  });
  private static ESLVal binExpType = new ESLVal(new Function(new ESLVal("binExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v422 = $args[0];
  ESLVal _v421 = $args[1];
  ESLVal _v420 = $args[2];
  ESLVal _v419 = $args[3];
  ESLVal _v418 = $args[4];
  ESLVal _v417 = $args[5];
  ESLVal _v416 = $args[6];
  ESLVal _v415 = $args[7];
  {ESLVal _v43 = _v420;
        
        switch(_v43.strVal) {
        case "+": return plusExpType.apply(_v422,_v421,_v419,_v418,_v417,_v416,_v415);
      case "-": return subExpType.apply(_v422,_v421,_v419,_v418,_v417,_v416,_v415);
      case "*": return mulExpType.apply(_v422,_v421,_v419,_v418,_v417,_v416,_v415);
      case "/": return divExpType.apply(_v422,_v421,_v419,_v418,_v417,_v416,_v415);
      case ":": return consExpType.apply(_v422,_v421,_v419,_v418,_v417,_v416,_v415);
      case "=": return eqlExpType.apply(_v422,_v421,_v419,_v418,_v417,_v416,_v415);
      case "<>": return neqlExpType.apply(_v422,_v421,_v419,_v418,_v417,_v416,_v415);
      case "and": return andExpType.apply(_v422,_v421,_v419,_v418,_v417,_v416,_v415);
      case "andalso": return andExpType.apply(_v422,_v421,_v419,_v418,_v417,_v416,_v415);
      case "or": return orExpType.apply(_v422,_v421,_v419,_v418,_v417,_v416,_v415);
      case "orelse": return orExpType.apply(_v422,_v421,_v419,_v418,_v417,_v416,_v415);
      case ">": return compareExpType.apply(_v422,_v421,new ESLVal(">"),_v419,_v418,_v417,_v416,_v415);
      case ">=": return compareExpType.apply(_v422,_v421,new ESLVal(">="),_v419,_v418,_v417,_v416,_v415);
      case "<": return compareExpType.apply(_v422,_v421,new ESLVal("<"),_v419,_v418,_v417,_v416,_v415);
      case "<=": return compareExpType.apply(_v422,_v421,new ESLVal("<="),_v419,_v418,_v417,_v416,_v415);
      case "..": return dotDotExpType.apply(_v422,_v421,_v419,_v418,_v417,_v416,_v415);
      case "%": return percentExpType.apply(_v422,_v421,_v419,_v418,_v417,_v416,_v415);
      case "@": return atExpType.apply(_v422,_v421,_v419,_v418,_v417,_v416,_v415);
        default: {ESLVal _v423 = _v43;
          
          return error(new ESLVal("TypeError",_v422,new ESLVal("unknown operator: ").add(_v423)));
        }
      }
      }
    }
  });
  private static ESLVal andExpType = new ESLVal(new Function(new ESLVal("andExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v414 = $args[0];
  ESLVal _v413 = $args[1];
  ESLVal _v412 = $args[2];
  ESLVal _v411 = $args[3];
  ESLVal _v410 = $args[4];
  ESLVal _v409 = $args[5];
  ESLVal _v408 = $args[6];
  {ESLVal t1 = expType.apply(_v413,_v411,_v410,_v409,_v408);
        ESLVal t2 = expType.apply(_v412,_v411,_v410,_v409,_v408);
        
        if(isBoolType.apply(t1).and(isBoolType.apply(t2)).boolVal)
        return t1;
        else
          return error(new ESLVal("TypeError",_v414,new ESLVal("and expects boolean arguments: ").add(ppType.apply(t1,_v408).add(new ESLVal(" ").add(ppType.apply(t2,_v408))))));
      }
    }
  });
  private static ESLVal atExpType = new ESLVal(new Function(new ESLVal("atExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v407 = $args[0];
  ESLVal _v406 = $args[1];
  ESLVal _v405 = $args[2];
  ESLVal _v404 = $args[3];
  ESLVal _v403 = $args[4];
  ESLVal _v402 = $args[5];
  ESLVal _v401 = $args[6];
  {ESLVal t1 = expType.apply(_v406,_v404,_v403,_v402,_v401);
        ESLVal t2 = expType.apply(_v405,_v404,_v403,_v402,_v401);
        
        if(typeEqual.apply(t1,t2).boolVal)
        return t1;
        else
          return error(new ESLVal("TypeError",_v407,new ESLVal("@ expects arguments to be same type: ").add(ppType.apply(t1,_v401).add(new ESLVal(" ").add(ppType.apply(t2,_v401))))));
      }
    }
  });
  private static ESLVal dotDotExpType = new ESLVal(new Function(new ESLVal("dotDotExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v400 = $args[0];
  ESLVal _v399 = $args[1];
  ESLVal _v398 = $args[2];
  ESLVal _v397 = $args[3];
  ESLVal _v396 = $args[4];
  ESLVal _v395 = $args[5];
  ESLVal _v394 = $args[6];
  {ESLVal t1 = expType.apply(_v399,_v397,_v396,_v395,_v394);
        ESLVal t2 = expType.apply(_v398,_v397,_v396,_v395,_v394);
        
        if(isIntType.apply(t1).and(isIntType.apply(t2)).boolVal)
        return new ESLVal("ListType",_v400,new ESLVal("IntType",_v400));
        else
          return error(new ESLVal("TypeError",_v400,new ESLVal(".. expects integer arguments: ").add(ppType.apply(t1,_v394).add(new ESLVal(" ").add(ppType.apply(t2,_v394))))));
      }
    }
  });
  private static ESLVal percentExpType = new ESLVal(new Function(new ESLVal("percentExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v393 = $args[0];
  ESLVal _v392 = $args[1];
  ESLVal _v391 = $args[2];
  ESLVal _v390 = $args[3];
  ESLVal _v389 = $args[4];
  ESLVal _v388 = $args[5];
  ESLVal _v387 = $args[6];
  {ESLVal t1 = expType.apply(_v392,_v390,_v389,_v388,_v387);
        ESLVal t2 = expType.apply(_v391,_v390,_v389,_v388,_v387);
        
        if(isIntType.apply(t1).and(isIntType.apply(t2)).boolVal)
        return new ESLVal("IntType",_v393);
        else
          return error(new ESLVal("TypeError",_v393,new ESLVal("% expects integer arguments: ").add(ppType.apply(t1,_v387).add(new ESLVal(" ").add(ppType.apply(t2,_v387))))));
      }
    }
  });
  private static ESLVal compareExpType = new ESLVal(new Function(new ESLVal("compareExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v386 = $args[0];
  ESLVal _v385 = $args[1];
  ESLVal _v384 = $args[2];
  ESLVal _v383 = $args[3];
  ESLVal _v382 = $args[4];
  ESLVal _v381 = $args[5];
  ESLVal _v380 = $args[6];
  ESLVal _v379 = $args[7];
  {ESLVal t1 = expType.apply(_v385,_v382,_v381,_v380,_v379);
        ESLVal t2 = expType.apply(_v383,_v382,_v381,_v380,_v379);
        
        if(isNumType.apply(t1).and(isNumType.apply(t2)).boolVal)
        return new ESLVal("BoolType",_v386);
        else
          return error(new ESLVal("TypeError",_v386,_v384.add(new ESLVal(" expects numeric arguments: ").add(ppType.apply(t1,_v379).add(new ESLVal(" ").add(ppType.apply(t2,_v379)))))));
      }
    }
  });
  private static ESLVal orExpType = new ESLVal(new Function(new ESLVal("orExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v378 = $args[0];
  ESLVal _v377 = $args[1];
  ESLVal _v376 = $args[2];
  ESLVal _v375 = $args[3];
  ESLVal _v374 = $args[4];
  ESLVal _v373 = $args[5];
  ESLVal _v372 = $args[6];
  {ESLVal t1 = expType.apply(_v377,_v375,_v374,_v373,_v372);
        ESLVal t2 = expType.apply(_v376,_v375,_v374,_v373,_v372);
        
        if(isBoolType.apply(t1).and(isBoolType.apply(t2)).boolVal)
        return t1;
        else
          return error(new ESLVal("TypeError",_v378,new ESLVal("or expects boolean arguments: ").add(ppType.apply(t1,_v372).add(new ESLVal(" ").add(ppType.apply(t2,_v372))))));
      }
    }
  });
  private static ESLVal eqlExpType = new ESLVal(new Function(new ESLVal("eqlExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v371 = $args[0];
  ESLVal _v370 = $args[1];
  ESLVal _v369 = $args[2];
  ESLVal _v368 = $args[3];
  ESLVal _v367 = $args[4];
  ESLVal _v366 = $args[5];
  ESLVal _v365 = $args[6];
  {ESLVal t1 = expType.apply(_v370,_v368,_v367,_v366,_v365);
        ESLVal t2 = expType.apply(_v369,_v368,_v367,_v366,_v365);
        
        if(typeEqual.apply(t1,t2).boolVal)
        return new ESLVal("BoolType",_v371);
        else
          return error(new ESLVal("TypeError",_v371,new ESLVal("= expects types to agree: ").add(ppType.apply(t1,_v365).add(new ESLVal(" <> ").add(ppType.apply(t2,_v365))))));
      }
    }
  });
  private static ESLVal neqlExpType = new ESLVal(new Function(new ESLVal("neqlExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v364 = $args[0];
  ESLVal _v363 = $args[1];
  ESLVal _v362 = $args[2];
  ESLVal _v361 = $args[3];
  ESLVal _v360 = $args[4];
  ESLVal _v359 = $args[5];
  ESLVal _v358 = $args[6];
  {ESLVal t1 = expType.apply(_v363,_v361,_v360,_v359,_v358);
        ESLVal t2 = expType.apply(_v362,_v361,_v360,_v359,_v358);
        
        if(typeEqual.apply(t1,t2).boolVal)
        return new ESLVal("BoolType",_v364);
        else
          return error(new ESLVal("TypeError",_v364,new ESLVal("<> expects types to agree: ").add(ppType.apply(t1,_v358).add(new ESLVal(" <> ").add(ppType.apply(t2,_v358))))));
      }
    }
  });
  private static ESLVal consExpType = new ESLVal(new Function(new ESLVal("consExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v356 = $args[0];
  ESLVal _v355 = $args[1];
  ESLVal _v354 = $args[2];
  ESLVal _v353 = $args[3];
  ESLVal _v352 = $args[4];
  ESLVal _v351 = $args[5];
  ESLVal _v350 = $args[6];
  {ESLVal t1 = typeNF.apply(expType.apply(_v355,_v353,_v352,_v351,_v350),_v350);
        ESLVal t2 = typeNF.apply(expType.apply(_v354,_v353,_v352,_v351,_v350),_v350);
        
        {ESLVal _v42 = t2;
        ESLVal _v41 = t1;
        
        switch(_v42.termName) {
        case "ListType": {ESLVal $161 = _v42.termRef(0);
          ESLVal $160 = _v42.termRef(1);
          
          {ESLVal _v357 = $161;
          
          {ESLVal elementType = $160;
          
          {ESLVal headType = _v41;
          
          if(subType.apply(headType,elementType).boolVal)
          return t2;
          else
            return error(new ESLVal("TypeError",_v357,new ESLVal(": expects head type ").add(ppType.apply(headType,_v350).add(new ESLVal(" and element type ").add(ppType.apply(elementType,_v350).add(new ESLVal(" to agree")))))));
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(59705,59986)").add(ESLVal.list(_v42,_v41)));
      }
      }
      }
    }
  });
  private static ESLVal divExpType = new ESLVal(new Function(new ESLVal("divExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v343 = $args[0];
  ESLVal _v342 = $args[1];
  ESLVal _v341 = $args[2];
  ESLVal _v340 = $args[3];
  ESLVal _v339 = $args[4];
  ESLVal _v338 = $args[5];
  ESLVal _v337 = $args[6];
  {ESLVal t1 = expType.apply(_v342,_v340,_v339,_v338,_v337);
        ESLVal t2 = expType.apply(_v341,_v340,_v339,_v338,_v337);
        
        {ESLVal _v40 = t1;
        ESLVal _v39 = t2;
        
        switch(_v40.termName) {
        case "IntType": {ESLVal $158 = _v40.termRef(0);
          
          switch(_v39.termName) {
          case "IntType": {ESLVal $159 = _v39.termRef(0);
            
            {ESLVal l1 = $158;
            
            {ESLVal l2 = $159;
            
            return t1;
          }
          }
          }
          default: {ESLVal _v346 = _v40;
            
            {ESLVal _v347 = _v39;
            
            return error(new ESLVal("TypeError",_v343,new ESLVal("incomptible types for /: ").add(ppType.apply(_v346,_v337).add(new ESLVal(" and ").add(ppType.apply(_v347,_v337))))));
          }
          }
        }
        }
      case "FloatType": {ESLVal $156 = _v40.termRef(0);
          
          switch(_v39.termName) {
          case "FloatType": {ESLVal $157 = _v39.termRef(0);
            
            {ESLVal l1 = $156;
            
            {ESLVal l2 = $157;
            
            return t1;
          }
          }
          }
          default: {ESLVal _v344 = _v40;
            
            {ESLVal _v345 = _v39;
            
            return error(new ESLVal("TypeError",_v343,new ESLVal("incomptible types for /: ").add(ppType.apply(_v344,_v337).add(new ESLVal(" and ").add(ppType.apply(_v345,_v337))))));
          }
          }
        }
        }
        default: {ESLVal _v348 = _v40;
          
          {ESLVal _v349 = _v39;
          
          return error(new ESLVal("TypeError",_v343,new ESLVal("incomptible types for /: ").add(ppType.apply(_v348,_v337).add(new ESLVal(" and ").add(ppType.apply(_v349,_v337))))));
        }
        }
      }
      }
      }
    }
  });
  private static ESLVal mulExpType = new ESLVal(new Function(new ESLVal("mulExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v330 = $args[0];
  ESLVal _v329 = $args[1];
  ESLVal _v328 = $args[2];
  ESLVal _v327 = $args[3];
  ESLVal _v326 = $args[4];
  ESLVal _v325 = $args[5];
  ESLVal _v324 = $args[6];
  {ESLVal t1 = expType.apply(_v329,_v327,_v326,_v325,_v324);
        ESLVal t2 = expType.apply(_v328,_v327,_v326,_v325,_v324);
        
        {ESLVal _v38 = t1;
        ESLVal _v37 = t2;
        
        switch(_v38.termName) {
        case "IntType": {ESLVal $153 = _v38.termRef(0);
          
          switch(_v37.termName) {
          case "IntType": {ESLVal $155 = _v37.termRef(0);
            
            {ESLVal l1 = $153;
            
            {ESLVal l2 = $155;
            
            return t1;
          }
          }
          }
        case "FloatType": {ESLVal $154 = _v37.termRef(0);
            
            {ESLVal l1 = $153;
            
            {ESLVal l2 = $154;
            
            return t2;
          }
          }
          }
          default: {ESLVal _v333 = _v38;
            
            {ESLVal _v334 = _v37;
            
            return error(new ESLVal("TypeError",_v330,new ESLVal("incomptible types for *: ").add(ppType.apply(_v333,_v324).add(new ESLVal(" and ").add(ppType.apply(_v334,_v324))))));
          }
          }
        }
        }
      case "FloatType": {ESLVal $150 = _v38.termRef(0);
          
          switch(_v37.termName) {
          case "FloatType": {ESLVal $152 = _v37.termRef(0);
            
            {ESLVal l1 = $150;
            
            {ESLVal l2 = $152;
            
            return t1;
          }
          }
          }
        case "IntType": {ESLVal $151 = _v37.termRef(0);
            
            {ESLVal l1 = $150;
            
            {ESLVal l2 = $151;
            
            return t1;
          }
          }
          }
          default: {ESLVal _v331 = _v38;
            
            {ESLVal _v332 = _v37;
            
            return error(new ESLVal("TypeError",_v330,new ESLVal("incomptible types for *: ").add(ppType.apply(_v331,_v324).add(new ESLVal(" and ").add(ppType.apply(_v332,_v324))))));
          }
          }
        }
        }
        default: {ESLVal _v335 = _v38;
          
          {ESLVal _v336 = _v37;
          
          return error(new ESLVal("TypeError",_v330,new ESLVal("incomptible types for *: ").add(ppType.apply(_v335,_v324).add(new ESLVal(" and ").add(ppType.apply(_v336,_v324))))));
        }
        }
      }
      }
      }
    }
  });
  private static ESLVal subExpType = new ESLVal(new Function(new ESLVal("subExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v317 = $args[0];
  ESLVal _v316 = $args[1];
  ESLVal _v315 = $args[2];
  ESLVal _v314 = $args[3];
  ESLVal _v313 = $args[4];
  ESLVal _v312 = $args[5];
  ESLVal _v311 = $args[6];
  {ESLVal t1 = expType.apply(_v316,_v314,_v313,_v312,_v311);
        ESLVal t2 = expType.apply(_v315,_v314,_v313,_v312,_v311);
        
        {ESLVal _v36 = t1;
        ESLVal _v35 = t2;
        
        switch(_v36.termName) {
        case "IntType": {ESLVal $147 = _v36.termRef(0);
          
          switch(_v35.termName) {
          case "IntType": {ESLVal $149 = _v35.termRef(0);
            
            {ESLVal l1 = $147;
            
            {ESLVal l2 = $149;
            
            return t1;
          }
          }
          }
        case "FloatType": {ESLVal $148 = _v35.termRef(0);
            
            {ESLVal l1 = $147;
            
            {ESLVal l2 = $148;
            
            return t2;
          }
          }
          }
          default: {ESLVal _v320 = _v36;
            
            {ESLVal _v321 = _v35;
            
            return error(new ESLVal("TypeError",_v317,new ESLVal("incomptible types for -: ").add(ppType.apply(_v320,_v311).add(new ESLVal(" and ").add(ppType.apply(_v321,_v311))))));
          }
          }
        }
        }
      case "FloatType": {ESLVal $144 = _v36.termRef(0);
          
          switch(_v35.termName) {
          case "FloatType": {ESLVal $146 = _v35.termRef(0);
            
            {ESLVal l1 = $144;
            
            {ESLVal l2 = $146;
            
            return t1;
          }
          }
          }
        case "IntType": {ESLVal $145 = _v35.termRef(0);
            
            {ESLVal l1 = $144;
            
            {ESLVal l2 = $145;
            
            return t1;
          }
          }
          }
          default: {ESLVal _v318 = _v36;
            
            {ESLVal _v319 = _v35;
            
            return error(new ESLVal("TypeError",_v317,new ESLVal("incomptible types for -: ").add(ppType.apply(_v318,_v311).add(new ESLVal(" and ").add(ppType.apply(_v319,_v311))))));
          }
          }
        }
        }
        default: {ESLVal _v322 = _v36;
          
          {ESLVal _v323 = _v35;
          
          return error(new ESLVal("TypeError",_v317,new ESLVal("incomptible types for -: ").add(ppType.apply(_v322,_v311).add(new ESLVal(" and ").add(ppType.apply(_v323,_v311))))));
        }
        }
      }
      }
      }
    }
  });
  private static ESLVal plusExpType = new ESLVal(new Function(new ESLVal("plusExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v276 = $args[0];
  ESLVal _v275 = $args[1];
  ESLVal _v274 = $args[2];
  ESLVal _v273 = $args[3];
  ESLVal _v272 = $args[4];
  ESLVal _v271 = $args[5];
  ESLVal _v270 = $args[6];
  {ESLVal t1 = expType.apply(_v275,_v273,_v272,_v271,_v270);
        ESLVal t2 = expType.apply(_v274,_v273,_v272,_v271,_v270);
        
        {ESLVal _v34 = t1;
        ESLVal _v33 = t2;
        
        switch(_v34.termName) {
        case "StrType": {ESLVal $143 = _v34.termRef(0);
          
          {ESLVal _v305 = $143;
          
          {ESLVal _v306 = _v33;
          
          return t1;
        }
        }
        }
      case "IntType": {ESLVal $141 = _v34.termRef(0);
          
          switch(_v33.termName) {
          case "IntType": {ESLVal $142 = _v33.termRef(0);
            
            {ESLVal l1 = $141;
            
            {ESLVal l2 = $142;
            
            return t1;
          }
          }
          }
          default: switch(_v33.termName) {
            case "StrType": {ESLVal $130 = _v33.termRef(0);
              
              {ESLVal _v301 = _v34;
              
              {ESLVal _v302 = $130;
              
              return t2;
            }
            }
            }
            default: {ESLVal _v303 = _v34;
              
              {ESLVal _v304 = _v33;
              
              return error(new ESLVal("TypeError",_v276,new ESLVal("incomptible types for +: ").add(ppType.apply(_v303,_v270).add(new ESLVal(" and ").add(ppType.apply(_v304,_v270))))));
            }
            }
          }
        }
        }
      case "FloatType": {ESLVal $139 = _v34.termRef(0);
          
          switch(_v33.termName) {
          case "FloatType": {ESLVal $140 = _v33.termRef(0);
            
            {ESLVal l1 = $139;
            
            {ESLVal l2 = $140;
            
            return t1;
          }
          }
          }
          default: switch(_v33.termName) {
            case "StrType": {ESLVal $130 = _v33.termRef(0);
              
              {ESLVal _v297 = _v34;
              
              {ESLVal _v298 = $130;
              
              return t2;
            }
            }
            }
            default: {ESLVal _v299 = _v34;
              
              {ESLVal _v300 = _v33;
              
              return error(new ESLVal("TypeError",_v276,new ESLVal("incomptible types for +: ").add(ppType.apply(_v299,_v270).add(new ESLVal(" and ").add(ppType.apply(_v300,_v270))))));
            }
            }
          }
        }
        }
      case "ListType": {ESLVal $136 = _v34.termRef(0);
          ESLVal $135 = _v34.termRef(1);
          
          switch(_v33.termName) {
          case "ListType": {ESLVal $138 = _v33.termRef(0);
            ESLVal $137 = _v33.termRef(1);
            
            {ESLVal l1 = $136;
            
            {ESLVal _v287 = $135;
            
            {ESLVal l2 = $138;
            
            {ESLVal _v288 = $137;
            
            if(typeEqual.apply(_v287,_v288).boolVal)
            return new ESLVal("ListType",l1,_v287);
            else
              switch(_v33.termName) {
                case "StrType": {ESLVal $130 = _v33.termRef(0);
                  
                  {ESLVal _v289 = _v34;
                  
                  {ESLVal _v290 = $130;
                  
                  return _v288;
                }
                }
                }
                default: {ESLVal _v291 = _v34;
                  
                  {ESLVal _v292 = _v33;
                  
                  return error(new ESLVal("TypeError",_v276,new ESLVal("incomptible types for +: ").add(ppType.apply(_v291,_v270).add(new ESLVal(" and ").add(ppType.apply(_v292,_v270))))));
                }
                }
              }
          }
          }
          }
          }
          }
          default: switch(_v33.termName) {
            case "StrType": {ESLVal $130 = _v33.termRef(0);
              
              {ESLVal _v293 = _v34;
              
              {ESLVal _v294 = $130;
              
              return t2;
            }
            }
            }
            default: {ESLVal _v295 = _v34;
              
              {ESLVal _v296 = _v33;
              
              return error(new ESLVal("TypeError",_v276,new ESLVal("incomptible types for +: ").add(ppType.apply(_v295,_v270).add(new ESLVal(" and ").add(ppType.apply(_v296,_v270))))));
            }
            }
          }
        }
        }
      case "SetType": {ESLVal $132 = _v34.termRef(0);
          ESLVal $131 = _v34.termRef(1);
          
          switch(_v33.termName) {
          case "SetType": {ESLVal $134 = _v33.termRef(0);
            ESLVal $133 = _v33.termRef(1);
            
            {ESLVal l1 = $132;
            
            {ESLVal _v277 = $131;
            
            {ESLVal l2 = $134;
            
            {ESLVal _v278 = $133;
            
            if(typeEqual.apply(_v277,_v278).boolVal)
            return new ESLVal("SetType",l1,_v277);
            else
              switch(_v33.termName) {
                case "StrType": {ESLVal $130 = _v33.termRef(0);
                  
                  {ESLVal _v279 = _v34;
                  
                  {ESLVal _v280 = $130;
                  
                  return _v278;
                }
                }
                }
                default: {ESLVal _v281 = _v34;
                  
                  {ESLVal _v282 = _v33;
                  
                  return error(new ESLVal("TypeError",_v276,new ESLVal("incomptible types for +: ").add(ppType.apply(_v281,_v270).add(new ESLVal(" and ").add(ppType.apply(_v282,_v270))))));
                }
                }
              }
          }
          }
          }
          }
          }
          default: switch(_v33.termName) {
            case "StrType": {ESLVal $130 = _v33.termRef(0);
              
              {ESLVal _v283 = _v34;
              
              {ESLVal _v284 = $130;
              
              return t2;
            }
            }
            }
            default: {ESLVal _v285 = _v34;
              
              {ESLVal _v286 = _v33;
              
              return error(new ESLVal("TypeError",_v276,new ESLVal("incomptible types for +: ").add(ppType.apply(_v285,_v270).add(new ESLVal(" and ").add(ppType.apply(_v286,_v270))))));
            }
            }
          }
        }
        }
        default: switch(_v33.termName) {
          case "StrType": {ESLVal $130 = _v33.termRef(0);
            
            {ESLVal _v307 = _v34;
            
            {ESLVal _v308 = $130;
            
            return t2;
          }
          }
          }
          default: {ESLVal _v309 = _v34;
            
            {ESLVal _v310 = _v33;
            
            return error(new ESLVal("TypeError",_v276,new ESLVal("incomptible types for +: ").add(ppType.apply(_v309,_v270).add(new ESLVal(" and ").add(ppType.apply(_v310,_v270))))));
          }
          }
        }
      }
      }
      }
    }
  });
  private static ESLVal applyTypeExp = new ESLVal(new Function(new ESLVal("applyTypeExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v265 = $args[0];
  ESLVal _v264 = $args[1];
  ESLVal _v263 = $args[2];
  ESLVal _v262 = $args[3];
  ESLVal _v261 = $args[4];
  ESLVal _v260 = $args[5];
  ESLVal _v259 = $args[6];
  {ESLVal _v267 = substTypesEnv.apply(_v259,_v263);
        ESLVal _v266 = expType.apply(_v264,_v262,_v261,_v260,_v259);
        
        {ESLVal _v32 = _v266;
        
        switch(_v32.termName) {
        case "ForallType": {ESLVal $129 = _v32.termRef(0);
          ESLVal $128 = _v32.termRef(1);
          ESLVal $127 = _v32.termRef(2);
          
          {ESLVal l1 = $129;
          
          {ESLVal ns = $128;
          
          {ESLVal _v268 = $127;
          
          if(length.apply(ns).eql(length.apply(_v267)).boolVal)
          {ESLVal env = zipTypeEnv.apply(ns,_v267);
            
            return substTypeEnv.apply(env.add(_v261),_v268);
          }
          else
            return error(new ESLVal("TypeError",_v265,new ESLVal("universal type expects ").add(length.apply(ns).add(new ESLVal(" types, but supplied with ").add(length.apply(_v267))))));
        }
        }
        }
        }
        default: {ESLVal _v269 = _v32;
          
          return error(new ESLVal("TypeError",_v265,new ESLVal("expecting a universal type: ").add(_v269)));
        }
      }
      }
      }
    }
  });
  private static ESLVal expTypes = new ESLVal(new Function(new ESLVal("expTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v258 = $args[0];
  ESLVal _v257 = $args[1];
  ESLVal _v256 = $args[2];
  ESLVal _v255 = $args[3];
  ESLVal _v254 = $args[4];
  return map.apply(new ESLVal(new Function(new ESLVal("fun537"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal e = $args[0];
        return expType.apply(e,_v257,_v256,_v255,_v254);
          }
        }),_v258);
    }
  });
  private static ESLVal applyType = new ESLVal(new Function(new ESLVal("applyType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v253 = $args[0];
  ESLVal _v252 = $args[1];
  ESLVal _v251 = $args[2];
  ESLVal _v250 = $args[3];
  ESLVal _v249 = $args[4];
  ESLVal _v248 = $args[5];
  ESLVal _v247 = $args[6];
  {ESLVal _v31 = typeNF.apply(expType.apply(_v252,_v250,_v249,_v248,_v247),_v247);
        
        switch(_v31.termName) {
        case "FunType": {ESLVal $126 = _v31.termRef(0);
          ESLVal $125 = _v31.termRef(1);
          ESLVal $124 = _v31.termRef(2);
          
          {ESLVal l1 = $126;
          
          {ESLVal domain = $125;
          
          {ESLVal range = $124;
          
          {ESLVal supplied = expTypes.apply(_v251,_v250,_v249,_v248,_v247);
          
          if(length.apply(domain).eql(length.apply(supplied)).boolVal)
          if(subTypes.apply(supplied,domain).boolVal)
            return range;
            else
              return error(new ESLVal("TypeError",_v253,new ESLVal("supplied argument types ").add(ppTypes.apply(supplied,_v247).add(new ESLVal(" do not match function domain ").add(ppTypes.apply(domain,_v247))))));
          else
            return error(new ESLVal("TypeError",_v253,new ESLVal("expecting ").add(length.apply(domain).add(new ESLVal(" args, but supplied with ").add(length.apply(supplied))))));
        }
        }
        }
        }
        }
        default: {ESLVal t = _v31;
          
          return error(new ESLVal("TypeError",_v253,new ESLVal("unknown type for apply: ").add(ppType.apply(t,_v247))));
        }
      }
      }
    }
  });
  private static ESLVal ifType = new ESLVal(new Function(new ESLVal("ifType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v246 = $args[0];
  ESLVal _v245 = $args[1];
  ESLVal _v244 = $args[2];
  ESLVal _v243 = $args[3];
  ESLVal _v242 = $args[4];
  ESLVal _v241 = $args[5];
  ESLVal _v240 = $args[6];
  ESLVal _v239 = $args[7];
  {ESLVal testType = expType.apply(_v245,_v242,_v241,_v240,_v239);
        
        if(isBoolType.apply(testType).boolVal)
        {ESLVal conseqType = expType.apply(_v244,_v242,_v241,_v240,_v239);
          ESLVal altType = expType.apply(_v243,_v242,_v241,_v240,_v239);
          
          if(typeEqual.apply(conseqType,altType).boolVal)
          return conseqType;
          else
            return error(new ESLVal("TypeError",_v246,new ESLVal("conseq and alt types do not agree: ").add(ppType.apply(conseqType,_v239).add(new ESLVal(" ").add(ppType.apply(altType,_v239))))));
        }
        else
          return error(new ESLVal("if expects a bool ").add(ppType.apply(testType,_v239)));
      }
    }
  });
  private static ESLVal checkDecs = new ESLVal(new Function(new ESLVal("checkDecs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal ds = $args[0];
  {ESLVal _v29 = ds;
        
        if(_v29.isCons())
        {ESLVal $122 = _v29.head();
          ESLVal $123 = _v29.tail();
          
          {ESLVal d = $122;
          
          {ESLVal _v237 = $123;
          
          if(member.apply(decName.apply(d),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v30 = $qualArg;
              
              {ESLVal _v238 = _v30;
              
              return ESLVal.list(ESLVal.list(decName.apply(_v238)));
            }
            }
          }
        }).map(_v237).flatten().flatten()).boolVal)
          return error(new ESLVal("TypeError",decLoc.apply(d),new ESLVal(" duplicate argument ").add(decName.apply(d))));
          else
            return checkDecs.apply(_v237);
        }
        }
        }
      else if(_v29.isNil())
        return $null;
      else return error(new ESLVal("case error at Pos(64852,65085)").add(ESLVal.list(_v29)));
      }
    }
  });
  private static ESLVal funType = new ESLVal(new Function(new ESLVal("funType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v234 = $args[0];
  ESLVal _v233 = $args[1];
  ESLVal _v232 = $args[2];
  ESLVal _v231 = $args[3];
  ESLVal _v230 = $args[4];
  ESLVal _v229 = $args[5];
  ESLVal _v228 = $args[6];
  ESLVal _v227 = $args[7];
  ESLVal _v226 = $args[8];
  {checkDecs.apply(_v232);
      {ESLVal nType = expType.apply(_v233,_v229,_v228,_v227,_v226);
        
        if(isStrType.apply(nType).boolVal)
        {ESLVal declaredType = substTypeEnv.apply(_v226,_v231);
          
          return decTypes.apply(_v232,_v228,_v226,new ESLVal(new Function(new ESLVal("fun538"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v236 = $args[0];
          ESLVal _v235 = $args[1];
          {ESLVal actualRange = expType.apply(_v230,_v229,_v235,_v227,_v226);
                
                if(subType.apply(new ESLVal("FunType",_v234,_v236,actualRange),declaredType).boolVal)
                return new ESLVal("FunType",_v234,_v236,actualRange);
                else
                  return error(new ESLVal("TypeError",_v234,new ESLVal("function declared type ").add(ppType.apply(declaredType,_v226).add(new ESLVal(" but is ").add(ppType.apply(new ESLVal("FunType",_v234,_v236,actualRange),_v226))))));
              }
            }
          }));
        }
        else
          return error(new ESLVal("TypeError",_v234,new ESLVal("expecting a string for a function name: ").add(_v233)));
      }}
    }
  });
  private static ESLVal decTypes = new ESLVal(new Function(new ESLVal("decTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v222 = $args[0];
  ESLVal _v221 = $args[1];
  ESLVal _v220 = $args[2];
  ESLVal _v219 = $args[3];
  LetRec letrec = new LetRec() {
        ESLVal processDecs = new ESLVal(new Function(new ESLVal("processDecs"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v224 = $args[0];
          ESLVal _v223 = $args[1];
          {ESLVal _v28 = _v224;
                
                if(_v28.isCons())
                {ESLVal $116 = _v28.head();
                  ESLVal $117 = _v28.tail();
                  
                  switch($116.termName) {
                  case "Dec": {ESLVal $121 = $116.termRef(0);
                    ESLVal $120 = $116.termRef(1);
                    ESLVal $119 = $116.termRef(2);
                    ESLVal $118 = $116.termRef(3);
                    
                    {ESLVal l = $121;
                    
                    {ESLVal n = $120;
                    
                    {ESLVal t = $119;
                    
                    {ESLVal st = $118;
                    
                    {ESLVal _v225 = $117;
                    
                    return processDecs.apply(_v225,_v223.cons(new ESLVal("Map",n,substTypeEnv.apply(_v220,t))));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(66278,66503)").add(ESLVal.list(_v28)));
                }
                }
              else if(_v28.isNil())
                return _v219.apply(reverse.apply(typeEnvRan.apply(_v223)),_v223.add(_v221));
              else return error(new ESLVal("case error at Pos(66278,66503)").add(ESLVal.list(_v28)));
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "processDecs": return processDecs;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal processDecs = letrec.get("processDecs");
      
        return processDecs.apply(_v222,$nil);
      
    }
  });
  private static ESLVal termType = new ESLVal(new Function(new ESLVal("termType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v218 = $args[0];
  ESLVal _v217 = $args[1];
  ESLVal _v216 = $args[2];
  ESLVal _v215 = $args[3];
  ESLVal _v214 = $args[4];
  ESLVal _v213 = $args[5];
  ESLVal _v212 = $args[6];
  ESLVal _v211 = $args[7];
  {ESLVal t0 = lookupType.apply(_v217,_v212);
        
        if(t0.eql($null).boolVal)
        return error(new ESLVal("TypeError",_v218,new ESLVal("cannot find cnstr ").add(_v217)));
        else
          {ESLVal t = unfoldIf.apply(t0);
            
            return termTypeCheckUnion.apply(t,_v218,_v217,_v216,_v215,_v214,_v213,_v212,_v211);
          }
      }
    }
  });
  private static ESLVal termTypeCheckUnion = new ESLVal(new Function(new ESLVal("termTypeCheckUnion"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v208 = $args[0];
  ESLVal _v207 = $args[1];
  ESLVal _v206 = $args[2];
  ESLVal _v205 = $args[3];
  ESLVal _v204 = $args[4];
  ESLVal _v203 = $args[5];
  ESLVal _v202 = $args[6];
  ESLVal _v201 = $args[7];
  ESLVal _v200 = $args[8];
  if(_v208.eql($null).boolVal)
        return error(new ESLVal("TypeError",_v207,new ESLVal("cannot find constructor ").add(_v206)));
        else
          {ESLVal _v26 = _v208;
            
            switch(_v26.termName) {
            case "TypeFun": {ESLVal $113 = _v26.termRef(0);
              ESLVal $112 = _v26.termRef(1);
              ESLVal $111 = _v26.termRef(2);
              
              {ESLVal lf = $113;
              
              {ESLVal ns = $112;
              
              {ESLVal body = $111;
              
              if(length.apply(ns).eql(length.apply(_v205)).boolVal)
              {ESLVal args = map.apply(new ESLVal(new Function(new ESLVal("fun539"),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      ESLVal _v209 = $args[0];
                  return substTypeEnv.apply(_v200,_v209);
                    }
                  }),_v205);
                
                {ESLVal _v27 = substTypeEnv.apply(zipTypeEnv.apply(ns,args),body);
                
                switch(_v27.termName) {
                case "UnionType": {ESLVal $115 = _v27.termRef(0);
                  ESLVal $114 = _v27.termRef(1);
                  
                  {ESLVal l1 = $115;
                  
                  {ESLVal terms = $114;
                  
                  {ESLVal ts2 = findTermArgTypes.apply(_v206,terms);
                  
                  if(length.apply(_v204).eql(length.apply(ts2)).boolVal)
                  {checkTermArgTypes.apply(_v207,_v204,ts2,_v203,_v202,_v201,_v200);
                  return new ESLVal("UnionType",l1,terms);}
                  else
                    return error(_v206.add(new ESLVal(" expects ").add(length.apply(ts2).add(new ESLVal(" args, but you supplied ").add(length.apply(_v204))))));
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(67376,67926)").add(ESLVal.list(_v27)));
              }
              }
              }
              else
                return error(new ESLVal("TypeError",_v207,new ESLVal("generic constructor ").add(_v206.add(new ESLVal(" expects ").add(length.apply(ns).add(new ESLVal(" type arguments, but received ").add(length.apply(_v205))))))));
            }
            }
            }
            }
          case "UnionType": {ESLVal $110 = _v26.termRef(0);
              ESLVal $109 = _v26.termRef(1);
              
              {ESLVal l1 = $110;
              
              {ESLVal terms = $109;
              
              {ESLVal ts2 = findTermArgTypes.apply(_v206,terms);
              
              if(length.apply(_v205).neql($zero).boolVal)
              return error(new ESLVal("TypeError",_v207,new ESLVal("generic application of non-generic constructior: ").add(_v206)));
              else
                if(length.apply(_v204).eql(length.apply(ts2)).boolVal)
                  {checkTermArgTypes.apply(_v207,_v204,ts2,_v203,_v202,_v201,_v200);
                  return _v208;}
                  else
                    return error(_v206.add(new ESLVal(" expects ").add(length.apply(ts2).add(new ESLVal(" args, but you supplied ").add(length.apply(_v204))))));
            }
            }
            }
            }
            default: {ESLVal _v210 = _v26;
              
              return error(new ESLVal("TypeError",_v207,new ESLVal("expecting a union type for ").add(_v206.add(new ESLVal(" but got ").add(ppType.apply(_v210,_v200))))));
            }
          }
          }
    }
  });
  private static ESLVal unfoldIf = new ESLVal(new Function(new ESLVal("unfoldIf"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v25 = t;
        
        switch(_v25.termName) {
        case "RecType": {ESLVal $108 = _v25.termRef(0);
          ESLVal $107 = _v25.termRef(1);
          ESLVal $106 = _v25.termRef(2);
          
          {ESLVal l = $108;
          
          {ESLVal n = $107;
          
          {ESLVal _v198 = $106;
          
          return unfoldIf.apply(unfoldType.apply(l,n,_v198));
        }
        }
        }
        }
        default: {ESLVal _v199 = _v25;
          
          return _v199;
        }
      }
      }
    }
  });
  private static ESLVal findTermArgTypes = new ESLVal(new Function(new ESLVal("findTermArgTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal n = $args[0];
  ESLVal terms = $args[1];
  {ESLVal _v24 = terms;
        
        if(_v24.isCons())
        {ESLVal $101 = _v24.head();
          ESLVal $102 = _v24.tail();
          
          switch($101.termName) {
          case "TermType": {ESLVal $105 = $101.termRef(0);
            ESLVal $104 = $101.termRef(1);
            ESLVal $103 = $101.termRef(2);
            
            {ESLVal l = $105;
            
            {ESLVal nn = $104;
            
            {ESLVal ts = $103;
            
            {ESLVal _v196 = $102;
            
            if(nn.eql(n).boolVal)
            return ts;
            else
              {ESLVal t = $101;
                
                {ESLVal _v197 = $102;
                
                return findTermArgTypes.apply(n,_v197);
              }
              }
          }
          }
          }
          }
          }
          default: {ESLVal t = $101;
            
            {ESLVal ts = $102;
            
            return findTermArgTypes.apply(n,ts);
          }
          }
        }
        }
      else if(_v24.isNil())
        return error(new ESLVal("cannot find constructor ").add(n));
      else return error(new ESLVal("case error at Pos(68922,69122)").add(ESLVal.list(_v24)));
      }
    }
  });
  private static ESLVal checkTermArgTypes = new ESLVal(new Function(new ESLVal("checkTermArgTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v193 = $args[0];
  ESLVal _v192 = $args[1];
  ESLVal _v191 = $args[2];
  ESLVal _v190 = $args[3];
  ESLVal _v189 = $args[4];
  ESLVal _v188 = $args[5];
  ESLVal _v187 = $args[6];
  {ESLVal _v23 = _v192;
        ESLVal _v22 = _v191;
        
        if(_v23.isCons())
        {ESLVal $95 = _v23.head();
          ESLVal $96 = _v23.tail();
          
          if(_v22.isCons())
          {ESLVal $97 = _v22.head();
            ESLVal $98 = _v22.tail();
            
            {ESLVal e = $95;
            
            {ESLVal _v194 = $96;
            
            {ESLVal t = $97;
            
            {ESLVal _v195 = $98;
            
            {ESLVal tt = expType.apply(e,_v190,_v189,_v188,_v187);
            
            if(typeEqual.apply(t,tt).boolVal)
            return checkTermArgTypes.apply(_v193,_v194,_v195,_v190,_v189,_v188,_v187);
            else
              return error(new ESLVal("TypeError",_v193,new ESLVal("expected constructor arg type ").add(ppType.apply(t,_v187).add(new ESLVal(" but supplied ").add(ppType.apply(tt,_v187))))));
          }
          }
          }
          }
          }
          }
        else if(_v22.isNil())
          return error(new ESLVal("case error at Pos(69240,69662)").add(ESLVal.list(_v23,_v22)));
        else return error(new ESLVal("case error at Pos(69240,69662)").add(ESLVal.list(_v23,_v22)));
        }
      else if(_v23.isNil())
        if(_v22.isCons())
          {ESLVal $99 = _v22.head();
            ESLVal $100 = _v22.tail();
            
            return error(new ESLVal("case error at Pos(69240,69662)").add(ESLVal.list(_v23,_v22)));
          }
        else if(_v22.isNil())
          return $null;
        else return error(new ESLVal("case error at Pos(69240,69662)").add(ESLVal.list(_v23,_v22)));
      else return error(new ESLVal("case error at Pos(69240,69662)").add(ESLVal.list(_v23,_v22)));
      }
    }
  });
  private static ESLVal notType = new ESLVal(new Function(new ESLVal("notType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v185 = $args[0];
  ESLVal _v184 = $args[1];
  ESLVal _v183 = $args[2];
  ESLVal _v182 = $args[3];
  ESLVal _v181 = $args[4];
  ESLVal _v180 = $args[5];
  {ESLVal _v21 = expType.apply(_v184,_v183,_v182,_v181,_v180);
        
        switch(_v21.termName) {
        case "BoolType": {ESLVal $94 = _v21.termRef(0);
          
          {ESLVal _v186 = $94;
          
          return new ESLVal("BoolType",_v186);
        }
        }
        default: {ESLVal t = _v21;
          
          return error(new ESLVal("TypeError",_v185,new ESLVal("expecting a boolean: ").add(ppType.apply(t,_v180))));
        }
      }
      }
    }
  });
  private static ESLVal varType = new ESLVal(new Function(new ESLVal("varType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal n = $args[1];
  ESLVal valueEnv = $args[2];
  {ESLVal t = lookupType.apply(n,valueEnv);
        
        if(t.eql($null).boolVal)
        return error(new ESLVal("TypeError",l,new ESLVal("unbound variable ").add(n)));
        else
          {ESLVal _v20 = t;
            
            switch(_v20.termName) {
            case "TypeClosure": {ESLVal $93 = _v20.termRef(0);
              
              {ESLVal f = $93;
              
              return f.apply();
            }
            }
            default: {ESLVal _v179 = _v20;
              
              return _v179;
            }
          }
          }
      }
    }
  });
  private static ESLVal blockType = new ESLVal(new Function(new ESLVal("blockType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v178 = $args[0];
  ESLVal _v177 = $args[1];
  ESLVal _v176 = $args[2];
  ESLVal _v175 = $args[3];
  ESLVal _v174 = $args[4];
  ESLVal _v173 = $args[5];
  {ESLVal[] t = new ESLVal[]{new ESLVal("VoidType",_v178)};
        
        {{
        ESLVal _v19 = _v177;
        while(_v19.isCons()) {
          ESLVal e = _v19.headVal;
          t[0] = expType.apply(e,_v176,_v175,_v174,_v173);
          _v19 = _v19.tailVal;}
      }
      return t[0];}
      }
    }
  });
  private static ESLVal listType = new ESLVal(new Function(new ESLVal("listType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v172 = $args[0];
  ESLVal _v171 = $args[1];
  ESLVal _v170 = $args[2];
  ESLVal _v169 = $args[3];
  ESLVal _v168 = $args[4];
  ESLVal _v167 = $args[5];
  if(_v171.eql($nil).boolVal)
        return new ESLVal("ForallType",_v172,ESLVal.list(new ESLVal("T")),new ESLVal("ListType",_v172,new ESLVal("VarType",_v172,new ESLVal("T"))));
        else
          {ESLVal ts = map.apply(new ESLVal(new Function(new ESLVal("fun540"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal e = $args[0];
              return expType.apply(e,_v170,_v169,_v168,_v167);
                }
              }),_v171);
            
            if(allEqualTypes.apply(head.apply(ts),tail.apply(ts)).boolVal)
            return new ESLVal("ListType",_v172,head.apply(ts));
            else
              return error(new ESLVal("TypeError",_v172,new ESLVal("lists should have elements of the same type: ").add(_v171)));
          }
    }
  });
  private static ESLVal setType = new ESLVal(new Function(new ESLVal("setType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v166 = $args[0];
  ESLVal _v165 = $args[1];
  ESLVal _v164 = $args[2];
  ESLVal _v163 = $args[3];
  ESLVal _v162 = $args[4];
  ESLVal _v161 = $args[5];
  if(_v165.eql($nil).boolVal)
        return new ESLVal("ForallType",_v166,ESLVal.list(new ESLVal("T")),new ESLVal("SetType",_v166,new ESLVal("VarType",_v166,new ESLVal("T"))));
        else
          {ESLVal ts = map.apply(new ESLVal(new Function(new ESLVal("fun541"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal e = $args[0];
              return expType.apply(e,_v164,_v163,_v162,_v161);
                }
              }),_v165);
            
            if(allEqualTypes.apply(head.apply(ts),tail.apply(ts)).boolVal)
            return new ESLVal("SetType",_v166,head.apply(ts));
            else
              return error(new ESLVal("TypeError",_v166,new ESLVal("sets should have elements of the same type: ").add(_v165)));
          }
    }
  });
  private static ESLVal bagType = new ESLVal(new Function(new ESLVal("bagType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v160 = $args[0];
  ESLVal _v159 = $args[1];
  ESLVal _v158 = $args[2];
  ESLVal _v157 = $args[3];
  ESLVal _v156 = $args[4];
  ESLVal _v155 = $args[5];
  if(_v159.eql($nil).boolVal)
        return new ESLVal("ForallType",_v160,ESLVal.list(new ESLVal("T")),new ESLVal("BagType",_v160,new ESLVal("VarType",_v160,new ESLVal("T"))));
        else
          {ESLVal ts = map.apply(new ESLVal(new Function(new ESLVal("fun542"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal e = $args[0];
              return expType.apply(e,_v158,_v157,_v156,_v155);
                }
              }),_v159);
            
            if(allEqualTypes.apply(head.apply(ts),tail.apply(ts)).boolVal)
            return new ESLVal("BagType",_v160,head.apply(ts));
            else
              return error(new ESLVal("TypeError",_v160,new ESLVal("bags should have elements of the same type: ").add(_v159)));
          }
    }
  });
  private static ESLVal recTypes = new ESLVal(new Function(new ESLVal("recTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal env = $args[0];
  LetRec letrec = new LetRec() {
        ESLVal fixEnv = new ESLVal(new Function(new ESLVal("fixEnv"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v153 = $args[0];
          {ESLVal[] e = new ESLVal[]{$null};
                
                {ESLVal fenv = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      ESLVal $qualArg = $args[0];
                  {ESLVal _v17 = $qualArg;
                        
                        {ESLVal t = _v17;
                        
                        return ESLVal.list(new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                          public ESLVal apply(ESLVal... $args) {
                            ESLVal _v154 = $args[0];
                        {ESLVal _v18 = _v154;
                              
                              {ESLVal n = _v18;
                              
                              return ESLVal.list(ESLVal.list(new ESLVal("Map",n,new ESLVal("TypeClosure",new ESLVal(new Function(new ESLVal("lookup: ").add(n),getSelf()) {
                                public ESLVal apply(ESLVal... $args) {
                                  return lookupType.apply(n,e[0]);
                                }
                              })))));
                            }
                            }
                          }
                        }).map(typeFV.apply(t)).flatten().flatten());
                      }
                      }
                    }
                  }).map(typeEnvRan.apply(_v153)).flatten().flatten();
                
                {ESLVal env1 = substOnce.apply(_v153,fenv);
                
                {e[0] = env1;
              return env1;}
              }
              }
              }
            }
          });
        ESLVal introduceRecTypes = new ESLVal(new Function(new ESLVal("introduceRecTypes"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v152 = $args[0];
          {ESLVal _v16 = _v152;
                
                if(_v16.isCons())
                {ESLVal $87 = _v16.head();
                  ESLVal $88 = _v16.tail();
                  
                  switch($87.termName) {
                  case "Map": {ESLVal $90 = $87.termRef(0);
                    ESLVal $89 = $87.termRef(1);
                    
                    switch($89.termName) {
                    case "RecordType": {ESLVal $92 = $89.termRef(0);
                      ESLVal $91 = $89.termRef(1);
                      
                      {ESLVal n = $90;
                      
                      {ESLVal l = $92;
                      
                      {ESLVal fs = $91;
                      
                      {ESLVal e = $88;
                      
                      return introduceRecTypes.apply(e).cons(new ESLVal("Map",n,new ESLVal("RecordType",l,fs)));
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal n = $90;
                      
                      {ESLVal t = $89;
                      
                      {ESLVal e = $88;
                      
                      if(member.apply(n,typeFV.apply(t)).boolVal)
                      return introduceRecTypes.apply(e).cons(new ESLVal("Map",n,new ESLVal("RecType",p0,n,t)));
                      else
                        return introduceRecTypes.apply(e).cons(new ESLVal("Map",n,t));
                    }
                    }
                    }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(72211,72525)").add(ESLVal.list(_v16)));
                }
                }
              else if(_v16.isNil())
                return _v152;
              else return error(new ESLVal("case error at Pos(72211,72525)").add(ESLVal.list(_v16)));
              }
            }
          });
        ESLVal substOnce = new ESLVal(new Function(new ESLVal("substOnce"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v150 = $args[0];
          ESLVal _v149 = $args[1];
          {ESLVal map1 = new ESLVal(new Function(new ESLVal("map1"),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      ESLVal m = $args[0];
                  {ESLVal _v14 = m;
                        
                        switch(_v14.termName) {
                        case "Map": {ESLVal $86 = _v14.termRef(0);
                          ESLVal $85 = _v14.termRef(1);
                          
                          {ESLVal n = $86;
                          
                          {ESLVal t = $85;
                          
                          return new ESLVal("Map",n,substTypeEnv.apply(new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                            public ESLVal apply(ESLVal... $args) {
                              ESLVal $qualArg = $args[0];
                          {ESLVal _v15 = $qualArg;
                                
                                {ESLVal _v151 = _v15;
                                
                                return ESLVal.list(ESLVal.list(new ESLVal("Map",_v151,lookupType.apply(_v151,_v149))));
                              }
                              }
                            }
                          }).map(typeFV.apply(t)).flatten().flatten(),t));
                        }
                        }
                        }
                        default: return error(new ESLVal("case error at Pos(72635,72766)").add(ESLVal.list(_v14)));
                      }
                      }
                    }
                  });
                
                return map.apply(map1,_v150);
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "fixEnv": return fixEnv;
            
            case "introduceRecTypes": return introduceRecTypes;
            
            case "substOnce": return substOnce;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal fixEnv = letrec.get("fixEnv");
      
      ESLVal introduceRecTypes = letrec.get("introduceRecTypes");
      
      ESLVal substOnce = letrec.get("substOnce");
      
        return fixEnv.apply(introduceRecTypes.apply(env));
      
    }
  });
  private static ESLVal typeFV = new ESLVal(new Function(new ESLVal("typeFV"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  return removeDups.apply(varTypeNames.apply(typeFV1.apply(t,$nil)));
    }
  });
  private static ESLVal varTypeNames = new ESLVal(new Function(new ESLVal("varTypeNames"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal vs = $args[0];
  return map.apply(varTypeName,vs);
    }
  });
  private static ESLVal varTypeName = new ESLVal(new Function(new ESLVal("varTypeName"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v13 = t;
        
        switch(_v13.termName) {
        case "VarType": {ESLVal $84 = _v13.termRef(0);
          ESLVal $83 = _v13.termRef(1);
          
          {ESLVal l = $84;
          
          {ESLVal n = $83;
          
          return n;
        }
        }
        }
        default: {ESLVal x = _v13;
          
          return new ESLVal("<var>");
        }
      }
      }
    }
  });
  private static ESLVal tdecsFV1 = new ESLVal(new Function(new ESLVal("tdecsFV1"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal decs = $args[0];
  ESLVal fv = $args[1];
  {ESLVal _v12 = decs;
        
        if(_v12.isCons())
        {ESLVal $81 = _v12.head();
          ESLVal $82 = _v12.tail();
          
          {ESLVal d = $81;
          
          {ESLVal ds = $82;
          
          return tdecFV1.apply(d,tdecsFV1.apply(ds,fv));
        }
        }
        }
      else if(_v12.isNil())
        return fv;
      else return error(new ESLVal("case error at Pos(73152,73241)").add(ESLVal.list(_v12)));
      }
    }
  });
  private static ESLVal tdecFV1 = new ESLVal(new Function(new ESLVal("tdecFV1"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d = $args[0];
  ESLVal fv = $args[1];
  {ESLVal _v11 = d;
        
        switch(_v11.termName) {
        case "Dec": {ESLVal $80 = _v11.termRef(0);
          ESLVal $79 = _v11.termRef(1);
          ESLVal $78 = _v11.termRef(2);
          ESLVal $77 = _v11.termRef(3);
          
          {ESLVal l = $80;
          
          {ESLVal n = $79;
          
          {ESLVal t = $78;
          
          {ESLVal st = $77;
          
          return typeFV1.apply(t,fv);
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(73285,73364)").add(ESLVal.list(_v11)));
      }
      }
    }
  });
  private static ESLVal handlersFV1 = new ESLVal(new Function(new ESLVal("handlersFV1"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal handlers = $args[0];
  ESLVal fv = $args[1];
  {ESLVal _v10 = handlers;
        
        if(_v10.isCons())
        {ESLVal $75 = _v10.head();
          ESLVal $76 = _v10.tail();
          
          {ESLVal m = $75;
          
          {ESLVal hs = $76;
          
          return handlerFV1.apply(m,handlersFV1.apply(hs,fv));
        }
        }
        }
      else if(_v10.isNil())
        return fv;
      else return error(new ESLVal("case error at Pos(73422,73524)").add(ESLVal.list(_v10)));
      }
    }
  });
  private static ESLVal handlerFV1 = new ESLVal(new Function(new ESLVal("handlerFV1"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal m = $args[0];
  ESLVal fv = $args[1];
  {ESLVal _v9 = m;
        
        switch(_v9.termName) {
        case "MessageType": {ESLVal $74 = _v9.termRef(0);
          ESLVal $73 = _v9.termRef(1);
          
          {ESLVal l = $74;
          
          {ESLVal ts = $73;
          
          return typesFV1.apply(ts,fv);
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(73572,73648)").add(ESLVal.list(_v9)));
      }
      }
    }
  });
  private static ESLVal typesFV1 = new ESLVal(new Function(new ESLVal("typesFV1"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal ts = $args[0];
  ESLVal fv = $args[1];
  {ESLVal _v8 = ts;
        
        if(_v8.isCons())
        {ESLVal $71 = _v8.head();
          ESLVal $72 = _v8.tail();
          
          {ESLVal t = $71;
          
          {ESLVal _v148 = $72;
          
          return typeFV1.apply(t,typesFV1.apply(_v148,fv));
        }
        }
        }
      else if(_v8.isNil())
        return fv;
      else return error(new ESLVal("case error at Pos(73697,73784)").add(ESLVal.list(_v8)));
      }
    }
  });
  private static ESLVal typeFV1 = new ESLVal(new Function(new ESLVal("typeFV1"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  ESLVal fv = $args[1];
  {ESLVal _v3 = t;
        
        switch(_v3.termName) {
        case "ArrayType": {ESLVal $60 = _v3.termRef(0);
          ESLVal $59 = _v3.termRef(1);
          
          {ESLVal l = $60;
          
          {ESLVal _v147 = $59;
          
          return typeFV1.apply(_v147,fv);
        }
        }
        }
      case "ActType": {ESLVal $58 = _v3.termRef(0);
          ESLVal $57 = _v3.termRef(1);
          ESLVal $56 = _v3.termRef(2);
          
          {ESLVal l = $58;
          
          {ESLVal decs = $57;
          
          {ESLVal handlers = $56;
          
          return tdecsFV1.apply(decs,handlersFV1.apply(handlers,fv));
        }
        }
        }
        }
      case "ExtendedAct": {ESLVal $55 = _v3.termRef(0);
          ESLVal $54 = _v3.termRef(1);
          ESLVal $53 = _v3.termRef(2);
          ESLVal $52 = _v3.termRef(3);
          
          {ESLVal l = $55;
          
          {ESLVal parent = $54;
          
          {ESLVal decs = $53;
          
          {ESLVal handlers = $52;
          
          return tdecsFV1.apply(decs,handlersFV1.apply(handlers,typeFV1.apply(parent,fv)));
        }
        }
        }
        }
        }
      case "ApplyType": {ESLVal $51 = _v3.termRef(0);
          ESLVal $50 = _v3.termRef(1);
          ESLVal $49 = _v3.termRef(2);
          
          {ESLVal l = $51;
          
          {ESLVal n = $50;
          
          {ESLVal types = $49;
          
          return typesFV1.apply(types,fv.cons(new ESLVal("VarType",l,n)));
        }
        }
        }
        }
      case "ApplyTypeFun": {ESLVal $48 = _v3.termRef(0);
          ESLVal $47 = _v3.termRef(1);
          ESLVal $46 = _v3.termRef(2);
          
          {ESLVal l = $48;
          
          {ESLVal op = $47;
          
          {ESLVal args = $46;
          
          return typesFV1.apply(args,typeFV1.apply(op,fv));
        }
        }
        }
        }
      case "BoolType": {ESLVal $45 = _v3.termRef(0);
          
          {ESLVal l = $45;
          
          return fv;
        }
        }
      case "FieldType": {ESLVal $44 = _v3.termRef(0);
          ESLVal $43 = _v3.termRef(1);
          ESLVal $42 = _v3.termRef(2);
          
          {ESLVal l = $44;
          
          {ESLVal n = $43;
          
          {ESLVal _v146 = $42;
          
          return typeFV1.apply(_v146,fv);
        }
        }
        }
        }
      case "FloatType": {ESLVal $41 = _v3.termRef(0);
          
          {ESLVal l = $41;
          
          return fv;
        }
        }
      case "ForallType": {ESLVal $40 = _v3.termRef(0);
          ESLVal $39 = _v3.termRef(1);
          ESLVal $38 = _v3.termRef(2);
          
          {ESLVal l = $40;
          
          {ESLVal ns = $39;
          
          {ESLVal _v143 = $38;
          
          return filter.apply(new ESLVal(new Function(new ESLVal("fun543"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v144 = $args[0];
          {ESLVal _v7 = _v144;
                
                switch(_v7.termName) {
                case "VarType": {ESLVal $70 = _v7.termRef(0);
                  ESLVal $69 = _v7.termRef(1);
                  
                  {ESLVal _v145 = $70;
                  
                  {ESLVal n = $69;
                  
                  return member.apply(n,ns).not();
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(74623,74683)").add(ESLVal.list(_v7)));
              }
              }
            }
          }),typeFV1.apply(_v143,$nil)).add(fv);
        }
        }
        }
        }
      case "FunType": {ESLVal $37 = _v3.termRef(0);
          ESLVal $36 = _v3.termRef(1);
          ESLVal $35 = _v3.termRef(2);
          
          {ESLVal l = $37;
          
          {ESLVal d = $36;
          
          {ESLVal r = $35;
          
          return typesFV1.apply(d,typeFV1.apply(r,fv));
        }
        }
        }
        }
      case "IntType": {ESLVal $34 = _v3.termRef(0);
          
          {ESLVal l = $34;
          
          return fv;
        }
        }
      case "ListType": {ESLVal $33 = _v3.termRef(0);
          ESLVal $32 = _v3.termRef(1);
          
          {ESLVal l = $33;
          
          {ESLVal _v142 = $32;
          
          return typeFV1.apply(_v142,fv);
        }
        }
        }
      case "BagType": {ESLVal $31 = _v3.termRef(0);
          ESLVal $30 = _v3.termRef(1);
          
          {ESLVal l = $31;
          
          {ESLVal _v141 = $30;
          
          return typeFV1.apply(_v141,fv);
        }
        }
        }
      case "SetType": {ESLVal $29 = _v3.termRef(0);
          ESLVal $28 = _v3.termRef(1);
          
          {ESLVal l = $29;
          
          {ESLVal _v140 = $28;
          
          return typeFV1.apply(_v140,fv);
        }
        }
        }
      case "NullType": {ESLVal $27 = _v3.termRef(0);
          
          {ESLVal l = $27;
          
          return fv;
        }
        }
      case "RecordType": {ESLVal $26 = _v3.termRef(0);
          ESLVal $25 = _v3.termRef(1);
          
          {ESLVal l = $26;
          
          {ESLVal fs = $25;
          
          return typesFV1.apply(new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v6 = $qualArg;
                
                switch(_v6.termName) {
                case "Dec": {ESLVal $68 = _v6.termRef(0);
                  ESLVal $67 = _v6.termRef(1);
                  ESLVal $66 = _v6.termRef(2);
                  ESLVal $65 = _v6.termRef(3);
                  
                  {ESLVal _v138 = $68;
                  
                  {ESLVal n = $67;
                  
                  {ESLVal _v139 = $66;
                  
                  {ESLVal dt = $65;
                  
                  return ESLVal.list(ESLVal.list(_v139));
                }
                }
                }
                }
                }
                default: {ESLVal _0 = _v6;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten(),fv);
        }
        }
        }
      case "RecType": {ESLVal $24 = _v3.termRef(0);
          ESLVal $23 = _v3.termRef(1);
          ESLVal $22 = _v3.termRef(2);
          
          {ESLVal l = $24;
          
          {ESLVal a = $23;
          
          {ESLVal _v135 = $22;
          
          return filter.apply(new ESLVal(new Function(new ESLVal("fun544"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v136 = $args[0];
          {ESLVal _v5 = _v136;
                
                switch(_v5.termName) {
                case "VarType": {ESLVal $64 = _v5.termRef(0);
                  ESLVal $63 = _v5.termRef(1);
                  
                  {ESLVal _v137 = $64;
                  
                  {ESLVal n = $63;
                  
                  return n.eql(a).not();
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(75124,75172)").add(ESLVal.list(_v5)));
              }
              }
            }
          }),typeFV1.apply(_v135,$nil)).add(fv);
        }
        }
        }
        }
      case "StrType": {ESLVal $21 = _v3.termRef(0);
          
          {ESLVal l = $21;
          
          return fv;
        }
        }
      case "TableType": {ESLVal $20 = _v3.termRef(0);
          ESLVal $19 = _v3.termRef(1);
          ESLVal $18 = _v3.termRef(2);
          
          {ESLVal l = $20;
          
          {ESLVal k = $19;
          
          {ESLVal v = $18;
          
          return typeFV1.apply(k,typeFV1.apply(v,fv));
        }
        }
        }
        }
      case "TypeClosure": {ESLVal $17 = _v3.termRef(0);
          
          {ESLVal f = $17;
          
          return $nil;
        }
        }
      case "TermType": {ESLVal $16 = _v3.termRef(0);
          ESLVal $15 = _v3.termRef(1);
          ESLVal $14 = _v3.termRef(2);
          
          {ESLVal l = $16;
          
          {ESLVal n = $15;
          
          {ESLVal ts = $14;
          
          return typesFV1.apply(ts,fv);
        }
        }
        }
        }
      case "TypeFun": {ESLVal $13 = _v3.termRef(0);
          ESLVal $12 = _v3.termRef(1);
          ESLVal $11 = _v3.termRef(2);
          
          {ESLVal l = $13;
          
          {ESLVal ns = $12;
          
          {ESLVal _v132 = $11;
          
          return filter.apply(new ESLVal(new Function(new ESLVal("fun545"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v133 = $args[0];
          {ESLVal _v4 = _v133;
                
                switch(_v4.termName) {
                case "VarType": {ESLVal $62 = _v4.termRef(0);
                  ESLVal $61 = _v4.termRef(1);
                  
                  {ESLVal _v134 = $62;
                  
                  {ESLVal n = $61;
                  
                  return member.apply(n,ns).not();
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(75468,75528)").add(ESLVal.list(_v4)));
              }
              }
            }
          }),typeFV1.apply(_v132,$nil)).add(fv);
        }
        }
        }
        }
      case "UnfoldType": {ESLVal $10 = _v3.termRef(0);
          ESLVal $9 = _v3.termRef(1);
          
          {ESLVal l = $10;
          
          {ESLVal _v131 = $9;
          
          return typeFV1.apply(_v131,fv);
        }
        }
        }
      case "UnionType": {ESLVal $8 = _v3.termRef(0);
          ESLVal $7 = _v3.termRef(1);
          
          {ESLVal l = $8;
          
          {ESLVal ts = $7;
          
          return typesFV1.apply(ts,fv);
        }
        }
        }
      case "VarType": {ESLVal $6 = _v3.termRef(0);
          ESLVal $5 = _v3.termRef(1);
          
          {ESLVal l = $6;
          
          {ESLVal n = $5;
          
          return fv.cons(t);
        }
        }
        }
      case "VoidType": {ESLVal $4 = _v3.termRef(0);
          
          {ESLVal l = $4;
          
          return fv;
        }
        }
      case "UnionRef": {ESLVal $3 = _v3.termRef(0);
          ESLVal $2 = _v3.termRef(1);
          ESLVal $1 = _v3.termRef(2);
          
          {ESLVal l = $3;
          
          {ESLVal _v130 = $2;
          
          {ESLVal n = $1;
          
          return typeFV1.apply(_v130,fv);
        }
        }
        }
        }
        default: {ESLVal x = _v3;
          
          return error(x);
        }
      }
      }
    }
  });
  public static ESLVal main = new ESLVal(new Function(new ESLVal("main"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      return new ESLVal(new BehaviourAdapter(false,getSelf(),new ESLVal("main")) {
          
          public ESLVal handle(ESLVal $m) {{ESLVal _v2 = $m;
            
            return error(new ESLVal("case error at Pos(0,0)").add(ESLVal.list(_v2)));
          }}
          public ESLVal get(String name) {
            switch(name) {
              
              default: throw new Error("ref illegal " + self + "." + name);
            }
          }
        public void handleTime(ESLVal $t) {
          {}
        }
        public ESLVal init() {
            return ((Supplier<ESLVal>)() -> { 
                {new Function(new ESLVal("try"),getSelf()) {
                  public ESLVal apply(ESLVal... args) { 
                    try { 
                      return typeCheckModule.apply(new ESLVal("esl/compiler/test1.esl"));
                    } catch(ESLError $exception) {
                      ESLVal $x = $exception.value;
                      {ESLVal _v1 = $x;
                  
                  {ESLVal message = _v1;
                  
                  return print.apply(new ESLVal("Type Error: ").add(message));
                }
                }
                    }
                  }
                }.apply();
                print.apply(new ESLVal("DONE"));
                return stopAll.apply();}
              }).get();
          }
        });
    }
  });
public static void main(String[] args) {
    newActor(main,new ESLVal(new Actor())); 
  }
}