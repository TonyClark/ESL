package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
// import static esl.Lists.*;
import static esl.compiler.Types.*;
import java.util.function.Supplier;
public class MethodTransform {
  public static ESLVal getSelf() { return $null; }
  
public static ESLVal addMethodCalls(ESLVal module) {
    
    {ESLVal _v1942 = module;
      
      switch(_v1942.termName) {
      case "JModule": {ESLVal $3926 = _v1942.termRef(0);
        ESLVal $3925 = _v1942.termRef(1);
        ESLVal $3924 = _v1942.termRef(2);
        ESLVal $3923 = _v1942.termRef(3);
        ESLVal $3922 = _v1942.termRef(4);
        
        {ESLVal name = $3926;
        
        {ESLVal imports = $3925;
        
        {ESLVal exports = $3924;
        
        {ESLVal methods = $3923;
        
        {ESLVal fields = $3922;
        
        {ESLVal methodNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1943 = $qualArg;
                
                switch(_v1943.termName) {
                case "JMethod": {ESLVal $3929 = _v1943.termRef(0);
                  ESLVal $3928 = _v1943.termRef(1);
                  ESLVal $3927 = _v1943.termRef(2);
                  
                  {ESLVal n = $3929;
                  
                  {ESLVal args = $3928;
                  
                  {ESLVal body = $3927;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1943;
                  
                  return $nil;
                }
              }
              }
            }
          }).map(methods).flatten().flatten();
        
        {ESLVal newMethods = new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal m = $l0.head();
                $l0 = $l0.tail();
                $v.add(walkJMethodDef(m,methodNames));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(methods);
        ESLVal newFields = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1944 = $qualArg;
                
                switch(_v1944.termName) {
                case "JField": {ESLVal $3932 = _v1944.termRef(0);
                  ESLVal $3931 = _v1944.termRef(1);
                  ESLVal $3930 = _v1944.termRef(2);
                  
                  {ESLVal n = $3932;
                  
                  {ESLVal t = $3931;
                  
                  {ESLVal e = $3930;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,walkJExp(e,methodNames))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1944;
                  
                  return $nil;
                }
              }
              }
            }
          }).map(fields).flatten().flatten();
        
        return new ESLVal("JModule",name,imports,exports,newMethods,newFields);
      }
      }
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(1166,1561)").add(ESLVal.list(_v1942)));
    }
    }
  }
  public static ESLVal addMethodCalls = new ESLVal(new Function(new ESLVal("addMethodCalls"),null) { public ESLVal apply(ESLVal... args) { return addMethodCalls(args[0]); }});
  private static ESLVal walkJMethodDef(ESLVal method,ESLVal methodNames) {
    
    {ESLVal _v1945 = method;
      
      switch(_v1945.termName) {
      case "JMethod": {ESLVal $3935 = _v1945.termRef(0);
        ESLVal $3934 = _v1945.termRef(1);
        ESLVal $3933 = _v1945.termRef(2);
        
        {ESLVal n = $3935;
        
        {ESLVal args = $3934;
        
        {ESLVal body = $3933;
        
        {ESLVal argNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1946 = $qualArg;
                
                switch(_v1946.termName) {
                case "JDec": {ESLVal $3937 = _v1946.termRef(0);
                  ESLVal $3936 = _v1946.termRef(1);
                  
                  {ESLVal _v1970 = $3937;
                  
                  {ESLVal t = $3936;
                  
                  return ESLVal.list(ESLVal.list(_v1970));
                }
                }
                }
                default: {ESLVal _0 = _v1946;
                  
                  return $nil;
                }
              }
              }
            }
          }).map(args).flatten().flatten();
        
        {ESLVal _v1971 = removeAll.apply(argNames,methodNames);
        
        return new ESLVal("JMethod",n,args,walkJCommand(body,_v1971));
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(1633,1862)").add(ESLVal.list(_v1945)));
    }
    }
  }
  private static ESLVal walkJMethodDef = new ESLVal(new Function(new ESLVal("walkJMethodDef"),null) { public ESLVal apply(ESLVal... args) { return walkJMethodDef(args[0],args[1]); }});
  private static ESLVal walkJExp(ESLVal x,ESLVal methodNames) {
    
    {ESLVal _v1947 = x;
      
      switch(_v1947.termName) {
      case "JApply": {ESLVal $4014 = _v1947.termRef(0);
        ESLVal $4013 = _v1947.termRef(1);
        
        switch($4014.termName) {
        case "JVar": {ESLVal $4016 = $4014.termRef(0);
          ESLVal $4015 = $4014.termRef(1);
          
          {ESLVal n = $4016;
          
          {ESLVal t = $4015;
          
          {ESLVal args = $4013;
          
          if(member.apply(n,methodNames).boolVal)
          return new ESLVal("JMethodCall",n,new java.util.function.Function<ESLVal,ESLVal>() {
              public ESLVal apply(ESLVal $l0) {
                ESLVal $a = $nil;
                java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                while(!$l0.isNil()) { 
                  ESLVal e = $l0.head();
                  $l0 = $l0.tail();
                  $v.add(walkJExp(e,methodNames));
                }
                for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                return $a;
              }}.apply(args));
          else
            {ESLVal op = $4014;
              
              {ESLVal _v1969 = $4013;
              
              return new ESLVal("JApply",walkJExp(op,methodNames),new java.util.function.Function<ESLVal,ESLVal>() {
                public ESLVal apply(ESLVal $l0) {
                  ESLVal $a = $nil;
                  java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                  while(!$l0.isNil()) { 
                    ESLVal e = $l0.head();
                    $l0 = $l0.tail();
                    $v.add(walkJExp(e,methodNames));
                  }
                  for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                  return $a;
                }}.apply(_v1969));
            }
            }
        }
        }
        }
        }
        default: {ESLVal op = $4014;
          
          {ESLVal args = $4013;
          
          return new ESLVal("JApply",walkJExp(op,methodNames),new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal e = $l0.head();
                $l0 = $l0.tail();
                $v.add(walkJExp(e,methodNames));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(args));
        }
        }
      }
      }
    case "JArrayRef": {ESLVal $4012 = _v1947.termRef(0);
        ESLVal $4011 = _v1947.termRef(1);
        
        {ESLVal array = $4012;
        
        {ESLVal index = $4011;
        
        return new ESLVal("JArrayRef",walkJExp(array,methodNames),walkJExp(index,methodNames));
      }
      }
      }
    case "JArrayUpdate": {ESLVal $4010 = _v1947.termRef(0);
        ESLVal $4009 = _v1947.termRef(1);
        ESLVal $4008 = _v1947.termRef(2);
        
        {ESLVal array = $4010;
        
        {ESLVal index = $4009;
        
        {ESLVal value = $4008;
        
        return new ESLVal("JArrayUpdate",walkJExp(array,methodNames),walkJExp(index,methodNames),walkJExp(value,methodNames));
      }
      }
      }
      }
    case "JBag": {ESLVal $4007 = _v1947.termRef(0);
        ESLVal $4006 = _v1947.termRef(1);
        
        {ESLVal t = $4007;
        
        {ESLVal values = $4006;
        
        return new ESLVal("JBag",t,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal v = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJExp(v,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(values));
      }
      }
      }
    case "JBecome": {ESLVal $4005 = _v1947.termRef(0);
        ESLVal $4004 = _v1947.termRef(1);
        
        {ESLVal behaviour = $4005;
        
        {ESLVal args = $4004;
        
        return new ESLVal("JBecome",walkJExp(behaviour,methodNames),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal arg = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJExp(arg,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(args));
      }
      }
      }
    case "JBehaviour": {ESLVal $4003 = _v1947.termRef(0);
        ESLVal $4002 = _v1947.termRef(1);
        ESLVal $4001 = _v1947.termRef(2);
        ESLVal $4000 = _v1947.termRef(3);
        ESLVal $3999 = _v1947.termRef(4);
        ESLVal $3998 = _v1947.termRef(5);
        
        {ESLVal exports = $4003;
        
        {ESLVal fields = $4002;
        
        {ESLVal methods = $4001;
        
        {ESLVal parent = $4000;
        
        {ESLVal init = $3999;
        
        {ESLVal handler = $3998;
        
        {ESLVal fieldNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1951 = $qualArg;
                
                switch(_v1951.termName) {
                case "JField": {ESLVal $4027 = _v1951.termRef(0);
                  ESLVal $4026 = _v1951.termRef(1);
                  ESLVal $4025 = _v1951.termRef(2);
                  
                  {ESLVal n = $4027;
                  
                  {ESLVal t = $4026;
                  
                  {ESLVal v = $4025;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1951;
                  
                  return $nil;
                }
              }
              }
            }
          }).map(fields).flatten().flatten();
        
        {ESLVal _v1968 = removeAll.apply(fieldNames,methodNames).add(new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1952 = $qualArg;
                
                switch(_v1952.termName) {
                case "JMethod": {ESLVal $4030 = _v1952.termRef(0);
                  ESLVal $4029 = _v1952.termRef(1);
                  ESLVal $4028 = _v1952.termRef(2);
                  
                  {ESLVal n = $4030;
                  
                  {ESLVal args = $4029;
                  
                  {ESLVal body = $4028;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1952;
                  
                  return $nil;
                }
              }
              }
            }
          }).map(methods).flatten().flatten());
        
        return new ESLVal("JBehaviour",exports,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal f = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJFieldDef(f,_v1968));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(fields),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal m = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJMethodDef(m,_v1968));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(methods),walkJExp(parent,_v1968),walkJExp(init,_v1968),walkJCommand(handler,_v1968));
      }
      }
      }
      }
      }
      }
      }
      }
      }
    case "JBinExp": {ESLVal $3997 = _v1947.termRef(0);
        ESLVal $3996 = _v1947.termRef(1);
        ESLVal $3995 = _v1947.termRef(2);
        
        {ESLVal e1 = $3997;
        
        {ESLVal op = $3996;
        
        {ESLVal e2 = $3995;
        
        return new ESLVal("JBinExp",walkJExp(e1,methodNames),op,walkJExp(e2,methodNames));
      }
      }
      }
      }
    case "JCmpExp": {ESLVal $3994 = _v1947.termRef(0);
        
        {ESLVal cmp = $3994;
        
        return new ESLVal("JCmpExp",walkJCmp(cmp,methodNames));
      }
      }
    case "JCommandExp": {ESLVal $3993 = _v1947.termRef(0);
        ESLVal $3992 = _v1947.termRef(1);
        
        {ESLVal c = $3993;
        
        {ESLVal t = $3992;
        
        return new ESLVal("JCommandExp",walkJCommand(c,methodNames),t);
      }
      }
      }
    case "JConstExp": {ESLVal $3991 = _v1947.termRef(0);
        
        {ESLVal c = $3991;
        
        return new ESLVal("JConstExp",c);
      }
      }
    case "JError": {ESLVal $3990 = _v1947.termRef(0);
        
        {ESLVal e = $3990;
        
        return new ESLVal("JError",walkJExp(e,methodNames));
      }
      }
    case "JExtendedBehaviour": {ESLVal $3989 = _v1947.termRef(0);
        ESLVal $3988 = _v1947.termRef(1);
        ESLVal $3987 = _v1947.termRef(2);
        ESLVal $3986 = _v1947.termRef(3);
        ESLVal $3985 = _v1947.termRef(4);
        ESLVal $3984 = _v1947.termRef(5);
        ESLVal $3983 = _v1947.termRef(6);
        
        {ESLVal exports = $3989;
        
        {ESLVal parent = $3988;
        
        {ESLVal fields = $3987;
        
        {ESLVal methods = $3986;
        
        {ESLVal init = $3985;
        
        {ESLVal handler = $3984;
        
        {ESLVal time = $3983;
        
        {ESLVal fieldNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1949 = $qualArg;
                
                switch(_v1949.termName) {
                case "JField": {ESLVal $4021 = _v1949.termRef(0);
                  ESLVal $4020 = _v1949.termRef(1);
                  ESLVal $4019 = _v1949.termRef(2);
                  
                  {ESLVal n = $4021;
                  
                  {ESLVal t = $4020;
                  
                  {ESLVal v = $4019;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1949;
                  
                  return $nil;
                }
              }
              }
            }
          }).map(fields).flatten().flatten();
        
        {ESLVal _v1967 = removeAll.apply(fieldNames,methodNames).add(new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1950 = $qualArg;
                
                switch(_v1950.termName) {
                case "JMethod": {ESLVal $4024 = _v1950.termRef(0);
                  ESLVal $4023 = _v1950.termRef(1);
                  ESLVal $4022 = _v1950.termRef(2);
                  
                  {ESLVal n = $4024;
                  
                  {ESLVal args = $4023;
                  
                  {ESLVal body = $4022;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1950;
                  
                  return $nil;
                }
              }
              }
            }
          }).map(methods).flatten().flatten());
        
        return new ESLVal("JExtendedBehaviour",exports,walkJExp(parent,_v1967),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal f = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJFieldDef(f,_v1967));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(fields),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal m = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJMethodDef(m,_v1967));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(methods),walkJExp(init,_v1967),walkJExp(handler,_v1967),walkJCommand(time,_v1967));
      }
      }
      }
      }
      }
      }
      }
      }
      }
      }
    case "JFlatten": {ESLVal $3982 = _v1947.termRef(0);
        
        {ESLVal e = $3982;
        
        return new ESLVal("JFlatten",walkJExp(e,methodNames));
      }
      }
    case "JFun": {ESLVal $3981 = _v1947.termRef(0);
        ESLVal $3980 = _v1947.termRef(1);
        ESLVal $3979 = _v1947.termRef(2);
        ESLVal $3978 = _v1947.termRef(3);
        
        {ESLVal name = $3981;
        
        {ESLVal args = $3980;
        
        {ESLVal t = $3979;
        
        {ESLVal body = $3978;
        
        {ESLVal argNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1948 = $qualArg;
                
                switch(_v1948.termName) {
                case "JDec": {ESLVal $4018 = _v1948.termRef(0);
                  ESLVal $4017 = _v1948.termRef(1);
                  
                  {ESLVal n = $4018;
                  
                  {ESLVal _v1965 = $4017;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                default: {ESLVal _0 = _v1948;
                  
                  return $nil;
                }
              }
              }
            }
          }).map(args).flatten().flatten();
        
        {ESLVal _v1966 = removeAll.apply(argNames,methodNames);
        
        {print.apply(new ESLVal("fun ").add(name.add(new ESLVal(" methodNames = ").add(_v1966))));
      return new ESLVal("JFun",walkJExp(name,_v1966),args,t,walkJCommand(body,_v1966));}
      }
      }
      }
      }
      }
      }
      }
    case "JGrab": {ESLVal $3977 = _v1947.termRef(0);
        ESLVal $3976 = _v1947.termRef(1);
        
        {ESLVal es = $3977;
        
        {ESLVal body = $3976;
        
        return new ESLVal("JGrab",new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJExp(e,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(es),walkJExp(body,methodNames));
      }
      }
      }
    case "JHead": {ESLVal $3975 = _v1947.termRef(0);
        
        {ESLVal e = $3975;
        
        return new ESLVal("JHead",walkJExp(e,methodNames));
      }
      }
    case "JIfExp": {ESLVal $3974 = _v1947.termRef(0);
        ESLVal $3973 = _v1947.termRef(1);
        ESLVal $3972 = _v1947.termRef(2);
        
        {ESLVal e1 = $3974;
        
        {ESLVal e2 = $3973;
        
        {ESLVal e3 = $3972;
        
        return new ESLVal("JIfExp",walkJExp(e1,methodNames),walkJExp(e2,methodNames),walkJExp(e3,methodNames));
      }
      }
      }
      }
    case "JList": {ESLVal $3971 = _v1947.termRef(0);
        ESLVal $3970 = _v1947.termRef(1);
        
        {ESLVal t = $3971;
        
        {ESLVal es = $3970;
        
        return new ESLVal("JList",t,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJExp(e,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(es));
      }
      }
      }
    case "JMapFun": {ESLVal $3969 = _v1947.termRef(0);
        ESLVal $3968 = _v1947.termRef(1);
        
        {ESLVal f = $3969;
        
        {ESLVal e = $3968;
        
        return new ESLVal("JMapFun",walkJExp(f,methodNames),walkJExp(e,methodNames));
      }
      }
      }
    case "JNew": {ESLVal $3967 = _v1947.termRef(0);
        ESLVal $3966 = _v1947.termRef(1);
        
        {ESLVal b = $3967;
        
        {ESLVal args = $3966;
        
        return new ESLVal("JNew",walkJExp(b,methodNames),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal arg = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJExp(arg,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(args));
      }
      }
      }
    case "JNewArray": {ESLVal $3965 = _v1947.termRef(0);
        
        {ESLVal e = $3965;
        
        return new ESLVal("JNewArray",walkJExp(e,methodNames));
      }
      }
    case "JNewJava": {ESLVal $3964 = _v1947.termRef(0);
        ESLVal $3963 = _v1947.termRef(1);
        
        {ESLVal path = $3964;
        
        {ESLVal args = $3963;
        
        return new ESLVal("JNewJava",path,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJExp(e,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(args));
      }
      }
      }
    case "JNewTable": {
        return new ESLVal("JNewTable",new ESLVal[]{});
      }
    case "JNil": {ESLVal $3962 = _v1947.termRef(0);
        
        {ESLVal t = $3962;
        
        return new ESLVal("JNil",t);
      }
      }
    case "JNot": {ESLVal $3961 = _v1947.termRef(0);
        
        {ESLVal e = $3961;
        
        return new ESLVal("JNot",walkJExp(e,methodNames));
      }
      }
    case "JNow": {
        return new ESLVal("JNow",new ESLVal[]{});
      }
    case "JNull": {
        return new ESLVal("JNull",new ESLVal[]{});
      }
    case "JProbably": {ESLVal $3960 = _v1947.termRef(0);
        ESLVal $3959 = _v1947.termRef(1);
        ESLVal $3958 = _v1947.termRef(2);
        
        {ESLVal e1 = $3960;
        
        {ESLVal e2 = $3959;
        
        {ESLVal e3 = $3958;
        
        return new ESLVal("JProbably",walkJExp(e1,methodNames),walkJExp(e2,methodNames),walkJExp(e3,methodNames));
      }
      }
      }
      }
    case "JRecord": {ESLVal $3957 = _v1947.termRef(0);
        
        {ESLVal fields = $3957;
        
        return new ESLVal("JRecord",new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal f = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJFieldDef(f,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(fields));
      }
      }
    case "JRef": {ESLVal $3956 = _v1947.termRef(0);
        ESLVal $3955 = _v1947.termRef(1);
        
        {ESLVal e = $3956;
        
        {ESLVal name = $3955;
        
        return new ESLVal("JRef",walkJExp(e,methodNames),name);
      }
      }
      }
    case "JRefSuper": {ESLVal $3954 = _v1947.termRef(0);
        
        {ESLVal name = $3954;
        
        return new ESLVal("JRefSuper",name);
      }
      }
    case "JSelf": {
        return new ESLVal("JSelf",new ESLVal[]{});
      }
    case "JSend": {ESLVal $3953 = _v1947.termRef(0);
        ESLVal $3952 = _v1947.termRef(1);
        ESLVal $3951 = _v1947.termRef(2);
        
        {ESLVal e = $3953;
        
        {ESLVal name = $3952;
        
        {ESLVal args = $3951;
        
        return new ESLVal("JSend",walkJExp(e,methodNames),name,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJExp(e,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(args));
      }
      }
      }
      }
    case "JSendSuper": {ESLVal $3950 = _v1947.termRef(0);
        
        {ESLVal e = $3950;
        
        return new ESLVal("JSendSuper",walkJExp(e,methodNames));
      }
      }
    case "JSendTimeSuper": {
        return new ESLVal("JSendTimeSuper",new ESLVal[]{});
      }
    case "JSet": {ESLVal $3949 = _v1947.termRef(0);
        ESLVal $3948 = _v1947.termRef(1);
        
        {ESLVal t = $3949;
        
        {ESLVal values = $3948;
        
        return new ESLVal("JSet",t,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJExp(e,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(values));
      }
      }
      }
    case "JTail": {ESLVal $3947 = _v1947.termRef(0);
        
        {ESLVal e = $3947;
        
        return new ESLVal("JTail",walkJExp(e,methodNames));
      }
      }
    case "JTerm": {ESLVal $3946 = _v1947.termRef(0);
        ESLVal $3945 = _v1947.termRef(1);
        
        {ESLVal name = $3946;
        
        {ESLVal values = $3945;
        
        return new ESLVal("JTerm",name,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJExp(e,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(values));
      }
      }
      }
    case "JTermRef": {ESLVal $3944 = _v1947.termRef(0);
        ESLVal $3943 = _v1947.termRef(1);
        
        {ESLVal e = $3944;
        
        {ESLVal i = $3943;
        
        return new ESLVal("JTermRef",walkJExp(e,methodNames),i);
      }
      }
      }
    case "JTry": {ESLVal $3942 = _v1947.termRef(0);
        ESLVal $3941 = _v1947.termRef(1);
        ESLVal $3940 = _v1947.termRef(2);
        
        {ESLVal e = $3942;
        
        {ESLVal n = $3941;
        
        {ESLVal c = $3940;
        
        return new ESLVal("JTry",walkJExp(e,methodNames),n,walkJCommand(c,methodNames));
      }
      }
      }
      }
    case "JVar": {ESLVal $3939 = _v1947.termRef(0);
        ESLVal $3938 = _v1947.termRef(1);
        
        {ESLVal name = $3939;
        
        {ESLVal t = $3938;
        
        return new ESLVal("JVar",name,t);
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(1913,5834)").add(ESLVal.list(_v1947)));
    }
    }
  }
  private static ESLVal walkJExp = new ESLVal(new Function(new ESLVal("walkJExp"),null) { public ESLVal apply(ESLVal... args) { return walkJExp(args[0],args[1]); }});
  private static ESLVal walkJFieldDef(ESLVal x,ESLVal methodNames) {
    
    {ESLVal _v1953 = x;
      
      switch(_v1953.termName) {
      case "JField": {ESLVal $4033 = _v1953.termRef(0);
        ESLVal $4032 = _v1953.termRef(1);
        ESLVal $4031 = _v1953.termRef(2);
        
        {ESLVal name = $4033;
        
        {ESLVal t = $4032;
        
        {ESLVal value = $4031;
        
        return new ESLVal("JField",name,t,walkJExp(value,methodNames));
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(5902,5986)").add(ESLVal.list(_v1953)));
    }
    }
  }
  private static ESLVal walkJFieldDef = new ESLVal(new Function(new ESLVal("walkJFieldDef"),null) { public ESLVal apply(ESLVal... args) { return walkJFieldDef(args[0],args[1]); }});
  private static ESLVal walkJCommand(ESLVal x,ESLVal methodNames) {
    
    {ESLVal _v1954 = x;
      
      switch(_v1954.termName) {
      case "JBlock": {ESLVal $4074 = _v1954.termRef(0);
        
        {ESLVal commands = $4074;
        
        return new ESLVal("JBlock",new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal c = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJCommand(c,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(commands));
      }
      }
    case "JCaseBool": {ESLVal $4073 = _v1954.termRef(0);
        ESLVal $4072 = _v1954.termRef(1);
        ESLVal $4071 = _v1954.termRef(2);
        
        {ESLVal e = $4073;
        
        {ESLVal boolArms = $4072;
        
        {ESLVal alt = $4071;
        
        return new ESLVal("JCaseBool",walkJExp(e,methodNames),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal a = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJBoolArm(a,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(boolArms),walkJCommand(alt,methodNames));
      }
      }
      }
      }
    case "JCaseInt": {ESLVal $4070 = _v1954.termRef(0);
        ESLVal $4069 = _v1954.termRef(1);
        ESLVal $4068 = _v1954.termRef(2);
        
        {ESLVal e = $4070;
        
        {ESLVal intArms = $4069;
        
        {ESLVal alt = $4068;
        
        return new ESLVal("JCaseInt",walkJExp(e,methodNames),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal a = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJIntArm(a,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(intArms),walkJCommand(alt,methodNames));
      }
      }
      }
      }
    case "JCaseList": {ESLVal $4067 = _v1954.termRef(0);
        ESLVal $4066 = _v1954.termRef(1);
        ESLVal $4065 = _v1954.termRef(2);
        ESLVal $4064 = _v1954.termRef(3);
        
        {ESLVal e = $4067;
        
        {ESLVal head = $4066;
        
        {ESLVal tail = $4065;
        
        {ESLVal alt = $4064;
        
        return new ESLVal("JCaseList",walkJExp(e,methodNames),walkJCommand(head,methodNames),walkJCommand(tail,methodNames),walkJCommand(alt,methodNames));
      }
      }
      }
      }
      }
    case "JCaseStr": {ESLVal $4063 = _v1954.termRef(0);
        ESLVal $4062 = _v1954.termRef(1);
        ESLVal $4061 = _v1954.termRef(2);
        
        {ESLVal e = $4063;
        
        {ESLVal strArms = $4062;
        
        {ESLVal alt = $4061;
        
        return new ESLVal("JCaseStr",walkJExp(e,methodNames),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal a = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJStrArm(a,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(strArms),walkJCommand(alt,methodNames));
      }
      }
      }
      }
    case "JCaseTerm": {ESLVal $4060 = _v1954.termRef(0);
        ESLVal $4059 = _v1954.termRef(1);
        ESLVal $4058 = _v1954.termRef(2);
        
        {ESLVal e = $4060;
        
        {ESLVal termArms = $4059;
        
        {ESLVal alt = $4058;
        
        return new ESLVal("JCaseTerm",walkJExp(e,methodNames),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal a = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJTermArm(a,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(termArms),walkJCommand(alt,methodNames));
      }
      }
      }
      }
    case "JFor": {ESLVal $4057 = _v1954.termRef(0);
        ESLVal $4056 = _v1954.termRef(1);
        ESLVal $4055 = _v1954.termRef(2);
        ESLVal $4054 = _v1954.termRef(3);
        
        {ESLVal n1 = $4057;
        
        {ESLVal n2 = $4056;
        
        {ESLVal e = $4055;
        
        {ESLVal c = $4054;
        
        return new ESLVal("JFor",n1,n2,walkJExp(e,methodNames),walkJCommand(c,methodNames));
      }
      }
      }
      }
      }
    case "JIfCommand": {ESLVal $4053 = _v1954.termRef(0);
        ESLVal $4052 = _v1954.termRef(1);
        ESLVal $4051 = _v1954.termRef(2);
        
        {ESLVal e = $4053;
        
        {ESLVal c1 = $4052;
        
        {ESLVal c2 = $4051;
        
        return new ESLVal("JIfCommand",walkJExp(e,methodNames),walkJCommand(c1,methodNames),walkJCommand(c2,methodNames));
      }
      }
      }
      }
    case "JLet": {ESLVal $4050 = _v1954.termRef(0);
        ESLVal $4049 = _v1954.termRef(1);
        
        {ESLVal fields = $4050;
        
        {ESLVal body = $4049;
        
        {ESLVal fieldNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1957 = $qualArg;
                
                switch(_v1957.termName) {
                case "JField": {ESLVal $4083 = _v1957.termRef(0);
                  ESLVal $4082 = _v1957.termRef(1);
                  ESLVal $4081 = _v1957.termRef(2);
                  
                  {ESLVal n = $4083;
                  
                  {ESLVal t = $4082;
                  
                  {ESLVal v = $4081;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1957;
                  
                  return $nil;
                }
              }
              }
            }
          }).map(fields).flatten().flatten();
        
        {ESLVal methodNames2 = removeAll.apply(fieldNames,methodNames);
        
        return new ESLVal("JLet",new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal f = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJFieldDef(f,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(fields),walkJCommand(body,methodNames2));
      }
      }
      }
      }
      }
    case "JLetRec": {ESLVal $4048 = _v1954.termRef(0);
        ESLVal $4047 = _v1954.termRef(1);
        
        {ESLVal fields = $4048;
        
        {ESLVal body = $4047;
        
        {ESLVal fieldNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1956 = $qualArg;
                
                switch(_v1956.termName) {
                case "JField": {ESLVal $4080 = _v1956.termRef(0);
                  ESLVal $4079 = _v1956.termRef(1);
                  ESLVal $4078 = _v1956.termRef(2);
                  
                  {ESLVal n = $4080;
                  
                  {ESLVal t = $4079;
                  
                  {ESLVal v = $4078;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1956;
                  
                  return $nil;
                }
              }
              }
            }
          }).map(fields).flatten().flatten();
        
        {ESLVal _v1964 = removeAll.apply(fieldNames,methodNames);
        
        return new ESLVal("JLetRec",new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal f = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJFieldDef(f,_v1964));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(fields),walkJCommand(body,_v1964));
      }
      }
      }
      }
      }
    case "JPLet": {ESLVal $4046 = _v1954.termRef(0);
        ESLVal $4045 = _v1954.termRef(1);
        
        {ESLVal fields = $4046;
        
        {ESLVal body = $4045;
        
        {ESLVal fieldNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1955 = $qualArg;
                
                switch(_v1955.termName) {
                case "JField": {ESLVal $4077 = _v1955.termRef(0);
                  ESLVal $4076 = _v1955.termRef(1);
                  ESLVal $4075 = _v1955.termRef(2);
                  
                  {ESLVal n = $4077;
                  
                  {ESLVal t = $4076;
                  
                  {ESLVal v = $4075;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1955;
                  
                  return $nil;
                }
              }
              }
            }
          }).map(fields).flatten().flatten();
        
        {ESLVal methodNames2 = removeAll.apply(fieldNames,methodNames);
        
        return new ESLVal("JPLet",new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal f = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJFieldDef(f,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(fields),walkJCommand(body,methodNames2));
      }
      }
      }
      }
      }
    case "JReturn": {ESLVal $4044 = _v1954.termRef(0);
        
        {ESLVal e = $4044;
        
        return new ESLVal("JReturn",walkJExp(e,methodNames));
      }
      }
    case "JStatement": {ESLVal $4043 = _v1954.termRef(0);
        
        {ESLVal e = $4043;
        
        return new ESLVal("JStatement",walkJExp(e,methodNames));
      }
      }
    case "JSwitch": {ESLVal $4042 = _v1954.termRef(0);
        ESLVal $4041 = _v1954.termRef(1);
        ESLVal $4040 = _v1954.termRef(2);
        
        {ESLVal e = $4042;
        
        {ESLVal cases = $4041;
        
        {ESLVal command = $4040;
        
        return new ESLVal("JSwitch",walkJExp(e,methodNames),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal c = $l0.head();
              $l0 = $l0.tail();
              $v.add(walkJCase(c,methodNames));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(cases),walkJCommand(command,methodNames));
      }
      }
      }
      }
    case "JSwitchList": {ESLVal $4039 = _v1954.termRef(0);
        ESLVal $4038 = _v1954.termRef(1);
        ESLVal $4037 = _v1954.termRef(2);
        ESLVal $4036 = _v1954.termRef(3);
        
        {ESLVal e = $4039;
        
        {ESLVal c1 = $4038;
        
        {ESLVal c2 = $4037;
        
        {ESLVal c3 = $4036;
        
        return new ESLVal("JSwitchList",walkJExp(e,methodNames),walkJCommand(c1,methodNames),walkJCommand(c2,methodNames),walkJCommand(c3,methodNames));
      }
      }
      }
      }
      }
    case "JUpdate": {ESLVal $4035 = _v1954.termRef(0);
        ESLVal $4034 = _v1954.termRef(1);
        
        {ESLVal n = $4035;
        
        {ESLVal e = $4034;
        
        return new ESLVal("JUpdate",n,walkJExp(e,methodNames));
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(6051,8341)").add(ESLVal.list(_v1954)));
    }
    }
  }
  private static ESLVal walkJCommand = new ESLVal(new Function(new ESLVal("walkJCommand"),null) { public ESLVal apply(ESLVal... args) { return walkJCommand(args[0],args[1]); }});
  private static ESLVal walkJBoolArm(ESLVal x,ESLVal methodNames) {
    
    {ESLVal _v1958 = x;
      
      switch(_v1958.termName) {
      case "JBArm": {ESLVal $4085 = _v1958.termRef(0);
        ESLVal $4084 = _v1958.termRef(1);
        
        {ESLVal b = $4085;
        
        {ESLVal command = $4084;
        
        return new ESLVal("JBArm",b,walkJCommand(command,methodNames));
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(8406,8486)").add(ESLVal.list(_v1958)));
    }
    }
  }
  private static ESLVal walkJBoolArm = new ESLVal(new Function(new ESLVal("walkJBoolArm"),null) { public ESLVal apply(ESLVal... args) { return walkJBoolArm(args[0],args[1]); }});
  private static ESLVal walkJIntArm(ESLVal x,ESLVal methodNames) {
    
    {ESLVal _v1959 = x;
      
      switch(_v1959.termName) {
      case "JIArm": {ESLVal $4087 = _v1959.termRef(0);
        ESLVal $4086 = _v1959.termRef(1);
        
        {ESLVal i = $4087;
        
        {ESLVal command = $4086;
        
        return new ESLVal("JIArm",i,walkJCommand(command,methodNames));
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(8548,8628)").add(ESLVal.list(_v1959)));
    }
    }
  }
  private static ESLVal walkJIntArm = new ESLVal(new Function(new ESLVal("walkJIntArm"),null) { public ESLVal apply(ESLVal... args) { return walkJIntArm(args[0],args[1]); }});
  private static ESLVal walkJStrArm(ESLVal x,ESLVal methodNames) {
    
    {ESLVal _v1960 = x;
      
      switch(_v1960.termName) {
      case "JSArm": {ESLVal $4089 = _v1960.termRef(0);
        ESLVal $4088 = _v1960.termRef(1);
        
        {ESLVal s = $4089;
        
        {ESLVal command = $4088;
        
        return new ESLVal("JSArm",s,walkJCommand(command,methodNames));
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(8690,8770)").add(ESLVal.list(_v1960)));
    }
    }
  }
  private static ESLVal walkJStrArm = new ESLVal(new Function(new ESLVal("walkJStrArm"),null) { public ESLVal apply(ESLVal... args) { return walkJStrArm(args[0],args[1]); }});
  private static ESLVal walkJTermArm(ESLVal x,ESLVal methodNames) {
    
    {ESLVal _v1961 = x;
      
      switch(_v1961.termName) {
      case "JTArm": {ESLVal $4092 = _v1961.termRef(0);
        ESLVal $4091 = _v1961.termRef(1);
        ESLVal $4090 = _v1961.termRef(2);
        
        {ESLVal name = $4092;
        
        {ESLVal index = $4091;
        
        {ESLVal command = $4090;
        
        return new ESLVal("JTArm",name,index,walkJCommand(command,methodNames));
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(8835,8933)").add(ESLVal.list(_v1961)));
    }
    }
  }
  private static ESLVal walkJTermArm = new ESLVal(new Function(new ESLVal("walkJTermArm"),null) { public ESLVal apply(ESLVal... args) { return walkJTermArm(args[0],args[1]); }});
  private static ESLVal walkJCase(ESLVal x,ESLVal methodNames) {
    
    {ESLVal _v1962 = x;
      
      switch(_v1962.termName) {
      case "JCaseOf": {ESLVal $4094 = _v1962.termRef(0);
        ESLVal $4093 = _v1962.termRef(1);
        
        {ESLVal k = $4094;
        
        {ESLVal command = $4093;
        
        return new ESLVal("JCaseOf",k,walkJCommand(command,methodNames));
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(8989,9073)").add(ESLVal.list(_v1962)));
    }
    }
  }
  private static ESLVal walkJCase = new ESLVal(new Function(new ESLVal("walkJCase"),null) { public ESLVal apply(ESLVal... args) { return walkJCase(args[0],args[1]); }});
  private static ESLVal walkJCmp(ESLVal x,ESLVal methodNames) {
    
    {ESLVal _v1963 = x;
      
      switch(_v1963.termName) {
      case "JCmpList": {ESLVal $4103 = _v1963.termRef(0);
        
        {ESLVal e = $4103;
        
        return new ESLVal("JCmpList",walkJExp(e,methodNames));
      }
      }
    case "JCmpOuter": {ESLVal $4102 = _v1963.termRef(0);
        ESLVal $4101 = _v1963.termRef(1);
        ESLVal $4100 = _v1963.termRef(2);
        
        {ESLVal n = $4102;
        
        {ESLVal e = $4101;
        
        {ESLVal c = $4100;
        
        return new ESLVal("JCmpOuter",n,walkJExp(e,remove.apply(n,methodNames)),walkJCmp(c,remove.apply(n,methodNames)));
      }
      }
      }
      }
    case "JCmpIf": {ESLVal $4099 = _v1963.termRef(0);
        ESLVal $4098 = _v1963.termRef(1);
        
        {ESLVal e = $4099;
        
        {ESLVal c = $4098;
        
        return new ESLVal("JCmpIf",walkJExp(e,methodNames),walkJCmp(c,methodNames));
      }
      }
      }
    case "JCmpBind": {ESLVal $4097 = _v1963.termRef(0);
        ESLVal $4096 = _v1963.termRef(1);
        ESLVal $4095 = _v1963.termRef(2);
        
        {ESLVal n = $4097;
        
        {ESLVal e = $4096;
        
        {ESLVal c = $4095;
        
        return new ESLVal("JCmpBind",n,walkJExp(e,remove.apply(n,methodNames)),walkJCmp(c,remove.apply(n,methodNames)));
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(9126,9498)").add(ESLVal.list(_v1963)));
    }
    }
  }
  private static ESLVal walkJCmp = new ESLVal(new Function(new ESLVal("walkJCmp"),null) { public ESLVal apply(ESLVal... args) { return walkJCmp(args[0],args[1]); }});
public static void main(String[] args) {
  }
}