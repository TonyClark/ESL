package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
// import static esl.Lists.*;
import static esl.compiler.Types.*;
import static esl.compiler.PpExp.*;
import java.util.function.Supplier;
public class Cases {
  public static ESLVal getSelf() { return $null; }
  private static ESLVal loc0 = new ESLVal("Pos",$zero,$zero);
  private static ESLVal voidType = new ESLVal("VoidType",loc0);
  private static ESLVal varCounter = $zero;
  private static ESLVal case0 = new ESLVal("Case",new ESLVal("Pos",$zero,$zero),$nil,ESLVal.list(new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("x")),new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("y"))),ESLVal.list(new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PVar",loc0,new ESLVal("xx"),voidType),new ESLVal("PVar",loc0,new ESLVal("yy"),voidType)),new ESLVal("BoolExp",loc0,$true),new ESLVal("Var",loc0,new ESLVal("OK")))));
  private static ESLVal case1 = new ESLVal("Case",new ESLVal("Pos",$zero,$zero),$nil,ESLVal.list(new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("x")),new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("y"))),ESLVal.list(new ESLVal("BArm",loc0,ESLVal.list(pterm(new ESLVal("A"),ESLVal.list(pterm(new ESLVal("B"),ESLVal.list(pvar(new ESLVal("v0")))),pvar(new ESLVal("v1")),pvar(new ESLVal("v2")))),pterm(new ESLVal("C"),$nil)),new ESLVal("BoolExp",loc0,$true),new ESLVal("Var",loc0,new ESLVal("OK1"))),new ESLVal("BArm",loc0,ESLVal.list(pvar(new ESLVal("v0")),pterm(new ESLVal("C"),$nil)),new ESLVal("BoolExp",loc0,$true),new ESLVal("Var",loc0,new ESLVal("OK2")))));
  private static ESLVal case2 = new ESLVal("Case",loc0,$nil,ESLVal.list(var(new ESLVal("l"))),ESLVal.list(new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PNil",loc0)),var(new ESLVal("g1")),var(new ESLVal("M1"))),new ESLVal("BArm",loc0,ESLVal.list(pcons(pterm(new ESLVal("One"),$nil),pvar(new ESLVal("rest1")))),var(new ESLVal("g1")),var(new ESLVal("M1"))),new ESLVal("BArm",loc0,ESLVal.list(pcons(pterm(new ESLVal("Succ"),ESLVal.list(pterm(new ESLVal("One"),$nil))),pvar(new ESLVal("rest2")))),var(new ESLVal("g2")),var(new ESLVal("M2"))),new ESLVal("BArm",loc0,ESLVal.list(pcons(pterm(new ESLVal("Infinity"),$nil),new ESLVal("PNil",loc0))),var(new ESLVal("g3")),var(new ESLVal("M3")))));
  private static ESLVal case3 = new ESLVal("Case",loc0,$nil,ESLVal.list(var(new ESLVal("x")),var(new ESLVal("y"))),ESLVal.list(new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PInt",loc0,$zero),new ESLVal("PInt",loc0,$one)),var(new ESLVal("g1")),var(new ESLVal("M1"))),new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PInt",loc0,$one),new ESLVal("PInt",loc0,$zero)),var(new ESLVal("g2")),var(new ESLVal("M2"))),new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PInt",loc0,$zero),pvar(new ESLVal("x"))),var(new ESLVal("g3")),var(new ESLVal("M3"))),new ESLVal("BArm",loc0,ESLVal.list(pvar(new ESLVal("x")),new ESLVal("PInt",loc0,$one)),var(new ESLVal("g4")),var(new ESLVal("M4")))));
  private static ESLVal case4 = new ESLVal("Case",loc0,$nil,ESLVal.list(var(new ESLVal("x")),var(new ESLVal("y"))),ESLVal.list(new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PStr",loc0,new ESLVal("one")),new ESLVal("PInt",loc0,$one)),var(new ESLVal("g1")),var(new ESLVal("M1"))),new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PStr",loc0,new ESLVal("one")),new ESLVal("PInt",loc0,$zero)),var(new ESLVal("g2")),var(new ESLVal("M2"))),new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PStr",loc0,new ESLVal("two")),pvar(new ESLVal("x"))),var(new ESLVal("g3")),var(new ESLVal("M3"))),new ESLVal("BArm",loc0,ESLVal.list(pvar(new ESLVal("x")),new ESLVal("PInt",loc0,$one)),var(new ESLVal("g4")),var(new ESLVal("M4")))));
  private static ESLVal case5 = new ESLVal("Case",loc0,$nil,ESLVal.list(var(new ESLVal("x")),var(new ESLVal("y"))),ESLVal.list(new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PStr",loc0,new ESLVal("one")),new ESLVal("PInt",loc0,$one)),var(new ESLVal("g1")),var(new ESLVal("M1"))),new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PStr",loc0,new ESLVal("one")),new ESLVal("PInt",loc0,$zero)),var(new ESLVal("g2")),var(new ESLVal("M2"))),new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PStr",loc0,new ESLVal("two")),pvar(new ESLVal("x"))),var(new ESLVal("g3")),var(new ESLVal("M3"))),new ESLVal("BArm",loc0,ESLVal.list(pvar(new ESLVal("x")),new ESLVal("PInt",loc0,$one)),var(new ESLVal("g4")),var(new ESLVal("M4"))),new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PBool",loc0,$true),new ESLVal("PInt",loc0,$one)),var(new ESLVal("g4")),var(new ESLVal("M4")))));
  private static ESLVal case6 = new ESLVal("Case",loc0,$nil,ESLVal.list(var(new ESLVal("x"))),ESLVal.list(new ESLVal("BArm",loc0,ESLVal.list(pterm(new ESLVal("A"),ESLVal.list(new ESLVal("PInt",loc0,$one)))),var(new ESLVal("g1")),var(new ESLVal("M1")))));
  public static ESLVal main = new ESLVal(new Function(new ESLVal("main"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      return new ESLVal(new BehaviourAdapter(true,getSelf(),new ESLVal("main")) {
          

          public ESLVal handle(ESLVal $m) {{ESLVal _v1918 = $m;
            
            return error(new ESLVal("case error at Pos(0,0)").add(ESLVal.list(_v1918)));
          }}
          public ESLVal get(String name) {
            switch(name) {
              
              default: throw new Error("ref illegal " + self + "." + name);
            }
          }
        public void handleTime(ESLVal $t) {
          {ESLVal n = $t;
            
            if($true.boolVal)
            {new Function(new ESLVal("try"),getSelf()) {
              public ESLVal apply(ESLVal... args) { 
                try { 
                  return ((Supplier<ESLVal>)() -> { 
                  {print.apply(ppExp.apply($zero,translateCases(case0)));
                  print.apply(ppExp.apply($zero,translateCases(case1)));
                  print.apply(ppExp.apply($zero,translateCases(case2)));
                  print.apply(ppExp.apply($zero,translateCases(case3)));
                  print.apply(ppExp.apply($zero,translateCases(case4)));
                  print.apply(ppExp.apply($zero,translateCases(case5)));
                  return print.apply(ppExp.apply($zero,translateCases(case6)));}
                }).get();
                } catch(ESLError $exception) {
                  ESLVal $x = $exception.value;
                  {ESLVal _v1917 = $x;
              
              {ESLVal x = _v1917;
              
              return print.apply(x);
            }
            }
                }
              }
            }.apply();
            stopAll.apply();}
            else
              {}
          }
        }
        public ESLVal init() {
            return $null;
          }
        });
    }
  });
private static ESLVal newVar() {
    
    {varCounter = varCounter.add($one);
    return new ESLVal("$").add(varCounter);}
  }
  private static ESLVal newVar = new ESLVal(new Function(new ESLVal("newVar"),null) { public ESLVal apply(ESLVal... args) { return newVar(); }});
  private static ESLVal translateArms(ESLVal as) {
    
    {ESLVal _v1875 = as;
      
      if(_v1875.isCons())
      {ESLVal $3608 = _v1875.head();
        ESLVal $3609 = _v1875.tail();
        
        switch($3608.termName) {
        case "BArm": {ESLVal $3613 = $3608.termRef(0);
          ESLVal $3612 = $3608.termRef(1);
          ESLVal $3611 = $3608.termRef(2);
          ESLVal $3610 = $3608.termRef(3);
          
          {ESLVal l = $3613;
          
          {ESLVal ps = $3612;
          
          {ESLVal g = $3611;
          
          {ESLVal e = $3610;
          
          {ESLVal _v1941 = $3609;
          
          return translateArms(_v1941).cons(new ESLVal("LArm",l,ps,$nil,g,e));
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(1889,2030)").add(ESLVal.list(_v1875)));
      }
      }
    else if(_v1875.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(1889,2030)").add(ESLVal.list(_v1875)));
    }
  }
  private static ESLVal translateArms = new ESLVal(new Function(new ESLVal("translateArms"),null) { public ESLVal apply(ESLVal... args) { return translateArms(args[0]); }});
  private static ESLVal newVars(ESLVal n) {
    
    if(n.eql($zero).boolVal)
      return $nil;
      else
        return newVars(n.sub($one)).cons(newVar());
  }
  private static ESLVal newVars = new ESLVal(new Function(new ESLVal("newVars"),null) { public ESLVal apply(ESLVal... args) { return newVars(args[0]); }});
  public static ESLVal translateCases(ESLVal exp) {
    
    {ESLVal _v1876 = exp;
      
      switch(_v1876.termName) {
      case "Module": {ESLVal $3735 = _v1876.termRef(0);
        ESLVal $3734 = _v1876.termRef(1);
        ESLVal $3733 = _v1876.termRef(2);
        ESLVal $3732 = _v1876.termRef(3);
        ESLVal $3731 = _v1876.termRef(4);
        ESLVal $3730 = _v1876.termRef(5);
        ESLVal $3729 = _v1876.termRef(6);
        
        {ESLVal path = $3735;
        
        {ESLVal name = $3734;
        
        {ESLVal exports = $3733;
        
        {ESLVal imports = $3732;
        
        {ESLVal x = $3731;
        
        {ESLVal y = $3730;
        
        {ESLVal defs = $3729;
        
        return new ESLVal("Module",path,name,exports,imports,x,y,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal d = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateDef(d));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(mergeFunDefs.apply(defs)));
      }
      }
      }
      }
      }
      }
      }
      }
    case "FunExp": {ESLVal $3728 = _v1876.termRef(0);
        ESLVal $3727 = _v1876.termRef(1);
        ESLVal $3726 = _v1876.termRef(2);
        ESLVal $3725 = _v1876.termRef(3);
        ESLVal $3724 = _v1876.termRef(4);
        
        {ESLVal l = $3728;
        
        {ESLVal n = $3727;
        
        {ESLVal args = $3726;
        
        {ESLVal t = $3725;
        
        {ESLVal e = $3724;
        
        return new ESLVal("FunExp",l,n,args,t,translateCases(e));
      }
      }
      }
      }
      }
      }
    case "StrExp": {ESLVal $3723 = _v1876.termRef(0);
        ESLVal $3722 = _v1876.termRef(1);
        
        {ESLVal l = $3723;
        
        {ESLVal v = $3722;
        
        return exp;
      }
      }
      }
    case "IntExp": {ESLVal $3721 = _v1876.termRef(0);
        ESLVal $3720 = _v1876.termRef(1);
        
        {ESLVal l = $3721;
        
        {ESLVal v = $3720;
        
        return exp;
      }
      }
      }
    case "BoolExp": {ESLVal $3719 = _v1876.termRef(0);
        ESLVal $3718 = _v1876.termRef(1);
        
        {ESLVal l = $3719;
        
        {ESLVal v = $3718;
        
        return exp;
      }
      }
      }
    case "BagExp": {ESLVal $3717 = _v1876.termRef(0);
        ESLVal $3716 = _v1876.termRef(1);
        
        {ESLVal l = $3717;
        
        {ESLVal es = $3716;
        
        return new ESLVal("BagExp",l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateCases(e));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(es));
      }
      }
      }
    case "NullExp": {ESLVal $3715 = _v1876.termRef(0);
        
        {ESLVal l = $3715;
        
        return exp;
      }
      }
    case "FloatExp": {ESLVal $3714 = _v1876.termRef(0);
        ESLVal $3713 = _v1876.termRef(1);
        
        {ESLVal l = $3714;
        
        {ESLVal f = $3713;
        
        return exp;
      }
      }
      }
    case "Term": {ESLVal $3712 = _v1876.termRef(0);
        ESLVal $3711 = _v1876.termRef(1);
        ESLVal $3710 = _v1876.termRef(2);
        ESLVal $3709 = _v1876.termRef(3);
        
        {ESLVal l = $3712;
        
        {ESLVal n = $3711;
        
        {ESLVal ts = $3710;
        
        {ESLVal es = $3709;
        
        return new ESLVal("Term",l,n,ts,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateCases(e));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(es));
      }
      }
      }
      }
      }
    case "List": {ESLVal $3708 = _v1876.termRef(0);
        ESLVal $3707 = _v1876.termRef(1);
        
        {ESLVal l = $3708;
        
        {ESLVal es = $3707;
        
        return new ESLVal("List",l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateCases(e));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(es));
      }
      }
      }
    case "Block": {ESLVal $3706 = _v1876.termRef(0);
        ESLVal $3705 = _v1876.termRef(1);
        
        {ESLVal l = $3706;
        
        {ESLVal es = $3705;
        
        return new ESLVal("Block",l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateCases(e));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(es));
      }
      }
      }
    case "Apply": {ESLVal $3704 = _v1876.termRef(0);
        ESLVal $3703 = _v1876.termRef(1);
        ESLVal $3702 = _v1876.termRef(2);
        
        {ESLVal l = $3704;
        
        {ESLVal op = $3703;
        
        {ESLVal args = $3702;
        
        return new ESLVal("Apply",l,translateCases(op),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateCases(e));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(args));
      }
      }
      }
      }
    case "ApplyTypeExp": {ESLVal $3701 = _v1876.termRef(0);
        ESLVal $3700 = _v1876.termRef(1);
        ESLVal $3699 = _v1876.termRef(2);
        
        {ESLVal l = $3701;
        
        {ESLVal op = $3700;
        
        {ESLVal args = $3699;
        
        return new ESLVal("ApplyTypeExp",l,translateCases(op),args);
      }
      }
      }
      }
    case "Case": {ESLVal $3698 = _v1876.termRef(0);
        ESLVal $3697 = _v1876.termRef(1);
        ESLVal $3696 = _v1876.termRef(2);
        ESLVal $3695 = _v1876.termRef(3);
        
        {ESLVal l = $3698;
        
        {ESLVal ds = $3697;
        
        {ESLVal es = $3696;
        
        {ESLVal as = $3695;
        
        return compileCase(l,es,translateArms(as),new ESLVal("CaseError",l,new ESLVal("List",l,es)));
      }
      }
      }
      }
      }
    case "BinExp": {ESLVal $3694 = _v1876.termRef(0);
        ESLVal $3693 = _v1876.termRef(1);
        ESLVal $3692 = _v1876.termRef(2);
        ESLVal $3691 = _v1876.termRef(3);
        
        {ESLVal l = $3694;
        
        {ESLVal e1 = $3693;
        
        {ESLVal op = $3692;
        
        {ESLVal e2 = $3691;
        
        return new ESLVal("BinExp",l,translateCases(e1),op,translateCases(e2));
      }
      }
      }
      }
      }
    case "For": {ESLVal $3690 = _v1876.termRef(0);
        ESLVal $3689 = _v1876.termRef(1);
        ESLVal $3688 = _v1876.termRef(2);
        ESLVal $3687 = _v1876.termRef(3);
        
        {ESLVal l = $3690;
        
        {ESLVal p = $3689;
        
        {ESLVal e1 = $3688;
        
        {ESLVal e2 = $3687;
        
        return new ESLVal("For",l,p,translateCases(e1),translateCases(e2));
      }
      }
      }
      }
      }
    case "Throw": {ESLVal $3686 = _v1876.termRef(0);
        ESLVal $3685 = _v1876.termRef(1);
        ESLVal $3684 = _v1876.termRef(2);
        
        {ESLVal l = $3686;
        
        {ESLVal t = $3685;
        
        {ESLVal e = $3684;
        
        return new ESLVal("Throw",l,t,translateCases(e));
      }
      }
      }
      }
    case "Try": {ESLVal $3683 = _v1876.termRef(0);
        ESLVal $3682 = _v1876.termRef(1);
        ESLVal $3681 = _v1876.termRef(2);
        
        {ESLVal l = $3683;
        
        {ESLVal e = $3682;
        
        {ESLVal as = $3681;
        
        return new ESLVal("Try",l,translateCases(e),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal a = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateArm(a));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(as));
      }
      }
      }
      }
    case "ActExp": {ESLVal $3680 = _v1876.termRef(0);
        ESLVal $3679 = _v1876.termRef(1);
        ESLVal $3678 = _v1876.termRef(2);
        ESLVal $3677 = _v1876.termRef(3);
        ESLVal $3676 = _v1876.termRef(4);
        ESLVal $3675 = _v1876.termRef(5);
        ESLVal $3674 = _v1876.termRef(6);
        ESLVal $3673 = _v1876.termRef(7);
        
        {ESLVal l = $3680;
        
        {ESLVal n = $3679;
        
        {ESLVal args = $3678;
        
        {ESLVal x = $3677;
        
        {ESLVal spec = $3676;
        
        {ESLVal locals = $3675;
        
        {ESLVal init = $3674;
        
        {ESLVal handlers = $3673;
        
        return new ESLVal("ActExp",l,n,args,x,spec,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateDef(b));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(locals),translateCases(init),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal h = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateArm(h));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(handlers));
      }
      }
      }
      }
      }
      }
      }
      }
      }
    case "If": {ESLVal $3672 = _v1876.termRef(0);
        ESLVal $3671 = _v1876.termRef(1);
        ESLVal $3670 = _v1876.termRef(2);
        ESLVal $3669 = _v1876.termRef(3);
        
        {ESLVal l = $3672;
        
        {ESLVal e1 = $3671;
        
        {ESLVal e2 = $3670;
        
        {ESLVal e3 = $3669;
        
        return new ESLVal("If",l,translateCases(e1),translateCases(e2),translateCases(e3));
      }
      }
      }
      }
      }
    case "Self": {ESLVal $3668 = _v1876.termRef(0);
        
        {ESLVal l = $3668;
        
        return exp;
      }
      }
    case "Update": {ESLVal $3667 = _v1876.termRef(0);
        ESLVal $3666 = _v1876.termRef(1);
        ESLVal $3665 = _v1876.termRef(2);
        
        {ESLVal l = $3667;
        
        {ESLVal n = $3666;
        
        {ESLVal e = $3665;
        
        return new ESLVal("Update",l,n,translateCases(e));
      }
      }
      }
      }
    case "Ref": {ESLVal $3664 = _v1876.termRef(0);
        ESLVal $3663 = _v1876.termRef(1);
        ESLVal $3662 = _v1876.termRef(2);
        
        {ESLVal l = $3664;
        
        {ESLVal e = $3663;
        
        {ESLVal n = $3662;
        
        return new ESLVal("Ref",l,translateCases(e),n);
      }
      }
      }
      }
    case "Var": {ESLVal $3661 = _v1876.termRef(0);
        ESLVal $3660 = _v1876.termRef(1);
        
        {ESLVal l = $3661;
        
        {ESLVal n = $3660;
        
        return exp;
      }
      }
      }
    case "Send": {ESLVal $3659 = _v1876.termRef(0);
        ESLVal $3658 = _v1876.termRef(1);
        ESLVal $3657 = _v1876.termRef(2);
        
        {ESLVal l = $3659;
        
        {ESLVal target = $3658;
        
        {ESLVal message = $3657;
        
        return new ESLVal("Send",l,translateCases(target),translateCases(message));
      }
      }
      }
      }
    case "SendTimeSuper": {ESLVal $3656 = _v1876.termRef(0);
        
        {ESLVal l = $3656;
        
        return new ESLVal("SendTimeSuper",l);
      }
      }
    case "SendSuper": {ESLVal $3655 = _v1876.termRef(0);
        ESLVal $3654 = _v1876.termRef(1);
        
        {ESLVal l = $3655;
        
        {ESLVal e = $3654;
        
        return new ESLVal("SendSuper",l,translateCases(e));
      }
      }
      }
    case "SetExp": {ESLVal $3653 = _v1876.termRef(0);
        ESLVal $3652 = _v1876.termRef(1);
        
        {ESLVal l = $3653;
        
        {ESLVal es = $3652;
        
        return new ESLVal("SetExp",l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateCases(e));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(es));
      }
      }
      }
    case "Cmp": {ESLVal $3651 = _v1876.termRef(0);
        ESLVal $3650 = _v1876.termRef(1);
        ESLVal $3649 = _v1876.termRef(2);
        
        {ESLVal l = $3651;
        
        {ESLVal e = $3650;
        
        {ESLVal qs = $3649;
        
        return new ESLVal("Cmp",l,translateCases(e),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal q = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateQual(q));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(qs));
      }
      }
      }
      }
    case "New": {ESLVal $3648 = _v1876.termRef(0);
        ESLVal $3647 = _v1876.termRef(1);
        ESLVal $3646 = _v1876.termRef(2);
        
        {ESLVal l = $3648;
        
        {ESLVal b = $3647;
        
        {ESLVal args = $3646;
        
        return new ESLVal("New",l,translateCases(b),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateCases(e));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(args));
      }
      }
      }
      }
    case "NewJava": {ESLVal $3645 = _v1876.termRef(0);
        ESLVal $3644 = _v1876.termRef(1);
        ESLVal $3643 = _v1876.termRef(2);
        ESLVal $3642 = _v1876.termRef(3);
        
        {ESLVal l = $3645;
        
        {ESLVal className = $3644;
        
        {ESLVal t = $3643;
        
        {ESLVal args = $3642;
        
        return new ESLVal("NewJava",l,className,t,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateCases(e));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(args));
      }
      }
      }
      }
      }
    case "Let": {ESLVal $3641 = _v1876.termRef(0);
        ESLVal $3640 = _v1876.termRef(1);
        ESLVal $3639 = _v1876.termRef(2);
        
        {ESLVal l = $3641;
        
        {ESLVal bs = $3640;
        
        {ESLVal e = $3639;
        
        return new ESLVal("Let",l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateDef(b));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(bs),translateCases(e));
      }
      }
      }
      }
    case "Letrec": {ESLVal $3638 = _v1876.termRef(0);
        ESLVal $3637 = _v1876.termRef(1);
        ESLVal $3636 = _v1876.termRef(2);
        
        {ESLVal l = $3638;
        
        {ESLVal bs = $3637;
        
        {ESLVal e = $3636;
        
        return new ESLVal("Letrec",l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateDef(b));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(bs),translateCases(e));
      }
      }
      }
      }
    case "Grab": {ESLVal $3635 = _v1876.termRef(0);
        ESLVal $3634 = _v1876.termRef(1);
        ESLVal $3633 = _v1876.termRef(2);
        
        {ESLVal l = $3635;
        
        {ESLVal rs = $3634;
        
        {ESLVal e = $3633;
        
        return new ESLVal("Grab",l,rs,translateCases(e));
      }
      }
      }
      }
    case "PLet": {ESLVal $3632 = _v1876.termRef(0);
        ESLVal $3631 = _v1876.termRef(1);
        ESLVal $3630 = _v1876.termRef(2);
        
        {ESLVal l = $3632;
        
        {ESLVal bs = $3631;
        
        {ESLVal e = $3630;
        
        return new ESLVal("PLet",l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              $v.add(translateDef(b));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(bs),translateCases(e));
      }
      }
      }
      }
    case "Probably": {ESLVal $3629 = _v1876.termRef(0);
        ESLVal $3628 = _v1876.termRef(1);
        ESLVal $3627 = _v1876.termRef(2);
        ESLVal $3626 = _v1876.termRef(3);
        ESLVal $3625 = _v1876.termRef(4);
        
        {ESLVal l = $3629;
        
        {ESLVal p = $3628;
        
        {ESLVal t = $3627;
        
        {ESLVal e1 = $3626;
        
        {ESLVal e2 = $3625;
        
        return new ESLVal("Probably",l,translateCases(p),t,translateCases(e1),translateCases(e2));
      }
      }
      }
      }
      }
      }
    case "Not": {ESLVal $3624 = _v1876.termRef(0);
        ESLVal $3623 = _v1876.termRef(1);
        
        {ESLVal l = $3624;
        
        {ESLVal e = $3623;
        
        return new ESLVal("Not",l,translateCases(e));
      }
      }
      }
    case "Fold": {ESLVal $3622 = _v1876.termRef(0);
        ESLVal $3621 = _v1876.termRef(1);
        ESLVal $3620 = _v1876.termRef(2);
        
        {ESLVal l = $3622;
        
        {ESLVal t = $3621;
        
        {ESLVal e = $3620;
        
        return new ESLVal("Fold",l,t,translateCases(e));
      }
      }
      }
      }
    case "Unfold": {ESLVal $3619 = _v1876.termRef(0);
        ESLVal $3618 = _v1876.termRef(1);
        ESLVal $3617 = _v1876.termRef(2);
        
        {ESLVal l = $3619;
        
        {ESLVal t = $3618;
        
        {ESLVal e = $3617;
        
        return new ESLVal("Unfold",l,t,translateCases(e));
      }
      }
      }
      }
    case "Now": {ESLVal $3616 = _v1876.termRef(0);
        
        {ESLVal l = $3616;
        
        return exp;
      }
      }
    case "Become": {ESLVal $3615 = _v1876.termRef(0);
        ESLVal $3614 = _v1876.termRef(1);
        
        {ESLVal l = $3615;
        
        {ESLVal e = $3614;
        
        return new ESLVal("Become",l,translateCases(e));
      }
      }
      }
      default: {ESLVal x = _v1876;
        
        return error(exp);
      }
    }
    }
  }
  public static ESLVal translateCases = new ESLVal(new Function(new ESLVal("translateCases"),null) { public ESLVal apply(ESLVal... args) { return translateCases(args[0]); }});
  private static ESLVal armPatterns(ESLVal arm) {
    
    {ESLVal _v1877 = arm;
      
      switch(_v1877.termName) {
      case "LArm": {ESLVal $3740 = _v1877.termRef(0);
        ESLVal $3739 = _v1877.termRef(1);
        ESLVal $3738 = _v1877.termRef(2);
        ESLVal $3737 = _v1877.termRef(3);
        ESLVal $3736 = _v1877.termRef(4);
        
        {ESLVal l = $3740;
        
        {ESLVal ps = $3739;
        
        {ESLVal bs = $3738;
        
        {ESLVal g = $3737;
        
        {ESLVal e = $3736;
        
        return ps;
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(8442,8522)").add(ESLVal.list(_v1877)));
    }
    }
  }
  private static ESLVal armPatterns = new ESLVal(new Function(new ESLVal("armPatterns"),null) { public ESLVal apply(ESLVal... args) { return armPatterns(args[0]); }});
  private static ESLVal armBody(ESLVal arm) {
    
    {ESLVal _v1878 = arm;
      
      switch(_v1878.termName) {
      case "LArm": {ESLVal $3745 = _v1878.termRef(0);
        ESLVal $3744 = _v1878.termRef(1);
        ESLVal $3743 = _v1878.termRef(2);
        ESLVal $3742 = _v1878.termRef(3);
        ESLVal $3741 = _v1878.termRef(4);
        
        {ESLVal l = $3745;
        
        {ESLVal ps = $3744;
        
        {ESLVal bs = $3743;
        
        {ESLVal g = $3742;
        
        {ESLVal e = $3741;
        
        return e;
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(8551,8630)").add(ESLVal.list(_v1878)));
    }
    }
  }
  private static ESLVal armBody = new ESLVal(new Function(new ESLVal("armBody"),null) { public ESLVal apply(ESLVal... args) { return armBody(args[0]); }});
  private static ESLVal armGuard(ESLVal arm) {
    
    {ESLVal _v1879 = arm;
      
      switch(_v1879.termName) {
      case "LArm": {ESLVal $3750 = _v1879.termRef(0);
        ESLVal $3749 = _v1879.termRef(1);
        ESLVal $3748 = _v1879.termRef(2);
        ESLVal $3747 = _v1879.termRef(3);
        ESLVal $3746 = _v1879.termRef(4);
        
        {ESLVal l = $3750;
        
        {ESLVal ps = $3749;
        
        {ESLVal bs = $3748;
        
        {ESLVal g = $3747;
        
        {ESLVal e = $3746;
        
        return g;
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(8660,8739)").add(ESLVal.list(_v1879)));
    }
    }
  }
  private static ESLVal armGuard = new ESLVal(new Function(new ESLVal("armGuard"),null) { public ESLVal apply(ESLVal... args) { return armGuard(args[0]); }});
  private static ESLVal setArmBody(ESLVal arm,ESLVal e) {
    
    {ESLVal _v1880 = arm;
      
      switch(_v1880.termName) {
      case "LArm": {ESLVal $3755 = _v1880.termRef(0);
        ESLVal $3754 = _v1880.termRef(1);
        ESLVal $3753 = _v1880.termRef(2);
        ESLVal $3752 = _v1880.termRef(3);
        ESLVal $3751 = _v1880.termRef(4);
        
        {ESLVal l = $3755;
        
        {ESLVal ps = $3754;
        
        {ESLVal bs = $3753;
        
        {ESLVal g = $3752;
        
        {ESLVal old = $3751;
        
        return new ESLVal("LArm",l,ps,bs,g,e);
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(8778,8875)").add(ESLVal.list(_v1880)));
    }
    }
  }
  private static ESLVal setArmBody = new ESLVal(new Function(new ESLVal("setArmBody"),null) { public ESLVal apply(ESLVal... args) { return setArmBody(args[0],args[1]); }});
  private static ESLVal setArmPatterns(ESLVal arm,ESLVal ps) {
    
    {ESLVal _v1881 = arm;
      
      switch(_v1881.termName) {
      case "LArm": {ESLVal $3760 = _v1881.termRef(0);
        ESLVal $3759 = _v1881.termRef(1);
        ESLVal $3758 = _v1881.termRef(2);
        ESLVal $3757 = _v1881.termRef(3);
        ESLVal $3756 = _v1881.termRef(4);
        
        {ESLVal l = $3760;
        
        {ESLVal old = $3759;
        
        {ESLVal bs = $3758;
        
        {ESLVal g = $3757;
        
        {ESLVal e = $3756;
        
        return new ESLVal("LArm",l,ps,bs,g,e);
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(8925,9022)").add(ESLVal.list(_v1881)));
    }
    }
  }
  private static ESLVal setArmPatterns = new ESLVal(new Function(new ESLVal("setArmPatterns"),null) { public ESLVal apply(ESLVal... args) { return setArmPatterns(args[0],args[1]); }});
  private static ESLVal addArmBindings(ESLVal arm,ESLVal newBS) {
    
    {ESLVal _v1882 = arm;
      
      switch(_v1882.termName) {
      case "LArm": {ESLVal $3765 = _v1882.termRef(0);
        ESLVal $3764 = _v1882.termRef(1);
        ESLVal $3763 = _v1882.termRef(2);
        ESLVal $3762 = _v1882.termRef(3);
        ESLVal $3761 = _v1882.termRef(4);
        
        {ESLVal l = $3765;
        
        {ESLVal ps = $3764;
        
        {ESLVal bs = $3763;
        
        {ESLVal g = $3762;
        
        {ESLVal e = $3761;
        
        return new ESLVal("LArm",l,ps,bs.add(ESLVal.list(newBS)),g,e);
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(9073,9178)").add(ESLVal.list(_v1882)));
    }
    }
  }
  private static ESLVal addArmBindings = new ESLVal(new Function(new ESLVal("addArmBindings"),null) { public ESLVal apply(ESLVal... args) { return addArmBindings(args[0],args[1]); }});
  private static ESLVal isPVar(ESLVal p) {
    
    {ESLVal _v1883 = p;
      
      switch(_v1883.termName) {
      case "PVar": {ESLVal $3768 = _v1883.termRef(0);
        ESLVal $3767 = _v1883.termRef(1);
        ESLVal $3766 = _v1883.termRef(2);
        
        {ESLVal l = $3768;
        
        {ESLVal n = $3767;
        
        {ESLVal t = $3766;
        
        return $true;
      }
      }
      }
      }
      default: {ESLVal _v1940 = _v1883;
        
        return $false;
      }
    }
    }
  }
  private static ESLVal isPVar = new ESLVal(new Function(new ESLVal("isPVar"),null) { public ESLVal apply(ESLVal... args) { return isPVar(args[0]); }});
  private static ESLVal isPInt(ESLVal p) {
    
    {ESLVal _v1884 = p;
      
      switch(_v1884.termName) {
      case "PInt": {ESLVal $3770 = _v1884.termRef(0);
        ESLVal $3769 = _v1884.termRef(1);
        
        {ESLVal l = $3770;
        
        {ESLVal n = $3769;
        
        return $true;
      }
      }
      }
      default: {ESLVal _v1939 = _v1884;
        
        return $false;
      }
    }
    }
  }
  private static ESLVal isPInt = new ESLVal(new Function(new ESLVal("isPInt"),null) { public ESLVal apply(ESLVal... args) { return isPInt(args[0]); }});
  private static ESLVal isPStr(ESLVal p) {
    
    {ESLVal _v1885 = p;
      
      switch(_v1885.termName) {
      case "PStr": {ESLVal $3772 = _v1885.termRef(0);
        ESLVal $3771 = _v1885.termRef(1);
        
        {ESLVal l = $3772;
        
        {ESLVal n = $3771;
        
        return $true;
      }
      }
      }
      default: {ESLVal _v1938 = _v1885;
        
        return $false;
      }
    }
    }
  }
  private static ESLVal isPStr = new ESLVal(new Function(new ESLVal("isPStr"),null) { public ESLVal apply(ESLVal... args) { return isPStr(args[0]); }});
  private static ESLVal isPBool(ESLVal p) {
    
    {ESLVal _v1886 = p;
      
      switch(_v1886.termName) {
      case "PBool": {ESLVal $3774 = _v1886.termRef(0);
        ESLVal $3773 = _v1886.termRef(1);
        
        {ESLVal l = $3774;
        
        {ESLVal b = $3773;
        
        return $true;
      }
      }
      }
      default: {ESLVal _v1937 = _v1886;
        
        return $false;
      }
    }
    }
  }
  private static ESLVal isPBool = new ESLVal(new Function(new ESLVal("isPBool"),null) { public ESLVal apply(ESLVal... args) { return isPBool(args[0]); }});
  private static ESLVal isPTerm(ESLVal p) {
    
    {ESLVal _v1887 = p;
      
      switch(_v1887.termName) {
      case "PTerm": {ESLVal $3778 = _v1887.termRef(0);
        ESLVal $3777 = _v1887.termRef(1);
        ESLVal $3776 = _v1887.termRef(2);
        ESLVal $3775 = _v1887.termRef(3);
        
        {ESLVal l = $3778;
        
        {ESLVal n = $3777;
        
        {ESLVal ts = $3776;
        
        {ESLVal ps = $3775;
        
        return $true;
      }
      }
      }
      }
      }
      default: {ESLVal _v1936 = _v1887;
        
        return $false;
      }
    }
    }
  }
  private static ESLVal isPTerm = new ESLVal(new Function(new ESLVal("isPTerm"),null) { public ESLVal apply(ESLVal... args) { return isPTerm(args[0]); }});
  private static ESLVal isPCons(ESLVal p) {
    
    {ESLVal _v1888 = p;
      
      switch(_v1888.termName) {
      case "PCons": {ESLVal $3781 = _v1888.termRef(0);
        ESLVal $3780 = _v1888.termRef(1);
        ESLVal $3779 = _v1888.termRef(2);
        
        {ESLVal l = $3781;
        
        {ESLVal h = $3780;
        
        {ESLVal t = $3779;
        
        return $true;
      }
      }
      }
      }
      default: {ESLVal _v1935 = _v1888;
        
        return $false;
      }
    }
    }
  }
  private static ESLVal isPCons = new ESLVal(new Function(new ESLVal("isPCons"),null) { public ESLVal apply(ESLVal... args) { return isPCons(args[0]); }});
  private static ESLVal isPNil(ESLVal p) {
    
    {ESLVal _v1889 = p;
      
      switch(_v1889.termName) {
      case "PNil": {ESLVal $3786 = _v1889.termRef(0);
        
        {ESLVal l = $3786;
        
        return $true;
      }
      }
    case "PApplyType": {ESLVal $3784 = _v1889.termRef(0);
        ESLVal $3783 = _v1889.termRef(1);
        ESLVal $3782 = _v1889.termRef(2);
        
        switch($3783.termName) {
        case "PNil": {ESLVal $3785 = $3783.termRef(0);
          
          {ESLVal l1 = $3784;
          
          {ESLVal l2 = $3785;
          
          {ESLVal ts = $3782;
          
          return $true;
        }
        }
        }
        }
        default: {ESLVal _v1933 = _v1889;
          
          return $false;
        }
      }
      }
      default: {ESLVal _v1934 = _v1889;
        
        return $false;
      }
    }
    }
  }
  private static ESLVal isPNil = new ESLVal(new Function(new ESLVal("isPNil"),null) { public ESLVal apply(ESLVal... args) { return isPNil(args[0]); }});
  private static ESLVal isPList(ESLVal p) {
    
    return isPCons(p).or(isPNil(p));
  }
  private static ESLVal isPList = new ESLVal(new Function(new ESLVal("isPList"),null) { public ESLVal apply(ESLVal... args) { return isPList(args[0]); }});
  private static ESLVal isPNonDetList(ESLVal p) {
    
    return isPAdd(p);
  }
  private static ESLVal isPNonDetList = new ESLVal(new Function(new ESLVal("isPNonDetList"),null) { public ESLVal apply(ESLVal... args) { return isPNonDetList(args[0]); }});
  private static ESLVal isPSetCons(ESLVal p) {
    
    {ESLVal _v1890 = p;
      
      switch(_v1890.termName) {
      case "PSetCons": {ESLVal $3789 = _v1890.termRef(0);
        ESLVal $3788 = _v1890.termRef(1);
        ESLVal $3787 = _v1890.termRef(2);
        
        {ESLVal l = $3789;
        
        {ESLVal p1 = $3788;
        
        {ESLVal p2 = $3787;
        
        return $true;
      }
      }
      }
      }
      default: {ESLVal _v1932 = _v1890;
        
        return $false;
      }
    }
    }
  }
  private static ESLVal isPSetCons = new ESLVal(new Function(new ESLVal("isPSetCons"),null) { public ESLVal apply(ESLVal... args) { return isPSetCons(args[0]); }});
  private static ESLVal isPEmptySet(ESLVal p) {
    
    {ESLVal _v1891 = p;
      
      switch(_v1891.termName) {
      case "PEmptySet": {ESLVal $3790 = _v1891.termRef(0);
        
        {ESLVal l = $3790;
        
        return $true;
      }
      }
      default: {ESLVal _v1931 = _v1891;
        
        return $false;
      }
    }
    }
  }
  private static ESLVal isPEmptySet = new ESLVal(new Function(new ESLVal("isPEmptySet"),null) { public ESLVal apply(ESLVal... args) { return isPEmptySet(args[0]); }});
  private static ESLVal isPAdd(ESLVal p) {
    
    {ESLVal _v1892 = p;
      
      switch(_v1892.termName) {
      case "PAdd": {ESLVal $3793 = _v1892.termRef(0);
        ESLVal $3792 = _v1892.termRef(1);
        ESLVal $3791 = _v1892.termRef(2);
        
        {ESLVal l = $3793;
        
        {ESLVal p1 = $3792;
        
        {ESLVal p2 = $3791;
        
        return $true;
      }
      }
      }
      }
      default: {ESLVal _v1930 = _v1892;
        
        return $false;
      }
    }
    }
  }
  private static ESLVal isPAdd = new ESLVal(new Function(new ESLVal("isPAdd"),null) { public ESLVal apply(ESLVal... args) { return isPAdd(args[0]); }});
  private static ESLVal isPSet(ESLVal p) {
    
    return isPSetCons(p).or(isPEmptySet(p));
  }
  private static ESLVal isPSet = new ESLVal(new Function(new ESLVal("isPSet"),null) { public ESLVal apply(ESLVal... args) { return isPSet(args[0]); }});
  private static ESLVal pTermName(ESLVal p) {
    
    {ESLVal _v1893 = p;
      
      switch(_v1893.termName) {
      case "PTerm": {ESLVal $3797 = _v1893.termRef(0);
        ESLVal $3796 = _v1893.termRef(1);
        ESLVal $3795 = _v1893.termRef(2);
        ESLVal $3794 = _v1893.termRef(3);
        
        {ESLVal l = $3797;
        
        {ESLVal n = $3796;
        
        {ESLVal ts = $3795;
        
        {ESLVal ps = $3794;
        
        return n;
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(10558,10626)").add(ESLVal.list(_v1893)));
    }
    }
  }
  private static ESLVal pTermName = new ESLVal(new Function(new ESLVal("pTermName"),null) { public ESLVal apply(ESLVal... args) { return pTermName(args[0]); }});
  private static ESLVal pTermArgs(ESLVal p) {
    
    {ESLVal _v1894 = p;
      
      switch(_v1894.termName) {
      case "PTerm": {ESLVal $3801 = _v1894.termRef(0);
        ESLVal $3800 = _v1894.termRef(1);
        ESLVal $3799 = _v1894.termRef(2);
        ESLVal $3798 = _v1894.termRef(3);
        
        {ESLVal l = $3801;
        
        {ESLVal n = $3800;
        
        {ESLVal ts = $3799;
        
        {ESLVal ps = $3798;
        
        return ps;
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(10666,10735)").add(ESLVal.list(_v1894)));
    }
    }
  }
  private static ESLVal pTermArgs = new ESLVal(new Function(new ESLVal("pTermArgs"),null) { public ESLVal apply(ESLVal... args) { return pTermArgs(args[0]); }});
  private static ESLVal pVarName(ESLVal p) {
    
    {ESLVal _v1895 = p;
      
      switch(_v1895.termName) {
      case "PVar": {ESLVal $3804 = _v1895.termRef(0);
        ESLVal $3803 = _v1895.termRef(1);
        ESLVal $3802 = _v1895.termRef(2);
        
        {ESLVal l = $3804;
        
        {ESLVal n = $3803;
        
        {ESLVal t = $3802;
        
        return n;
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(10768,10818)").add(ESLVal.list(_v1895)));
    }
    }
  }
  private static ESLVal pVarName = new ESLVal(new Function(new ESLVal("pVarName"),null) { public ESLVal apply(ESLVal... args) { return pVarName(args[0]); }});
  private static ESLVal pConsHead(ESLVal p) {
    
    {ESLVal _v1896 = p;
      
      switch(_v1896.termName) {
      case "PCons": {ESLVal $3807 = _v1896.termRef(0);
        ESLVal $3806 = _v1896.termRef(1);
        ESLVal $3805 = _v1896.termRef(2);
        
        {ESLVal l = $3807;
        
        {ESLVal h = $3806;
        
        {ESLVal t = $3805;
        
        return h;
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(10856,10914)").add(ESLVal.list(_v1896)));
    }
    }
  }
  private static ESLVal pConsHead = new ESLVal(new Function(new ESLVal("pConsHead"),null) { public ESLVal apply(ESLVal... args) { return pConsHead(args[0]); }});
  private static ESLVal pConsTail(ESLVal p) {
    
    {ESLVal _v1897 = p;
      
      switch(_v1897.termName) {
      case "PCons": {ESLVal $3810 = _v1897.termRef(0);
        ESLVal $3809 = _v1897.termRef(1);
        ESLVal $3808 = _v1897.termRef(2);
        
        {ESLVal l = $3810;
        
        {ESLVal h = $3809;
        
        {ESLVal t = $3808;
        
        return t;
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(10952,11010)").add(ESLVal.list(_v1897)));
    }
    }
  }
  private static ESLVal pConsTail = new ESLVal(new Function(new ESLVal("pConsTail"),null) { public ESLVal apply(ESLVal... args) { return pConsTail(args[0]); }});
  private static ESLVal pSetConsHead(ESLVal p) {
    
    {ESLVal _v1898 = p;
      
      switch(_v1898.termName) {
      case "PSetCons": {ESLVal $3813 = _v1898.termRef(0);
        ESLVal $3812 = _v1898.termRef(1);
        ESLVal $3811 = _v1898.termRef(2);
        
        {ESLVal l = $3813;
        
        {ESLVal h = $3812;
        
        {ESLVal t = $3811;
        
        return h;
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(11051,11112)").add(ESLVal.list(_v1898)));
    }
    }
  }
  private static ESLVal pSetConsHead = new ESLVal(new Function(new ESLVal("pSetConsHead"),null) { public ESLVal apply(ESLVal... args) { return pSetConsHead(args[0]); }});
  private static ESLVal pSetConsTail(ESLVal p) {
    
    {ESLVal _v1899 = p;
      
      switch(_v1899.termName) {
      case "PSetCons": {ESLVal $3816 = _v1899.termRef(0);
        ESLVal $3815 = _v1899.termRef(1);
        ESLVal $3814 = _v1899.termRef(2);
        
        {ESLVal l = $3816;
        
        {ESLVal h = $3815;
        
        {ESLVal t = $3814;
        
        return t;
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(11153,11214)").add(ESLVal.list(_v1899)));
    }
    }
  }
  private static ESLVal pSetConsTail = new ESLVal(new Function(new ESLVal("pSetConsTail"),null) { public ESLVal apply(ESLVal... args) { return pSetConsTail(args[0]); }});
  private static ESLVal pAddLeft(ESLVal p) {
    
    {ESLVal _v1900 = p;
      
      switch(_v1900.termName) {
      case "PAdd": {ESLVal $3819 = _v1900.termRef(0);
        ESLVal $3818 = _v1900.termRef(1);
        ESLVal $3817 = _v1900.termRef(2);
        
        {ESLVal l = $3819;
        
        {ESLVal left = $3818;
        
        {ESLVal right = $3817;
        
        return left;
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(11250,11317)").add(ESLVal.list(_v1900)));
    }
    }
  }
  private static ESLVal pAddLeft = new ESLVal(new Function(new ESLVal("pAddLeft"),null) { public ESLVal apply(ESLVal... args) { return pAddLeft(args[0]); }});
  private static ESLVal pAddRight(ESLVal p) {
    
    {ESLVal _v1901 = p;
      
      switch(_v1901.termName) {
      case "PAdd": {ESLVal $3822 = _v1901.termRef(0);
        ESLVal $3821 = _v1901.termRef(1);
        ESLVal $3820 = _v1901.termRef(2);
        
        {ESLVal l = $3822;
        
        {ESLVal left = $3821;
        
        {ESLVal right = $3820;
        
        return right;
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(11354,11422)").add(ESLVal.list(_v1901)));
    }
    }
  }
  private static ESLVal pAddRight = new ESLVal(new Function(new ESLVal("pAddRight"),null) { public ESLVal apply(ESLVal... args) { return pAddRight(args[0]); }});
  private static ESLVal pIntValue(ESLVal p) {
    
    {ESLVal _v1902 = p;
      
      switch(_v1902.termName) {
      case "PInt": {ESLVal $3824 = _v1902.termRef(0);
        ESLVal $3823 = _v1902.termRef(1);
        
        {ESLVal l = $3824;
        
        {ESLVal n = $3823;
        
        return n;
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(11456,11498)").add(ESLVal.list(_v1902)));
    }
    }
  }
  private static ESLVal pIntValue = new ESLVal(new Function(new ESLVal("pIntValue"),null) { public ESLVal apply(ESLVal... args) { return pIntValue(args[0]); }});
  private static ESLVal pStrValue(ESLVal p) {
    
    {ESLVal _v1903 = p;
      
      switch(_v1903.termName) {
      case "PStr": {ESLVal $3826 = _v1903.termRef(0);
        ESLVal $3825 = _v1903.termRef(1);
        
        {ESLVal l = $3826;
        
        {ESLVal n = $3825;
        
        return n;
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(11532,11574)").add(ESLVal.list(_v1903)));
    }
    }
  }
  private static ESLVal pStrValue = new ESLVal(new Function(new ESLVal("pStrValue"),null) { public ESLVal apply(ESLVal... args) { return pStrValue(args[0]); }});
  private static ESLVal pBoolValue(ESLVal p) {
    
    {ESLVal _v1904 = p;
      
      switch(_v1904.termName) {
      case "PBool": {ESLVal $3828 = _v1904.termRef(0);
        ESLVal $3827 = _v1904.termRef(1);
        
        {ESLVal l = $3828;
        
        {ESLVal b = $3827;
        
        return b;
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(11610,11655)").add(ESLVal.list(_v1904)));
    }
    }
  }
  private static ESLVal pBoolValue = new ESLVal(new Function(new ESLVal("pBoolValue"),null) { public ESLVal apply(ESLVal... args) { return pBoolValue(args[0]); }});
  private static ESLVal isEmptyPatterns(ESLVal arms) {
    
    return forall.apply(new ESLVal(new Function(new ESLVal("fun431"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return length.apply(armPatterns(a)).eql($zero);
        }
      }),arms);
  }
  private static ESLVal isEmptyPatterns = new ESLVal(new Function(new ESLVal("isEmptyPatterns"),null) { public ESLVal apply(ESLVal... args) { return isEmptyPatterns(args[0]); }});
  private static ESLVal isFirstColumnVars(ESLVal arms) {
    
    return forall.apply(new ESLVal(new Function(new ESLVal("fun432"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPVar(head.apply(armPatterns(a)));
        }
      }),arms);
  }
  private static ESLVal isFirstColumnVars = new ESLVal(new Function(new ESLVal("isFirstColumnVars"),null) { public ESLVal apply(ESLVal... args) { return isFirstColumnVars(args[0]); }});
  private static ESLVal isFirstColumnInts(ESLVal arms) {
    
    return forall.apply(new ESLVal(new Function(new ESLVal("fun433"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPInt(head.apply(armPatterns(a)));
        }
      }),arms);
  }
  private static ESLVal isFirstColumnInts = new ESLVal(new Function(new ESLVal("isFirstColumnInts"),null) { public ESLVal apply(ESLVal... args) { return isFirstColumnInts(args[0]); }});
  private static ESLVal isFirstColumnStrs(ESLVal arms) {
    
    return forall.apply(new ESLVal(new Function(new ESLVal("fun434"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPStr(head.apply(armPatterns(a)));
        }
      }),arms);
  }
  private static ESLVal isFirstColumnStrs = new ESLVal(new Function(new ESLVal("isFirstColumnStrs"),null) { public ESLVal apply(ESLVal... args) { return isFirstColumnStrs(args[0]); }});
  private static ESLVal isFirstColumnBools(ESLVal arms) {
    
    return forall.apply(new ESLVal(new Function(new ESLVal("fun435"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPBool(head.apply(armPatterns(a)));
        }
      }),arms);
  }
  private static ESLVal isFirstColumnBools = new ESLVal(new Function(new ESLVal("isFirstColumnBools"),null) { public ESLVal apply(ESLVal... args) { return isFirstColumnBools(args[0]); }});
  private static ESLVal isFirstColumnCnstrs(ESLVal arms) {
    
    return forall.apply(new ESLVal(new Function(new ESLVal("fun436"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPTerm(head.apply(armPatterns(a)));
        }
      }),arms);
  }
  private static ESLVal isFirstColumnCnstrs = new ESLVal(new Function(new ESLVal("isFirstColumnCnstrs"),null) { public ESLVal apply(ESLVal... args) { return isFirstColumnCnstrs(args[0]); }});
  private static ESLVal isFirstColumnSets(ESLVal arms) {
    
    return forall.apply(new ESLVal(new Function(new ESLVal("fun437"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPSet(head.apply(armPatterns(a)));
        }
      }),arms);
  }
  private static ESLVal isFirstColumnSets = new ESLVal(new Function(new ESLVal("isFirstColumnSets"),null) { public ESLVal apply(ESLVal... args) { return isFirstColumnSets(args[0]); }});
  private static ESLVal isFirstColumnNonDetLists(ESLVal arms) {
    
    return forall.apply(new ESLVal(new Function(new ESLVal("fun438"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPNonDetList(head.apply(armPatterns(a)));
        }
      }),arms);
  }
  private static ESLVal isFirstColumnNonDetLists = new ESLVal(new Function(new ESLVal("isFirstColumnNonDetLists"),null) { public ESLVal apply(ESLVal... args) { return isFirstColumnNonDetLists(args[0]); }});
  private static ESLVal isFirstColumnLists(ESLVal arms) {
    
    {ESLVal isList = new ESLVal(new Function(new ESLVal("isList"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPCons(head.apply(armPatterns(a))).or(isPNil(head.apply(armPatterns(a))));
          }
        });
      
      return forall.apply(isList,arms);
    }
  }
  private static ESLVal isFirstColumnLists = new ESLVal(new Function(new ESLVal("isFirstColumnLists"),null) { public ESLVal apply(ESLVal... args) { return isFirstColumnLists(args[0]); }});
  private static ESLVal dropPattern(ESLVal arm) {
    
    return setArmPatterns(arm,tail.apply(armPatterns(arm)));
  }
  private static ESLVal dropPattern = new ESLVal(new Function(new ESLVal("dropPattern"),null) { public ESLVal apply(ESLVal... args) { return dropPattern(args[0]); }});
  private static ESLVal firstVarNames(ESLVal arms) {
    
    return map.apply(new ESLVal(new Function(new ESLVal("fun439"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return pVarName(head.apply(armPatterns(a)));
        }
      }),arms);
  }
  private static ESLVal firstVarNames = new ESLVal(new Function(new ESLVal("firstVarNames"),null) { public ESLVal apply(ESLVal... args) { return firstVarNames(args[0]); }});
  private static ESLVal sharedCnstr(ESLVal arms) {
    
    return pTermName(head.apply(armPatterns(head.apply(arms))));
  }
  private static ESLVal sharedCnstr = new ESLVal(new Function(new ESLVal("sharedCnstr"),null) { public ESLVal apply(ESLVal... args) { return sharedCnstr(args[0]); }});
  private static ESLVal sharedInt(ESLVal arms) {
    
    return pIntValue(head.apply(armPatterns(head.apply(arms))));
  }
  private static ESLVal sharedInt = new ESLVal(new Function(new ESLVal("sharedInt"),null) { public ESLVal apply(ESLVal... args) { return sharedInt(args[0]); }});
  private static ESLVal sharedStr(ESLVal arms) {
    
    return pStrValue(head.apply(armPatterns(head.apply(arms))));
  }
  private static ESLVal sharedStr = new ESLVal(new Function(new ESLVal("sharedStr"),null) { public ESLVal apply(ESLVal... args) { return sharedStr(args[0]); }});
  private static ESLVal sharedBool(ESLVal arms) {
    
    return pBoolValue(head.apply(armPatterns(head.apply(arms))));
  }
  private static ESLVal sharedBool = new ESLVal(new Function(new ESLVal("sharedBool"),null) { public ESLVal apply(ESLVal... args) { return sharedBool(args[0]); }});
  private static ESLVal bindVarsBody(ESLVal e,ESLVal vNames) {
    
    return new ESLVal(new Function(new ESLVal("fun440"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal arms = $args[0];
      { LetRec letrec = new LetRec() {
            ESLVal bind = new ESLVal(new Function(new ESLVal("bind"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal _v1924 = $args[0];
              ESLVal _v1925 = $args[1];
              {ESLVal _v1905 = _v1924;
                    ESLVal _v1906 = _v1925;
                    
                    if(_v1905.isCons())
                    {ESLVal $3829 = _v1905.head();
                      ESLVal $3830 = _v1905.tail();
                      
                      if(_v1906.isCons())
                      {ESLVal $3831 = _v1906.head();
                        ESLVal $3832 = _v1906.tail();
                        
                        {ESLVal a = $3829;
                        
                        {ESLVal _v1926 = $3830;
                        
                        {ESLVal v = $3831;
                        
                        {ESLVal _v1927 = $3832;
                        
                        {ESLVal _v1907 = e;
                        
                        switch(_v1907.termName) {
                        case "Var": {ESLVal $3836 = _v1907.termRef(0);
                          ESLVal $3835 = _v1907.termRef(1);
                          
                          {ESLVal l = $3836;
                          
                          {ESLVal n = $3835;
                          
                          if(n.eql(v).boolVal)
                          return bind.apply(_v1926,_v1927).cons(a);
                          else
                            {ESLVal _v1928 = _v1907;
                              
                              return bind.apply(_v1926,_v1927).cons(addArmBindings(a,ESLVal.list(new ESLVal("Binding",loc0,v,voidType,voidType,_v1928))));
                            }
                        }
                        }
                        }
                        default: {ESLVal _v1929 = _v1907;
                          
                          return bind.apply(_v1926,_v1927).cons(addArmBindings(a,ESLVal.list(new ESLVal("Binding",loc0,v,voidType,voidType,_v1929))));
                        }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                    else if(_v1906.isNil())
                      return error(new ESLVal("case error at Pos(13825,14135)").add(ESLVal.list(_v1905,_v1906)));
                    else return error(new ESLVal("case error at Pos(13825,14135)").add(ESLVal.list(_v1905,_v1906)));
                    }
                  else if(_v1905.isNil())
                    if(_v1906.isCons())
                      {ESLVal $3833 = _v1906.head();
                        ESLVal $3834 = _v1906.tail();
                        
                        return error(new ESLVal("case error at Pos(13825,14135)").add(ESLVal.list(_v1905,_v1906)));
                      }
                    else if(_v1906.isNil())
                      return $nil;
                    else return error(new ESLVal("case error at Pos(13825,14135)").add(ESLVal.list(_v1905,_v1906)));
                  else return error(new ESLVal("case error at Pos(13825,14135)").add(ESLVal.list(_v1905,_v1906)));
                  }
                }
              });
            
            public ESLVal get(String name) {
              switch(name) {
                case "bind": return bind;
                
                default: throw new Error("cannot find letrec binding");
              }
              }
            };
          ESLVal bind = letrec.get("bind");
          
            return bind.apply(arms,vNames);}
          
        }
      });
  }
  private static ESLVal bindVarsBody = new ESLVal(new Function(new ESLVal("bindVarsBody"),null) { public ESLVal apply(ESLVal... args) { return bindVarsBody(args[0],args[1]); }});
  private static ESLVal bindVars(ESLVal e,ESLVal arms) {
    
    return bindVarsBody(e,firstVarNames(arms)).apply(map.apply(dropPattern,arms));
  }
  private static ESLVal bindVars = new ESLVal(new Function(new ESLVal("bindVars"),null) { public ESLVal apply(ESLVal... args) { return bindVars(args[0],args[1]); }});
  private static ESLVal cnstrArms(ESLVal c,ESLVal arms) {
    
    return filter.apply(new ESLVal(new Function(new ESLVal("fun441"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return pTermName(head.apply(armPatterns(a))).eql(c);
        }
      }),arms);
  }
  private static ESLVal cnstrArms = new ESLVal(new Function(new ESLVal("cnstrArms"),null) { public ESLVal apply(ESLVal... args) { return cnstrArms(args[0],args[1]); }});
  private static ESLVal intArms(ESLVal n,ESLVal arms) {
    
    return filter.apply(new ESLVal(new Function(new ESLVal("fun442"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return pIntValue(head.apply(armPatterns(a))).eql(n);
        }
      }),arms);
  }
  private static ESLVal intArms = new ESLVal(new Function(new ESLVal("intArms"),null) { public ESLVal apply(ESLVal... args) { return intArms(args[0],args[1]); }});
  private static ESLVal strArms(ESLVal s,ESLVal arms) {
    
    return filter.apply(new ESLVal(new Function(new ESLVal("fun443"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return pStrValue(head.apply(armPatterns(a))).eql(s);
        }
      }),arms);
  }
  private static ESLVal strArms = new ESLVal(new Function(new ESLVal("strArms"),null) { public ESLVal apply(ESLVal... args) { return strArms(args[0],args[1]); }});
  private static ESLVal boolArms(ESLVal b,ESLVal arms) {
    
    return filter.apply(new ESLVal(new Function(new ESLVal("fun444"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return pBoolValue(head.apply(armPatterns(a))).eql(b);
        }
      }),arms);
  }
  private static ESLVal boolArms = new ESLVal(new Function(new ESLVal("boolArms"),null) { public ESLVal apply(ESLVal... args) { return boolArms(args[0],args[1]); }});
  private static ESLVal fieldBindings(ESLVal e,ESLVal names) {
    
    return new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal n = $l0.head();
            $l0 = $l0.tail();
            $v.add(new ESLVal("Binding",loc0,n,voidType,voidType,new ESLVal("TermRef",e,indexOf.apply(n,names))));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(names);
  }
  private static ESLVal fieldBindings = new ESLVal(new Function(new ESLVal("fieldBindings"),null) { public ESLVal apply(ESLVal... args) { return fieldBindings(args[0],args[1]); }});
  private static ESLVal explodeCnstr(ESLVal a) {
    
    return setArmPatterns(a,pTermArgs(head.apply(armPatterns(a))).add(tail.apply(armPatterns(a))));
  }
  private static ESLVal explodeCnstr = new ESLVal(new Function(new ESLVal("explodeCnstr"),null) { public ESLVal apply(ESLVal... args) { return explodeCnstr(args[0]); }});
  private static ESLVal explodeCons(ESLVal a) {
    
    return setArmPatterns(a,ESLVal.list(pConsHead(head.apply(armPatterns(a))),pConsTail(head.apply(armPatterns(a)))).add(tail.apply(armPatterns(a))));
  }
  private static ESLVal explodeCons = new ESLVal(new Function(new ESLVal("explodeCons"),null) { public ESLVal apply(ESLVal... args) { return explodeCons(args[0]); }});
  private static ESLVal explodeSetCons(ESLVal a) {
    
    return setArmPatterns(a,ESLVal.list(pSetConsHead(head.apply(armPatterns(a))),pSetConsTail(head.apply(armPatterns(a)))).add(tail.apply(armPatterns(a))));
  }
  private static ESLVal explodeSetCons = new ESLVal(new Function(new ESLVal("explodeSetCons"),null) { public ESLVal apply(ESLVal... args) { return explodeSetCons(args[0]); }});
  private static ESLVal explodeAdd(ESLVal a) {
    
    return setArmPatterns(a,ESLVal.list(pAddLeft(head.apply(armPatterns(a))),pAddRight(head.apply(armPatterns(a)))).add(tail.apply(armPatterns(a))));
  }
  private static ESLVal explodeAdd = new ESLVal(new Function(new ESLVal("explodeAdd"),null) { public ESLVal apply(ESLVal... args) { return explodeAdd(args[0]); }});
  private static ESLVal cnstrArm(ESLVal l,ESLVal e,ESLVal es,ESLVal arms,ESLVal alt) {
    
    {ESLVal names = newVars(length.apply(pTermArgs(head.apply(armPatterns(head.apply(arms))))));
      
      return new ESLVal("Let",loc0,fieldBindings(e,names),compileCase(l,new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal n = $l0.head();
            $l0 = $l0.tail();
            $v.add(new ESLVal("Var",loc0,n));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(names).add(es),new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal a = $l0.head();
            $l0 = $l0.tail();
            $v.add(explodeCnstr(a));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(arms),alt));
    }
  }
  private static ESLVal cnstrArm = new ESLVal(new Function(new ESLVal("cnstrArm"),null) { public ESLVal apply(ESLVal... args) { return cnstrArm(args[0],args[1],args[2],args[3],args[4]); }});
  private static ESLVal processCnstrs(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    {ESLVal cnstrs = removeDups.apply(map.apply(pTermName,map.apply(head,map.apply(armPatterns,arms))));
      
      {ESLVal armss = map.apply(new ESLVal(new Function(new ESLVal("fun445"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal c = $args[0];
        return cnstrArms(c,arms);
          }
        }),cnstrs);
      
      return new ESLVal("CaseTerm",l,head.apply(es),createTArms(l,armss,es,alt),alt);
    }
    }
  }
  private static ESLVal processCnstrs = new ESLVal(new Function(new ESLVal("processCnstrs"),null) { public ESLVal apply(ESLVal... args) { return processCnstrs(args[0],args[1],args[2],args[3]); }});
  private static ESLVal createTArms(ESLVal l,ESLVal armss,ESLVal es,ESLVal alt) {
    
    {ESLVal _v1908 = armss;
      
      if(_v1908.isCons())
      {ESLVal $3837 = _v1908.head();
        ESLVal $3838 = _v1908.tail();
        
        {ESLVal as = $3837;
        
        {ESLVal _v1923 = $3838;
        
        return createTArms(l,_v1923,es,alt).cons(new ESLVal("TArm",sharedCnstr(as),cnstrArm(l,head.apply(es),tail.apply(es),as,alt)));
      }
      }
      }
    else if(_v1908.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(16496,16676)").add(ESLVal.list(_v1908)));
    }
  }
  private static ESLVal createTArms = new ESLVal(new Function(new ESLVal("createTArms"),null) { public ESLVal apply(ESLVal... args) { return createTArms(args[0],args[1],args[2],args[3]); }});
  private static ESLVal processConsArms(ESLVal loc,ESLVal es,ESLVal arms,ESLVal alt) {
    
    {ESLVal l = head.apply(es);
      ESLVal hn = newVar();
      ESLVal tn = newVar();
      
      {ESLVal hp = new ESLVal("PVar",loc0,hn,voidType);
      ESLVal tp = new ESLVal("PVar",loc0,tn,voidType);
      ESLVal hv = new ESLVal("Var",loc0,hn);
      ESLVal tv = new ESLVal("Var",loc0,tn);
      
      return new ESLVal("Let",loc0,ESLVal.list(new ESLVal("Binding",loc0,hn,voidType,voidType,new ESLVal("Head",l)),new ESLVal("Binding",loc0,tn,voidType,voidType,new ESLVal("Tail",l))),compileCase(loc,ESLVal.list(hv,tv).add(tail.apply(es)),new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal a = $l0.head();
            $l0 = $l0.tail();
            $v.add(explodeCons(a));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(arms),alt));
    }
    }
  }
  private static ESLVal processConsArms = new ESLVal(new Function(new ESLVal("processConsArms"),null) { public ESLVal apply(ESLVal... args) { return processConsArms(args[0],args[1],args[2],args[3]); }});
  private static ESLVal processLists(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    {ESLVal consArms = filter.apply(new ESLVal(new Function(new ESLVal("fun446"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPCons(head.apply(armPatterns(a)));
          }
        }),arms);
      ESLVal nilArms = map.apply(dropPattern,filter.apply(new ESLVal(new Function(new ESLVal("fun447"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPNil(head.apply(armPatterns(a)));
          }
        }),arms));
      
      return new ESLVal("CaseList",l,head.apply(es),processConsArms(l,es,consArms,alt),compileCase(l,tail.apply(es),nilArms,alt),alt);
    }
  }
  private static ESLVal processLists = new ESLVal(new Function(new ESLVal("processLists"),null) { public ESLVal apply(ESLVal... args) { return processLists(args[0],args[1],args[2],args[3]); }});
  private static ESLVal processSetArms(ESLVal l,ESLVal es,ESLVal arm) {
    
    {ESLVal _v1909 = head.apply(armPatterns(arm));
      
      switch(_v1909.termName) {
      case "PEmptySet": {ESLVal $3845 = _v1909.termRef(0);
        
        {ESLVal pl = $3845;
        
        {ESLVal fail = newVar();
        
        return new ESLVal("Term",l,new ESLVal("$empty"),$nil,ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("emptyset")),ESLVal.list(new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase(l,es,ESLVal.list(dropPattern(arm)),new ESLVal("Apply",l,new ESLVal("Var",l,fail),$nil)))));
      }
      }
      }
    case "PSetCons": {ESLVal $3844 = _v1909.termRef(0);
        ESLVal $3843 = _v1909.termRef(1);
        ESLVal $3842 = _v1909.termRef(2);
        
        {ESLVal pl = $3844;
        
        {ESLVal p1 = $3843;
        
        {ESLVal p2 = $3842;
        
        {ESLVal fail = newVar();
        ESLVal element = newVar();
        ESLVal rest = newVar();
        
        return new ESLVal("Term",l,new ESLVal("$cons"),$nil,ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("setcons")),ESLVal.list(new ESLVal("Dec",l,element,$null,$null),new ESLVal("Dec",l,rest,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase(l,ESLVal.list(new ESLVal("Var",l,element),new ESLVal("Var",l,rest)).add(es),ESLVal.list(explodeSetCons(arm)),new ESLVal("Apply",l,new ESLVal("Var",l,fail),$nil)))));
      }
      }
      }
      }
      }
    case "PAdd": {ESLVal $3841 = _v1909.termRef(0);
        ESLVal $3840 = _v1909.termRef(1);
        ESLVal $3839 = _v1909.termRef(2);
        
        {ESLVal pl = $3841;
        
        {ESLVal p1 = $3840;
        
        {ESLVal p2 = $3839;
        
        {ESLVal fail = newVar();
        ESLVal left = newVar();
        ESLVal right = newVar();
        
        return new ESLVal("Term",l,new ESLVal("$add"),$nil,ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("setadd")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,right)).add(es),ESLVal.list(explodeAdd(arm)),new ESLVal("Apply",l,new ESLVal("Var",l,fail),$nil)))));
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(17621,18742)").add(ESLVal.list(_v1909)));
    }
    }
  }
  private static ESLVal processSetArms = new ESLVal(new Function(new ESLVal("processSetArms"),null) { public ESLVal apply(ESLVal... args) { return processSetArms(args[0],args[1],args[2]); }});
  private static ESLVal processNonDetListArms(ESLVal l,ESLVal es,ESLVal arm) {
    
    {ESLVal _v1910 = head.apply(armPatterns(arm));
      
      switch(_v1910.termName) {
      case "PNil": {ESLVal $3874 = _v1910.termRef(0);
        
        {ESLVal pl = $3874;
        
        {ESLVal fail = newVar();
        
        return new ESLVal("Term",l,new ESLVal("$empty"),$nil,ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("nil")),ESLVal.list(new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase(l,es,ESLVal.list(dropPattern(arm)),new ESLVal("Apply",l,new ESLVal("Var",l,fail),$nil)))));
      }
      }
      }
    case "PCons": {ESLVal $3873 = _v1910.termRef(0);
        ESLVal $3872 = _v1910.termRef(1);
        ESLVal $3871 = _v1910.termRef(2);
        
        {ESLVal pl = $3873;
        
        {ESLVal p1 = $3872;
        
        {ESLVal p2 = $3871;
        
        {ESLVal fail = newVar();
        ESLVal element = newVar();
        ESLVal rest = newVar();
        
        return new ESLVal("Term",l,new ESLVal("$cons"),$nil,ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("cons")),ESLVal.list(new ESLVal("Dec",l,element,$null,$null),new ESLVal("Dec",l,rest,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase(l,ESLVal.list(new ESLVal("Var",l,element),new ESLVal("Var",l,rest)).add(es),ESLVal.list(explodeCons(arm)),new ESLVal("Apply",l,new ESLVal("Var",l,fail),$nil)))));
      }
      }
      }
      }
      }
    case "PAdd": {ESLVal $3848 = _v1910.termRef(0);
        ESLVal $3847 = _v1910.termRef(1);
        ESLVal $3846 = _v1910.termRef(2);
        
        switch($3847.termName) {
        case "PCons": {ESLVal $3869 = $3847.termRef(0);
          ESLVal $3868 = $3847.termRef(1);
          ESLVal $3867 = $3847.termRef(2);
          
          switch($3867.termName) {
          case "PNil": {ESLVal $3870 = $3867.termRef(0);
            
            {ESLVal l1 = $3848;
            
            {ESLVal l2 = $3869;
            
            {ESLVal p1 = $3868;
            
            {ESLVal l3 = $3870;
            
            {ESLVal p2 = $3846;
            
            {ESLVal fail = newVar();
            ESLVal left = newVar();
            ESLVal right = newVar();
            ESLVal newArm = setArmPatterns(arm,ESLVal.list(p1,p2).add(tail.apply(armPatterns(arm))));
            
            return new ESLVal("Term",l,new ESLVal("$selectLeft"),$nil,ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),$nil)))));
          }
          }
          }
          }
          }
          }
          }
          default: switch($3846.termName) {
            case "PCons": {ESLVal $3858 = $3846.termRef(0);
              ESLVal $3857 = $3846.termRef(1);
              ESLVal $3856 = $3846.termRef(2);
              
              switch($3856.termName) {
              case "PNil": {ESLVal $3859 = $3856.termRef(0);
                
                {ESLVal l1 = $3848;
                
                {ESLVal p1 = $3847;
                
                {ESLVal l2 = $3858;
                
                {ESLVal p2 = $3857;
                
                {ESLVal l3 = $3859;
                
                {ESLVal fail = newVar();
                ESLVal left = newVar();
                ESLVal right = newVar();
                ESLVal newArm = setArmPatterns(arm,ESLVal.list(p1,p2).add(tail.apply(armPatterns(arm))));
                
                return new ESLVal("Term",l,new ESLVal("$selectRight"),$nil,ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),$nil)))));
              }
              }
              }
              }
              }
              }
              }
              default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1910)));
            }
            }
          case "PAdd": {ESLVal $3851 = $3846.termRef(0);
              ESLVal $3850 = $3846.termRef(1);
              ESLVal $3849 = $3846.termRef(2);
              
              switch($3850.termName) {
              case "PCons": {ESLVal $3854 = $3850.termRef(0);
                ESLVal $3853 = $3850.termRef(1);
                ESLVal $3852 = $3850.termRef(2);
                
                switch($3852.termName) {
                case "PNil": {ESLVal $3855 = $3852.termRef(0);
                  
                  {ESLVal l1 = $3848;
                  
                  {ESLVal p1 = $3847;
                  
                  {ESLVal l2 = $3851;
                  
                  {ESLVal l3 = $3854;
                  
                  {ESLVal p2 = $3853;
                  
                  {ESLVal l4 = $3855;
                  
                  {ESLVal p3 = $3849;
                  
                  {ESLVal fail = newVar();
                  ESLVal left = newVar();
                  ESLVal mid = newVar();
                  ESLVal right = newVar();
                  ESLVal newArm = setArmPatterns(arm,ESLVal.list(p1,p2,p3).add(tail.apply(armPatterns(arm))));
                  
                  return new ESLVal("Term",l,new ESLVal("$selectMid"),$nil,ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,mid,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,mid),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),$nil)))));
                }
                }
                }
                }
                }
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1910)));
              }
              }
              default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1910)));
            }
            }
            default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1910)));
          }
        }
        }
      case "PAdd": {ESLVal $3862 = $3847.termRef(0);
          ESLVal $3861 = $3847.termRef(1);
          ESLVal $3860 = $3847.termRef(2);
          
          switch($3860.termName) {
          case "PCons": {ESLVal $3865 = $3860.termRef(0);
            ESLVal $3864 = $3860.termRef(1);
            ESLVal $3863 = $3860.termRef(2);
            
            switch($3863.termName) {
            case "PNil": {ESLVal $3866 = $3863.termRef(0);
              
              {ESLVal l1 = $3848;
              
              {ESLVal l2 = $3862;
              
              {ESLVal p1 = $3861;
              
              {ESLVal l3 = $3865;
              
              {ESLVal p2 = $3864;
              
              {ESLVal l4 = $3866;
              
              {ESLVal p3 = $3846;
              
              {ESLVal fail = newVar();
              ESLVal left = newVar();
              ESLVal mid = newVar();
              ESLVal right = newVar();
              ESLVal newArm = setArmPatterns(arm,ESLVal.list(p1,p2,p3).add(armPatterns(arm)));
              
              return new ESLVal("Term",l,new ESLVal("$selectMid"),$nil,ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,mid,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,mid),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),$nil)))));
            }
            }
            }
            }
            }
            }
            }
            }
            }
            default: switch($3846.termName) {
              case "PCons": {ESLVal $3858 = $3846.termRef(0);
                ESLVal $3857 = $3846.termRef(1);
                ESLVal $3856 = $3846.termRef(2);
                
                switch($3856.termName) {
                case "PNil": {ESLVal $3859 = $3856.termRef(0);
                  
                  {ESLVal l1 = $3848;
                  
                  {ESLVal p1 = $3847;
                  
                  {ESLVal l2 = $3858;
                  
                  {ESLVal p2 = $3857;
                  
                  {ESLVal l3 = $3859;
                  
                  {ESLVal fail = newVar();
                  ESLVal left = newVar();
                  ESLVal right = newVar();
                  ESLVal newArm = setArmPatterns(arm,ESLVal.list(p1,p2).add(tail.apply(armPatterns(arm))));
                  
                  return new ESLVal("Term",l,new ESLVal("$selectRight"),$nil,ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),$nil)))));
                }
                }
                }
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1910)));
              }
              }
            case "PAdd": {ESLVal $3851 = $3846.termRef(0);
                ESLVal $3850 = $3846.termRef(1);
                ESLVal $3849 = $3846.termRef(2);
                
                switch($3850.termName) {
                case "PCons": {ESLVal $3854 = $3850.termRef(0);
                  ESLVal $3853 = $3850.termRef(1);
                  ESLVal $3852 = $3850.termRef(2);
                  
                  switch($3852.termName) {
                  case "PNil": {ESLVal $3855 = $3852.termRef(0);
                    
                    {ESLVal l1 = $3848;
                    
                    {ESLVal p1 = $3847;
                    
                    {ESLVal l2 = $3851;
                    
                    {ESLVal l3 = $3854;
                    
                    {ESLVal p2 = $3853;
                    
                    {ESLVal l4 = $3855;
                    
                    {ESLVal p3 = $3849;
                    
                    {ESLVal fail = newVar();
                    ESLVal left = newVar();
                    ESLVal mid = newVar();
                    ESLVal right = newVar();
                    ESLVal newArm = setArmPatterns(arm,ESLVal.list(p1,p2,p3).add(tail.apply(armPatterns(arm))));
                    
                    return new ESLVal("Term",l,new ESLVal("$selectMid"),$nil,ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,mid,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,mid),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),$nil)))));
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1910)));
                }
                }
                default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1910)));
              }
              }
              default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1910)));
            }
          }
          }
          default: switch($3846.termName) {
            case "PCons": {ESLVal $3858 = $3846.termRef(0);
              ESLVal $3857 = $3846.termRef(1);
              ESLVal $3856 = $3846.termRef(2);
              
              switch($3856.termName) {
              case "PNil": {ESLVal $3859 = $3856.termRef(0);
                
                {ESLVal l1 = $3848;
                
                {ESLVal p1 = $3847;
                
                {ESLVal l2 = $3858;
                
                {ESLVal p2 = $3857;
                
                {ESLVal l3 = $3859;
                
                {ESLVal fail = newVar();
                ESLVal left = newVar();
                ESLVal right = newVar();
                ESLVal newArm = setArmPatterns(arm,ESLVal.list(p1,p2).add(tail.apply(armPatterns(arm))));
                
                return new ESLVal("Term",l,new ESLVal("$selectRight"),$nil,ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),$nil)))));
              }
              }
              }
              }
              }
              }
              }
              default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1910)));
            }
            }
          case "PAdd": {ESLVal $3851 = $3846.termRef(0);
              ESLVal $3850 = $3846.termRef(1);
              ESLVal $3849 = $3846.termRef(2);
              
              switch($3850.termName) {
              case "PCons": {ESLVal $3854 = $3850.termRef(0);
                ESLVal $3853 = $3850.termRef(1);
                ESLVal $3852 = $3850.termRef(2);
                
                switch($3852.termName) {
                case "PNil": {ESLVal $3855 = $3852.termRef(0);
                  
                  {ESLVal l1 = $3848;
                  
                  {ESLVal p1 = $3847;
                  
                  {ESLVal l2 = $3851;
                  
                  {ESLVal l3 = $3854;
                  
                  {ESLVal p2 = $3853;
                  
                  {ESLVal l4 = $3855;
                  
                  {ESLVal p3 = $3849;
                  
                  {ESLVal fail = newVar();
                  ESLVal left = newVar();
                  ESLVal mid = newVar();
                  ESLVal right = newVar();
                  ESLVal newArm = setArmPatterns(arm,ESLVal.list(p1,p2,p3).add(tail.apply(armPatterns(arm))));
                  
                  return new ESLVal("Term",l,new ESLVal("$selectMid"),$nil,ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,mid,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,mid),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),$nil)))));
                }
                }
                }
                }
                }
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1910)));
              }
              }
              default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1910)));
            }
            }
            default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1910)));
          }
        }
        }
        default: switch($3846.termName) {
          case "PCons": {ESLVal $3858 = $3846.termRef(0);
            ESLVal $3857 = $3846.termRef(1);
            ESLVal $3856 = $3846.termRef(2);
            
            switch($3856.termName) {
            case "PNil": {ESLVal $3859 = $3856.termRef(0);
              
              {ESLVal l1 = $3848;
              
              {ESLVal p1 = $3847;
              
              {ESLVal l2 = $3858;
              
              {ESLVal p2 = $3857;
              
              {ESLVal l3 = $3859;
              
              {ESLVal fail = newVar();
              ESLVal left = newVar();
              ESLVal right = newVar();
              ESLVal newArm = setArmPatterns(arm,ESLVal.list(p1,p2).add(tail.apply(armPatterns(arm))));
              
              return new ESLVal("Term",l,new ESLVal("$selectRight"),$nil,ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),$nil)))));
            }
            }
            }
            }
            }
            }
            }
            default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1910)));
          }
          }
        case "PAdd": {ESLVal $3851 = $3846.termRef(0);
            ESLVal $3850 = $3846.termRef(1);
            ESLVal $3849 = $3846.termRef(2);
            
            switch($3850.termName) {
            case "PCons": {ESLVal $3854 = $3850.termRef(0);
              ESLVal $3853 = $3850.termRef(1);
              ESLVal $3852 = $3850.termRef(2);
              
              switch($3852.termName) {
              case "PNil": {ESLVal $3855 = $3852.termRef(0);
                
                {ESLVal l1 = $3848;
                
                {ESLVal p1 = $3847;
                
                {ESLVal l2 = $3851;
                
                {ESLVal l3 = $3854;
                
                {ESLVal p2 = $3853;
                
                {ESLVal l4 = $3855;
                
                {ESLVal p3 = $3849;
                
                {ESLVal fail = newVar();
                ESLVal left = newVar();
                ESLVal mid = newVar();
                ESLVal right = newVar();
                ESLVal newArm = setArmPatterns(arm,ESLVal.list(p1,p2,p3).add(tail.apply(armPatterns(arm))));
                
                return new ESLVal("Term",l,new ESLVal("$selectMid"),$nil,ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,mid,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,mid),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),$nil)))));
              }
              }
              }
              }
              }
              }
              }
              }
              }
              default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1910)));
            }
            }
            default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1910)));
          }
          }
          default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1910)));
        }
      }
      }
      default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v1910)));
    }
    }
  }
  private static ESLVal processNonDetListArms = new ESLVal(new Function(new ESLVal("processNonDetListArms"),null) { public ESLVal apply(ESLVal... args) { return processNonDetListArms(args[0],args[1],args[2]); }});
  private static ESLVal processInts(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    {ESLVal ints = removeDups.apply(map.apply(pIntValue,map.apply(head,map.apply(armPatterns,arms))));
      
      {ESLVal armss = map.apply(new ESLVal(new Function(new ESLVal("fun448"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal c = $args[0];
        return intArms(c,arms);
          }
        }),ints);
      
      return new ESLVal("CaseInt",l,head.apply(es),new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal as = $l0.head();
            $l0 = $l0.tail();
            $v.add(new ESLVal("IArm",sharedInt(as),compileCase(l,tail.apply(es),new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal a = $l0.head();
            $l0 = $l0.tail();
            $v.add(dropPattern(a));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(as),alt)));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(armss),alt);
    }
    }
  }
  private static ESLVal processInts = new ESLVal(new Function(new ESLVal("processInts"),null) { public ESLVal apply(ESLVal... args) { return processInts(args[0],args[1],args[2],args[3]); }});
  private static ESLVal processStrs(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    {ESLVal strs = removeDups.apply(map.apply(pStrValue,map.apply(head,map.apply(armPatterns,arms))));
      
      {ESLVal armss = map.apply(new ESLVal(new Function(new ESLVal("fun449"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal c = $args[0];
        return strArms(c,arms);
          }
        }),strs);
      
      return new ESLVal("CaseStr",l,head.apply(es),new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal as = $l0.head();
            $l0 = $l0.tail();
            $v.add(new ESLVal("SArm",sharedStr(as),compileCase(l,tail.apply(es),new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal a = $l0.head();
            $l0 = $l0.tail();
            $v.add(dropPattern(a));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(as),alt)));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(armss),alt);
    }
    }
  }
  private static ESLVal processStrs = new ESLVal(new Function(new ESLVal("processStrs"),null) { public ESLVal apply(ESLVal... args) { return processStrs(args[0],args[1],args[2],args[3]); }});
  private static ESLVal processBools(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    {ESLVal bools = removeDups.apply(map.apply(pBoolValue,map.apply(head,map.apply(armPatterns,arms))));
      
      {ESLVal armss = map.apply(new ESLVal(new Function(new ESLVal("fun450"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal c = $args[0];
        return boolArms(c,arms);
          }
        }),bools);
      
      return new ESLVal("CaseBool",l,head.apply(es),new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal as = $l0.head();
            $l0 = $l0.tail();
            $v.add(new ESLVal("BoolArm",sharedBool(as),compileCase(l,tail.apply(es),new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal a = $l0.head();
            $l0 = $l0.tail();
            $v.add(dropPattern(a));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(as),alt)));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(armss),alt);
    }
    }
  }
  private static ESLVal processBools = new ESLVal(new Function(new ESLVal("processBools"),null) { public ESLVal apply(ESLVal... args) { return processBools(args[0],args[1],args[2],args[3]); }});
  private static ESLVal processSets(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    {ESLVal f = new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("setFail")),$nil,$null,alt);
      
      return new ESLVal("CaseSet",l,head.apply(es),new ESLVal("List",l,new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal a = $l0.head();
            $l0 = $l0.tail();
            $v.add(processSetArms(l,tail.apply(es),a));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(arms)),f);
    }
  }
  private static ESLVal processSets = new ESLVal(new Function(new ESLVal("processSets"),null) { public ESLVal apply(ESLVal... args) { return processSets(args[0],args[1],args[2],args[3]); }});
  private static ESLVal processNonDetLists(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    {print.apply(new ESLVal("process nondet lists ").add(es.add(new ESLVal(" ").add(arms))));
    {ESLVal f = new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("listFail")),$nil,$null,alt);
      
      return new ESLVal("CaseAdd",l,head.apply(es),new ESLVal("List",l,new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal a = $l0.head();
            $l0 = $l0.tail();
            $v.add(processNonDetListArms(l,tail.apply(es),a));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(arms)),f);
    }}
  }
  private static ESLVal processNonDetLists = new ESLVal(new Function(new ESLVal("processNonDetLists"),null) { public ESLVal apply(ESLVal... args) { return processNonDetLists(args[0],args[1],args[2],args[3]); }});
  private static ESLVal splitTerms(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    return compileCase(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun451"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPTerm(head.apply(armPatterns(a)));
        }
      }),arms),compileCase(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun452"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPTerm(head.apply(armPatterns(a)));
        }
      }),arms),alt));
  }
  private static ESLVal splitTerms = new ESLVal(new Function(new ESLVal("splitTerms"),null) { public ESLVal apply(ESLVal... args) { return splitTerms(args[0],args[1],args[2],args[3]); }});
  private static ESLVal splitLists(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    return compileCase(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun453"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPList(head.apply(armPatterns(a)));
        }
      }),arms),compileCase(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun454"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPList(head.apply(armPatterns(a)));
        }
      }),arms),alt));
  }
  private static ESLVal splitLists = new ESLVal(new Function(new ESLVal("splitLists"),null) { public ESLVal apply(ESLVal... args) { return splitLists(args[0],args[1],args[2],args[3]); }});
  private static ESLVal splitAdd(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    return compileCase(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun455"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPAdd(head.apply(armPatterns(a)));
        }
      }),arms),compileCase(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun456"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPAdd(head.apply(armPatterns(a)));
        }
      }),arms),alt));
  }
  private static ESLVal splitAdd = new ESLVal(new Function(new ESLVal("splitAdd"),null) { public ESLVal apply(ESLVal... args) { return splitAdd(args[0],args[1],args[2],args[3]); }});
  private static ESLVal splitSets(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    return compileCase(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun457"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPSet(head.apply(armPatterns(a)));
        }
      }),arms),compileCase(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun458"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPSet(head.apply(armPatterns(a)));
        }
      }),arms),alt));
  }
  private static ESLVal splitSets = new ESLVal(new Function(new ESLVal("splitSets"),null) { public ESLVal apply(ESLVal... args) { return splitSets(args[0],args[1],args[2],args[3]); }});
  private static ESLVal splitInts(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    return compileCase(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun459"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPInt(head.apply(armPatterns(a)));
        }
      }),arms),compileCase(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun460"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPInt(head.apply(armPatterns(a)));
        }
      }),arms),alt));
  }
  private static ESLVal splitInts = new ESLVal(new Function(new ESLVal("splitInts"),null) { public ESLVal apply(ESLVal... args) { return splitInts(args[0],args[1],args[2],args[3]); }});
  private static ESLVal splitStrs(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    return compileCase(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun461"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPStr(head.apply(armPatterns(a)));
        }
      }),arms),compileCase(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun462"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPStr(head.apply(armPatterns(a)));
        }
      }),arms),alt));
  }
  private static ESLVal splitStrs = new ESLVal(new Function(new ESLVal("splitStrs"),null) { public ESLVal apply(ESLVal... args) { return splitStrs(args[0],args[1],args[2],args[3]); }});
  private static ESLVal splitBools(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    return compileCase(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun463"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPBool(head.apply(armPatterns(a)));
        }
      }),arms),compileCase(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun464"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPBool(head.apply(armPatterns(a)));
        }
      }),arms),alt));
  }
  private static ESLVal splitBools = new ESLVal(new Function(new ESLVal("splitBools"),null) { public ESLVal apply(ESLVal... args) { return splitBools(args[0],args[1],args[2],args[3]); }});
  private static ESLVal splitVars(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    return compileCase(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun465"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPVar(head.apply(armPatterns(a)));
        }
      }),arms),compileCase(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun466"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal a = $args[0];
      return isPVar(head.apply(armPatterns(a)));
        }
      }),arms),alt));
  }
  private static ESLVal splitVars = new ESLVal(new Function(new ESLVal("splitVars"),null) { public ESLVal apply(ESLVal... args) { return splitVars(args[0],args[1],args[2],args[3]); }});
  private static ESLVal splitCase(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    {ESLVal firstPatterns = map.apply(head,map.apply(armPatterns,arms));
      
      {ESLVal nonVarPatterns = filter.apply(new ESLVal(new Function(new ESLVal("fun467"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal p = $args[0];
        return isPVar(p).not();
          }
        }),firstPatterns);
      
      if(isPTerm(head.apply(nonVarPatterns)).boolVal)
      return splitTerms(l,es,arms,alt);
      else
        if(isPList(head.apply(nonVarPatterns)).boolVal)
          return splitLists(l,es,arms,alt);
          else
            if(isPSet(head.apply(nonVarPatterns)).boolVal)
              return splitSets(l,es,arms,alt);
              else
                if(isPInt(head.apply(nonVarPatterns)).boolVal)
                  return splitInts(l,es,arms,alt);
                  else
                    if(isPStr(head.apply(nonVarPatterns)).boolVal)
                      return splitStrs(l,es,arms,alt);
                      else
                        if(isPBool(head.apply(nonVarPatterns)).boolVal)
                          return splitBools(l,es,arms,alt);
                          else
                            if(isPVar(head.apply(firstPatterns)).boolVal)
                              return splitVars(l,es,arms,alt);
                              else
                                if(isPAdd(head.apply(firstPatterns)).boolVal)
                                  return splitAdd(l,es,arms,alt);
                                  else
                                    return error(new ESLVal("unknown split case: ").add(arms));
    }
    }
  }
  private static ESLVal splitCase = new ESLVal(new Function(new ESLVal("splitCase"),null) { public ESLVal apply(ESLVal... args) { return splitCase(args[0],args[1],args[2],args[3]); }});
  private static ESLVal compileCase(ESLVal l,ESLVal es,ESLVal arms,ESLVal alt) {
    
    if(arms.eql($nil).boolVal)
      return alt;
      else
        if(isEmptyPatterns(arms).boolVal)
          return foldArms(l,arms,alt);
          else
            if(isFirstColumnVars(arms).boolVal)
              return compileCase(l,tail.apply(es),bindVars(head.apply(es),arms),alt);
              else
                if(isFirstColumnCnstrs(arms).boolVal)
                  return processCnstrs(l,es,arms,alt);
                  else
                    if(isFirstColumnLists(arms).boolVal)
                      return processLists(l,es,arms,alt);
                      else
                        if(isFirstColumnInts(arms).boolVal)
                          return processInts(l,es,arms,alt);
                          else
                            if(isFirstColumnBools(arms).boolVal)
                              return processBools(l,es,arms,alt);
                              else
                                if(isFirstColumnStrs(arms).boolVal)
                                  return processStrs(l,es,arms,alt);
                                  else
                                    if(isFirstColumnSets(arms).boolVal)
                                      return processSets(l,es,arms,alt);
                                      else
                                        if(isFirstColumnNonDetLists(arms).boolVal)
                                          return processNonDetLists(l,es,arms,alt);
                                          else
                                            return splitCase(l,es,arms,alt);
  }
  private static ESLVal compileCase = new ESLVal(new Function(new ESLVal("compileCase"),null) { public ESLVal apply(ESLVal... args) { return compileCase(args[0],args[1],args[2],args[3]); }});
  private static ESLVal foldArms(ESLVal l,ESLVal arms,ESLVal alt) {
    
    {ESLVal _v1911 = arms;
      
      if(_v1911.isCons())
      {ESLVal $3875 = _v1911.head();
        ESLVal $3876 = _v1911.tail();
        
        switch($3875.termName) {
        case "LArm": {ESLVal $3881 = $3875.termRef(0);
          ESLVal $3880 = $3875.termRef(1);
          ESLVal $3879 = $3875.termRef(2);
          ESLVal $3878 = $3875.termRef(3);
          ESLVal $3877 = $3875.termRef(4);
          
          if($3880.isCons())
          {ESLVal $3882 = $3880.head();
            ESLVal $3883 = $3880.tail();
            
            return error(new ESLVal("case error at Pos(27421,27577)").add(ESLVal.list(_v1911)));
          }
        else if($3880.isNil())
          {ESLVal al = $3881;
            
            {ESLVal bs = $3879;
            
            {ESLVal g = $3878;
            
            {ESLVal e = $3877;
            
            {ESLVal _v1922 = $3876;
            
            return foldArm(al,bs,g,e,foldArms(l,_v1922,alt));
          }
          }
          }
          }
          }
        else return error(new ESLVal("case error at Pos(27421,27577)").add(ESLVal.list(_v1911)));
        }
        default: return error(new ESLVal("case error at Pos(27421,27577)").add(ESLVal.list(_v1911)));
      }
      }
    else if(_v1911.isNil())
      return alt;
    else return error(new ESLVal("case error at Pos(27421,27577)").add(ESLVal.list(_v1911)));
    }
  }
  private static ESLVal foldArms = new ESLVal(new Function(new ESLVal("foldArms"),null) { public ESLVal apply(ESLVal... args) { return foldArms(args[0],args[1],args[2]); }});
  private static ESLVal foldArm(ESLVal l,ESLVal bss,ESLVal g,ESLVal e,ESLVal alt) {
    
    {ESLVal _v1912 = bss;
      
      if(_v1912.isCons())
      {ESLVal $3884 = _v1912.head();
        ESLVal $3885 = _v1912.tail();
        
        {ESLVal bs = $3884;
        
        {ESLVal _v1919 = $3885;
        
        return new ESLVal("Let",l,bs,foldArm(l,_v1919,g,e,alt));
      }
      }
      }
    else if(_v1912.isNil())
      {ESLVal _v1913 = g;
        
        switch(_v1913.termName) {
        case "BoolExp": {ESLVal $3887 = _v1913.termRef(0);
          ESLVal $3886 = _v1913.termRef(1);
          
          switch($3886.boolVal ? 1 : 0) {
          case 1: {ESLVal bl = $3887;
            
            return e;
          }
          default: {ESLVal _v1920 = _v1913;
            
            return new ESLVal("If",l,_v1920,e,alt);
          }
        }
        }
        default: {ESLVal _v1921 = _v1913;
          
          return new ESLVal("If",l,_v1921,e,alt);
        }
      }
      }
    else return error(new ESLVal("case error at Pos(27642,27842)").add(ESLVal.list(_v1912)));
    }
  }
  private static ESLVal foldArm = new ESLVal(new Function(new ESLVal("foldArm"),null) { public ESLVal apply(ESLVal... args) { return foldArm(args[0],args[1],args[2],args[3],args[4]); }});
  private static ESLVal translateQual(ESLVal q) {
    
    {ESLVal _v1914 = q;
      
      switch(_v1914.termName) {
      case "BQual": {ESLVal $3892 = _v1914.termRef(0);
        ESLVal $3891 = _v1914.termRef(1);
        ESLVal $3890 = _v1914.termRef(2);
        
        {ESLVal l = $3892;
        
        {ESLVal p = $3891;
        
        {ESLVal e = $3890;
        
        return new ESLVal("BQual",l,p,translateCases(e));
      }
      }
      }
      }
    case "PQual": {ESLVal $3889 = _v1914.termRef(0);
        ESLVal $3888 = _v1914.termRef(1);
        
        {ESLVal l = $3889;
        
        {ESLVal p = $3888;
        
        return new ESLVal("PQual",l,translateCases(p));
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(27894,28031)").add(ESLVal.list(_v1914)));
    }
    }
  }
  private static ESLVal translateQual = new ESLVal(new Function(new ESLVal("translateQual"),null) { public ESLVal apply(ESLVal... args) { return translateQual(args[0]); }});
  private static ESLVal translateArm(ESLVal a) {
    
    {ESLVal _v1915 = a;
      
      switch(_v1915.termName) {
      case "LArm": {ESLVal $3897 = _v1915.termRef(0);
        ESLVal $3896 = _v1915.termRef(1);
        ESLVal $3895 = _v1915.termRef(2);
        ESLVal $3894 = _v1915.termRef(3);
        ESLVal $3893 = _v1915.termRef(4);
        
        {ESLVal l = $3897;
        
        {ESLVal ps = $3896;
        
        {ESLVal bs = $3895;
        
        {ESLVal guard = $3894;
        
        {ESLVal e = $3893;
        
        return new ESLVal("LArm",l,ps,bs,translateCases(guard),translateCases(e));
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(28070,28203)").add(ESLVal.list(_v1915)));
    }
    }
  }
  private static ESLVal translateArm = new ESLVal(new Function(new ESLVal("translateArm"),null) { public ESLVal apply(ESLVal... args) { return translateArm(args[0]); }});
  private static ESLVal translateDef(ESLVal b) {
    
    {ESLVal _v1916 = b;
      
      switch(_v1916.termName) {
      case "Binding": {ESLVal $3921 = _v1916.termRef(0);
        ESLVal $3920 = _v1916.termRef(1);
        ESLVal $3919 = _v1916.termRef(2);
        ESLVal $3918 = _v1916.termRef(3);
        ESLVal $3917 = _v1916.termRef(4);
        
        {ESLVal l = $3921;
        
        {ESLVal name = $3920;
        
        {ESLVal t = $3919;
        
        {ESLVal st = $3918;
        
        {ESLVal value = $3917;
        
        return new ESLVal("Binding",l,name,t,st,translateCases(value));
      }
      }
      }
      }
      }
      }
    case "TypeBind": {ESLVal $3916 = _v1916.termRef(0);
        ESLVal $3915 = _v1916.termRef(1);
        ESLVal $3914 = _v1916.termRef(2);
        ESLVal $3913 = _v1916.termRef(3);
        
        {ESLVal l = $3916;
        
        {ESLVal name = $3915;
        
        {ESLVal t = $3914;
        
        {ESLVal ignore = $3913;
        
        return b;
      }
      }
      }
      }
      }
    case "DataBind": {ESLVal $3912 = _v1916.termRef(0);
        ESLVal $3911 = _v1916.termRef(1);
        ESLVal $3910 = _v1916.termRef(2);
        ESLVal $3909 = _v1916.termRef(3);
        
        {ESLVal l = $3912;
        
        {ESLVal name = $3911;
        
        {ESLVal t = $3910;
        
        {ESLVal ignore = $3909;
        
        return b;
      }
      }
      }
      }
      }
    case "FunBind": {ESLVal $3908 = _v1916.termRef(0);
        ESLVal $3907 = _v1916.termRef(1);
        ESLVal $3906 = _v1916.termRef(2);
        ESLVal $3905 = _v1916.termRef(3);
        ESLVal $3904 = _v1916.termRef(4);
        ESLVal $3903 = _v1916.termRef(5);
        ESLVal $3902 = _v1916.termRef(6);
        
        {ESLVal l = $3908;
        
        {ESLVal n = $3907;
        
        {ESLVal args = $3906;
        
        {ESLVal t = $3905;
        
        {ESLVal st = $3904;
        
        {ESLVal body = $3903;
        
        {ESLVal guard = $3902;
        
        return new ESLVal("FunBind",l,n,args,t,st,translateCases(body),translateCases(guard));
      }
      }
      }
      }
      }
      }
      }
      }
    case "CnstrBind": {ESLVal $3901 = _v1916.termRef(0);
        ESLVal $3900 = _v1916.termRef(1);
        ESLVal $3899 = _v1916.termRef(2);
        ESLVal $3898 = _v1916.termRef(3);
        
        {ESLVal l = $3901;
        
        {ESLVal name = $3900;
        
        {ESLVal t = $3899;
        
        {ESLVal ignore = $3898;
        
        return b;
      }
      }
      }
      }
      }
      default: {ESLVal x = _v1916;
        
        return error(x);
      }
    }
    }
  }
  private static ESLVal translateDef = new ESLVal(new Function(new ESLVal("translateDef"),null) { public ESLVal apply(ESLVal... args) { return translateDef(args[0]); }});
  private static ESLVal pterm(ESLVal n,ESLVal ps) {
    
    return new ESLVal("PTerm",loc0,n,$nil,ps);
  }
  private static ESLVal pterm = new ESLVal(new Function(new ESLVal("pterm"),null) { public ESLVal apply(ESLVal... args) { return pterm(args[0],args[1]); }});
  private static ESLVal pvar(ESLVal n) {
    
    return new ESLVal("PVar",loc0,n,voidType);
  }
  private static ESLVal pvar = new ESLVal(new Function(new ESLVal("pvar"),null) { public ESLVal apply(ESLVal... args) { return pvar(args[0]); }});
  private static ESLVal var(ESLVal n) {
    
    return new ESLVal("Var",loc0,n);
  }
  private static ESLVal var = new ESLVal(new Function(new ESLVal("var"),null) { public ESLVal apply(ESLVal... args) { return var(args[0]); }});
  private static ESLVal pcons(ESLVal h,ESLVal t) {
    
    return new ESLVal("PCons",loc0,h,t);
  }
  private static ESLVal pcons = new ESLVal(new Function(new ESLVal("pcons"),null) { public ESLVal apply(ESLVal... args) { return pcons(args[0],args[1]); }});
public static void main(String[] args) {
    newActor(main,new ESLVal(new Actor())); 
  }
}