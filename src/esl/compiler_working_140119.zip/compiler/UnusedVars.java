package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
// import static esl.Lists.*;
import static esl.compiler.Types.*;
import static esl.compiler.Warnings.*;
import static esl.Displays.*;
import static esl.compiler.FV.*;
import java.util.function.Supplier;
public class UnusedVars {
  public static ESLVal getSelf() { return $null; }
  
public static ESLVal checkUnusedVars(ESLVal module) {
    
    return walkAST(module);
  }
  public static ESLVal checkUnusedVars = new ESLVal(new Function(new ESLVal("checkUnusedVars"),null) { public ESLVal apply(ESLVal... args) { return checkUnusedVars(args[0]); }});
  private static ESLVal walkArm(ESLVal x) {
    
    {ESLVal _v1656 = x;
      
      switch(_v1656.termName) {
      case "BArm": {ESLVal $2594 = _v1656.termRef(0);
        ESLVal $2593 = _v1656.termRef(1);
        ESLVal $2592 = _v1656.termRef(2);
        ESLVal $2591 = _v1656.termRef(3);
        
        {ESLVal v0 = $2594;
        
        {ESLVal v1 = $2593;
        
        {ESLVal v2 = $2592;
        
        {ESLVal v3 = $2591;
        
        {{
        ESLVal _v1657 = v1;
        while(_v1657.isCons()) {
          ESLVal p = _v1657.headVal;
          walkPattern(p);
          _v1657 = _v1657.tailVal;}
      }
      walkAST(v2);
      return walkAST(v3);}
      }
      }
      }
      }
      }
    case "LArm": {ESLVal $2590 = _v1656.termRef(0);
        ESLVal $2589 = _v1656.termRef(1);
        ESLVal $2588 = _v1656.termRef(2);
        ESLVal $2587 = _v1656.termRef(3);
        ESLVal $2586 = _v1656.termRef(4);
        
        {ESLVal v0 = $2590;
        
        {ESLVal v1 = $2589;
        
        {ESLVal v2 = $2588;
        
        {ESLVal v3 = $2587;
        
        {ESLVal v4 = $2586;
        
        return $null;
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(1426,1640)").add(ESLVal.list(_v1656)));
    }
    }
  }
  private static ESLVal walkArm = new ESLVal(new Function(new ESLVal("walkArm"),null) { public ESLVal apply(ESLVal... args) { return walkArm(args[0]); }});
  private static ESLVal walkPattern(ESLVal x) {
    
    {ESLVal _v1658 = x;
      
      switch(_v1658.termName) {
      case "PAdd": {ESLVal $2626 = _v1658.termRef(0);
        ESLVal $2625 = _v1658.termRef(1);
        ESLVal $2624 = _v1658.termRef(2);
        
        {ESLVal v0 = $2626;
        
        {ESLVal v1 = $2625;
        
        {ESLVal v2 = $2624;
        
        {walkPattern(v1);
      return walkPattern(v2);}
      }
      }
      }
      }
    case "PApplyType": {ESLVal $2623 = _v1658.termRef(0);
        ESLVal $2622 = _v1658.termRef(1);
        ESLVal $2621 = _v1658.termRef(2);
        
        {ESLVal v0 = $2623;
        
        {ESLVal v1 = $2622;
        
        {ESLVal v2 = $2621;
        
        return walkPattern(v1);
      }
      }
      }
      }
    case "PBagCons": {ESLVal $2620 = _v1658.termRef(0);
        ESLVal $2619 = _v1658.termRef(1);
        ESLVal $2618 = _v1658.termRef(2);
        
        {ESLVal v0 = $2620;
        
        {ESLVal v1 = $2619;
        
        {ESLVal v2 = $2618;
        
        {walkPattern(v1);
      return walkPattern(v2);}
      }
      }
      }
      }
    case "PBool": {ESLVal $2617 = _v1658.termRef(0);
        ESLVal $2616 = _v1658.termRef(1);
        
        {ESLVal v0 = $2617;
        
        {ESLVal v1 = $2616;
        
        return $null;
      }
      }
      }
    case "PCons": {ESLVal $2615 = _v1658.termRef(0);
        ESLVal $2614 = _v1658.termRef(1);
        ESLVal $2613 = _v1658.termRef(2);
        
        {ESLVal v0 = $2615;
        
        {ESLVal v1 = $2614;
        
        {ESLVal v2 = $2613;
        
        {walkPattern(v1);
      return walkPattern(v2);}
      }
      }
      }
      }
    case "PEmptyBag": {ESLVal $2612 = _v1658.termRef(0);
        
        {ESLVal v0 = $2612;
        
        return $null;
      }
      }
    case "PEmptySet": {ESLVal $2611 = _v1658.termRef(0);
        
        {ESLVal v0 = $2611;
        
        return $null;
      }
      }
    case "PInt": {ESLVal $2610 = _v1658.termRef(0);
        ESLVal $2609 = _v1658.termRef(1);
        
        {ESLVal v0 = $2610;
        
        {ESLVal v1 = $2609;
        
        return $null;
      }
      }
      }
    case "PNil": {ESLVal $2608 = _v1658.termRef(0);
        
        {ESLVal v0 = $2608;
        
        return $null;
      }
      }
    case "PNull": {ESLVal $2607 = _v1658.termRef(0);
        
        {ESLVal v0 = $2607;
        
        return $null;
      }
      }
    case "PSetCons": {ESLVal $2606 = _v1658.termRef(0);
        ESLVal $2605 = _v1658.termRef(1);
        ESLVal $2604 = _v1658.termRef(2);
        
        {ESLVal v0 = $2606;
        
        {ESLVal v1 = $2605;
        
        {ESLVal v2 = $2604;
        
        {walkPattern(v1);
      return walkPattern(v2);}
      }
      }
      }
      }
    case "PStr": {ESLVal $2603 = _v1658.termRef(0);
        ESLVal $2602 = _v1658.termRef(1);
        
        {ESLVal v0 = $2603;
        
        {ESLVal v1 = $2602;
        
        return $null;
      }
      }
      }
    case "PTerm": {ESLVal $2601 = _v1658.termRef(0);
        ESLVal $2600 = _v1658.termRef(1);
        ESLVal $2599 = _v1658.termRef(2);
        ESLVal $2598 = _v1658.termRef(3);
        
        {ESLVal v0 = $2601;
        
        {ESLVal v1 = $2600;
        
        {ESLVal v2 = $2599;
        
        {ESLVal v3 = $2598;
        
        {{
        ESLVal _v1659 = v3;
        while(_v1659.isCons()) {
          ESLVal p = _v1659.headVal;
          walkPattern(p);
          _v1659 = _v1659.tailVal;}
      }
      return $null;}
      }
      }
      }
      }
      }
    case "PVar": {ESLVal $2597 = _v1658.termRef(0);
        ESLVal $2596 = _v1658.termRef(1);
        ESLVal $2595 = _v1658.termRef(2);
        
        {ESLVal v0 = $2597;
        
        {ESLVal v1 = $2596;
        
        {ESLVal v2 = $2595;
        
        return $null;
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(1684,2528)").add(ESLVal.list(_v1658)));
    }
    }
  }
  private static ESLVal walkPattern = new ESLVal(new Function(new ESLVal("walkPattern"),null) { public ESLVal apply(ESLVal... args) { return walkPattern(args[0]); }});
  private static ESLVal walkTDec(ESLVal d) {
    
    {ESLVal _v1660 = d;
      
      switch(_v1660.termName) {
      case "Dec": {ESLVal $2630 = _v1660.termRef(0);
        ESLVal $2629 = _v1660.termRef(1);
        ESLVal $2628 = _v1660.termRef(2);
        ESLVal $2627 = _v1660.termRef(3);
        
        {ESLVal v0 = $2630;
        
        {ESLVal v1 = $2629;
        
        {ESLVal v2 = $2628;
        
        {ESLVal v3 = $2627;
        
        return $null;
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(2560,2626)").add(ESLVal.list(_v1660)));
    }
    }
  }
  private static ESLVal walkTDec = new ESLVal(new Function(new ESLVal("walkTDec"),null) { public ESLVal apply(ESLVal... args) { return walkTDec(args[0]); }});
  private static ESLVal walkTBind(ESLVal b) {
    
    {ESLVal _v1661 = b;
      
      switch(_v1661.termName) {
      case "TypeBind": {ESLVal $2656 = _v1661.termRef(0);
        ESLVal $2655 = _v1661.termRef(1);
        ESLVal $2654 = _v1661.termRef(2);
        ESLVal $2653 = _v1661.termRef(3);
        
        {ESLVal v0 = $2656;
        
        {ESLVal v1 = $2655;
        
        {ESLVal v2 = $2654;
        
        {ESLVal v3 = $2653;
        
        return $null;
      }
      }
      }
      }
      }
    case "CnstrBind": {ESLVal $2652 = _v1661.termRef(0);
        ESLVal $2651 = _v1661.termRef(1);
        ESLVal $2650 = _v1661.termRef(2);
        ESLVal $2649 = _v1661.termRef(3);
        
        {ESLVal v0 = $2652;
        
        {ESLVal v1 = $2651;
        
        {ESLVal v2 = $2650;
        
        {ESLVal v3 = $2649;
        
        return $null;
      }
      }
      }
      }
      }
    case "FunBind": {ESLVal $2648 = _v1661.termRef(0);
        ESLVal $2647 = _v1661.termRef(1);
        ESLVal $2646 = _v1661.termRef(2);
        ESLVal $2645 = _v1661.termRef(3);
        ESLVal $2644 = _v1661.termRef(4);
        ESLVal $2643 = _v1661.termRef(5);
        ESLVal $2642 = _v1661.termRef(6);
        
        {ESLVal l = $2648;
        
        {ESLVal name = $2647;
        
        {ESLVal args = $2646;
        
        {ESLVal t = $2645;
        
        {ESLVal dt = $2644;
        
        {ESLVal body = $2643;
        
        {ESLVal guard = $2642;
        
        {{ESLVal usedNames = freeVars.apply(body).add(freeVars.apply(guard));
        
        {
        ESLVal _v1662 = args;
        while(_v1662.isCons()) {
          ESLVal arg = _v1662.headVal;
          {
            ESLVal _v1663 = patternNames.apply(arg);
            while(_v1663.isCons()) {
              ESLVal n = _v1663.headVal;
              if(member.apply(n,usedNames).not().boolVal)
                addWarning.apply(patternLoc.apply(arg),n.add(new ESLVal(" is not used in the function body.")));
                else
                  {}
              _v1663 = _v1663.tailVal;}
          }
          _v1662 = _v1662.tailVal;}
      }
      }
      walkAST(body);
      return walkAST(guard);}
      }
      }
      }
      }
      }
      }
      }
      }
    case "FunBinds": {ESLVal $2641 = _v1661.termRef(0);
        ESLVal $2640 = _v1661.termRef(1);
        
        {ESLVal v0 = $2641;
        
        {ESLVal v1 = $2640;
        
        return $null;
      }
      }
      }
    case "Binding": {ESLVal $2639 = _v1661.termRef(0);
        ESLVal $2638 = _v1661.termRef(1);
        ESLVal $2637 = _v1661.termRef(2);
        ESLVal $2636 = _v1661.termRef(3);
        ESLVal $2635 = _v1661.termRef(4);
        
        {ESLVal v0 = $2639;
        
        {ESLVal v1 = $2638;
        
        {ESLVal v2 = $2637;
        
        {ESLVal v3 = $2636;
        
        {ESLVal v4 = $2635;
        
        return walkAST(v4);
      }
      }
      }
      }
      }
      }
    case "DataBind": {ESLVal $2634 = _v1661.termRef(0);
        ESLVal $2633 = _v1661.termRef(1);
        ESLVal $2632 = _v1661.termRef(2);
        ESLVal $2631 = _v1661.termRef(3);
        
        {ESLVal v0 = $2634;
        
        {ESLVal v1 = $2633;
        
        {ESLVal v2 = $2632;
        
        {ESLVal v3 = $2631;
        
        return $null;
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(2661,3429)").add(ESLVal.list(_v1661)));
    }
    }
  }
  private static ESLVal walkTBind = new ESLVal(new Function(new ESLVal("walkTBind"),null) { public ESLVal apply(ESLVal... args) { return walkTBind(args[0]); }});
  private static ESLVal walkQualifier(ESLVal x) {
    
    {ESLVal _v1664 = x;
      
      switch(_v1664.termName) {
      case "BQual": {ESLVal $2661 = _v1664.termRef(0);
        ESLVal $2660 = _v1664.termRef(1);
        ESLVal $2659 = _v1664.termRef(2);
        
        {ESLVal v0 = $2661;
        
        {ESLVal v1 = $2660;
        
        {ESLVal v2 = $2659;
        
        {walkPattern(v1);
      return walkAST(v2);}
      }
      }
      }
      }
    case "PQual": {ESLVal $2658 = _v1664.termRef(0);
        ESLVal $2657 = _v1664.termRef(1);
        
        {ESLVal v0 = $2658;
        
        {ESLVal v1 = $2657;
        
        return walkAST(v1);
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(3478,3639)").add(ESLVal.list(_v1664)));
    }
    }
  }
  private static ESLVal walkQualifier = new ESLVal(new Function(new ESLVal("walkQualifier"),null) { public ESLVal apply(ESLVal... args) { return walkQualifier(args[0]); }});
  private static ESLVal walkDRef(ESLVal x) {
    
    {ESLVal _v1665 = x;
      
      switch(_v1665.termName) {
      case "VarDynamicRef": {ESLVal $2666 = _v1665.termRef(0);
        ESLVal $2665 = _v1665.termRef(1);
        
        {ESLVal v0 = $2666;
        
        {ESLVal v1 = $2665;
        
        return walkAST(v1);
      }
      }
      }
    case "ActorDynamicRef": {ESLVal $2664 = _v1665.termRef(0);
        ESLVal $2663 = _v1665.termRef(1);
        ESLVal $2662 = _v1665.termRef(2);
        
        {ESLVal v0 = $2664;
        
        {ESLVal v1 = $2663;
        
        {ESLVal v2 = $2662;
        
        return walkAST(v1);
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(3673,3797)").add(ESLVal.list(_v1665)));
    }
    }
  }
  private static ESLVal walkDRef = new ESLVal(new Function(new ESLVal("walkDRef"),null) { public ESLVal apply(ESLVal... args) { return walkDRef(args[0]); }});
  private static ESLVal walkAST(ESLVal x) {
    
    {ESLVal _v1666 = x;
      
      switch(_v1666.termName) {
      case "ActExp": {ESLVal $2811 = _v1666.termRef(0);
        ESLVal $2810 = _v1666.termRef(1);
        ESLVal $2809 = _v1666.termRef(2);
        ESLVal $2808 = _v1666.termRef(3);
        ESLVal $2807 = _v1666.termRef(4);
        ESLVal $2806 = _v1666.termRef(5);
        ESLVal $2805 = _v1666.termRef(6);
        ESLVal $2804 = _v1666.termRef(7);
        
        {ESLVal v0 = $2811;
        
        {ESLVal v1 = $2810;
        
        {ESLVal v2 = $2809;
        
        {ESLVal v3 = $2808;
        
        {ESLVal v4 = $2807;
        
        {ESLVal v5 = $2806;
        
        {ESLVal v6 = $2805;
        
        {ESLVal v7 = $2804;
        
        {{
        ESLVal _v1688 = v2;
        while(_v1688.isCons()) {
          ESLVal d = _v1688.headVal;
          walkTDec(d);
          _v1688 = _v1688.tailVal;}
      }
      {
        ESLVal _v1689 = v5;
        while(_v1689.isCons()) {
          ESLVal b = _v1689.headVal;
          walkTBind(b);
          _v1689 = _v1689.tailVal;}
      }
      walkAST(v6);
      {{
        ESLVal _v1690 = v7;
        while(_v1690.isCons()) {
          ESLVal a = _v1690.headVal;
          walkArm(a);
          _v1690 = _v1690.tailVal;}
      }
      return $null;}}
      }
      }
      }
      }
      }
      }
      }
      }
      }
    case "Apply": {ESLVal $2803 = _v1666.termRef(0);
        ESLVal $2802 = _v1666.termRef(1);
        ESLVal $2801 = _v1666.termRef(2);
        
        {ESLVal v0 = $2803;
        
        {ESLVal v1 = $2802;
        
        {ESLVal v2 = $2801;
        
        {walkAST(v1);
      {{
        ESLVal _v1687 = v2;
        while(_v1687.isCons()) {
          ESLVal e = _v1687.headVal;
          walkAST(e);
          _v1687 = _v1687.tailVal;}
      }
      return $null;}}
      }
      }
      }
      }
    case "ApplyTypeExp": {ESLVal $2800 = _v1666.termRef(0);
        ESLVal $2799 = _v1666.termRef(1);
        ESLVal $2798 = _v1666.termRef(2);
        
        {ESLVal v0 = $2800;
        
        {ESLVal v1 = $2799;
        
        {ESLVal v2 = $2798;
        
        return walkAST(v1);
      }
      }
      }
      }
    case "ArrayRef": {ESLVal $2797 = _v1666.termRef(0);
        ESLVal $2796 = _v1666.termRef(1);
        ESLVal $2795 = _v1666.termRef(2);
        
        {ESLVal v0 = $2797;
        
        {ESLVal v1 = $2796;
        
        {ESLVal v2 = $2795;
        
        {walkAST(v1);
      return walkAST(v2);}
      }
      }
      }
      }
    case "ArrayUpdate": {ESLVal $2794 = _v1666.termRef(0);
        ESLVal $2793 = _v1666.termRef(1);
        ESLVal $2792 = _v1666.termRef(2);
        ESLVal $2791 = _v1666.termRef(3);
        
        {ESLVal v0 = $2794;
        
        {ESLVal v1 = $2793;
        
        {ESLVal v2 = $2792;
        
        {ESLVal v3 = $2791;
        
        {walkAST(v1);
      walkAST(v2);
      return walkAST(v3);}
      }
      }
      }
      }
      }
    case "BagExp": {ESLVal $2790 = _v1666.termRef(0);
        ESLVal $2789 = _v1666.termRef(1);
        
        {ESLVal v0 = $2790;
        
        {ESLVal v1 = $2789;
        
        {{
        ESLVal _v1686 = v1;
        while(_v1686.isCons()) {
          ESLVal e = _v1686.headVal;
          walkAST(e);
          _v1686 = _v1686.tailVal;}
      }
      return $null;}
      }
      }
      }
    case "Become": {ESLVal $2788 = _v1666.termRef(0);
        ESLVal $2787 = _v1666.termRef(1);
        
        {ESLVal v0 = $2788;
        
        {ESLVal v1 = $2787;
        
        return walkAST(v1);
      }
      }
      }
    case "BinExp": {ESLVal $2786 = _v1666.termRef(0);
        ESLVal $2785 = _v1666.termRef(1);
        ESLVal $2784 = _v1666.termRef(2);
        ESLVal $2783 = _v1666.termRef(3);
        
        {ESLVal v0 = $2786;
        
        {ESLVal v1 = $2785;
        
        {ESLVal v2 = $2784;
        
        {ESLVal v3 = $2783;
        
        {walkAST(v1);
      return walkAST(v3);}
      }
      }
      }
      }
      }
    case "Block": {ESLVal $2782 = _v1666.termRef(0);
        ESLVal $2781 = _v1666.termRef(1);
        
        {ESLVal v0 = $2782;
        
        {ESLVal v1 = $2781;
        
        {{
        ESLVal _v1685 = v1;
        while(_v1685.isCons()) {
          ESLVal e = _v1685.headVal;
          walkAST(e);
          _v1685 = _v1685.tailVal;}
      }
      return $null;}
      }
      }
      }
    case "BoolExp": {ESLVal $2780 = _v1666.termRef(0);
        ESLVal $2779 = _v1666.termRef(1);
        
        {ESLVal v0 = $2780;
        
        {ESLVal v1 = $2779;
        
        return $null;
      }
      }
      }
    case "Case": {ESLVal $2778 = _v1666.termRef(0);
        ESLVal $2777 = _v1666.termRef(1);
        ESLVal $2776 = _v1666.termRef(2);
        ESLVal $2775 = _v1666.termRef(3);
        
        {ESLVal v0 = $2778;
        
        {ESLVal v1 = $2777;
        
        {ESLVal v2 = $2776;
        
        {ESLVal v3 = $2775;
        
        {{
        ESLVal _v1682 = v1;
        while(_v1682.isCons()) {
          ESLVal d = _v1682.headVal;
          walkTDec(d);
          _v1682 = _v1682.tailVal;}
      }
      {
        ESLVal _v1683 = v2;
        while(_v1683.isCons()) {
          ESLVal e = _v1683.headVal;
          walkAST(e);
          _v1683 = _v1683.tailVal;}
      }
      {{
        ESLVal _v1684 = v3;
        while(_v1684.isCons()) {
          ESLVal a = _v1684.headVal;
          walkArm(a);
          _v1684 = _v1684.tailVal;}
      }
      return $null;}}
      }
      }
      }
      }
      }
    case "Cmp": {ESLVal $2774 = _v1666.termRef(0);
        ESLVal $2773 = _v1666.termRef(1);
        ESLVal $2772 = _v1666.termRef(2);
        
        {ESLVal v0 = $2774;
        
        {ESLVal v1 = $2773;
        
        {ESLVal v2 = $2772;
        
        {walkAST(v1);
      {{
        ESLVal _v1681 = v2;
        while(_v1681.isCons()) {
          ESLVal q = _v1681.headVal;
          walkQualifier(q);
          _v1681 = _v1681.tailVal;}
      }
      return $null;}}
      }
      }
      }
      }
    case "Cons": {ESLVal $2771 = _v1666.termRef(0);
        ESLVal $2770 = _v1666.termRef(1);
        
        {ESLVal v0 = $2771;
        
        {ESLVal v1 = $2770;
        
        {walkAST(v0);
      return walkAST(v1);}
      }
      }
      }
    case "For": {ESLVal $2769 = _v1666.termRef(0);
        ESLVal $2768 = _v1666.termRef(1);
        ESLVal $2767 = _v1666.termRef(2);
        ESLVal $2766 = _v1666.termRef(3);
        
        {ESLVal v0 = $2769;
        
        {ESLVal v1 = $2768;
        
        {ESLVal v2 = $2767;
        
        {ESLVal v3 = $2766;
        
        {walkPattern(v1);
      walkAST(v2);
      return walkAST(v3);}
      }
      }
      }
      }
      }
    case "FunExp": {ESLVal $2765 = _v1666.termRef(0);
        ESLVal $2764 = _v1666.termRef(1);
        ESLVal $2763 = _v1666.termRef(2);
        ESLVal $2762 = _v1666.termRef(3);
        ESLVal $2761 = _v1666.termRef(4);
        
        {ESLVal l = $2765;
        
        {ESLVal name = $2764;
        
        {ESLVal args = $2763;
        
        {ESLVal t = $2762;
        
        {ESLVal body = $2761;
        
        {ESLVal usedNames = freeVars.apply(body);
        
        {{
        ESLVal _v1680 = args;
        while(_v1680.isCons()) {
          ESLVal d = _v1680.headVal;
          {if(member.apply(decName.apply(d),usedNames).not().boolVal)
            addWarning.apply(decLoc.apply(d),decName.apply(d).add(new ESLVal(" is not used in the function body.")));
            else
              {}
          walkTDec(d);}
          _v1680 = _v1680.tailVal;}
      }
      walkAST(name);
      return walkAST(body);}
      }
      }
      }
      }
      }
      }
      }
    case "Grab": {ESLVal $2760 = _v1666.termRef(0);
        ESLVal $2759 = _v1666.termRef(1);
        ESLVal $2758 = _v1666.termRef(2);
        
        {ESLVal v0 = $2760;
        
        {ESLVal v1 = $2759;
        
        {ESLVal v2 = $2758;
        
        {{
        ESLVal _v1679 = v1;
        while(_v1679.isCons()) {
          ESLVal d = _v1679.headVal;
          walkDRef(d);
          _v1679 = _v1679.tailVal;}
      }
      return walkAST(v2);}
      }
      }
      }
      }
    case "If": {ESLVal $2757 = _v1666.termRef(0);
        ESLVal $2756 = _v1666.termRef(1);
        ESLVal $2755 = _v1666.termRef(2);
        ESLVal $2754 = _v1666.termRef(3);
        
        {ESLVal v0 = $2757;
        
        {ESLVal v1 = $2756;
        
        {ESLVal v2 = $2755;
        
        {ESLVal v3 = $2754;
        
        {walkAST(v1);
      walkAST(v2);
      return walkAST(v3);}
      }
      }
      }
      }
      }
    case "IntExp": {ESLVal $2753 = _v1666.termRef(0);
        ESLVal $2752 = _v1666.termRef(1);
        
        {ESLVal v0 = $2753;
        
        {ESLVal v1 = $2752;
        
        return $null;
      }
      }
      }
    case "FloatExp": {ESLVal $2751 = _v1666.termRef(0);
        ESLVal $2750 = _v1666.termRef(1);
        
        {ESLVal v0 = $2751;
        
        {ESLVal v1 = $2750;
        
        return $null;
      }
      }
      }
    case "Fold": {ESLVal $2749 = _v1666.termRef(0);
        ESLVal $2748 = _v1666.termRef(1);
        ESLVal $2747 = _v1666.termRef(2);
        
        {ESLVal v0 = $2749;
        
        {ESLVal v1 = $2748;
        
        {ESLVal v2 = $2747;
        
        return walkAST(v2);
      }
      }
      }
      }
    case "Head": {ESLVal $2746 = _v1666.termRef(0);
        
        {ESLVal v0 = $2746;
        
        return walkAST(v0);
      }
      }
    case "Let": {ESLVal $2745 = _v1666.termRef(0);
        ESLVal $2744 = _v1666.termRef(1);
        ESLVal $2743 = _v1666.termRef(2);
        
        {ESLVal l = $2745;
        
        {ESLVal bindings = $2744;
        
        {ESLVal body = $2743;
        
        {ESLVal usedNames = freeVars.apply(body);
        
        {{
        ESLVal _v1678 = bindings;
        while(_v1678.isCons()) {
          ESLVal b = _v1678.headVal;
          {if(member.apply(bindingName.apply(b),usedNames).not().boolVal)
            addWarning.apply(bindingLoc.apply(b),bindingName.apply(b).add(new ESLVal(" is not used in the let body.")));
            else
              {}
          walkTBind(b);}
          _v1678 = _v1678.tailVal;}
      }
      return walkAST(body);}
      }
      }
      }
      }
      }
    case "Letrec": {ESLVal $2742 = _v1666.termRef(0);
        ESLVal $2741 = _v1666.termRef(1);
        ESLVal $2740 = _v1666.termRef(2);
        
        {ESLVal l = $2742;
        
        {ESLVal bindings = $2741;
        
        {ESLVal body = $2740;
        
        {ESLVal usedNames = freeVars.apply(body).add(new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal b = $l0.head();
                $l0 = $l0.tail();
                ESLVal $l1 = bindingFV.apply(b);
          while(!$l1.isNil()) {
            ESLVal n = $l1.head();
            $l1 = $l1.tail();
            $v.add(n);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(bindings));
        
        {{
        ESLVal _v1677 = bindings;
        while(_v1677.isCons()) {
          ESLVal b = _v1677.headVal;
          {if(member.apply(bindingName.apply(b),usedNames).not().boolVal)
            addWarning.apply(bindingLoc.apply(b),bindingName.apply(b).add(new ESLVal(" is not used in the letrec body.")));
            else
              {}
          walkTBind(b);}
          _v1677 = _v1677.tailVal;}
      }
      return walkAST(body);}
      }
      }
      }
      }
      }
    case "List": {ESLVal $2739 = _v1666.termRef(0);
        ESLVal $2738 = _v1666.termRef(1);
        
        {ESLVal v0 = $2739;
        
        {ESLVal v1 = $2738;
        
        {{
        ESLVal _v1676 = v1;
        while(_v1676.isCons()) {
          ESLVal e = _v1676.headVal;
          walkAST(e);
          _v1676 = _v1676.tailVal;}
      }
      return $null;}
      }
      }
      }
    case "Module": {ESLVal $2737 = _v1666.termRef(0);
        ESLVal $2736 = _v1666.termRef(1);
        ESLVal $2735 = _v1666.termRef(2);
        ESLVal $2734 = _v1666.termRef(3);
        ESLVal $2733 = _v1666.termRef(4);
        ESLVal $2732 = _v1666.termRef(5);
        ESLVal $2731 = _v1666.termRef(6);
        
        {ESLVal path = $2737;
        
        {ESLVal name = $2736;
        
        {ESLVal exports = $2735;
        
        {ESLVal imports = $2734;
        
        {ESLVal v4 = $2733;
        
        {ESLVal v5 = $2732;
        
        {ESLVal defs = $2731;
        
        {ESLVal usedNames = new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal b = $l0.head();
                $l0 = $l0.tail();
                ESLVal $l1 = bindingFV.apply(b);
          while(!$l1.isNil()) {
            ESLVal n = $l1.head();
            $l1 = $l1.tail();
            $v.add(n);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(defs).add(exports);
        
        {{
        ESLVal _v1674 = defs;
        while(_v1674.isCons()) {
          ESLVal b = _v1674.headVal;
          if(isBinding.apply(b).or(isFunBind.apply(b)).boolVal)
            if(member.apply(bindingName.apply(b),usedNames).not().boolVal)
              addWarning.apply(bindingLoc.apply(b),bindingName.apply(b).add(new ESLVal(" is not used or exported.")));
              else
                {}
            else
              {}
          _v1674 = _v1674.tailVal;}
      }
      {{
        ESLVal _v1675 = defs;
        while(_v1675.isCons()) {
          ESLVal b = _v1675.headVal;
          walkTBind(b);
          _v1675 = _v1675.tailVal;}
      }
      return $null;}}
      }
      }
      }
      }
      }
      }
      }
      }
      }
    case "New": {ESLVal $2730 = _v1666.termRef(0);
        ESLVal $2729 = _v1666.termRef(1);
        ESLVal $2728 = _v1666.termRef(2);
        
        {ESLVal v0 = $2730;
        
        {ESLVal v1 = $2729;
        
        {ESLVal v2 = $2728;
        
        {walkAST(v1);
      {{
        ESLVal _v1673 = v2;
        while(_v1673.isCons()) {
          ESLVal e = _v1673.headVal;
          walkAST(e);
          _v1673 = _v1673.tailVal;}
      }
      return $null;}}
      }
      }
      }
      }
    case "NewArray": {ESLVal $2727 = _v1666.termRef(0);
        ESLVal $2726 = _v1666.termRef(1);
        ESLVal $2725 = _v1666.termRef(2);
        
        {ESLVal v0 = $2727;
        
        {ESLVal v1 = $2726;
        
        {ESLVal v2 = $2725;
        
        return walkAST(v2);
      }
      }
      }
      }
    case "NewJava": {ESLVal $2724 = _v1666.termRef(0);
        ESLVal $2723 = _v1666.termRef(1);
        ESLVal $2722 = _v1666.termRef(2);
        ESLVal $2721 = _v1666.termRef(3);
        
        {ESLVal v0 = $2724;
        
        {ESLVal v1 = $2723;
        
        {ESLVal v2 = $2722;
        
        {ESLVal v3 = $2721;
        
        {{
        ESLVal _v1672 = v3;
        while(_v1672.isCons()) {
          ESLVal e = _v1672.headVal;
          walkAST(e);
          _v1672 = _v1672.tailVal;}
      }
      return $null;}
      }
      }
      }
      }
      }
    case "NewTable": {ESLVal $2720 = _v1666.termRef(0);
        ESLVal $2719 = _v1666.termRef(1);
        ESLVal $2718 = _v1666.termRef(2);
        
        {ESLVal v0 = $2720;
        
        {ESLVal v1 = $2719;
        
        {ESLVal v2 = $2718;
        
        return $null;
      }
      }
      }
      }
    case "Not": {ESLVal $2717 = _v1666.termRef(0);
        ESLVal $2716 = _v1666.termRef(1);
        
        {ESLVal v0 = $2717;
        
        {ESLVal v1 = $2716;
        
        return walkAST(v1);
      }
      }
      }
    case "Now": {ESLVal $2715 = _v1666.termRef(0);
        
        {ESLVal v0 = $2715;
        
        return $null;
      }
      }
    case "NullExp": {ESLVal $2714 = _v1666.termRef(0);
        
        {ESLVal v0 = $2714;
        
        return $null;
      }
      }
    case "PLet": {ESLVal $2713 = _v1666.termRef(0);
        ESLVal $2712 = _v1666.termRef(1);
        ESLVal $2711 = _v1666.termRef(2);
        
        {ESLVal v0 = $2713;
        
        {ESLVal v1 = $2712;
        
        {ESLVal v2 = $2711;
        
        {{
        ESLVal _v1671 = v1;
        while(_v1671.isCons()) {
          ESLVal b = _v1671.headVal;
          walkTBind(b);
          _v1671 = _v1671.tailVal;}
      }
      return walkAST(v2);}
      }
      }
      }
      }
    case "Probably": {ESLVal $2710 = _v1666.termRef(0);
        ESLVal $2709 = _v1666.termRef(1);
        ESLVal $2708 = _v1666.termRef(2);
        ESLVal $2707 = _v1666.termRef(3);
        ESLVal $2706 = _v1666.termRef(4);
        
        {ESLVal v0 = $2710;
        
        {ESLVal v1 = $2709;
        
        {ESLVal v2 = $2708;
        
        {ESLVal v3 = $2707;
        
        {ESLVal v4 = $2706;
        
        {walkAST(v1);
      walkAST(v3);
      return walkAST(v4);}
      }
      }
      }
      }
      }
      }
    case "Record": {ESLVal $2705 = _v1666.termRef(0);
        ESLVal $2704 = _v1666.termRef(1);
        
        {ESLVal v0 = $2705;
        
        {ESLVal v1 = $2704;
        
        {{
        ESLVal _v1670 = v1;
        while(_v1670.isCons()) {
          ESLVal b = _v1670.headVal;
          walkTBind(b);
          _v1670 = _v1670.tailVal;}
      }
      return $null;}
      }
      }
      }
    case "RefSuper": {ESLVal $2703 = _v1666.termRef(0);
        ESLVal $2702 = _v1666.termRef(1);
        
        {ESLVal v0 = $2703;
        
        {ESLVal v1 = $2702;
        
        return $null;
      }
      }
      }
    case "Ref": {ESLVal $2701 = _v1666.termRef(0);
        ESLVal $2700 = _v1666.termRef(1);
        ESLVal $2699 = _v1666.termRef(2);
        
        {ESLVal v0 = $2701;
        
        {ESLVal v1 = $2700;
        
        {ESLVal v2 = $2699;
        
        return walkAST(v1);
      }
      }
      }
      }
    case "Self": {ESLVal $2698 = _v1666.termRef(0);
        
        {ESLVal v0 = $2698;
        
        return $null;
      }
      }
    case "Send": {ESLVal $2697 = _v1666.termRef(0);
        ESLVal $2696 = _v1666.termRef(1);
        ESLVal $2695 = _v1666.termRef(2);
        
        {ESLVal v0 = $2697;
        
        {ESLVal v1 = $2696;
        
        {ESLVal v2 = $2695;
        
        {walkAST(v1);
      return walkAST(v2);}
      }
      }
      }
      }
    case "SendSuper": {ESLVal $2694 = _v1666.termRef(0);
        ESLVal $2693 = _v1666.termRef(1);
        
        {ESLVal v0 = $2694;
        
        {ESLVal v1 = $2693;
        
        return walkAST(v1);
      }
      }
      }
    case "SendTimeSuper": {ESLVal $2692 = _v1666.termRef(0);
        
        {ESLVal v0 = $2692;
        
        return $null;
      }
      }
    case "SetExp": {ESLVal $2691 = _v1666.termRef(0);
        ESLVal $2690 = _v1666.termRef(1);
        
        {ESLVal v0 = $2691;
        
        {ESLVal v1 = $2690;
        
        {{
        ESLVal _v1669 = v1;
        while(_v1669.isCons()) {
          ESLVal e = _v1669.headVal;
          walkAST(e);
          _v1669 = _v1669.tailVal;}
      }
      return $null;}
      }
      }
      }
    case "StrExp": {ESLVal $2689 = _v1666.termRef(0);
        ESLVal $2688 = _v1666.termRef(1);
        
        {ESLVal v0 = $2689;
        
        {ESLVal v1 = $2688;
        
        return $null;
      }
      }
      }
    case "Tail": {ESLVal $2687 = _v1666.termRef(0);
        
        {ESLVal v0 = $2687;
        
        return walkAST(v0);
      }
      }
    case "Term": {ESLVal $2686 = _v1666.termRef(0);
        ESLVal $2685 = _v1666.termRef(1);
        ESLVal $2684 = _v1666.termRef(2);
        ESLVal $2683 = _v1666.termRef(3);
        
        {ESLVal v0 = $2686;
        
        {ESLVal v1 = $2685;
        
        {ESLVal v2 = $2684;
        
        {ESLVal v3 = $2683;
        
        {{
        ESLVal _v1668 = v3;
        while(_v1668.isCons()) {
          ESLVal termArg = _v1668.headVal;
          walkAST(termArg);
          _v1668 = _v1668.tailVal;}
      }
      return $null;}
      }
      }
      }
      }
      }
    case "TermRef": {ESLVal $2682 = _v1666.termRef(0);
        ESLVal $2681 = _v1666.termRef(1);
        
        {ESLVal v0 = $2682;
        
        {ESLVal v1 = $2681;
        
        return walkAST(v0);
      }
      }
      }
    case "Throw": {ESLVal $2680 = _v1666.termRef(0);
        ESLVal $2679 = _v1666.termRef(1);
        ESLVal $2678 = _v1666.termRef(2);
        
        {ESLVal v0 = $2680;
        
        {ESLVal v1 = $2679;
        
        {ESLVal v2 = $2678;
        
        return walkAST(v2);
      }
      }
      }
      }
    case "Try": {ESLVal $2677 = _v1666.termRef(0);
        ESLVal $2676 = _v1666.termRef(1);
        ESLVal $2675 = _v1666.termRef(2);
        
        {ESLVal v0 = $2677;
        
        {ESLVal v1 = $2676;
        
        {ESLVal v2 = $2675;
        
        {walkAST(v1);
      {{
        ESLVal _v1667 = v2;
        while(_v1667.isCons()) {
          ESLVal a = _v1667.headVal;
          walkArm(a);
          _v1667 = _v1667.tailVal;}
      }
      return $null;}}
      }
      }
      }
      }
    case "Update": {ESLVal $2674 = _v1666.termRef(0);
        ESLVal $2673 = _v1666.termRef(1);
        ESLVal $2672 = _v1666.termRef(2);
        
        {ESLVal v0 = $2674;
        
        {ESLVal v1 = $2673;
        
        {ESLVal v2 = $2672;
        
        return walkAST(v2);
      }
      }
      }
      }
    case "Unfold": {ESLVal $2671 = _v1666.termRef(0);
        ESLVal $2670 = _v1666.termRef(1);
        ESLVal $2669 = _v1666.termRef(2);
        
        {ESLVal v0 = $2671;
        
        {ESLVal v1 = $2670;
        
        {ESLVal v2 = $2669;
        
        return walkAST(v2);
      }
      }
      }
      }
    case "Var": {ESLVal $2668 = _v1666.termRef(0);
        ESLVal $2667 = _v1666.termRef(1);
        
        {ESLVal v0 = $2668;
        
        {ESLVal v1 = $2667;
        
        return $null;
      }
      }
      }
      default: {ESLVal _v1691 = _v1666;
        
        return print.apply(new ESLVal("unknown expression: ").add(_v1691));
      }
    }
    }
  }
  private static ESLVal walkAST = new ESLVal(new Function(new ESLVal("walkAST"),null) { public ESLVal apply(ESLVal... args) { return walkAST(args[0]); }});
public static void main(String[] args) {
  }
}