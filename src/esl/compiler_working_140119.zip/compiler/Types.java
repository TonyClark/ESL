package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
// import static esl.Lists.*;
import java.util.function.Supplier;
public class Types {
  public static ESLVal getSelf() { return $null; }
  public static ESLVal theTypeBool = new ESLVal("BoolType",new ESLVal("Pos",$zero,$zero));
  public static ESLVal theTypeInt = new ESLVal("IntType",new ESLVal("Pos",$zero,$zero));
  public static ESLVal theTypeFloat = new ESLVal("FloatType",new ESLVal("Pos",$zero,$zero));
  public static ESLVal theTypeNull = new ESLVal("NullType",new ESLVal("Pos",$zero,$zero));
  public static ESLVal theTypeStr = new ESLVal("StrType",new ESLVal("Pos",$zero,$zero));
  public static ESLVal theTypeVoid = new ESLVal("VoidType",new ESLVal("Pos",$zero,$zero));
public static ESLVal locStart(ESLVal l) {
    
    {ESLVal _v206 = l;
      
      switch(_v206.termName) {
      case "Pos": {ESLVal $603 = _v206.termRef(0);
        ESLVal $602 = _v206.termRef(1);
        
        {ESLVal start = $603;
        
        {ESLVal end = $602;
        
        return start;
      }
      }
      }
    case "TypedLoc": {ESLVal $601 = _v206.termRef(0);
        ESLVal $600 = _v206.termRef(1);
        ESLVal $599 = _v206.termRef(2);
        
        {ESLVal t = $601;
        
        {ESLVal start = $600;
        
        {ESLVal end = $599;
        
        return start;
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(6013,6097)").add(ESLVal.list(_v206)));
    }
    }
  }
  public static ESLVal locStart = new ESLVal(new Function(new ESLVal("locStart"),null) { public ESLVal apply(ESLVal... args) { return locStart(args[0]); }});
  public static ESLVal locEnd(ESLVal l) {
    
    {ESLVal _v207 = l;
      
      switch(_v207.termName) {
      case "Pos": {ESLVal $608 = _v207.termRef(0);
        ESLVal $607 = _v207.termRef(1);
        
        {ESLVal start = $608;
        
        {ESLVal end = $607;
        
        return end;
      }
      }
      }
    case "TypedLoc": {ESLVal $606 = _v207.termRef(0);
        ESLVal $605 = _v207.termRef(1);
        ESLVal $604 = _v207.termRef(2);
        
        {ESLVal t = $606;
        
        {ESLVal start = $605;
        
        {ESLVal end = $604;
        
        return end;
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(6124,6204)").add(ESLVal.list(_v207)));
    }
    }
  }
  public static ESLVal locEnd = new ESLVal(new Function(new ESLVal("locEnd"),null) { public ESLVal apply(ESLVal... args) { return locEnd(args[0]); }});
  public static ESLVal decName(ESLVal d) {
    
    {ESLVal _v208 = d;
      
      switch(_v208.termName) {
      case "Dec": {ESLVal $612 = _v208.termRef(0);
        ESLVal $611 = _v208.termRef(1);
        ESLVal $610 = _v208.termRef(2);
        ESLVal $609 = _v208.termRef(3);
        
        {ESLVal l = $612;
        
        {ESLVal n = $611;
        
        {ESLVal t = $610;
        
        {ESLVal dt = $609;
        
        return n;
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(6526,6648)").add(ESLVal.list(_v208)));
    }
    }
  }
  public static ESLVal decName = new ESLVal(new Function(new ESLVal("decName"),null) { public ESLVal apply(ESLVal... args) { return decName(args[0]); }});
  public static ESLVal decLoc(ESLVal d) {
    
    {ESLVal _v209 = d;
      
      switch(_v209.termName) {
      case "Dec": {ESLVal $616 = _v209.termRef(0);
        ESLVal $615 = _v209.termRef(1);
        ESLVal $614 = _v209.termRef(2);
        ESLVal $613 = _v209.termRef(3);
        
        {ESLVal l = $616;
        
        {ESLVal n = $615;
        
        {ESLVal t = $614;
        
        {ESLVal dt = $613;
        
        return l;
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(6752,6810)").add(ESLVal.list(_v209)));
    }
    }
  }
  public static ESLVal decLoc = new ESLVal(new Function(new ESLVal("decLoc"),null) { public ESLVal apply(ESLVal... args) { return decLoc(args[0]); }});
  public static ESLVal decType(ESLVal d) {
    
    {ESLVal _v210 = d;
      
      switch(_v210.termName) {
      case "Dec": {ESLVal $620 = _v210.termRef(0);
        ESLVal $619 = _v210.termRef(1);
        ESLVal $618 = _v210.termRef(2);
        ESLVal $617 = _v210.termRef(3);
        
        {ESLVal l = $620;
        
        {ESLVal n = $619;
        
        {ESLVal t = $618;
        
        {ESLVal dt = $617;
        
        return t;
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(6910,6968)").add(ESLVal.list(_v210)));
    }
    }
  }
  public static ESLVal decType = new ESLVal(new Function(new ESLVal("decType"),null) { public ESLVal apply(ESLVal... args) { return decType(args[0]); }});
  public static ESLVal isStrType(ESLVal t) {
    
    {ESLVal _v211 = t;
      
      switch(_v211.termName) {
      case "StrType": {ESLVal $621 = _v211.termRef(0);
        
        {ESLVal l = $621;
        
        return $true;
      }
      }
      default: {ESLVal _v1009 = _v211;
        
        return $false;
      }
    }
    }
  }
  public static ESLVal isStrType = new ESLVal(new Function(new ESLVal("isStrType"),null) { public ESLVal apply(ESLVal... args) { return isStrType(args[0]); }});
  public static ESLVal isIntType(ESLVal t) {
    
    {ESLVal _v212 = t;
      
      switch(_v212.termName) {
      case "IntType": {ESLVal $622 = _v212.termRef(0);
        
        {ESLVal l = $622;
        
        return $true;
      }
      }
      default: {ESLVal _v1008 = _v212;
        
        return $false;
      }
    }
    }
  }
  public static ESLVal isIntType = new ESLVal(new Function(new ESLVal("isIntType"),null) { public ESLVal apply(ESLVal... args) { return isIntType(args[0]); }});
  public static ESLVal isNumType(ESLVal t) {
    
    {ESLVal _v213 = t;
      
      switch(_v213.termName) {
      case "IntType": {ESLVal $624 = _v213.termRef(0);
        
        {ESLVal l = $624;
        
        return $true;
      }
      }
    case "FloatType": {ESLVal $623 = _v213.termRef(0);
        
        {ESLVal l = $623;
        
        return $true;
      }
      }
      default: {ESLVal _v1007 = _v213;
        
        return $false;
      }
    }
    }
  }
  public static ESLVal isNumType = new ESLVal(new Function(new ESLVal("isNumType"),null) { public ESLVal apply(ESLVal... args) { return isNumType(args[0]); }});
  public static ESLVal isBoolType(ESLVal t) {
    
    {ESLVal _v214 = t;
      
      switch(_v214.termName) {
      case "BoolType": {ESLVal $625 = _v214.termRef(0);
        
        {ESLVal l = $625;
        
        return $true;
      }
      }
      default: {ESLVal _v1006 = _v214;
        
        return $false;
      }
    }
    }
  }
  public static ESLVal isBoolType = new ESLVal(new Function(new ESLVal("isBoolType"),null) { public ESLVal apply(ESLVal... args) { return isBoolType(args[0]); }});
  public static ESLVal isFloatType(ESLVal t) {
    
    {ESLVal _v215 = t;
      
      switch(_v215.termName) {
      case "FloatType": {ESLVal $626 = _v215.termRef(0);
        
        {ESLVal l = $626;
        
        return $true;
      }
      }
      default: {ESLVal _v1005 = _v215;
        
        return $false;
      }
    }
    }
  }
  public static ESLVal isFloatType = new ESLVal(new Function(new ESLVal("isFloatType"),null) { public ESLVal apply(ESLVal... args) { return isFloatType(args[0]); }});
  public static ESLVal typeEqual(ESLVal t1,ESLVal t2) {
    
    {ESLVal b = typeEqual1(t1,t2);
      
      return b;
    }
  }
  public static ESLVal typeEqual = new ESLVal(new Function(new ESLVal("typeEqual"),null) { public ESLVal apply(ESLVal... args) { return typeEqual(args[0],args[1]); }});
  public static ESLVal typeEqual1(ESLVal t1,ESLVal t2) {
    
    if(t1.eql(t2).boolVal)
      return $true;
      else
        {ESLVal _v216 = t1;
          ESLVal _v217 = t2;
          
          switch(_v216.termName) {
          case "ArrayType": {ESLVal $796 = _v216.termRef(0);
            ESLVal $795 = _v216.termRef(1);
            
            switch(_v217.termName) {
            case "ArrayType": {ESLVal $798 = _v217.termRef(0);
              ESLVal $797 = _v217.termRef(1);
              
              {ESLVal l1 = $796;
              
              {ESLVal _v969 = $795;
              
              {ESLVal l2 = $798;
              
              {ESLVal _v970 = $797;
              
              return typeEqual(_v969,_v970);
            }
            }
            }
            }
            }
            default: switch(_v217.termName) {
              case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                ESLVal $653 = _v217.termRef(1);
                ESLVal $652 = _v217.termRef(2);
                
                {ESLVal _v985 = _v216;
                
                {ESLVal l = $654;
                
                {ESLVal op = $653;
                
                {ESLVal args = $652;
                
                return typeEqual(_v985,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                ESLVal $650 = _v217.termRef(1);
                ESLVal $649 = _v217.termRef(2);
                ESLVal $648 = _v217.termRef(3);
                
                {ESLVal _v983 = _v216;
                
                {ESLVal l2 = $651;
                
                {ESLVal _v984 = $650;
                
                {ESLVal ds2 = $649;
                
                {ESLVal ms2 = $648;
                
                return typeEqual(_v983,flattenAct(l2,_v984,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $647 = _v217.termRef(0);
                
                {ESLVal t = _v216;
                
                {ESLVal l1 = $647;
                
                return $true;
              }
              }
              }
            case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                ESLVal $643 = _v217.termRef(1);
                ESLVal $642 = _v217.termRef(2);
                
                switch($642.termName) {
                case "UnionType": {ESLVal $646 = $642.termRef(0);
                  ESLVal $645 = $642.termRef(1);
                  
                  {ESLVal _v980 = _v216;
                  
                  {ESLVal l = $644;
                  
                  {ESLVal state = $643;
                  
                  {ESLVal ul = $646;
                  
                  {ESLVal terms = $645;
                  
                  return typeEqual(_v980,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v981 = _v216;
                  
                  {ESLVal _v982 = _v217;
                  
                  return $false;
                }
                }
              }
              }
            case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                ESLVal $638 = _v217.termRef(1);
                ESLVal $637 = _v217.termRef(2);
                
                switch($637.termName) {
                case "UnionType": {ESLVal $641 = $637.termRef(0);
                  ESLVal $640 = $637.termRef(1);
                  
                  {ESLVal _v977 = _v216;
                  
                  {ESLVal l = $639;
                  
                  {ESLVal state = $638;
                  
                  {ESLVal ul = $641;
                  
                  {ESLVal terms = $640;
                  
                  return typeEqual(_v977,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v978 = _v216;
                  
                  {ESLVal _v979 = _v217;
                  
                  return $false;
                }
                }
              }
              }
            case "TermType": {ESLVal $636 = _v217.termRef(0);
                ESLVal $635 = _v217.termRef(1);
                ESLVal $634 = _v217.termRef(2);
                
                {ESLVal _v976 = _v216;
                
                {ESLVal l2 = $636;
                
                {ESLVal n2 = $635;
                
                {ESLVal args2 = $634;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                
                {ESLVal _v975 = _v216;
                
                {ESLVal f = $633;
                
                return typeEqual(_v975,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $632 = _v217.termRef(0);
                ESLVal $631 = _v217.termRef(1);
                ESLVal $630 = _v217.termRef(2);
                
                {ESLVal _v973 = _v216;
                
                {ESLVal l2 = $632;
                
                {ESLVal n2 = $631;
                
                {ESLVal _v974 = $630;
                
                return typeEqual(_v973,substType(new ESLVal("RecType",l2,n2,_v974),n2,_v974));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $629 = _v217.termRef(0);
                ESLVal $628 = _v217.termRef(1);
                ESLVal $627 = _v217.termRef(2);
                
                {ESLVal _v971 = _v216;
                
                {ESLVal l1 = $629;
                
                {ESLVal ns2 = $628;
                
                {ESLVal _v972 = $627;
                
                return typeEqual(_v971,_v972);
              }
              }
              }
              }
              }
              default: {ESLVal _v986 = _v216;
                
                {ESLVal _v987 = _v217;
                
                return $false;
              }
              }
            }
          }
          }
        case "ActType": {ESLVal $791 = _v216.termRef(0);
            ESLVal $790 = _v216.termRef(1);
            ESLVal $789 = _v216.termRef(2);
            
            switch(_v217.termName) {
            case "ActType": {ESLVal $794 = _v217.termRef(0);
              ESLVal $793 = _v217.termRef(1);
              ESLVal $792 = _v217.termRef(2);
              
              {ESLVal l1 = $791;
              
              {ESLVal exports1 = $790;
              
              {ESLVal handlers1 = $789;
              
              {ESLVal l2 = $794;
              
              {ESLVal exports2 = $793;
              
              {ESLVal handlers2 = $792;
              
              return actEqual(exports1,exports2,handlers1,handlers2);
            }
            }
            }
            }
            }
            }
            }
            default: switch(_v217.termName) {
              case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                ESLVal $653 = _v217.termRef(1);
                ESLVal $652 = _v217.termRef(2);
                
                {ESLVal _v966 = _v216;
                
                {ESLVal l = $654;
                
                {ESLVal op = $653;
                
                {ESLVal args = $652;
                
                return typeEqual(_v966,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                ESLVal $650 = _v217.termRef(1);
                ESLVal $649 = _v217.termRef(2);
                ESLVal $648 = _v217.termRef(3);
                
                {ESLVal _v964 = _v216;
                
                {ESLVal l2 = $651;
                
                {ESLVal _v965 = $650;
                
                {ESLVal ds2 = $649;
                
                {ESLVal ms2 = $648;
                
                return typeEqual(_v964,flattenAct(l2,_v965,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $647 = _v217.termRef(0);
                
                {ESLVal t = _v216;
                
                {ESLVal l1 = $647;
                
                return $true;
              }
              }
              }
            case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                ESLVal $643 = _v217.termRef(1);
                ESLVal $642 = _v217.termRef(2);
                
                switch($642.termName) {
                case "UnionType": {ESLVal $646 = $642.termRef(0);
                  ESLVal $645 = $642.termRef(1);
                  
                  {ESLVal _v961 = _v216;
                  
                  {ESLVal l = $644;
                  
                  {ESLVal state = $643;
                  
                  {ESLVal ul = $646;
                  
                  {ESLVal terms = $645;
                  
                  return typeEqual(_v961,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v962 = _v216;
                  
                  {ESLVal _v963 = _v217;
                  
                  return $false;
                }
                }
              }
              }
            case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                ESLVal $638 = _v217.termRef(1);
                ESLVal $637 = _v217.termRef(2);
                
                switch($637.termName) {
                case "UnionType": {ESLVal $641 = $637.termRef(0);
                  ESLVal $640 = $637.termRef(1);
                  
                  {ESLVal _v958 = _v216;
                  
                  {ESLVal l = $639;
                  
                  {ESLVal state = $638;
                  
                  {ESLVal ul = $641;
                  
                  {ESLVal terms = $640;
                  
                  return typeEqual(_v958,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v959 = _v216;
                  
                  {ESLVal _v960 = _v217;
                  
                  return $false;
                }
                }
              }
              }
            case "TermType": {ESLVal $636 = _v217.termRef(0);
                ESLVal $635 = _v217.termRef(1);
                ESLVal $634 = _v217.termRef(2);
                
                {ESLVal _v957 = _v216;
                
                {ESLVal l2 = $636;
                
                {ESLVal n2 = $635;
                
                {ESLVal args2 = $634;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                
                {ESLVal _v956 = _v216;
                
                {ESLVal f = $633;
                
                return typeEqual(_v956,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $632 = _v217.termRef(0);
                ESLVal $631 = _v217.termRef(1);
                ESLVal $630 = _v217.termRef(2);
                
                {ESLVal _v954 = _v216;
                
                {ESLVal l2 = $632;
                
                {ESLVal n2 = $631;
                
                {ESLVal _v955 = $630;
                
                return typeEqual(_v954,substType(new ESLVal("RecType",l2,n2,_v955),n2,_v955));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $629 = _v217.termRef(0);
                ESLVal $628 = _v217.termRef(1);
                ESLVal $627 = _v217.termRef(2);
                
                {ESLVal _v952 = _v216;
                
                {ESLVal l1 = $629;
                
                {ESLVal ns2 = $628;
                
                {ESLVal _v953 = $627;
                
                return typeEqual(_v952,_v953);
              }
              }
              }
              }
              }
              default: {ESLVal _v967 = _v216;
                
                {ESLVal _v968 = _v217;
                
                return $false;
              }
              }
            }
          }
          }
        case "ApplyTypeFun": {ESLVal $785 = _v216.termRef(0);
            ESLVal $784 = _v216.termRef(1);
            ESLVal $783 = _v216.termRef(2);
            
            switch(_v217.termName) {
            case "ApplyTypeFun": {ESLVal $788 = _v217.termRef(0);
              ESLVal $787 = _v217.termRef(1);
              ESLVal $786 = _v217.termRef(2);
              
              {ESLVal l1 = $785;
              
              {ESLVal op1 = $784;
              
              {ESLVal args1 = $783;
              
              {ESLVal l2 = $788;
              
              {ESLVal op2 = $787;
              
              {ESLVal args2 = $786;
              
              return typeEqual(op1,op2).and(typesEqual(args1,args2));
            }
            }
            }
            }
            }
            }
            }
            default: {ESLVal l = $785;
              
              {ESLVal op = $784;
              
              {ESLVal args = $783;
              
              {ESLVal _v951 = _v217;
              
              return typeEqual(applyTypeFun(l,forceType(op),args),_v951);
            }
            }
            }
            }
          }
          }
        case "ExtendedAct": {ESLVal $782 = _v216.termRef(0);
            ESLVal $781 = _v216.termRef(1);
            ESLVal $780 = _v216.termRef(2);
            ESLVal $779 = _v216.termRef(3);
            
            {ESLVal l1 = $782;
            
            {ESLVal _v949 = $781;
            
            {ESLVal ds1 = $780;
            
            {ESLVal ms1 = $779;
            
            {ESLVal _v950 = _v217;
            
            return typeEqual(flattenAct(l1,_v949,ds1,ms1),_v950);
          }
          }
          }
          }
          }
          }
        case "BoolType": {ESLVal $777 = _v216.termRef(0);
            
            switch(_v217.termName) {
            case "BoolType": {ESLVal $778 = _v217.termRef(0);
              
              {ESLVal l1 = $777;
              
              {ESLVal l2 = $778;
              
              return $true;
            }
            }
            }
            default: switch(_v217.termName) {
              case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                ESLVal $653 = _v217.termRef(1);
                ESLVal $652 = _v217.termRef(2);
                
                {ESLVal _v946 = _v216;
                
                {ESLVal l = $654;
                
                {ESLVal op = $653;
                
                {ESLVal args = $652;
                
                return typeEqual(_v946,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                ESLVal $650 = _v217.termRef(1);
                ESLVal $649 = _v217.termRef(2);
                ESLVal $648 = _v217.termRef(3);
                
                {ESLVal _v944 = _v216;
                
                {ESLVal l2 = $651;
                
                {ESLVal _v945 = $650;
                
                {ESLVal ds2 = $649;
                
                {ESLVal ms2 = $648;
                
                return typeEqual(_v944,flattenAct(l2,_v945,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $647 = _v217.termRef(0);
                
                {ESLVal t = _v216;
                
                {ESLVal l1 = $647;
                
                return $true;
              }
              }
              }
            case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                ESLVal $643 = _v217.termRef(1);
                ESLVal $642 = _v217.termRef(2);
                
                switch($642.termName) {
                case "UnionType": {ESLVal $646 = $642.termRef(0);
                  ESLVal $645 = $642.termRef(1);
                  
                  {ESLVal _v941 = _v216;
                  
                  {ESLVal l = $644;
                  
                  {ESLVal state = $643;
                  
                  {ESLVal ul = $646;
                  
                  {ESLVal terms = $645;
                  
                  return typeEqual(_v941,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v942 = _v216;
                  
                  {ESLVal _v943 = _v217;
                  
                  return $false;
                }
                }
              }
              }
            case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                ESLVal $638 = _v217.termRef(1);
                ESLVal $637 = _v217.termRef(2);
                
                switch($637.termName) {
                case "UnionType": {ESLVal $641 = $637.termRef(0);
                  ESLVal $640 = $637.termRef(1);
                  
                  {ESLVal _v938 = _v216;
                  
                  {ESLVal l = $639;
                  
                  {ESLVal state = $638;
                  
                  {ESLVal ul = $641;
                  
                  {ESLVal terms = $640;
                  
                  return typeEqual(_v938,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v939 = _v216;
                  
                  {ESLVal _v940 = _v217;
                  
                  return $false;
                }
                }
              }
              }
            case "TermType": {ESLVal $636 = _v217.termRef(0);
                ESLVal $635 = _v217.termRef(1);
                ESLVal $634 = _v217.termRef(2);
                
                {ESLVal _v937 = _v216;
                
                {ESLVal l2 = $636;
                
                {ESLVal n2 = $635;
                
                {ESLVal args2 = $634;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                
                {ESLVal _v936 = _v216;
                
                {ESLVal f = $633;
                
                return typeEqual(_v936,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $632 = _v217.termRef(0);
                ESLVal $631 = _v217.termRef(1);
                ESLVal $630 = _v217.termRef(2);
                
                {ESLVal _v934 = _v216;
                
                {ESLVal l2 = $632;
                
                {ESLVal n2 = $631;
                
                {ESLVal _v935 = $630;
                
                return typeEqual(_v934,substType(new ESLVal("RecType",l2,n2,_v935),n2,_v935));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $629 = _v217.termRef(0);
                ESLVal $628 = _v217.termRef(1);
                ESLVal $627 = _v217.termRef(2);
                
                {ESLVal _v932 = _v216;
                
                {ESLVal l1 = $629;
                
                {ESLVal ns2 = $628;
                
                {ESLVal _v933 = $627;
                
                return typeEqual(_v932,_v933);
              }
              }
              }
              }
              }
              default: {ESLVal _v947 = _v216;
                
                {ESLVal _v948 = _v217;
                
                return $false;
              }
              }
            }
          }
          }
        case "FloatType": {ESLVal $775 = _v216.termRef(0);
            
            switch(_v217.termName) {
            case "FloatType": {ESLVal $776 = _v217.termRef(0);
              
              {ESLVal l1 = $775;
              
              {ESLVal l2 = $776;
              
              return $true;
            }
            }
            }
            default: switch(_v217.termName) {
              case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                ESLVal $653 = _v217.termRef(1);
                ESLVal $652 = _v217.termRef(2);
                
                {ESLVal _v929 = _v216;
                
                {ESLVal l = $654;
                
                {ESLVal op = $653;
                
                {ESLVal args = $652;
                
                return typeEqual(_v929,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                ESLVal $650 = _v217.termRef(1);
                ESLVal $649 = _v217.termRef(2);
                ESLVal $648 = _v217.termRef(3);
                
                {ESLVal _v927 = _v216;
                
                {ESLVal l2 = $651;
                
                {ESLVal _v928 = $650;
                
                {ESLVal ds2 = $649;
                
                {ESLVal ms2 = $648;
                
                return typeEqual(_v927,flattenAct(l2,_v928,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $647 = _v217.termRef(0);
                
                {ESLVal t = _v216;
                
                {ESLVal l1 = $647;
                
                return $true;
              }
              }
              }
            case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                ESLVal $643 = _v217.termRef(1);
                ESLVal $642 = _v217.termRef(2);
                
                switch($642.termName) {
                case "UnionType": {ESLVal $646 = $642.termRef(0);
                  ESLVal $645 = $642.termRef(1);
                  
                  {ESLVal _v924 = _v216;
                  
                  {ESLVal l = $644;
                  
                  {ESLVal state = $643;
                  
                  {ESLVal ul = $646;
                  
                  {ESLVal terms = $645;
                  
                  return typeEqual(_v924,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v925 = _v216;
                  
                  {ESLVal _v926 = _v217;
                  
                  return $false;
                }
                }
              }
              }
            case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                ESLVal $638 = _v217.termRef(1);
                ESLVal $637 = _v217.termRef(2);
                
                switch($637.termName) {
                case "UnionType": {ESLVal $641 = $637.termRef(0);
                  ESLVal $640 = $637.termRef(1);
                  
                  {ESLVal _v921 = _v216;
                  
                  {ESLVal l = $639;
                  
                  {ESLVal state = $638;
                  
                  {ESLVal ul = $641;
                  
                  {ESLVal terms = $640;
                  
                  return typeEqual(_v921,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v922 = _v216;
                  
                  {ESLVal _v923 = _v217;
                  
                  return $false;
                }
                }
              }
              }
            case "TermType": {ESLVal $636 = _v217.termRef(0);
                ESLVal $635 = _v217.termRef(1);
                ESLVal $634 = _v217.termRef(2);
                
                {ESLVal _v920 = _v216;
                
                {ESLVal l2 = $636;
                
                {ESLVal n2 = $635;
                
                {ESLVal args2 = $634;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                
                {ESLVal _v919 = _v216;
                
                {ESLVal f = $633;
                
                return typeEqual(_v919,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $632 = _v217.termRef(0);
                ESLVal $631 = _v217.termRef(1);
                ESLVal $630 = _v217.termRef(2);
                
                {ESLVal _v917 = _v216;
                
                {ESLVal l2 = $632;
                
                {ESLVal n2 = $631;
                
                {ESLVal _v918 = $630;
                
                return typeEqual(_v917,substType(new ESLVal("RecType",l2,n2,_v918),n2,_v918));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $629 = _v217.termRef(0);
                ESLVal $628 = _v217.termRef(1);
                ESLVal $627 = _v217.termRef(2);
                
                {ESLVal _v915 = _v216;
                
                {ESLVal l1 = $629;
                
                {ESLVal ns2 = $628;
                
                {ESLVal _v916 = $627;
                
                return typeEqual(_v915,_v916);
              }
              }
              }
              }
              }
              default: {ESLVal _v930 = _v216;
                
                {ESLVal _v931 = _v217;
                
                return $false;
              }
              }
            }
          }
          }
        case "IntType": {ESLVal $773 = _v216.termRef(0);
            
            switch(_v217.termName) {
            case "IntType": {ESLVal $774 = _v217.termRef(0);
              
              {ESLVal l1 = $773;
              
              {ESLVal l2 = $774;
              
              return $true;
            }
            }
            }
            default: switch(_v217.termName) {
              case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                ESLVal $653 = _v217.termRef(1);
                ESLVal $652 = _v217.termRef(2);
                
                {ESLVal _v912 = _v216;
                
                {ESLVal l = $654;
                
                {ESLVal op = $653;
                
                {ESLVal args = $652;
                
                return typeEqual(_v912,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                ESLVal $650 = _v217.termRef(1);
                ESLVal $649 = _v217.termRef(2);
                ESLVal $648 = _v217.termRef(3);
                
                {ESLVal _v910 = _v216;
                
                {ESLVal l2 = $651;
                
                {ESLVal _v911 = $650;
                
                {ESLVal ds2 = $649;
                
                {ESLVal ms2 = $648;
                
                return typeEqual(_v910,flattenAct(l2,_v911,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $647 = _v217.termRef(0);
                
                {ESLVal t = _v216;
                
                {ESLVal l1 = $647;
                
                return $true;
              }
              }
              }
            case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                ESLVal $643 = _v217.termRef(1);
                ESLVal $642 = _v217.termRef(2);
                
                switch($642.termName) {
                case "UnionType": {ESLVal $646 = $642.termRef(0);
                  ESLVal $645 = $642.termRef(1);
                  
                  {ESLVal _v907 = _v216;
                  
                  {ESLVal l = $644;
                  
                  {ESLVal state = $643;
                  
                  {ESLVal ul = $646;
                  
                  {ESLVal terms = $645;
                  
                  return typeEqual(_v907,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v908 = _v216;
                  
                  {ESLVal _v909 = _v217;
                  
                  return $false;
                }
                }
              }
              }
            case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                ESLVal $638 = _v217.termRef(1);
                ESLVal $637 = _v217.termRef(2);
                
                switch($637.termName) {
                case "UnionType": {ESLVal $641 = $637.termRef(0);
                  ESLVal $640 = $637.termRef(1);
                  
                  {ESLVal _v904 = _v216;
                  
                  {ESLVal l = $639;
                  
                  {ESLVal state = $638;
                  
                  {ESLVal ul = $641;
                  
                  {ESLVal terms = $640;
                  
                  return typeEqual(_v904,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v905 = _v216;
                  
                  {ESLVal _v906 = _v217;
                  
                  return $false;
                }
                }
              }
              }
            case "TermType": {ESLVal $636 = _v217.termRef(0);
                ESLVal $635 = _v217.termRef(1);
                ESLVal $634 = _v217.termRef(2);
                
                {ESLVal _v903 = _v216;
                
                {ESLVal l2 = $636;
                
                {ESLVal n2 = $635;
                
                {ESLVal args2 = $634;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                
                {ESLVal _v902 = _v216;
                
                {ESLVal f = $633;
                
                return typeEqual(_v902,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $632 = _v217.termRef(0);
                ESLVal $631 = _v217.termRef(1);
                ESLVal $630 = _v217.termRef(2);
                
                {ESLVal _v900 = _v216;
                
                {ESLVal l2 = $632;
                
                {ESLVal n2 = $631;
                
                {ESLVal _v901 = $630;
                
                return typeEqual(_v900,substType(new ESLVal("RecType",l2,n2,_v901),n2,_v901));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $629 = _v217.termRef(0);
                ESLVal $628 = _v217.termRef(1);
                ESLVal $627 = _v217.termRef(2);
                
                {ESLVal _v898 = _v216;
                
                {ESLVal l1 = $629;
                
                {ESLVal ns2 = $628;
                
                {ESLVal _v899 = $627;
                
                return typeEqual(_v898,_v899);
              }
              }
              }
              }
              }
              default: {ESLVal _v913 = _v216;
                
                {ESLVal _v914 = _v217;
                
                return $false;
              }
              }
            }
          }
          }
        case "ListType": {ESLVal $759 = _v216.termRef(0);
            ESLVal $758 = _v216.termRef(1);
            
            switch(_v217.termName) {
            case "ListType": {ESLVal $772 = _v217.termRef(0);
              ESLVal $771 = _v217.termRef(1);
              
              {ESLVal l1 = $759;
              
              {ESLVal _v879 = $758;
              
              {ESLVal l2 = $772;
              
              {ESLVal _v880 = $771;
              
              return typeEqual(_v879,_v880);
            }
            }
            }
            }
            }
          case "ForallType": {ESLVal $762 = _v217.termRef(0);
              ESLVal $761 = _v217.termRef(1);
              ESLVal $760 = _v217.termRef(2);
              
              if($761.isCons())
              {ESLVal $763 = $761.head();
                ESLVal $764 = $761.tail();
                
                if($764.isCons())
                {ESLVal $765 = $764.head();
                  ESLVal $766 = $764.tail();
                  
                  switch(_v217.termName) {
                  case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                    ESLVal $653 = _v217.termRef(1);
                    ESLVal $652 = _v217.termRef(2);
                    
                    {ESLVal _v768 = _v216;
                    
                    {ESLVal l = $654;
                    
                    {ESLVal op = $653;
                    
                    {ESLVal args = $652;
                    
                    return typeEqual(_v768,applyTypeFun(l,forceType(op),args));
                  }
                  }
                  }
                  }
                  }
                case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                    ESLVal $650 = _v217.termRef(1);
                    ESLVal $649 = _v217.termRef(2);
                    ESLVal $648 = _v217.termRef(3);
                    
                    {ESLVal _v766 = _v216;
                    
                    {ESLVal l2 = $651;
                    
                    {ESLVal _v767 = $650;
                    
                    {ESLVal ds2 = $649;
                    
                    {ESLVal ms2 = $648;
                    
                    return typeEqual(_v766,flattenAct(l2,_v767,ds2,ms2));
                  }
                  }
                  }
                  }
                  }
                  }
                case "VoidType": {ESLVal $647 = _v217.termRef(0);
                    
                    {ESLVal t = _v216;
                    
                    {ESLVal l1 = $647;
                    
                    return $true;
                  }
                  }
                  }
                case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                    ESLVal $643 = _v217.termRef(1);
                    ESLVal $642 = _v217.termRef(2);
                    
                    switch($642.termName) {
                    case "UnionType": {ESLVal $646 = $642.termRef(0);
                      ESLVal $645 = $642.termRef(1);
                      
                      {ESLVal _v763 = _v216;
                      
                      {ESLVal l = $644;
                      
                      {ESLVal state = $643;
                      
                      {ESLVal ul = $646;
                      
                      {ESLVal terms = $645;
                      
                      return typeEqual(_v763,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                    }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal _v764 = _v216;
                      
                      {ESLVal _v765 = _v217;
                      
                      return $false;
                    }
                    }
                  }
                  }
                case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                    ESLVal $638 = _v217.termRef(1);
                    ESLVal $637 = _v217.termRef(2);
                    
                    switch($637.termName) {
                    case "UnionType": {ESLVal $641 = $637.termRef(0);
                      ESLVal $640 = $637.termRef(1);
                      
                      {ESLVal _v760 = _v216;
                      
                      {ESLVal l = $639;
                      
                      {ESLVal state = $638;
                      
                      {ESLVal ul = $641;
                      
                      {ESLVal terms = $640;
                      
                      return typeEqual(_v760,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                    }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal _v761 = _v216;
                      
                      {ESLVal _v762 = _v217;
                      
                      return $false;
                    }
                    }
                  }
                  }
                case "TermType": {ESLVal $636 = _v217.termRef(0);
                    ESLVal $635 = _v217.termRef(1);
                    ESLVal $634 = _v217.termRef(2);
                    
                    {ESLVal _v759 = _v216;
                    
                    {ESLVal l2 = $636;
                    
                    {ESLVal n2 = $635;
                    
                    {ESLVal args2 = $634;
                    
                    return $false;
                  }
                  }
                  }
                  }
                  }
                case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                    
                    {ESLVal _v758 = _v216;
                    
                    {ESLVal f = $633;
                    
                    return typeEqual(_v758,f.apply());
                  }
                  }
                  }
                case "RecType": {ESLVal $632 = _v217.termRef(0);
                    ESLVal $631 = _v217.termRef(1);
                    ESLVal $630 = _v217.termRef(2);
                    
                    {ESLVal _v756 = _v216;
                    
                    {ESLVal l2 = $632;
                    
                    {ESLVal n2 = $631;
                    
                    {ESLVal _v757 = $630;
                    
                    return typeEqual(_v756,substType(new ESLVal("RecType",l2,n2,_v757),n2,_v757));
                  }
                  }
                  }
                  }
                  }
                case "ForallType": {ESLVal $629 = _v217.termRef(0);
                    ESLVal $628 = _v217.termRef(1);
                    ESLVal $627 = _v217.termRef(2);
                    
                    {ESLVal _v754 = _v216;
                    
                    {ESLVal l1 = $629;
                    
                    {ESLVal ns2 = $628;
                    
                    {ESLVal _v755 = $627;
                    
                    return typeEqual(_v754,_v755);
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v769 = _v216;
                    
                    {ESLVal _v770 = _v217;
                    
                    return $false;
                  }
                  }
                }
                }
              else if($764.isNil())
                switch($760.termName) {
                  case "ListType": {ESLVal $768 = $760.termRef(0);
                    ESLVal $767 = $760.termRef(1);
                    
                    switch($767.termName) {
                    case "VarType": {ESLVal $770 = $767.termRef(0);
                      ESLVal $769 = $767.termRef(1);
                      
                      {ESLVal l1 = $759;
                      
                      {ESLVal _v771 = $758;
                      
                      {ESLVal l2 = $762;
                      
                      {ESLVal v1 = $763;
                      
                      {ESLVal l3 = $768;
                      
                      {ESLVal l4 = $770;
                      
                      {ESLVal v2 = $769;
                      
                      if(v1.eql(v2).boolVal)
                      return $true;
                      else
                        switch(_v217.termName) {
                          case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                            ESLVal $653 = _v217.termRef(1);
                            ESLVal $652 = _v217.termRef(2);
                            
                            {ESLVal _v791 = _v216;
                            
                            {ESLVal l = $654;
                            
                            {ESLVal op = $653;
                            
                            {ESLVal args = $652;
                            
                            return typeEqual(_v791,applyTypeFun(l,forceType(op),args));
                          }
                          }
                          }
                          }
                          }
                        case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                            ESLVal $650 = _v217.termRef(1);
                            ESLVal $649 = _v217.termRef(2);
                            ESLVal $648 = _v217.termRef(3);
                            
                            {ESLVal _v788 = _v216;
                            
                            {ESLVal _v789 = $651;
                            
                            {ESLVal _v790 = $650;
                            
                            {ESLVal ds2 = $649;
                            
                            {ESLVal ms2 = $648;
                            
                            return typeEqual(_v788,flattenAct(_v789,_v790,ds2,ms2));
                          }
                          }
                          }
                          }
                          }
                          }
                        case "VoidType": {ESLVal $647 = _v217.termRef(0);
                            
                            {ESLVal t = _v216;
                            
                            {ESLVal _v787 = $647;
                            
                            return $true;
                          }
                          }
                          }
                        case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                            ESLVal $643 = _v217.termRef(1);
                            ESLVal $642 = _v217.termRef(2);
                            
                            switch($642.termName) {
                            case "UnionType": {ESLVal $646 = $642.termRef(0);
                              ESLVal $645 = $642.termRef(1);
                              
                              {ESLVal _v784 = _v216;
                              
                              {ESLVal l = $644;
                              
                              {ESLVal state = $643;
                              
                              {ESLVal ul = $646;
                              
                              {ESLVal terms = $645;
                              
                              return typeEqual(_v784,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                            }
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v785 = _v216;
                              
                              {ESLVal _v786 = _v217;
                              
                              return $false;
                            }
                            }
                          }
                          }
                        case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                            ESLVal $638 = _v217.termRef(1);
                            ESLVal $637 = _v217.termRef(2);
                            
                            switch($637.termName) {
                            case "UnionType": {ESLVal $641 = $637.termRef(0);
                              ESLVal $640 = $637.termRef(1);
                              
                              {ESLVal _v781 = _v216;
                              
                              {ESLVal l = $639;
                              
                              {ESLVal state = $638;
                              
                              {ESLVal ul = $641;
                              
                              {ESLVal terms = $640;
                              
                              return typeEqual(_v781,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                            }
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v782 = _v216;
                              
                              {ESLVal _v783 = _v217;
                              
                              return $false;
                            }
                            }
                          }
                          }
                        case "TermType": {ESLVal $636 = _v217.termRef(0);
                            ESLVal $635 = _v217.termRef(1);
                            ESLVal $634 = _v217.termRef(2);
                            
                            {ESLVal _v779 = _v216;
                            
                            {ESLVal _v780 = $636;
                            
                            {ESLVal n2 = $635;
                            
                            {ESLVal args2 = $634;
                            
                            return $false;
                          }
                          }
                          }
                          }
                          }
                        case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                            
                            {ESLVal _v778 = _v216;
                            
                            {ESLVal f = $633;
                            
                            return typeEqual(_v778,f.apply());
                          }
                          }
                          }
                        case "RecType": {ESLVal $632 = _v217.termRef(0);
                            ESLVal $631 = _v217.termRef(1);
                            ESLVal $630 = _v217.termRef(2);
                            
                            {ESLVal _v775 = _v216;
                            
                            {ESLVal _v776 = $632;
                            
                            {ESLVal n2 = $631;
                            
                            {ESLVal _v777 = $630;
                            
                            return typeEqual(_v775,substType(new ESLVal("RecType",_v776,n2,_v777),n2,_v777));
                          }
                          }
                          }
                          }
                          }
                        case "ForallType": {ESLVal $629 = _v217.termRef(0);
                            ESLVal $628 = _v217.termRef(1);
                            ESLVal $627 = _v217.termRef(2);
                            
                            {ESLVal _v772 = _v216;
                            
                            {ESLVal _v773 = $629;
                            
                            {ESLVal ns2 = $628;
                            
                            {ESLVal _v774 = $627;
                            
                            return typeEqual(_v772,_v774);
                          }
                          }
                          }
                          }
                          }
                          default: {ESLVal _v792 = _v216;
                            
                            {ESLVal _v793 = _v217;
                            
                            return $false;
                          }
                          }
                        }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: switch(_v217.termName) {
                      case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                        ESLVal $653 = _v217.termRef(1);
                        ESLVal $652 = _v217.termRef(2);
                        
                        {ESLVal _v808 = _v216;
                        
                        {ESLVal l = $654;
                        
                        {ESLVal op = $653;
                        
                        {ESLVal args = $652;
                        
                        return typeEqual(_v808,applyTypeFun(l,forceType(op),args));
                      }
                      }
                      }
                      }
                      }
                    case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                        ESLVal $650 = _v217.termRef(1);
                        ESLVal $649 = _v217.termRef(2);
                        ESLVal $648 = _v217.termRef(3);
                        
                        {ESLVal _v806 = _v216;
                        
                        {ESLVal l2 = $651;
                        
                        {ESLVal _v807 = $650;
                        
                        {ESLVal ds2 = $649;
                        
                        {ESLVal ms2 = $648;
                        
                        return typeEqual(_v806,flattenAct(l2,_v807,ds2,ms2));
                      }
                      }
                      }
                      }
                      }
                      }
                    case "VoidType": {ESLVal $647 = _v217.termRef(0);
                        
                        {ESLVal t = _v216;
                        
                        {ESLVal l1 = $647;
                        
                        return $true;
                      }
                      }
                      }
                    case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                        ESLVal $643 = _v217.termRef(1);
                        ESLVal $642 = _v217.termRef(2);
                        
                        switch($642.termName) {
                        case "UnionType": {ESLVal $646 = $642.termRef(0);
                          ESLVal $645 = $642.termRef(1);
                          
                          {ESLVal _v803 = _v216;
                          
                          {ESLVal l = $644;
                          
                          {ESLVal state = $643;
                          
                          {ESLVal ul = $646;
                          
                          {ESLVal terms = $645;
                          
                          return typeEqual(_v803,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                        }
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal _v804 = _v216;
                          
                          {ESLVal _v805 = _v217;
                          
                          return $false;
                        }
                        }
                      }
                      }
                    case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                        ESLVal $638 = _v217.termRef(1);
                        ESLVal $637 = _v217.termRef(2);
                        
                        switch($637.termName) {
                        case "UnionType": {ESLVal $641 = $637.termRef(0);
                          ESLVal $640 = $637.termRef(1);
                          
                          {ESLVal _v800 = _v216;
                          
                          {ESLVal l = $639;
                          
                          {ESLVal state = $638;
                          
                          {ESLVal ul = $641;
                          
                          {ESLVal terms = $640;
                          
                          return typeEqual(_v800,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                        }
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal _v801 = _v216;
                          
                          {ESLVal _v802 = _v217;
                          
                          return $false;
                        }
                        }
                      }
                      }
                    case "TermType": {ESLVal $636 = _v217.termRef(0);
                        ESLVal $635 = _v217.termRef(1);
                        ESLVal $634 = _v217.termRef(2);
                        
                        {ESLVal _v799 = _v216;
                        
                        {ESLVal l2 = $636;
                        
                        {ESLVal n2 = $635;
                        
                        {ESLVal args2 = $634;
                        
                        return $false;
                      }
                      }
                      }
                      }
                      }
                    case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                        
                        {ESLVal _v798 = _v216;
                        
                        {ESLVal f = $633;
                        
                        return typeEqual(_v798,f.apply());
                      }
                      }
                      }
                    case "RecType": {ESLVal $632 = _v217.termRef(0);
                        ESLVal $631 = _v217.termRef(1);
                        ESLVal $630 = _v217.termRef(2);
                        
                        {ESLVal _v796 = _v216;
                        
                        {ESLVal l2 = $632;
                        
                        {ESLVal n2 = $631;
                        
                        {ESLVal _v797 = $630;
                        
                        return typeEqual(_v796,substType(new ESLVal("RecType",l2,n2,_v797),n2,_v797));
                      }
                      }
                      }
                      }
                      }
                    case "ForallType": {ESLVal $629 = _v217.termRef(0);
                        ESLVal $628 = _v217.termRef(1);
                        ESLVal $627 = _v217.termRef(2);
                        
                        {ESLVal _v794 = _v216;
                        
                        {ESLVal l1 = $629;
                        
                        {ESLVal ns2 = $628;
                        
                        {ESLVal _v795 = $627;
                        
                        return typeEqual(_v794,_v795);
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal _v809 = _v216;
                        
                        {ESLVal _v810 = _v217;
                        
                        return $false;
                      }
                      }
                    }
                  }
                  }
                  default: switch(_v217.termName) {
                    case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                      ESLVal $653 = _v217.termRef(1);
                      ESLVal $652 = _v217.termRef(2);
                      
                      {ESLVal _v825 = _v216;
                      
                      {ESLVal l = $654;
                      
                      {ESLVal op = $653;
                      
                      {ESLVal args = $652;
                      
                      return typeEqual(_v825,applyTypeFun(l,forceType(op),args));
                    }
                    }
                    }
                    }
                    }
                  case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                      ESLVal $650 = _v217.termRef(1);
                      ESLVal $649 = _v217.termRef(2);
                      ESLVal $648 = _v217.termRef(3);
                      
                      {ESLVal _v823 = _v216;
                      
                      {ESLVal l2 = $651;
                      
                      {ESLVal _v824 = $650;
                      
                      {ESLVal ds2 = $649;
                      
                      {ESLVal ms2 = $648;
                      
                      return typeEqual(_v823,flattenAct(l2,_v824,ds2,ms2));
                    }
                    }
                    }
                    }
                    }
                    }
                  case "VoidType": {ESLVal $647 = _v217.termRef(0);
                      
                      {ESLVal t = _v216;
                      
                      {ESLVal l1 = $647;
                      
                      return $true;
                    }
                    }
                    }
                  case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                      ESLVal $643 = _v217.termRef(1);
                      ESLVal $642 = _v217.termRef(2);
                      
                      switch($642.termName) {
                      case "UnionType": {ESLVal $646 = $642.termRef(0);
                        ESLVal $645 = $642.termRef(1);
                        
                        {ESLVal _v820 = _v216;
                        
                        {ESLVal l = $644;
                        
                        {ESLVal state = $643;
                        
                        {ESLVal ul = $646;
                        
                        {ESLVal terms = $645;
                        
                        return typeEqual(_v820,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                      }
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal _v821 = _v216;
                        
                        {ESLVal _v822 = _v217;
                        
                        return $false;
                      }
                      }
                    }
                    }
                  case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                      ESLVal $638 = _v217.termRef(1);
                      ESLVal $637 = _v217.termRef(2);
                      
                      switch($637.termName) {
                      case "UnionType": {ESLVal $641 = $637.termRef(0);
                        ESLVal $640 = $637.termRef(1);
                        
                        {ESLVal _v817 = _v216;
                        
                        {ESLVal l = $639;
                        
                        {ESLVal state = $638;
                        
                        {ESLVal ul = $641;
                        
                        {ESLVal terms = $640;
                        
                        return typeEqual(_v817,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                      }
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal _v818 = _v216;
                        
                        {ESLVal _v819 = _v217;
                        
                        return $false;
                      }
                      }
                    }
                    }
                  case "TermType": {ESLVal $636 = _v217.termRef(0);
                      ESLVal $635 = _v217.termRef(1);
                      ESLVal $634 = _v217.termRef(2);
                      
                      {ESLVal _v816 = _v216;
                      
                      {ESLVal l2 = $636;
                      
                      {ESLVal n2 = $635;
                      
                      {ESLVal args2 = $634;
                      
                      return $false;
                    }
                    }
                    }
                    }
                    }
                  case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                      
                      {ESLVal _v815 = _v216;
                      
                      {ESLVal f = $633;
                      
                      return typeEqual(_v815,f.apply());
                    }
                    }
                    }
                  case "RecType": {ESLVal $632 = _v217.termRef(0);
                      ESLVal $631 = _v217.termRef(1);
                      ESLVal $630 = _v217.termRef(2);
                      
                      {ESLVal _v813 = _v216;
                      
                      {ESLVal l2 = $632;
                      
                      {ESLVal n2 = $631;
                      
                      {ESLVal _v814 = $630;
                      
                      return typeEqual(_v813,substType(new ESLVal("RecType",l2,n2,_v814),n2,_v814));
                    }
                    }
                    }
                    }
                    }
                  case "ForallType": {ESLVal $629 = _v217.termRef(0);
                      ESLVal $628 = _v217.termRef(1);
                      ESLVal $627 = _v217.termRef(2);
                      
                      {ESLVal _v811 = _v216;
                      
                      {ESLVal l1 = $629;
                      
                      {ESLVal ns2 = $628;
                      
                      {ESLVal _v812 = $627;
                      
                      return typeEqual(_v811,_v812);
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal _v826 = _v216;
                      
                      {ESLVal _v827 = _v217;
                      
                      return $false;
                    }
                    }
                  }
                }
              else switch(_v217.termName) {
                  case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                    ESLVal $653 = _v217.termRef(1);
                    ESLVal $652 = _v217.termRef(2);
                    
                    {ESLVal _v842 = _v216;
                    
                    {ESLVal l = $654;
                    
                    {ESLVal op = $653;
                    
                    {ESLVal args = $652;
                    
                    return typeEqual(_v842,applyTypeFun(l,forceType(op),args));
                  }
                  }
                  }
                  }
                  }
                case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                    ESLVal $650 = _v217.termRef(1);
                    ESLVal $649 = _v217.termRef(2);
                    ESLVal $648 = _v217.termRef(3);
                    
                    {ESLVal _v840 = _v216;
                    
                    {ESLVal l2 = $651;
                    
                    {ESLVal _v841 = $650;
                    
                    {ESLVal ds2 = $649;
                    
                    {ESLVal ms2 = $648;
                    
                    return typeEqual(_v840,flattenAct(l2,_v841,ds2,ms2));
                  }
                  }
                  }
                  }
                  }
                  }
                case "VoidType": {ESLVal $647 = _v217.termRef(0);
                    
                    {ESLVal t = _v216;
                    
                    {ESLVal l1 = $647;
                    
                    return $true;
                  }
                  }
                  }
                case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                    ESLVal $643 = _v217.termRef(1);
                    ESLVal $642 = _v217.termRef(2);
                    
                    switch($642.termName) {
                    case "UnionType": {ESLVal $646 = $642.termRef(0);
                      ESLVal $645 = $642.termRef(1);
                      
                      {ESLVal _v837 = _v216;
                      
                      {ESLVal l = $644;
                      
                      {ESLVal state = $643;
                      
                      {ESLVal ul = $646;
                      
                      {ESLVal terms = $645;
                      
                      return typeEqual(_v837,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                    }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal _v838 = _v216;
                      
                      {ESLVal _v839 = _v217;
                      
                      return $false;
                    }
                    }
                  }
                  }
                case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                    ESLVal $638 = _v217.termRef(1);
                    ESLVal $637 = _v217.termRef(2);
                    
                    switch($637.termName) {
                    case "UnionType": {ESLVal $641 = $637.termRef(0);
                      ESLVal $640 = $637.termRef(1);
                      
                      {ESLVal _v834 = _v216;
                      
                      {ESLVal l = $639;
                      
                      {ESLVal state = $638;
                      
                      {ESLVal ul = $641;
                      
                      {ESLVal terms = $640;
                      
                      return typeEqual(_v834,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                    }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal _v835 = _v216;
                      
                      {ESLVal _v836 = _v217;
                      
                      return $false;
                    }
                    }
                  }
                  }
                case "TermType": {ESLVal $636 = _v217.termRef(0);
                    ESLVal $635 = _v217.termRef(1);
                    ESLVal $634 = _v217.termRef(2);
                    
                    {ESLVal _v833 = _v216;
                    
                    {ESLVal l2 = $636;
                    
                    {ESLVal n2 = $635;
                    
                    {ESLVal args2 = $634;
                    
                    return $false;
                  }
                  }
                  }
                  }
                  }
                case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                    
                    {ESLVal _v832 = _v216;
                    
                    {ESLVal f = $633;
                    
                    return typeEqual(_v832,f.apply());
                  }
                  }
                  }
                case "RecType": {ESLVal $632 = _v217.termRef(0);
                    ESLVal $631 = _v217.termRef(1);
                    ESLVal $630 = _v217.termRef(2);
                    
                    {ESLVal _v830 = _v216;
                    
                    {ESLVal l2 = $632;
                    
                    {ESLVal n2 = $631;
                    
                    {ESLVal _v831 = $630;
                    
                    return typeEqual(_v830,substType(new ESLVal("RecType",l2,n2,_v831),n2,_v831));
                  }
                  }
                  }
                  }
                  }
                case "ForallType": {ESLVal $629 = _v217.termRef(0);
                    ESLVal $628 = _v217.termRef(1);
                    ESLVal $627 = _v217.termRef(2);
                    
                    {ESLVal _v828 = _v216;
                    
                    {ESLVal l1 = $629;
                    
                    {ESLVal ns2 = $628;
                    
                    {ESLVal _v829 = $627;
                    
                    return typeEqual(_v828,_v829);
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v843 = _v216;
                    
                    {ESLVal _v844 = _v217;
                    
                    return $false;
                  }
                  }
                }
              }
            else if($761.isNil())
              switch(_v217.termName) {
                case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                  ESLVal $653 = _v217.termRef(1);
                  ESLVal $652 = _v217.termRef(2);
                  
                  {ESLVal _v859 = _v216;
                  
                  {ESLVal l = $654;
                  
                  {ESLVal op = $653;
                  
                  {ESLVal args = $652;
                  
                  return typeEqual(_v859,applyTypeFun(l,forceType(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                  ESLVal $650 = _v217.termRef(1);
                  ESLVal $649 = _v217.termRef(2);
                  ESLVal $648 = _v217.termRef(3);
                  
                  {ESLVal _v857 = _v216;
                  
                  {ESLVal l2 = $651;
                  
                  {ESLVal _v858 = $650;
                  
                  {ESLVal ds2 = $649;
                  
                  {ESLVal ms2 = $648;
                  
                  return typeEqual(_v857,flattenAct(l2,_v858,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $647 = _v217.termRef(0);
                  
                  {ESLVal t = _v216;
                  
                  {ESLVal l1 = $647;
                  
                  return $true;
                }
                }
                }
              case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                  ESLVal $643 = _v217.termRef(1);
                  ESLVal $642 = _v217.termRef(2);
                  
                  switch($642.termName) {
                  case "UnionType": {ESLVal $646 = $642.termRef(0);
                    ESLVal $645 = $642.termRef(1);
                    
                    {ESLVal _v854 = _v216;
                    
                    {ESLVal l = $644;
                    
                    {ESLVal state = $643;
                    
                    {ESLVal ul = $646;
                    
                    {ESLVal terms = $645;
                    
                    return typeEqual(_v854,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v855 = _v216;
                    
                    {ESLVal _v856 = _v217;
                    
                    return $false;
                  }
                  }
                }
                }
              case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                  ESLVal $638 = _v217.termRef(1);
                  ESLVal $637 = _v217.termRef(2);
                  
                  switch($637.termName) {
                  case "UnionType": {ESLVal $641 = $637.termRef(0);
                    ESLVal $640 = $637.termRef(1);
                    
                    {ESLVal _v851 = _v216;
                    
                    {ESLVal l = $639;
                    
                    {ESLVal state = $638;
                    
                    {ESLVal ul = $641;
                    
                    {ESLVal terms = $640;
                    
                    return typeEqual(_v851,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v852 = _v216;
                    
                    {ESLVal _v853 = _v217;
                    
                    return $false;
                  }
                  }
                }
                }
              case "TermType": {ESLVal $636 = _v217.termRef(0);
                  ESLVal $635 = _v217.termRef(1);
                  ESLVal $634 = _v217.termRef(2);
                  
                  {ESLVal _v850 = _v216;
                  
                  {ESLVal l2 = $636;
                  
                  {ESLVal n2 = $635;
                  
                  {ESLVal args2 = $634;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                  
                  {ESLVal _v849 = _v216;
                  
                  {ESLVal f = $633;
                  
                  return typeEqual(_v849,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $632 = _v217.termRef(0);
                  ESLVal $631 = _v217.termRef(1);
                  ESLVal $630 = _v217.termRef(2);
                  
                  {ESLVal _v847 = _v216;
                  
                  {ESLVal l2 = $632;
                  
                  {ESLVal n2 = $631;
                  
                  {ESLVal _v848 = $630;
                  
                  return typeEqual(_v847,substType(new ESLVal("RecType",l2,n2,_v848),n2,_v848));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $629 = _v217.termRef(0);
                  ESLVal $628 = _v217.termRef(1);
                  ESLVal $627 = _v217.termRef(2);
                  
                  {ESLVal _v845 = _v216;
                  
                  {ESLVal l1 = $629;
                  
                  {ESLVal ns2 = $628;
                  
                  {ESLVal _v846 = $627;
                  
                  return typeEqual(_v845,_v846);
                }
                }
                }
                }
                }
                default: {ESLVal _v860 = _v216;
                  
                  {ESLVal _v861 = _v217;
                  
                  return $false;
                }
                }
              }
            else switch(_v217.termName) {
                case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                  ESLVal $653 = _v217.termRef(1);
                  ESLVal $652 = _v217.termRef(2);
                  
                  {ESLVal _v876 = _v216;
                  
                  {ESLVal l = $654;
                  
                  {ESLVal op = $653;
                  
                  {ESLVal args = $652;
                  
                  return typeEqual(_v876,applyTypeFun(l,forceType(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                  ESLVal $650 = _v217.termRef(1);
                  ESLVal $649 = _v217.termRef(2);
                  ESLVal $648 = _v217.termRef(3);
                  
                  {ESLVal _v874 = _v216;
                  
                  {ESLVal l2 = $651;
                  
                  {ESLVal _v875 = $650;
                  
                  {ESLVal ds2 = $649;
                  
                  {ESLVal ms2 = $648;
                  
                  return typeEqual(_v874,flattenAct(l2,_v875,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $647 = _v217.termRef(0);
                  
                  {ESLVal t = _v216;
                  
                  {ESLVal l1 = $647;
                  
                  return $true;
                }
                }
                }
              case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                  ESLVal $643 = _v217.termRef(1);
                  ESLVal $642 = _v217.termRef(2);
                  
                  switch($642.termName) {
                  case "UnionType": {ESLVal $646 = $642.termRef(0);
                    ESLVal $645 = $642.termRef(1);
                    
                    {ESLVal _v871 = _v216;
                    
                    {ESLVal l = $644;
                    
                    {ESLVal state = $643;
                    
                    {ESLVal ul = $646;
                    
                    {ESLVal terms = $645;
                    
                    return typeEqual(_v871,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v872 = _v216;
                    
                    {ESLVal _v873 = _v217;
                    
                    return $false;
                  }
                  }
                }
                }
              case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                  ESLVal $638 = _v217.termRef(1);
                  ESLVal $637 = _v217.termRef(2);
                  
                  switch($637.termName) {
                  case "UnionType": {ESLVal $641 = $637.termRef(0);
                    ESLVal $640 = $637.termRef(1);
                    
                    {ESLVal _v868 = _v216;
                    
                    {ESLVal l = $639;
                    
                    {ESLVal state = $638;
                    
                    {ESLVal ul = $641;
                    
                    {ESLVal terms = $640;
                    
                    return typeEqual(_v868,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v869 = _v216;
                    
                    {ESLVal _v870 = _v217;
                    
                    return $false;
                  }
                  }
                }
                }
              case "TermType": {ESLVal $636 = _v217.termRef(0);
                  ESLVal $635 = _v217.termRef(1);
                  ESLVal $634 = _v217.termRef(2);
                  
                  {ESLVal _v867 = _v216;
                  
                  {ESLVal l2 = $636;
                  
                  {ESLVal n2 = $635;
                  
                  {ESLVal args2 = $634;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                  
                  {ESLVal _v866 = _v216;
                  
                  {ESLVal f = $633;
                  
                  return typeEqual(_v866,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $632 = _v217.termRef(0);
                  ESLVal $631 = _v217.termRef(1);
                  ESLVal $630 = _v217.termRef(2);
                  
                  {ESLVal _v864 = _v216;
                  
                  {ESLVal l2 = $632;
                  
                  {ESLVal n2 = $631;
                  
                  {ESLVal _v865 = $630;
                  
                  return typeEqual(_v864,substType(new ESLVal("RecType",l2,n2,_v865),n2,_v865));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $629 = _v217.termRef(0);
                  ESLVal $628 = _v217.termRef(1);
                  ESLVal $627 = _v217.termRef(2);
                  
                  {ESLVal _v862 = _v216;
                  
                  {ESLVal l1 = $629;
                  
                  {ESLVal ns2 = $628;
                  
                  {ESLVal _v863 = $627;
                  
                  return typeEqual(_v862,_v863);
                }
                }
                }
                }
                }
                default: {ESLVal _v877 = _v216;
                  
                  {ESLVal _v878 = _v217;
                  
                  return $false;
                }
                }
              }
            }
            default: switch(_v217.termName) {
              case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                ESLVal $653 = _v217.termRef(1);
                ESLVal $652 = _v217.termRef(2);
                
                {ESLVal _v895 = _v216;
                
                {ESLVal l = $654;
                
                {ESLVal op = $653;
                
                {ESLVal args = $652;
                
                return typeEqual(_v895,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                ESLVal $650 = _v217.termRef(1);
                ESLVal $649 = _v217.termRef(2);
                ESLVal $648 = _v217.termRef(3);
                
                {ESLVal _v893 = _v216;
                
                {ESLVal l2 = $651;
                
                {ESLVal _v894 = $650;
                
                {ESLVal ds2 = $649;
                
                {ESLVal ms2 = $648;
                
                return typeEqual(_v893,flattenAct(l2,_v894,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $647 = _v217.termRef(0);
                
                {ESLVal t = _v216;
                
                {ESLVal l1 = $647;
                
                return $true;
              }
              }
              }
            case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                ESLVal $643 = _v217.termRef(1);
                ESLVal $642 = _v217.termRef(2);
                
                switch($642.termName) {
                case "UnionType": {ESLVal $646 = $642.termRef(0);
                  ESLVal $645 = $642.termRef(1);
                  
                  {ESLVal _v890 = _v216;
                  
                  {ESLVal l = $644;
                  
                  {ESLVal state = $643;
                  
                  {ESLVal ul = $646;
                  
                  {ESLVal terms = $645;
                  
                  return typeEqual(_v890,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v891 = _v216;
                  
                  {ESLVal _v892 = _v217;
                  
                  return $false;
                }
                }
              }
              }
            case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                ESLVal $638 = _v217.termRef(1);
                ESLVal $637 = _v217.termRef(2);
                
                switch($637.termName) {
                case "UnionType": {ESLVal $641 = $637.termRef(0);
                  ESLVal $640 = $637.termRef(1);
                  
                  {ESLVal _v887 = _v216;
                  
                  {ESLVal l = $639;
                  
                  {ESLVal state = $638;
                  
                  {ESLVal ul = $641;
                  
                  {ESLVal terms = $640;
                  
                  return typeEqual(_v887,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v888 = _v216;
                  
                  {ESLVal _v889 = _v217;
                  
                  return $false;
                }
                }
              }
              }
            case "TermType": {ESLVal $636 = _v217.termRef(0);
                ESLVal $635 = _v217.termRef(1);
                ESLVal $634 = _v217.termRef(2);
                
                {ESLVal _v886 = _v216;
                
                {ESLVal l2 = $636;
                
                {ESLVal n2 = $635;
                
                {ESLVal args2 = $634;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                
                {ESLVal _v885 = _v216;
                
                {ESLVal f = $633;
                
                return typeEqual(_v885,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $632 = _v217.termRef(0);
                ESLVal $631 = _v217.termRef(1);
                ESLVal $630 = _v217.termRef(2);
                
                {ESLVal _v883 = _v216;
                
                {ESLVal l2 = $632;
                
                {ESLVal n2 = $631;
                
                {ESLVal _v884 = $630;
                
                return typeEqual(_v883,substType(new ESLVal("RecType",l2,n2,_v884),n2,_v884));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $629 = _v217.termRef(0);
                ESLVal $628 = _v217.termRef(1);
                ESLVal $627 = _v217.termRef(2);
                
                {ESLVal _v881 = _v216;
                
                {ESLVal l1 = $629;
                
                {ESLVal ns2 = $628;
                
                {ESLVal _v882 = $627;
                
                return typeEqual(_v881,_v882);
              }
              }
              }
              }
              }
              default: {ESLVal _v896 = _v216;
                
                {ESLVal _v897 = _v217;
                
                return $false;
              }
              }
            }
          }
          }
        case "BagType": {ESLVal $755 = _v216.termRef(0);
            ESLVal $754 = _v216.termRef(1);
            
            switch(_v217.termName) {
            case "BagType": {ESLVal $757 = _v217.termRef(0);
              ESLVal $756 = _v217.termRef(1);
              
              {ESLVal l1 = $755;
              
              {ESLVal _v735 = $754;
              
              {ESLVal l2 = $757;
              
              {ESLVal _v736 = $756;
              
              return typeEqual(_v735,_v736);
            }
            }
            }
            }
            }
            default: switch(_v217.termName) {
              case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                ESLVal $653 = _v217.termRef(1);
                ESLVal $652 = _v217.termRef(2);
                
                {ESLVal _v751 = _v216;
                
                {ESLVal l = $654;
                
                {ESLVal op = $653;
                
                {ESLVal args = $652;
                
                return typeEqual(_v751,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                ESLVal $650 = _v217.termRef(1);
                ESLVal $649 = _v217.termRef(2);
                ESLVal $648 = _v217.termRef(3);
                
                {ESLVal _v749 = _v216;
                
                {ESLVal l2 = $651;
                
                {ESLVal _v750 = $650;
                
                {ESLVal ds2 = $649;
                
                {ESLVal ms2 = $648;
                
                return typeEqual(_v749,flattenAct(l2,_v750,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $647 = _v217.termRef(0);
                
                {ESLVal t = _v216;
                
                {ESLVal l1 = $647;
                
                return $true;
              }
              }
              }
            case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                ESLVal $643 = _v217.termRef(1);
                ESLVal $642 = _v217.termRef(2);
                
                switch($642.termName) {
                case "UnionType": {ESLVal $646 = $642.termRef(0);
                  ESLVal $645 = $642.termRef(1);
                  
                  {ESLVal _v746 = _v216;
                  
                  {ESLVal l = $644;
                  
                  {ESLVal state = $643;
                  
                  {ESLVal ul = $646;
                  
                  {ESLVal terms = $645;
                  
                  return typeEqual(_v746,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v747 = _v216;
                  
                  {ESLVal _v748 = _v217;
                  
                  return $false;
                }
                }
              }
              }
            case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                ESLVal $638 = _v217.termRef(1);
                ESLVal $637 = _v217.termRef(2);
                
                switch($637.termName) {
                case "UnionType": {ESLVal $641 = $637.termRef(0);
                  ESLVal $640 = $637.termRef(1);
                  
                  {ESLVal _v743 = _v216;
                  
                  {ESLVal l = $639;
                  
                  {ESLVal state = $638;
                  
                  {ESLVal ul = $641;
                  
                  {ESLVal terms = $640;
                  
                  return typeEqual(_v743,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v744 = _v216;
                  
                  {ESLVal _v745 = _v217;
                  
                  return $false;
                }
                }
              }
              }
            case "TermType": {ESLVal $636 = _v217.termRef(0);
                ESLVal $635 = _v217.termRef(1);
                ESLVal $634 = _v217.termRef(2);
                
                {ESLVal _v742 = _v216;
                
                {ESLVal l2 = $636;
                
                {ESLVal n2 = $635;
                
                {ESLVal args2 = $634;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                
                {ESLVal _v741 = _v216;
                
                {ESLVal f = $633;
                
                return typeEqual(_v741,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $632 = _v217.termRef(0);
                ESLVal $631 = _v217.termRef(1);
                ESLVal $630 = _v217.termRef(2);
                
                {ESLVal _v739 = _v216;
                
                {ESLVal l2 = $632;
                
                {ESLVal n2 = $631;
                
                {ESLVal _v740 = $630;
                
                return typeEqual(_v739,substType(new ESLVal("RecType",l2,n2,_v740),n2,_v740));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $629 = _v217.termRef(0);
                ESLVal $628 = _v217.termRef(1);
                ESLVal $627 = _v217.termRef(2);
                
                {ESLVal _v737 = _v216;
                
                {ESLVal l1 = $629;
                
                {ESLVal ns2 = $628;
                
                {ESLVal _v738 = $627;
                
                return typeEqual(_v737,_v738);
              }
              }
              }
              }
              }
              default: {ESLVal _v752 = _v216;
                
                {ESLVal _v753 = _v217;
                
                return $false;
              }
              }
            }
          }
          }
        case "SetType": {ESLVal $740 = _v216.termRef(0);
            ESLVal $739 = _v216.termRef(1);
            
            switch(_v217.termName) {
            case "SetType": {ESLVal $753 = _v217.termRef(0);
              ESLVal $752 = _v217.termRef(1);
              
              {ESLVal l1 = $740;
              
              {ESLVal _v716 = $739;
              
              {ESLVal l2 = $753;
              
              {ESLVal _v717 = $752;
              
              return typeEqual(_v716,_v717);
            }
            }
            }
            }
            }
          case "ForallType": {ESLVal $743 = _v217.termRef(0);
              ESLVal $742 = _v217.termRef(1);
              ESLVal $741 = _v217.termRef(2);
              
              if($742.isCons())
              {ESLVal $744 = $742.head();
                ESLVal $745 = $742.tail();
                
                if($745.isCons())
                {ESLVal $746 = $745.head();
                  ESLVal $747 = $745.tail();
                  
                  switch(_v217.termName) {
                  case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                    ESLVal $653 = _v217.termRef(1);
                    ESLVal $652 = _v217.termRef(2);
                    
                    {ESLVal _v605 = _v216;
                    
                    {ESLVal l = $654;
                    
                    {ESLVal op = $653;
                    
                    {ESLVal args = $652;
                    
                    return typeEqual(_v605,applyTypeFun(l,forceType(op),args));
                  }
                  }
                  }
                  }
                  }
                case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                    ESLVal $650 = _v217.termRef(1);
                    ESLVal $649 = _v217.termRef(2);
                    ESLVal $648 = _v217.termRef(3);
                    
                    {ESLVal _v603 = _v216;
                    
                    {ESLVal l2 = $651;
                    
                    {ESLVal _v604 = $650;
                    
                    {ESLVal ds2 = $649;
                    
                    {ESLVal ms2 = $648;
                    
                    return typeEqual(_v603,flattenAct(l2,_v604,ds2,ms2));
                  }
                  }
                  }
                  }
                  }
                  }
                case "VoidType": {ESLVal $647 = _v217.termRef(0);
                    
                    {ESLVal t = _v216;
                    
                    {ESLVal l1 = $647;
                    
                    return $true;
                  }
                  }
                  }
                case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                    ESLVal $643 = _v217.termRef(1);
                    ESLVal $642 = _v217.termRef(2);
                    
                    switch($642.termName) {
                    case "UnionType": {ESLVal $646 = $642.termRef(0);
                      ESLVal $645 = $642.termRef(1);
                      
                      {ESLVal _v600 = _v216;
                      
                      {ESLVal l = $644;
                      
                      {ESLVal state = $643;
                      
                      {ESLVal ul = $646;
                      
                      {ESLVal terms = $645;
                      
                      return typeEqual(_v600,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                    }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal _v601 = _v216;
                      
                      {ESLVal _v602 = _v217;
                      
                      return $false;
                    }
                    }
                  }
                  }
                case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                    ESLVal $638 = _v217.termRef(1);
                    ESLVal $637 = _v217.termRef(2);
                    
                    switch($637.termName) {
                    case "UnionType": {ESLVal $641 = $637.termRef(0);
                      ESLVal $640 = $637.termRef(1);
                      
                      {ESLVal _v597 = _v216;
                      
                      {ESLVal l = $639;
                      
                      {ESLVal state = $638;
                      
                      {ESLVal ul = $641;
                      
                      {ESLVal terms = $640;
                      
                      return typeEqual(_v597,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                    }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal _v598 = _v216;
                      
                      {ESLVal _v599 = _v217;
                      
                      return $false;
                    }
                    }
                  }
                  }
                case "TermType": {ESLVal $636 = _v217.termRef(0);
                    ESLVal $635 = _v217.termRef(1);
                    ESLVal $634 = _v217.termRef(2);
                    
                    {ESLVal _v596 = _v216;
                    
                    {ESLVal l2 = $636;
                    
                    {ESLVal n2 = $635;
                    
                    {ESLVal args2 = $634;
                    
                    return $false;
                  }
                  }
                  }
                  }
                  }
                case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                    
                    {ESLVal _v595 = _v216;
                    
                    {ESLVal f = $633;
                    
                    return typeEqual(_v595,f.apply());
                  }
                  }
                  }
                case "RecType": {ESLVal $632 = _v217.termRef(0);
                    ESLVal $631 = _v217.termRef(1);
                    ESLVal $630 = _v217.termRef(2);
                    
                    {ESLVal _v593 = _v216;
                    
                    {ESLVal l2 = $632;
                    
                    {ESLVal n2 = $631;
                    
                    {ESLVal _v594 = $630;
                    
                    return typeEqual(_v593,substType(new ESLVal("RecType",l2,n2,_v594),n2,_v594));
                  }
                  }
                  }
                  }
                  }
                case "ForallType": {ESLVal $629 = _v217.termRef(0);
                    ESLVal $628 = _v217.termRef(1);
                    ESLVal $627 = _v217.termRef(2);
                    
                    {ESLVal _v591 = _v216;
                    
                    {ESLVal l1 = $629;
                    
                    {ESLVal ns2 = $628;
                    
                    {ESLVal _v592 = $627;
                    
                    return typeEqual(_v591,_v592);
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v606 = _v216;
                    
                    {ESLVal _v607 = _v217;
                    
                    return $false;
                  }
                  }
                }
                }
              else if($745.isNil())
                switch($741.termName) {
                  case "SetType": {ESLVal $749 = $741.termRef(0);
                    ESLVal $748 = $741.termRef(1);
                    
                    switch($748.termName) {
                    case "VarType": {ESLVal $751 = $748.termRef(0);
                      ESLVal $750 = $748.termRef(1);
                      
                      {ESLVal l1 = $740;
                      
                      {ESLVal _v608 = $739;
                      
                      {ESLVal l2 = $743;
                      
                      {ESLVal v1 = $744;
                      
                      {ESLVal l3 = $749;
                      
                      {ESLVal l4 = $751;
                      
                      {ESLVal v2 = $750;
                      
                      if(v1.eql(v2).boolVal)
                      return $true;
                      else
                        switch(_v217.termName) {
                          case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                            ESLVal $653 = _v217.termRef(1);
                            ESLVal $652 = _v217.termRef(2);
                            
                            {ESLVal _v628 = _v216;
                            
                            {ESLVal l = $654;
                            
                            {ESLVal op = $653;
                            
                            {ESLVal args = $652;
                            
                            return typeEqual(_v628,applyTypeFun(l,forceType(op),args));
                          }
                          }
                          }
                          }
                          }
                        case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                            ESLVal $650 = _v217.termRef(1);
                            ESLVal $649 = _v217.termRef(2);
                            ESLVal $648 = _v217.termRef(3);
                            
                            {ESLVal _v625 = _v216;
                            
                            {ESLVal _v626 = $651;
                            
                            {ESLVal _v627 = $650;
                            
                            {ESLVal ds2 = $649;
                            
                            {ESLVal ms2 = $648;
                            
                            return typeEqual(_v625,flattenAct(_v626,_v627,ds2,ms2));
                          }
                          }
                          }
                          }
                          }
                          }
                        case "VoidType": {ESLVal $647 = _v217.termRef(0);
                            
                            {ESLVal t = _v216;
                            
                            {ESLVal _v624 = $647;
                            
                            return $true;
                          }
                          }
                          }
                        case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                            ESLVal $643 = _v217.termRef(1);
                            ESLVal $642 = _v217.termRef(2);
                            
                            switch($642.termName) {
                            case "UnionType": {ESLVal $646 = $642.termRef(0);
                              ESLVal $645 = $642.termRef(1);
                              
                              {ESLVal _v621 = _v216;
                              
                              {ESLVal l = $644;
                              
                              {ESLVal state = $643;
                              
                              {ESLVal ul = $646;
                              
                              {ESLVal terms = $645;
                              
                              return typeEqual(_v621,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                            }
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v622 = _v216;
                              
                              {ESLVal _v623 = _v217;
                              
                              return $false;
                            }
                            }
                          }
                          }
                        case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                            ESLVal $638 = _v217.termRef(1);
                            ESLVal $637 = _v217.termRef(2);
                            
                            switch($637.termName) {
                            case "UnionType": {ESLVal $641 = $637.termRef(0);
                              ESLVal $640 = $637.termRef(1);
                              
                              {ESLVal _v618 = _v216;
                              
                              {ESLVal l = $639;
                              
                              {ESLVal state = $638;
                              
                              {ESLVal ul = $641;
                              
                              {ESLVal terms = $640;
                              
                              return typeEqual(_v618,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                            }
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v619 = _v216;
                              
                              {ESLVal _v620 = _v217;
                              
                              return $false;
                            }
                            }
                          }
                          }
                        case "TermType": {ESLVal $636 = _v217.termRef(0);
                            ESLVal $635 = _v217.termRef(1);
                            ESLVal $634 = _v217.termRef(2);
                            
                            {ESLVal _v616 = _v216;
                            
                            {ESLVal _v617 = $636;
                            
                            {ESLVal n2 = $635;
                            
                            {ESLVal args2 = $634;
                            
                            return $false;
                          }
                          }
                          }
                          }
                          }
                        case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                            
                            {ESLVal _v615 = _v216;
                            
                            {ESLVal f = $633;
                            
                            return typeEqual(_v615,f.apply());
                          }
                          }
                          }
                        case "RecType": {ESLVal $632 = _v217.termRef(0);
                            ESLVal $631 = _v217.termRef(1);
                            ESLVal $630 = _v217.termRef(2);
                            
                            {ESLVal _v612 = _v216;
                            
                            {ESLVal _v613 = $632;
                            
                            {ESLVal n2 = $631;
                            
                            {ESLVal _v614 = $630;
                            
                            return typeEqual(_v612,substType(new ESLVal("RecType",_v613,n2,_v614),n2,_v614));
                          }
                          }
                          }
                          }
                          }
                        case "ForallType": {ESLVal $629 = _v217.termRef(0);
                            ESLVal $628 = _v217.termRef(1);
                            ESLVal $627 = _v217.termRef(2);
                            
                            {ESLVal _v609 = _v216;
                            
                            {ESLVal _v610 = $629;
                            
                            {ESLVal ns2 = $628;
                            
                            {ESLVal _v611 = $627;
                            
                            return typeEqual(_v609,_v611);
                          }
                          }
                          }
                          }
                          }
                          default: {ESLVal _v629 = _v216;
                            
                            {ESLVal _v630 = _v217;
                            
                            return $false;
                          }
                          }
                        }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: switch(_v217.termName) {
                      case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                        ESLVal $653 = _v217.termRef(1);
                        ESLVal $652 = _v217.termRef(2);
                        
                        {ESLVal _v645 = _v216;
                        
                        {ESLVal l = $654;
                        
                        {ESLVal op = $653;
                        
                        {ESLVal args = $652;
                        
                        return typeEqual(_v645,applyTypeFun(l,forceType(op),args));
                      }
                      }
                      }
                      }
                      }
                    case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                        ESLVal $650 = _v217.termRef(1);
                        ESLVal $649 = _v217.termRef(2);
                        ESLVal $648 = _v217.termRef(3);
                        
                        {ESLVal _v643 = _v216;
                        
                        {ESLVal l2 = $651;
                        
                        {ESLVal _v644 = $650;
                        
                        {ESLVal ds2 = $649;
                        
                        {ESLVal ms2 = $648;
                        
                        return typeEqual(_v643,flattenAct(l2,_v644,ds2,ms2));
                      }
                      }
                      }
                      }
                      }
                      }
                    case "VoidType": {ESLVal $647 = _v217.termRef(0);
                        
                        {ESLVal t = _v216;
                        
                        {ESLVal l1 = $647;
                        
                        return $true;
                      }
                      }
                      }
                    case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                        ESLVal $643 = _v217.termRef(1);
                        ESLVal $642 = _v217.termRef(2);
                        
                        switch($642.termName) {
                        case "UnionType": {ESLVal $646 = $642.termRef(0);
                          ESLVal $645 = $642.termRef(1);
                          
                          {ESLVal _v640 = _v216;
                          
                          {ESLVal l = $644;
                          
                          {ESLVal state = $643;
                          
                          {ESLVal ul = $646;
                          
                          {ESLVal terms = $645;
                          
                          return typeEqual(_v640,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                        }
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal _v641 = _v216;
                          
                          {ESLVal _v642 = _v217;
                          
                          return $false;
                        }
                        }
                      }
                      }
                    case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                        ESLVal $638 = _v217.termRef(1);
                        ESLVal $637 = _v217.termRef(2);
                        
                        switch($637.termName) {
                        case "UnionType": {ESLVal $641 = $637.termRef(0);
                          ESLVal $640 = $637.termRef(1);
                          
                          {ESLVal _v637 = _v216;
                          
                          {ESLVal l = $639;
                          
                          {ESLVal state = $638;
                          
                          {ESLVal ul = $641;
                          
                          {ESLVal terms = $640;
                          
                          return typeEqual(_v637,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                        }
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal _v638 = _v216;
                          
                          {ESLVal _v639 = _v217;
                          
                          return $false;
                        }
                        }
                      }
                      }
                    case "TermType": {ESLVal $636 = _v217.termRef(0);
                        ESLVal $635 = _v217.termRef(1);
                        ESLVal $634 = _v217.termRef(2);
                        
                        {ESLVal _v636 = _v216;
                        
                        {ESLVal l2 = $636;
                        
                        {ESLVal n2 = $635;
                        
                        {ESLVal args2 = $634;
                        
                        return $false;
                      }
                      }
                      }
                      }
                      }
                    case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                        
                        {ESLVal _v635 = _v216;
                        
                        {ESLVal f = $633;
                        
                        return typeEqual(_v635,f.apply());
                      }
                      }
                      }
                    case "RecType": {ESLVal $632 = _v217.termRef(0);
                        ESLVal $631 = _v217.termRef(1);
                        ESLVal $630 = _v217.termRef(2);
                        
                        {ESLVal _v633 = _v216;
                        
                        {ESLVal l2 = $632;
                        
                        {ESLVal n2 = $631;
                        
                        {ESLVal _v634 = $630;
                        
                        return typeEqual(_v633,substType(new ESLVal("RecType",l2,n2,_v634),n2,_v634));
                      }
                      }
                      }
                      }
                      }
                    case "ForallType": {ESLVal $629 = _v217.termRef(0);
                        ESLVal $628 = _v217.termRef(1);
                        ESLVal $627 = _v217.termRef(2);
                        
                        {ESLVal _v631 = _v216;
                        
                        {ESLVal l1 = $629;
                        
                        {ESLVal ns2 = $628;
                        
                        {ESLVal _v632 = $627;
                        
                        return typeEqual(_v631,_v632);
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal _v646 = _v216;
                        
                        {ESLVal _v647 = _v217;
                        
                        return $false;
                      }
                      }
                    }
                  }
                  }
                  default: switch(_v217.termName) {
                    case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                      ESLVal $653 = _v217.termRef(1);
                      ESLVal $652 = _v217.termRef(2);
                      
                      {ESLVal _v662 = _v216;
                      
                      {ESLVal l = $654;
                      
                      {ESLVal op = $653;
                      
                      {ESLVal args = $652;
                      
                      return typeEqual(_v662,applyTypeFun(l,forceType(op),args));
                    }
                    }
                    }
                    }
                    }
                  case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                      ESLVal $650 = _v217.termRef(1);
                      ESLVal $649 = _v217.termRef(2);
                      ESLVal $648 = _v217.termRef(3);
                      
                      {ESLVal _v660 = _v216;
                      
                      {ESLVal l2 = $651;
                      
                      {ESLVal _v661 = $650;
                      
                      {ESLVal ds2 = $649;
                      
                      {ESLVal ms2 = $648;
                      
                      return typeEqual(_v660,flattenAct(l2,_v661,ds2,ms2));
                    }
                    }
                    }
                    }
                    }
                    }
                  case "VoidType": {ESLVal $647 = _v217.termRef(0);
                      
                      {ESLVal t = _v216;
                      
                      {ESLVal l1 = $647;
                      
                      return $true;
                    }
                    }
                    }
                  case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                      ESLVal $643 = _v217.termRef(1);
                      ESLVal $642 = _v217.termRef(2);
                      
                      switch($642.termName) {
                      case "UnionType": {ESLVal $646 = $642.termRef(0);
                        ESLVal $645 = $642.termRef(1);
                        
                        {ESLVal _v657 = _v216;
                        
                        {ESLVal l = $644;
                        
                        {ESLVal state = $643;
                        
                        {ESLVal ul = $646;
                        
                        {ESLVal terms = $645;
                        
                        return typeEqual(_v657,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                      }
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal _v658 = _v216;
                        
                        {ESLVal _v659 = _v217;
                        
                        return $false;
                      }
                      }
                    }
                    }
                  case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                      ESLVal $638 = _v217.termRef(1);
                      ESLVal $637 = _v217.termRef(2);
                      
                      switch($637.termName) {
                      case "UnionType": {ESLVal $641 = $637.termRef(0);
                        ESLVal $640 = $637.termRef(1);
                        
                        {ESLVal _v654 = _v216;
                        
                        {ESLVal l = $639;
                        
                        {ESLVal state = $638;
                        
                        {ESLVal ul = $641;
                        
                        {ESLVal terms = $640;
                        
                        return typeEqual(_v654,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                      }
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal _v655 = _v216;
                        
                        {ESLVal _v656 = _v217;
                        
                        return $false;
                      }
                      }
                    }
                    }
                  case "TermType": {ESLVal $636 = _v217.termRef(0);
                      ESLVal $635 = _v217.termRef(1);
                      ESLVal $634 = _v217.termRef(2);
                      
                      {ESLVal _v653 = _v216;
                      
                      {ESLVal l2 = $636;
                      
                      {ESLVal n2 = $635;
                      
                      {ESLVal args2 = $634;
                      
                      return $false;
                    }
                    }
                    }
                    }
                    }
                  case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                      
                      {ESLVal _v652 = _v216;
                      
                      {ESLVal f = $633;
                      
                      return typeEqual(_v652,f.apply());
                    }
                    }
                    }
                  case "RecType": {ESLVal $632 = _v217.termRef(0);
                      ESLVal $631 = _v217.termRef(1);
                      ESLVal $630 = _v217.termRef(2);
                      
                      {ESLVal _v650 = _v216;
                      
                      {ESLVal l2 = $632;
                      
                      {ESLVal n2 = $631;
                      
                      {ESLVal _v651 = $630;
                      
                      return typeEqual(_v650,substType(new ESLVal("RecType",l2,n2,_v651),n2,_v651));
                    }
                    }
                    }
                    }
                    }
                  case "ForallType": {ESLVal $629 = _v217.termRef(0);
                      ESLVal $628 = _v217.termRef(1);
                      ESLVal $627 = _v217.termRef(2);
                      
                      {ESLVal _v648 = _v216;
                      
                      {ESLVal l1 = $629;
                      
                      {ESLVal ns2 = $628;
                      
                      {ESLVal _v649 = $627;
                      
                      return typeEqual(_v648,_v649);
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal _v663 = _v216;
                      
                      {ESLVal _v664 = _v217;
                      
                      return $false;
                    }
                    }
                  }
                }
              else switch(_v217.termName) {
                  case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                    ESLVal $653 = _v217.termRef(1);
                    ESLVal $652 = _v217.termRef(2);
                    
                    {ESLVal _v679 = _v216;
                    
                    {ESLVal l = $654;
                    
                    {ESLVal op = $653;
                    
                    {ESLVal args = $652;
                    
                    return typeEqual(_v679,applyTypeFun(l,forceType(op),args));
                  }
                  }
                  }
                  }
                  }
                case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                    ESLVal $650 = _v217.termRef(1);
                    ESLVal $649 = _v217.termRef(2);
                    ESLVal $648 = _v217.termRef(3);
                    
                    {ESLVal _v677 = _v216;
                    
                    {ESLVal l2 = $651;
                    
                    {ESLVal _v678 = $650;
                    
                    {ESLVal ds2 = $649;
                    
                    {ESLVal ms2 = $648;
                    
                    return typeEqual(_v677,flattenAct(l2,_v678,ds2,ms2));
                  }
                  }
                  }
                  }
                  }
                  }
                case "VoidType": {ESLVal $647 = _v217.termRef(0);
                    
                    {ESLVal t = _v216;
                    
                    {ESLVal l1 = $647;
                    
                    return $true;
                  }
                  }
                  }
                case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                    ESLVal $643 = _v217.termRef(1);
                    ESLVal $642 = _v217.termRef(2);
                    
                    switch($642.termName) {
                    case "UnionType": {ESLVal $646 = $642.termRef(0);
                      ESLVal $645 = $642.termRef(1);
                      
                      {ESLVal _v674 = _v216;
                      
                      {ESLVal l = $644;
                      
                      {ESLVal state = $643;
                      
                      {ESLVal ul = $646;
                      
                      {ESLVal terms = $645;
                      
                      return typeEqual(_v674,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                    }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal _v675 = _v216;
                      
                      {ESLVal _v676 = _v217;
                      
                      return $false;
                    }
                    }
                  }
                  }
                case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                    ESLVal $638 = _v217.termRef(1);
                    ESLVal $637 = _v217.termRef(2);
                    
                    switch($637.termName) {
                    case "UnionType": {ESLVal $641 = $637.termRef(0);
                      ESLVal $640 = $637.termRef(1);
                      
                      {ESLVal _v671 = _v216;
                      
                      {ESLVal l = $639;
                      
                      {ESLVal state = $638;
                      
                      {ESLVal ul = $641;
                      
                      {ESLVal terms = $640;
                      
                      return typeEqual(_v671,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                    }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal _v672 = _v216;
                      
                      {ESLVal _v673 = _v217;
                      
                      return $false;
                    }
                    }
                  }
                  }
                case "TermType": {ESLVal $636 = _v217.termRef(0);
                    ESLVal $635 = _v217.termRef(1);
                    ESLVal $634 = _v217.termRef(2);
                    
                    {ESLVal _v670 = _v216;
                    
                    {ESLVal l2 = $636;
                    
                    {ESLVal n2 = $635;
                    
                    {ESLVal args2 = $634;
                    
                    return $false;
                  }
                  }
                  }
                  }
                  }
                case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                    
                    {ESLVal _v669 = _v216;
                    
                    {ESLVal f = $633;
                    
                    return typeEqual(_v669,f.apply());
                  }
                  }
                  }
                case "RecType": {ESLVal $632 = _v217.termRef(0);
                    ESLVal $631 = _v217.termRef(1);
                    ESLVal $630 = _v217.termRef(2);
                    
                    {ESLVal _v667 = _v216;
                    
                    {ESLVal l2 = $632;
                    
                    {ESLVal n2 = $631;
                    
                    {ESLVal _v668 = $630;
                    
                    return typeEqual(_v667,substType(new ESLVal("RecType",l2,n2,_v668),n2,_v668));
                  }
                  }
                  }
                  }
                  }
                case "ForallType": {ESLVal $629 = _v217.termRef(0);
                    ESLVal $628 = _v217.termRef(1);
                    ESLVal $627 = _v217.termRef(2);
                    
                    {ESLVal _v665 = _v216;
                    
                    {ESLVal l1 = $629;
                    
                    {ESLVal ns2 = $628;
                    
                    {ESLVal _v666 = $627;
                    
                    return typeEqual(_v665,_v666);
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v680 = _v216;
                    
                    {ESLVal _v681 = _v217;
                    
                    return $false;
                  }
                  }
                }
              }
            else if($742.isNil())
              switch(_v217.termName) {
                case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                  ESLVal $653 = _v217.termRef(1);
                  ESLVal $652 = _v217.termRef(2);
                  
                  {ESLVal _v696 = _v216;
                  
                  {ESLVal l = $654;
                  
                  {ESLVal op = $653;
                  
                  {ESLVal args = $652;
                  
                  return typeEqual(_v696,applyTypeFun(l,forceType(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                  ESLVal $650 = _v217.termRef(1);
                  ESLVal $649 = _v217.termRef(2);
                  ESLVal $648 = _v217.termRef(3);
                  
                  {ESLVal _v694 = _v216;
                  
                  {ESLVal l2 = $651;
                  
                  {ESLVal _v695 = $650;
                  
                  {ESLVal ds2 = $649;
                  
                  {ESLVal ms2 = $648;
                  
                  return typeEqual(_v694,flattenAct(l2,_v695,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $647 = _v217.termRef(0);
                  
                  {ESLVal t = _v216;
                  
                  {ESLVal l1 = $647;
                  
                  return $true;
                }
                }
                }
              case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                  ESLVal $643 = _v217.termRef(1);
                  ESLVal $642 = _v217.termRef(2);
                  
                  switch($642.termName) {
                  case "UnionType": {ESLVal $646 = $642.termRef(0);
                    ESLVal $645 = $642.termRef(1);
                    
                    {ESLVal _v691 = _v216;
                    
                    {ESLVal l = $644;
                    
                    {ESLVal state = $643;
                    
                    {ESLVal ul = $646;
                    
                    {ESLVal terms = $645;
                    
                    return typeEqual(_v691,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v692 = _v216;
                    
                    {ESLVal _v693 = _v217;
                    
                    return $false;
                  }
                  }
                }
                }
              case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                  ESLVal $638 = _v217.termRef(1);
                  ESLVal $637 = _v217.termRef(2);
                  
                  switch($637.termName) {
                  case "UnionType": {ESLVal $641 = $637.termRef(0);
                    ESLVal $640 = $637.termRef(1);
                    
                    {ESLVal _v688 = _v216;
                    
                    {ESLVal l = $639;
                    
                    {ESLVal state = $638;
                    
                    {ESLVal ul = $641;
                    
                    {ESLVal terms = $640;
                    
                    return typeEqual(_v688,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v689 = _v216;
                    
                    {ESLVal _v690 = _v217;
                    
                    return $false;
                  }
                  }
                }
                }
              case "TermType": {ESLVal $636 = _v217.termRef(0);
                  ESLVal $635 = _v217.termRef(1);
                  ESLVal $634 = _v217.termRef(2);
                  
                  {ESLVal _v687 = _v216;
                  
                  {ESLVal l2 = $636;
                  
                  {ESLVal n2 = $635;
                  
                  {ESLVal args2 = $634;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                  
                  {ESLVal _v686 = _v216;
                  
                  {ESLVal f = $633;
                  
                  return typeEqual(_v686,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $632 = _v217.termRef(0);
                  ESLVal $631 = _v217.termRef(1);
                  ESLVal $630 = _v217.termRef(2);
                  
                  {ESLVal _v684 = _v216;
                  
                  {ESLVal l2 = $632;
                  
                  {ESLVal n2 = $631;
                  
                  {ESLVal _v685 = $630;
                  
                  return typeEqual(_v684,substType(new ESLVal("RecType",l2,n2,_v685),n2,_v685));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $629 = _v217.termRef(0);
                  ESLVal $628 = _v217.termRef(1);
                  ESLVal $627 = _v217.termRef(2);
                  
                  {ESLVal _v682 = _v216;
                  
                  {ESLVal l1 = $629;
                  
                  {ESLVal ns2 = $628;
                  
                  {ESLVal _v683 = $627;
                  
                  return typeEqual(_v682,_v683);
                }
                }
                }
                }
                }
                default: {ESLVal _v697 = _v216;
                  
                  {ESLVal _v698 = _v217;
                  
                  return $false;
                }
                }
              }
            else switch(_v217.termName) {
                case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                  ESLVal $653 = _v217.termRef(1);
                  ESLVal $652 = _v217.termRef(2);
                  
                  {ESLVal _v713 = _v216;
                  
                  {ESLVal l = $654;
                  
                  {ESLVal op = $653;
                  
                  {ESLVal args = $652;
                  
                  return typeEqual(_v713,applyTypeFun(l,forceType(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                  ESLVal $650 = _v217.termRef(1);
                  ESLVal $649 = _v217.termRef(2);
                  ESLVal $648 = _v217.termRef(3);
                  
                  {ESLVal _v711 = _v216;
                  
                  {ESLVal l2 = $651;
                  
                  {ESLVal _v712 = $650;
                  
                  {ESLVal ds2 = $649;
                  
                  {ESLVal ms2 = $648;
                  
                  return typeEqual(_v711,flattenAct(l2,_v712,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $647 = _v217.termRef(0);
                  
                  {ESLVal t = _v216;
                  
                  {ESLVal l1 = $647;
                  
                  return $true;
                }
                }
                }
              case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                  ESLVal $643 = _v217.termRef(1);
                  ESLVal $642 = _v217.termRef(2);
                  
                  switch($642.termName) {
                  case "UnionType": {ESLVal $646 = $642.termRef(0);
                    ESLVal $645 = $642.termRef(1);
                    
                    {ESLVal _v708 = _v216;
                    
                    {ESLVal l = $644;
                    
                    {ESLVal state = $643;
                    
                    {ESLVal ul = $646;
                    
                    {ESLVal terms = $645;
                    
                    return typeEqual(_v708,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v709 = _v216;
                    
                    {ESLVal _v710 = _v217;
                    
                    return $false;
                  }
                  }
                }
                }
              case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                  ESLVal $638 = _v217.termRef(1);
                  ESLVal $637 = _v217.termRef(2);
                  
                  switch($637.termName) {
                  case "UnionType": {ESLVal $641 = $637.termRef(0);
                    ESLVal $640 = $637.termRef(1);
                    
                    {ESLVal _v705 = _v216;
                    
                    {ESLVal l = $639;
                    
                    {ESLVal state = $638;
                    
                    {ESLVal ul = $641;
                    
                    {ESLVal terms = $640;
                    
                    return typeEqual(_v705,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v706 = _v216;
                    
                    {ESLVal _v707 = _v217;
                    
                    return $false;
                  }
                  }
                }
                }
              case "TermType": {ESLVal $636 = _v217.termRef(0);
                  ESLVal $635 = _v217.termRef(1);
                  ESLVal $634 = _v217.termRef(2);
                  
                  {ESLVal _v704 = _v216;
                  
                  {ESLVal l2 = $636;
                  
                  {ESLVal n2 = $635;
                  
                  {ESLVal args2 = $634;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                  
                  {ESLVal _v703 = _v216;
                  
                  {ESLVal f = $633;
                  
                  return typeEqual(_v703,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $632 = _v217.termRef(0);
                  ESLVal $631 = _v217.termRef(1);
                  ESLVal $630 = _v217.termRef(2);
                  
                  {ESLVal _v701 = _v216;
                  
                  {ESLVal l2 = $632;
                  
                  {ESLVal n2 = $631;
                  
                  {ESLVal _v702 = $630;
                  
                  return typeEqual(_v701,substType(new ESLVal("RecType",l2,n2,_v702),n2,_v702));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $629 = _v217.termRef(0);
                  ESLVal $628 = _v217.termRef(1);
                  ESLVal $627 = _v217.termRef(2);
                  
                  {ESLVal _v699 = _v216;
                  
                  {ESLVal l1 = $629;
                  
                  {ESLVal ns2 = $628;
                  
                  {ESLVal _v700 = $627;
                  
                  return typeEqual(_v699,_v700);
                }
                }
                }
                }
                }
                default: {ESLVal _v714 = _v216;
                  
                  {ESLVal _v715 = _v217;
                  
                  return $false;
                }
                }
              }
            }
            default: switch(_v217.termName) {
              case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                ESLVal $653 = _v217.termRef(1);
                ESLVal $652 = _v217.termRef(2);
                
                {ESLVal _v732 = _v216;
                
                {ESLVal l = $654;
                
                {ESLVal op = $653;
                
                {ESLVal args = $652;
                
                return typeEqual(_v732,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                ESLVal $650 = _v217.termRef(1);
                ESLVal $649 = _v217.termRef(2);
                ESLVal $648 = _v217.termRef(3);
                
                {ESLVal _v730 = _v216;
                
                {ESLVal l2 = $651;
                
                {ESLVal _v731 = $650;
                
                {ESLVal ds2 = $649;
                
                {ESLVal ms2 = $648;
                
                return typeEqual(_v730,flattenAct(l2,_v731,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $647 = _v217.termRef(0);
                
                {ESLVal t = _v216;
                
                {ESLVal l1 = $647;
                
                return $true;
              }
              }
              }
            case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                ESLVal $643 = _v217.termRef(1);
                ESLVal $642 = _v217.termRef(2);
                
                switch($642.termName) {
                case "UnionType": {ESLVal $646 = $642.termRef(0);
                  ESLVal $645 = $642.termRef(1);
                  
                  {ESLVal _v727 = _v216;
                  
                  {ESLVal l = $644;
                  
                  {ESLVal state = $643;
                  
                  {ESLVal ul = $646;
                  
                  {ESLVal terms = $645;
                  
                  return typeEqual(_v727,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v728 = _v216;
                  
                  {ESLVal _v729 = _v217;
                  
                  return $false;
                }
                }
              }
              }
            case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                ESLVal $638 = _v217.termRef(1);
                ESLVal $637 = _v217.termRef(2);
                
                switch($637.termName) {
                case "UnionType": {ESLVal $641 = $637.termRef(0);
                  ESLVal $640 = $637.termRef(1);
                  
                  {ESLVal _v724 = _v216;
                  
                  {ESLVal l = $639;
                  
                  {ESLVal state = $638;
                  
                  {ESLVal ul = $641;
                  
                  {ESLVal terms = $640;
                  
                  return typeEqual(_v724,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v725 = _v216;
                  
                  {ESLVal _v726 = _v217;
                  
                  return $false;
                }
                }
              }
              }
            case "TermType": {ESLVal $636 = _v217.termRef(0);
                ESLVal $635 = _v217.termRef(1);
                ESLVal $634 = _v217.termRef(2);
                
                {ESLVal _v723 = _v216;
                
                {ESLVal l2 = $636;
                
                {ESLVal n2 = $635;
                
                {ESLVal args2 = $634;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                
                {ESLVal _v722 = _v216;
                
                {ESLVal f = $633;
                
                return typeEqual(_v722,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $632 = _v217.termRef(0);
                ESLVal $631 = _v217.termRef(1);
                ESLVal $630 = _v217.termRef(2);
                
                {ESLVal _v720 = _v216;
                
                {ESLVal l2 = $632;
                
                {ESLVal n2 = $631;
                
                {ESLVal _v721 = $630;
                
                return typeEqual(_v720,substType(new ESLVal("RecType",l2,n2,_v721),n2,_v721));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $629 = _v217.termRef(0);
                ESLVal $628 = _v217.termRef(1);
                ESLVal $627 = _v217.termRef(2);
                
                {ESLVal _v718 = _v216;
                
                {ESLVal l1 = $629;
                
                {ESLVal ns2 = $628;
                
                {ESLVal _v719 = $627;
                
                return typeEqual(_v718,_v719);
              }
              }
              }
              }
              }
              default: {ESLVal _v733 = _v216;
                
                {ESLVal _v734 = _v217;
                
                return $false;
              }
              }
            }
          }
          }
        case "StrType": {ESLVal $737 = _v216.termRef(0);
            
            switch(_v217.termName) {
            case "StrType": {ESLVal $738 = _v217.termRef(0);
              
              {ESLVal l1 = $737;
              
              {ESLVal l2 = $738;
              
              return $true;
            }
            }
            }
            default: switch(_v217.termName) {
              case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                ESLVal $653 = _v217.termRef(1);
                ESLVal $652 = _v217.termRef(2);
                
                {ESLVal _v588 = _v216;
                
                {ESLVal l = $654;
                
                {ESLVal op = $653;
                
                {ESLVal args = $652;
                
                return typeEqual(_v588,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                ESLVal $650 = _v217.termRef(1);
                ESLVal $649 = _v217.termRef(2);
                ESLVal $648 = _v217.termRef(3);
                
                {ESLVal _v586 = _v216;
                
                {ESLVal l2 = $651;
                
                {ESLVal _v587 = $650;
                
                {ESLVal ds2 = $649;
                
                {ESLVal ms2 = $648;
                
                return typeEqual(_v586,flattenAct(l2,_v587,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $647 = _v217.termRef(0);
                
                {ESLVal t = _v216;
                
                {ESLVal l1 = $647;
                
                return $true;
              }
              }
              }
            case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                ESLVal $643 = _v217.termRef(1);
                ESLVal $642 = _v217.termRef(2);
                
                switch($642.termName) {
                case "UnionType": {ESLVal $646 = $642.termRef(0);
                  ESLVal $645 = $642.termRef(1);
                  
                  {ESLVal _v583 = _v216;
                  
                  {ESLVal l = $644;
                  
                  {ESLVal state = $643;
                  
                  {ESLVal ul = $646;
                  
                  {ESLVal terms = $645;
                  
                  return typeEqual(_v583,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v584 = _v216;
                  
                  {ESLVal _v585 = _v217;
                  
                  return $false;
                }
                }
              }
              }
            case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                ESLVal $638 = _v217.termRef(1);
                ESLVal $637 = _v217.termRef(2);
                
                switch($637.termName) {
                case "UnionType": {ESLVal $641 = $637.termRef(0);
                  ESLVal $640 = $637.termRef(1);
                  
                  {ESLVal _v580 = _v216;
                  
                  {ESLVal l = $639;
                  
                  {ESLVal state = $638;
                  
                  {ESLVal ul = $641;
                  
                  {ESLVal terms = $640;
                  
                  return typeEqual(_v580,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v581 = _v216;
                  
                  {ESLVal _v582 = _v217;
                  
                  return $false;
                }
                }
              }
              }
            case "TermType": {ESLVal $636 = _v217.termRef(0);
                ESLVal $635 = _v217.termRef(1);
                ESLVal $634 = _v217.termRef(2);
                
                {ESLVal _v579 = _v216;
                
                {ESLVal l2 = $636;
                
                {ESLVal n2 = $635;
                
                {ESLVal args2 = $634;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                
                {ESLVal _v578 = _v216;
                
                {ESLVal f = $633;
                
                return typeEqual(_v578,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $632 = _v217.termRef(0);
                ESLVal $631 = _v217.termRef(1);
                ESLVal $630 = _v217.termRef(2);
                
                {ESLVal _v576 = _v216;
                
                {ESLVal l2 = $632;
                
                {ESLVal n2 = $631;
                
                {ESLVal _v577 = $630;
                
                return typeEqual(_v576,substType(new ESLVal("RecType",l2,n2,_v577),n2,_v577));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $629 = _v217.termRef(0);
                ESLVal $628 = _v217.termRef(1);
                ESLVal $627 = _v217.termRef(2);
                
                {ESLVal _v574 = _v216;
                
                {ESLVal l1 = $629;
                
                {ESLVal ns2 = $628;
                
                {ESLVal _v575 = $627;
                
                return typeEqual(_v574,_v575);
              }
              }
              }
              }
              }
              default: {ESLVal _v589 = _v216;
                
                {ESLVal _v590 = _v217;
                
                return $false;
              }
              }
            }
          }
          }
        case "VoidType": {ESLVal $736 = _v216.termRef(0);
            
            {ESLVal l1 = $736;
            
            {ESLVal t = _v217;
            
            return $true;
          }
          }
          }
        case "FieldType": {ESLVal $732 = _v216.termRef(0);
            ESLVal $731 = _v216.termRef(1);
            ESLVal $730 = _v216.termRef(2);
            
            switch(_v217.termName) {
            case "FieldType": {ESLVal $735 = _v217.termRef(0);
              ESLVal $734 = _v217.termRef(1);
              ESLVal $733 = _v217.termRef(2);
              
              {ESLVal l1 = $732;
              
              {ESLVal n1 = $731;
              
              {ESLVal _v555 = $730;
              
              {ESLVal l2 = $735;
              
              {ESLVal n2 = $734;
              
              {ESLVal _v556 = $733;
              
              return n1.eql(n2).and(typeEqual(_v555,_v556));
            }
            }
            }
            }
            }
            }
            }
            default: switch(_v217.termName) {
              case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                ESLVal $653 = _v217.termRef(1);
                ESLVal $652 = _v217.termRef(2);
                
                {ESLVal _v571 = _v216;
                
                {ESLVal l = $654;
                
                {ESLVal op = $653;
                
                {ESLVal args = $652;
                
                return typeEqual(_v571,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                ESLVal $650 = _v217.termRef(1);
                ESLVal $649 = _v217.termRef(2);
                ESLVal $648 = _v217.termRef(3);
                
                {ESLVal _v569 = _v216;
                
                {ESLVal l2 = $651;
                
                {ESLVal _v570 = $650;
                
                {ESLVal ds2 = $649;
                
                {ESLVal ms2 = $648;
                
                return typeEqual(_v569,flattenAct(l2,_v570,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $647 = _v217.termRef(0);
                
                {ESLVal t = _v216;
                
                {ESLVal l1 = $647;
                
                return $true;
              }
              }
              }
            case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                ESLVal $643 = _v217.termRef(1);
                ESLVal $642 = _v217.termRef(2);
                
                switch($642.termName) {
                case "UnionType": {ESLVal $646 = $642.termRef(0);
                  ESLVal $645 = $642.termRef(1);
                  
                  {ESLVal _v566 = _v216;
                  
                  {ESLVal l = $644;
                  
                  {ESLVal state = $643;
                  
                  {ESLVal ul = $646;
                  
                  {ESLVal terms = $645;
                  
                  return typeEqual(_v566,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v567 = _v216;
                  
                  {ESLVal _v568 = _v217;
                  
                  return $false;
                }
                }
              }
              }
            case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                ESLVal $638 = _v217.termRef(1);
                ESLVal $637 = _v217.termRef(2);
                
                switch($637.termName) {
                case "UnionType": {ESLVal $641 = $637.termRef(0);
                  ESLVal $640 = $637.termRef(1);
                  
                  {ESLVal _v563 = _v216;
                  
                  {ESLVal l = $639;
                  
                  {ESLVal state = $638;
                  
                  {ESLVal ul = $641;
                  
                  {ESLVal terms = $640;
                  
                  return typeEqual(_v563,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v564 = _v216;
                  
                  {ESLVal _v565 = _v217;
                  
                  return $false;
                }
                }
              }
              }
            case "TermType": {ESLVal $636 = _v217.termRef(0);
                ESLVal $635 = _v217.termRef(1);
                ESLVal $634 = _v217.termRef(2);
                
                {ESLVal _v562 = _v216;
                
                {ESLVal l2 = $636;
                
                {ESLVal n2 = $635;
                
                {ESLVal args2 = $634;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                
                {ESLVal _v561 = _v216;
                
                {ESLVal f = $633;
                
                return typeEqual(_v561,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $632 = _v217.termRef(0);
                ESLVal $631 = _v217.termRef(1);
                ESLVal $630 = _v217.termRef(2);
                
                {ESLVal _v559 = _v216;
                
                {ESLVal l2 = $632;
                
                {ESLVal n2 = $631;
                
                {ESLVal _v560 = $630;
                
                return typeEqual(_v559,substType(new ESLVal("RecType",l2,n2,_v560),n2,_v560));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $629 = _v217.termRef(0);
                ESLVal $628 = _v217.termRef(1);
                ESLVal $627 = _v217.termRef(2);
                
                {ESLVal _v557 = _v216;
                
                {ESLVal l1 = $629;
                
                {ESLVal ns2 = $628;
                
                {ESLVal _v558 = $627;
                
                return typeEqual(_v557,_v558);
              }
              }
              }
              }
              }
              default: {ESLVal _v572 = _v216;
                
                {ESLVal _v573 = _v217;
                
                return $false;
              }
              }
            }
          }
          }
        case "ObservedType": {ESLVal $724 = _v216.termRef(0);
            ESLVal $723 = _v216.termRef(1);
            ESLVal $722 = _v216.termRef(2);
            
            switch($722.termName) {
            case "UnionType": {ESLVal $729 = $722.termRef(0);
              ESLVal $728 = $722.termRef(1);
              
              {ESLVal l = $724;
              
              {ESLVal state = $723;
              
              {ESLVal ul = $729;
              
              {ESLVal terms = $728;
              
              {ESLVal _v537 = _v217;
              
              return typeEqual(expandObservedType(l,state,new ESLVal("UnionType",ul,terms)),_v537);
            }
            }
            }
            }
            }
            }
            default: switch(_v217.termName) {
              case "ObservedType": {ESLVal $727 = _v217.termRef(0);
                ESLVal $726 = _v217.termRef(1);
                ESLVal $725 = _v217.termRef(2);
                
                {ESLVal l1 = $724;
                
                {ESLVal s1 = $723;
                
                {ESLVal m1 = $722;
                
                {ESLVal l2 = $727;
                
                {ESLVal s2 = $726;
                
                {ESLVal m2 = $725;
                
                return typeEqual(s1,s2).and(typeEqual(m1,m2));
              }
              }
              }
              }
              }
              }
              }
              default: switch(_v217.termName) {
                case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                  ESLVal $653 = _v217.termRef(1);
                  ESLVal $652 = _v217.termRef(2);
                  
                  {ESLVal _v552 = _v216;
                  
                  {ESLVal l = $654;
                  
                  {ESLVal op = $653;
                  
                  {ESLVal args = $652;
                  
                  return typeEqual(_v552,applyTypeFun(l,forceType(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                  ESLVal $650 = _v217.termRef(1);
                  ESLVal $649 = _v217.termRef(2);
                  ESLVal $648 = _v217.termRef(3);
                  
                  {ESLVal _v550 = _v216;
                  
                  {ESLVal l2 = $651;
                  
                  {ESLVal _v551 = $650;
                  
                  {ESLVal ds2 = $649;
                  
                  {ESLVal ms2 = $648;
                  
                  return typeEqual(_v550,flattenAct(l2,_v551,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $647 = _v217.termRef(0);
                  
                  {ESLVal t = _v216;
                  
                  {ESLVal l1 = $647;
                  
                  return $true;
                }
                }
                }
              case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                  ESLVal $643 = _v217.termRef(1);
                  ESLVal $642 = _v217.termRef(2);
                  
                  switch($642.termName) {
                  case "UnionType": {ESLVal $646 = $642.termRef(0);
                    ESLVal $645 = $642.termRef(1);
                    
                    {ESLVal _v547 = _v216;
                    
                    {ESLVal l = $644;
                    
                    {ESLVal state = $643;
                    
                    {ESLVal ul = $646;
                    
                    {ESLVal terms = $645;
                    
                    return typeEqual(_v547,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v548 = _v216;
                    
                    {ESLVal _v549 = _v217;
                    
                    return $false;
                  }
                  }
                }
                }
              case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                  ESLVal $638 = _v217.termRef(1);
                  ESLVal $637 = _v217.termRef(2);
                  
                  switch($637.termName) {
                  case "UnionType": {ESLVal $641 = $637.termRef(0);
                    ESLVal $640 = $637.termRef(1);
                    
                    {ESLVal _v544 = _v216;
                    
                    {ESLVal l = $639;
                    
                    {ESLVal state = $638;
                    
                    {ESLVal ul = $641;
                    
                    {ESLVal terms = $640;
                    
                    return typeEqual(_v544,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v545 = _v216;
                    
                    {ESLVal _v546 = _v217;
                    
                    return $false;
                  }
                  }
                }
                }
              case "TermType": {ESLVal $636 = _v217.termRef(0);
                  ESLVal $635 = _v217.termRef(1);
                  ESLVal $634 = _v217.termRef(2);
                  
                  {ESLVal _v543 = _v216;
                  
                  {ESLVal l2 = $636;
                  
                  {ESLVal n2 = $635;
                  
                  {ESLVal args2 = $634;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                  
                  {ESLVal _v542 = _v216;
                  
                  {ESLVal f = $633;
                  
                  return typeEqual(_v542,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $632 = _v217.termRef(0);
                  ESLVal $631 = _v217.termRef(1);
                  ESLVal $630 = _v217.termRef(2);
                  
                  {ESLVal _v540 = _v216;
                  
                  {ESLVal l2 = $632;
                  
                  {ESLVal n2 = $631;
                  
                  {ESLVal _v541 = $630;
                  
                  return typeEqual(_v540,substType(new ESLVal("RecType",l2,n2,_v541),n2,_v541));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $629 = _v217.termRef(0);
                  ESLVal $628 = _v217.termRef(1);
                  ESLVal $627 = _v217.termRef(2);
                  
                  {ESLVal _v538 = _v216;
                  
                  {ESLVal l1 = $629;
                  
                  {ESLVal ns2 = $628;
                  
                  {ESLVal _v539 = $627;
                  
                  return typeEqual(_v538,_v539);
                }
                }
                }
                }
                }
                default: {ESLVal _v553 = _v216;
                  
                  {ESLVal _v554 = _v217;
                  
                  return $false;
                }
                }
              }
            }
          }
          }
        case "ObserverType": {ESLVal $716 = _v216.termRef(0);
            ESLVal $715 = _v216.termRef(1);
            ESLVal $714 = _v216.termRef(2);
            
            switch($714.termName) {
            case "UnionType": {ESLVal $721 = $714.termRef(0);
              ESLVal $720 = $714.termRef(1);
              
              {ESLVal l = $716;
              
              {ESLVal state = $715;
              
              {ESLVal ul = $721;
              
              {ESLVal terms = $720;
              
              {ESLVal _v519 = _v217;
              
              return typeEqual(expandObserverType(l,state,new ESLVal("UnionType",ul,terms)),_v519);
            }
            }
            }
            }
            }
            }
            default: switch(_v217.termName) {
              case "ObserverType": {ESLVal $719 = _v217.termRef(0);
                ESLVal $718 = _v217.termRef(1);
                ESLVal $717 = _v217.termRef(2);
                
                {ESLVal l1 = $716;
                
                {ESLVal state1 = $715;
                
                {ESLVal messages1 = $714;
                
                {ESLVal l2 = $719;
                
                {ESLVal state2 = $718;
                
                {ESLVal messages2 = $717;
                
                return typeEqual(state1,state2).and(typeEqual(messages1,messages2));
              }
              }
              }
              }
              }
              }
              }
              default: switch(_v217.termName) {
                case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                  ESLVal $653 = _v217.termRef(1);
                  ESLVal $652 = _v217.termRef(2);
                  
                  {ESLVal _v534 = _v216;
                  
                  {ESLVal l = $654;
                  
                  {ESLVal op = $653;
                  
                  {ESLVal args = $652;
                  
                  return typeEqual(_v534,applyTypeFun(l,forceType(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                  ESLVal $650 = _v217.termRef(1);
                  ESLVal $649 = _v217.termRef(2);
                  ESLVal $648 = _v217.termRef(3);
                  
                  {ESLVal _v532 = _v216;
                  
                  {ESLVal l2 = $651;
                  
                  {ESLVal _v533 = $650;
                  
                  {ESLVal ds2 = $649;
                  
                  {ESLVal ms2 = $648;
                  
                  return typeEqual(_v532,flattenAct(l2,_v533,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $647 = _v217.termRef(0);
                  
                  {ESLVal t = _v216;
                  
                  {ESLVal l1 = $647;
                  
                  return $true;
                }
                }
                }
              case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                  ESLVal $643 = _v217.termRef(1);
                  ESLVal $642 = _v217.termRef(2);
                  
                  switch($642.termName) {
                  case "UnionType": {ESLVal $646 = $642.termRef(0);
                    ESLVal $645 = $642.termRef(1);
                    
                    {ESLVal _v529 = _v216;
                    
                    {ESLVal l = $644;
                    
                    {ESLVal state = $643;
                    
                    {ESLVal ul = $646;
                    
                    {ESLVal terms = $645;
                    
                    return typeEqual(_v529,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v530 = _v216;
                    
                    {ESLVal _v531 = _v217;
                    
                    return $false;
                  }
                  }
                }
                }
              case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                  ESLVal $638 = _v217.termRef(1);
                  ESLVal $637 = _v217.termRef(2);
                  
                  switch($637.termName) {
                  case "UnionType": {ESLVal $641 = $637.termRef(0);
                    ESLVal $640 = $637.termRef(1);
                    
                    {ESLVal _v526 = _v216;
                    
                    {ESLVal l = $639;
                    
                    {ESLVal state = $638;
                    
                    {ESLVal ul = $641;
                    
                    {ESLVal terms = $640;
                    
                    return typeEqual(_v526,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v527 = _v216;
                    
                    {ESLVal _v528 = _v217;
                    
                    return $false;
                  }
                  }
                }
                }
              case "TermType": {ESLVal $636 = _v217.termRef(0);
                  ESLVal $635 = _v217.termRef(1);
                  ESLVal $634 = _v217.termRef(2);
                  
                  {ESLVal _v525 = _v216;
                  
                  {ESLVal l2 = $636;
                  
                  {ESLVal n2 = $635;
                  
                  {ESLVal args2 = $634;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                  
                  {ESLVal _v524 = _v216;
                  
                  {ESLVal f = $633;
                  
                  return typeEqual(_v524,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $632 = _v217.termRef(0);
                  ESLVal $631 = _v217.termRef(1);
                  ESLVal $630 = _v217.termRef(2);
                  
                  {ESLVal _v522 = _v216;
                  
                  {ESLVal l2 = $632;
                  
                  {ESLVal n2 = $631;
                  
                  {ESLVal _v523 = $630;
                  
                  return typeEqual(_v522,substType(new ESLVal("RecType",l2,n2,_v523),n2,_v523));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $629 = _v217.termRef(0);
                  ESLVal $628 = _v217.termRef(1);
                  ESLVal $627 = _v217.termRef(2);
                  
                  {ESLVal _v520 = _v216;
                  
                  {ESLVal l1 = $629;
                  
                  {ESLVal ns2 = $628;
                  
                  {ESLVal _v521 = $627;
                  
                  return typeEqual(_v520,_v521);
                }
                }
                }
                }
                }
                default: {ESLVal _v535 = _v216;
                  
                  {ESLVal _v536 = _v217;
                  
                  return $false;
                }
                }
              }
            }
          }
          }
        case "TableType": {ESLVal $710 = _v216.termRef(0);
            ESLVal $709 = _v216.termRef(1);
            ESLVal $708 = _v216.termRef(2);
            
            switch(_v217.termName) {
            case "TableType": {ESLVal $713 = _v217.termRef(0);
              ESLVal $712 = _v217.termRef(1);
              ESLVal $711 = _v217.termRef(2);
              
              {ESLVal l1 = $710;
              
              {ESLVal k1 = $709;
              
              {ESLVal v1 = $708;
              
              {ESLVal l2 = $713;
              
              {ESLVal k2 = $712;
              
              {ESLVal v2 = $711;
              
              return typeEqual(k1,k2).and(typeEqual(v1,v2));
            }
            }
            }
            }
            }
            }
            }
            default: switch(_v217.termName) {
              case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                ESLVal $653 = _v217.termRef(1);
                ESLVal $652 = _v217.termRef(2);
                
                {ESLVal _v516 = _v216;
                
                {ESLVal l = $654;
                
                {ESLVal op = $653;
                
                {ESLVal args = $652;
                
                return typeEqual(_v516,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                ESLVal $650 = _v217.termRef(1);
                ESLVal $649 = _v217.termRef(2);
                ESLVal $648 = _v217.termRef(3);
                
                {ESLVal _v514 = _v216;
                
                {ESLVal l2 = $651;
                
                {ESLVal _v515 = $650;
                
                {ESLVal ds2 = $649;
                
                {ESLVal ms2 = $648;
                
                return typeEqual(_v514,flattenAct(l2,_v515,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $647 = _v217.termRef(0);
                
                {ESLVal t = _v216;
                
                {ESLVal l1 = $647;
                
                return $true;
              }
              }
              }
            case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                ESLVal $643 = _v217.termRef(1);
                ESLVal $642 = _v217.termRef(2);
                
                switch($642.termName) {
                case "UnionType": {ESLVal $646 = $642.termRef(0);
                  ESLVal $645 = $642.termRef(1);
                  
                  {ESLVal _v511 = _v216;
                  
                  {ESLVal l = $644;
                  
                  {ESLVal state = $643;
                  
                  {ESLVal ul = $646;
                  
                  {ESLVal terms = $645;
                  
                  return typeEqual(_v511,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v512 = _v216;
                  
                  {ESLVal _v513 = _v217;
                  
                  return $false;
                }
                }
              }
              }
            case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                ESLVal $638 = _v217.termRef(1);
                ESLVal $637 = _v217.termRef(2);
                
                switch($637.termName) {
                case "UnionType": {ESLVal $641 = $637.termRef(0);
                  ESLVal $640 = $637.termRef(1);
                  
                  {ESLVal _v508 = _v216;
                  
                  {ESLVal l = $639;
                  
                  {ESLVal state = $638;
                  
                  {ESLVal ul = $641;
                  
                  {ESLVal terms = $640;
                  
                  return typeEqual(_v508,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v509 = _v216;
                  
                  {ESLVal _v510 = _v217;
                  
                  return $false;
                }
                }
              }
              }
            case "TermType": {ESLVal $636 = _v217.termRef(0);
                ESLVal $635 = _v217.termRef(1);
                ESLVal $634 = _v217.termRef(2);
                
                {ESLVal _v507 = _v216;
                
                {ESLVal l2 = $636;
                
                {ESLVal n2 = $635;
                
                {ESLVal args2 = $634;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                
                {ESLVal _v506 = _v216;
                
                {ESLVal f = $633;
                
                return typeEqual(_v506,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $632 = _v217.termRef(0);
                ESLVal $631 = _v217.termRef(1);
                ESLVal $630 = _v217.termRef(2);
                
                {ESLVal _v504 = _v216;
                
                {ESLVal l2 = $632;
                
                {ESLVal n2 = $631;
                
                {ESLVal _v505 = $630;
                
                return typeEqual(_v504,substType(new ESLVal("RecType",l2,n2,_v505),n2,_v505));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $629 = _v217.termRef(0);
                ESLVal $628 = _v217.termRef(1);
                ESLVal $627 = _v217.termRef(2);
                
                {ESLVal _v502 = _v216;
                
                {ESLVal l1 = $629;
                
                {ESLVal ns2 = $628;
                
                {ESLVal _v503 = $627;
                
                return typeEqual(_v502,_v503);
              }
              }
              }
              }
              }
              default: {ESLVal _v517 = _v216;
                
                {ESLVal _v518 = _v217;
                
                return $false;
              }
              }
            }
          }
          }
        case "TermType": {ESLVal $704 = _v216.termRef(0);
            ESLVal $703 = _v216.termRef(1);
            ESLVal $702 = _v216.termRef(2);
            
            switch(_v217.termName) {
            case "TermType": {ESLVal $707 = _v217.termRef(0);
              ESLVal $706 = _v217.termRef(1);
              ESLVal $705 = _v217.termRef(2);
              
              {ESLVal l1 = $704;
              
              {ESLVal n1 = $703;
              
              {ESLVal args1 = $702;
              
              {ESLVal l2 = $707;
              
              {ESLVal n2 = $706;
              
              {ESLVal args2 = $705;
              
              if(n1.eql(n2).boolVal)
              return typesEqual(args1,args2);
              else
                return $false;
            }
            }
            }
            }
            }
            }
            }
            default: {ESLVal l1 = $704;
              
              {ESLVal n1 = $703;
              
              {ESLVal args1 = $702;
              
              {ESLVal _v501 = _v217;
              
              return $false;
            }
            }
            }
            }
          }
          }
        case "FunType": {ESLVal $698 = _v216.termRef(0);
            ESLVal $697 = _v216.termRef(1);
            ESLVal $696 = _v216.termRef(2);
            
            switch(_v217.termName) {
            case "FunType": {ESLVal $701 = _v217.termRef(0);
              ESLVal $700 = _v217.termRef(1);
              ESLVal $699 = _v217.termRef(2);
              
              {ESLVal l1 = $698;
              
              {ESLVal d1 = $697;
              
              {ESLVal r1 = $696;
              
              {ESLVal l2 = $701;
              
              {ESLVal d2 = $700;
              
              {ESLVal r2 = $699;
              
              return typeEqual(r1,r2).and(typesEqual(d1,d2));
            }
            }
            }
            }
            }
            }
            }
            default: switch(_v217.termName) {
              case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                ESLVal $653 = _v217.termRef(1);
                ESLVal $652 = _v217.termRef(2);
                
                {ESLVal _v498 = _v216;
                
                {ESLVal l = $654;
                
                {ESLVal op = $653;
                
                {ESLVal args = $652;
                
                return typeEqual(_v498,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                ESLVal $650 = _v217.termRef(1);
                ESLVal $649 = _v217.termRef(2);
                ESLVal $648 = _v217.termRef(3);
                
                {ESLVal _v496 = _v216;
                
                {ESLVal l2 = $651;
                
                {ESLVal _v497 = $650;
                
                {ESLVal ds2 = $649;
                
                {ESLVal ms2 = $648;
                
                return typeEqual(_v496,flattenAct(l2,_v497,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $647 = _v217.termRef(0);
                
                {ESLVal t = _v216;
                
                {ESLVal l1 = $647;
                
                return $true;
              }
              }
              }
            case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                ESLVal $643 = _v217.termRef(1);
                ESLVal $642 = _v217.termRef(2);
                
                switch($642.termName) {
                case "UnionType": {ESLVal $646 = $642.termRef(0);
                  ESLVal $645 = $642.termRef(1);
                  
                  {ESLVal _v493 = _v216;
                  
                  {ESLVal l = $644;
                  
                  {ESLVal state = $643;
                  
                  {ESLVal ul = $646;
                  
                  {ESLVal terms = $645;
                  
                  return typeEqual(_v493,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v494 = _v216;
                  
                  {ESLVal _v495 = _v217;
                  
                  return $false;
                }
                }
              }
              }
            case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                ESLVal $638 = _v217.termRef(1);
                ESLVal $637 = _v217.termRef(2);
                
                switch($637.termName) {
                case "UnionType": {ESLVal $641 = $637.termRef(0);
                  ESLVal $640 = $637.termRef(1);
                  
                  {ESLVal _v490 = _v216;
                  
                  {ESLVal l = $639;
                  
                  {ESLVal state = $638;
                  
                  {ESLVal ul = $641;
                  
                  {ESLVal terms = $640;
                  
                  return typeEqual(_v490,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v491 = _v216;
                  
                  {ESLVal _v492 = _v217;
                  
                  return $false;
                }
                }
              }
              }
            case "TermType": {ESLVal $636 = _v217.termRef(0);
                ESLVal $635 = _v217.termRef(1);
                ESLVal $634 = _v217.termRef(2);
                
                {ESLVal _v489 = _v216;
                
                {ESLVal l2 = $636;
                
                {ESLVal n2 = $635;
                
                {ESLVal args2 = $634;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                
                {ESLVal _v488 = _v216;
                
                {ESLVal f = $633;
                
                return typeEqual(_v488,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $632 = _v217.termRef(0);
                ESLVal $631 = _v217.termRef(1);
                ESLVal $630 = _v217.termRef(2);
                
                {ESLVal _v486 = _v216;
                
                {ESLVal l2 = $632;
                
                {ESLVal n2 = $631;
                
                {ESLVal _v487 = $630;
                
                return typeEqual(_v486,substType(new ESLVal("RecType",l2,n2,_v487),n2,_v487));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $629 = _v217.termRef(0);
                ESLVal $628 = _v217.termRef(1);
                ESLVal $627 = _v217.termRef(2);
                
                {ESLVal _v484 = _v216;
                
                {ESLVal l1 = $629;
                
                {ESLVal ns2 = $628;
                
                {ESLVal _v485 = $627;
                
                return typeEqual(_v484,_v485);
              }
              }
              }
              }
              }
              default: {ESLVal _v499 = _v216;
                
                {ESLVal _v500 = _v217;
                
                return $false;
              }
              }
            }
          }
          }
        case "TypeClosure": {ESLVal $695 = _v216.termRef(0);
            
            {ESLVal f = $695;
            
            {ESLVal _v483 = _v217;
            
            return typeEqual(f.apply(),_v483);
          }
          }
          }
        case "RecordType": {ESLVal $692 = _v216.termRef(0);
            ESLVal $691 = _v216.termRef(1);
            
            switch(_v217.termName) {
            case "RecordType": {ESLVal $694 = _v217.termRef(0);
              ESLVal $693 = _v217.termRef(1);
              
              {ESLVal l1 = $692;
              
              {ESLVal fs1 = $691;
              
              {ESLVal l2 = $694;
              
              {ESLVal fs2 = $693;
              
              return recordTypeEqual(fs1,fs2);
            }
            }
            }
            }
            }
            default: switch(_v217.termName) {
              case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                ESLVal $653 = _v217.termRef(1);
                ESLVal $652 = _v217.termRef(2);
                
                {ESLVal _v480 = _v216;
                
                {ESLVal l = $654;
                
                {ESLVal op = $653;
                
                {ESLVal args = $652;
                
                return typeEqual(_v480,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                ESLVal $650 = _v217.termRef(1);
                ESLVal $649 = _v217.termRef(2);
                ESLVal $648 = _v217.termRef(3);
                
                {ESLVal _v478 = _v216;
                
                {ESLVal l2 = $651;
                
                {ESLVal _v479 = $650;
                
                {ESLVal ds2 = $649;
                
                {ESLVal ms2 = $648;
                
                return typeEqual(_v478,flattenAct(l2,_v479,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $647 = _v217.termRef(0);
                
                {ESLVal t = _v216;
                
                {ESLVal l1 = $647;
                
                return $true;
              }
              }
              }
            case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                ESLVal $643 = _v217.termRef(1);
                ESLVal $642 = _v217.termRef(2);
                
                switch($642.termName) {
                case "UnionType": {ESLVal $646 = $642.termRef(0);
                  ESLVal $645 = $642.termRef(1);
                  
                  {ESLVal _v475 = _v216;
                  
                  {ESLVal l = $644;
                  
                  {ESLVal state = $643;
                  
                  {ESLVal ul = $646;
                  
                  {ESLVal terms = $645;
                  
                  return typeEqual(_v475,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v476 = _v216;
                  
                  {ESLVal _v477 = _v217;
                  
                  return $false;
                }
                }
              }
              }
            case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                ESLVal $638 = _v217.termRef(1);
                ESLVal $637 = _v217.termRef(2);
                
                switch($637.termName) {
                case "UnionType": {ESLVal $641 = $637.termRef(0);
                  ESLVal $640 = $637.termRef(1);
                  
                  {ESLVal _v472 = _v216;
                  
                  {ESLVal l = $639;
                  
                  {ESLVal state = $638;
                  
                  {ESLVal ul = $641;
                  
                  {ESLVal terms = $640;
                  
                  return typeEqual(_v472,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v473 = _v216;
                  
                  {ESLVal _v474 = _v217;
                  
                  return $false;
                }
                }
              }
              }
            case "TermType": {ESLVal $636 = _v217.termRef(0);
                ESLVal $635 = _v217.termRef(1);
                ESLVal $634 = _v217.termRef(2);
                
                {ESLVal _v471 = _v216;
                
                {ESLVal l2 = $636;
                
                {ESLVal n2 = $635;
                
                {ESLVal args2 = $634;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                
                {ESLVal _v470 = _v216;
                
                {ESLVal f = $633;
                
                return typeEqual(_v470,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $632 = _v217.termRef(0);
                ESLVal $631 = _v217.termRef(1);
                ESLVal $630 = _v217.termRef(2);
                
                {ESLVal _v468 = _v216;
                
                {ESLVal l2 = $632;
                
                {ESLVal n2 = $631;
                
                {ESLVal _v469 = $630;
                
                return typeEqual(_v468,substType(new ESLVal("RecType",l2,n2,_v469),n2,_v469));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $629 = _v217.termRef(0);
                ESLVal $628 = _v217.termRef(1);
                ESLVal $627 = _v217.termRef(2);
                
                {ESLVal _v466 = _v216;
                
                {ESLVal l1 = $629;
                
                {ESLVal ns2 = $628;
                
                {ESLVal _v467 = $627;
                
                return typeEqual(_v466,_v467);
              }
              }
              }
              }
              }
              default: {ESLVal _v481 = _v216;
                
                {ESLVal _v482 = _v217;
                
                return $false;
              }
              }
            }
          }
          }
        case "RecType": {ESLVal $687 = _v216.termRef(0);
            ESLVal $686 = _v216.termRef(1);
            ESLVal $685 = _v216.termRef(2);
            
            switch(_v217.termName) {
            case "RecType": {ESLVal $690 = _v217.termRef(0);
              ESLVal $689 = _v217.termRef(1);
              ESLVal $688 = _v217.termRef(2);
              
              {ESLVal l1 = $687;
              
              {ESLVal n1 = $686;
              
              {ESLVal _v458 = $685;
              
              {ESLVal l2 = $690;
              
              {ESLVal n2 = $689;
              
              {ESLVal _v459 = $688;
              
              if(n1.eql(n2).boolVal)
              return typeEqual(_v458,_v459);
              else
                {ESLVal _v460 = $687;
                  
                  {ESLVal _v461 = $686;
                  
                  {ESLVal _v462 = $685;
                  
                  {ESLVal _v463 = _v217;
                  
                  return typeEqual(substType(new ESLVal("RecType",_v460,_v461,_v462),_v461,_v462),_v463);
                }
                }
                }
                }
            }
            }
            }
            }
            }
            }
            }
            default: {ESLVal l1 = $687;
              
              {ESLVal n1 = $686;
              
              {ESLVal _v464 = $685;
              
              {ESLVal _v465 = _v217;
              
              return typeEqual(substType(new ESLVal("RecType",l1,n1,_v464),n1,_v464),_v465);
            }
            }
            }
            }
          }
          }
        case "UnionType": {ESLVal $682 = _v216.termRef(0);
            ESLVal $681 = _v216.termRef(1);
            
            switch(_v217.termName) {
            case "UnionType": {ESLVal $684 = _v217.termRef(0);
              ESLVal $683 = _v217.termRef(1);
              
              {ESLVal l1 = $682;
              
              {ESLVal terms1 = $681;
              
              {ESLVal l2 = $684;
              
              {ESLVal terms2 = $683;
              
              return typeSetEqual(terms1,terms2);
            }
            }
            }
            }
            }
            default: switch(_v217.termName) {
              case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                ESLVal $653 = _v217.termRef(1);
                ESLVal $652 = _v217.termRef(2);
                
                {ESLVal _v455 = _v216;
                
                {ESLVal l = $654;
                
                {ESLVal op = $653;
                
                {ESLVal args = $652;
                
                return typeEqual(_v455,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                ESLVal $650 = _v217.termRef(1);
                ESLVal $649 = _v217.termRef(2);
                ESLVal $648 = _v217.termRef(3);
                
                {ESLVal _v453 = _v216;
                
                {ESLVal l2 = $651;
                
                {ESLVal _v454 = $650;
                
                {ESLVal ds2 = $649;
                
                {ESLVal ms2 = $648;
                
                return typeEqual(_v453,flattenAct(l2,_v454,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $647 = _v217.termRef(0);
                
                {ESLVal t = _v216;
                
                {ESLVal l1 = $647;
                
                return $true;
              }
              }
              }
            case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                ESLVal $643 = _v217.termRef(1);
                ESLVal $642 = _v217.termRef(2);
                
                switch($642.termName) {
                case "UnionType": {ESLVal $646 = $642.termRef(0);
                  ESLVal $645 = $642.termRef(1);
                  
                  {ESLVal _v450 = _v216;
                  
                  {ESLVal l = $644;
                  
                  {ESLVal state = $643;
                  
                  {ESLVal ul = $646;
                  
                  {ESLVal terms = $645;
                  
                  return typeEqual(_v450,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v451 = _v216;
                  
                  {ESLVal _v452 = _v217;
                  
                  return $false;
                }
                }
              }
              }
            case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                ESLVal $638 = _v217.termRef(1);
                ESLVal $637 = _v217.termRef(2);
                
                switch($637.termName) {
                case "UnionType": {ESLVal $641 = $637.termRef(0);
                  ESLVal $640 = $637.termRef(1);
                  
                  {ESLVal _v447 = _v216;
                  
                  {ESLVal l = $639;
                  
                  {ESLVal state = $638;
                  
                  {ESLVal ul = $641;
                  
                  {ESLVal terms = $640;
                  
                  return typeEqual(_v447,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v448 = _v216;
                  
                  {ESLVal _v449 = _v217;
                  
                  return $false;
                }
                }
              }
              }
            case "TermType": {ESLVal $636 = _v217.termRef(0);
                ESLVal $635 = _v217.termRef(1);
                ESLVal $634 = _v217.termRef(2);
                
                {ESLVal _v446 = _v216;
                
                {ESLVal l2 = $636;
                
                {ESLVal n2 = $635;
                
                {ESLVal args2 = $634;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                
                {ESLVal _v445 = _v216;
                
                {ESLVal f = $633;
                
                return typeEqual(_v445,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $632 = _v217.termRef(0);
                ESLVal $631 = _v217.termRef(1);
                ESLVal $630 = _v217.termRef(2);
                
                {ESLVal _v443 = _v216;
                
                {ESLVal l2 = $632;
                
                {ESLVal n2 = $631;
                
                {ESLVal _v444 = $630;
                
                return typeEqual(_v443,substType(new ESLVal("RecType",l2,n2,_v444),n2,_v444));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $629 = _v217.termRef(0);
                ESLVal $628 = _v217.termRef(1);
                ESLVal $627 = _v217.termRef(2);
                
                {ESLVal _v441 = _v216;
                
                {ESLVal l1 = $629;
                
                {ESLVal ns2 = $628;
                
                {ESLVal _v442 = $627;
                
                return typeEqual(_v441,_v442);
              }
              }
              }
              }
              }
              default: {ESLVal _v456 = _v216;
                
                {ESLVal _v457 = _v217;
                
                return $false;
              }
              }
            }
          }
          }
        case "VarType": {ESLVal $678 = _v216.termRef(0);
            ESLVal $677 = _v216.termRef(1);
            
            switch(_v217.termName) {
            case "VarType": {ESLVal $680 = _v217.termRef(0);
              ESLVal $679 = _v217.termRef(1);
              
              {ESLVal l1 = $678;
              
              {ESLVal n1 = $677;
              
              {ESLVal l2 = $680;
              
              {ESLVal n2 = $679;
              
              return n1.eql(n2);
            }
            }
            }
            }
            }
            default: switch(_v217.termName) {
              case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
                ESLVal $653 = _v217.termRef(1);
                ESLVal $652 = _v217.termRef(2);
                
                {ESLVal _v438 = _v216;
                
                {ESLVal l = $654;
                
                {ESLVal op = $653;
                
                {ESLVal args = $652;
                
                return typeEqual(_v438,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
                ESLVal $650 = _v217.termRef(1);
                ESLVal $649 = _v217.termRef(2);
                ESLVal $648 = _v217.termRef(3);
                
                {ESLVal _v436 = _v216;
                
                {ESLVal l2 = $651;
                
                {ESLVal _v437 = $650;
                
                {ESLVal ds2 = $649;
                
                {ESLVal ms2 = $648;
                
                return typeEqual(_v436,flattenAct(l2,_v437,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $647 = _v217.termRef(0);
                
                {ESLVal t = _v216;
                
                {ESLVal l1 = $647;
                
                return $true;
              }
              }
              }
            case "ObservedType": {ESLVal $644 = _v217.termRef(0);
                ESLVal $643 = _v217.termRef(1);
                ESLVal $642 = _v217.termRef(2);
                
                switch($642.termName) {
                case "UnionType": {ESLVal $646 = $642.termRef(0);
                  ESLVal $645 = $642.termRef(1);
                  
                  {ESLVal _v433 = _v216;
                  
                  {ESLVal l = $644;
                  
                  {ESLVal state = $643;
                  
                  {ESLVal ul = $646;
                  
                  {ESLVal terms = $645;
                  
                  return typeEqual(_v433,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v434 = _v216;
                  
                  {ESLVal _v435 = _v217;
                  
                  return $false;
                }
                }
              }
              }
            case "ObserverType": {ESLVal $639 = _v217.termRef(0);
                ESLVal $638 = _v217.termRef(1);
                ESLVal $637 = _v217.termRef(2);
                
                switch($637.termName) {
                case "UnionType": {ESLVal $641 = $637.termRef(0);
                  ESLVal $640 = $637.termRef(1);
                  
                  {ESLVal _v430 = _v216;
                  
                  {ESLVal l = $639;
                  
                  {ESLVal state = $638;
                  
                  {ESLVal ul = $641;
                  
                  {ESLVal terms = $640;
                  
                  return typeEqual(_v430,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v431 = _v216;
                  
                  {ESLVal _v432 = _v217;
                  
                  return $false;
                }
                }
              }
              }
            case "TermType": {ESLVal $636 = _v217.termRef(0);
                ESLVal $635 = _v217.termRef(1);
                ESLVal $634 = _v217.termRef(2);
                
                {ESLVal _v429 = _v216;
                
                {ESLVal l2 = $636;
                
                {ESLVal n2 = $635;
                
                {ESLVal args2 = $634;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
                
                {ESLVal _v428 = _v216;
                
                {ESLVal f = $633;
                
                return typeEqual(_v428,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $632 = _v217.termRef(0);
                ESLVal $631 = _v217.termRef(1);
                ESLVal $630 = _v217.termRef(2);
                
                {ESLVal _v426 = _v216;
                
                {ESLVal l2 = $632;
                
                {ESLVal n2 = $631;
                
                {ESLVal _v427 = $630;
                
                return typeEqual(_v426,substType(new ESLVal("RecType",l2,n2,_v427),n2,_v427));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $629 = _v217.termRef(0);
                ESLVal $628 = _v217.termRef(1);
                ESLVal $627 = _v217.termRef(2);
                
                {ESLVal _v424 = _v216;
                
                {ESLVal l1 = $629;
                
                {ESLVal ns2 = $628;
                
                {ESLVal _v425 = $627;
                
                return typeEqual(_v424,_v425);
              }
              }
              }
              }
              }
              default: {ESLVal _v439 = _v216;
                
                {ESLVal _v440 = _v217;
                
                return $false;
              }
              }
            }
          }
          }
        case "ForallType": {ESLVal $657 = _v216.termRef(0);
            ESLVal $656 = _v216.termRef(1);
            ESLVal $655 = _v216.termRef(2);
            
            if($656.isCons())
            {ESLVal $661 = $656.head();
              ESLVal $662 = $656.tail();
              
              if($662.isCons())
              {ESLVal $663 = $662.head();
                ESLVal $664 = $662.tail();
                
                switch(_v217.termName) {
                case "ForallType": {ESLVal $660 = _v217.termRef(0);
                  ESLVal $659 = _v217.termRef(1);
                  ESLVal $658 = _v217.termRef(2);
                  
                  {ESLVal l1 = $657;
                  
                  {ESLVal ns1 = $656;
                  
                  {ESLVal _v372 = $655;
                  
                  {ESLVal l2 = $660;
                  
                  {ESLVal ns2 = $659;
                  
                  {ESLVal _v373 = $658;
                  
                  return ns1.eql(ns2).and(typeEqual(_v372,_v373));
                }
                }
                }
                }
                }
                }
                }
                default: {ESLVal l1 = $657;
                  
                  {ESLVal ns1 = $656;
                  
                  {ESLVal _v374 = $655;
                  
                  {ESLVal _v375 = _v217;
                  
                  return typeEqual(_v374,_v375);
                }
                }
                }
                }
              }
              }
            else if($662.isNil())
              switch($655.termName) {
                case "ListType": {ESLVal $672 = $655.termRef(0);
                  ESLVal $671 = $655.termRef(1);
                  
                  switch($671.termName) {
                  case "VarType": {ESLVal $674 = $671.termRef(0);
                    ESLVal $673 = $671.termRef(1);
                    
                    switch(_v217.termName) {
                    case "ListType": {ESLVal $676 = _v217.termRef(0);
                      ESLVal $675 = _v217.termRef(1);
                      
                      {ESLVal l2 = $657;
                      
                      {ESLVal v1 = $661;
                      
                      {ESLVal l3 = $672;
                      
                      {ESLVal l4 = $674;
                      
                      {ESLVal v2 = $673;
                      
                      {ESLVal l1 = $676;
                      
                      {ESLVal _v392 = $675;
                      
                      if(v1.eql(v2).boolVal)
                      return $true;
                      else
                        switch(_v217.termName) {
                          case "ForallType": {ESLVal $660 = _v217.termRef(0);
                            ESLVal $659 = _v217.termRef(1);
                            ESLVal $658 = _v217.termRef(2);
                            
                            {ESLVal _v393 = $657;
                            
                            {ESLVal ns1 = $656;
                            
                            {ESLVal _v394 = $655;
                            
                            {ESLVal _v395 = $660;
                            
                            {ESLVal ns2 = $659;
                            
                            {ESLVal _v396 = $658;
                            
                            return ns1.eql(ns2).and(typeEqual(_v394,_v396));
                          }
                          }
                          }
                          }
                          }
                          }
                          }
                          default: {ESLVal _v397 = $657;
                            
                            {ESLVal ns1 = $656;
                            
                            {ESLVal _v398 = $655;
                            
                            {ESLVal _v399 = _v217;
                            
                            return typeEqual(_v398,_v399);
                          }
                          }
                          }
                          }
                        }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: switch(_v217.termName) {
                      case "ForallType": {ESLVal $660 = _v217.termRef(0);
                        ESLVal $659 = _v217.termRef(1);
                        ESLVal $658 = _v217.termRef(2);
                        
                        {ESLVal l1 = $657;
                        
                        {ESLVal ns1 = $656;
                        
                        {ESLVal _v400 = $655;
                        
                        {ESLVal l2 = $660;
                        
                        {ESLVal ns2 = $659;
                        
                        {ESLVal _v401 = $658;
                        
                        return ns1.eql(ns2).and(typeEqual(_v400,_v401));
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal l1 = $657;
                        
                        {ESLVal ns1 = $656;
                        
                        {ESLVal _v402 = $655;
                        
                        {ESLVal _v403 = _v217;
                        
                        return typeEqual(_v402,_v403);
                      }
                      }
                      }
                      }
                    }
                  }
                  }
                  default: switch(_v217.termName) {
                    case "ForallType": {ESLVal $660 = _v217.termRef(0);
                      ESLVal $659 = _v217.termRef(1);
                      ESLVal $658 = _v217.termRef(2);
                      
                      {ESLVal l1 = $657;
                      
                      {ESLVal ns1 = $656;
                      
                      {ESLVal _v404 = $655;
                      
                      {ESLVal l2 = $660;
                      
                      {ESLVal ns2 = $659;
                      
                      {ESLVal _v405 = $658;
                      
                      return ns1.eql(ns2).and(typeEqual(_v404,_v405));
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal l1 = $657;
                      
                      {ESLVal ns1 = $656;
                      
                      {ESLVal _v406 = $655;
                      
                      {ESLVal _v407 = _v217;
                      
                      return typeEqual(_v406,_v407);
                    }
                    }
                    }
                    }
                  }
                }
                }
              case "SetType": {ESLVal $666 = $655.termRef(0);
                  ESLVal $665 = $655.termRef(1);
                  
                  switch($665.termName) {
                  case "VarType": {ESLVal $668 = $665.termRef(0);
                    ESLVal $667 = $665.termRef(1);
                    
                    switch(_v217.termName) {
                    case "SetType": {ESLVal $670 = _v217.termRef(0);
                      ESLVal $669 = _v217.termRef(1);
                      
                      {ESLVal l2 = $657;
                      
                      {ESLVal v1 = $661;
                      
                      {ESLVal l3 = $666;
                      
                      {ESLVal l4 = $668;
                      
                      {ESLVal v2 = $667;
                      
                      {ESLVal l1 = $670;
                      
                      {ESLVal _v376 = $669;
                      
                      if(v1.eql(v2).boolVal)
                      return $true;
                      else
                        switch(_v217.termName) {
                          case "ForallType": {ESLVal $660 = _v217.termRef(0);
                            ESLVal $659 = _v217.termRef(1);
                            ESLVal $658 = _v217.termRef(2);
                            
                            {ESLVal _v377 = $657;
                            
                            {ESLVal ns1 = $656;
                            
                            {ESLVal _v378 = $655;
                            
                            {ESLVal _v379 = $660;
                            
                            {ESLVal ns2 = $659;
                            
                            {ESLVal _v380 = $658;
                            
                            return ns1.eql(ns2).and(typeEqual(_v378,_v380));
                          }
                          }
                          }
                          }
                          }
                          }
                          }
                          default: {ESLVal _v381 = $657;
                            
                            {ESLVal ns1 = $656;
                            
                            {ESLVal _v382 = $655;
                            
                            {ESLVal _v383 = _v217;
                            
                            return typeEqual(_v382,_v383);
                          }
                          }
                          }
                          }
                        }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: switch(_v217.termName) {
                      case "ForallType": {ESLVal $660 = _v217.termRef(0);
                        ESLVal $659 = _v217.termRef(1);
                        ESLVal $658 = _v217.termRef(2);
                        
                        {ESLVal l1 = $657;
                        
                        {ESLVal ns1 = $656;
                        
                        {ESLVal _v384 = $655;
                        
                        {ESLVal l2 = $660;
                        
                        {ESLVal ns2 = $659;
                        
                        {ESLVal _v385 = $658;
                        
                        return ns1.eql(ns2).and(typeEqual(_v384,_v385));
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal l1 = $657;
                        
                        {ESLVal ns1 = $656;
                        
                        {ESLVal _v386 = $655;
                        
                        {ESLVal _v387 = _v217;
                        
                        return typeEqual(_v386,_v387);
                      }
                      }
                      }
                      }
                    }
                  }
                  }
                  default: switch(_v217.termName) {
                    case "ForallType": {ESLVal $660 = _v217.termRef(0);
                      ESLVal $659 = _v217.termRef(1);
                      ESLVal $658 = _v217.termRef(2);
                      
                      {ESLVal l1 = $657;
                      
                      {ESLVal ns1 = $656;
                      
                      {ESLVal _v388 = $655;
                      
                      {ESLVal l2 = $660;
                      
                      {ESLVal ns2 = $659;
                      
                      {ESLVal _v389 = $658;
                      
                      return ns1.eql(ns2).and(typeEqual(_v388,_v389));
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal l1 = $657;
                      
                      {ESLVal ns1 = $656;
                      
                      {ESLVal _v390 = $655;
                      
                      {ESLVal _v391 = _v217;
                      
                      return typeEqual(_v390,_v391);
                    }
                    }
                    }
                    }
                  }
                }
                }
                default: switch(_v217.termName) {
                  case "ForallType": {ESLVal $660 = _v217.termRef(0);
                    ESLVal $659 = _v217.termRef(1);
                    ESLVal $658 = _v217.termRef(2);
                    
                    {ESLVal l1 = $657;
                    
                    {ESLVal ns1 = $656;
                    
                    {ESLVal _v408 = $655;
                    
                    {ESLVal l2 = $660;
                    
                    {ESLVal ns2 = $659;
                    
                    {ESLVal _v409 = $658;
                    
                    return ns1.eql(ns2).and(typeEqual(_v408,_v409));
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal l1 = $657;
                    
                    {ESLVal ns1 = $656;
                    
                    {ESLVal _v410 = $655;
                    
                    {ESLVal _v411 = _v217;
                    
                    return typeEqual(_v410,_v411);
                  }
                  }
                  }
                  }
                }
              }
            else switch(_v217.termName) {
                case "ForallType": {ESLVal $660 = _v217.termRef(0);
                  ESLVal $659 = _v217.termRef(1);
                  ESLVal $658 = _v217.termRef(2);
                  
                  {ESLVal l1 = $657;
                  
                  {ESLVal ns1 = $656;
                  
                  {ESLVal _v412 = $655;
                  
                  {ESLVal l2 = $660;
                  
                  {ESLVal ns2 = $659;
                  
                  {ESLVal _v413 = $658;
                  
                  return ns1.eql(ns2).and(typeEqual(_v412,_v413));
                }
                }
                }
                }
                }
                }
                }
                default: {ESLVal l1 = $657;
                  
                  {ESLVal ns1 = $656;
                  
                  {ESLVal _v414 = $655;
                  
                  {ESLVal _v415 = _v217;
                  
                  return typeEqual(_v414,_v415);
                }
                }
                }
                }
              }
            }
          else if($656.isNil())
            switch(_v217.termName) {
              case "ForallType": {ESLVal $660 = _v217.termRef(0);
                ESLVal $659 = _v217.termRef(1);
                ESLVal $658 = _v217.termRef(2);
                
                {ESLVal l1 = $657;
                
                {ESLVal ns1 = $656;
                
                {ESLVal _v416 = $655;
                
                {ESLVal l2 = $660;
                
                {ESLVal ns2 = $659;
                
                {ESLVal _v417 = $658;
                
                return ns1.eql(ns2).and(typeEqual(_v416,_v417));
              }
              }
              }
              }
              }
              }
              }
              default: {ESLVal l1 = $657;
                
                {ESLVal ns1 = $656;
                
                {ESLVal _v418 = $655;
                
                {ESLVal _v419 = _v217;
                
                return typeEqual(_v418,_v419);
              }
              }
              }
              }
            }
          else switch(_v217.termName) {
              case "ForallType": {ESLVal $660 = _v217.termRef(0);
                ESLVal $659 = _v217.termRef(1);
                ESLVal $658 = _v217.termRef(2);
                
                {ESLVal l1 = $657;
                
                {ESLVal ns1 = $656;
                
                {ESLVal _v420 = $655;
                
                {ESLVal l2 = $660;
                
                {ESLVal ns2 = $659;
                
                {ESLVal _v421 = $658;
                
                return ns1.eql(ns2).and(typeEqual(_v420,_v421));
              }
              }
              }
              }
              }
              }
              }
              default: {ESLVal l1 = $657;
                
                {ESLVal ns1 = $656;
                
                {ESLVal _v422 = $655;
                
                {ESLVal _v423 = _v217;
                
                return typeEqual(_v422,_v423);
              }
              }
              }
              }
            }
          }
          default: switch(_v217.termName) {
            case "ApplyTypeFun": {ESLVal $654 = _v217.termRef(0);
              ESLVal $653 = _v217.termRef(1);
              ESLVal $652 = _v217.termRef(2);
              
              {ESLVal _v1002 = _v216;
              
              {ESLVal l = $654;
              
              {ESLVal op = $653;
              
              {ESLVal args = $652;
              
              return typeEqual(_v1002,applyTypeFun(l,forceType(op),args));
            }
            }
            }
            }
            }
          case "ExtendedAct": {ESLVal $651 = _v217.termRef(0);
              ESLVal $650 = _v217.termRef(1);
              ESLVal $649 = _v217.termRef(2);
              ESLVal $648 = _v217.termRef(3);
              
              {ESLVal _v1000 = _v216;
              
              {ESLVal l2 = $651;
              
              {ESLVal _v1001 = $650;
              
              {ESLVal ds2 = $649;
              
              {ESLVal ms2 = $648;
              
              return typeEqual(_v1000,flattenAct(l2,_v1001,ds2,ms2));
            }
            }
            }
            }
            }
            }
          case "VoidType": {ESLVal $647 = _v217.termRef(0);
              
              {ESLVal t = _v216;
              
              {ESLVal l1 = $647;
              
              return $true;
            }
            }
            }
          case "ObservedType": {ESLVal $644 = _v217.termRef(0);
              ESLVal $643 = _v217.termRef(1);
              ESLVal $642 = _v217.termRef(2);
              
              switch($642.termName) {
              case "UnionType": {ESLVal $646 = $642.termRef(0);
                ESLVal $645 = $642.termRef(1);
                
                {ESLVal _v997 = _v216;
                
                {ESLVal l = $644;
                
                {ESLVal state = $643;
                
                {ESLVal ul = $646;
                
                {ESLVal terms = $645;
                
                return typeEqual(_v997,expandObservedType(l,state,new ESLVal("UnionType",ul,terms)));
              }
              }
              }
              }
              }
              }
              default: {ESLVal _v998 = _v216;
                
                {ESLVal _v999 = _v217;
                
                return $false;
              }
              }
            }
            }
          case "ObserverType": {ESLVal $639 = _v217.termRef(0);
              ESLVal $638 = _v217.termRef(1);
              ESLVal $637 = _v217.termRef(2);
              
              switch($637.termName) {
              case "UnionType": {ESLVal $641 = $637.termRef(0);
                ESLVal $640 = $637.termRef(1);
                
                {ESLVal _v994 = _v216;
                
                {ESLVal l = $639;
                
                {ESLVal state = $638;
                
                {ESLVal ul = $641;
                
                {ESLVal terms = $640;
                
                return typeEqual(_v994,expandObserverType(l,state,new ESLVal("UnionType",ul,terms)));
              }
              }
              }
              }
              }
              }
              default: {ESLVal _v995 = _v216;
                
                {ESLVal _v996 = _v217;
                
                return $false;
              }
              }
            }
            }
          case "TermType": {ESLVal $636 = _v217.termRef(0);
              ESLVal $635 = _v217.termRef(1);
              ESLVal $634 = _v217.termRef(2);
              
              {ESLVal _v993 = _v216;
              
              {ESLVal l2 = $636;
              
              {ESLVal n2 = $635;
              
              {ESLVal args2 = $634;
              
              return $false;
            }
            }
            }
            }
            }
          case "TypeClosure": {ESLVal $633 = _v217.termRef(0);
              
              {ESLVal _v992 = _v216;
              
              {ESLVal f = $633;
              
              return typeEqual(_v992,f.apply());
            }
            }
            }
          case "RecType": {ESLVal $632 = _v217.termRef(0);
              ESLVal $631 = _v217.termRef(1);
              ESLVal $630 = _v217.termRef(2);
              
              {ESLVal _v990 = _v216;
              
              {ESLVal l2 = $632;
              
              {ESLVal n2 = $631;
              
              {ESLVal _v991 = $630;
              
              return typeEqual(_v990,substType(new ESLVal("RecType",l2,n2,_v991),n2,_v991));
            }
            }
            }
            }
            }
          case "ForallType": {ESLVal $629 = _v217.termRef(0);
              ESLVal $628 = _v217.termRef(1);
              ESLVal $627 = _v217.termRef(2);
              
              {ESLVal _v988 = _v216;
              
              {ESLVal l1 = $629;
              
              {ESLVal ns2 = $628;
              
              {ESLVal _v989 = $627;
              
              return typeEqual(_v988,_v989);
            }
            }
            }
            }
            }
            default: {ESLVal _v1003 = _v216;
              
              {ESLVal _v1004 = _v217;
              
              return $false;
            }
            }
          }
        }
        }
  }
  public static ESLVal typeEqual1 = new ESLVal(new Function(new ESLVal("typeEqual1"),null) { public ESLVal apply(ESLVal... args) { return typeEqual1(args[0],args[1]); }});
  public static ESLVal subType(ESLVal sub,ESLVal parent) {
    
    if(sub.eql(parent).boolVal)
      return $true;
      else
        {ESLVal _v218 = sub;
          ESLVal _v219 = parent;
          
          switch(_v218.termName) {
          case "ActType": {ESLVal $917 = _v218.termRef(0);
            ESLVal $916 = _v218.termRef(1);
            ESLVal $915 = _v218.termRef(2);
            
            switch(_v219.termName) {
            case "ActType": {ESLVal $920 = _v219.termRef(0);
              ESLVal $919 = _v219.termRef(1);
              ESLVal $918 = _v219.termRef(2);
              
              {ESLVal l1 = $917;
              
              {ESLVal exports1 = $916;
              
              {ESLVal handlers1 = $915;
              
              {ESLVal l2 = $920;
              
              {ESLVal exports2 = $919;
              
              {ESLVal handlers2 = $918;
              
              return actSubType(exports1,exports2,handlers1,handlers2);
            }
            }
            }
            }
            }
            }
            }
            default: switch(_v219.termName) {
              case "ApplyTypeFun": {ESLVal $820 = _v219.termRef(0);
                ESLVal $819 = _v219.termRef(1);
                ESLVal $818 = _v219.termRef(2);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l = $820;
                
                {ESLVal op = $819;
                
                {ESLVal args = $818;
                
                return subType(t1,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $817 = _v219.termRef(0);
                ESLVal $816 = _v219.termRef(1);
                ESLVal $815 = _v219.termRef(2);
                ESLVal $814 = _v219.termRef(3);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l2 = $817;
                
                {ESLVal t2 = $816;
                
                {ESLVal ds2 = $815;
                
                {ESLVal ms2 = $814;
                
                return subType(t1,flattenAct(l2,t2,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $813 = _v219.termRef(0);
                
                {ESLVal t1 = _v218;
                
                {ESLVal f = $813;
                
                return subType(t1,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $812 = _v219.termRef(0);
                ESLVal $811 = _v219.termRef(1);
                ESLVal $810 = _v219.termRef(2);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l2 = $812;
                
                {ESLVal n2 = $811;
                
                {ESLVal t2 = $810;
                
                return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $809 = _v219.termRef(0);
                ESLVal $808 = _v219.termRef(1);
                ESLVal $807 = _v219.termRef(2);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l1 = $809;
                
                {ESLVal ns2 = $808;
                
                {ESLVal t2 = $807;
                
                return subType(t1,t2);
              }
              }
              }
              }
              }
            case "ObservedType": {ESLVal $805 = _v219.termRef(0);
                ESLVal $804 = _v219.termRef(1);
                ESLVal $803 = _v219.termRef(2);
                
                switch($803.termName) {
                case "TypeClosure": {ESLVal $806 = $803.termRef(0);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l = $805;
                  
                  {ESLVal state = $804;
                  
                  {ESLVal f = $806;
                  
                  return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v218;
                  
                  {ESLVal l = $805;
                  
                  {ESLVal state = $804;
                  
                  {ESLVal messages = $803;
                  
                  return subType(t1,expandObservedType(l,state,messages));
                }
                }
                }
                }
              }
              }
            case "ObserverType": {ESLVal $801 = _v219.termRef(0);
                ESLVal $800 = _v219.termRef(1);
                ESLVal $799 = _v219.termRef(2);
                
                switch($799.termName) {
                case "TypeClosure": {ESLVal $802 = $799.termRef(0);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l = $801;
                  
                  {ESLVal state = $800;
                  
                  {ESLVal f = $802;
                  
                  return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v218;
                  
                  {ESLVal l = $801;
                  
                  {ESLVal state = $800;
                  
                  {ESLVal messages = $799;
                  
                  return subType(t1,expandObserverType(l,state,messages));
                }
                }
                }
                }
              }
              }
              default: {ESLVal t1 = _v218;
                
                {ESLVal t2 = _v219;
                
                return typeEqual(t1,t2);
              }
              }
            }
          }
          }
        case "ApplyTypeFun": {ESLVal $914 = _v218.termRef(0);
            ESLVal $913 = _v218.termRef(1);
            ESLVal $912 = _v218.termRef(2);
            
            {ESLVal l = $914;
            
            {ESLVal op = $913;
            
            {ESLVal args = $912;
            
            {ESLVal t2 = _v219;
            
            return subType(applyTypeFun(l,forceType(op),args),t2);
          }
          }
          }
          }
          }
        case "ExtendedAct": {ESLVal $911 = _v218.termRef(0);
            ESLVal $910 = _v218.termRef(1);
            ESLVal $909 = _v218.termRef(2);
            ESLVal $908 = _v218.termRef(3);
            
            {ESLVal l1 = $911;
            
            {ESLVal t1 = $910;
            
            {ESLVal ds1 = $909;
            
            {ESLVal ms1 = $908;
            
            {ESLVal t2 = _v219;
            
            return subType(flattenAct(l1,t1,ds1,ms1),t2);
          }
          }
          }
          }
          }
          }
        case "ListType": {ESLVal $894 = _v218.termRef(0);
            ESLVal $893 = _v218.termRef(1);
            
            switch(_v219.termName) {
            case "ListType": {ESLVal $907 = _v219.termRef(0);
              ESLVal $906 = _v219.termRef(1);
              
              {ESLVal l1 = $894;
              
              {ESLVal t1 = $893;
              
              {ESLVal l2 = $907;
              
              {ESLVal t2 = $906;
              
              return subType(t1,t2);
            }
            }
            }
            }
            }
          case "ForallType": {ESLVal $897 = _v219.termRef(0);
              ESLVal $896 = _v219.termRef(1);
              ESLVal $895 = _v219.termRef(2);
              
              if($896.isCons())
              {ESLVal $898 = $896.head();
                ESLVal $899 = $896.tail();
                
                if($899.isCons())
                {ESLVal $900 = $899.head();
                  ESLVal $901 = $899.tail();
                  
                  switch(_v219.termName) {
                  case "ApplyTypeFun": {ESLVal $820 = _v219.termRef(0);
                    ESLVal $819 = _v219.termRef(1);
                    ESLVal $818 = _v219.termRef(2);
                    
                    {ESLVal t1 = _v218;
                    
                    {ESLVal l = $820;
                    
                    {ESLVal op = $819;
                    
                    {ESLVal args = $818;
                    
                    return subType(t1,applyTypeFun(l,forceType(op),args));
                  }
                  }
                  }
                  }
                  }
                case "ExtendedAct": {ESLVal $817 = _v219.termRef(0);
                    ESLVal $816 = _v219.termRef(1);
                    ESLVal $815 = _v219.termRef(2);
                    ESLVal $814 = _v219.termRef(3);
                    
                    {ESLVal t1 = _v218;
                    
                    {ESLVal l2 = $817;
                    
                    {ESLVal t2 = $816;
                    
                    {ESLVal ds2 = $815;
                    
                    {ESLVal ms2 = $814;
                    
                    return subType(t1,flattenAct(l2,t2,ds2,ms2));
                  }
                  }
                  }
                  }
                  }
                  }
                case "TypeClosure": {ESLVal $813 = _v219.termRef(0);
                    
                    {ESLVal t1 = _v218;
                    
                    {ESLVal f = $813;
                    
                    return subType(t1,f.apply());
                  }
                  }
                  }
                case "RecType": {ESLVal $812 = _v219.termRef(0);
                    ESLVal $811 = _v219.termRef(1);
                    ESLVal $810 = _v219.termRef(2);
                    
                    {ESLVal t1 = _v218;
                    
                    {ESLVal l2 = $812;
                    
                    {ESLVal n2 = $811;
                    
                    {ESLVal t2 = $810;
                    
                    return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
                  }
                  }
                  }
                  }
                  }
                case "ForallType": {ESLVal $809 = _v219.termRef(0);
                    ESLVal $808 = _v219.termRef(1);
                    ESLVal $807 = _v219.termRef(2);
                    
                    {ESLVal t1 = _v218;
                    
                    {ESLVal l1 = $809;
                    
                    {ESLVal ns2 = $808;
                    
                    {ESLVal t2 = $807;
                    
                    return subType(t1,t2);
                  }
                  }
                  }
                  }
                  }
                case "ObservedType": {ESLVal $805 = _v219.termRef(0);
                    ESLVal $804 = _v219.termRef(1);
                    ESLVal $803 = _v219.termRef(2);
                    
                    switch($803.termName) {
                    case "TypeClosure": {ESLVal $806 = $803.termRef(0);
                      
                      {ESLVal t1 = _v218;
                      
                      {ESLVal l = $805;
                      
                      {ESLVal state = $804;
                      
                      {ESLVal f = $806;
                      
                      return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal t1 = _v218;
                      
                      {ESLVal l = $805;
                      
                      {ESLVal state = $804;
                      
                      {ESLVal messages = $803;
                      
                      return subType(t1,expandObservedType(l,state,messages));
                    }
                    }
                    }
                    }
                  }
                  }
                case "ObserverType": {ESLVal $801 = _v219.termRef(0);
                    ESLVal $800 = _v219.termRef(1);
                    ESLVal $799 = _v219.termRef(2);
                    
                    switch($799.termName) {
                    case "TypeClosure": {ESLVal $802 = $799.termRef(0);
                      
                      {ESLVal t1 = _v218;
                      
                      {ESLVal l = $801;
                      
                      {ESLVal state = $800;
                      
                      {ESLVal f = $802;
                      
                      return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal t1 = _v218;
                      
                      {ESLVal l = $801;
                      
                      {ESLVal state = $800;
                      
                      {ESLVal messages = $799;
                      
                      return subType(t1,expandObserverType(l,state,messages));
                    }
                    }
                    }
                    }
                  }
                  }
                  default: {ESLVal t1 = _v218;
                    
                    {ESLVal t2 = _v219;
                    
                    return typeEqual(t1,t2);
                  }
                  }
                }
                }
              else if($899.isNil())
                switch($895.termName) {
                  case "ListType": {ESLVal $903 = $895.termRef(0);
                    ESLVal $902 = $895.termRef(1);
                    
                    switch($902.termName) {
                    case "VarType": {ESLVal $905 = $902.termRef(0);
                      ESLVal $904 = $902.termRef(1);
                      
                      {ESLVal l1 = $894;
                      
                      {ESLVal t1 = $893;
                      
                      {ESLVal l2 = $897;
                      
                      {ESLVal v1 = $898;
                      
                      {ESLVal l3 = $903;
                      
                      {ESLVal l4 = $905;
                      
                      {ESLVal v2 = $904;
                      
                      if(v1.eql(v2).boolVal)
                      return $true;
                      else
                        switch(_v219.termName) {
                          case "ApplyTypeFun": {ESLVal $820 = _v219.termRef(0);
                            ESLVal $819 = _v219.termRef(1);
                            ESLVal $818 = _v219.termRef(2);
                            
                            {ESLVal _v370 = _v218;
                            
                            {ESLVal l = $820;
                            
                            {ESLVal op = $819;
                            
                            {ESLVal args = $818;
                            
                            return subType(_v370,applyTypeFun(l,forceType(op),args));
                          }
                          }
                          }
                          }
                          }
                        case "ExtendedAct": {ESLVal $817 = _v219.termRef(0);
                            ESLVal $816 = _v219.termRef(1);
                            ESLVal $815 = _v219.termRef(2);
                            ESLVal $814 = _v219.termRef(3);
                            
                            {ESLVal _v368 = _v218;
                            
                            {ESLVal _v369 = $817;
                            
                            {ESLVal t2 = $816;
                            
                            {ESLVal ds2 = $815;
                            
                            {ESLVal ms2 = $814;
                            
                            return subType(_v368,flattenAct(_v369,t2,ds2,ms2));
                          }
                          }
                          }
                          }
                          }
                          }
                        case "TypeClosure": {ESLVal $813 = _v219.termRef(0);
                            
                            {ESLVal _v367 = _v218;
                            
                            {ESLVal f = $813;
                            
                            return subType(_v367,f.apply());
                          }
                          }
                          }
                        case "RecType": {ESLVal $812 = _v219.termRef(0);
                            ESLVal $811 = _v219.termRef(1);
                            ESLVal $810 = _v219.termRef(2);
                            
                            {ESLVal _v365 = _v218;
                            
                            {ESLVal _v366 = $812;
                            
                            {ESLVal n2 = $811;
                            
                            {ESLVal t2 = $810;
                            
                            return subType(_v365,substType(new ESLVal("RecType",_v366,n2,t2),n2,t2));
                          }
                          }
                          }
                          }
                          }
                        case "ForallType": {ESLVal $809 = _v219.termRef(0);
                            ESLVal $808 = _v219.termRef(1);
                            ESLVal $807 = _v219.termRef(2);
                            
                            {ESLVal _v363 = _v218;
                            
                            {ESLVal _v364 = $809;
                            
                            {ESLVal ns2 = $808;
                            
                            {ESLVal t2 = $807;
                            
                            return subType(_v363,t2);
                          }
                          }
                          }
                          }
                          }
                        case "ObservedType": {ESLVal $805 = _v219.termRef(0);
                            ESLVal $804 = _v219.termRef(1);
                            ESLVal $803 = _v219.termRef(2);
                            
                            switch($803.termName) {
                            case "TypeClosure": {ESLVal $806 = $803.termRef(0);
                              
                              {ESLVal _v361 = _v218;
                              
                              {ESLVal l = $805;
                              
                              {ESLVal state = $804;
                              
                              {ESLVal f = $806;
                              
                              return subType(_v361,new ESLVal("ObservedType",l,state,f.apply()));
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v362 = _v218;
                              
                              {ESLVal l = $805;
                              
                              {ESLVal state = $804;
                              
                              {ESLVal messages = $803;
                              
                              return subType(_v362,expandObservedType(l,state,messages));
                            }
                            }
                            }
                            }
                          }
                          }
                        case "ObserverType": {ESLVal $801 = _v219.termRef(0);
                            ESLVal $800 = _v219.termRef(1);
                            ESLVal $799 = _v219.termRef(2);
                            
                            switch($799.termName) {
                            case "TypeClosure": {ESLVal $802 = $799.termRef(0);
                              
                              {ESLVal _v359 = _v218;
                              
                              {ESLVal l = $801;
                              
                              {ESLVal state = $800;
                              
                              {ESLVal f = $802;
                              
                              return subType(_v359,new ESLVal("ObserverType",l,state,f.apply()));
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v360 = _v218;
                              
                              {ESLVal l = $801;
                              
                              {ESLVal state = $800;
                              
                              {ESLVal messages = $799;
                              
                              return subType(_v360,expandObserverType(l,state,messages));
                            }
                            }
                            }
                            }
                          }
                          }
                          default: {ESLVal _v371 = _v218;
                            
                            {ESLVal t2 = _v219;
                            
                            return typeEqual(_v371,t2);
                          }
                          }
                        }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: switch(_v219.termName) {
                      case "ApplyTypeFun": {ESLVal $820 = _v219.termRef(0);
                        ESLVal $819 = _v219.termRef(1);
                        ESLVal $818 = _v219.termRef(2);
                        
                        {ESLVal t1 = _v218;
                        
                        {ESLVal l = $820;
                        
                        {ESLVal op = $819;
                        
                        {ESLVal args = $818;
                        
                        return subType(t1,applyTypeFun(l,forceType(op),args));
                      }
                      }
                      }
                      }
                      }
                    case "ExtendedAct": {ESLVal $817 = _v219.termRef(0);
                        ESLVal $816 = _v219.termRef(1);
                        ESLVal $815 = _v219.termRef(2);
                        ESLVal $814 = _v219.termRef(3);
                        
                        {ESLVal t1 = _v218;
                        
                        {ESLVal l2 = $817;
                        
                        {ESLVal t2 = $816;
                        
                        {ESLVal ds2 = $815;
                        
                        {ESLVal ms2 = $814;
                        
                        return subType(t1,flattenAct(l2,t2,ds2,ms2));
                      }
                      }
                      }
                      }
                      }
                      }
                    case "TypeClosure": {ESLVal $813 = _v219.termRef(0);
                        
                        {ESLVal t1 = _v218;
                        
                        {ESLVal f = $813;
                        
                        return subType(t1,f.apply());
                      }
                      }
                      }
                    case "RecType": {ESLVal $812 = _v219.termRef(0);
                        ESLVal $811 = _v219.termRef(1);
                        ESLVal $810 = _v219.termRef(2);
                        
                        {ESLVal t1 = _v218;
                        
                        {ESLVal l2 = $812;
                        
                        {ESLVal n2 = $811;
                        
                        {ESLVal t2 = $810;
                        
                        return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
                      }
                      }
                      }
                      }
                      }
                    case "ForallType": {ESLVal $809 = _v219.termRef(0);
                        ESLVal $808 = _v219.termRef(1);
                        ESLVal $807 = _v219.termRef(2);
                        
                        {ESLVal t1 = _v218;
                        
                        {ESLVal l1 = $809;
                        
                        {ESLVal ns2 = $808;
                        
                        {ESLVal t2 = $807;
                        
                        return subType(t1,t2);
                      }
                      }
                      }
                      }
                      }
                    case "ObservedType": {ESLVal $805 = _v219.termRef(0);
                        ESLVal $804 = _v219.termRef(1);
                        ESLVal $803 = _v219.termRef(2);
                        
                        switch($803.termName) {
                        case "TypeClosure": {ESLVal $806 = $803.termRef(0);
                          
                          {ESLVal t1 = _v218;
                          
                          {ESLVal l = $805;
                          
                          {ESLVal state = $804;
                          
                          {ESLVal f = $806;
                          
                          return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal t1 = _v218;
                          
                          {ESLVal l = $805;
                          
                          {ESLVal state = $804;
                          
                          {ESLVal messages = $803;
                          
                          return subType(t1,expandObservedType(l,state,messages));
                        }
                        }
                        }
                        }
                      }
                      }
                    case "ObserverType": {ESLVal $801 = _v219.termRef(0);
                        ESLVal $800 = _v219.termRef(1);
                        ESLVal $799 = _v219.termRef(2);
                        
                        switch($799.termName) {
                        case "TypeClosure": {ESLVal $802 = $799.termRef(0);
                          
                          {ESLVal t1 = _v218;
                          
                          {ESLVal l = $801;
                          
                          {ESLVal state = $800;
                          
                          {ESLVal f = $802;
                          
                          return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal t1 = _v218;
                          
                          {ESLVal l = $801;
                          
                          {ESLVal state = $800;
                          
                          {ESLVal messages = $799;
                          
                          return subType(t1,expandObserverType(l,state,messages));
                        }
                        }
                        }
                        }
                      }
                      }
                      default: {ESLVal t1 = _v218;
                        
                        {ESLVal t2 = _v219;
                        
                        return typeEqual(t1,t2);
                      }
                      }
                    }
                  }
                  }
                  default: switch(_v219.termName) {
                    case "ApplyTypeFun": {ESLVal $820 = _v219.termRef(0);
                      ESLVal $819 = _v219.termRef(1);
                      ESLVal $818 = _v219.termRef(2);
                      
                      {ESLVal t1 = _v218;
                      
                      {ESLVal l = $820;
                      
                      {ESLVal op = $819;
                      
                      {ESLVal args = $818;
                      
                      return subType(t1,applyTypeFun(l,forceType(op),args));
                    }
                    }
                    }
                    }
                    }
                  case "ExtendedAct": {ESLVal $817 = _v219.termRef(0);
                      ESLVal $816 = _v219.termRef(1);
                      ESLVal $815 = _v219.termRef(2);
                      ESLVal $814 = _v219.termRef(3);
                      
                      {ESLVal t1 = _v218;
                      
                      {ESLVal l2 = $817;
                      
                      {ESLVal t2 = $816;
                      
                      {ESLVal ds2 = $815;
                      
                      {ESLVal ms2 = $814;
                      
                      return subType(t1,flattenAct(l2,t2,ds2,ms2));
                    }
                    }
                    }
                    }
                    }
                    }
                  case "TypeClosure": {ESLVal $813 = _v219.termRef(0);
                      
                      {ESLVal t1 = _v218;
                      
                      {ESLVal f = $813;
                      
                      return subType(t1,f.apply());
                    }
                    }
                    }
                  case "RecType": {ESLVal $812 = _v219.termRef(0);
                      ESLVal $811 = _v219.termRef(1);
                      ESLVal $810 = _v219.termRef(2);
                      
                      {ESLVal t1 = _v218;
                      
                      {ESLVal l2 = $812;
                      
                      {ESLVal n2 = $811;
                      
                      {ESLVal t2 = $810;
                      
                      return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
                    }
                    }
                    }
                    }
                    }
                  case "ForallType": {ESLVal $809 = _v219.termRef(0);
                      ESLVal $808 = _v219.termRef(1);
                      ESLVal $807 = _v219.termRef(2);
                      
                      {ESLVal t1 = _v218;
                      
                      {ESLVal l1 = $809;
                      
                      {ESLVal ns2 = $808;
                      
                      {ESLVal t2 = $807;
                      
                      return subType(t1,t2);
                    }
                    }
                    }
                    }
                    }
                  case "ObservedType": {ESLVal $805 = _v219.termRef(0);
                      ESLVal $804 = _v219.termRef(1);
                      ESLVal $803 = _v219.termRef(2);
                      
                      switch($803.termName) {
                      case "TypeClosure": {ESLVal $806 = $803.termRef(0);
                        
                        {ESLVal t1 = _v218;
                        
                        {ESLVal l = $805;
                        
                        {ESLVal state = $804;
                        
                        {ESLVal f = $806;
                        
                        return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal t1 = _v218;
                        
                        {ESLVal l = $805;
                        
                        {ESLVal state = $804;
                        
                        {ESLVal messages = $803;
                        
                        return subType(t1,expandObservedType(l,state,messages));
                      }
                      }
                      }
                      }
                    }
                    }
                  case "ObserverType": {ESLVal $801 = _v219.termRef(0);
                      ESLVal $800 = _v219.termRef(1);
                      ESLVal $799 = _v219.termRef(2);
                      
                      switch($799.termName) {
                      case "TypeClosure": {ESLVal $802 = $799.termRef(0);
                        
                        {ESLVal t1 = _v218;
                        
                        {ESLVal l = $801;
                        
                        {ESLVal state = $800;
                        
                        {ESLVal f = $802;
                        
                        return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal t1 = _v218;
                        
                        {ESLVal l = $801;
                        
                        {ESLVal state = $800;
                        
                        {ESLVal messages = $799;
                        
                        return subType(t1,expandObserverType(l,state,messages));
                      }
                      }
                      }
                      }
                    }
                    }
                    default: {ESLVal t1 = _v218;
                      
                      {ESLVal t2 = _v219;
                      
                      return typeEqual(t1,t2);
                    }
                    }
                  }
                }
              else switch(_v219.termName) {
                  case "ApplyTypeFun": {ESLVal $820 = _v219.termRef(0);
                    ESLVal $819 = _v219.termRef(1);
                    ESLVal $818 = _v219.termRef(2);
                    
                    {ESLVal t1 = _v218;
                    
                    {ESLVal l = $820;
                    
                    {ESLVal op = $819;
                    
                    {ESLVal args = $818;
                    
                    return subType(t1,applyTypeFun(l,forceType(op),args));
                  }
                  }
                  }
                  }
                  }
                case "ExtendedAct": {ESLVal $817 = _v219.termRef(0);
                    ESLVal $816 = _v219.termRef(1);
                    ESLVal $815 = _v219.termRef(2);
                    ESLVal $814 = _v219.termRef(3);
                    
                    {ESLVal t1 = _v218;
                    
                    {ESLVal l2 = $817;
                    
                    {ESLVal t2 = $816;
                    
                    {ESLVal ds2 = $815;
                    
                    {ESLVal ms2 = $814;
                    
                    return subType(t1,flattenAct(l2,t2,ds2,ms2));
                  }
                  }
                  }
                  }
                  }
                  }
                case "TypeClosure": {ESLVal $813 = _v219.termRef(0);
                    
                    {ESLVal t1 = _v218;
                    
                    {ESLVal f = $813;
                    
                    return subType(t1,f.apply());
                  }
                  }
                  }
                case "RecType": {ESLVal $812 = _v219.termRef(0);
                    ESLVal $811 = _v219.termRef(1);
                    ESLVal $810 = _v219.termRef(2);
                    
                    {ESLVal t1 = _v218;
                    
                    {ESLVal l2 = $812;
                    
                    {ESLVal n2 = $811;
                    
                    {ESLVal t2 = $810;
                    
                    return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
                  }
                  }
                  }
                  }
                  }
                case "ForallType": {ESLVal $809 = _v219.termRef(0);
                    ESLVal $808 = _v219.termRef(1);
                    ESLVal $807 = _v219.termRef(2);
                    
                    {ESLVal t1 = _v218;
                    
                    {ESLVal l1 = $809;
                    
                    {ESLVal ns2 = $808;
                    
                    {ESLVal t2 = $807;
                    
                    return subType(t1,t2);
                  }
                  }
                  }
                  }
                  }
                case "ObservedType": {ESLVal $805 = _v219.termRef(0);
                    ESLVal $804 = _v219.termRef(1);
                    ESLVal $803 = _v219.termRef(2);
                    
                    switch($803.termName) {
                    case "TypeClosure": {ESLVal $806 = $803.termRef(0);
                      
                      {ESLVal t1 = _v218;
                      
                      {ESLVal l = $805;
                      
                      {ESLVal state = $804;
                      
                      {ESLVal f = $806;
                      
                      return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal t1 = _v218;
                      
                      {ESLVal l = $805;
                      
                      {ESLVal state = $804;
                      
                      {ESLVal messages = $803;
                      
                      return subType(t1,expandObservedType(l,state,messages));
                    }
                    }
                    }
                    }
                  }
                  }
                case "ObserverType": {ESLVal $801 = _v219.termRef(0);
                    ESLVal $800 = _v219.termRef(1);
                    ESLVal $799 = _v219.termRef(2);
                    
                    switch($799.termName) {
                    case "TypeClosure": {ESLVal $802 = $799.termRef(0);
                      
                      {ESLVal t1 = _v218;
                      
                      {ESLVal l = $801;
                      
                      {ESLVal state = $800;
                      
                      {ESLVal f = $802;
                      
                      return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal t1 = _v218;
                      
                      {ESLVal l = $801;
                      
                      {ESLVal state = $800;
                      
                      {ESLVal messages = $799;
                      
                      return subType(t1,expandObserverType(l,state,messages));
                    }
                    }
                    }
                    }
                  }
                  }
                  default: {ESLVal t1 = _v218;
                    
                    {ESLVal t2 = _v219;
                    
                    return typeEqual(t1,t2);
                  }
                  }
                }
              }
            else if($896.isNil())
              switch(_v219.termName) {
                case "ApplyTypeFun": {ESLVal $820 = _v219.termRef(0);
                  ESLVal $819 = _v219.termRef(1);
                  ESLVal $818 = _v219.termRef(2);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l = $820;
                  
                  {ESLVal op = $819;
                  
                  {ESLVal args = $818;
                  
                  return subType(t1,applyTypeFun(l,forceType(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $817 = _v219.termRef(0);
                  ESLVal $816 = _v219.termRef(1);
                  ESLVal $815 = _v219.termRef(2);
                  ESLVal $814 = _v219.termRef(3);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l2 = $817;
                  
                  {ESLVal t2 = $816;
                  
                  {ESLVal ds2 = $815;
                  
                  {ESLVal ms2 = $814;
                  
                  return subType(t1,flattenAct(l2,t2,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $813 = _v219.termRef(0);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal f = $813;
                  
                  return subType(t1,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $812 = _v219.termRef(0);
                  ESLVal $811 = _v219.termRef(1);
                  ESLVal $810 = _v219.termRef(2);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l2 = $812;
                  
                  {ESLVal n2 = $811;
                  
                  {ESLVal t2 = $810;
                  
                  return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $809 = _v219.termRef(0);
                  ESLVal $808 = _v219.termRef(1);
                  ESLVal $807 = _v219.termRef(2);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l1 = $809;
                  
                  {ESLVal ns2 = $808;
                  
                  {ESLVal t2 = $807;
                  
                  return subType(t1,t2);
                }
                }
                }
                }
                }
              case "ObservedType": {ESLVal $805 = _v219.termRef(0);
                  ESLVal $804 = _v219.termRef(1);
                  ESLVal $803 = _v219.termRef(2);
                  
                  switch($803.termName) {
                  case "TypeClosure": {ESLVal $806 = $803.termRef(0);
                    
                    {ESLVal t1 = _v218;
                    
                    {ESLVal l = $805;
                    
                    {ESLVal state = $804;
                    
                    {ESLVal f = $806;
                    
                    return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal t1 = _v218;
                    
                    {ESLVal l = $805;
                    
                    {ESLVal state = $804;
                    
                    {ESLVal messages = $803;
                    
                    return subType(t1,expandObservedType(l,state,messages));
                  }
                  }
                  }
                  }
                }
                }
              case "ObserverType": {ESLVal $801 = _v219.termRef(0);
                  ESLVal $800 = _v219.termRef(1);
                  ESLVal $799 = _v219.termRef(2);
                  
                  switch($799.termName) {
                  case "TypeClosure": {ESLVal $802 = $799.termRef(0);
                    
                    {ESLVal t1 = _v218;
                    
                    {ESLVal l = $801;
                    
                    {ESLVal state = $800;
                    
                    {ESLVal f = $802;
                    
                    return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal t1 = _v218;
                    
                    {ESLVal l = $801;
                    
                    {ESLVal state = $800;
                    
                    {ESLVal messages = $799;
                    
                    return subType(t1,expandObserverType(l,state,messages));
                  }
                  }
                  }
                  }
                }
                }
                default: {ESLVal t1 = _v218;
                  
                  {ESLVal t2 = _v219;
                  
                  return typeEqual(t1,t2);
                }
                }
              }
            else switch(_v219.termName) {
                case "ApplyTypeFun": {ESLVal $820 = _v219.termRef(0);
                  ESLVal $819 = _v219.termRef(1);
                  ESLVal $818 = _v219.termRef(2);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l = $820;
                  
                  {ESLVal op = $819;
                  
                  {ESLVal args = $818;
                  
                  return subType(t1,applyTypeFun(l,forceType(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $817 = _v219.termRef(0);
                  ESLVal $816 = _v219.termRef(1);
                  ESLVal $815 = _v219.termRef(2);
                  ESLVal $814 = _v219.termRef(3);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l2 = $817;
                  
                  {ESLVal t2 = $816;
                  
                  {ESLVal ds2 = $815;
                  
                  {ESLVal ms2 = $814;
                  
                  return subType(t1,flattenAct(l2,t2,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $813 = _v219.termRef(0);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal f = $813;
                  
                  return subType(t1,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $812 = _v219.termRef(0);
                  ESLVal $811 = _v219.termRef(1);
                  ESLVal $810 = _v219.termRef(2);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l2 = $812;
                  
                  {ESLVal n2 = $811;
                  
                  {ESLVal t2 = $810;
                  
                  return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $809 = _v219.termRef(0);
                  ESLVal $808 = _v219.termRef(1);
                  ESLVal $807 = _v219.termRef(2);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l1 = $809;
                  
                  {ESLVal ns2 = $808;
                  
                  {ESLVal t2 = $807;
                  
                  return subType(t1,t2);
                }
                }
                }
                }
                }
              case "ObservedType": {ESLVal $805 = _v219.termRef(0);
                  ESLVal $804 = _v219.termRef(1);
                  ESLVal $803 = _v219.termRef(2);
                  
                  switch($803.termName) {
                  case "TypeClosure": {ESLVal $806 = $803.termRef(0);
                    
                    {ESLVal t1 = _v218;
                    
                    {ESLVal l = $805;
                    
                    {ESLVal state = $804;
                    
                    {ESLVal f = $806;
                    
                    return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal t1 = _v218;
                    
                    {ESLVal l = $805;
                    
                    {ESLVal state = $804;
                    
                    {ESLVal messages = $803;
                    
                    return subType(t1,expandObservedType(l,state,messages));
                  }
                  }
                  }
                  }
                }
                }
              case "ObserverType": {ESLVal $801 = _v219.termRef(0);
                  ESLVal $800 = _v219.termRef(1);
                  ESLVal $799 = _v219.termRef(2);
                  
                  switch($799.termName) {
                  case "TypeClosure": {ESLVal $802 = $799.termRef(0);
                    
                    {ESLVal t1 = _v218;
                    
                    {ESLVal l = $801;
                    
                    {ESLVal state = $800;
                    
                    {ESLVal f = $802;
                    
                    return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal t1 = _v218;
                    
                    {ESLVal l = $801;
                    
                    {ESLVal state = $800;
                    
                    {ESLVal messages = $799;
                    
                    return subType(t1,expandObserverType(l,state,messages));
                  }
                  }
                  }
                  }
                }
                }
                default: {ESLVal t1 = _v218;
                  
                  {ESLVal t2 = _v219;
                  
                  return typeEqual(t1,t2);
                }
                }
              }
            }
            default: switch(_v219.termName) {
              case "ApplyTypeFun": {ESLVal $820 = _v219.termRef(0);
                ESLVal $819 = _v219.termRef(1);
                ESLVal $818 = _v219.termRef(2);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l = $820;
                
                {ESLVal op = $819;
                
                {ESLVal args = $818;
                
                return subType(t1,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $817 = _v219.termRef(0);
                ESLVal $816 = _v219.termRef(1);
                ESLVal $815 = _v219.termRef(2);
                ESLVal $814 = _v219.termRef(3);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l2 = $817;
                
                {ESLVal t2 = $816;
                
                {ESLVal ds2 = $815;
                
                {ESLVal ms2 = $814;
                
                return subType(t1,flattenAct(l2,t2,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $813 = _v219.termRef(0);
                
                {ESLVal t1 = _v218;
                
                {ESLVal f = $813;
                
                return subType(t1,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $812 = _v219.termRef(0);
                ESLVal $811 = _v219.termRef(1);
                ESLVal $810 = _v219.termRef(2);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l2 = $812;
                
                {ESLVal n2 = $811;
                
                {ESLVal t2 = $810;
                
                return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $809 = _v219.termRef(0);
                ESLVal $808 = _v219.termRef(1);
                ESLVal $807 = _v219.termRef(2);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l1 = $809;
                
                {ESLVal ns2 = $808;
                
                {ESLVal t2 = $807;
                
                return subType(t1,t2);
              }
              }
              }
              }
              }
            case "ObservedType": {ESLVal $805 = _v219.termRef(0);
                ESLVal $804 = _v219.termRef(1);
                ESLVal $803 = _v219.termRef(2);
                
                switch($803.termName) {
                case "TypeClosure": {ESLVal $806 = $803.termRef(0);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l = $805;
                  
                  {ESLVal state = $804;
                  
                  {ESLVal f = $806;
                  
                  return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v218;
                  
                  {ESLVal l = $805;
                  
                  {ESLVal state = $804;
                  
                  {ESLVal messages = $803;
                  
                  return subType(t1,expandObservedType(l,state,messages));
                }
                }
                }
                }
              }
              }
            case "ObserverType": {ESLVal $801 = _v219.termRef(0);
                ESLVal $800 = _v219.termRef(1);
                ESLVal $799 = _v219.termRef(2);
                
                switch($799.termName) {
                case "TypeClosure": {ESLVal $802 = $799.termRef(0);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l = $801;
                  
                  {ESLVal state = $800;
                  
                  {ESLVal f = $802;
                  
                  return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v218;
                  
                  {ESLVal l = $801;
                  
                  {ESLVal state = $800;
                  
                  {ESLVal messages = $799;
                  
                  return subType(t1,expandObserverType(l,state,messages));
                }
                }
                }
                }
              }
              }
              default: {ESLVal t1 = _v218;
                
                {ESLVal t2 = _v219;
                
                return typeEqual(t1,t2);
              }
              }
            }
          }
          }
        case "BagType": {ESLVal $890 = _v218.termRef(0);
            ESLVal $889 = _v218.termRef(1);
            
            switch(_v219.termName) {
            case "BagType": {ESLVal $892 = _v219.termRef(0);
              ESLVal $891 = _v219.termRef(1);
              
              {ESLVal l1 = $890;
              
              {ESLVal t1 = $889;
              
              {ESLVal l2 = $892;
              
              {ESLVal t2 = $891;
              
              return subType(t1,t2);
            }
            }
            }
            }
            }
            default: switch(_v219.termName) {
              case "ApplyTypeFun": {ESLVal $820 = _v219.termRef(0);
                ESLVal $819 = _v219.termRef(1);
                ESLVal $818 = _v219.termRef(2);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l = $820;
                
                {ESLVal op = $819;
                
                {ESLVal args = $818;
                
                return subType(t1,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $817 = _v219.termRef(0);
                ESLVal $816 = _v219.termRef(1);
                ESLVal $815 = _v219.termRef(2);
                ESLVal $814 = _v219.termRef(3);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l2 = $817;
                
                {ESLVal t2 = $816;
                
                {ESLVal ds2 = $815;
                
                {ESLVal ms2 = $814;
                
                return subType(t1,flattenAct(l2,t2,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $813 = _v219.termRef(0);
                
                {ESLVal t1 = _v218;
                
                {ESLVal f = $813;
                
                return subType(t1,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $812 = _v219.termRef(0);
                ESLVal $811 = _v219.termRef(1);
                ESLVal $810 = _v219.termRef(2);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l2 = $812;
                
                {ESLVal n2 = $811;
                
                {ESLVal t2 = $810;
                
                return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $809 = _v219.termRef(0);
                ESLVal $808 = _v219.termRef(1);
                ESLVal $807 = _v219.termRef(2);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l1 = $809;
                
                {ESLVal ns2 = $808;
                
                {ESLVal t2 = $807;
                
                return subType(t1,t2);
              }
              }
              }
              }
              }
            case "ObservedType": {ESLVal $805 = _v219.termRef(0);
                ESLVal $804 = _v219.termRef(1);
                ESLVal $803 = _v219.termRef(2);
                
                switch($803.termName) {
                case "TypeClosure": {ESLVal $806 = $803.termRef(0);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l = $805;
                  
                  {ESLVal state = $804;
                  
                  {ESLVal f = $806;
                  
                  return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v218;
                  
                  {ESLVal l = $805;
                  
                  {ESLVal state = $804;
                  
                  {ESLVal messages = $803;
                  
                  return subType(t1,expandObservedType(l,state,messages));
                }
                }
                }
                }
              }
              }
            case "ObserverType": {ESLVal $801 = _v219.termRef(0);
                ESLVal $800 = _v219.termRef(1);
                ESLVal $799 = _v219.termRef(2);
                
                switch($799.termName) {
                case "TypeClosure": {ESLVal $802 = $799.termRef(0);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l = $801;
                  
                  {ESLVal state = $800;
                  
                  {ESLVal f = $802;
                  
                  return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v218;
                  
                  {ESLVal l = $801;
                  
                  {ESLVal state = $800;
                  
                  {ESLVal messages = $799;
                  
                  return subType(t1,expandObserverType(l,state,messages));
                }
                }
                }
                }
              }
              }
              default: {ESLVal t1 = _v218;
                
                {ESLVal t2 = _v219;
                
                return typeEqual(t1,t2);
              }
              }
            }
          }
          }
        case "SetType": {ESLVal $875 = _v218.termRef(0);
            ESLVal $874 = _v218.termRef(1);
            
            switch(_v219.termName) {
            case "SetType": {ESLVal $888 = _v219.termRef(0);
              ESLVal $887 = _v219.termRef(1);
              
              {ESLVal l1 = $875;
              
              {ESLVal t1 = $874;
              
              {ESLVal l2 = $888;
              
              {ESLVal t2 = $887;
              
              return subType(t1,t2);
            }
            }
            }
            }
            }
          case "ForallType": {ESLVal $878 = _v219.termRef(0);
              ESLVal $877 = _v219.termRef(1);
              ESLVal $876 = _v219.termRef(2);
              
              if($877.isCons())
              {ESLVal $879 = $877.head();
                ESLVal $880 = $877.tail();
                
                if($880.isCons())
                {ESLVal $881 = $880.head();
                  ESLVal $882 = $880.tail();
                  
                  switch(_v219.termName) {
                  case "ApplyTypeFun": {ESLVal $820 = _v219.termRef(0);
                    ESLVal $819 = _v219.termRef(1);
                    ESLVal $818 = _v219.termRef(2);
                    
                    {ESLVal t1 = _v218;
                    
                    {ESLVal l = $820;
                    
                    {ESLVal op = $819;
                    
                    {ESLVal args = $818;
                    
                    return subType(t1,applyTypeFun(l,forceType(op),args));
                  }
                  }
                  }
                  }
                  }
                case "ExtendedAct": {ESLVal $817 = _v219.termRef(0);
                    ESLVal $816 = _v219.termRef(1);
                    ESLVal $815 = _v219.termRef(2);
                    ESLVal $814 = _v219.termRef(3);
                    
                    {ESLVal t1 = _v218;
                    
                    {ESLVal l2 = $817;
                    
                    {ESLVal t2 = $816;
                    
                    {ESLVal ds2 = $815;
                    
                    {ESLVal ms2 = $814;
                    
                    return subType(t1,flattenAct(l2,t2,ds2,ms2));
                  }
                  }
                  }
                  }
                  }
                  }
                case "TypeClosure": {ESLVal $813 = _v219.termRef(0);
                    
                    {ESLVal t1 = _v218;
                    
                    {ESLVal f = $813;
                    
                    return subType(t1,f.apply());
                  }
                  }
                  }
                case "RecType": {ESLVal $812 = _v219.termRef(0);
                    ESLVal $811 = _v219.termRef(1);
                    ESLVal $810 = _v219.termRef(2);
                    
                    {ESLVal t1 = _v218;
                    
                    {ESLVal l2 = $812;
                    
                    {ESLVal n2 = $811;
                    
                    {ESLVal t2 = $810;
                    
                    return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
                  }
                  }
                  }
                  }
                  }
                case "ForallType": {ESLVal $809 = _v219.termRef(0);
                    ESLVal $808 = _v219.termRef(1);
                    ESLVal $807 = _v219.termRef(2);
                    
                    {ESLVal t1 = _v218;
                    
                    {ESLVal l1 = $809;
                    
                    {ESLVal ns2 = $808;
                    
                    {ESLVal t2 = $807;
                    
                    return subType(t1,t2);
                  }
                  }
                  }
                  }
                  }
                case "ObservedType": {ESLVal $805 = _v219.termRef(0);
                    ESLVal $804 = _v219.termRef(1);
                    ESLVal $803 = _v219.termRef(2);
                    
                    switch($803.termName) {
                    case "TypeClosure": {ESLVal $806 = $803.termRef(0);
                      
                      {ESLVal t1 = _v218;
                      
                      {ESLVal l = $805;
                      
                      {ESLVal state = $804;
                      
                      {ESLVal f = $806;
                      
                      return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal t1 = _v218;
                      
                      {ESLVal l = $805;
                      
                      {ESLVal state = $804;
                      
                      {ESLVal messages = $803;
                      
                      return subType(t1,expandObservedType(l,state,messages));
                    }
                    }
                    }
                    }
                  }
                  }
                case "ObserverType": {ESLVal $801 = _v219.termRef(0);
                    ESLVal $800 = _v219.termRef(1);
                    ESLVal $799 = _v219.termRef(2);
                    
                    switch($799.termName) {
                    case "TypeClosure": {ESLVal $802 = $799.termRef(0);
                      
                      {ESLVal t1 = _v218;
                      
                      {ESLVal l = $801;
                      
                      {ESLVal state = $800;
                      
                      {ESLVal f = $802;
                      
                      return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal t1 = _v218;
                      
                      {ESLVal l = $801;
                      
                      {ESLVal state = $800;
                      
                      {ESLVal messages = $799;
                      
                      return subType(t1,expandObserverType(l,state,messages));
                    }
                    }
                    }
                    }
                  }
                  }
                  default: {ESLVal t1 = _v218;
                    
                    {ESLVal t2 = _v219;
                    
                    return typeEqual(t1,t2);
                  }
                  }
                }
                }
              else if($880.isNil())
                switch($876.termName) {
                  case "SetType": {ESLVal $884 = $876.termRef(0);
                    ESLVal $883 = $876.termRef(1);
                    
                    switch($883.termName) {
                    case "VarType": {ESLVal $886 = $883.termRef(0);
                      ESLVal $885 = $883.termRef(1);
                      
                      {ESLVal l1 = $875;
                      
                      {ESLVal t1 = $874;
                      
                      {ESLVal l2 = $878;
                      
                      {ESLVal v1 = $879;
                      
                      {ESLVal l3 = $884;
                      
                      {ESLVal l4 = $886;
                      
                      {ESLVal v2 = $885;
                      
                      if(v1.eql(v2).boolVal)
                      return $true;
                      else
                        switch(_v219.termName) {
                          case "ApplyTypeFun": {ESLVal $820 = _v219.termRef(0);
                            ESLVal $819 = _v219.termRef(1);
                            ESLVal $818 = _v219.termRef(2);
                            
                            {ESLVal _v357 = _v218;
                            
                            {ESLVal l = $820;
                            
                            {ESLVal op = $819;
                            
                            {ESLVal args = $818;
                            
                            return subType(_v357,applyTypeFun(l,forceType(op),args));
                          }
                          }
                          }
                          }
                          }
                        case "ExtendedAct": {ESLVal $817 = _v219.termRef(0);
                            ESLVal $816 = _v219.termRef(1);
                            ESLVal $815 = _v219.termRef(2);
                            ESLVal $814 = _v219.termRef(3);
                            
                            {ESLVal _v355 = _v218;
                            
                            {ESLVal _v356 = $817;
                            
                            {ESLVal t2 = $816;
                            
                            {ESLVal ds2 = $815;
                            
                            {ESLVal ms2 = $814;
                            
                            return subType(_v355,flattenAct(_v356,t2,ds2,ms2));
                          }
                          }
                          }
                          }
                          }
                          }
                        case "TypeClosure": {ESLVal $813 = _v219.termRef(0);
                            
                            {ESLVal _v354 = _v218;
                            
                            {ESLVal f = $813;
                            
                            return subType(_v354,f.apply());
                          }
                          }
                          }
                        case "RecType": {ESLVal $812 = _v219.termRef(0);
                            ESLVal $811 = _v219.termRef(1);
                            ESLVal $810 = _v219.termRef(2);
                            
                            {ESLVal _v352 = _v218;
                            
                            {ESLVal _v353 = $812;
                            
                            {ESLVal n2 = $811;
                            
                            {ESLVal t2 = $810;
                            
                            return subType(_v352,substType(new ESLVal("RecType",_v353,n2,t2),n2,t2));
                          }
                          }
                          }
                          }
                          }
                        case "ForallType": {ESLVal $809 = _v219.termRef(0);
                            ESLVal $808 = _v219.termRef(1);
                            ESLVal $807 = _v219.termRef(2);
                            
                            {ESLVal _v350 = _v218;
                            
                            {ESLVal _v351 = $809;
                            
                            {ESLVal ns2 = $808;
                            
                            {ESLVal t2 = $807;
                            
                            return subType(_v350,t2);
                          }
                          }
                          }
                          }
                          }
                        case "ObservedType": {ESLVal $805 = _v219.termRef(0);
                            ESLVal $804 = _v219.termRef(1);
                            ESLVal $803 = _v219.termRef(2);
                            
                            switch($803.termName) {
                            case "TypeClosure": {ESLVal $806 = $803.termRef(0);
                              
                              {ESLVal _v348 = _v218;
                              
                              {ESLVal l = $805;
                              
                              {ESLVal state = $804;
                              
                              {ESLVal f = $806;
                              
                              return subType(_v348,new ESLVal("ObservedType",l,state,f.apply()));
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v349 = _v218;
                              
                              {ESLVal l = $805;
                              
                              {ESLVal state = $804;
                              
                              {ESLVal messages = $803;
                              
                              return subType(_v349,expandObservedType(l,state,messages));
                            }
                            }
                            }
                            }
                          }
                          }
                        case "ObserverType": {ESLVal $801 = _v219.termRef(0);
                            ESLVal $800 = _v219.termRef(1);
                            ESLVal $799 = _v219.termRef(2);
                            
                            switch($799.termName) {
                            case "TypeClosure": {ESLVal $802 = $799.termRef(0);
                              
                              {ESLVal _v346 = _v218;
                              
                              {ESLVal l = $801;
                              
                              {ESLVal state = $800;
                              
                              {ESLVal f = $802;
                              
                              return subType(_v346,new ESLVal("ObserverType",l,state,f.apply()));
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v347 = _v218;
                              
                              {ESLVal l = $801;
                              
                              {ESLVal state = $800;
                              
                              {ESLVal messages = $799;
                              
                              return subType(_v347,expandObserverType(l,state,messages));
                            }
                            }
                            }
                            }
                          }
                          }
                          default: {ESLVal _v358 = _v218;
                            
                            {ESLVal t2 = _v219;
                            
                            return typeEqual(_v358,t2);
                          }
                          }
                        }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: switch(_v219.termName) {
                      case "ApplyTypeFun": {ESLVal $820 = _v219.termRef(0);
                        ESLVal $819 = _v219.termRef(1);
                        ESLVal $818 = _v219.termRef(2);
                        
                        {ESLVal t1 = _v218;
                        
                        {ESLVal l = $820;
                        
                        {ESLVal op = $819;
                        
                        {ESLVal args = $818;
                        
                        return subType(t1,applyTypeFun(l,forceType(op),args));
                      }
                      }
                      }
                      }
                      }
                    case "ExtendedAct": {ESLVal $817 = _v219.termRef(0);
                        ESLVal $816 = _v219.termRef(1);
                        ESLVal $815 = _v219.termRef(2);
                        ESLVal $814 = _v219.termRef(3);
                        
                        {ESLVal t1 = _v218;
                        
                        {ESLVal l2 = $817;
                        
                        {ESLVal t2 = $816;
                        
                        {ESLVal ds2 = $815;
                        
                        {ESLVal ms2 = $814;
                        
                        return subType(t1,flattenAct(l2,t2,ds2,ms2));
                      }
                      }
                      }
                      }
                      }
                      }
                    case "TypeClosure": {ESLVal $813 = _v219.termRef(0);
                        
                        {ESLVal t1 = _v218;
                        
                        {ESLVal f = $813;
                        
                        return subType(t1,f.apply());
                      }
                      }
                      }
                    case "RecType": {ESLVal $812 = _v219.termRef(0);
                        ESLVal $811 = _v219.termRef(1);
                        ESLVal $810 = _v219.termRef(2);
                        
                        {ESLVal t1 = _v218;
                        
                        {ESLVal l2 = $812;
                        
                        {ESLVal n2 = $811;
                        
                        {ESLVal t2 = $810;
                        
                        return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
                      }
                      }
                      }
                      }
                      }
                    case "ForallType": {ESLVal $809 = _v219.termRef(0);
                        ESLVal $808 = _v219.termRef(1);
                        ESLVal $807 = _v219.termRef(2);
                        
                        {ESLVal t1 = _v218;
                        
                        {ESLVal l1 = $809;
                        
                        {ESLVal ns2 = $808;
                        
                        {ESLVal t2 = $807;
                        
                        return subType(t1,t2);
                      }
                      }
                      }
                      }
                      }
                    case "ObservedType": {ESLVal $805 = _v219.termRef(0);
                        ESLVal $804 = _v219.termRef(1);
                        ESLVal $803 = _v219.termRef(2);
                        
                        switch($803.termName) {
                        case "TypeClosure": {ESLVal $806 = $803.termRef(0);
                          
                          {ESLVal t1 = _v218;
                          
                          {ESLVal l = $805;
                          
                          {ESLVal state = $804;
                          
                          {ESLVal f = $806;
                          
                          return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal t1 = _v218;
                          
                          {ESLVal l = $805;
                          
                          {ESLVal state = $804;
                          
                          {ESLVal messages = $803;
                          
                          return subType(t1,expandObservedType(l,state,messages));
                        }
                        }
                        }
                        }
                      }
                      }
                    case "ObserverType": {ESLVal $801 = _v219.termRef(0);
                        ESLVal $800 = _v219.termRef(1);
                        ESLVal $799 = _v219.termRef(2);
                        
                        switch($799.termName) {
                        case "TypeClosure": {ESLVal $802 = $799.termRef(0);
                          
                          {ESLVal t1 = _v218;
                          
                          {ESLVal l = $801;
                          
                          {ESLVal state = $800;
                          
                          {ESLVal f = $802;
                          
                          return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal t1 = _v218;
                          
                          {ESLVal l = $801;
                          
                          {ESLVal state = $800;
                          
                          {ESLVal messages = $799;
                          
                          return subType(t1,expandObserverType(l,state,messages));
                        }
                        }
                        }
                        }
                      }
                      }
                      default: {ESLVal t1 = _v218;
                        
                        {ESLVal t2 = _v219;
                        
                        return typeEqual(t1,t2);
                      }
                      }
                    }
                  }
                  }
                  default: switch(_v219.termName) {
                    case "ApplyTypeFun": {ESLVal $820 = _v219.termRef(0);
                      ESLVal $819 = _v219.termRef(1);
                      ESLVal $818 = _v219.termRef(2);
                      
                      {ESLVal t1 = _v218;
                      
                      {ESLVal l = $820;
                      
                      {ESLVal op = $819;
                      
                      {ESLVal args = $818;
                      
                      return subType(t1,applyTypeFun(l,forceType(op),args));
                    }
                    }
                    }
                    }
                    }
                  case "ExtendedAct": {ESLVal $817 = _v219.termRef(0);
                      ESLVal $816 = _v219.termRef(1);
                      ESLVal $815 = _v219.termRef(2);
                      ESLVal $814 = _v219.termRef(3);
                      
                      {ESLVal t1 = _v218;
                      
                      {ESLVal l2 = $817;
                      
                      {ESLVal t2 = $816;
                      
                      {ESLVal ds2 = $815;
                      
                      {ESLVal ms2 = $814;
                      
                      return subType(t1,flattenAct(l2,t2,ds2,ms2));
                    }
                    }
                    }
                    }
                    }
                    }
                  case "TypeClosure": {ESLVal $813 = _v219.termRef(0);
                      
                      {ESLVal t1 = _v218;
                      
                      {ESLVal f = $813;
                      
                      return subType(t1,f.apply());
                    }
                    }
                    }
                  case "RecType": {ESLVal $812 = _v219.termRef(0);
                      ESLVal $811 = _v219.termRef(1);
                      ESLVal $810 = _v219.termRef(2);
                      
                      {ESLVal t1 = _v218;
                      
                      {ESLVal l2 = $812;
                      
                      {ESLVal n2 = $811;
                      
                      {ESLVal t2 = $810;
                      
                      return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
                    }
                    }
                    }
                    }
                    }
                  case "ForallType": {ESLVal $809 = _v219.termRef(0);
                      ESLVal $808 = _v219.termRef(1);
                      ESLVal $807 = _v219.termRef(2);
                      
                      {ESLVal t1 = _v218;
                      
                      {ESLVal l1 = $809;
                      
                      {ESLVal ns2 = $808;
                      
                      {ESLVal t2 = $807;
                      
                      return subType(t1,t2);
                    }
                    }
                    }
                    }
                    }
                  case "ObservedType": {ESLVal $805 = _v219.termRef(0);
                      ESLVal $804 = _v219.termRef(1);
                      ESLVal $803 = _v219.termRef(2);
                      
                      switch($803.termName) {
                      case "TypeClosure": {ESLVal $806 = $803.termRef(0);
                        
                        {ESLVal t1 = _v218;
                        
                        {ESLVal l = $805;
                        
                        {ESLVal state = $804;
                        
                        {ESLVal f = $806;
                        
                        return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal t1 = _v218;
                        
                        {ESLVal l = $805;
                        
                        {ESLVal state = $804;
                        
                        {ESLVal messages = $803;
                        
                        return subType(t1,expandObservedType(l,state,messages));
                      }
                      }
                      }
                      }
                    }
                    }
                  case "ObserverType": {ESLVal $801 = _v219.termRef(0);
                      ESLVal $800 = _v219.termRef(1);
                      ESLVal $799 = _v219.termRef(2);
                      
                      switch($799.termName) {
                      case "TypeClosure": {ESLVal $802 = $799.termRef(0);
                        
                        {ESLVal t1 = _v218;
                        
                        {ESLVal l = $801;
                        
                        {ESLVal state = $800;
                        
                        {ESLVal f = $802;
                        
                        return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal t1 = _v218;
                        
                        {ESLVal l = $801;
                        
                        {ESLVal state = $800;
                        
                        {ESLVal messages = $799;
                        
                        return subType(t1,expandObserverType(l,state,messages));
                      }
                      }
                      }
                      }
                    }
                    }
                    default: {ESLVal t1 = _v218;
                      
                      {ESLVal t2 = _v219;
                      
                      return typeEqual(t1,t2);
                    }
                    }
                  }
                }
              else switch(_v219.termName) {
                  case "ApplyTypeFun": {ESLVal $820 = _v219.termRef(0);
                    ESLVal $819 = _v219.termRef(1);
                    ESLVal $818 = _v219.termRef(2);
                    
                    {ESLVal t1 = _v218;
                    
                    {ESLVal l = $820;
                    
                    {ESLVal op = $819;
                    
                    {ESLVal args = $818;
                    
                    return subType(t1,applyTypeFun(l,forceType(op),args));
                  }
                  }
                  }
                  }
                  }
                case "ExtendedAct": {ESLVal $817 = _v219.termRef(0);
                    ESLVal $816 = _v219.termRef(1);
                    ESLVal $815 = _v219.termRef(2);
                    ESLVal $814 = _v219.termRef(3);
                    
                    {ESLVal t1 = _v218;
                    
                    {ESLVal l2 = $817;
                    
                    {ESLVal t2 = $816;
                    
                    {ESLVal ds2 = $815;
                    
                    {ESLVal ms2 = $814;
                    
                    return subType(t1,flattenAct(l2,t2,ds2,ms2));
                  }
                  }
                  }
                  }
                  }
                  }
                case "TypeClosure": {ESLVal $813 = _v219.termRef(0);
                    
                    {ESLVal t1 = _v218;
                    
                    {ESLVal f = $813;
                    
                    return subType(t1,f.apply());
                  }
                  }
                  }
                case "RecType": {ESLVal $812 = _v219.termRef(0);
                    ESLVal $811 = _v219.termRef(1);
                    ESLVal $810 = _v219.termRef(2);
                    
                    {ESLVal t1 = _v218;
                    
                    {ESLVal l2 = $812;
                    
                    {ESLVal n2 = $811;
                    
                    {ESLVal t2 = $810;
                    
                    return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
                  }
                  }
                  }
                  }
                  }
                case "ForallType": {ESLVal $809 = _v219.termRef(0);
                    ESLVal $808 = _v219.termRef(1);
                    ESLVal $807 = _v219.termRef(2);
                    
                    {ESLVal t1 = _v218;
                    
                    {ESLVal l1 = $809;
                    
                    {ESLVal ns2 = $808;
                    
                    {ESLVal t2 = $807;
                    
                    return subType(t1,t2);
                  }
                  }
                  }
                  }
                  }
                case "ObservedType": {ESLVal $805 = _v219.termRef(0);
                    ESLVal $804 = _v219.termRef(1);
                    ESLVal $803 = _v219.termRef(2);
                    
                    switch($803.termName) {
                    case "TypeClosure": {ESLVal $806 = $803.termRef(0);
                      
                      {ESLVal t1 = _v218;
                      
                      {ESLVal l = $805;
                      
                      {ESLVal state = $804;
                      
                      {ESLVal f = $806;
                      
                      return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal t1 = _v218;
                      
                      {ESLVal l = $805;
                      
                      {ESLVal state = $804;
                      
                      {ESLVal messages = $803;
                      
                      return subType(t1,expandObservedType(l,state,messages));
                    }
                    }
                    }
                    }
                  }
                  }
                case "ObserverType": {ESLVal $801 = _v219.termRef(0);
                    ESLVal $800 = _v219.termRef(1);
                    ESLVal $799 = _v219.termRef(2);
                    
                    switch($799.termName) {
                    case "TypeClosure": {ESLVal $802 = $799.termRef(0);
                      
                      {ESLVal t1 = _v218;
                      
                      {ESLVal l = $801;
                      
                      {ESLVal state = $800;
                      
                      {ESLVal f = $802;
                      
                      return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal t1 = _v218;
                      
                      {ESLVal l = $801;
                      
                      {ESLVal state = $800;
                      
                      {ESLVal messages = $799;
                      
                      return subType(t1,expandObserverType(l,state,messages));
                    }
                    }
                    }
                    }
                  }
                  }
                  default: {ESLVal t1 = _v218;
                    
                    {ESLVal t2 = _v219;
                    
                    return typeEqual(t1,t2);
                  }
                  }
                }
              }
            else if($877.isNil())
              switch(_v219.termName) {
                case "ApplyTypeFun": {ESLVal $820 = _v219.termRef(0);
                  ESLVal $819 = _v219.termRef(1);
                  ESLVal $818 = _v219.termRef(2);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l = $820;
                  
                  {ESLVal op = $819;
                  
                  {ESLVal args = $818;
                  
                  return subType(t1,applyTypeFun(l,forceType(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $817 = _v219.termRef(0);
                  ESLVal $816 = _v219.termRef(1);
                  ESLVal $815 = _v219.termRef(2);
                  ESLVal $814 = _v219.termRef(3);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l2 = $817;
                  
                  {ESLVal t2 = $816;
                  
                  {ESLVal ds2 = $815;
                  
                  {ESLVal ms2 = $814;
                  
                  return subType(t1,flattenAct(l2,t2,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $813 = _v219.termRef(0);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal f = $813;
                  
                  return subType(t1,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $812 = _v219.termRef(0);
                  ESLVal $811 = _v219.termRef(1);
                  ESLVal $810 = _v219.termRef(2);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l2 = $812;
                  
                  {ESLVal n2 = $811;
                  
                  {ESLVal t2 = $810;
                  
                  return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $809 = _v219.termRef(0);
                  ESLVal $808 = _v219.termRef(1);
                  ESLVal $807 = _v219.termRef(2);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l1 = $809;
                  
                  {ESLVal ns2 = $808;
                  
                  {ESLVal t2 = $807;
                  
                  return subType(t1,t2);
                }
                }
                }
                }
                }
              case "ObservedType": {ESLVal $805 = _v219.termRef(0);
                  ESLVal $804 = _v219.termRef(1);
                  ESLVal $803 = _v219.termRef(2);
                  
                  switch($803.termName) {
                  case "TypeClosure": {ESLVal $806 = $803.termRef(0);
                    
                    {ESLVal t1 = _v218;
                    
                    {ESLVal l = $805;
                    
                    {ESLVal state = $804;
                    
                    {ESLVal f = $806;
                    
                    return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal t1 = _v218;
                    
                    {ESLVal l = $805;
                    
                    {ESLVal state = $804;
                    
                    {ESLVal messages = $803;
                    
                    return subType(t1,expandObservedType(l,state,messages));
                  }
                  }
                  }
                  }
                }
                }
              case "ObserverType": {ESLVal $801 = _v219.termRef(0);
                  ESLVal $800 = _v219.termRef(1);
                  ESLVal $799 = _v219.termRef(2);
                  
                  switch($799.termName) {
                  case "TypeClosure": {ESLVal $802 = $799.termRef(0);
                    
                    {ESLVal t1 = _v218;
                    
                    {ESLVal l = $801;
                    
                    {ESLVal state = $800;
                    
                    {ESLVal f = $802;
                    
                    return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal t1 = _v218;
                    
                    {ESLVal l = $801;
                    
                    {ESLVal state = $800;
                    
                    {ESLVal messages = $799;
                    
                    return subType(t1,expandObserverType(l,state,messages));
                  }
                  }
                  }
                  }
                }
                }
                default: {ESLVal t1 = _v218;
                  
                  {ESLVal t2 = _v219;
                  
                  return typeEqual(t1,t2);
                }
                }
              }
            else switch(_v219.termName) {
                case "ApplyTypeFun": {ESLVal $820 = _v219.termRef(0);
                  ESLVal $819 = _v219.termRef(1);
                  ESLVal $818 = _v219.termRef(2);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l = $820;
                  
                  {ESLVal op = $819;
                  
                  {ESLVal args = $818;
                  
                  return subType(t1,applyTypeFun(l,forceType(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $817 = _v219.termRef(0);
                  ESLVal $816 = _v219.termRef(1);
                  ESLVal $815 = _v219.termRef(2);
                  ESLVal $814 = _v219.termRef(3);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l2 = $817;
                  
                  {ESLVal t2 = $816;
                  
                  {ESLVal ds2 = $815;
                  
                  {ESLVal ms2 = $814;
                  
                  return subType(t1,flattenAct(l2,t2,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $813 = _v219.termRef(0);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal f = $813;
                  
                  return subType(t1,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $812 = _v219.termRef(0);
                  ESLVal $811 = _v219.termRef(1);
                  ESLVal $810 = _v219.termRef(2);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l2 = $812;
                  
                  {ESLVal n2 = $811;
                  
                  {ESLVal t2 = $810;
                  
                  return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $809 = _v219.termRef(0);
                  ESLVal $808 = _v219.termRef(1);
                  ESLVal $807 = _v219.termRef(2);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l1 = $809;
                  
                  {ESLVal ns2 = $808;
                  
                  {ESLVal t2 = $807;
                  
                  return subType(t1,t2);
                }
                }
                }
                }
                }
              case "ObservedType": {ESLVal $805 = _v219.termRef(0);
                  ESLVal $804 = _v219.termRef(1);
                  ESLVal $803 = _v219.termRef(2);
                  
                  switch($803.termName) {
                  case "TypeClosure": {ESLVal $806 = $803.termRef(0);
                    
                    {ESLVal t1 = _v218;
                    
                    {ESLVal l = $805;
                    
                    {ESLVal state = $804;
                    
                    {ESLVal f = $806;
                    
                    return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal t1 = _v218;
                    
                    {ESLVal l = $805;
                    
                    {ESLVal state = $804;
                    
                    {ESLVal messages = $803;
                    
                    return subType(t1,expandObservedType(l,state,messages));
                  }
                  }
                  }
                  }
                }
                }
              case "ObserverType": {ESLVal $801 = _v219.termRef(0);
                  ESLVal $800 = _v219.termRef(1);
                  ESLVal $799 = _v219.termRef(2);
                  
                  switch($799.termName) {
                  case "TypeClosure": {ESLVal $802 = $799.termRef(0);
                    
                    {ESLVal t1 = _v218;
                    
                    {ESLVal l = $801;
                    
                    {ESLVal state = $800;
                    
                    {ESLVal f = $802;
                    
                    return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal t1 = _v218;
                    
                    {ESLVal l = $801;
                    
                    {ESLVal state = $800;
                    
                    {ESLVal messages = $799;
                    
                    return subType(t1,expandObserverType(l,state,messages));
                  }
                  }
                  }
                  }
                }
                }
                default: {ESLVal t1 = _v218;
                  
                  {ESLVal t2 = _v219;
                  
                  return typeEqual(t1,t2);
                }
                }
              }
            }
            default: switch(_v219.termName) {
              case "ApplyTypeFun": {ESLVal $820 = _v219.termRef(0);
                ESLVal $819 = _v219.termRef(1);
                ESLVal $818 = _v219.termRef(2);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l = $820;
                
                {ESLVal op = $819;
                
                {ESLVal args = $818;
                
                return subType(t1,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $817 = _v219.termRef(0);
                ESLVal $816 = _v219.termRef(1);
                ESLVal $815 = _v219.termRef(2);
                ESLVal $814 = _v219.termRef(3);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l2 = $817;
                
                {ESLVal t2 = $816;
                
                {ESLVal ds2 = $815;
                
                {ESLVal ms2 = $814;
                
                return subType(t1,flattenAct(l2,t2,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $813 = _v219.termRef(0);
                
                {ESLVal t1 = _v218;
                
                {ESLVal f = $813;
                
                return subType(t1,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $812 = _v219.termRef(0);
                ESLVal $811 = _v219.termRef(1);
                ESLVal $810 = _v219.termRef(2);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l2 = $812;
                
                {ESLVal n2 = $811;
                
                {ESLVal t2 = $810;
                
                return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $809 = _v219.termRef(0);
                ESLVal $808 = _v219.termRef(1);
                ESLVal $807 = _v219.termRef(2);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l1 = $809;
                
                {ESLVal ns2 = $808;
                
                {ESLVal t2 = $807;
                
                return subType(t1,t2);
              }
              }
              }
              }
              }
            case "ObservedType": {ESLVal $805 = _v219.termRef(0);
                ESLVal $804 = _v219.termRef(1);
                ESLVal $803 = _v219.termRef(2);
                
                switch($803.termName) {
                case "TypeClosure": {ESLVal $806 = $803.termRef(0);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l = $805;
                  
                  {ESLVal state = $804;
                  
                  {ESLVal f = $806;
                  
                  return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v218;
                  
                  {ESLVal l = $805;
                  
                  {ESLVal state = $804;
                  
                  {ESLVal messages = $803;
                  
                  return subType(t1,expandObservedType(l,state,messages));
                }
                }
                }
                }
              }
              }
            case "ObserverType": {ESLVal $801 = _v219.termRef(0);
                ESLVal $800 = _v219.termRef(1);
                ESLVal $799 = _v219.termRef(2);
                
                switch($799.termName) {
                case "TypeClosure": {ESLVal $802 = $799.termRef(0);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l = $801;
                  
                  {ESLVal state = $800;
                  
                  {ESLVal f = $802;
                  
                  return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v218;
                  
                  {ESLVal l = $801;
                  
                  {ESLVal state = $800;
                  
                  {ESLVal messages = $799;
                  
                  return subType(t1,expandObserverType(l,state,messages));
                }
                }
                }
                }
              }
              }
              default: {ESLVal t1 = _v218;
                
                {ESLVal t2 = _v219;
                
                return typeEqual(t1,t2);
              }
              }
            }
          }
          }
        case "TermType": {ESLVal $870 = _v218.termRef(0);
            ESLVal $869 = _v218.termRef(1);
            ESLVal $868 = _v218.termRef(2);
            
            switch(_v219.termName) {
            case "TermType": {ESLVal $873 = _v219.termRef(0);
              ESLVal $872 = _v219.termRef(1);
              ESLVal $871 = _v219.termRef(2);
              
              {ESLVal l1 = $870;
              
              {ESLVal n1 = $869;
              
              {ESLVal args1 = $868;
              
              {ESLVal l2 = $873;
              
              {ESLVal n2 = $872;
              
              {ESLVal args2 = $871;
              
              if(n1.eql(n2).boolVal)
              return subTypes(args1,args2);
              else
                return $false;
            }
            }
            }
            }
            }
            }
            }
            default: switch(_v219.termName) {
              case "ApplyTypeFun": {ESLVal $820 = _v219.termRef(0);
                ESLVal $819 = _v219.termRef(1);
                ESLVal $818 = _v219.termRef(2);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l = $820;
                
                {ESLVal op = $819;
                
                {ESLVal args = $818;
                
                return subType(t1,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $817 = _v219.termRef(0);
                ESLVal $816 = _v219.termRef(1);
                ESLVal $815 = _v219.termRef(2);
                ESLVal $814 = _v219.termRef(3);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l2 = $817;
                
                {ESLVal t2 = $816;
                
                {ESLVal ds2 = $815;
                
                {ESLVal ms2 = $814;
                
                return subType(t1,flattenAct(l2,t2,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $813 = _v219.termRef(0);
                
                {ESLVal t1 = _v218;
                
                {ESLVal f = $813;
                
                return subType(t1,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $812 = _v219.termRef(0);
                ESLVal $811 = _v219.termRef(1);
                ESLVal $810 = _v219.termRef(2);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l2 = $812;
                
                {ESLVal n2 = $811;
                
                {ESLVal t2 = $810;
                
                return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $809 = _v219.termRef(0);
                ESLVal $808 = _v219.termRef(1);
                ESLVal $807 = _v219.termRef(2);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l1 = $809;
                
                {ESLVal ns2 = $808;
                
                {ESLVal t2 = $807;
                
                return subType(t1,t2);
              }
              }
              }
              }
              }
            case "ObservedType": {ESLVal $805 = _v219.termRef(0);
                ESLVal $804 = _v219.termRef(1);
                ESLVal $803 = _v219.termRef(2);
                
                switch($803.termName) {
                case "TypeClosure": {ESLVal $806 = $803.termRef(0);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l = $805;
                  
                  {ESLVal state = $804;
                  
                  {ESLVal f = $806;
                  
                  return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v218;
                  
                  {ESLVal l = $805;
                  
                  {ESLVal state = $804;
                  
                  {ESLVal messages = $803;
                  
                  return subType(t1,expandObservedType(l,state,messages));
                }
                }
                }
                }
              }
              }
            case "ObserverType": {ESLVal $801 = _v219.termRef(0);
                ESLVal $800 = _v219.termRef(1);
                ESLVal $799 = _v219.termRef(2);
                
                switch($799.termName) {
                case "TypeClosure": {ESLVal $802 = $799.termRef(0);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l = $801;
                  
                  {ESLVal state = $800;
                  
                  {ESLVal f = $802;
                  
                  return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v218;
                  
                  {ESLVal l = $801;
                  
                  {ESLVal state = $800;
                  
                  {ESLVal messages = $799;
                  
                  return subType(t1,expandObserverType(l,state,messages));
                }
                }
                }
                }
              }
              }
              default: {ESLVal t1 = _v218;
                
                {ESLVal t2 = _v219;
                
                return typeEqual(t1,t2);
              }
              }
            }
          }
          }
        case "FunType": {ESLVal $864 = _v218.termRef(0);
            ESLVal $863 = _v218.termRef(1);
            ESLVal $862 = _v218.termRef(2);
            
            switch(_v219.termName) {
            case "FunType": {ESLVal $867 = _v219.termRef(0);
              ESLVal $866 = _v219.termRef(1);
              ESLVal $865 = _v219.termRef(2);
              
              {ESLVal l1 = $864;
              
              {ESLVal d1 = $863;
              
              {ESLVal r1 = $862;
              
              {ESLVal l2 = $867;
              
              {ESLVal d2 = $866;
              
              {ESLVal r2 = $865;
              
              return subType(r1,r2).and(subTypes(d2,d1));
            }
            }
            }
            }
            }
            }
            }
            default: switch(_v219.termName) {
              case "ApplyTypeFun": {ESLVal $820 = _v219.termRef(0);
                ESLVal $819 = _v219.termRef(1);
                ESLVal $818 = _v219.termRef(2);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l = $820;
                
                {ESLVal op = $819;
                
                {ESLVal args = $818;
                
                return subType(t1,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $817 = _v219.termRef(0);
                ESLVal $816 = _v219.termRef(1);
                ESLVal $815 = _v219.termRef(2);
                ESLVal $814 = _v219.termRef(3);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l2 = $817;
                
                {ESLVal t2 = $816;
                
                {ESLVal ds2 = $815;
                
                {ESLVal ms2 = $814;
                
                return subType(t1,flattenAct(l2,t2,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $813 = _v219.termRef(0);
                
                {ESLVal t1 = _v218;
                
                {ESLVal f = $813;
                
                return subType(t1,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $812 = _v219.termRef(0);
                ESLVal $811 = _v219.termRef(1);
                ESLVal $810 = _v219.termRef(2);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l2 = $812;
                
                {ESLVal n2 = $811;
                
                {ESLVal t2 = $810;
                
                return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $809 = _v219.termRef(0);
                ESLVal $808 = _v219.termRef(1);
                ESLVal $807 = _v219.termRef(2);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l1 = $809;
                
                {ESLVal ns2 = $808;
                
                {ESLVal t2 = $807;
                
                return subType(t1,t2);
              }
              }
              }
              }
              }
            case "ObservedType": {ESLVal $805 = _v219.termRef(0);
                ESLVal $804 = _v219.termRef(1);
                ESLVal $803 = _v219.termRef(2);
                
                switch($803.termName) {
                case "TypeClosure": {ESLVal $806 = $803.termRef(0);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l = $805;
                  
                  {ESLVal state = $804;
                  
                  {ESLVal f = $806;
                  
                  return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v218;
                  
                  {ESLVal l = $805;
                  
                  {ESLVal state = $804;
                  
                  {ESLVal messages = $803;
                  
                  return subType(t1,expandObservedType(l,state,messages));
                }
                }
                }
                }
              }
              }
            case "ObserverType": {ESLVal $801 = _v219.termRef(0);
                ESLVal $800 = _v219.termRef(1);
                ESLVal $799 = _v219.termRef(2);
                
                switch($799.termName) {
                case "TypeClosure": {ESLVal $802 = $799.termRef(0);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l = $801;
                  
                  {ESLVal state = $800;
                  
                  {ESLVal f = $802;
                  
                  return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v218;
                  
                  {ESLVal l = $801;
                  
                  {ESLVal state = $800;
                  
                  {ESLVal messages = $799;
                  
                  return subType(t1,expandObserverType(l,state,messages));
                }
                }
                }
                }
              }
              }
              default: {ESLVal t1 = _v218;
                
                {ESLVal t2 = _v219;
                
                return typeEqual(t1,t2);
              }
              }
            }
          }
          }
        case "TypeClosure": {ESLVal $861 = _v218.termRef(0);
            
            {ESLVal f = $861;
            
            {ESLVal t2 = _v219;
            
            return subType(f.apply(),t2);
          }
          }
          }
        case "RecordType": {ESLVal $858 = _v218.termRef(0);
            ESLVal $857 = _v218.termRef(1);
            
            switch(_v219.termName) {
            case "RecordType": {ESLVal $860 = _v219.termRef(0);
              ESLVal $859 = _v219.termRef(1);
              
              {ESLVal l1 = $858;
              
              {ESLVal fs1 = $857;
              
              {ESLVal l2 = $860;
              
              {ESLVal fs2 = $859;
              
              return recordSubType(fs1,fs2);
            }
            }
            }
            }
            }
            default: switch(_v219.termName) {
              case "ApplyTypeFun": {ESLVal $820 = _v219.termRef(0);
                ESLVal $819 = _v219.termRef(1);
                ESLVal $818 = _v219.termRef(2);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l = $820;
                
                {ESLVal op = $819;
                
                {ESLVal args = $818;
                
                return subType(t1,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $817 = _v219.termRef(0);
                ESLVal $816 = _v219.termRef(1);
                ESLVal $815 = _v219.termRef(2);
                ESLVal $814 = _v219.termRef(3);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l2 = $817;
                
                {ESLVal t2 = $816;
                
                {ESLVal ds2 = $815;
                
                {ESLVal ms2 = $814;
                
                return subType(t1,flattenAct(l2,t2,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $813 = _v219.termRef(0);
                
                {ESLVal t1 = _v218;
                
                {ESLVal f = $813;
                
                return subType(t1,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $812 = _v219.termRef(0);
                ESLVal $811 = _v219.termRef(1);
                ESLVal $810 = _v219.termRef(2);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l2 = $812;
                
                {ESLVal n2 = $811;
                
                {ESLVal t2 = $810;
                
                return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $809 = _v219.termRef(0);
                ESLVal $808 = _v219.termRef(1);
                ESLVal $807 = _v219.termRef(2);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l1 = $809;
                
                {ESLVal ns2 = $808;
                
                {ESLVal t2 = $807;
                
                return subType(t1,t2);
              }
              }
              }
              }
              }
            case "ObservedType": {ESLVal $805 = _v219.termRef(0);
                ESLVal $804 = _v219.termRef(1);
                ESLVal $803 = _v219.termRef(2);
                
                switch($803.termName) {
                case "TypeClosure": {ESLVal $806 = $803.termRef(0);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l = $805;
                  
                  {ESLVal state = $804;
                  
                  {ESLVal f = $806;
                  
                  return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v218;
                  
                  {ESLVal l = $805;
                  
                  {ESLVal state = $804;
                  
                  {ESLVal messages = $803;
                  
                  return subType(t1,expandObservedType(l,state,messages));
                }
                }
                }
                }
              }
              }
            case "ObserverType": {ESLVal $801 = _v219.termRef(0);
                ESLVal $800 = _v219.termRef(1);
                ESLVal $799 = _v219.termRef(2);
                
                switch($799.termName) {
                case "TypeClosure": {ESLVal $802 = $799.termRef(0);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l = $801;
                  
                  {ESLVal state = $800;
                  
                  {ESLVal f = $802;
                  
                  return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v218;
                  
                  {ESLVal l = $801;
                  
                  {ESLVal state = $800;
                  
                  {ESLVal messages = $799;
                  
                  return subType(t1,expandObserverType(l,state,messages));
                }
                }
                }
                }
              }
              }
              default: {ESLVal t1 = _v218;
                
                {ESLVal t2 = _v219;
                
                return typeEqual(t1,t2);
              }
              }
            }
          }
          }
        case "RecType": {ESLVal $853 = _v218.termRef(0);
            ESLVal $852 = _v218.termRef(1);
            ESLVal $851 = _v218.termRef(2);
            
            switch(_v219.termName) {
            case "RecType": {ESLVal $856 = _v219.termRef(0);
              ESLVal $855 = _v219.termRef(1);
              ESLVal $854 = _v219.termRef(2);
              
              {ESLVal l1 = $853;
              
              {ESLVal n1 = $852;
              
              {ESLVal t1 = $851;
              
              {ESLVal l2 = $856;
              
              {ESLVal n2 = $855;
              
              {ESLVal t2 = $854;
              
              if(n1.eql(n2).boolVal)
              return subType(t1,t2);
              else
                {ESLVal _v342 = $853;
                  
                  {ESLVal _v343 = $852;
                  
                  {ESLVal _v344 = $851;
                  
                  {ESLVal _v345 = _v219;
                  
                  return subType(substType(new ESLVal("RecType",_v342,_v343,_v344),_v343,_v344),_v345);
                }
                }
                }
                }
            }
            }
            }
            }
            }
            }
            }
            default: {ESLVal l1 = $853;
              
              {ESLVal n1 = $852;
              
              {ESLVal t1 = $851;
              
              {ESLVal t2 = _v219;
              
              return subType(substType(new ESLVal("RecType",l1,n1,t1),n1,t1),t2);
            }
            }
            }
            }
          }
          }
        case "UnionType": {ESLVal $848 = _v218.termRef(0);
            ESLVal $847 = _v218.termRef(1);
            
            switch(_v219.termName) {
            case "UnionType": {ESLVal $850 = _v219.termRef(0);
              ESLVal $849 = _v219.termRef(1);
              
              {ESLVal l1 = $848;
              
              {ESLVal terms1 = $847;
              
              {ESLVal l2 = $850;
              
              {ESLVal terms2 = $849;
              
              return subTypes(terms1,terms2);
            }
            }
            }
            }
            }
            default: switch(_v219.termName) {
              case "ApplyTypeFun": {ESLVal $820 = _v219.termRef(0);
                ESLVal $819 = _v219.termRef(1);
                ESLVal $818 = _v219.termRef(2);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l = $820;
                
                {ESLVal op = $819;
                
                {ESLVal args = $818;
                
                return subType(t1,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $817 = _v219.termRef(0);
                ESLVal $816 = _v219.termRef(1);
                ESLVal $815 = _v219.termRef(2);
                ESLVal $814 = _v219.termRef(3);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l2 = $817;
                
                {ESLVal t2 = $816;
                
                {ESLVal ds2 = $815;
                
                {ESLVal ms2 = $814;
                
                return subType(t1,flattenAct(l2,t2,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $813 = _v219.termRef(0);
                
                {ESLVal t1 = _v218;
                
                {ESLVal f = $813;
                
                return subType(t1,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $812 = _v219.termRef(0);
                ESLVal $811 = _v219.termRef(1);
                ESLVal $810 = _v219.termRef(2);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l2 = $812;
                
                {ESLVal n2 = $811;
                
                {ESLVal t2 = $810;
                
                return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $809 = _v219.termRef(0);
                ESLVal $808 = _v219.termRef(1);
                ESLVal $807 = _v219.termRef(2);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l1 = $809;
                
                {ESLVal ns2 = $808;
                
                {ESLVal t2 = $807;
                
                return subType(t1,t2);
              }
              }
              }
              }
              }
            case "ObservedType": {ESLVal $805 = _v219.termRef(0);
                ESLVal $804 = _v219.termRef(1);
                ESLVal $803 = _v219.termRef(2);
                
                switch($803.termName) {
                case "TypeClosure": {ESLVal $806 = $803.termRef(0);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l = $805;
                  
                  {ESLVal state = $804;
                  
                  {ESLVal f = $806;
                  
                  return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v218;
                  
                  {ESLVal l = $805;
                  
                  {ESLVal state = $804;
                  
                  {ESLVal messages = $803;
                  
                  return subType(t1,expandObservedType(l,state,messages));
                }
                }
                }
                }
              }
              }
            case "ObserverType": {ESLVal $801 = _v219.termRef(0);
                ESLVal $800 = _v219.termRef(1);
                ESLVal $799 = _v219.termRef(2);
                
                switch($799.termName) {
                case "TypeClosure": {ESLVal $802 = $799.termRef(0);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l = $801;
                  
                  {ESLVal state = $800;
                  
                  {ESLVal f = $802;
                  
                  return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v218;
                  
                  {ESLVal l = $801;
                  
                  {ESLVal state = $800;
                  
                  {ESLVal messages = $799;
                  
                  return subType(t1,expandObserverType(l,state,messages));
                }
                }
                }
                }
              }
              }
              default: {ESLVal t1 = _v218;
                
                {ESLVal t2 = _v219;
                
                return typeEqual(t1,t2);
              }
              }
            }
          }
          }
        case "VarType": {ESLVal $844 = _v218.termRef(0);
            ESLVal $843 = _v218.termRef(1);
            
            switch(_v219.termName) {
            case "VarType": {ESLVal $846 = _v219.termRef(0);
              ESLVal $845 = _v219.termRef(1);
              
              {ESLVal l1 = $844;
              
              {ESLVal n1 = $843;
              
              {ESLVal l2 = $846;
              
              {ESLVal n2 = $845;
              
              return n1.eql(n2);
            }
            }
            }
            }
            }
            default: switch(_v219.termName) {
              case "ApplyTypeFun": {ESLVal $820 = _v219.termRef(0);
                ESLVal $819 = _v219.termRef(1);
                ESLVal $818 = _v219.termRef(2);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l = $820;
                
                {ESLVal op = $819;
                
                {ESLVal args = $818;
                
                return subType(t1,applyTypeFun(l,forceType(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $817 = _v219.termRef(0);
                ESLVal $816 = _v219.termRef(1);
                ESLVal $815 = _v219.termRef(2);
                ESLVal $814 = _v219.termRef(3);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l2 = $817;
                
                {ESLVal t2 = $816;
                
                {ESLVal ds2 = $815;
                
                {ESLVal ms2 = $814;
                
                return subType(t1,flattenAct(l2,t2,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $813 = _v219.termRef(0);
                
                {ESLVal t1 = _v218;
                
                {ESLVal f = $813;
                
                return subType(t1,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $812 = _v219.termRef(0);
                ESLVal $811 = _v219.termRef(1);
                ESLVal $810 = _v219.termRef(2);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l2 = $812;
                
                {ESLVal n2 = $811;
                
                {ESLVal t2 = $810;
                
                return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $809 = _v219.termRef(0);
                ESLVal $808 = _v219.termRef(1);
                ESLVal $807 = _v219.termRef(2);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l1 = $809;
                
                {ESLVal ns2 = $808;
                
                {ESLVal t2 = $807;
                
                return subType(t1,t2);
              }
              }
              }
              }
              }
            case "ObservedType": {ESLVal $805 = _v219.termRef(0);
                ESLVal $804 = _v219.termRef(1);
                ESLVal $803 = _v219.termRef(2);
                
                switch($803.termName) {
                case "TypeClosure": {ESLVal $806 = $803.termRef(0);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l = $805;
                  
                  {ESLVal state = $804;
                  
                  {ESLVal f = $806;
                  
                  return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v218;
                  
                  {ESLVal l = $805;
                  
                  {ESLVal state = $804;
                  
                  {ESLVal messages = $803;
                  
                  return subType(t1,expandObservedType(l,state,messages));
                }
                }
                }
                }
              }
              }
            case "ObserverType": {ESLVal $801 = _v219.termRef(0);
                ESLVal $800 = _v219.termRef(1);
                ESLVal $799 = _v219.termRef(2);
                
                switch($799.termName) {
                case "TypeClosure": {ESLVal $802 = $799.termRef(0);
                  
                  {ESLVal t1 = _v218;
                  
                  {ESLVal l = $801;
                  
                  {ESLVal state = $800;
                  
                  {ESLVal f = $802;
                  
                  return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v218;
                  
                  {ESLVal l = $801;
                  
                  {ESLVal state = $800;
                  
                  {ESLVal messages = $799;
                  
                  return subType(t1,expandObserverType(l,state,messages));
                }
                }
                }
                }
              }
              }
              default: {ESLVal t1 = _v218;
                
                {ESLVal t2 = _v219;
                
                return typeEqual(t1,t2);
              }
              }
            }
          }
          }
        case "ForallType": {ESLVal $823 = _v218.termRef(0);
            ESLVal $822 = _v218.termRef(1);
            ESLVal $821 = _v218.termRef(2);
            
            if($822.isCons())
            {ESLVal $827 = $822.head();
              ESLVal $828 = $822.tail();
              
              if($828.isCons())
              {ESLVal $829 = $828.head();
                ESLVal $830 = $828.tail();
                
                switch(_v219.termName) {
                case "ForallType": {ESLVal $826 = _v219.termRef(0);
                  ESLVal $825 = _v219.termRef(1);
                  ESLVal $824 = _v219.termRef(2);
                  
                  {ESLVal l1 = $823;
                  
                  {ESLVal ns1 = $822;
                  
                  {ESLVal t1 = $821;
                  
                  {ESLVal l2 = $826;
                  
                  {ESLVal ns2 = $825;
                  
                  {ESLVal t2 = $824;
                  
                  return ns1.eql(ns2).and(subType(t1,t2));
                }
                }
                }
                }
                }
                }
                }
                default: {ESLVal l1 = $823;
                  
                  {ESLVal ns1 = $822;
                  
                  {ESLVal t1 = $821;
                  
                  {ESLVal t2 = _v219;
                  
                  return subType(t1,t2);
                }
                }
                }
                }
              }
              }
            else if($828.isNil())
              switch($821.termName) {
                case "ListType": {ESLVal $838 = $821.termRef(0);
                  ESLVal $837 = $821.termRef(1);
                  
                  switch($837.termName) {
                  case "VarType": {ESLVal $840 = $837.termRef(0);
                    ESLVal $839 = $837.termRef(1);
                    
                    switch(_v219.termName) {
                    case "ListType": {ESLVal $842 = _v219.termRef(0);
                      ESLVal $841 = _v219.termRef(1);
                      
                      {ESLVal l2 = $823;
                      
                      {ESLVal v1 = $827;
                      
                      {ESLVal l3 = $838;
                      
                      {ESLVal l4 = $840;
                      
                      {ESLVal v2 = $839;
                      
                      {ESLVal l1 = $842;
                      
                      {ESLVal t1 = $841;
                      
                      if(v1.eql(v2).boolVal)
                      return $true;
                      else
                        switch(_v219.termName) {
                          case "ForallType": {ESLVal $826 = _v219.termRef(0);
                            ESLVal $825 = _v219.termRef(1);
                            ESLVal $824 = _v219.termRef(2);
                            
                            {ESLVal _v337 = $823;
                            
                            {ESLVal ns1 = $822;
                            
                            {ESLVal _v338 = $821;
                            
                            {ESLVal _v339 = $826;
                            
                            {ESLVal ns2 = $825;
                            
                            {ESLVal t2 = $824;
                            
                            return ns1.eql(ns2).and(subType(_v338,t2));
                          }
                          }
                          }
                          }
                          }
                          }
                          }
                          default: {ESLVal _v340 = $823;
                            
                            {ESLVal ns1 = $822;
                            
                            {ESLVal _v341 = $821;
                            
                            {ESLVal t2 = _v219;
                            
                            return subType(_v341,t2);
                          }
                          }
                          }
                          }
                        }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: switch(_v219.termName) {
                      case "ForallType": {ESLVal $826 = _v219.termRef(0);
                        ESLVal $825 = _v219.termRef(1);
                        ESLVal $824 = _v219.termRef(2);
                        
                        {ESLVal l1 = $823;
                        
                        {ESLVal ns1 = $822;
                        
                        {ESLVal t1 = $821;
                        
                        {ESLVal l2 = $826;
                        
                        {ESLVal ns2 = $825;
                        
                        {ESLVal t2 = $824;
                        
                        return ns1.eql(ns2).and(subType(t1,t2));
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal l1 = $823;
                        
                        {ESLVal ns1 = $822;
                        
                        {ESLVal t1 = $821;
                        
                        {ESLVal t2 = _v219;
                        
                        return subType(t1,t2);
                      }
                      }
                      }
                      }
                    }
                  }
                  }
                  default: switch(_v219.termName) {
                    case "ForallType": {ESLVal $826 = _v219.termRef(0);
                      ESLVal $825 = _v219.termRef(1);
                      ESLVal $824 = _v219.termRef(2);
                      
                      {ESLVal l1 = $823;
                      
                      {ESLVal ns1 = $822;
                      
                      {ESLVal t1 = $821;
                      
                      {ESLVal l2 = $826;
                      
                      {ESLVal ns2 = $825;
                      
                      {ESLVal t2 = $824;
                      
                      return ns1.eql(ns2).and(subType(t1,t2));
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal l1 = $823;
                      
                      {ESLVal ns1 = $822;
                      
                      {ESLVal t1 = $821;
                      
                      {ESLVal t2 = _v219;
                      
                      return subType(t1,t2);
                    }
                    }
                    }
                    }
                  }
                }
                }
              case "SetType": {ESLVal $832 = $821.termRef(0);
                  ESLVal $831 = $821.termRef(1);
                  
                  switch($831.termName) {
                  case "VarType": {ESLVal $834 = $831.termRef(0);
                    ESLVal $833 = $831.termRef(1);
                    
                    switch(_v219.termName) {
                    case "SetType": {ESLVal $836 = _v219.termRef(0);
                      ESLVal $835 = _v219.termRef(1);
                      
                      {ESLVal l2 = $823;
                      
                      {ESLVal v1 = $827;
                      
                      {ESLVal l3 = $832;
                      
                      {ESLVal l4 = $834;
                      
                      {ESLVal v2 = $833;
                      
                      {ESLVal l1 = $836;
                      
                      {ESLVal t1 = $835;
                      
                      if(v1.eql(v2).boolVal)
                      return $true;
                      else
                        switch(_v219.termName) {
                          case "ForallType": {ESLVal $826 = _v219.termRef(0);
                            ESLVal $825 = _v219.termRef(1);
                            ESLVal $824 = _v219.termRef(2);
                            
                            {ESLVal _v332 = $823;
                            
                            {ESLVal ns1 = $822;
                            
                            {ESLVal _v333 = $821;
                            
                            {ESLVal _v334 = $826;
                            
                            {ESLVal ns2 = $825;
                            
                            {ESLVal t2 = $824;
                            
                            return ns1.eql(ns2).and(subType(_v333,t2));
                          }
                          }
                          }
                          }
                          }
                          }
                          }
                          default: {ESLVal _v335 = $823;
                            
                            {ESLVal ns1 = $822;
                            
                            {ESLVal _v336 = $821;
                            
                            {ESLVal t2 = _v219;
                            
                            return subType(_v336,t2);
                          }
                          }
                          }
                          }
                        }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: switch(_v219.termName) {
                      case "ForallType": {ESLVal $826 = _v219.termRef(0);
                        ESLVal $825 = _v219.termRef(1);
                        ESLVal $824 = _v219.termRef(2);
                        
                        {ESLVal l1 = $823;
                        
                        {ESLVal ns1 = $822;
                        
                        {ESLVal t1 = $821;
                        
                        {ESLVal l2 = $826;
                        
                        {ESLVal ns2 = $825;
                        
                        {ESLVal t2 = $824;
                        
                        return ns1.eql(ns2).and(subType(t1,t2));
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal l1 = $823;
                        
                        {ESLVal ns1 = $822;
                        
                        {ESLVal t1 = $821;
                        
                        {ESLVal t2 = _v219;
                        
                        return subType(t1,t2);
                      }
                      }
                      }
                      }
                    }
                  }
                  }
                  default: switch(_v219.termName) {
                    case "ForallType": {ESLVal $826 = _v219.termRef(0);
                      ESLVal $825 = _v219.termRef(1);
                      ESLVal $824 = _v219.termRef(2);
                      
                      {ESLVal l1 = $823;
                      
                      {ESLVal ns1 = $822;
                      
                      {ESLVal t1 = $821;
                      
                      {ESLVal l2 = $826;
                      
                      {ESLVal ns2 = $825;
                      
                      {ESLVal t2 = $824;
                      
                      return ns1.eql(ns2).and(subType(t1,t2));
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal l1 = $823;
                      
                      {ESLVal ns1 = $822;
                      
                      {ESLVal t1 = $821;
                      
                      {ESLVal t2 = _v219;
                      
                      return subType(t1,t2);
                    }
                    }
                    }
                    }
                  }
                }
                }
                default: switch(_v219.termName) {
                  case "ForallType": {ESLVal $826 = _v219.termRef(0);
                    ESLVal $825 = _v219.termRef(1);
                    ESLVal $824 = _v219.termRef(2);
                    
                    {ESLVal l1 = $823;
                    
                    {ESLVal ns1 = $822;
                    
                    {ESLVal t1 = $821;
                    
                    {ESLVal l2 = $826;
                    
                    {ESLVal ns2 = $825;
                    
                    {ESLVal t2 = $824;
                    
                    return ns1.eql(ns2).and(subType(t1,t2));
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal l1 = $823;
                    
                    {ESLVal ns1 = $822;
                    
                    {ESLVal t1 = $821;
                    
                    {ESLVal t2 = _v219;
                    
                    return subType(t1,t2);
                  }
                  }
                  }
                  }
                }
              }
            else switch(_v219.termName) {
                case "ForallType": {ESLVal $826 = _v219.termRef(0);
                  ESLVal $825 = _v219.termRef(1);
                  ESLVal $824 = _v219.termRef(2);
                  
                  {ESLVal l1 = $823;
                  
                  {ESLVal ns1 = $822;
                  
                  {ESLVal t1 = $821;
                  
                  {ESLVal l2 = $826;
                  
                  {ESLVal ns2 = $825;
                  
                  {ESLVal t2 = $824;
                  
                  return ns1.eql(ns2).and(subType(t1,t2));
                }
                }
                }
                }
                }
                }
                }
                default: {ESLVal l1 = $823;
                  
                  {ESLVal ns1 = $822;
                  
                  {ESLVal t1 = $821;
                  
                  {ESLVal t2 = _v219;
                  
                  return subType(t1,t2);
                }
                }
                }
                }
              }
            }
          else if($822.isNil())
            switch(_v219.termName) {
              case "ForallType": {ESLVal $826 = _v219.termRef(0);
                ESLVal $825 = _v219.termRef(1);
                ESLVal $824 = _v219.termRef(2);
                
                {ESLVal l1 = $823;
                
                {ESLVal ns1 = $822;
                
                {ESLVal t1 = $821;
                
                {ESLVal l2 = $826;
                
                {ESLVal ns2 = $825;
                
                {ESLVal t2 = $824;
                
                return ns1.eql(ns2).and(subType(t1,t2));
              }
              }
              }
              }
              }
              }
              }
              default: {ESLVal l1 = $823;
                
                {ESLVal ns1 = $822;
                
                {ESLVal t1 = $821;
                
                {ESLVal t2 = _v219;
                
                return subType(t1,t2);
              }
              }
              }
              }
            }
          else switch(_v219.termName) {
              case "ForallType": {ESLVal $826 = _v219.termRef(0);
                ESLVal $825 = _v219.termRef(1);
                ESLVal $824 = _v219.termRef(2);
                
                {ESLVal l1 = $823;
                
                {ESLVal ns1 = $822;
                
                {ESLVal t1 = $821;
                
                {ESLVal l2 = $826;
                
                {ESLVal ns2 = $825;
                
                {ESLVal t2 = $824;
                
                return ns1.eql(ns2).and(subType(t1,t2));
              }
              }
              }
              }
              }
              }
              }
              default: {ESLVal l1 = $823;
                
                {ESLVal ns1 = $822;
                
                {ESLVal t1 = $821;
                
                {ESLVal t2 = _v219;
                
                return subType(t1,t2);
              }
              }
              }
              }
            }
          }
          default: switch(_v219.termName) {
            case "ApplyTypeFun": {ESLVal $820 = _v219.termRef(0);
              ESLVal $819 = _v219.termRef(1);
              ESLVal $818 = _v219.termRef(2);
              
              {ESLVal t1 = _v218;
              
              {ESLVal l = $820;
              
              {ESLVal op = $819;
              
              {ESLVal args = $818;
              
              return subType(t1,applyTypeFun(l,forceType(op),args));
            }
            }
            }
            }
            }
          case "ExtendedAct": {ESLVal $817 = _v219.termRef(0);
              ESLVal $816 = _v219.termRef(1);
              ESLVal $815 = _v219.termRef(2);
              ESLVal $814 = _v219.termRef(3);
              
              {ESLVal t1 = _v218;
              
              {ESLVal l2 = $817;
              
              {ESLVal t2 = $816;
              
              {ESLVal ds2 = $815;
              
              {ESLVal ms2 = $814;
              
              return subType(t1,flattenAct(l2,t2,ds2,ms2));
            }
            }
            }
            }
            }
            }
          case "TypeClosure": {ESLVal $813 = _v219.termRef(0);
              
              {ESLVal t1 = _v218;
              
              {ESLVal f = $813;
              
              return subType(t1,f.apply());
            }
            }
            }
          case "RecType": {ESLVal $812 = _v219.termRef(0);
              ESLVal $811 = _v219.termRef(1);
              ESLVal $810 = _v219.termRef(2);
              
              {ESLVal t1 = _v218;
              
              {ESLVal l2 = $812;
              
              {ESLVal n2 = $811;
              
              {ESLVal t2 = $810;
              
              return subType(t1,substType(new ESLVal("RecType",l2,n2,t2),n2,t2));
            }
            }
            }
            }
            }
          case "ForallType": {ESLVal $809 = _v219.termRef(0);
              ESLVal $808 = _v219.termRef(1);
              ESLVal $807 = _v219.termRef(2);
              
              {ESLVal t1 = _v218;
              
              {ESLVal l1 = $809;
              
              {ESLVal ns2 = $808;
              
              {ESLVal t2 = $807;
              
              return subType(t1,t2);
            }
            }
            }
            }
            }
          case "ObservedType": {ESLVal $805 = _v219.termRef(0);
              ESLVal $804 = _v219.termRef(1);
              ESLVal $803 = _v219.termRef(2);
              
              switch($803.termName) {
              case "TypeClosure": {ESLVal $806 = $803.termRef(0);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l = $805;
                
                {ESLVal state = $804;
                
                {ESLVal f = $806;
                
                return subType(t1,new ESLVal("ObservedType",l,state,f.apply()));
              }
              }
              }
              }
              }
              default: {ESLVal t1 = _v218;
                
                {ESLVal l = $805;
                
                {ESLVal state = $804;
                
                {ESLVal messages = $803;
                
                return subType(t1,expandObservedType(l,state,messages));
              }
              }
              }
              }
            }
            }
          case "ObserverType": {ESLVal $801 = _v219.termRef(0);
              ESLVal $800 = _v219.termRef(1);
              ESLVal $799 = _v219.termRef(2);
              
              switch($799.termName) {
              case "TypeClosure": {ESLVal $802 = $799.termRef(0);
                
                {ESLVal t1 = _v218;
                
                {ESLVal l = $801;
                
                {ESLVal state = $800;
                
                {ESLVal f = $802;
                
                return subType(t1,new ESLVal("ObserverType",l,state,f.apply()));
              }
              }
              }
              }
              }
              default: {ESLVal t1 = _v218;
                
                {ESLVal l = $801;
                
                {ESLVal state = $800;
                
                {ESLVal messages = $799;
                
                return subType(t1,expandObserverType(l,state,messages));
              }
              }
              }
              }
            }
            }
            default: {ESLVal t1 = _v218;
              
              {ESLVal t2 = _v219;
              
              return typeEqual(t1,t2);
            }
            }
          }
        }
        }
  }
  public static ESLVal subType = new ESLVal(new Function(new ESLVal("subType"),null) { public ESLVal apply(ESLVal... args) { return subType(args[0],args[1]); }});
  public static ESLVal expandObserverType(ESLVal l1,ESLVal state,ESLVal messages) {
    
    return new ESLVal("ActType",l1,$nil,ESLVal.list(new ESLVal("MessageType",l1,ESLVal.list(new ESLVal("TermType",l1,new ESLVal("Start"),ESLVal.list(expandObservedType(l1,state,messages),new ESLVal("IntType",l1),state)))),new ESLVal("MessageType",l1,ESLVal.list(new ESLVal("TermType",l1,new ESLVal("Transition"),ESLVal.list(expandObservedType(l1,state,messages),new ESLVal("IntType",l1),messages,state))))));
  }
  public static ESLVal expandObserverType = new ESLVal(new Function(new ESLVal("expandObserverType"),null) { public ESLVal apply(ESLVal... args) { return expandObserverType(args[0],args[1],args[2]); }});
  public static ESLVal maybe(ESLVal t) {
    
    return new ESLVal("UnionType",new ESLVal("Pos",$zero,$zero),ESLVal.list(new ESLVal("TermType",new ESLVal("Pos",$zero,$zero),new ESLVal("Exactly"),ESLVal.list(t)),new ESLVal("TermType",new ESLVal("Pos",$zero,$zero),new ESLVal("Nothing"),$nil)));
  }
  public static ESLVal maybe = new ESLVal(new Function(new ESLVal("maybe"),null) { public ESLVal apply(ESLVal... args) { return maybe(args[0]); }});
  public static ESLVal expandObservedType(ESLVal l,ESLVal state,ESLVal messages) {
    
    return new ESLVal("ActType",l,ESLVal.list(new ESLVal("Dec",l,new ESLVal("observeState"),new ESLVal("FunType",l,$nil,state),new ESLVal("FunType",l,$nil,state)),new ESLVal("Dec",l,new ESLVal("observeMessage"),new ESLVal("FunType",l,ESLVal.list(new ESLVal("UnionType",l,$nil)),maybe(messages)),new ESLVal("FunType",l,ESLVal.list(new ESLVal("UnionType",l,$nil)),maybe(messages)))),$nil);
  }
  public static ESLVal expandObservedType = new ESLVal(new Function(new ESLVal("expandObservedType"),null) { public ESLVal apply(ESLVal... args) { return expandObservedType(args[0],args[1],args[2]); }});
  public static ESLVal flattenAct(ESLVal l1,ESLVal t,ESLVal ds1,ESLVal ms1) {
    
    {ESLVal _v220 = t;
      
      switch(_v220.termName) {
      case "ActType": {ESLVal $931 = _v220.termRef(0);
        ESLVal $930 = _v220.termRef(1);
        ESLVal $929 = _v220.termRef(2);
        
        {ESLVal l2 = $931;
        
        {ESLVal ds2 = $930;
        
        {ESLVal ms2 = $929;
        
        return new ESLVal("ActType",l1,ds1.add(ds2),ms1.add(ms2));
      }
      }
      }
      }
    case "ExtendedAct": {ESLVal $928 = _v220.termRef(0);
        ESLVal $927 = _v220.termRef(1);
        ESLVal $926 = _v220.termRef(2);
        ESLVal $925 = _v220.termRef(3);
        
        {ESLVal l2 = $928;
        
        {ESLVal _v330 = $927;
        
        {ESLVal ds2 = $926;
        
        {ESLVal ms2 = $925;
        
        return flattenAct(l1,flattenAct(l2,_v330,ds2,ms2),ds1,ms1);
      }
      }
      }
      }
      }
    case "TypeClosure": {ESLVal $924 = _v220.termRef(0);
        
        {ESLVal f = $924;
        
        return flattenAct(l1,f.apply(),ds1,ms1);
      }
      }
    case "RecType": {ESLVal $923 = _v220.termRef(0);
        ESLVal $922 = _v220.termRef(1);
        ESLVal $921 = _v220.termRef(2);
        
        {ESLVal l2 = $923;
        
        {ESLVal n = $922;
        
        {ESLVal b = $921;
        
        return flattenAct(l1,substType(t,n,b),ds1,ms1);
      }
      }
      }
      }
      default: {ESLVal _v331 = _v220;
        
        return error(new ESLVal("TypeError",l1,new ESLVal("unknown type for flatten ").add(_v331)));
      }
    }
    }
  }
  public static ESLVal flattenAct = new ESLVal(new Function(new ESLVal("flattenAct"),null) { public ESLVal apply(ESLVal... args) { return flattenAct(args[0],args[1],args[2],args[3]); }});
  public static ESLVal actEqual(ESLVal exports1,ESLVal exports2,ESLVal handlers1,ESLVal handlers2) {
    
    return forall.apply(new ESLVal(new Function(new ESLVal("fun335"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal d1 = $args[0];
      return exists.apply(new ESLVal(new Function(new ESLVal("fun336"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal d2 = $args[0];
            return equalDec(d1,d2);
              }
            }),exports2);
        }
      }),exports1).and(forall.apply(new ESLVal(new Function(new ESLVal("fun337"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal d1 = $args[0];
      return exists.apply(new ESLVal(new Function(new ESLVal("fun338"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal d2 = $args[0];
            return equalDec(d1,d2);
              }
            }),exports1);
        }
      }),exports2).and(forall.apply(new ESLVal(new Function(new ESLVal("fun339"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal m1 = $args[0];
      return exists.apply(new ESLVal(new Function(new ESLVal("fun340"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal m2 = $args[0];
            return equalMessage(m1,m2);
              }
            }),handlers2);
        }
      }),handlers1).and(forall.apply(new ESLVal(new Function(new ESLVal("fun341"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal m1 = $args[0];
      return exists.apply(new ESLVal(new Function(new ESLVal("fun342"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal m2 = $args[0];
            return equalMessage(m1,m2);
              }
            }),handlers1);
        }
      }),handlers2))));
  }
  public static ESLVal actEqual = new ESLVal(new Function(new ESLVal("actEqual"),null) { public ESLVal apply(ESLVal... args) { return actEqual(args[0],args[1],args[2],args[3]); }});
  public static ESLVal actSubType(ESLVal exports1,ESLVal exports2,ESLVal handlers1,ESLVal handlers2) {
    
    {ESLVal isObservedMessage = new ESLVal(new Function(new ESLVal("isObservedMessage"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal d = $args[0];
        {ESLVal _v221 = d;
              
              switch(_v221.termName) {
              case "Dec": {ESLVal $935 = _v221.termRef(0);
                ESLVal $934 = _v221.termRef(1);
                ESLVal $933 = _v221.termRef(2);
                ESLVal $932 = _v221.termRef(3);
                
                switch($934.strVal) {
                case "observeMessage": {ESLVal l = $935;
                  
                  {ESLVal t1 = $933;
                  
                  {ESLVal t2 = $932;
                  
                  return $true;
                }
                }
                }
                default: {ESLVal _v328 = _v221;
                  
                  return $false;
                }
              }
              }
              default: {ESLVal _v329 = _v221;
                
                return $false;
              }
            }
            }
          }
        });
      
      return forall.apply(new ESLVal(new Function(new ESLVal("fun343"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal d2 = $args[0];
      return exists.apply(new ESLVal(new Function(new ESLVal("fun344"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal d1 = $args[0];
            return decSubType(d1,d2);
              }
            }),reject.apply(isObservedMessage,exports1));
        }
      }),reject.apply(isObservedMessage,exports2)).and(forall.apply(new ESLVal(new Function(new ESLVal("fun345"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal m2 = $args[0];
      return exists.apply(new ESLVal(new Function(new ESLVal("fun346"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal m1 = $args[0];
            return messSubType(m1,m2);
              }
            }),handlers1);
        }
      }),handlers2));
    }
  }
  public static ESLVal actSubType = new ESLVal(new Function(new ESLVal("actSubType"),null) { public ESLVal apply(ESLVal... args) { return actSubType(args[0],args[1],args[2],args[3]); }});
  public static ESLVal equalDec(ESLVal d1,ESLVal d2) {
    
    {ESLVal _v222 = d1;
      ESLVal _v223 = d2;
      
      switch(_v222.termName) {
      case "Dec": {ESLVal $939 = _v222.termRef(0);
        ESLVal $938 = _v222.termRef(1);
        ESLVal $937 = _v222.termRef(2);
        ESLVal $936 = _v222.termRef(3);
        
        switch(_v223.termName) {
        case "Dec": {ESLVal $943 = _v223.termRef(0);
          ESLVal $942 = _v223.termRef(1);
          ESLVal $941 = _v223.termRef(2);
          ESLVal $940 = _v223.termRef(3);
          
          {ESLVal l1 = $939;
          
          {ESLVal n1 = $938;
          
          {ESLVal t1 = $937;
          
          {ESLVal st1 = $936;
          
          {ESLVal l2 = $943;
          
          {ESLVal n2 = $942;
          
          {ESLVal t2 = $941;
          
          {ESLVal st2 = $940;
          
          return n1.eql(n2).and(typeEqual(t1,t2));
        }
        }
        }
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(23260,23391)").add(ESLVal.list(_v222,_v223)));
      }
      }
      default: return error(new ESLVal("case error at Pos(23260,23391)").add(ESLVal.list(_v222,_v223)));
    }
    }
  }
  public static ESLVal equalDec = new ESLVal(new Function(new ESLVal("equalDec"),null) { public ESLVal apply(ESLVal... args) { return equalDec(args[0],args[1]); }});
  public static ESLVal decSubType(ESLVal d1,ESLVal d2) {
    
    {ESLVal _v224 = d1;
      ESLVal _v225 = d2;
      
      switch(_v224.termName) {
      case "Dec": {ESLVal $947 = _v224.termRef(0);
        ESLVal $946 = _v224.termRef(1);
        ESLVal $945 = _v224.termRef(2);
        ESLVal $944 = _v224.termRef(3);
        
        switch(_v225.termName) {
        case "Dec": {ESLVal $951 = _v225.termRef(0);
          ESLVal $950 = _v225.termRef(1);
          ESLVal $949 = _v225.termRef(2);
          ESLVal $948 = _v225.termRef(3);
          
          {ESLVal l1 = $947;
          
          {ESLVal n1 = $946;
          
          {ESLVal t1 = $945;
          
          {ESLVal st1 = $944;
          
          {ESLVal l2 = $951;
          
          {ESLVal n2 = $950;
          
          {ESLVal t2 = $949;
          
          {ESLVal st2 = $948;
          
          return n1.eql(n2).and(subType(t1,t2));
        }
        }
        }
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(23435,23565)").add(ESLVal.list(_v224,_v225)));
      }
      }
      default: return error(new ESLVal("case error at Pos(23435,23565)").add(ESLVal.list(_v224,_v225)));
    }
    }
  }
  public static ESLVal decSubType = new ESLVal(new Function(new ESLVal("decSubType"),null) { public ESLVal apply(ESLVal... args) { return decSubType(args[0],args[1]); }});
  public static ESLVal equalMessage(ESLVal m1,ESLVal m2) {
    
    {ESLVal _v226 = m1;
      ESLVal _v227 = m2;
      
      switch(_v226.termName) {
      case "MessageType": {ESLVal $953 = _v226.termRef(0);
        ESLVal $952 = _v226.termRef(1);
        
        switch(_v227.termName) {
        case "MessageType": {ESLVal $955 = _v227.termRef(0);
          ESLVal $954 = _v227.termRef(1);
          
          {ESLVal l1 = $953;
          
          {ESLVal ts1 = $952;
          
          {ESLVal l2 = $955;
          
          {ESLVal ts2 = $954;
          
          return typesEqual(ts1,ts2);
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(23611,23721)").add(ESLVal.list(_v226,_v227)));
      }
      }
      default: return error(new ESLVal("case error at Pos(23611,23721)").add(ESLVal.list(_v226,_v227)));
    }
    }
  }
  public static ESLVal equalMessage = new ESLVal(new Function(new ESLVal("equalMessage"),null) { public ESLVal apply(ESLVal... args) { return equalMessage(args[0],args[1]); }});
  public static ESLVal messSubType(ESLVal m1,ESLVal m2) {
    
    {ESLVal _v228 = m1;
      ESLVal _v229 = m2;
      
      switch(_v228.termName) {
      case "MessageType": {ESLVal $957 = _v228.termRef(0);
        ESLVal $956 = _v228.termRef(1);
        
        switch(_v229.termName) {
        case "MessageType": {ESLVal $959 = _v229.termRef(0);
          ESLVal $958 = _v229.termRef(1);
          
          {ESLVal l1 = $957;
          
          {ESLVal ts1 = $956;
          
          {ESLVal l2 = $959;
          
          {ESLVal ts2 = $958;
          
          return subTypes(ts1,ts2);
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(23766,23874)").add(ESLVal.list(_v228,_v229)));
      }
      }
      default: return error(new ESLVal("case error at Pos(23766,23874)").add(ESLVal.list(_v228,_v229)));
    }
    }
  }
  public static ESLVal messSubType = new ESLVal(new Function(new ESLVal("messSubType"),null) { public ESLVal apply(ESLVal... args) { return messSubType(args[0],args[1]); }});
  public static ESLVal recordTypeEqual(ESLVal fields1,ESLVal fields2) {
    
    return forall.apply(new ESLVal(new Function(new ESLVal("fun347"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal t1 = $args[0];
      return exists.apply(new ESLVal(new Function(new ESLVal("fun348"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal t2 = $args[0];
            return decName(t1).eql(decName(t2)).and(typeEqual(decType(t1),decType(t2)));
              }
            }),fields2);
        }
      }),fields1).and(forall.apply(new ESLVal(new Function(new ESLVal("fun349"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal t1 = $args[0];
      return exists.apply(new ESLVal(new Function(new ESLVal("fun350"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal t2 = $args[0];
            return decName(t1).eql(decName(t2)).and(typeEqual(decType(t1),decType(t2)));
              }
            }),fields1);
        }
      }),fields2));
  }
  public static ESLVal recordTypeEqual = new ESLVal(new Function(new ESLVal("recordTypeEqual"),null) { public ESLVal apply(ESLVal... args) { return recordTypeEqual(args[0],args[1]); }});
  public static ESLVal recordSubType(ESLVal fields1,ESLVal fields2) {
    
    return forall.apply(new ESLVal(new Function(new ESLVal("fun351"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal t2 = $args[0];
      return exists.apply(new ESLVal(new Function(new ESLVal("fun352"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal t1 = $args[0];
            return decName(t1).eql(decName(t2)).and(subType(decType(t1),decType(t2)));
              }
            }),fields1);
        }
      }),fields2);
  }
  public static ESLVal recordSubType = new ESLVal(new Function(new ESLVal("recordSubType"),null) { public ESLVal apply(ESLVal... args) { return recordSubType(args[0],args[1]); }});
  public static ESLVal applyTypeFun(ESLVal l,ESLVal op,ESLVal args) {
    
    {ESLVal _v230 = op;
      
      switch(_v230.termName) {
      case "RecType": {ESLVal $965 = _v230.termRef(0);
        ESLVal $964 = _v230.termRef(1);
        ESLVal $963 = _v230.termRef(2);
        
        {ESLVal lr = $965;
        
        {ESLVal n = $964;
        
        {ESLVal t = $963;
        
        return applyTypeFun(l,unfoldType(lr,n,t),args);
      }
      }
      }
      }
    case "TypeFun": {ESLVal $962 = _v230.termRef(0);
        ESLVal $961 = _v230.termRef(1);
        ESLVal $960 = _v230.termRef(2);
        
        {ESLVal _v326 = $962;
        
        {ESLVal names = $961;
        
        {ESLVal t = $960;
        
        if(length.apply(args).eql(length.apply(names)).boolVal)
        return substTypeEnv(zipTypeEnv(names,args),t);
        else
          return error(new ESLVal("TypeError",_v326,new ESLVal("type fun expects ").add(length.apply(names).add(new ESLVal(" args, but supplied with ").add(length.apply(args))))));
      }
      }
      }
      }
      default: {ESLVal _v327 = _v230;
        
        return error(new ESLVal("TypeError",l,new ESLVal("expecting a type function: ").add(_v327)));
      }
    }
    }
  }
  public static ESLVal applyTypeFun = new ESLVal(new Function(new ESLVal("applyTypeFun"),null) { public ESLVal apply(ESLVal... args) { return applyTypeFun(args[0],args[1],args[2]); }});
  public static ESLVal unfoldType(ESLVal l,ESLVal n,ESLVal t) {
    
    return substType(new ESLVal("RecType",l,n,t),n,t);
  }
  public static ESLVal unfoldType = new ESLVal(new Function(new ESLVal("unfoldType"),null) { public ESLVal apply(ESLVal... args) { return unfoldType(args[0],args[1],args[2]); }});
  public static ESLVal forceType(ESLVal t) {
    
    {ESLVal _v231 = t;
      
      switch(_v231.termName) {
      case "TypeClosure": {ESLVal $966 = _v231.termRef(0);
        
        {ESLVal f = $966;
        
        return forceType(f.apply());
      }
      }
      default: {ESLVal _v325 = _v231;
        
        return _v325;
      }
    }
    }
  }
  public static ESLVal forceType = new ESLVal(new Function(new ESLVal("forceType"),null) { public ESLVal apply(ESLVal... args) { return forceType(args[0]); }});
  public static ESLVal typesEqual(ESLVal ts1,ESLVal ts2) {
    
    {ESLVal _v232 = ts1;
      ESLVal _v233 = ts2;
      
      if(_v232.isCons())
      {ESLVal $969 = _v232.head();
        ESLVal $970 = _v232.tail();
        
        if(_v233.isCons())
        {ESLVal $971 = _v233.head();
          ESLVal $972 = _v233.tail();
          
          {ESLVal t1 = $969;
          
          {ESLVal _v318 = $970;
          
          {ESLVal t2 = $971;
          
          {ESLVal _v319 = $972;
          
          return typeEqual(t1,t2).and(typesEqual(_v318,_v319));
        }
        }
        }
        }
        }
      else if(_v233.isNil())
        if(_v233.isCons())
          {ESLVal $967 = _v233.head();
            ESLVal $968 = _v233.tail();
            
            return error(new ESLVal("case error at Pos(25180,25390)").add(ESLVal.list(_v232,_v233)));
          }
        else if(_v233.isNil())
          {ESLVal _v320 = _v232;
            
            return $false;
          }
        else return error(new ESLVal("case error at Pos(25180,25390)").add(ESLVal.list(_v232,_v233)));
      else if(_v233.isCons())
          {ESLVal $967 = _v233.head();
            ESLVal $968 = _v233.tail();
            
            return error(new ESLVal("case error at Pos(25180,25390)").add(ESLVal.list(_v232,_v233)));
          }
        else if(_v233.isNil())
          {ESLVal _v321 = _v232;
            
            return $false;
          }
        else return error(new ESLVal("case error at Pos(25180,25390)").add(ESLVal.list(_v232,_v233)));
      }
    else if(_v232.isNil())
      if(_v233.isCons())
        {ESLVal $973 = _v233.head();
          ESLVal $974 = _v233.tail();
          
          {ESLVal _v322 = _v233;
          
          return $false;
        }
        }
      else if(_v233.isNil())
        return $true;
      else {ESLVal _v323 = _v233;
          
          return $false;
        }
    else if(_v233.isCons())
        {ESLVal $967 = _v233.head();
          ESLVal $968 = _v233.tail();
          
          return error(new ESLVal("case error at Pos(25180,25390)").add(ESLVal.list(_v232,_v233)));
        }
      else if(_v233.isNil())
        {ESLVal _v324 = _v232;
          
          return $false;
        }
      else return error(new ESLVal("case error at Pos(25180,25390)").add(ESLVal.list(_v232,_v233)));
    }
  }
  public static ESLVal typesEqual = new ESLVal(new Function(new ESLVal("typesEqual"),null) { public ESLVal apply(ESLVal... args) { return typesEqual(args[0],args[1]); }});
  public static ESLVal subTypes(ESLVal ts1,ESLVal ts2) {
    
    {ESLVal _v234 = ts1;
      ESLVal _v235 = ts2;
      
      if(_v234.isCons())
      {ESLVal $977 = _v234.head();
        ESLVal $978 = _v234.tail();
        
        if(_v235.isCons())
        {ESLVal $979 = _v235.head();
          ESLVal $980 = _v235.tail();
          
          {ESLVal t1 = $977;
          
          {ESLVal _v311 = $978;
          
          {ESLVal t2 = $979;
          
          {ESLVal _v312 = $980;
          
          return subType(t1,t2).and(subTypes(_v311,_v312));
        }
        }
        }
        }
        }
      else if(_v235.isNil())
        if(_v235.isCons())
          {ESLVal $975 = _v235.head();
            ESLVal $976 = _v235.tail();
            
            return error(new ESLVal("case error at Pos(25436,25642)").add(ESLVal.list(_v234,_v235)));
          }
        else if(_v235.isNil())
          {ESLVal _v313 = _v234;
            
            return $false;
          }
        else return error(new ESLVal("case error at Pos(25436,25642)").add(ESLVal.list(_v234,_v235)));
      else if(_v235.isCons())
          {ESLVal $975 = _v235.head();
            ESLVal $976 = _v235.tail();
            
            return error(new ESLVal("case error at Pos(25436,25642)").add(ESLVal.list(_v234,_v235)));
          }
        else if(_v235.isNil())
          {ESLVal _v314 = _v234;
            
            return $false;
          }
        else return error(new ESLVal("case error at Pos(25436,25642)").add(ESLVal.list(_v234,_v235)));
      }
    else if(_v234.isNil())
      if(_v235.isCons())
        {ESLVal $981 = _v235.head();
          ESLVal $982 = _v235.tail();
          
          {ESLVal _v315 = _v235;
          
          return $false;
        }
        }
      else if(_v235.isNil())
        return $true;
      else {ESLVal _v316 = _v235;
          
          return $false;
        }
    else if(_v235.isCons())
        {ESLVal $975 = _v235.head();
          ESLVal $976 = _v235.tail();
          
          return error(new ESLVal("case error at Pos(25436,25642)").add(ESLVal.list(_v234,_v235)));
        }
      else if(_v235.isNil())
        {ESLVal _v317 = _v234;
          
          return $false;
        }
      else return error(new ESLVal("case error at Pos(25436,25642)").add(ESLVal.list(_v234,_v235)));
    }
  }
  public static ESLVal subTypes = new ESLVal(new Function(new ESLVal("subTypes"),null) { public ESLVal apply(ESLVal... args) { return subTypes(args[0],args[1]); }});
  public static ESLVal typeSetEqual(ESLVal types1,ESLVal types2) {
    
    return typeSubset(types1,types2).and(typeSubset(types2,types1));
  }
  public static ESLVal typeSetEqual = new ESLVal(new Function(new ESLVal("typeSetEqual"),null) { public ESLVal apply(ESLVal... args) { return typeSetEqual(args[0],args[1]); }});
  public static ESLVal typeSubset(ESLVal sub,ESLVal sup) {
    
    {ESLVal _v236 = sub;
      
      if(_v236.isCons())
      {ESLVal $983 = _v236.head();
        ESLVal $984 = _v236.tail();
        
        {ESLVal t = $983;
        
        {ESLVal _v310 = $984;
        
        return typeMember(t,sup).and(typeSubset(_v310,sup));
      }
      }
      }
    else if(_v236.isNil())
      return $true;
    else return error(new ESLVal("case error at Pos(25802,25908)").add(ESLVal.list(_v236)));
    }
  }
  public static ESLVal typeSubset = new ESLVal(new Function(new ESLVal("typeSubset"),null) { public ESLVal apply(ESLVal... args) { return typeSubset(args[0],args[1]); }});
  public static ESLVal typeMember(ESLVal t,ESLVal types) {
    
    {ESLVal _v237 = types;
      
      if(_v237.isCons())
      {ESLVal $985 = _v237.head();
        ESLVal $986 = _v237.tail();
        
        {ESLVal tt = $985;
        
        {ESLVal _v307 = $986;
        
        if(typeEqual(t,tt).boolVal)
        return $true;
        else
          {ESLVal _v308 = $985;
            
            {ESLVal _v309 = $986;
            
            return typeMember(t,_v309);
          }
          }
      }
      }
      }
    else if(_v237.isNil())
      return $false;
    else return error(new ESLVal("case error at Pos(25954,26101)").add(ESLVal.list(_v237)));
    }
  }
  public static ESLVal typeMember = new ESLVal(new Function(new ESLVal("typeMember"),null) { public ESLVal apply(ESLVal... args) { return typeMember(args[0],args[1]); }});
  public static ESLVal substTypes(ESLVal newType,ESLVal n,ESLVal oldTypes) {
    
    {ESLVal _v238 = oldTypes;
      
      if(_v238.isCons())
      {ESLVal $987 = _v238.head();
        ESLVal $988 = _v238.tail();
        
        {ESLVal t = $987;
        
        {ESLVal ts = $988;
        
        return substTypes(newType,n,ts).cons(substType(newType,n,t));
      }
      }
      }
    else if(_v238.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(26253,26373)").add(ESLVal.list(_v238)));
    }
  }
  public static ESLVal substTypes = new ESLVal(new Function(new ESLVal("substTypes"),null) { public ESLVal apply(ESLVal... args) { return substTypes(args[0],args[1],args[2]); }});
  public static ESLVal substType(ESLVal newType,ESLVal n,ESLVal oldType) {
    
    {ESLVal _v239 = oldType;
      
      switch(_v239.termName) {
      case "ApplyType": {ESLVal $1049 = _v239.termRef(0);
        ESLVal $1048 = _v239.termRef(1);
        ESLVal $1047 = _v239.termRef(2);
        
        {ESLVal l = $1049;
        
        {ESLVal m = $1048;
        
        {ESLVal types = $1047;
        
        if(m.eql(n).boolVal)
        return new ESLVal("ApplyTypeFun",l,newType,substTypes(newType,n,types));
        else
          return new ESLVal("ApplyType",l,m,substTypes(newType,n,types));
      }
      }
      }
      }
    case "ApplyTypeFun": {ESLVal $1046 = _v239.termRef(0);
        ESLVal $1045 = _v239.termRef(1);
        ESLVal $1044 = _v239.termRef(2);
        
        {ESLVal l = $1046;
        
        {ESLVal op = $1045;
        
        {ESLVal args = $1044;
        
        return new ESLVal("ApplyTypeFun",l,substType(newType,n,op),substTypes(newType,n,args));
      }
      }
      }
      }
    case "ActType": {ESLVal $1043 = _v239.termRef(0);
        ESLVal $1042 = _v239.termRef(1);
        ESLVal $1041 = _v239.termRef(2);
        
        {ESLVal l = $1043;
        
        {ESLVal decs = $1042;
        
        {ESLVal handlers = $1041;
        
        return new ESLVal("ActType",l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal d = $l0.head();
              $l0 = $l0.tail();
              $v.add(substDec(newType,n,d));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(decs),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal m = $l0.head();
              $l0 = $l0.tail();
              $v.add(substMType(newType,n,m));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(handlers));
      }
      }
      }
      }
    case "ArrayType": {ESLVal $1040 = _v239.termRef(0);
        ESLVal $1039 = _v239.termRef(1);
        
        {ESLVal l = $1040;
        
        {ESLVal t = $1039;
        
        return new ESLVal("ArrayType",l,substType(newType,n,t));
      }
      }
      }
    case "BoolType": {ESLVal $1038 = _v239.termRef(0);
        
        {ESLVal l = $1038;
        
        return oldType;
      }
      }
    case "ExtendedAct": {ESLVal $1037 = _v239.termRef(0);
        ESLVal $1036 = _v239.termRef(1);
        ESLVal $1035 = _v239.termRef(2);
        ESLVal $1034 = _v239.termRef(3);
        
        {ESLVal l = $1037;
        
        {ESLVal parent = $1036;
        
        {ESLVal decs = $1035;
        
        {ESLVal ms = $1034;
        
        return new ESLVal("ExtendedAct",l,substType(newType,n,parent),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal d = $l0.head();
              $l0 = $l0.tail();
              $v.add(substDec(newType,n,d));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(decs),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal m = $l0.head();
              $l0 = $l0.tail();
              $v.add(substMType(newType,n,m));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(ms));
      }
      }
      }
      }
      }
    case "FloatType": {ESLVal $1033 = _v239.termRef(0);
        
        {ESLVal l = $1033;
        
        return oldType;
      }
      }
    case "ForallType": {ESLVal $1032 = _v239.termRef(0);
        ESLVal $1031 = _v239.termRef(1);
        ESLVal $1030 = _v239.termRef(2);
        
        {ESLVal l = $1032;
        
        {ESLVal ns = $1031;
        
        {ESLVal t = $1030;
        
        if(member.apply(n,ns).boolVal)
        return oldType;
        else
          return new ESLVal("ForallType",l,ns,substType(newType,n,t));
      }
      }
      }
      }
    case "FunType": {ESLVal $1029 = _v239.termRef(0);
        ESLVal $1028 = _v239.termRef(1);
        ESLVal $1027 = _v239.termRef(2);
        
        {ESLVal l = $1029;
        
        {ESLVal d = $1028;
        
        {ESLVal r = $1027;
        
        return new ESLVal("FunType",l,substTypes(newType,n,d),substType(newType,n,r));
      }
      }
      }
      }
    case "IntType": {ESLVal $1026 = _v239.termRef(0);
        
        {ESLVal l = $1026;
        
        return oldType;
      }
      }
    case "ListType": {ESLVal $1025 = _v239.termRef(0);
        ESLVal $1024 = _v239.termRef(1);
        
        {ESLVal l = $1025;
        
        {ESLVal t = $1024;
        
        return new ESLVal("ListType",l,substType(newType,n,t));
      }
      }
      }
    case "NullType": {ESLVal $1023 = _v239.termRef(0);
        
        {ESLVal l = $1023;
        
        return oldType;
      }
      }
    case "ObserverType": {ESLVal $1022 = _v239.termRef(0);
        ESLVal $1021 = _v239.termRef(1);
        ESLVal $1020 = _v239.termRef(2);
        
        {ESLVal l = $1022;
        
        {ESLVal s = $1021;
        
        {ESLVal m = $1020;
        
        return new ESLVal("ObserverType",l,substType(newType,n,s),substType(newType,n,m));
      }
      }
      }
      }
    case "ObservedType": {ESLVal $1019 = _v239.termRef(0);
        ESLVal $1018 = _v239.termRef(1);
        ESLVal $1017 = _v239.termRef(2);
        
        {ESLVal l = $1019;
        
        {ESLVal s = $1018;
        
        {ESLVal m = $1017;
        
        return new ESLVal("ObservedType",l,substType(newType,n,s),substType(newType,n,m));
      }
      }
      }
      }
    case "RecordType": {ESLVal $1016 = _v239.termRef(0);
        ESLVal $1015 = _v239.termRef(1);
        
        {ESLVal l = $1016;
        
        {ESLVal fs = $1015;
        
        return new ESLVal("RecordType",l,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v240 = $qualArg;
              
              switch(_v240.termName) {
              case "Dec": {ESLVal $1053 = _v240.termRef(0);
                ESLVal $1052 = _v240.termRef(1);
                ESLVal $1051 = _v240.termRef(2);
                ESLVal $1050 = _v240.termRef(3);
                
                {ESLVal dl = $1053;
                
                {ESLVal _v306 = $1052;
                
                {ESLVal t = $1051;
                
                {ESLVal dt = $1050;
                
                return ESLVal.list(ESLVal.list(new ESLVal("Dec",dl,_v306,substType(newType,_v306,t),dt)));
              }
              }
              }
              }
              }
              default: {ESLVal _0 = _v240;
                
                return $nil;
              }
            }
            }
          }
        }).map(fs).flatten().flatten());
      }
      }
      }
    case "RecType": {ESLVal $1014 = _v239.termRef(0);
        ESLVal $1013 = _v239.termRef(1);
        ESLVal $1012 = _v239.termRef(2);
        
        {ESLVal l = $1014;
        
        {ESLVal a = $1013;
        
        {ESLVal t = $1012;
        
        if(n.eql(a).boolVal)
        return oldType;
        else
          return new ESLVal("RecType",l,a,substType(newType,n,t));
      }
      }
      }
      }
    case "SetType": {ESLVal $1011 = _v239.termRef(0);
        ESLVal $1010 = _v239.termRef(1);
        
        {ESLVal l = $1011;
        
        {ESLVal t = $1010;
        
        return new ESLVal("SetType",l,substType(newType,n,t));
      }
      }
      }
    case "StrType": {ESLVal $1009 = _v239.termRef(0);
        
        {ESLVal l = $1009;
        
        return oldType;
      }
      }
    case "TableType": {ESLVal $1008 = _v239.termRef(0);
        ESLVal $1007 = _v239.termRef(1);
        ESLVal $1006 = _v239.termRef(2);
        
        {ESLVal l = $1008;
        
        {ESLVal k = $1007;
        
        {ESLVal v = $1006;
        
        return new ESLVal("TableType",l,substType(newType,n,k),substType(newType,n,v));
      }
      }
      }
      }
    case "TermType": {ESLVal $1005 = _v239.termRef(0);
        ESLVal $1004 = _v239.termRef(1);
        ESLVal $1003 = _v239.termRef(2);
        
        {ESLVal l = $1005;
        
        {ESLVal f = $1004;
        
        {ESLVal ts = $1003;
        
        return new ESLVal("TermType",l,f,substTypes(newType,n,ts));
      }
      }
      }
      }
    case "TypeClosure": {ESLVal $1002 = _v239.termRef(0);
        
        {ESLVal f = $1002;
        
        return oldType;
      }
      }
    case "TypeFun": {ESLVal $1001 = _v239.termRef(0);
        ESLVal $1000 = _v239.termRef(1);
        ESLVal $999 = _v239.termRef(2);
        
        {ESLVal l = $1001;
        
        {ESLVal ns = $1000;
        
        {ESLVal t = $999;
        
        if(member.apply(n,ns).boolVal)
        return oldType;
        else
          return new ESLVal("TypeFun",l,ns,substType(newType,n,t));
      }
      }
      }
      }
    case "UnfoldType": {ESLVal $998 = _v239.termRef(0);
        ESLVal $997 = _v239.termRef(1);
        
        {ESLVal l = $998;
        
        {ESLVal t = $997;
        
        return new ESLVal("UnfoldType",l,substType(newType,n,t));
      }
      }
      }
    case "UnionType": {ESLVal $996 = _v239.termRef(0);
        ESLVal $995 = _v239.termRef(1);
        
        {ESLVal l = $996;
        
        {ESLVal ts = $995;
        
        return new ESLVal("UnionType",l,substTypes(newType,n,ts));
      }
      }
      }
    case "VarType": {ESLVal $994 = _v239.termRef(0);
        ESLVal $993 = _v239.termRef(1);
        
        {ESLVal l = $994;
        
        {ESLVal name = $993;
        
        if(name.eql(n).boolVal)
        return newType;
        else
          return oldType;
      }
      }
      }
    case "VoidType": {ESLVal $992 = _v239.termRef(0);
        
        {ESLVal l = $992;
        
        return oldType;
      }
      }
    case "UnionRef": {ESLVal $991 = _v239.termRef(0);
        ESLVal $990 = _v239.termRef(1);
        ESLVal $989 = _v239.termRef(2);
        
        {ESLVal l = $991;
        
        {ESLVal t = $990;
        
        {ESLVal name = $989;
        
        return new ESLVal("UnionRef",l,substType(newType,n,t),name);
      }
      }
      }
      }
      default: {ESLVal x = _v239;
        
        return error(x);
      }
    }
    }
  }
  public static ESLVal substType = new ESLVal(new Function(new ESLVal("substType"),null) { public ESLVal apply(ESLVal... args) { return substType(args[0],args[1],args[2]); }});
  public static ESLVal substTypesEnv(ESLVal env,ESLVal types) {
    
    {ESLVal _v241 = types;
      
      if(_v241.isCons())
      {ESLVal $1054 = _v241.head();
        ESLVal $1055 = _v241.tail();
        
        {ESLVal t = $1054;
        
        {ESLVal ts = $1055;
        
        return substTypesEnv(env,ts).cons(substTypeEnv(env,t));
      }
      }
      }
    else if(_v241.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(29069,29180)").add(ESLVal.list(_v241)));
    }
  }
  public static ESLVal substTypesEnv = new ESLVal(new Function(new ESLVal("substTypesEnv"),null) { public ESLVal apply(ESLVal... args) { return substTypesEnv(args[0],args[1]); }});
  public static ESLVal substTypeEnv(ESLVal env,ESLVal oldType) {
    
    {ESLVal _v242 = oldType;
      
      switch(_v242.termName) {
      case "ApplyType": {ESLVal $1125 = _v242.termRef(0);
        ESLVal $1124 = _v242.termRef(1);
        ESLVal $1123 = _v242.termRef(2);
        
        {ESLVal l = $1125;
        
        {ESLVal n = $1124;
        
        {ESLVal types = $1123;
        
        {ESLVal op = lookupType(n,env);
        
        if(op.eql($null).boolVal)
        return new ESLVal("ApplyType",l,n,substTypesEnv(env,types));
        else
          return new ESLVal("ApplyTypeFun",l,op,substTypesEnv(env,types));
      }
      }
      }
      }
      }
    case "ApplyTypeFun": {ESLVal $1122 = _v242.termRef(0);
        ESLVal $1121 = _v242.termRef(1);
        ESLVal $1120 = _v242.termRef(2);
        
        {ESLVal l = $1122;
        
        {ESLVal op = $1121;
        
        {ESLVal args = $1120;
        
        return new ESLVal("ApplyTypeFun",l,substTypeEnv(env,op),substTypesEnv(env,args));
      }
      }
      }
      }
    case "ActType": {ESLVal $1119 = _v242.termRef(0);
        ESLVal $1118 = _v242.termRef(1);
        ESLVal $1117 = _v242.termRef(2);
        
        {ESLVal l = $1119;
        
        {ESLVal decs = $1118;
        
        {ESLVal handlers = $1117;
        
        return new ESLVal("ActType",l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal d = $l0.head();
              $l0 = $l0.tail();
              $v.add(substDecEnv(env,d));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(decs),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal m = $l0.head();
              $l0 = $l0.tail();
              $v.add(substMTypeEnv(env,m));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(handlers));
      }
      }
      }
      }
    case "ExtendedAct": {ESLVal $1116 = _v242.termRef(0);
        ESLVal $1115 = _v242.termRef(1);
        ESLVal $1114 = _v242.termRef(2);
        ESLVal $1113 = _v242.termRef(3);
        
        {ESLVal l = $1116;
        
        {ESLVal parent = $1115;
        
        {ESLVal decs = $1114;
        
        {ESLVal handlers = $1113;
        
        return new ESLVal("ExtendedAct",l,substTypeEnv(env,parent),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal d = $l0.head();
              $l0 = $l0.tail();
              $v.add(substDecEnv(env,d));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(decs),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal m = $l0.head();
              $l0 = $l0.tail();
              $v.add(substMTypeEnv(env,m));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(handlers));
      }
      }
      }
      }
      }
    case "ArrayType": {ESLVal $1112 = _v242.termRef(0);
        ESLVal $1111 = _v242.termRef(1);
        
        {ESLVal l = $1112;
        
        {ESLVal t = $1111;
        
        return new ESLVal("ArrayType",l,substTypeEnv(env,t));
      }
      }
      }
    case "BoolType": {ESLVal $1110 = _v242.termRef(0);
        
        {ESLVal l = $1110;
        
        return oldType;
      }
      }
    case "FloatType": {ESLVal $1109 = _v242.termRef(0);
        
        {ESLVal l = $1109;
        
        return oldType;
      }
      }
    case "ForallType": {ESLVal $1108 = _v242.termRef(0);
        ESLVal $1107 = _v242.termRef(1);
        ESLVal $1106 = _v242.termRef(2);
        
        {ESLVal l = $1108;
        
        {ESLVal ns = $1107;
        
        {ESLVal t = $1106;
        
        return new ESLVal("ForallType",l,ns,substTypeEnv(removeFromDom(env,ns),t));
      }
      }
      }
      }
    case "FieldType": {ESLVal $1105 = _v242.termRef(0);
        ESLVal $1104 = _v242.termRef(1);
        ESLVal $1103 = _v242.termRef(2);
        
        {ESLVal l = $1105;
        
        {ESLVal n = $1104;
        
        {ESLVal t = $1103;
        
        return new ESLVal("FieldType",l,n,substTypeEnv(env,t));
      }
      }
      }
      }
    case "FunType": {ESLVal $1102 = _v242.termRef(0);
        ESLVal $1101 = _v242.termRef(1);
        ESLVal $1100 = _v242.termRef(2);
        
        {ESLVal l = $1102;
        
        {ESLVal d = $1101;
        
        {ESLVal r = $1100;
        
        return new ESLVal("FunType",l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal t = $l0.head();
              $l0 = $l0.tail();
              $v.add(substTypeEnv(env,t));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(d),substTypeEnv(env,r));
      }
      }
      }
      }
    case "TaggedFunType": {ESLVal $1099 = _v242.termRef(0);
        ESLVal $1098 = _v242.termRef(1);
        ESLVal $1097 = _v242.termRef(2);
        ESLVal $1096 = _v242.termRef(3);
        
        {ESLVal l = $1099;
        
        {ESLVal d = $1098;
        
        {ESLVal p = $1097;
        
        {ESLVal r = $1096;
        
        return new ESLVal("FunType",l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal t = $l0.head();
              $l0 = $l0.tail();
              $v.add(substTypeEnv(env,t));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(d),substTypeEnv(env,r));
      }
      }
      }
      }
      }
    case "IntType": {ESLVal $1095 = _v242.termRef(0);
        
        {ESLVal l = $1095;
        
        return oldType;
      }
      }
    case "ListType": {ESLVal $1094 = _v242.termRef(0);
        ESLVal $1093 = _v242.termRef(1);
        
        {ESLVal l = $1094;
        
        {ESLVal t = $1093;
        
        return new ESLVal("ListType",l,substTypeEnv(env,t));
      }
      }
      }
    case "SetType": {ESLVal $1092 = _v242.termRef(0);
        ESLVal $1091 = _v242.termRef(1);
        
        {ESLVal l = $1092;
        
        {ESLVal t = $1091;
        
        return new ESLVal("SetType",l,substTypeEnv(env,t));
      }
      }
      }
    case "BagType": {ESLVal $1090 = _v242.termRef(0);
        ESLVal $1089 = _v242.termRef(1);
        
        {ESLVal l = $1090;
        
        {ESLVal t = $1089;
        
        return new ESLVal("BagType",l,substTypeEnv(env,t));
      }
      }
      }
    case "NullType": {ESLVal $1088 = _v242.termRef(0);
        
        {ESLVal l = $1088;
        
        return oldType;
      }
      }
    case "ObserverType": {ESLVal $1087 = _v242.termRef(0);
        ESLVal $1086 = _v242.termRef(1);
        ESLVal $1085 = _v242.termRef(2);
        
        {ESLVal l = $1087;
        
        {ESLVal s = $1086;
        
        {ESLVal m = $1085;
        
        return new ESLVal("ObserverType",l,substTypeEnv(env,s),substTypeEnv(env,m));
      }
      }
      }
      }
    case "ObservedType": {ESLVal $1084 = _v242.termRef(0);
        ESLVal $1083 = _v242.termRef(1);
        ESLVal $1082 = _v242.termRef(2);
        
        {ESLVal l = $1084;
        
        {ESLVal s = $1083;
        
        {ESLVal m = $1082;
        
        return new ESLVal("ObservedType",l,substTypeEnv(env,s),substTypeEnv(env,m));
      }
      }
      }
      }
    case "RecType": {ESLVal $1081 = _v242.termRef(0);
        ESLVal $1080 = _v242.termRef(1);
        ESLVal $1079 = _v242.termRef(2);
        
        {ESLVal l = $1081;
        
        {ESLVal a = $1080;
        
        {ESLVal t = $1079;
        
        return new ESLVal("RecType",l,a,substTypeEnv(removeFromDom(env,ESLVal.list(a)),t));
      }
      }
      }
      }
    case "RecordType": {ESLVal $1078 = _v242.termRef(0);
        ESLVal $1077 = _v242.termRef(1);
        
        {ESLVal l = $1078;
        
        {ESLVal fs = $1077;
        
        return new ESLVal("RecordType",l,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v243 = $qualArg;
              
              switch(_v243.termName) {
              case "Dec": {ESLVal $1129 = _v243.termRef(0);
                ESLVal $1128 = _v243.termRef(1);
                ESLVal $1127 = _v243.termRef(2);
                ESLVal $1126 = _v243.termRef(3);
                
                {ESLVal dl = $1129;
                
                {ESLVal n = $1128;
                
                {ESLVal t = $1127;
                
                {ESLVal dt = $1126;
                
                return ESLVal.list(ESLVal.list(new ESLVal("Dec",dl,n,substTypeEnv(env,t),dt)));
              }
              }
              }
              }
              }
              default: {ESLVal _0 = _v243;
                
                return $nil;
              }
            }
            }
          }
        }).map(fs).flatten().flatten());
      }
      }
      }
    case "StrType": {ESLVal $1076 = _v242.termRef(0);
        
        {ESLVal l = $1076;
        
        return oldType;
      }
      }
    case "TableType": {ESLVal $1075 = _v242.termRef(0);
        ESLVal $1074 = _v242.termRef(1);
        ESLVal $1073 = _v242.termRef(2);
        
        {ESLVal l = $1075;
        
        {ESLVal k = $1074;
        
        {ESLVal v = $1073;
        
        return new ESLVal("TableType",l,substTypeEnv(env,k),substTypeEnv(env,v));
      }
      }
      }
      }
    case "TermType": {ESLVal $1072 = _v242.termRef(0);
        ESLVal $1071 = _v242.termRef(1);
        ESLVal $1070 = _v242.termRef(2);
        
        {ESLVal l = $1072;
        
        {ESLVal f = $1071;
        
        {ESLVal ts = $1070;
        
        return new ESLVal("TermType",l,f,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal t = $l0.head();
              $l0 = $l0.tail();
              $v.add(substTypeEnv(env,t));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(ts));
      }
      }
      }
      }
    case "TypeClosure": {ESLVal $1069 = _v242.termRef(0);
        
        {ESLVal f = $1069;
        
        return oldType;
      }
      }
    case "TypeFun": {ESLVal $1068 = _v242.termRef(0);
        ESLVal $1067 = _v242.termRef(1);
        ESLVal $1066 = _v242.termRef(2);
        
        {ESLVal l = $1068;
        
        {ESLVal ns = $1067;
        
        {ESLVal t = $1066;
        
        return new ESLVal("TypeFun",l,ns,substTypeEnv(removeFromDom(env,ns),t));
      }
      }
      }
      }
    case "UnfoldType": {ESLVal $1065 = _v242.termRef(0);
        ESLVal $1064 = _v242.termRef(1);
        
        {ESLVal l = $1065;
        
        {ESLVal t = $1064;
        
        return new ESLVal("UnfoldType",l,substTypeEnv(env,t));
      }
      }
      }
    case "UnionType": {ESLVal $1063 = _v242.termRef(0);
        ESLVal $1062 = _v242.termRef(1);
        
        {ESLVal l = $1063;
        
        {ESLVal ts = $1062;
        
        return new ESLVal("UnionType",l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal t = $l0.head();
              $l0 = $l0.tail();
              $v.add(substTypeEnv(env,t));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(ts));
      }
      }
      }
    case "VarType": {ESLVal $1061 = _v242.termRef(0);
        ESLVal $1060 = _v242.termRef(1);
        
        {ESLVal l = $1061;
        
        {ESLVal name = $1060;
        
        if(member.apply(name,typeEnvDom(env)).boolVal)
        return lookupType(name,env);
        else
          return oldType;
      }
      }
      }
    case "VoidType": {ESLVal $1059 = _v242.termRef(0);
        
        {ESLVal l = $1059;
        
        return oldType;
      }
      }
    case "UnionRef": {ESLVal $1058 = _v242.termRef(0);
        ESLVal $1057 = _v242.termRef(1);
        ESLVal $1056 = _v242.termRef(2);
        
        {ESLVal l = $1058;
        
        {ESLVal t = $1057;
        
        {ESLVal name = $1056;
        
        return new ESLVal("UnionRef",l,substTypeEnv(env,t),name);
      }
      }
      }
      }
      default: {ESLVal x = _v242;
        
        return error(new ESLVal("substTypeEnv: ").add(oldType));
      }
    }
    }
  }
  public static ESLVal substTypeEnv = new ESLVal(new Function(new ESLVal("substTypeEnv"),null) { public ESLVal apply(ESLVal... args) { return substTypeEnv(args[0],args[1]); }});
  public static ESLVal zipTypeEnv(ESLVal ns,ESLVal ts) {
    
    {ESLVal _v244 = ns;
      ESLVal _v245 = ts;
      
      if(_v244.isCons())
      {ESLVal $1130 = _v244.head();
        ESLVal $1131 = _v244.tail();
        
        if(_v245.isCons())
        {ESLVal $1132 = _v245.head();
          ESLVal $1133 = _v245.tail();
          
          {ESLVal n = $1130;
          
          {ESLVal _v304 = $1131;
          
          {ESLVal t = $1132;
          
          {ESLVal _v305 = $1133;
          
          return zipTypeEnv(_v304,_v305).cons(new ESLVal("Map",n,t));
        }
        }
        }
        }
        }
      else if(_v245.isNil())
        return error(new ESLVal("case error at Pos(32116,32237)").add(ESLVal.list(_v244,_v245)));
      else return error(new ESLVal("case error at Pos(32116,32237)").add(ESLVal.list(_v244,_v245)));
      }
    else if(_v244.isNil())
      if(_v245.isCons())
        {ESLVal $1134 = _v245.head();
          ESLVal $1135 = _v245.tail();
          
          return error(new ESLVal("case error at Pos(32116,32237)").add(ESLVal.list(_v244,_v245)));
        }
      else if(_v245.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(32116,32237)").add(ESLVal.list(_v244,_v245)));
    else return error(new ESLVal("case error at Pos(32116,32237)").add(ESLVal.list(_v244,_v245)));
    }
  }
  public static ESLVal zipTypeEnv = new ESLVal(new Function(new ESLVal("zipTypeEnv"),null) { public ESLVal apply(ESLVal... args) { return zipTypeEnv(args[0],args[1]); }});
  public static ESLVal lookupType(ESLVal name,ESLVal env) {
    
    {ESLVal _v246 = env;
      
      if(_v246.isCons())
      {ESLVal $1136 = _v246.head();
        ESLVal $1137 = _v246.tail();
        
        switch($1136.termName) {
        case "Map": {ESLVal $1139 = $1136.termRef(0);
          ESLVal $1138 = $1136.termRef(1);
          
          {ESLVal n = $1139;
          
          {ESLVal t = $1138;
          
          {ESLVal e = $1137;
          
          if(n.eql(name).boolVal)
          return t;
          else
            {ESLVal m = $1136;
              
              {ESLVal _v303 = $1137;
              
              return lookupType(name,_v303);
            }
            }
        }
        }
        }
        }
        default: {ESLVal m = $1136;
          
          {ESLVal e = $1137;
          
          return lookupType(name,e);
        }
        }
      }
      }
    else if(_v246.isNil())
      return $null;
    else return error(new ESLVal("case error at Pos(32283,32420)").add(ESLVal.list(_v246)));
    }
  }
  public static ESLVal lookupType = new ESLVal(new Function(new ESLVal("lookupType"),null) { public ESLVal apply(ESLVal... args) { return lookupType(args[0],args[1]); }});
  public static ESLVal typeEnvDom(ESLVal e) {
    
    {ESLVal _v247 = e;
      
      if(_v247.isCons())
      {ESLVal $1140 = _v247.head();
        ESLVal $1141 = _v247.tail();
        
        switch($1140.termName) {
        case "Map": {ESLVal $1143 = $1140.termRef(0);
          ESLVal $1142 = $1140.termRef(1);
          
          {ESLVal n = $1143;
          
          {ESLVal t = $1142;
          
          {ESLVal x = $1141;
          
          return typeEnvDom(x).cons(n);
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(32455,32544)").add(ESLVal.list(_v247)));
      }
      }
    else if(_v247.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(32455,32544)").add(ESLVal.list(_v247)));
    }
  }
  public static ESLVal typeEnvDom = new ESLVal(new Function(new ESLVal("typeEnvDom"),null) { public ESLVal apply(ESLVal... args) { return typeEnvDom(args[0]); }});
  public static ESLVal removeFromDom(ESLVal e,ESLVal ns) {
    
    {ESLVal _v248 = e;
      
      if(_v248.isCons())
      {ESLVal $1144 = _v248.head();
        ESLVal $1145 = _v248.tail();
        
        switch($1144.termName) {
        case "Map": {ESLVal $1147 = $1144.termRef(0);
          ESLVal $1146 = $1144.termRef(1);
          
          {ESLVal n = $1147;
          
          {ESLVal t = $1146;
          
          {ESLVal _v299 = $1145;
          
          if(member.apply(n,ns).boolVal)
          return removeFromDom(_v299,ns);
          else
            {ESLVal _v300 = $1147;
              
              {ESLVal _v301 = $1146;
              
              {ESLVal _v302 = $1145;
              
              return removeFromDom(_v302,ns).cons(new ESLVal("Map",_v300,_v301));
            }
            }
            }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(32591,32773)").add(ESLVal.list(_v248)));
      }
      }
    else if(_v248.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(32591,32773)").add(ESLVal.list(_v248)));
    }
  }
  public static ESLVal removeFromDom = new ESLVal(new Function(new ESLVal("removeFromDom"),null) { public ESLVal apply(ESLVal... args) { return removeFromDom(args[0],args[1]); }});
  public static ESLVal restrictTypeEnv(ESLVal e,ESLVal ns) {
    
    {ESLVal _v249 = e;
      
      if(_v249.isCons())
      {ESLVal $1148 = _v249.head();
        ESLVal $1149 = _v249.tail();
        
        switch($1148.termName) {
        case "Map": {ESLVal $1151 = $1148.termRef(0);
          ESLVal $1150 = $1148.termRef(1);
          
          {ESLVal n = $1151;
          
          {ESLVal t = $1150;
          
          {ESLVal _v295 = $1149;
          
          if(member.apply(n,ns).not().boolVal)
          return restrictTypeEnv(_v295,ns);
          else
            {ESLVal _v296 = $1151;
              
              {ESLVal _v297 = $1150;
              
              {ESLVal _v298 = $1149;
              
              return restrictTypeEnv(_v298,ns).cons(new ESLVal("Map",_v296,_v297));
            }
            }
            }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(32822,33013)").add(ESLVal.list(_v249)));
      }
      }
    else if(_v249.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(32822,33013)").add(ESLVal.list(_v249)));
    }
  }
  public static ESLVal restrictTypeEnv = new ESLVal(new Function(new ESLVal("restrictTypeEnv"),null) { public ESLVal apply(ESLVal... args) { return restrictTypeEnv(args[0],args[1]); }});
  public static ESLVal typeEnvRan(ESLVal e) {
    
    {ESLVal _v250 = e;
      
      if(_v250.isCons())
      {ESLVal $1152 = _v250.head();
        ESLVal $1153 = _v250.tail();
        
        switch($1152.termName) {
        case "Map": {ESLVal $1155 = $1152.termRef(0);
          ESLVal $1154 = $1152.termRef(1);
          
          {ESLVal n = $1155;
          
          {ESLVal t = $1154;
          
          {ESLVal x = $1153;
          
          return typeEnvRan(x).cons(t);
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(33049,33140)").add(ESLVal.list(_v250)));
      }
      }
    else if(_v250.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(33049,33140)").add(ESLVal.list(_v250)));
    }
  }
  public static ESLVal typeEnvRan = new ESLVal(new Function(new ESLVal("typeEnvRan"),null) { public ESLVal apply(ESLVal... args) { return typeEnvRan(args[0]); }});
  public static ESLVal allEqualTypes(ESLVal t1,ESLVal ts) {
    
    {ESLVal _v251 = ts;
      
      if(_v251.isCons())
      {ESLVal $1156 = _v251.head();
        ESLVal $1157 = _v251.tail();
        
        {ESLVal t2 = $1156;
        
        {ESLVal _v292 = $1157;
        
        if(typeEqual(t1,t2).boolVal)
        return allEqualTypes(t1,_v292);
        else
          {ESLVal _v293 = _v251;
            
            return $false;
          }
      }
      }
      }
    else if(_v251.isNil())
      return $true;
    else {ESLVal _v294 = _v251;
        
        return $false;
      }
    }
  }
  public static ESLVal allEqualTypes = new ESLVal(new Function(new ESLVal("allEqualTypes"),null) { public ESLVal apply(ESLVal... args) { return allEqualTypes(args[0],args[1]); }});
  public static ESLVal substDec(ESLVal newType,ESLVal n,ESLVal d) {
    
    {ESLVal _v252 = d;
      
      switch(_v252.termName) {
      case "Dec": {ESLVal $1161 = _v252.termRef(0);
        ESLVal $1160 = _v252.termRef(1);
        ESLVal $1159 = _v252.termRef(2);
        ESLVal $1158 = _v252.termRef(3);
        
        {ESLVal l = $1161;
        
        {ESLVal name = $1160;
        
        {ESLVal t = $1159;
        
        {ESLVal st = $1158;
        
        return new ESLVal("Dec",l,name,substType(newType,n,t),st);
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(33373,33470)").add(ESLVal.list(_v252)));
    }
    }
  }
  public static ESLVal substDec = new ESLVal(new Function(new ESLVal("substDec"),null) { public ESLVal apply(ESLVal... args) { return substDec(args[0],args[1],args[2]); }});
  public static ESLVal substDecEnv(ESLVal env,ESLVal d) {
    
    {ESLVal _v253 = d;
      
      switch(_v253.termName) {
      case "Dec": {ESLVal $1165 = _v253.termRef(0);
        ESLVal $1164 = _v253.termRef(1);
        ESLVal $1163 = _v253.termRef(2);
        ESLVal $1162 = _v253.termRef(3);
        
        {ESLVal l = $1165;
        
        {ESLVal name = $1164;
        
        {ESLVal t = $1163;
        
        {ESLVal st = $1162;
        
        return new ESLVal("Dec",l,name,substTypeEnv(env,t),st);
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(33515,33609)").add(ESLVal.list(_v253)));
    }
    }
  }
  public static ESLVal substDecEnv = new ESLVal(new Function(new ESLVal("substDecEnv"),null) { public ESLVal apply(ESLVal... args) { return substDecEnv(args[0],args[1]); }});
  public static ESLVal substMType(ESLVal newType,ESLVal n,ESLVal m) {
    
    {ESLVal _v254 = m;
      
      switch(_v254.termName) {
      case "MessageType": {ESLVal $1167 = _v254.termRef(0);
        ESLVal $1166 = _v254.termRef(1);
        
        {ESLVal l = $1167;
        
        {ESLVal ts = $1166;
        
        return new ESLVal("MessageType",l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal t = $l0.head();
              $l0 = $l0.tail();
              $v.add(substType(newType,n,t));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(ts));
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(33669,33777)").add(ESLVal.list(_v254)));
    }
    }
  }
  public static ESLVal substMType = new ESLVal(new Function(new ESLVal("substMType"),null) { public ESLVal apply(ESLVal... args) { return substMType(args[0],args[1],args[2]); }});
  public static ESLVal substMTypeEnv(ESLVal env,ESLVal m) {
    
    {ESLVal _v255 = m;
      
      switch(_v255.termName) {
      case "MessageType": {ESLVal $1169 = _v255.termRef(0);
        ESLVal $1168 = _v255.termRef(1);
        
        {ESLVal l = $1169;
        
        {ESLVal ts = $1168;
        
        return new ESLVal("MessageType",l,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal t = $l0.head();
              $l0 = $l0.tail();
              $v.add(substTypeEnv(env,t));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(ts));
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(33829,33934)").add(ESLVal.list(_v255)));
    }
    }
  }
  public static ESLVal substMTypeEnv = new ESLVal(new Function(new ESLVal("substMTypeEnv"),null) { public ESLVal apply(ESLVal... args) { return substMTypeEnv(args[0],args[1]); }});
  public static ESLVal patternNames(ESLVal x) {
    
    {ESLVal _v256 = x;
      
      switch(_v256.termName) {
      case "PAdd": {ESLVal $1201 = _v256.termRef(0);
        ESLVal $1200 = _v256.termRef(1);
        ESLVal $1199 = _v256.termRef(2);
        
        {ESLVal l = $1201;
        
        {ESLVal p1 = $1200;
        
        {ESLVal p2 = $1199;
        
        return patternNames(p1).add(patternNames(p2));
      }
      }
      }
      }
    case "PVar": {ESLVal $1198 = _v256.termRef(0);
        ESLVal $1197 = _v256.termRef(1);
        ESLVal $1196 = _v256.termRef(2);
        
        {ESLVal v0 = $1198;
        
        {ESLVal v1 = $1197;
        
        {ESLVal v2 = $1196;
        
        return ESLVal.list(v1);
      }
      }
      }
      }
    case "PTerm": {ESLVal $1195 = _v256.termRef(0);
        ESLVal $1194 = _v256.termRef(1);
        ESLVal $1193 = _v256.termRef(2);
        ESLVal $1192 = _v256.termRef(3);
        
        {ESLVal v0 = $1195;
        
        {ESLVal v1 = $1194;
        
        {ESLVal v2 = $1193;
        
        {ESLVal v3 = $1192;
        
        return new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal p = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = patternNames(p);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v3);
      }
      }
      }
      }
      }
    case "PApplyType": {ESLVal $1191 = _v256.termRef(0);
        ESLVal $1190 = _v256.termRef(1);
        ESLVal $1189 = _v256.termRef(2);
        
        {ESLVal v0 = $1191;
        
        {ESLVal v1 = $1190;
        
        {ESLVal v2 = $1189;
        
        return patternNames(v1);
      }
      }
      }
      }
    case "PNil": {ESLVal $1188 = _v256.termRef(0);
        
        {ESLVal v0 = $1188;
        
        return $nil;
      }
      }
    case "PNull": {ESLVal $1187 = _v256.termRef(0);
        
        {ESLVal v0 = $1187;
        
        return $nil;
      }
      }
    case "PInt": {ESLVal $1186 = _v256.termRef(0);
        ESLVal $1185 = _v256.termRef(1);
        
        {ESLVal v0 = $1186;
        
        {ESLVal v1 = $1185;
        
        return $nil;
      }
      }
      }
    case "PStr": {ESLVal $1184 = _v256.termRef(0);
        ESLVal $1183 = _v256.termRef(1);
        
        {ESLVal v0 = $1184;
        
        {ESLVal v1 = $1183;
        
        return $nil;
      }
      }
      }
    case "PBool": {ESLVal $1182 = _v256.termRef(0);
        ESLVal $1181 = _v256.termRef(1);
        
        {ESLVal v0 = $1182;
        
        {ESLVal v1 = $1181;
        
        return $nil;
      }
      }
      }
    case "PCons": {ESLVal $1180 = _v256.termRef(0);
        ESLVal $1179 = _v256.termRef(1);
        ESLVal $1178 = _v256.termRef(2);
        
        {ESLVal v0 = $1180;
        
        {ESLVal v1 = $1179;
        
        {ESLVal v2 = $1178;
        
        return patternNames(v1).add(patternNames(v2));
      }
      }
      }
      }
    case "PBagCons": {ESLVal $1177 = _v256.termRef(0);
        ESLVal $1176 = _v256.termRef(1);
        ESLVal $1175 = _v256.termRef(2);
        
        {ESLVal v0 = $1177;
        
        {ESLVal v1 = $1176;
        
        {ESLVal v2 = $1175;
        
        return patternNames(v1).add(patternNames(v2));
      }
      }
      }
      }
    case "PEmptyBag": {ESLVal $1174 = _v256.termRef(0);
        
        {ESLVal v0 = $1174;
        
        return $nil;
      }
      }
    case "PSetCons": {ESLVal $1173 = _v256.termRef(0);
        ESLVal $1172 = _v256.termRef(1);
        ESLVal $1171 = _v256.termRef(2);
        
        {ESLVal v0 = $1173;
        
        {ESLVal v1 = $1172;
        
        {ESLVal v2 = $1171;
        
        return patternNames(v1).add(patternNames(v2));
      }
      }
      }
      }
    case "PEmptySet": {ESLVal $1170 = _v256.termRef(0);
        
        {ESLVal v0 = $1170;
        
        return $nil;
      }
      }
      default: return error(new ESLVal("case error at Pos(34808,35588)").add(ESLVal.list(_v256)));
    }
    }
  }
  public static ESLVal patternNames = new ESLVal(new Function(new ESLVal("patternNames"),null) { public ESLVal apply(ESLVal... args) { return patternNames(args[0]); }});
  public static ESLVal patternLoc(ESLVal x) {
    
    {ESLVal _v257 = x;
      
      switch(_v257.termName) {
      case "PAdd": {ESLVal $1233 = _v257.termRef(0);
        ESLVal $1232 = _v257.termRef(1);
        ESLVal $1231 = _v257.termRef(2);
        
        {ESLVal l = $1233;
        
        {ESLVal p1 = $1232;
        
        {ESLVal p2 = $1231;
        
        return l;
      }
      }
      }
      }
    case "PVar": {ESLVal $1230 = _v257.termRef(0);
        ESLVal $1229 = _v257.termRef(1);
        ESLVal $1228 = _v257.termRef(2);
        
        {ESLVal l = $1230;
        
        {ESLVal v1 = $1229;
        
        {ESLVal v2 = $1228;
        
        return l;
      }
      }
      }
      }
    case "PTerm": {ESLVal $1227 = _v257.termRef(0);
        ESLVal $1226 = _v257.termRef(1);
        ESLVal $1225 = _v257.termRef(2);
        ESLVal $1224 = _v257.termRef(3);
        
        {ESLVal l = $1227;
        
        {ESLVal v1 = $1226;
        
        {ESLVal v2 = $1225;
        
        {ESLVal v3 = $1224;
        
        return l;
      }
      }
      }
      }
      }
    case "PApplyType": {ESLVal $1223 = _v257.termRef(0);
        ESLVal $1222 = _v257.termRef(1);
        ESLVal $1221 = _v257.termRef(2);
        
        {ESLVal l = $1223;
        
        {ESLVal v1 = $1222;
        
        {ESLVal v2 = $1221;
        
        return l;
      }
      }
      }
      }
    case "PNil": {ESLVal $1220 = _v257.termRef(0);
        
        {ESLVal l = $1220;
        
        return l;
      }
      }
    case "PNull": {ESLVal $1219 = _v257.termRef(0);
        
        {ESLVal l = $1219;
        
        return l;
      }
      }
    case "PInt": {ESLVal $1218 = _v257.termRef(0);
        ESLVal $1217 = _v257.termRef(1);
        
        {ESLVal l = $1218;
        
        {ESLVal v1 = $1217;
        
        return l;
      }
      }
      }
    case "PStr": {ESLVal $1216 = _v257.termRef(0);
        ESLVal $1215 = _v257.termRef(1);
        
        {ESLVal l = $1216;
        
        {ESLVal v1 = $1215;
        
        return l;
      }
      }
      }
    case "PBool": {ESLVal $1214 = _v257.termRef(0);
        ESLVal $1213 = _v257.termRef(1);
        
        {ESLVal l = $1214;
        
        {ESLVal v1 = $1213;
        
        return l;
      }
      }
      }
    case "PCons": {ESLVal $1212 = _v257.termRef(0);
        ESLVal $1211 = _v257.termRef(1);
        ESLVal $1210 = _v257.termRef(2);
        
        {ESLVal l = $1212;
        
        {ESLVal v1 = $1211;
        
        {ESLVal v2 = $1210;
        
        return l;
      }
      }
      }
      }
    case "PBagCons": {ESLVal $1209 = _v257.termRef(0);
        ESLVal $1208 = _v257.termRef(1);
        ESLVal $1207 = _v257.termRef(2);
        
        {ESLVal l = $1209;
        
        {ESLVal v1 = $1208;
        
        {ESLVal v2 = $1207;
        
        return l;
      }
      }
      }
      }
    case "PEmptyBag": {ESLVal $1206 = _v257.termRef(0);
        
        {ESLVal l = $1206;
        
        return l;
      }
      }
    case "PSetCons": {ESLVal $1205 = _v257.termRef(0);
        ESLVal $1204 = _v257.termRef(1);
        ESLVal $1203 = _v257.termRef(2);
        
        {ESLVal l = $1205;
        
        {ESLVal v1 = $1204;
        
        {ESLVal v2 = $1203;
        
        return l;
      }
      }
      }
      }
    case "PEmptySet": {ESLVal $1202 = _v257.termRef(0);
        
        {ESLVal l = $1202;
        
        return l;
      }
      }
      default: return error(new ESLVal("case error at Pos(35626,36182)").add(ESLVal.list(_v257)));
    }
    }
  }
  public static ESLVal patternLoc = new ESLVal(new Function(new ESLVal("patternLoc"),null) { public ESLVal apply(ESLVal... args) { return patternLoc(args[0]); }});
  public static ESLVal mergeFunDefs(ESLVal defs) {
    
    { LetRec letrec = new LetRec() {
      ESLVal getFunCases = new ESLVal(new Function(new ESLVal("getFunCases"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v284 = $args[0];
        ESLVal _v285 = $args[1];
        {ESLVal _v258 = _v285;
              
              if(_v258.isCons())
              {ESLVal $1234 = _v258.head();
                ESLVal $1235 = _v258.tail();
                
                switch($1234.termName) {
                case "FunBind": {ESLVal $1242 = $1234.termRef(0);
                  ESLVal $1241 = $1234.termRef(1);
                  ESLVal $1240 = $1234.termRef(2);
                  ESLVal $1239 = $1234.termRef(3);
                  ESLVal $1238 = $1234.termRef(4);
                  ESLVal $1237 = $1234.termRef(5);
                  ESLVal $1236 = $1234.termRef(6);
                  
                  {ESLVal l = $1242;
                  
                  {ESLVal n0 = $1241;
                  
                  {ESLVal args = $1240;
                  
                  {ESLVal t = $1239;
                  
                  {ESLVal dt = $1238;
                  
                  {ESLVal e = $1237;
                  
                  {ESLVal g = $1236;
                  
                  {ESLVal _v286 = $1235;
                  
                  if(_v284.eql(n0).boolVal)
                  return getFunCases.apply(_v284,_v286).cons(new ESLVal("FunCase",l,args,t,g,e));
                  else
                    {ESLVal def = $1234;
                      
                      {ESLVal _v287 = $1235;
                      
                      return getFunCases.apply(_v284,_v287);
                    }
                    }
                }
                }
                }
                }
                }
                }
                }
                }
                }
                default: {ESLVal def = $1234;
                  
                  {ESLVal _v288 = $1235;
                  
                  return getFunCases.apply(_v284,_v288);
                }
                }
              }
              }
            else if(_v258.isNil())
              return $nil;
            else return error(new ESLVal("case error at Pos(36561,36738)").add(ESLVal.list(_v258)));
            }
          }
        });
      ESLVal removeFunCases = new ESLVal(new Function(new ESLVal("removeFunCases"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v279 = $args[0];
        ESLVal _v280 = $args[1];
        {ESLVal _v259 = _v280;
              
              if(_v259.isCons())
              {ESLVal $1243 = _v259.head();
                ESLVal $1244 = _v259.tail();
                
                switch($1243.termName) {
                case "FunBind": {ESLVal $1251 = $1243.termRef(0);
                  ESLVal $1250 = $1243.termRef(1);
                  ESLVal $1249 = $1243.termRef(2);
                  ESLVal $1248 = $1243.termRef(3);
                  ESLVal $1247 = $1243.termRef(4);
                  ESLVal $1246 = $1243.termRef(5);
                  ESLVal $1245 = $1243.termRef(6);
                  
                  {ESLVal l = $1251;
                  
                  {ESLVal n0 = $1250;
                  
                  {ESLVal args = $1249;
                  
                  {ESLVal t = $1248;
                  
                  {ESLVal dt = $1247;
                  
                  {ESLVal e = $1246;
                  
                  {ESLVal g = $1245;
                  
                  {ESLVal _v281 = $1244;
                  
                  if(_v279.eql(n0).boolVal)
                  return removeFunCases.apply(_v279,_v281);
                  else
                    {ESLVal def = $1243;
                      
                      {ESLVal _v282 = $1244;
                      
                      return removeFunCases.apply(_v279,_v282).cons(def);
                    }
                    }
                }
                }
                }
                }
                }
                }
                }
                }
                }
                default: {ESLVal def = $1243;
                  
                  {ESLVal _v283 = $1244;
                  
                  return removeFunCases.apply(_v279,_v283).cons(def);
                }
                }
              }
              }
            else if(_v259.isNil())
              return $nil;
            else return error(new ESLVal("case error at Pos(36797,36962)").add(ESLVal.list(_v259)));
            }
          }
        });
      
      public ESLVal get(String name) {
        switch(name) {
          case "getFunCases": return getFunCases;
          
          case "removeFunCases": return removeFunCases;
          
          default: throw new Error("cannot find letrec binding");
        }
        }
      };
    ESLVal getFunCases = letrec.get("getFunCases");
    
    ESLVal removeFunCases = letrec.get("removeFunCases");
    
      {ESLVal _v260 = defs;
      
      if(_v260.isCons())
      {ESLVal $1252 = _v260.head();
        ESLVal $1253 = _v260.tail();
        
        switch($1252.termName) {
        case "FunBind": {ESLVal $1260 = $1252.termRef(0);
          ESLVal $1259 = $1252.termRef(1);
          ESLVal $1258 = $1252.termRef(2);
          ESLVal $1257 = $1252.termRef(3);
          ESLVal $1256 = $1252.termRef(4);
          ESLVal $1255 = $1252.termRef(5);
          ESLVal $1254 = $1252.termRef(6);
          
          {ESLVal l = $1260;
          
          {ESLVal n = $1259;
          
          {ESLVal args = $1258;
          
          {ESLVal t = $1257;
          
          {ESLVal dt = $1256;
          
          {ESLVal e = $1255;
          
          {ESLVal g = $1254;
          
          {ESLVal _v289 = $1253;
          
          {ESLVal cases = getFunCases.apply(n,_v289);
          
          if(cases.eql($nil).boolVal)
          return mergeFunDefs(_v289).cons(new ESLVal("FunBind",l,n,args,t,dt,e,g));
          else
            {ESLVal _v290 = removeFunCases.apply(n,_v289);
              
              return mergeFunDefs(_v290).cons(new ESLVal("FunBinds",n,cases.cons(new ESLVal("FunCase",l,args,t,g,e))));
            }
        }
        }
        }
        }
        }
        }
        }
        }
        }
        }
        default: {ESLVal def = $1252;
          
          {ESLVal _v291 = $1253;
          
          return mergeFunDefs(_v291).cons(def);
        }
        }
      }
      }
    else if(_v260.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(36974,37394)").add(ESLVal.list(_v260)));
    }}
    
  }
  public static ESLVal mergeFunDefs = new ESLVal(new Function(new ESLVal("mergeFunDefs"),null) { public ESLVal apply(ESLVal... args) { return mergeFunDefs(args[0]); }});
  public static ESLVal expandFunDefs(ESLVal defs) {
    
    {ESLVal _v261 = defs;
      
      if(_v261.isCons())
      {ESLVal $1261 = _v261.head();
        ESLVal $1262 = _v261.tail();
        
        switch($1261.termName) {
        case "FunBinds": {ESLVal $1264 = $1261.termRef(0);
          ESLVal $1263 = $1261.termRef(1);
          
          if($1263.isCons())
          {ESLVal $1265 = $1263.head();
            ESLVal $1266 = $1263.tail();
            
            switch($1265.termName) {
            case "FunCase": {ESLVal $1271 = $1265.termRef(0);
              ESLVal $1270 = $1265.termRef(1);
              ESLVal $1269 = $1265.termRef(2);
              ESLVal $1268 = $1265.termRef(3);
              ESLVal $1267 = $1265.termRef(4);
              
              {ESLVal n = $1264;
              
              {ESLVal l = $1271;
              
              {ESLVal args = $1270;
              
              {ESLVal t = $1269;
              
              {ESLVal g = $1268;
              
              {ESLVal e = $1267;
              
              {ESLVal cases = $1266;
              
              {ESLVal _v269 = $1262;
              
              {ESLVal names = new java.util.function.Function<ESLVal,ESLVal>() {
                  public ESLVal apply(ESLVal $l0) {
                    ESLVal $a = $nil;
                    java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                    while(!$l0.isNil()) { 
                      ESLVal i = $l0.head();
                      $l0 = $l0.tail();
                      $v.add(new ESLVal("$").add(i));
                    }
                    for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                    return $a;
                  }}.apply($zero.to(length.apply(args)));
              
              return expandFunDefs(_v269).cons(new ESLVal("Binding",l,n,t,t,new ESLVal("FunExp",l,new ESLVal("StrExp",l,n),new java.util.function.Function<ESLVal,ESLVal>() {
                public ESLVal apply(ESLVal $l0) {
                  ESLVal $a = $nil;
                  java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                  while(!$l0.isNil()) { 
                    ESLVal n = $l0.head();
                    $l0 = $l0.tail();
                    $v.add(new ESLVal("Dec",l,n,$null,$null));
                  }
                  for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                  return $a;
                }}.apply(names),t,new ESLVal("Case",l,$nil,new java.util.function.Function<ESLVal,ESLVal>() {
                public ESLVal apply(ESLVal $l0) {
                  ESLVal $a = $nil;
                  java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                  while(!$l0.isNil()) { 
                    ESLVal n = $l0.head();
                    $l0 = $l0.tail();
                    $v.add(new ESLVal("Var",l,n));
                  }
                  for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                  return $a;
                }}.apply(names),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v262 = $qualArg;
                    
                    switch(_v262.termName) {
                    case "FunCase": {ESLVal $1276 = _v262.termRef(0);
                      ESLVal $1275 = _v262.termRef(1);
                      ESLVal $1274 = _v262.termRef(2);
                      ESLVal $1273 = _v262.termRef(3);
                      ESLVal $1272 = _v262.termRef(4);
                      
                      {ESLVal _v270 = $1276;
                      
                      {ESLVal _v271 = $1275;
                      
                      {ESLVal _v272 = $1274;
                      
                      {ESLVal _v273 = $1273;
                      
                      {ESLVal _v274 = $1272;
                      
                      return ESLVal.list(ESLVal.list(new ESLVal("BArm",_v270,_v271,_v273,_v274)));
                    }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal _0 = _v262;
                      
                      return $nil;
                    }
                  }
                  }
                }
              }).map(cases.cons(new ESLVal("FunCase",l,args,t,g,e))).flatten().flatten()))));
            }
            }
            }
            }
            }
            }
            }
            }
            }
            }
            default: {ESLVal d = $1261;
              
              {ESLVal _v275 = $1262;
              
              return expandFunDefs(_v275).cons(d);
            }
            }
          }
          }
        else if($1263.isNil())
          {ESLVal d = $1261;
            
            {ESLVal _v276 = $1262;
            
            return expandFunDefs(_v276).cons(d);
          }
          }
        else {ESLVal d = $1261;
            
            {ESLVal _v277 = $1262;
            
            return expandFunDefs(_v277).cons(d);
          }
          }
        }
        default: {ESLVal d = $1261;
          
          {ESLVal _v278 = $1262;
          
          return expandFunDefs(_v278).cons(d);
        }
        }
      }
      }
    else if(_v261.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(37442,37898)").add(ESLVal.list(_v261)));
    }
  }
  public static ESLVal expandFunDefs = new ESLVal(new Function(new ESLVal("expandFunDefs"),null) { public ESLVal apply(ESLVal... args) { return expandFunDefs(args[0]); }});
  public static ESLVal isBinding(ESLVal b) {
    
    {ESLVal _v263 = b;
      
      switch(_v263.termName) {
      case "Binding": {ESLVal $1281 = _v263.termRef(0);
        ESLVal $1280 = _v263.termRef(1);
        ESLVal $1279 = _v263.termRef(2);
        ESLVal $1278 = _v263.termRef(3);
        ESLVal $1277 = _v263.termRef(4);
        
        {ESLVal l = $1281;
        
        {ESLVal n = $1280;
        
        {ESLVal t = $1279;
        
        {ESLVal st = $1278;
        
        {ESLVal e = $1277;
        
        return $true;
      }
      }
      }
      }
      }
      }
      default: {ESLVal _v268 = _v263;
        
        return $false;
      }
    }
    }
  }
  public static ESLVal isBinding = new ESLVal(new Function(new ESLVal("isBinding"),null) { public ESLVal apply(ESLVal... args) { return isBinding(args[0]); }});
  public static ESLVal isFunBind(ESLVal b) {
    
    {ESLVal _v264 = b;
      
      switch(_v264.termName) {
      case "FunBind": {ESLVal $1288 = _v264.termRef(0);
        ESLVal $1287 = _v264.termRef(1);
        ESLVal $1286 = _v264.termRef(2);
        ESLVal $1285 = _v264.termRef(3);
        ESLVal $1284 = _v264.termRef(4);
        ESLVal $1283 = _v264.termRef(5);
        ESLVal $1282 = _v264.termRef(6);
        
        {ESLVal l = $1288;
        
        {ESLVal n = $1287;
        
        {ESLVal args = $1286;
        
        {ESLVal t = $1285;
        
        {ESLVal st = $1284;
        
        {ESLVal g = $1283;
        
        {ESLVal e = $1282;
        
        return $true;
      }
      }
      }
      }
      }
      }
      }
      }
      default: {ESLVal _v267 = _v264;
        
        return $false;
      }
    }
    }
  }
  public static ESLVal isFunBind = new ESLVal(new Function(new ESLVal("isFunBind"),null) { public ESLVal apply(ESLVal... args) { return isFunBind(args[0]); }});
  public static ESLVal bindingName(ESLVal b) {
    
    {ESLVal _v265 = b;
      
      switch(_v265.termName) {
      case "TypeBind": {ESLVal $1314 = _v265.termRef(0);
        ESLVal $1313 = _v265.termRef(1);
        ESLVal $1312 = _v265.termRef(2);
        ESLVal $1311 = _v265.termRef(3);
        
        {ESLVal v0 = $1314;
        
        {ESLVal v1 = $1313;
        
        {ESLVal v2 = $1312;
        
        {ESLVal v3 = $1311;
        
        return v1;
      }
      }
      }
      }
      }
    case "CnstrBind": {ESLVal $1310 = _v265.termRef(0);
        ESLVal $1309 = _v265.termRef(1);
        ESLVal $1308 = _v265.termRef(2);
        ESLVal $1307 = _v265.termRef(3);
        
        {ESLVal v0 = $1310;
        
        {ESLVal v1 = $1309;
        
        {ESLVal v2 = $1308;
        
        {ESLVal v3 = $1307;
        
        return v1;
      }
      }
      }
      }
      }
    case "FunBind": {ESLVal $1306 = _v265.termRef(0);
        ESLVal $1305 = _v265.termRef(1);
        ESLVal $1304 = _v265.termRef(2);
        ESLVal $1303 = _v265.termRef(3);
        ESLVal $1302 = _v265.termRef(4);
        ESLVal $1301 = _v265.termRef(5);
        ESLVal $1300 = _v265.termRef(6);
        
        {ESLVal v0 = $1306;
        
        {ESLVal v1 = $1305;
        
        {ESLVal v2 = $1304;
        
        {ESLVal v3 = $1303;
        
        {ESLVal v4 = $1302;
        
        {ESLVal v5 = $1301;
        
        {ESLVal v6 = $1300;
        
        return v1;
      }
      }
      }
      }
      }
      }
      }
      }
    case "FunBinds": {ESLVal $1299 = _v265.termRef(0);
        ESLVal $1298 = _v265.termRef(1);
        
        {ESLVal n = $1299;
        
        {ESLVal cases = $1298;
        
        return n;
      }
      }
      }
    case "Binding": {ESLVal $1297 = _v265.termRef(0);
        ESLVal $1296 = _v265.termRef(1);
        ESLVal $1295 = _v265.termRef(2);
        ESLVal $1294 = _v265.termRef(3);
        ESLVal $1293 = _v265.termRef(4);
        
        {ESLVal v0 = $1297;
        
        {ESLVal v1 = $1296;
        
        {ESLVal v2 = $1295;
        
        {ESLVal v3 = $1294;
        
        {ESLVal v4 = $1293;
        
        return v1;
      }
      }
      }
      }
      }
      }
    case "DataBind": {ESLVal $1292 = _v265.termRef(0);
        ESLVal $1291 = _v265.termRef(1);
        ESLVal $1290 = _v265.termRef(2);
        ESLVal $1289 = _v265.termRef(3);
        
        {ESLVal v0 = $1292;
        
        {ESLVal v1 = $1291;
        
        {ESLVal v2 = $1290;
        
        {ESLVal v3 = $1289;
        
        return v1;
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(38208,38557)").add(ESLVal.list(_v265)));
    }
    }
  }
  public static ESLVal bindingName = new ESLVal(new Function(new ESLVal("bindingName"),null) { public ESLVal apply(ESLVal... args) { return bindingName(args[0]); }});
  public static ESLVal bindingLoc(ESLVal b) {
    
    {ESLVal _v266 = b;
      
      switch(_v266.termName) {
      case "TypeBind": {ESLVal $1347 = _v266.termRef(0);
        ESLVal $1346 = _v266.termRef(1);
        ESLVal $1345 = _v266.termRef(2);
        ESLVal $1344 = _v266.termRef(3);
        
        {ESLVal v0 = $1347;
        
        {ESLVal v1 = $1346;
        
        {ESLVal v2 = $1345;
        
        {ESLVal v3 = $1344;
        
        return v0;
      }
      }
      }
      }
      }
    case "CnstrBind": {ESLVal $1343 = _v266.termRef(0);
        ESLVal $1342 = _v266.termRef(1);
        ESLVal $1341 = _v266.termRef(2);
        ESLVal $1340 = _v266.termRef(3);
        
        {ESLVal v0 = $1343;
        
        {ESLVal v1 = $1342;
        
        {ESLVal v2 = $1341;
        
        {ESLVal v3 = $1340;
        
        return v0;
      }
      }
      }
      }
      }
    case "FunBind": {ESLVal $1339 = _v266.termRef(0);
        ESLVal $1338 = _v266.termRef(1);
        ESLVal $1337 = _v266.termRef(2);
        ESLVal $1336 = _v266.termRef(3);
        ESLVal $1335 = _v266.termRef(4);
        ESLVal $1334 = _v266.termRef(5);
        ESLVal $1333 = _v266.termRef(6);
        
        {ESLVal v0 = $1339;
        
        {ESLVal v1 = $1338;
        
        {ESLVal v2 = $1337;
        
        {ESLVal v3 = $1336;
        
        {ESLVal v4 = $1335;
        
        {ESLVal v5 = $1334;
        
        {ESLVal v6 = $1333;
        
        return v0;
      }
      }
      }
      }
      }
      }
      }
      }
    case "FunBinds": {ESLVal $1325 = _v266.termRef(0);
        ESLVal $1324 = _v266.termRef(1);
        
        if($1324.isCons())
        {ESLVal $1326 = $1324.head();
          ESLVal $1327 = $1324.tail();
          
          switch($1326.termName) {
          case "FunCase": {ESLVal $1332 = $1326.termRef(0);
            ESLVal $1331 = $1326.termRef(1);
            ESLVal $1330 = $1326.termRef(2);
            ESLVal $1329 = $1326.termRef(3);
            ESLVal $1328 = $1326.termRef(4);
            
            {ESLVal n = $1325;
            
            {ESLVal l = $1332;
            
            {ESLVal args = $1331;
            
            {ESLVal t = $1330;
            
            {ESLVal g = $1329;
            
            {ESLVal e = $1328;
            
            {ESLVal cases = $1327;
            
            return l;
          }
          }
          }
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(38589,38960)").add(ESLVal.list(_v266)));
        }
        }
      else if($1324.isNil())
        return error(new ESLVal("case error at Pos(38589,38960)").add(ESLVal.list(_v266)));
      else return error(new ESLVal("case error at Pos(38589,38960)").add(ESLVal.list(_v266)));
      }
    case "Binding": {ESLVal $1323 = _v266.termRef(0);
        ESLVal $1322 = _v266.termRef(1);
        ESLVal $1321 = _v266.termRef(2);
        ESLVal $1320 = _v266.termRef(3);
        ESLVal $1319 = _v266.termRef(4);
        
        {ESLVal v0 = $1323;
        
        {ESLVal v1 = $1322;
        
        {ESLVal v2 = $1321;
        
        {ESLVal v3 = $1320;
        
        {ESLVal v4 = $1319;
        
        return v0;
      }
      }
      }
      }
      }
      }
    case "DataBind": {ESLVal $1318 = _v266.termRef(0);
        ESLVal $1317 = _v266.termRef(1);
        ESLVal $1316 = _v266.termRef(2);
        ESLVal $1315 = _v266.termRef(3);
        
        {ESLVal v0 = $1318;
        
        {ESLVal v1 = $1317;
        
        {ESLVal v2 = $1316;
        
        {ESLVal v3 = $1315;
        
        return v0;
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(38589,38960)").add(ESLVal.list(_v266)));
    }
    }
  }
  public static ESLVal bindingLoc = new ESLVal(new Function(new ESLVal("bindingLoc"),null) { public ESLVal apply(ESLVal... args) { return bindingLoc(args[0]); }});
public static void main(String[] args) {
  }
}