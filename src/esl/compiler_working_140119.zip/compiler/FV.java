package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
import static esl.compiler.Types.*;
// import static esl.Lists.*;
import java.util.function.Supplier;
public class FV {
  public static ESLVal getSelf() { return $null; }
  
private static ESLVal remStr(ESLVal s,ESLVal ss) {
    
    return remove.apply(s,ss);
  }
  private static ESLVal remStr = new ESLVal(new Function(new ESLVal("remStr"),null) { public ESLVal apply(ESLVal... args) { return remStr(args[0],args[1]); }});
  private static ESLVal remStrs(ESLVal ss1,ESLVal ss2) {
    
    return removeAll.apply(ss1,ss2);
  }
  private static ESLVal remStrs = new ESLVal(new Function(new ESLVal("remStrs"),null) { public ESLVal apply(ESLVal... args) { return remStrs(args[0],args[1]); }});
  public static ESLVal bindingFV(ESLVal b) {
    
    {ESLVal _v1692 = b;
      
      switch(_v1692.termName) {
      case "TypeBind": {ESLVal $2844 = _v1692.termRef(0);
        ESLVal $2843 = _v1692.termRef(1);
        ESLVal $2842 = _v1692.termRef(2);
        ESLVal $2841 = _v1692.termRef(3);
        
        {ESLVal v0 = $2844;
        
        {ESLVal v1 = $2843;
        
        {ESLVal v2 = $2842;
        
        {ESLVal v3 = $2841;
        
        return $nil;
      }
      }
      }
      }
      }
    case "CnstrBind": {ESLVal $2840 = _v1692.termRef(0);
        ESLVal $2839 = _v1692.termRef(1);
        ESLVal $2838 = _v1692.termRef(2);
        ESLVal $2837 = _v1692.termRef(3);
        
        {ESLVal v0 = $2840;
        
        {ESLVal v1 = $2839;
        
        {ESLVal v2 = $2838;
        
        {ESLVal v3 = $2837;
        
        return $nil;
      }
      }
      }
      }
      }
    case "FunBind": {ESLVal $2836 = _v1692.termRef(0);
        ESLVal $2835 = _v1692.termRef(1);
        ESLVal $2834 = _v1692.termRef(2);
        ESLVal $2833 = _v1692.termRef(3);
        ESLVal $2832 = _v1692.termRef(4);
        ESLVal $2831 = _v1692.termRef(5);
        ESLVal $2830 = _v1692.termRef(6);
        
        {ESLVal v0 = $2836;
        
        {ESLVal v1 = $2835;
        
        {ESLVal v2 = $2834;
        
        {ESLVal v3 = $2833;
        
        {ESLVal v4 = $2832;
        
        {ESLVal body = $2831;
        
        {ESLVal guard = $2830;
        
        return remStrs(new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal p = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = patternNames.apply(p);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v2),freeVars(body));
      }
      }
      }
      }
      }
      }
      }
      }
    case "FunBinds": {ESLVal $2822 = _v1692.termRef(0);
        ESLVal $2821 = _v1692.termRef(1);
        
        if($2821.isCons())
        {ESLVal $2823 = $2821.head();
          ESLVal $2824 = $2821.tail();
          
          switch($2823.termName) {
          case "FunCase": {ESLVal $2829 = $2823.termRef(0);
            ESLVal $2828 = $2823.termRef(1);
            ESLVal $2827 = $2823.termRef(2);
            ESLVal $2826 = $2823.termRef(3);
            ESLVal $2825 = $2823.termRef(4);
            
            {ESLVal n = $2822;
            
            {ESLVal l = $2829;
            
            {ESLVal args = $2828;
            
            {ESLVal t = $2827;
            
            {ESLVal g = $2826;
            
            {ESLVal e = $2825;
            
            {ESLVal cases = $2824;
            
            return $nil;
          }
          }
          }
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(230,815)").add(ESLVal.list(_v1692)));
        }
        }
      else if($2821.isNil())
        return error(new ESLVal("case error at Pos(230,815)").add(ESLVal.list(_v1692)));
      else return error(new ESLVal("case error at Pos(230,815)").add(ESLVal.list(_v1692)));
      }
    case "Binding": {ESLVal $2820 = _v1692.termRef(0);
        ESLVal $2819 = _v1692.termRef(1);
        ESLVal $2818 = _v1692.termRef(2);
        ESLVal $2817 = _v1692.termRef(3);
        ESLVal $2816 = _v1692.termRef(4);
        
        {ESLVal v0 = $2820;
        
        {ESLVal v1 = $2819;
        
        {ESLVal v2 = $2818;
        
        {ESLVal v3 = $2817;
        
        {ESLVal v4 = $2816;
        
        return freeVars(v4);
      }
      }
      }
      }
      }
      }
    case "DataBind": {ESLVal $2815 = _v1692.termRef(0);
        ESLVal $2814 = _v1692.termRef(1);
        ESLVal $2813 = _v1692.termRef(2);
        ESLVal $2812 = _v1692.termRef(3);
        
        {ESLVal v0 = $2815;
        
        {ESLVal v1 = $2814;
        
        {ESLVal v2 = $2813;
        
        {ESLVal v3 = $2812;
        
        return $nil;
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(230,815)").add(ESLVal.list(_v1692)));
    }
    }
  }
  public static ESLVal bindingFV = new ESLVal(new Function(new ESLVal("bindingFV"),null) { public ESLVal apply(ESLVal... args) { return bindingFV(args[0]); }});
  private static ESLVal armFV(ESLVal a) {
    
    {ESLVal _v1693 = a;
      
      switch(_v1693.termName) {
      case "BArm": {ESLVal $2848 = _v1693.termRef(0);
        ESLVal $2847 = _v1693.termRef(1);
        ESLVal $2846 = _v1693.termRef(2);
        ESLVal $2845 = _v1693.termRef(3);
        
        {ESLVal l = $2848;
        
        {ESLVal ps = $2847;
        
        {ESLVal g = $2846;
        
        {ESLVal e = $2845;
        
        {ESLVal bound = new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal p = $l0.head();
                $l0 = $l0.tail();
                ESLVal $l1 = patternNames.apply(p);
          while(!$l1.isNil()) {
            ESLVal n = $l1.head();
            $l1 = $l1.tail();
            $v.add(n);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(ps);
        
        return remStrs(bound,freeVars(g).add(freeVars(e)));
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(842,993)").add(ESLVal.list(_v1693)));
    }
    }
  }
  private static ESLVal armFV = new ESLVal(new Function(new ESLVal("armFV"),null) { public ESLVal apply(ESLVal... args) { return armFV(args[0]); }});
  public static ESLVal freeVars(ESLVal e) {
    
    {ESLVal _v1694 = e;
      
      switch(_v1694.termName) {
      case "ActExp": {ESLVal $3000 = _v1694.termRef(0);
        ESLVal $2999 = _v1694.termRef(1);
        ESLVal $2998 = _v1694.termRef(2);
        ESLVal $2997 = _v1694.termRef(3);
        ESLVal $2996 = _v1694.termRef(4);
        ESLVal $2995 = _v1694.termRef(5);
        ESLVal $2994 = _v1694.termRef(6);
        ESLVal $2993 = _v1694.termRef(7);
        
        {ESLVal l = $3000;
        
        {ESLVal name = $2999;
        
        {ESLVal args = $2998;
        
        {ESLVal exports = $2997;
        
        {ESLVal parent = $2996;
        
        {ESLVal bindings = $2995;
        
        {ESLVal init = $2994;
        
        {ESLVal handlers = $2993;
        
        {ESLVal outerBoundVars = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1697 = $qualArg;
                
                switch(_v1697.termName) {
                case "Dec": {ESLVal $3010 = _v1697.termRef(0);
                  ESLVal $3009 = _v1697.termRef(1);
                  ESLVal $3008 = _v1697.termRef(2);
                  ESLVal $3007 = _v1697.termRef(3);
                  
                  {ESLVal _v1702 = $3010;
                  
                  {ESLVal n = $3009;
                  
                  {ESLVal t = $3008;
                  
                  {ESLVal dt = $3007;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                }
                default: {ESLVal _0 = _v1697;
                  
                  return $nil;
                }
              }
              }
            }
          }).map(args).flatten().flatten();
        ESLVal innerBoundVars = new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal b = $l0.head();
                $l0 = $l0.tail();
                $v.add(bindingName.apply(b));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(bindings);
        ESLVal bindingFV = new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal b = $l0.head();
                $l0 = $l0.tail();
                ESLVal $l1 = bindingFV(b);
          while(!$l1.isNil()) {
            ESLVal n = $l1.head();
            $l1 = $l1.tail();
            $v.add(n);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(bindings);
        ESLVal handlerFV = new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal a = $l0.head();
                $l0 = $l0.tail();
                ESLVal $l1 = armFV(a);
          while(!$l1.isNil()) {
            ESLVal n = $l1.head();
            $l1 = $l1.tail();
            $v.add(n);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(handlers);
        ESLVal parentFV = ((Supplier<ESLVal>)() -> { 
            if(parent.eql($null).boolVal)
              return $nil;
              else
                return freeVars(parent);
          }).get();
        
        return remStrs(outerBoundVars,freeVars(name).add(parentFV.add(freeVars(init)))).add(remStrs(outerBoundVars.add(innerBoundVars),bindingFV.add(handlerFV)));
      }
      }
      }
      }
      }
      }
      }
      }
      }
      }
    case "Apply": {ESLVal $2992 = _v1694.termRef(0);
        ESLVal $2991 = _v1694.termRef(1);
        ESLVal $2990 = _v1694.termRef(2);
        
        {ESLVal v0 = $2992;
        
        {ESLVal v1 = $2991;
        
        {ESLVal v2 = $2990;
        
        return freeVars(v1).add(new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = freeVars(e);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v2));
      }
      }
      }
      }
    case "ApplyTypeExp": {ESLVal $2989 = _v1694.termRef(0);
        ESLVal $2988 = _v1694.termRef(1);
        ESLVal $2987 = _v1694.termRef(2);
        
        {ESLVal v0 = $2989;
        
        {ESLVal v1 = $2988;
        
        {ESLVal v2 = $2987;
        
        return freeVars(v1);
      }
      }
      }
      }
    case "ArrayRef": {ESLVal $2986 = _v1694.termRef(0);
        ESLVal $2985 = _v1694.termRef(1);
        ESLVal $2984 = _v1694.termRef(2);
        
        {ESLVal v0 = $2986;
        
        {ESLVal v1 = $2985;
        
        {ESLVal v2 = $2984;
        
        return freeVars(v1).add(freeVars(v2));
      }
      }
      }
      }
    case "ArrayUpdate": {ESLVal $2983 = _v1694.termRef(0);
        ESLVal $2982 = _v1694.termRef(1);
        ESLVal $2981 = _v1694.termRef(2);
        ESLVal $2980 = _v1694.termRef(3);
        
        {ESLVal v0 = $2983;
        
        {ESLVal v1 = $2982;
        
        {ESLVal v2 = $2981;
        
        {ESLVal v3 = $2980;
        
        return freeVars(v1).add(freeVars(v2).add(freeVars(v3)));
      }
      }
      }
      }
      }
    case "BagExp": {ESLVal $2979 = _v1694.termRef(0);
        ESLVal $2978 = _v1694.termRef(1);
        
        {ESLVal v0 = $2979;
        
        {ESLVal v1 = $2978;
        
        return new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = freeVars(e);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1);
      }
      }
      }
    case "Become": {ESLVal $2977 = _v1694.termRef(0);
        ESLVal $2976 = _v1694.termRef(1);
        
        {ESLVal v0 = $2977;
        
        {ESLVal v1 = $2976;
        
        return freeVars(v1);
      }
      }
      }
    case "BinExp": {ESLVal $2975 = _v1694.termRef(0);
        ESLVal $2974 = _v1694.termRef(1);
        ESLVal $2973 = _v1694.termRef(2);
        ESLVal $2972 = _v1694.termRef(3);
        
        {ESLVal v0 = $2975;
        
        {ESLVal v1 = $2974;
        
        {ESLVal v2 = $2973;
        
        {ESLVal v3 = $2972;
        
        return freeVars(v1).add(freeVars(v3));
      }
      }
      }
      }
      }
    case "Block": {ESLVal $2971 = _v1694.termRef(0);
        ESLVal $2970 = _v1694.termRef(1);
        
        {ESLVal v0 = $2971;
        
        {ESLVal v1 = $2970;
        
        return new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = freeVars(e);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1);
      }
      }
      }
    case "BoolExp": {ESLVal $2969 = _v1694.termRef(0);
        ESLVal $2968 = _v1694.termRef(1);
        
        {ESLVal v0 = $2969;
        
        {ESLVal v1 = $2968;
        
        return $nil;
      }
      }
      }
    case "Case": {ESLVal $2967 = _v1694.termRef(0);
        ESLVal $2966 = _v1694.termRef(1);
        ESLVal $2965 = _v1694.termRef(2);
        ESLVal $2964 = _v1694.termRef(3);
        
        {ESLVal v0 = $2967;
        
        {ESLVal v1 = $2966;
        
        {ESLVal v2 = $2965;
        
        {ESLVal v3 = $2964;
        
        return new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = freeVars(e);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v2).add(new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal a = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = armFV(a);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v3));
      }
      }
      }
      }
      }
    case "Cmp": {ESLVal $2956 = _v1694.termRef(0);
        ESLVal $2955 = _v1694.termRef(1);
        ESLVal $2954 = _v1694.termRef(2);
        
        if($2954.isCons())
        {ESLVal $2957 = $2954.head();
          ESLVal $2958 = $2954.tail();
          
          switch($2957.termName) {
          case "BQual": {ESLVal $2963 = $2957.termRef(0);
            ESLVal $2962 = $2957.termRef(1);
            ESLVal $2961 = $2957.termRef(2);
            
            {ESLVal l = $2956;
            
            {ESLVal _v1700 = $2955;
            
            {ESLVal ql = $2963;
            
            {ESLVal qp = $2962;
            
            {ESLVal qe = $2961;
            
            {ESLVal qs = $2958;
            
            return freeVars(qe).add(remStrs(patternNames.apply(qp),freeVars(new ESLVal("Cmp",l,_v1700,qs))));
          }
          }
          }
          }
          }
          }
          }
        case "PQual": {ESLVal $2960 = $2957.termRef(0);
            ESLVal $2959 = $2957.termRef(1);
            
            {ESLVal l = $2956;
            
            {ESLVal _v1699 = $2955;
            
            {ESLVal ql = $2960;
            
            {ESLVal qe = $2959;
            
            {ESLVal qs = $2958;
            
            return freeVars(qe).add(freeVars(new ESLVal("Cmp",l,_v1699,qs)));
          }
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(1025,6155)").add(ESLVal.list(_v1694)));
        }
        }
      else if($2954.isNil())
        {ESLVal l = $2956;
          
          {ESLVal _v1701 = $2955;
          
          return freeVars(_v1701);
        }
        }
      else return error(new ESLVal("case error at Pos(1025,6155)").add(ESLVal.list(_v1694)));
      }
    case "Cons": {ESLVal $2953 = _v1694.termRef(0);
        ESLVal $2952 = _v1694.termRef(1);
        
        {ESLVal v0 = $2953;
        
        {ESLVal v1 = $2952;
        
        return freeVars(v0).add(freeVars(v1));
      }
      }
      }
    case "For": {ESLVal $2951 = _v1694.termRef(0);
        ESLVal $2950 = _v1694.termRef(1);
        ESLVal $2949 = _v1694.termRef(2);
        ESLVal $2948 = _v1694.termRef(3);
        
        {ESLVal v0 = $2951;
        
        {ESLVal v1 = $2950;
        
        {ESLVal v2 = $2949;
        
        {ESLVal v3 = $2948;
        
        return freeVars(v2).add(remStrs(patternNames.apply(v1),freeVars(v3)));
      }
      }
      }
      }
      }
    case "FunExp": {ESLVal $2947 = _v1694.termRef(0);
        ESLVal $2946 = _v1694.termRef(1);
        ESLVal $2945 = _v1694.termRef(2);
        ESLVal $2944 = _v1694.termRef(3);
        ESLVal $2943 = _v1694.termRef(4);
        
        {ESLVal v0 = $2947;
        
        {ESLVal v1 = $2946;
        
        {ESLVal v2 = $2945;
        
        {ESLVal v3 = $2944;
        
        {ESLVal v4 = $2943;
        
        return remStrs(new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v1696 = $qualArg;
              
              switch(_v1696.termName) {
              case "Dec": {ESLVal $3006 = _v1696.termRef(0);
                ESLVal $3005 = _v1696.termRef(1);
                ESLVal $3004 = _v1696.termRef(2);
                ESLVal $3003 = _v1696.termRef(3);
                
                {ESLVal l = $3006;
                
                {ESLVal n = $3005;
                
                {ESLVal t = $3004;
                
                {ESLVal dt = $3003;
                
                return ESLVal.list(ESLVal.list(n));
              }
              }
              }
              }
              }
              default: {ESLVal _0 = _v1696;
                
                return $nil;
              }
            }
            }
          }
        }).map(v2).flatten().flatten(),freeVars(v1).add(freeVars(v4)));
      }
      }
      }
      }
      }
      }
    case "Grab": {ESLVal $2942 = _v1694.termRef(0);
        ESLVal $2941 = _v1694.termRef(1);
        ESLVal $2940 = _v1694.termRef(2);
        
        {ESLVal v0 = $2942;
        
        {ESLVal v1 = $2941;
        
        {ESLVal v2 = $2940;
        
        return new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v1695 = $qualArg;
              
              switch(_v1695.termName) {
              case "VarDynamicRef": {ESLVal $3002 = _v1695.termRef(0);
                ESLVal $3001 = _v1695.termRef(1);
                
                {ESLVal l = $3002;
                
                {ESLVal _v1698 = $3001;
                
                return ESLVal.list(new java.util.function.Function<ESLVal,ESLVal>() {
                  public ESLVal apply(ESLVal $l0) {
                    ESLVal $a = $nil;
                    java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                    while(!$l0.isNil()) { 
                      ESLVal n = $l0.head();
                      $l0 = $l0.tail();
                      $v.add(n);
                    }
                    for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                    return $a;
                  }}.apply(freeVars(_v1698)));
              }
              }
              }
              default: {ESLVal _0 = _v1695;
                
                return $nil;
              }
            }
            }
          }
        }).map(v1).flatten().flatten().add(freeVars(v2));
      }
      }
      }
      }
    case "If": {ESLVal $2939 = _v1694.termRef(0);
        ESLVal $2938 = _v1694.termRef(1);
        ESLVal $2937 = _v1694.termRef(2);
        ESLVal $2936 = _v1694.termRef(3);
        
        {ESLVal v0 = $2939;
        
        {ESLVal v1 = $2938;
        
        {ESLVal v2 = $2937;
        
        {ESLVal v3 = $2936;
        
        return freeVars(v1).add(freeVars(v2).add(freeVars(v3)));
      }
      }
      }
      }
      }
    case "IntExp": {ESLVal $2935 = _v1694.termRef(0);
        ESLVal $2934 = _v1694.termRef(1);
        
        {ESLVal v0 = $2935;
        
        {ESLVal v1 = $2934;
        
        return $nil;
      }
      }
      }
    case "FloatExp": {ESLVal $2933 = _v1694.termRef(0);
        ESLVal $2932 = _v1694.termRef(1);
        
        {ESLVal v0 = $2933;
        
        {ESLVal v1 = $2932;
        
        return $nil;
      }
      }
      }
    case "Fold": {ESLVal $2931 = _v1694.termRef(0);
        ESLVal $2930 = _v1694.termRef(1);
        ESLVal $2929 = _v1694.termRef(2);
        
        {ESLVal v0 = $2931;
        
        {ESLVal v1 = $2930;
        
        {ESLVal v2 = $2929;
        
        return freeVars(v2);
      }
      }
      }
      }
    case "Head": {ESLVal $2928 = _v1694.termRef(0);
        
        {ESLVal v0 = $2928;
        
        return freeVars(v0);
      }
      }
    case "Let": {ESLVal $2927 = _v1694.termRef(0);
        ESLVal $2926 = _v1694.termRef(1);
        ESLVal $2925 = _v1694.termRef(2);
        
        {ESLVal v0 = $2927;
        
        {ESLVal v1 = $2926;
        
        {ESLVal v2 = $2925;
        
        return new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = bindingFV(b);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1).add(remStrs(new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              $v.add(bindingName.apply(b));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1),freeVars(v2)));
      }
      }
      }
      }
    case "Letrec": {ESLVal $2924 = _v1694.termRef(0);
        ESLVal $2923 = _v1694.termRef(1);
        ESLVal $2922 = _v1694.termRef(2);
        
        {ESLVal v0 = $2924;
        
        {ESLVal v1 = $2923;
        
        {ESLVal v2 = $2922;
        
        return remStrs(new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              $v.add(bindingName.apply(b));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = bindingFV(b);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1).add(freeVars(v2)));
      }
      }
      }
      }
    case "List": {ESLVal $2921 = _v1694.termRef(0);
        ESLVal $2920 = _v1694.termRef(1);
        
        {ESLVal v0 = $2921;
        
        {ESLVal v1 = $2920;
        
        return new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = freeVars(e);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1);
      }
      }
      }
    case "Module": {ESLVal $2919 = _v1694.termRef(0);
        ESLVal $2918 = _v1694.termRef(1);
        ESLVal $2917 = _v1694.termRef(2);
        ESLVal $2916 = _v1694.termRef(3);
        ESLVal $2915 = _v1694.termRef(4);
        ESLVal $2914 = _v1694.termRef(5);
        ESLVal $2913 = _v1694.termRef(6);
        
        {ESLVal v0 = $2919;
        
        {ESLVal v1 = $2918;
        
        {ESLVal v2 = $2917;
        
        {ESLVal v3 = $2916;
        
        {ESLVal v4 = $2915;
        
        {ESLVal v5 = $2914;
        
        {ESLVal v6 = $2913;
        
        return remStrs(new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              $v.add(bindingName.apply(b));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v6),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = bindingFV(b);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v6));
      }
      }
      }
      }
      }
      }
      }
      }
    case "New": {ESLVal $2912 = _v1694.termRef(0);
        ESLVal $2911 = _v1694.termRef(1);
        ESLVal $2910 = _v1694.termRef(2);
        
        {ESLVal v0 = $2912;
        
        {ESLVal v1 = $2911;
        
        {ESLVal v2 = $2910;
        
        return freeVars(v1).add(new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = freeVars(e);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v2));
      }
      }
      }
      }
    case "NewArray": {ESLVal $2909 = _v1694.termRef(0);
        ESLVal $2908 = _v1694.termRef(1);
        ESLVal $2907 = _v1694.termRef(2);
        
        {ESLVal v0 = $2909;
        
        {ESLVal v1 = $2908;
        
        {ESLVal v2 = $2907;
        
        return freeVars(v2);
      }
      }
      }
      }
    case "NewJava": {ESLVal $2906 = _v1694.termRef(0);
        ESLVal $2905 = _v1694.termRef(1);
        ESLVal $2904 = _v1694.termRef(2);
        ESLVal $2903 = _v1694.termRef(3);
        
        {ESLVal v0 = $2906;
        
        {ESLVal v1 = $2905;
        
        {ESLVal v2 = $2904;
        
        {ESLVal v3 = $2903;
        
        return new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = freeVars(e);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v3);
      }
      }
      }
      }
      }
    case "NewTable": {ESLVal $2902 = _v1694.termRef(0);
        ESLVal $2901 = _v1694.termRef(1);
        ESLVal $2900 = _v1694.termRef(2);
        
        {ESLVal v0 = $2902;
        
        {ESLVal v1 = $2901;
        
        {ESLVal v2 = $2900;
        
        return $nil;
      }
      }
      }
      }
    case "Not": {ESLVal $2899 = _v1694.termRef(0);
        ESLVal $2898 = _v1694.termRef(1);
        
        {ESLVal v0 = $2899;
        
        {ESLVal v1 = $2898;
        
        return freeVars(v1);
      }
      }
      }
    case "Now": {ESLVal $2897 = _v1694.termRef(0);
        
        {ESLVal v0 = $2897;
        
        return $nil;
      }
      }
    case "NullExp": {ESLVal $2896 = _v1694.termRef(0);
        
        {ESLVal v0 = $2896;
        
        return $nil;
      }
      }
    case "PLet": {ESLVal $2895 = _v1694.termRef(0);
        ESLVal $2894 = _v1694.termRef(1);
        ESLVal $2893 = _v1694.termRef(2);
        
        {ESLVal v0 = $2895;
        
        {ESLVal v1 = $2894;
        
        {ESLVal v2 = $2893;
        
        return new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = bindingFV(b);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1).add(remStrs(new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              $v.add(bindingName.apply(b));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1),freeVars(v2)));
      }
      }
      }
      }
    case "Probably": {ESLVal $2892 = _v1694.termRef(0);
        ESLVal $2891 = _v1694.termRef(1);
        ESLVal $2890 = _v1694.termRef(2);
        ESLVal $2889 = _v1694.termRef(3);
        ESLVal $2888 = _v1694.termRef(4);
        
        {ESLVal v0 = $2892;
        
        {ESLVal v1 = $2891;
        
        {ESLVal v2 = $2890;
        
        {ESLVal v3 = $2889;
        
        {ESLVal v4 = $2888;
        
        return freeVars(v1).add(freeVars(v3).add(freeVars(v4)));
      }
      }
      }
      }
      }
      }
    case "Record": {ESLVal $2887 = _v1694.termRef(0);
        ESLVal $2886 = _v1694.termRef(1);
        
        {ESLVal v0 = $2887;
        
        {ESLVal v1 = $2886;
        
        return new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = bindingFV(b);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1);
      }
      }
      }
    case "RefSuper": {ESLVal $2885 = _v1694.termRef(0);
        ESLVal $2884 = _v1694.termRef(1);
        
        {ESLVal v0 = $2885;
        
        {ESLVal v1 = $2884;
        
        return $nil;
      }
      }
      }
    case "Ref": {ESLVal $2883 = _v1694.termRef(0);
        ESLVal $2882 = _v1694.termRef(1);
        ESLVal $2881 = _v1694.termRef(2);
        
        {ESLVal v0 = $2883;
        
        {ESLVal v1 = $2882;
        
        {ESLVal v2 = $2881;
        
        return freeVars(v1);
      }
      }
      }
      }
    case "Self": {ESLVal $2880 = _v1694.termRef(0);
        
        {ESLVal v0 = $2880;
        
        return $nil;
      }
      }
    case "Send": {ESLVal $2879 = _v1694.termRef(0);
        ESLVal $2878 = _v1694.termRef(1);
        ESLVal $2877 = _v1694.termRef(2);
        
        {ESLVal v0 = $2879;
        
        {ESLVal v1 = $2878;
        
        {ESLVal v2 = $2877;
        
        return freeVars(v1).add(freeVars(v2));
      }
      }
      }
      }
    case "SendSuper": {ESLVal $2876 = _v1694.termRef(0);
        ESLVal $2875 = _v1694.termRef(1);
        
        {ESLVal v0 = $2876;
        
        {ESLVal v1 = $2875;
        
        return freeVars(v1);
      }
      }
      }
    case "SendTimeSuper": {ESLVal $2874 = _v1694.termRef(0);
        
        {ESLVal v0 = $2874;
        
        return $nil;
      }
      }
    case "SetExp": {ESLVal $2873 = _v1694.termRef(0);
        ESLVal $2872 = _v1694.termRef(1);
        
        {ESLVal v0 = $2873;
        
        {ESLVal v1 = $2872;
        
        return new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = freeVars(e);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1);
      }
      }
      }
    case "StrExp": {ESLVal $2871 = _v1694.termRef(0);
        ESLVal $2870 = _v1694.termRef(1);
        
        {ESLVal v0 = $2871;
        
        {ESLVal v1 = $2870;
        
        return $nil;
      }
      }
      }
    case "Tail": {ESLVal $2869 = _v1694.termRef(0);
        
        {ESLVal v0 = $2869;
        
        return freeVars(v0);
      }
      }
    case "Term": {ESLVal $2868 = _v1694.termRef(0);
        ESLVal $2867 = _v1694.termRef(1);
        ESLVal $2866 = _v1694.termRef(2);
        ESLVal $2865 = _v1694.termRef(3);
        
        {ESLVal v0 = $2868;
        
        {ESLVal v1 = $2867;
        
        {ESLVal v2 = $2866;
        
        {ESLVal v3 = $2865;
        
        return new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = freeVars(e);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v3);
      }
      }
      }
      }
      }
    case "TermRef": {ESLVal $2864 = _v1694.termRef(0);
        ESLVal $2863 = _v1694.termRef(1);
        
        {ESLVal v0 = $2864;
        
        {ESLVal v1 = $2863;
        
        return freeVars(v0);
      }
      }
      }
    case "Throw": {ESLVal $2862 = _v1694.termRef(0);
        ESLVal $2861 = _v1694.termRef(1);
        ESLVal $2860 = _v1694.termRef(2);
        
        {ESLVal v0 = $2862;
        
        {ESLVal v1 = $2861;
        
        {ESLVal v2 = $2860;
        
        return freeVars(v2);
      }
      }
      }
      }
    case "Try": {ESLVal $2859 = _v1694.termRef(0);
        ESLVal $2858 = _v1694.termRef(1);
        ESLVal $2857 = _v1694.termRef(2);
        
        {ESLVal v0 = $2859;
        
        {ESLVal v1 = $2858;
        
        {ESLVal v2 = $2857;
        
        return freeVars(v1).add(new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal a = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = armFV(a);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v2));
      }
      }
      }
      }
    case "Update": {ESLVal $2856 = _v1694.termRef(0);
        ESLVal $2855 = _v1694.termRef(1);
        ESLVal $2854 = _v1694.termRef(2);
        
        {ESLVal v0 = $2856;
        
        {ESLVal v1 = $2855;
        
        {ESLVal v2 = $2854;
        
        return ESLVal.list(v1).add(freeVars(v2));
      }
      }
      }
      }
    case "Unfold": {ESLVal $2853 = _v1694.termRef(0);
        ESLVal $2852 = _v1694.termRef(1);
        ESLVal $2851 = _v1694.termRef(2);
        
        {ESLVal v0 = $2853;
        
        {ESLVal v1 = $2852;
        
        {ESLVal v2 = $2851;
        
        return freeVars(v2);
      }
      }
      }
      }
    case "Var": {ESLVal $2850 = _v1694.termRef(0);
        ESLVal $2849 = _v1694.termRef(1);
        
        {ESLVal v0 = $2850;
        
        {ESLVal v1 = $2849;
        
        return ESLVal.list(v1);
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(1025,6155)").add(ESLVal.list(_v1694)));
    }
    }
  }
  public static ESLVal freeVars = new ESLVal(new Function(new ESLVal("freeVars"),null) { public ESLVal apply(ESLVal... args) { return freeVars(args[0]); }});
public static void main(String[] args) {
  }
}