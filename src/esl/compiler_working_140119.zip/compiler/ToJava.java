package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
import static esl.Tables.*;
// import static esl.Lists.*;
import static esl.compiler.Cases.*;
import static esl.compiler.Types.*;
import static esl.compiler.Info.*;
import java.util.function.Supplier;
public class ToJava {
  public static ESLVal getSelf() { return $null; }
  private static ESLVal addObserverJField = new ESLVal("JField",new ESLVal("addObserver"),$null,new ESLVal("JFun",new ESLVal("JConstExp",new ESLVal("JConstStr",new ESLVal("addObserver"))),ESLVal.list(new ESLVal("JDec",new ESLVal("o"),$null)),$null,new ESLVal("JBlock",ESLVal.list(new ESLVal("JUpdate",new ESLVal("$observers"),new ESLVal("JBinExp",new ESLVal("JVar",new ESLVal("o"),$null),new ESLVal("cons"),new ESLVal("JVar",new ESLVal("$observers"),$null))),new ESLVal("JReturn",new ESLVal("JSend",new ESLVal("JVar",new ESLVal("o"),$null),new ESLVal("Start"),ESLVal.list(new ESLVal("JSelf",new ESLVal[]{}),new ESLVal("JNow",new ESLVal[]{}),new ESLVal("JApply",new ESLVal("JVar",new ESLVal("observeState"),$null),$nil))))))));
  private static ESLVal nameCount = $zero;
  public static ESLVal main = new ESLVal(new Function(new ESLVal("main"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      return new ESLVal(new BehaviourAdapter(true,getSelf(),new ESLVal("main")) {
          

          public ESLVal handle(ESLVal $m) {{ESLVal _v1757 = $m;
            
            return error(new ESLVal("case error at Pos(0,0)").add(ESLVal.list(_v1757)));
          }}
          public ESLVal get(String name) {
            switch(name) {
              
              default: throw new Error("ref illegal " + self + "." + name);
            }
          }
        public void handleTime(ESLVal $t) {
          {ESLVal n = $t;
            
            if($true.boolVal)
            {print.apply(new ESLVal("").add(emptyTable));
            stopAll.apply();}
            else
              {}
          }
        }
        public ESLVal init() {
            return $null;
          }
        });
    }
  });
private static ESLVal defToField(ESLVal d) {
    
    {ESLVal _v1704 = d;
      
      switch(_v1704.termName) {
      case "Binding": {ESLVal $3024 = _v1704.termRef(0);
        ESLVal $3023 = _v1704.termRef(1);
        ESLVal $3022 = _v1704.termRef(2);
        ESLVal $3021 = _v1704.termRef(3);
        ESLVal $3020 = _v1704.termRef(4);
        
        {ESLVal l = $3024;
        
        {ESLVal n = $3023;
        
        {ESLVal t = $3022;
        
        {ESLVal st = $3021;
        
        {ESLVal e = $3020;
        
        return new ESLVal("JField",n,$null,expToJExp(e));
      }
      }
      }
      }
      }
      }
    case "FunBind": {ESLVal $3017 = _v1704.termRef(0);
        ESLVal $3016 = _v1704.termRef(1);
        ESLVal $3015 = _v1704.termRef(2);
        ESLVal $3014 = _v1704.termRef(3);
        ESLVal $3013 = _v1704.termRef(4);
        ESLVal $3012 = _v1704.termRef(5);
        ESLVal $3011 = _v1704.termRef(6);
        
        switch($3011.termName) {
        case "BoolExp": {ESLVal $3019 = $3011.termRef(0);
          ESLVal $3018 = $3011.termRef(1);
          
          switch($3018.boolVal ? 1 : 0) {
          case 1: {ESLVal l = $3017;
            
            {ESLVal n = $3016;
            
            {ESLVal args = $3015;
            
            {ESLVal t = $3014;
            
            {ESLVal st = $3013;
            
            {ESLVal e = $3012;
            
            {ESLVal bl = $3019;
            
            {ESLVal formals = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v1705 = $qualArg;
                    
                    switch(_v1705.termName) {
                    case "PVar": {ESLVal $3027 = _v1705.termRef(0);
                      ESLVal $3026 = _v1705.termRef(1);
                      ESLVal $3025 = _v1705.termRef(2);
                      
                      {ESLVal _v1865 = $3027;
                      
                      {ESLVal _v1866 = $3026;
                      
                      {ESLVal _v1867 = $3025;
                      
                      return ESLVal.list(ESLVal.list(new ESLVal("Dec",_v1865,_v1866,_v1867,st)));
                    }
                    }
                    }
                    }
                    default: {ESLVal _0 = _v1705;
                      
                      return $nil;
                    }
                  }
                  }
                }
              }).map(args).flatten().flatten();
            
            return new ESLVal("JField",n,$null,expToJExp(new ESLVal("FunExp",l,new ESLVal("StrExp",l,n),formals,t,e)));
          }
          }
          }
          }
          }
          }
          }
          }
          default: {ESLVal l = $3017;
            
            {ESLVal n = $3016;
            
            {ESLVal args = $3015;
            
            {ESLVal t = $3014;
            
            {ESLVal st = $3013;
            
            {ESLVal e = $3012;
            
            {ESLVal g = $3011;
            
            {ESLVal formals = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v1706 = $qualArg;
                    
                    switch(_v1706.termName) {
                    case "PVar": {ESLVal $3030 = _v1706.termRef(0);
                      ESLVal $3029 = _v1706.termRef(1);
                      ESLVal $3028 = _v1706.termRef(2);
                      
                      {ESLVal _v1868 = $3030;
                      
                      {ESLVal _v1869 = $3029;
                      
                      {ESLVal _v1870 = $3028;
                      
                      return ESLVal.list(ESLVal.list(new ESLVal("Dec",_v1868,_v1869,_v1870,st)));
                    }
                    }
                    }
                    }
                    default: {ESLVal _0 = _v1706;
                      
                      return $nil;
                    }
                  }
                  }
                }
              }).map(args).flatten().flatten();
            
            return new ESLVal("JField",n,$null,expToJExp(new ESLVal("FunExp",l,new ESLVal("StrExp",l,n),formals,t,new ESLVal("If",l,g,e,new ESLVal("Throw",l,t,new ESLVal("StrExp",l,new ESLVal("guard failed for ").add(n)))))));
          }
          }
          }
          }
          }
          }
          }
          }
        }
        }
        default: {ESLVal l = $3017;
          
          {ESLVal n = $3016;
          
          {ESLVal args = $3015;
          
          {ESLVal t = $3014;
          
          {ESLVal st = $3013;
          
          {ESLVal e = $3012;
          
          {ESLVal g = $3011;
          
          {ESLVal formals = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v1707 = $qualArg;
                  
                  switch(_v1707.termName) {
                  case "PVar": {ESLVal $3033 = _v1707.termRef(0);
                    ESLVal $3032 = _v1707.termRef(1);
                    ESLVal $3031 = _v1707.termRef(2);
                    
                    {ESLVal _v1871 = $3033;
                    
                    {ESLVal _v1872 = $3032;
                    
                    {ESLVal _v1873 = $3031;
                    
                    return ESLVal.list(ESLVal.list(new ESLVal("Dec",_v1871,_v1872,_v1873,st)));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v1707;
                    
                    return $nil;
                  }
                }
                }
              }
            }).map(args).flatten().flatten();
          
          return new ESLVal("JField",n,$null,expToJExp(new ESLVal("FunExp",l,new ESLVal("StrExp",l,n),formals,t,new ESLVal("If",l,g,e,new ESLVal("Throw",l,t,new ESLVal("StrExp",l,new ESLVal("guard failed for ").add(n)))))));
        }
        }
        }
        }
        }
        }
        }
        }
      }
      }
      default: {ESLVal _v1874 = _v1704;
        
        return error(new ESLVal("unexpected definition to translate to Java: ").add(_v1874));
      }
    }
    }
  }
  private static ESLVal defToField = new ESLVal(new Function(new ESLVal("defToField"),null) { public ESLVal apply(ESLVal... args) { return defToField(args[0]); }});
  private static ESLVal defToMethod(ESLVal d) {
    
    {ESLVal _v1708 = d;
      
      switch(_v1708.termName) {
      case "FunBind": {ESLVal $3040 = _v1708.termRef(0);
        ESLVal $3039 = _v1708.termRef(1);
        ESLVal $3038 = _v1708.termRef(2);
        ESLVal $3037 = _v1708.termRef(3);
        ESLVal $3036 = _v1708.termRef(4);
        ESLVal $3035 = _v1708.termRef(5);
        ESLVal $3034 = _v1708.termRef(6);
        
        {ESLVal l = $3040;
        
        {ESLVal n = $3039;
        
        {ESLVal args = $3038;
        
        {ESLVal t = $3037;
        
        {ESLVal st = $3036;
        
        {ESLVal body = $3035;
        
        {ESLVal guard = $3034;
        
        {ESLVal formals = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1709 = $qualArg;
                
                switch(_v1709.termName) {
                case "PVar": {ESLVal $3043 = _v1709.termRef(0);
                  ESLVal $3042 = _v1709.termRef(1);
                  ESLVal $3041 = _v1709.termRef(2);
                  
                  {ESLVal _v1861 = $3043;
                  
                  {ESLVal _v1862 = $3042;
                  
                  {ESLVal _v1863 = $3041;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JDec",_v1862,$null)));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1709;
                  
                  return $nil;
                }
              }
              }
            }
          }).map(args).flatten().flatten();
        
        return new ESLVal("JMethod",n,formals,expToJCommand(body,$true));
      }
      }
      }
      }
      }
      }
      }
      }
      }
      default: {ESLVal _v1864 = _v1708;
        
        return error(new ESLVal("cannot transform definition ").add(_v1864.add(new ESLVal(" to a method"))));
      }
    }
    }
  }
  private static ESLVal defToMethod = new ESLVal(new Function(new ESLVal("defToMethod"),null) { public ESLVal apply(ESLVal... args) { return defToMethod(args[0]); }});
  private static ESLVal decToJDec(ESLVal d) {
    
    {ESLVal _v1710 = d;
      
      switch(_v1710.termName) {
      case "Dec": {ESLVal $3047 = _v1710.termRef(0);
        ESLVal $3046 = _v1710.termRef(1);
        ESLVal $3045 = _v1710.termRef(2);
        ESLVal $3044 = _v1710.termRef(3);
        
        {ESLVal l = $3047;
        
        {ESLVal n = $3046;
        
        {ESLVal t = $3045;
        
        {ESLVal st = $3044;
        
        return new ESLVal("JDec",n,$null);
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(2614,2690)").add(ESLVal.list(_v1710)));
    }
    }
  }
  private static ESLVal decToJDec = new ESLVal(new Function(new ESLVal("decToJDec"),null) { public ESLVal apply(ESLVal... args) { return decToJDec(args[0]); }});
  private static ESLVal expsToJCommands(ESLVal cs,ESLVal isLast) {
    
    {ESLVal _v1711 = cs;
      
      if(_v1711.isCons())
      {ESLVal $3048 = _v1711.head();
        ESLVal $3049 = _v1711.tail();
        
        if($3049.isCons())
        {ESLVal $3050 = $3049.head();
          ESLVal $3051 = $3049.tail();
          
          {ESLVal c = $3048;
          
          {ESLVal _v1859 = $3049;
          
          return expsToJCommands(_v1859,isLast).cons(expToJCommand(c,$false));
        }
        }
        }
      else if($3049.isNil())
        {ESLVal c = $3048;
          
          return ESLVal.list(expToJCommand(c,isLast));
        }
      else {ESLVal c = $3048;
          
          {ESLVal _v1860 = $3049;
          
          return expsToJCommands(_v1860,isLast).cons(expToJCommand(c,$false));
        }
        }
      }
    else if(_v1711.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(2749,2909)").add(ESLVal.list(_v1711)));
    }
  }
  private static ESLVal expsToJCommands = new ESLVal(new Function(new ESLVal("expsToJCommands"),null) { public ESLVal apply(ESLVal... args) { return expsToJCommands(args[0],args[1]); }});
  private static ESLVal expToJCommand(ESLVal c,ESLVal isLast) {
    
    {ESLVal _v1712 = c;
      
      switch(_v1712.termName) {
      case "Block": {ESLVal $3097 = _v1712.termRef(0);
        ESLVal $3096 = _v1712.termRef(1);
        
        if($3096.isCons())
        {ESLVal $3098 = $3096.head();
          ESLVal $3099 = $3096.tail();
          
          if($3099.isCons())
          {ESLVal $3100 = $3099.head();
            ESLVal $3101 = $3099.tail();
            
            {ESLVal l = $3097;
            
            {ESLVal es = $3096;
            
            return new ESLVal("JBlock",new java.util.function.Function<ESLVal,ESLVal>() {
              public ESLVal apply(ESLVal $l0) {
                ESLVal $a = $nil;
                java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                while(!$l0.isNil()) { 
                  ESLVal e = $l0.head();
                  $l0 = $l0.tail();
                  $v.add(expToJCommand(e,$false));
                }
                for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                return $a;
              }}.apply(butlast.apply(es)).add(ESLVal.list(expToJCommand(last.apply(es),isLast))));
          }
          }
          }
        else if($3099.isNil())
          {ESLVal l = $3097;
            
            {ESLVal e = $3098;
            
            return expToJCommand(e,isLast);
          }
          }
        else {ESLVal l = $3097;
            
            {ESLVal es = $3096;
            
            return new ESLVal("JBlock",new java.util.function.Function<ESLVal,ESLVal>() {
              public ESLVal apply(ESLVal $l0) {
                ESLVal $a = $nil;
                java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                while(!$l0.isNil()) { 
                  ESLVal e = $l0.head();
                  $l0 = $l0.tail();
                  $v.add(expToJCommand(e,$false));
                }
                for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                return $a;
              }}.apply(butlast.apply(es)).add(ESLVal.list(expToJCommand(last.apply(es),isLast))));
          }
          }
        }
      else if($3096.isNil())
        {ESLVal l = $3097;
          
          if(isLast.boolVal)
          return new ESLVal("JReturn",new ESLVal("JNull",new ESLVal[]{}));
          else
            {ESLVal _v1857 = $3097;
              
              return new ESLVal("JBlock",$nil);
            }
        }
      else {ESLVal l = $3097;
          
          {ESLVal es = $3096;
          
          return new ESLVal("JBlock",new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal e = $l0.head();
                $l0 = $l0.tail();
                $v.add(expToJCommand(e,$false));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(butlast.apply(es)).add(ESLVal.list(expToJCommand(last.apply(es),isLast))));
        }
        }
      }
    case "Update": {ESLVal $3095 = _v1712.termRef(0);
        ESLVal $3094 = _v1712.termRef(1);
        ESLVal $3093 = _v1712.termRef(2);
        
        {ESLVal l = $3095;
        
        {ESLVal n = $3094;
        
        {ESLVal e = $3093;
        
        if(isLast.boolVal)
        return new ESLVal("JBlock",ESLVal.list(new ESLVal("JUpdate",n,expToJExp(e)),new ESLVal("JReturn",new ESLVal("JNull",new ESLVal[]{}))));
        else
          {ESLVal _v1854 = $3095;
            
            {ESLVal _v1855 = $3094;
            
            {ESLVal _v1856 = $3093;
            
            return new ESLVal("JUpdate",_v1855,expToJExp(_v1856));
          }
          }
          }
      }
      }
      }
      }
    case "If": {ESLVal $3092 = _v1712.termRef(0);
        ESLVal $3091 = _v1712.termRef(1);
        ESLVal $3090 = _v1712.termRef(2);
        ESLVal $3089 = _v1712.termRef(3);
        
        {ESLVal l = $3092;
        
        {ESLVal e1 = $3091;
        
        {ESLVal e2 = $3090;
        
        {ESLVal e3 = $3089;
        
        return new ESLVal("JIfCommand",expToJExp(e1),expToJCommand(e2,isLast),expToJCommand(e3,isLast));
      }
      }
      }
      }
      }
    case "CaseList": {ESLVal $3088 = _v1712.termRef(0);
        ESLVal $3087 = _v1712.termRef(1);
        ESLVal $3086 = _v1712.termRef(2);
        ESLVal $3085 = _v1712.termRef(3);
        ESLVal $3084 = _v1712.termRef(4);
        
        {ESLVal l = $3088;
        
        {ESLVal e = $3087;
        
        {ESLVal cons = $3086;
        
        {ESLVal nil = $3085;
        
        {ESLVal alt = $3084;
        
        return new ESLVal("JCaseList",expToJExp(e),expToJCommand(cons,isLast),expToJCommand(nil,isLast),expToJCommand(alt,isLast));
      }
      }
      }
      }
      }
      }
    case "CaseTerm": {ESLVal $3083 = _v1712.termRef(0);
        ESLVal $3082 = _v1712.termRef(1);
        ESLVal $3081 = _v1712.termRef(2);
        ESLVal $3080 = _v1712.termRef(3);
        
        {ESLVal l = $3083;
        
        {ESLVal e = $3082;
        
        {ESLVal arms = $3081;
        
        {ESLVal alt = $3080;
        
        return new ESLVal("JCaseTerm",expToJExp(e),termArmsToJTermArms(arms,isLast),expToJCommand(alt,isLast));
      }
      }
      }
      }
      }
    case "CaseInt": {ESLVal $3079 = _v1712.termRef(0);
        ESLVal $3078 = _v1712.termRef(1);
        ESLVal $3077 = _v1712.termRef(2);
        ESLVal $3076 = _v1712.termRef(3);
        
        {ESLVal l = $3079;
        
        {ESLVal e = $3078;
        
        {ESLVal arms = $3077;
        
        {ESLVal alt = $3076;
        
        return new ESLVal("JCaseInt",expToJExp(e),intArmsToJIntArms(arms,isLast),expToJCommand(alt,isLast));
      }
      }
      }
      }
      }
    case "CaseStr": {ESLVal $3075 = _v1712.termRef(0);
        ESLVal $3074 = _v1712.termRef(1);
        ESLVal $3073 = _v1712.termRef(2);
        ESLVal $3072 = _v1712.termRef(3);
        
        {ESLVal l = $3075;
        
        {ESLVal e = $3074;
        
        {ESLVal arms = $3073;
        
        {ESLVal alt = $3072;
        
        return new ESLVal("JCaseStr",expToJExp(e),strArmsToJStrArms(arms,isLast),expToJCommand(alt,isLast));
      }
      }
      }
      }
      }
    case "CaseBool": {ESLVal $3071 = _v1712.termRef(0);
        ESLVal $3070 = _v1712.termRef(1);
        ESLVal $3069 = _v1712.termRef(2);
        ESLVal $3068 = _v1712.termRef(3);
        
        {ESLVal l = $3071;
        
        {ESLVal e = $3070;
        
        {ESLVal arms = $3069;
        
        {ESLVal alt = $3068;
        
        return new ESLVal("JCaseBool",expToJExp(e),boolArmsToJBoolArms(arms,isLast),expToJCommand(alt,isLast));
      }
      }
      }
      }
      }
    case "Let": {ESLVal $3067 = _v1712.termRef(0);
        ESLVal $3066 = _v1712.termRef(1);
        ESLVal $3065 = _v1712.termRef(2);
        
        {ESLVal l = $3067;
        
        {ESLVal bs = $3066;
        
        {ESLVal e = $3065;
        
        return new ESLVal("JLet",new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              $v.add(defToField(b));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(bs),expToJCommand(e,isLast));
      }
      }
      }
      }
    case "Letrec": {ESLVal $3064 = _v1712.termRef(0);
        ESLVal $3063 = _v1712.termRef(1);
        ESLVal $3062 = _v1712.termRef(2);
        
        {ESLVal l = $3064;
        
        {ESLVal bs = $3063;
        
        {ESLVal e = $3062;
        
        return new ESLVal("JLetRec",new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              $v.add(defToField(b));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(bs),expToJCommand(e,$true));
      }
      }
      }
      }
    case "For": {ESLVal $3058 = _v1712.termRef(0);
        ESLVal $3057 = _v1712.termRef(1);
        ESLVal $3056 = _v1712.termRef(2);
        ESLVal $3055 = _v1712.termRef(3);
        
        switch($3057.termName) {
        case "PVar": {ESLVal $3061 = $3057.termRef(0);
          ESLVal $3060 = $3057.termRef(1);
          ESLVal $3059 = $3057.termRef(2);
          
          {ESLVal l1 = $3058;
          
          {ESLVal l2 = $3061;
          
          {ESLVal n = $3060;
          
          {ESLVal t = $3059;
          
          {ESLVal e = $3056;
          
          {ESLVal b = $3055;
          
          if(isLast.boolVal)
          return new ESLVal("JBlock",ESLVal.list(new ESLVal("JFor",newName(),n,expToJExp(e),expToJCommand(b,$false)),new ESLVal("JReturn",new ESLVal("JNull",new ESLVal[]{}))));
          else
            {ESLVal _v1848 = $3058;
              
              {ESLVal _v1849 = $3061;
              
              {ESLVal _v1850 = $3060;
              
              {ESLVal _v1851 = $3059;
              
              {ESLVal _v1852 = $3056;
              
              {ESLVal _v1853 = $3055;
              
              return new ESLVal("JFor",newName(),_v1850,expToJExp(_v1852),expToJCommand(_v1853,$false));
            }
            }
            }
            }
            }
            }
        }
        }
        }
        }
        }
        }
        }
        default: {ESLVal l = $3058;
          
          {ESLVal p = $3057;
          
          {ESLVal e = $3056;
          
          {ESLVal b = $3055;
          
          {ESLVal opName = newName();
          ESLVal varName = newName();
          
          return expToJCommand(new ESLVal("For",l,new ESLVal("PVar",l,varName,$null),e,new ESLVal("Let",l,ESLVal.list(new ESLVal("Binding",l,opName,$null,$null,new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("forp")),$nil,$null,new ESLVal("Case",l,$nil,ESLVal.list(new ESLVal("Var",l,varName)),ESLVal.list(new ESLVal("BArm",l,ESLVal.list(p),new ESLVal("BoolExp",l,$true),b),new ESLVal("BArm",l,ESLVal.list(new ESLVal("PVar",l,new ESLVal("$$$"),$null)),new ESLVal("BoolExp",l,$true),new ESLVal("Block",l,$nil))))))),new ESLVal("Apply",l,new ESLVal("Var",l,opName),$nil))),isLast);
        }
        }
        }
        }
        }
      }
      }
    case "PLet": {ESLVal $3054 = _v1712.termRef(0);
        ESLVal $3053 = _v1712.termRef(1);
        ESLVal $3052 = _v1712.termRef(2);
        
        {ESLVal l = $3054;
        
        {ESLVal bs = $3053;
        
        {ESLVal e = $3052;
        
        return new ESLVal("JPLet",new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal b = $l0.head();
              $l0 = $l0.tail();
              $v.add(defToField(b));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(bs),expToJCommand(e,isLast));
      }
      }
      }
      }
      default: {ESLVal e = _v1712;
        
        if(isLast.boolVal)
        return new ESLVal("JReturn",expToJExp(e));
        else
          {ESLVal _v1858 = _v1712;
            
            return new ESLVal("JStatement",expToJExp(_v1858));
          }
      }
    }
    }
  }
  private static ESLVal expToJCommand = new ESLVal(new Function(new ESLVal("expToJCommand"),null) { public ESLVal apply(ESLVal... args) { return expToJCommand(args[0],args[1]); }});
  private static ESLVal expsToJExps(ESLVal es) {
    
    return map.apply(new ESLVal(new Function(new ESLVal("fun424"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal e = $args[0];
      return expToJExp(e);
        }
      }),es);
  }
  private static ESLVal expsToJExps = new ESLVal(new Function(new ESLVal("expsToJExps"),null) { public ESLVal apply(ESLVal... args) { return expsToJExps(args[0]); }});
  private static ESLVal termArmsToJTermArms(ESLVal arms,ESLVal isLast) {
    
    {ESLVal _v1713 = arms;
      
      if(_v1713.isCons())
      {ESLVal $3102 = _v1713.head();
        ESLVal $3103 = _v1713.tail();
        
        switch($3102.termName) {
        case "TArm": {ESLVal $3105 = $3102.termRef(0);
          ESLVal $3104 = $3102.termRef(1);
          
          {ESLVal n = $3105;
          
          {ESLVal e = $3104;
          
          {ESLVal _v1847 = $3103;
          
          return termArmsToJTermArms(_v1847,isLast).cons(new ESLVal("JTArm",n,$zero,expToJCommand(e,isLast)));
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(6244,6413)").add(ESLVal.list(_v1713)));
      }
      }
    else if(_v1713.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(6244,6413)").add(ESLVal.list(_v1713)));
    }
  }
  private static ESLVal termArmsToJTermArms = new ESLVal(new Function(new ESLVal("termArmsToJTermArms"),null) { public ESLVal apply(ESLVal... args) { return termArmsToJTermArms(args[0],args[1]); }});
  private static ESLVal intArmsToJIntArms(ESLVal arms,ESLVal isLast) {
    
    {ESLVal _v1714 = arms;
      
      if(_v1714.isCons())
      {ESLVal $3106 = _v1714.head();
        ESLVal $3107 = _v1714.tail();
        
        switch($3106.termName) {
        case "IArm": {ESLVal $3109 = $3106.termRef(0);
          ESLVal $3108 = $3106.termRef(1);
          
          {ESLVal n = $3109;
          
          {ESLVal e = $3108;
          
          {ESLVal _v1846 = $3107;
          
          return intArmsToJIntArms(_v1846,isLast).cons(new ESLVal("JIArm",n,expToJCommand(e,isLast)));
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(6482,6646)").add(ESLVal.list(_v1714)));
      }
      }
    else if(_v1714.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(6482,6646)").add(ESLVal.list(_v1714)));
    }
  }
  private static ESLVal intArmsToJIntArms = new ESLVal(new Function(new ESLVal("intArmsToJIntArms"),null) { public ESLVal apply(ESLVal... args) { return intArmsToJIntArms(args[0],args[1]); }});
  private static ESLVal strArmsToJStrArms(ESLVal arms,ESLVal isLast) {
    
    {ESLVal _v1715 = arms;
      
      if(_v1715.isCons())
      {ESLVal $3110 = _v1715.head();
        ESLVal $3111 = _v1715.tail();
        
        switch($3110.termName) {
        case "SArm": {ESLVal $3113 = $3110.termRef(0);
          ESLVal $3112 = $3110.termRef(1);
          
          {ESLVal s = $3113;
          
          {ESLVal e = $3112;
          
          {ESLVal _v1845 = $3111;
          
          return strArmsToJStrArms(_v1845,isLast).cons(new ESLVal("JSArm",s,expToJCommand(e,isLast)));
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(6715,6879)").add(ESLVal.list(_v1715)));
      }
      }
    else if(_v1715.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(6715,6879)").add(ESLVal.list(_v1715)));
    }
  }
  private static ESLVal strArmsToJStrArms = new ESLVal(new Function(new ESLVal("strArmsToJStrArms"),null) { public ESLVal apply(ESLVal... args) { return strArmsToJStrArms(args[0],args[1]); }});
  private static ESLVal boolArmsToJBoolArms(ESLVal arms,ESLVal isLast) {
    
    {ESLVal _v1716 = arms;
      
      if(_v1716.isCons())
      {ESLVal $3114 = _v1716.head();
        ESLVal $3115 = _v1716.tail();
        
        switch($3114.termName) {
        case "BoolArm": {ESLVal $3117 = $3114.termRef(0);
          ESLVal $3116 = $3114.termRef(1);
          
          {ESLVal b = $3117;
          
          {ESLVal e = $3116;
          
          {ESLVal _v1844 = $3115;
          
          return boolArmsToJBoolArms(_v1844,isLast).cons(new ESLVal("JBArm",b,expToJCommand(e,isLast)));
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(6954,7127)").add(ESLVal.list(_v1716)));
      }
      }
    else if(_v1716.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(6954,7127)").add(ESLVal.list(_v1716)));
    }
  }
  private static ESLVal boolArmsToJBoolArms = new ESLVal(new Function(new ESLVal("boolArmsToJBoolArms"),null) { public ESLVal apply(ESLVal... args) { return boolArmsToJBoolArms(args[0],args[1]); }});
  private static ESLVal opToJOp(ESLVal op) {
    
    {ESLVal _v1717 = op;
      
      switch(_v1717.strVal) {
      case "@": return new ESLVal("at");
    case "+": return new ESLVal("add");
    case "-": return new ESLVal("sub");
    case "*": return new ESLVal("mul");
    case "/": return new ESLVal("div");
    case "%": return new ESLVal("mod");
    case ">": return new ESLVal("gre");
    case ">=": return new ESLVal("greql");
    case "<": return new ESLVal("less");
    case "<=": return new ESLVal("lesseql");
    case "=": return new ESLVal("eql");
    case "<>": return new ESLVal("neql");
    case ":": return new ESLVal("cons");
    case "..": return new ESLVal("to");
    case "or": return new ESLVal("or");
    case "and": return new ESLVal("and");
    case "andalso": return new ESLVal("andalso");
    case "orelse": return new ESLVal("orelse");
      default: return error(new ESLVal("case error at Pos(7155,7524)").add(ESLVal.list(_v1717)));
    }
    }
  }
  private static ESLVal opToJOp = new ESLVal(new Function(new ESLVal("opToJOp"),null) { public ESLVal apply(ESLVal... args) { return opToJOp(args[0]); }});
  private static ESLVal caseToJExp(ESLVal l,ESLVal es,ESLVal arms) {
    
    {ESLVal bindings = new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(new ESLVal("Binding",l,newName(),$null,$null,e));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(es);
      
      {ESLVal names = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v1718 = $qualArg;
              
              switch(_v1718.termName) {
              case "Binding": {ESLVal $3122 = _v1718.termRef(0);
                ESLVal $3121 = _v1718.termRef(1);
                ESLVal $3120 = _v1718.termRef(2);
                ESLVal $3119 = _v1718.termRef(3);
                ESLVal $3118 = _v1718.termRef(4);
                
                {ESLVal _v1843 = $3122;
                
                {ESLVal n = $3121;
                
                {ESLVal dt = $3120;
                
                {ESLVal t = $3119;
                
                {ESLVal e = $3118;
                
                return ESLVal.list(ESLVal.list(n));
              }
              }
              }
              }
              }
              }
              default: {ESLVal _0 = _v1718;
                
                return $nil;
              }
            }
            }
          }
        }).map(bindings).flatten().flatten();
      
      return expToJExp(new ESLVal("Let",l,bindings,translateCases.apply(new ESLVal("Case",l,$nil,new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal n = $l0.head();
            $l0 = $l0.tail();
            $v.add(new ESLVal("Var",l,n));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(names),arms))));
    }
    }
  }
  private static ESLVal caseToJExp = new ESLVal(new Function(new ESLVal("caseToJExp"),null) { public ESLVal apply(ESLVal... args) { return caseToJExp(args[0],args[1],args[2]); }});
  private static ESLVal expToJExp(ESLVal e) {
    
    {ESLVal _v1719 = e;
      
      switch(_v1719.termName) {
      case "Apply": {ESLVal $3307 = _v1719.termRef(0);
        ESLVal $3306 = _v1719.termRef(1);
        ESLVal $3305 = _v1719.termRef(2);
        
        {ESLVal l = $3307;
        
        {ESLVal op = $3306;
        
        {ESLVal args = $3305;
        
        return new ESLVal("JApply",expToJExp(op),expsToJExps(args));
      }
      }
      }
      }
    case "ArrayUpdate": {ESLVal $3304 = _v1719.termRef(0);
        ESLVal $3303 = _v1719.termRef(1);
        ESLVal $3302 = _v1719.termRef(2);
        ESLVal $3301 = _v1719.termRef(3);
        
        {ESLVal l = $3304;
        
        {ESLVal a = $3303;
        
        {ESLVal i = $3302;
        
        {ESLVal v = $3301;
        
        return new ESLVal("JArrayUpdate",expToJExp(a),expToJExp(i),expToJExp(v));
      }
      }
      }
      }
      }
    case "ArrayRef": {ESLVal $3300 = _v1719.termRef(0);
        ESLVal $3299 = _v1719.termRef(1);
        ESLVal $3298 = _v1719.termRef(2);
        
        {ESLVal l = $3300;
        
        {ESLVal a = $3299;
        
        {ESLVal i = $3298;
        
        return new ESLVal("JArrayRef",expToJExp(a),expToJExp(i));
      }
      }
      }
      }
    case "IntExp": {ESLVal $3297 = _v1719.termRef(0);
        ESLVal $3296 = _v1719.termRef(1);
        
        {ESLVal l = $3297;
        
        {ESLVal n = $3296;
        
        return new ESLVal("JConstExp",new ESLVal("JConstInt",n));
      }
      }
      }
    case "StrExp": {ESLVal $3295 = _v1719.termRef(0);
        ESLVal $3294 = _v1719.termRef(1);
        
        {ESLVal l = $3295;
        
        {ESLVal s = $3294;
        
        return new ESLVal("JConstExp",new ESLVal("JConstStr",s));
      }
      }
      }
    case "BoolExp": {ESLVal $3293 = _v1719.termRef(0);
        ESLVal $3292 = _v1719.termRef(1);
        
        {ESLVal l = $3293;
        
        {ESLVal b = $3292;
        
        return new ESLVal("JConstExp",new ESLVal("JConstBool",b));
      }
      }
      }
    case "FloatExp": {ESLVal $3291 = _v1719.termRef(0);
        ESLVal $3290 = _v1719.termRef(1);
        
        {ESLVal l = $3291;
        
        {ESLVal f = $3290;
        
        return new ESLVal("JConstExp",new ESLVal("JConstDouble",f));
      }
      }
      }
    case "ApplyTypeExp": {ESLVal $3276 = _v1719.termRef(0);
        ESLVal $3275 = _v1719.termRef(1);
        ESLVal $3274 = _v1719.termRef(2);
        
        switch($3275.termName) {
        case "List": {ESLVal $3283 = $3275.termRef(0);
          ESLVal $3282 = $3275.termRef(1);
          
          if($3282.isCons())
          {ESLVal $3284 = $3282.head();
            ESLVal $3285 = $3282.tail();
            
            {ESLVal l = $3276;
            
            {ESLVal _v1836 = $3275;
            
            {ESLVal ts = $3274;
            
            return expToJExp(_v1836);
          }
          }
          }
          }
        else if($3282.isNil())
          if($3274.isCons())
            {ESLVal $3286 = $3274.head();
              ESLVal $3287 = $3274.tail();
              
              if($3287.isCons())
              {ESLVal $3288 = $3287.head();
                ESLVal $3289 = $3287.tail();
                
                {ESLVal l = $3276;
                
                {ESLVal _v1837 = $3275;
                
                {ESLVal ts = $3274;
                
                return expToJExp(_v1837);
              }
              }
              }
              }
            else if($3287.isNil())
              {ESLVal l1 = $3276;
                
                {ESLVal l2 = $3283;
                
                {ESLVal t = $3286;
                
                return new ESLVal("JNil",$null);
              }
              }
              }
            else {ESLVal l = $3276;
                
                {ESLVal _v1838 = $3275;
                
                {ESLVal ts = $3274;
                
                return expToJExp(_v1838);
              }
              }
              }
            }
          else if($3274.isNil())
            {ESLVal l = $3276;
              
              {ESLVal _v1839 = $3275;
              
              {ESLVal ts = $3274;
              
              return expToJExp(_v1839);
            }
            }
            }
          else {ESLVal l = $3276;
              
              {ESLVal _v1840 = $3275;
              
              {ESLVal ts = $3274;
              
              return expToJExp(_v1840);
            }
            }
            }
        else {ESLVal l = $3276;
            
            {ESLVal _v1841 = $3275;
            
            {ESLVal ts = $3274;
            
            return expToJExp(_v1841);
          }
          }
          }
        }
      case "NullExp": {ESLVal $3277 = $3275.termRef(0);
          
          if($3274.isCons())
          {ESLVal $3278 = $3274.head();
            ESLVal $3279 = $3274.tail();
            
            if($3279.isCons())
            {ESLVal $3280 = $3279.head();
              ESLVal $3281 = $3279.tail();
              
              {ESLVal l = $3276;
              
              {ESLVal _v1832 = $3275;
              
              {ESLVal ts = $3274;
              
              return expToJExp(_v1832);
            }
            }
            }
            }
          else if($3279.isNil())
            {ESLVal l1 = $3276;
              
              {ESLVal l2 = $3277;
              
              {ESLVal t = $3278;
              
              return new ESLVal("JNull",new ESLVal[]{});
            }
            }
            }
          else {ESLVal l = $3276;
              
              {ESLVal _v1833 = $3275;
              
              {ESLVal ts = $3274;
              
              return expToJExp(_v1833);
            }
            }
            }
          }
        else if($3274.isNil())
          {ESLVal l = $3276;
            
            {ESLVal _v1834 = $3275;
            
            {ESLVal ts = $3274;
            
            return expToJExp(_v1834);
          }
          }
          }
        else {ESLVal l = $3276;
            
            {ESLVal _v1835 = $3275;
            
            {ESLVal ts = $3274;
            
            return expToJExp(_v1835);
          }
          }
          }
        }
        default: {ESLVal l = $3276;
          
          {ESLVal _v1842 = $3275;
          
          {ESLVal ts = $3274;
          
          return expToJExp(_v1842);
        }
        }
        }
      }
      }
    case "List": {ESLVal $3273 = _v1719.termRef(0);
        ESLVal $3272 = _v1719.termRef(1);
        
        {ESLVal l = $3273;
        
        {ESLVal es = $3272;
        
        return new ESLVal("JList",$null,expsToJExps(es));
      }
      }
      }
    case "SetExp": {ESLVal $3271 = _v1719.termRef(0);
        ESLVal $3270 = _v1719.termRef(1);
        
        {ESLVal l = $3271;
        
        {ESLVal es = $3270;
        
        return new ESLVal("JSet",$null,expsToJExps(es));
      }
      }
      }
    case "BagExp": {ESLVal $3269 = _v1719.termRef(0);
        ESLVal $3268 = _v1719.termRef(1);
        
        {ESLVal l = $3269;
        
        {ESLVal es = $3268;
        
        return new ESLVal("JBag",$null,expsToJExps(es));
      }
      }
      }
    case "Term": {ESLVal $3267 = _v1719.termRef(0);
        ESLVal $3266 = _v1719.termRef(1);
        ESLVal $3265 = _v1719.termRef(2);
        ESLVal $3264 = _v1719.termRef(3);
        
        {ESLVal l = $3267;
        
        {ESLVal n = $3266;
        
        {ESLVal ts = $3265;
        
        {ESLVal es = $3264;
        
        return new ESLVal("JTerm",n,expsToJExps(es));
      }
      }
      }
      }
      }
    case "Case": {ESLVal $3263 = _v1719.termRef(0);
        ESLVal $3262 = _v1719.termRef(1);
        ESLVal $3261 = _v1719.termRef(2);
        ESLVal $3260 = _v1719.termRef(3);
        
        {ESLVal l = $3263;
        
        {ESLVal ds = $3262;
        
        {ESLVal es = $3261;
        
        {ESLVal arms = $3260;
        
        return caseToJExp(l,es,arms);
      }
      }
      }
      }
      }
    case "CaseAdd": {ESLVal $3259 = _v1719.termRef(0);
        ESLVal $3258 = _v1719.termRef(1);
        ESLVal $3257 = _v1719.termRef(2);
        ESLVal $3256 = _v1719.termRef(3);
        
        {ESLVal l = $3259;
        
        {ESLVal s = $3258;
        
        {ESLVal handler = $3257;
        
        {ESLVal fail = $3256;
        
        return expToJExp(new ESLVal("Apply",l,new ESLVal("Var",l,new ESLVal("$ndCase")),ESLVal.list(s,handler,fail)));
      }
      }
      }
      }
      }
    case "CaseList": {ESLVal $3255 = _v1719.termRef(0);
        ESLVal $3254 = _v1719.termRef(1);
        ESLVal $3253 = _v1719.termRef(2);
        ESLVal $3252 = _v1719.termRef(3);
        ESLVal $3251 = _v1719.termRef(4);
        
        {ESLVal l = $3255;
        
        {ESLVal list = $3254;
        
        {ESLVal cons = $3253;
        
        {ESLVal nil = $3252;
        
        {ESLVal alt = $3251;
        
        return new ESLVal("JCommandExp",expToJCommand(e,$true),$null);
      }
      }
      }
      }
      }
      }
    case "CaseTerm": {ESLVal $3250 = _v1719.termRef(0);
        ESLVal $3249 = _v1719.termRef(1);
        ESLVal $3248 = _v1719.termRef(2);
        ESLVal $3247 = _v1719.termRef(3);
        
        {ESLVal l = $3250;
        
        {ESLVal list = $3249;
        
        {ESLVal arms = $3248;
        
        {ESLVal alt = $3247;
        
        return new ESLVal("JCommandExp",expToJCommand(e,$true),$null);
      }
      }
      }
      }
      }
    case "CaseStr": {ESLVal $3246 = _v1719.termRef(0);
        ESLVal $3245 = _v1719.termRef(1);
        ESLVal $3244 = _v1719.termRef(2);
        ESLVal $3243 = _v1719.termRef(3);
        
        {ESLVal l = $3246;
        
        {ESLVal s = $3245;
        
        {ESLVal arms = $3244;
        
        {ESLVal alt = $3243;
        
        return new ESLVal("JCommandExp",expToJCommand(e,$true),$null);
      }
      }
      }
      }
      }
    case "CaseBool": {ESLVal $3242 = _v1719.termRef(0);
        ESLVal $3241 = _v1719.termRef(1);
        ESLVal $3240 = _v1719.termRef(2);
        ESLVal $3239 = _v1719.termRef(3);
        
        {ESLVal l = $3242;
        
        {ESLVal s = $3241;
        
        {ESLVal arms = $3240;
        
        {ESLVal alt = $3239;
        
        return new ESLVal("JCommandExp",expToJCommand(e,$true),$null);
      }
      }
      }
      }
      }
    case "CaseSet": {ESLVal $3238 = _v1719.termRef(0);
        ESLVal $3237 = _v1719.termRef(1);
        ESLVal $3236 = _v1719.termRef(2);
        ESLVal $3235 = _v1719.termRef(3);
        
        {ESLVal l = $3238;
        
        {ESLVal s = $3237;
        
        {ESLVal handler = $3236;
        
        {ESLVal fail = $3235;
        
        return expToJExp(new ESLVal("Apply",l,new ESLVal("Var",l,new ESLVal("$ndCase")),ESLVal.list(s,handler,fail)));
      }
      }
      }
      }
      }
    case "Head": {ESLVal $3234 = _v1719.termRef(0);
        
        {ESLVal _v1831 = $3234;
        
        return new ESLVal("JHead",expToJExp(_v1831));
      }
      }
    case "Tail": {ESLVal $3233 = _v1719.termRef(0);
        
        {ESLVal _v1830 = $3233;
        
        return new ESLVal("JTail",expToJExp(_v1830));
      }
      }
    case "CaseError": {ESLVal $3232 = _v1719.termRef(0);
        ESLVal $3231 = _v1719.termRef(1);
        
        {ESLVal l = $3232;
        
        {ESLVal _v1829 = $3231;
        
        return new ESLVal("JError",new ESLVal("JBinExp",new ESLVal("JConstExp",new ESLVal("JConstStr",new ESLVal("case error at ").add(l))),new ESLVal("add"),expToJExp(_v1829)));
      }
      }
      }
    case "NullExp": {ESLVal $3230 = _v1719.termRef(0);
        
        {ESLVal l = $3230;
        
        return new ESLVal("JNull",new ESLVal[]{});
      }
      }
    case "Var": {ESLVal $3229 = _v1719.termRef(0);
        ESLVal $3228 = _v1719.termRef(1);
        
        {ESLVal l = $3229;
        
        {ESLVal n = $3228;
        
        return new ESLVal("JVar",n,$null);
      }
      }
      }
    case "Let": {ESLVal $3227 = _v1719.termRef(0);
        ESLVal $3226 = _v1719.termRef(1);
        ESLVal $3225 = _v1719.termRef(2);
        
        {ESLVal l = $3227;
        
        {ESLVal bs = $3226;
        
        {ESLVal body = $3225;
        
        return new ESLVal("JCommandExp",expToJCommand(e,$true),$null);
      }
      }
      }
      }
    case "Letrec": {ESLVal $3224 = _v1719.termRef(0);
        ESLVal $3223 = _v1719.termRef(1);
        ESLVal $3222 = _v1719.termRef(2);
        
        {ESLVal l = $3224;
        
        {ESLVal bs = $3223;
        
        {ESLVal body = $3222;
        
        return new ESLVal("JCommandExp",expToJCommand(e,$true),$null);
      }
      }
      }
      }
    case "Throw": {ESLVal $3221 = _v1719.termRef(0);
        ESLVal $3220 = _v1719.termRef(1);
        ESLVal $3219 = _v1719.termRef(2);
        
        {ESLVal l = $3221;
        
        {ESLVal t = $3220;
        
        {ESLVal _v1828 = $3219;
        
        return new ESLVal("JError",expToJExp(_v1828));
      }
      }
      }
      }
    case "BinExp": {ESLVal $3218 = _v1719.termRef(0);
        ESLVal $3217 = _v1719.termRef(1);
        ESLVal $3216 = _v1719.termRef(2);
        ESLVal $3215 = _v1719.termRef(3);
        
        {ESLVal l = $3218;
        
        {ESLVal e1 = $3217;
        
        {ESLVal op = $3216;
        
        {ESLVal e2 = $3215;
        
        return new ESLVal("JBinExp",expToJExp(e1),opToJOp(op),expToJExp(e2));
      }
      }
      }
      }
      }
    case "Become": {ESLVal $3211 = _v1719.termRef(0);
        ESLVal $3210 = _v1719.termRef(1);
        
        switch($3210.termName) {
        case "Apply": {ESLVal $3214 = $3210.termRef(0);
          ESLVal $3213 = $3210.termRef(1);
          ESLVal $3212 = $3210.termRef(2);
          
          {ESLVal l = $3211;
          
          {ESLVal al = $3214;
          
          {ESLVal b = $3213;
          
          {ESLVal args = $3212;
          
          return new ESLVal("JBecome",expToJExp(b),expsToJExps(args));
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(7891,16667)").add(ESLVal.list(_v1719)));
      }
      }
    case "Block": {ESLVal $3205 = _v1719.termRef(0);
        ESLVal $3204 = _v1719.termRef(1);
        
        if($3204.isCons())
        {ESLVal $3206 = $3204.head();
          ESLVal $3207 = $3204.tail();
          
          if($3207.isCons())
          {ESLVal $3208 = $3207.head();
            ESLVal $3209 = $3207.tail();
            
            {ESLVal l = $3205;
            
            {ESLVal es = $3204;
            
            return new ESLVal("JCommandExp",new ESLVal("JBlock",expsToJCommands(es,$true)),$null);
          }
          }
          }
        else if($3207.isNil())
          {ESLVal l = $3205;
            
            {ESLVal _v1827 = $3206;
            
            return expToJExp(_v1827);
          }
          }
        else {ESLVal l = $3205;
            
            {ESLVal es = $3204;
            
            return new ESLVal("JCommandExp",new ESLVal("JBlock",expsToJCommands(es,$true)),$null);
          }
          }
        }
      else if($3204.isNil())
        {ESLVal l = $3205;
          
          return new ESLVal("JNull",new ESLVal[]{});
        }
      else {ESLVal l = $3205;
          
          {ESLVal es = $3204;
          
          return new ESLVal("JCommandExp",new ESLVal("JBlock",expsToJCommands(es,$true)),$null);
        }
        }
      }
    case "If": {ESLVal $3203 = _v1719.termRef(0);
        ESLVal $3202 = _v1719.termRef(1);
        ESLVal $3201 = _v1719.termRef(2);
        ESLVal $3200 = _v1719.termRef(3);
        
        {ESLVal l = $3203;
        
        {ESLVal e1 = $3202;
        
        {ESLVal e2 = $3201;
        
        {ESLVal e3 = $3200;
        
        return new ESLVal("JCommandExp",new ESLVal("JIfCommand",expToJExp(e1),expToJCommand(e2,$true),expToJCommand(e3,$true)),$null);
      }
      }
      }
      }
      }
    case "FunExp": {ESLVal $3199 = _v1719.termRef(0);
        ESLVal $3198 = _v1719.termRef(1);
        ESLVal $3197 = _v1719.termRef(2);
        ESLVal $3196 = _v1719.termRef(3);
        ESLVal $3195 = _v1719.termRef(4);
        
        {ESLVal l = $3199;
        
        {ESLVal n = $3198;
        
        {ESLVal args = $3197;
        
        {ESLVal t = $3196;
        
        {ESLVal body = $3195;
        
        return new ESLVal("JFun",expToJExp(n),map.apply(new ESLVal(new Function(new ESLVal("fun425"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal d = $args[0];
        return decToJDec(d);
          }
        }),args),new ESLVal("JFunType",new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal a = $l0.head();
              $l0 = $l0.tail();
              $v.add($null);
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(args),$null),expToJCommand(body,$true));
      }
      }
      }
      }
      }
      }
    case "TermRef": {ESLVal $3194 = _v1719.termRef(0);
        ESLVal $3193 = _v1719.termRef(1);
        
        {ESLVal _v1826 = $3194;
        
        {ESLVal i = $3193;
        
        return new ESLVal("JTermRef",expToJExp(_v1826),i);
      }
      }
      }
    case "Cmp": {ESLVal $3188 = _v1719.termRef(0);
        ESLVal $3187 = _v1719.termRef(1);
        ESLVal $3186 = _v1719.termRef(2);
        
        if($3186.isCons())
        {ESLVal $3189 = $3186.head();
          ESLVal $3190 = $3186.tail();
          
          switch($3189.termName) {
          case "PQual": {ESLVal $3192 = $3189.termRef(0);
            ESLVal $3191 = $3189.termRef(1);
            
            {ESLVal l = $3188;
            
            {ESLVal _v1813 = $3187;
            
            {ESLVal ql = $3192;
            
            {ESLVal p = $3191;
            
            {ESLVal qs = $3190;
            
            return expToJExp(new ESLVal("If",ql,p,new ESLVal("Cmp",l,_v1813,qs),new ESLVal("List",l,$nil)));
          }
          }
          }
          }
          }
          }
          default: {ESLVal l = $3188;
            
            {ESLVal _v1814 = $3187;
            
            {ESLVal qs = $3186;
            
            if(exists.apply(isBindingQualifier,qs).and(forall.apply(isSimpleQualifier,qs)).boolVal)
            return new ESLVal("JCmpExp",cmpToJCmp(_v1814,qs));
            else
              {ESLVal _v1815 = $3188;
                
                {ESLVal _v1816 = $3187;
                
                {ESLVal _v1817 = $3186;
                
                return cmpToJExp(_v1816,_v1817);
              }
              }
              }
          }
          }
          }
        }
        }
      else if($3186.isNil())
        {ESLVal l = $3188;
          
          {ESLVal _v1818 = $3187;
          
          {ESLVal qs = $3186;
          
          if(exists.apply(isBindingQualifier,qs).and(forall.apply(isSimpleQualifier,qs)).boolVal)
          return new ESLVal("JCmpExp",cmpToJCmp(_v1818,qs));
          else
            {ESLVal _v1819 = $3188;
              
              {ESLVal _v1820 = $3187;
              
              {ESLVal _v1821 = $3186;
              
              return cmpToJExp(_v1820,_v1821);
            }
            }
            }
        }
        }
        }
      else {ESLVal l = $3188;
          
          {ESLVal _v1822 = $3187;
          
          {ESLVal qs = $3186;
          
          if(exists.apply(isBindingQualifier,qs).and(forall.apply(isSimpleQualifier,qs)).boolVal)
          return new ESLVal("JCmpExp",cmpToJCmp(_v1822,qs));
          else
            {ESLVal _v1823 = $3188;
              
              {ESLVal _v1824 = $3187;
              
              {ESLVal _v1825 = $3186;
              
              return cmpToJExp(_v1824,_v1825);
            }
            }
            }
        }
        }
        }
      }
    case "Not": {ESLVal $3185 = _v1719.termRef(0);
        ESLVal $3184 = _v1719.termRef(1);
        
        {ESLVal l = $3185;
        
        {ESLVal _v1812 = $3184;
        
        return new ESLVal("JNot",expToJExp(_v1812));
      }
      }
      }
    case "New": {ESLVal $3183 = _v1719.termRef(0);
        ESLVal $3182 = _v1719.termRef(1);
        ESLVal $3181 = _v1719.termRef(2);
        
        {ESLVal l = $3183;
        
        {ESLVal b = $3182;
        
        {ESLVal args = $3181;
        
        return new ESLVal("JNew",expToJExp(b),expsToJExps(args));
      }
      }
      }
      }
    case "NewArray": {ESLVal $3180 = _v1719.termRef(0);
        ESLVal $3179 = _v1719.termRef(1);
        ESLVal $3178 = _v1719.termRef(2);
        
        {ESLVal l = $3180;
        
        {ESLVal t = $3179;
        
        {ESLVal i = $3178;
        
        return new ESLVal("JNewArray",expToJExp(i));
      }
      }
      }
      }
    case "NewJava": {ESLVal $3177 = _v1719.termRef(0);
        ESLVal $3176 = _v1719.termRef(1);
        ESLVal $3175 = _v1719.termRef(2);
        ESLVal $3174 = _v1719.termRef(3);
        
        {ESLVal l = $3177;
        
        {ESLVal n = $3176;
        
        {ESLVal t = $3175;
        
        {ESLVal args = $3174;
        
        return new ESLVal("JNewJava",n,expsToJExps(args));
      }
      }
      }
      }
      }
    case "NewTable": {ESLVal $3173 = _v1719.termRef(0);
        ESLVal $3172 = _v1719.termRef(1);
        ESLVal $3171 = _v1719.termRef(2);
        
        {ESLVal l = $3173;
        
        {ESLVal key = $3172;
        
        {ESLVal value = $3171;
        
        return new ESLVal("JNewTable",new ESLVal[]{});
      }
      }
      }
      }
    case "Record": {ESLVal $3170 = _v1719.termRef(0);
        ESLVal $3169 = _v1719.termRef(1);
        
        {ESLVal l = $3170;
        
        {ESLVal fs = $3169;
        
        return new ESLVal("JRecord",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v1720 = $qualArg;
              
              switch(_v1720.termName) {
              case "Binding": {ESLVal $3312 = _v1720.termRef(0);
                ESLVal $3311 = _v1720.termRef(1);
                ESLVal $3310 = _v1720.termRef(2);
                ESLVal $3309 = _v1720.termRef(3);
                ESLVal $3308 = _v1720.termRef(4);
                
                {ESLVal bl = $3312;
                
                {ESLVal n = $3311;
                
                {ESLVal t = $3310;
                
                {ESLVal dt = $3309;
                
                {ESLVal _v1811 = $3308;
                
                return ESLVal.list(ESLVal.list(new ESLVal("JField",n,$null,expToJExp(_v1811))));
              }
              }
              }
              }
              }
              }
              default: {ESLVal _0 = _v1720;
                
                return $nil;
              }
            }
            }
          }
        }).map(fs).flatten().flatten());
      }
      }
      }
    case "Send": {ESLVal $3164 = _v1719.termRef(0);
        ESLVal $3163 = _v1719.termRef(1);
        ESLVal $3162 = _v1719.termRef(2);
        
        switch($3162.termName) {
        case "Term": {ESLVal $3168 = $3162.termRef(0);
          ESLVal $3167 = $3162.termRef(1);
          ESLVal $3166 = $3162.termRef(2);
          ESLVal $3165 = $3162.termRef(3);
          
          {ESLVal l = $3164;
          
          {ESLVal a = $3163;
          
          {ESLVal lt = $3168;
          
          {ESLVal n = $3167;
          
          {ESLVal ts = $3166;
          
          {ESLVal es = $3165;
          
          return new ESLVal("JSend",expToJExp(a),n,expsToJExps(es));
        }
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(7891,16667)").add(ESLVal.list(_v1719)));
      }
      }
    case "SendTimeSuper": {ESLVal $3161 = _v1719.termRef(0);
        
        {ESLVal l = $3161;
        
        return new ESLVal("JSendTimeSuper",new ESLVal[]{});
      }
      }
    case "SendSuper": {ESLVal $3160 = _v1719.termRef(0);
        ESLVal $3159 = _v1719.termRef(1);
        
        {ESLVal l = $3160;
        
        {ESLVal _v1810 = $3159;
        
        return new ESLVal("JSendSuper",expToJExp(_v1810));
      }
      }
      }
    case "Self": {ESLVal $3158 = _v1719.termRef(0);
        
        {ESLVal l = $3158;
        
        return new ESLVal("JSelf",new ESLVal[]{});
      }
      }
    case "Fold": {ESLVal $3157 = _v1719.termRef(0);
        ESLVal $3156 = _v1719.termRef(1);
        ESLVal $3155 = _v1719.termRef(2);
        
        {ESLVal l = $3157;
        
        {ESLVal t = $3156;
        
        {ESLVal _v1809 = $3155;
        
        return expToJExp(_v1809);
      }
      }
      }
      }
    case "Now": {ESLVal $3154 = _v1719.termRef(0);
        
        {ESLVal l = $3154;
        
        return new ESLVal("JNow",new ESLVal[]{});
      }
      }
    case "Ref": {ESLVal $3153 = _v1719.termRef(0);
        ESLVal $3152 = _v1719.termRef(1);
        ESLVal $3151 = _v1719.termRef(2);
        
        {ESLVal l = $3153;
        
        {ESLVal _v1808 = $3152;
        
        {ESLVal n = $3151;
        
        return new ESLVal("JRef",expToJExp(_v1808),n);
      }
      }
      }
      }
    case "RefSuper": {ESLVal $3150 = _v1719.termRef(0);
        ESLVal $3149 = _v1719.termRef(1);
        
        {ESLVal l = $3150;
        
        {ESLVal n = $3149;
        
        return new ESLVal("JRefSuper",n);
      }
      }
      }
    case "For": {ESLVal $3148 = _v1719.termRef(0);
        ESLVal $3147 = _v1719.termRef(1);
        ESLVal $3146 = _v1719.termRef(2);
        ESLVal $3145 = _v1719.termRef(3);
        
        {ESLVal l1 = $3148;
        
        {ESLVal p = $3147;
        
        {ESLVal l2 = $3146;
        
        {ESLVal c = $3145;
        
        return new ESLVal("JCommandExp",expToJCommand(e,$true),$null);
      }
      }
      }
      }
      }
    case "Grab": {ESLVal $3144 = _v1719.termRef(0);
        ESLVal $3143 = _v1719.termRef(1);
        ESLVal $3142 = _v1719.termRef(2);
        
        {ESLVal l = $3144;
        
        {ESLVal refs = $3143;
        
        {ESLVal _v1807 = $3142;
        
        return new ESLVal("JGrab",refsToJExps(refs),expToJExp(_v1807));
      }
      }
      }
      }
    case "Update": {ESLVal $3141 = _v1719.termRef(0);
        ESLVal $3140 = _v1719.termRef(1);
        ESLVal $3139 = _v1719.termRef(2);
        
        {ESLVal l = $3141;
        
        {ESLVal n = $3140;
        
        {ESLVal v = $3139;
        
        return new ESLVal("JCommandExp",expToJCommand(e,$true),$null);
      }
      }
      }
      }
    case "Probably": {ESLVal $3138 = _v1719.termRef(0);
        ESLVal $3137 = _v1719.termRef(1);
        ESLVal $3136 = _v1719.termRef(2);
        ESLVal $3135 = _v1719.termRef(3);
        ESLVal $3134 = _v1719.termRef(4);
        
        {ESLVal l = $3138;
        
        {ESLVal _v1806 = $3137;
        
        {ESLVal t = $3136;
        
        {ESLVal e1 = $3135;
        
        {ESLVal e2 = $3134;
        
        return new ESLVal("JProbably",expToJExp(_v1806),expToJExp(e1),expToJExp(e2));
      }
      }
      }
      }
      }
      }
    case "Try": {ESLVal $3133 = _v1719.termRef(0);
        ESLVal $3132 = _v1719.termRef(1);
        ESLVal $3131 = _v1719.termRef(2);
        
        {ESLVal l = $3133;
        
        {ESLVal _v1805 = $3132;
        
        {ESLVal arms = $3131;
        
        return new ESLVal("JTry",expToJExp(_v1805),new ESLVal("$x"),expToJCommand(new ESLVal("Case",l,$nil,ESLVal.list(new ESLVal("Var",l,new ESLVal("$x"))),arms),$true));
      }
      }
      }
      }
    case "ActExp": {ESLVal $3130 = _v1719.termRef(0);
        ESLVal $3129 = _v1719.termRef(1);
        ESLVal $3128 = _v1719.termRef(2);
        ESLVal $3127 = _v1719.termRef(3);
        ESLVal $3126 = _v1719.termRef(4);
        ESLVal $3125 = _v1719.termRef(5);
        ESLVal $3124 = _v1719.termRef(6);
        ESLVal $3123 = _v1719.termRef(7);
        
        {ESLVal l = $3130;
        
        {ESLVal name = $3129;
        
        {ESLVal decs = $3128;
        
        {ESLVal exports = $3127;
        
        {ESLVal parent = $3126;
        
        {ESLVal defs = $3125;
        
        {ESLVal init = $3124;
        
        {ESLVal arms = $3123;
        
        return actToJava(name,decs,exports,parent,defs,init,arms);
      }
      }
      }
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(7891,16667)").add(ESLVal.list(_v1719)));
    }
    }
  }
  private static ESLVal expToJExp = new ESLVal(new Function(new ESLVal("expToJExp"),null) { public ESLVal apply(ESLVal... args) { return expToJExp(args[0]); }});
  private static ESLVal isSimpleQualifier(ESLVal q) {
    
    {ESLVal _v1721 = q;
      
      switch(_v1721.termName) {
      case "BQual": {ESLVal $3315 = _v1721.termRef(0);
        ESLVal $3314 = _v1721.termRef(1);
        ESLVal $3313 = _v1721.termRef(2);
        
        switch($3314.termName) {
        case "PVar": {ESLVal $3318 = $3314.termRef(0);
          ESLVal $3317 = $3314.termRef(1);
          ESLVal $3316 = $3314.termRef(2);
          
          {ESLVal l = $3315;
          
          {ESLVal vl = $3318;
          
          {ESLVal n = $3317;
          
          {ESLVal t = $3316;
          
          {ESLVal e = $3313;
          
          return $true;
        }
        }
        }
        }
        }
        }
        default: {ESLVal l = $3315;
          
          {ESLVal p = $3314;
          
          {ESLVal e = $3313;
          
          return $false;
        }
        }
        }
      }
      }
      default: {ESLVal _v1804 = _v1721;
        
        return $true;
      }
    }
    }
  }
  private static ESLVal isSimpleQualifier = new ESLVal(new Function(new ESLVal("isSimpleQualifier"),null) { public ESLVal apply(ESLVal... args) { return isSimpleQualifier(args[0]); }});
  private static ESLVal isBindingQualifier(ESLVal q) {
    
    {ESLVal _v1722 = q;
      
      switch(_v1722.termName) {
      case "BQual": {ESLVal $3321 = _v1722.termRef(0);
        ESLVal $3320 = _v1722.termRef(1);
        ESLVal $3319 = _v1722.termRef(2);
        
        {ESLVal l = $3321;
        
        {ESLVal p = $3320;
        
        {ESLVal e = $3319;
        
        return $true;
      }
      }
      }
      }
      default: {ESLVal _v1803 = _v1722;
        
        return $false;
      }
    }
    }
  }
  private static ESLVal isBindingQualifier = new ESLVal(new Function(new ESLVal("isBindingQualifier"),null) { public ESLVal apply(ESLVal... args) { return isBindingQualifier(args[0]); }});
  private static ESLVal cmpToJCmp(ESLVal e,ESLVal qs) {
    
    { LetRec letrec = new LetRec() {
      ESLVal inner = new ESLVal(new Function(new ESLVal("inner"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1798 = $args[0];
        {ESLVal _v1723 = _v1798;
              
              if(_v1723.isCons())
              {ESLVal $3322 = _v1723.head();
                ESLVal $3323 = _v1723.tail();
                
                switch($3322.termName) {
                case "BQual": {ESLVal $3328 = $3322.termRef(0);
                  ESLVal $3327 = $3322.termRef(1);
                  ESLVal $3326 = $3322.termRef(2);
                  
                  switch($3327.termName) {
                  case "PVar": {ESLVal $3331 = $3327.termRef(0);
                    ESLVal $3330 = $3327.termRef(1);
                    ESLVal $3329 = $3327.termRef(2);
                    
                    {ESLVal l = $3328;
                    
                    {ESLVal vl = $3331;
                    
                    {ESLVal n = $3330;
                    
                    {ESLVal t = $3329;
                    
                    {ESLVal listExp = $3326;
                    
                    {ESLVal _v1800 = $3323;
                    
                    return new ESLVal("JCmpBind",n,expToJExp(listExp),inner.apply(_v1800));
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(17072,17270)").add(ESLVal.list(_v1723)));
                }
                }
              case "PQual": {ESLVal $3325 = $3322.termRef(0);
                  ESLVal $3324 = $3322.termRef(1);
                  
                  {ESLVal l = $3325;
                  
                  {ESLVal p = $3324;
                  
                  {ESLVal _v1799 = $3323;
                  
                  return new ESLVal("JCmpIf",expToJExp(p),inner.apply(_v1799));
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(17072,17270)").add(ESLVal.list(_v1723)));
              }
              }
            else if(_v1723.isNil())
              return new ESLVal("JCmpList",expToJExp(e));
            else return error(new ESLVal("case error at Pos(17072,17270)").add(ESLVal.list(_v1723)));
            }
          }
        });
      
      public ESLVal get(String name) {
        switch(name) {
          case "inner": return inner;
          
          default: throw new Error("cannot find letrec binding");
        }
        }
      };
    ESLVal inner = letrec.get("inner");
    
      {ESLVal _v1724 = qs;
      
      if(_v1724.isCons())
      {ESLVal $3332 = _v1724.head();
        ESLVal $3333 = _v1724.tail();
        
        switch($3332.termName) {
        case "BQual": {ESLVal $3338 = $3332.termRef(0);
          ESLVal $3337 = $3332.termRef(1);
          ESLVal $3336 = $3332.termRef(2);
          
          switch($3337.termName) {
          case "PVar": {ESLVal $3341 = $3337.termRef(0);
            ESLVal $3340 = $3337.termRef(1);
            ESLVal $3339 = $3337.termRef(2);
            
            {ESLVal l = $3338;
            
            {ESLVal vl = $3341;
            
            {ESLVal n = $3340;
            
            {ESLVal t = $3339;
            
            {ESLVal listExp = $3336;
            
            {ESLVal _v1802 = $3333;
            
            return new ESLVal("JCmpOuter",n,expToJExp(listExp),inner.apply(_v1802));
          }
          }
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(17282,17479)").add(ESLVal.list(_v1724)));
        }
        }
      case "PQual": {ESLVal $3335 = $3332.termRef(0);
          ESLVal $3334 = $3332.termRef(1);
          
          {ESLVal l = $3335;
          
          {ESLVal p = $3334;
          
          {ESLVal _v1801 = $3333;
          
          return new ESLVal("JCmpIf",expToJExp(p),cmpToJCmp(e,_v1801));
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(17282,17479)").add(ESLVal.list(_v1724)));
      }
      }
    else if(_v1724.isNil())
      return new ESLVal("JCmpList",expToJExp(e));
    else return error(new ESLVal("case error at Pos(17282,17479)").add(ESLVal.list(_v1724)));
    }}
    
  }
  private static ESLVal cmpToJCmp = new ESLVal(new Function(new ESLVal("cmpToJCmp"),null) { public ESLVal apply(ESLVal... args) { return cmpToJCmp(args[0],args[1]); }});
  private static ESLVal refsToJExps(ESLVal refs) {
    
    {ESLVal _v1725 = refs;
      
      if(_v1725.isCons())
      {ESLVal $3342 = _v1725.head();
        ESLVal $3343 = _v1725.tail();
        
        switch($3342.termName) {
        case "VarDynamicRef": {ESLVal $3348 = $3342.termRef(0);
          ESLVal $3347 = $3342.termRef(1);
          
          switch($3347.termName) {
          case "Var": {ESLVal $3350 = $3347.termRef(0);
            ESLVal $3349 = $3347.termRef(1);
            
            {ESLVal l = $3348;
            
            {ESLVal vl = $3350;
            
            {ESLVal n = $3349;
            
            {ESLVal _v1797 = $3343;
            
            return refsToJExps(_v1797).cons(new ESLVal("JVar",n,$null));
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(17526,17767)").add(ESLVal.list(_v1725)));
        }
        }
      case "ActorDynamicRef": {ESLVal $3346 = $3342.termRef(0);
          ESLVal $3345 = $3342.termRef(1);
          ESLVal $3344 = $3342.termRef(2);
          
          {ESLVal l = $3346;
          
          {ESLVal e = $3345;
          
          {ESLVal n = $3344;
          
          {ESLVal _v1796 = $3343;
          
          return refsToJExps(_v1796).cons(new ESLVal("JRef",expToJExp(e),n));
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(17526,17767)").add(ESLVal.list(_v1725)));
      }
      }
    else if(_v1725.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(17526,17767)").add(ESLVal.list(_v1725)));
    }
  }
  private static ESLVal refsToJExps = new ESLVal(new Function(new ESLVal("refsToJExps"),null) { public ESLVal apply(ESLVal... args) { return refsToJExps(args[0]); }});
  private static ESLVal actToJava(ESLVal name,ESLVal decs,ESLVal exports,ESLVal parent,ESLVal defs,ESLVal init,ESLVal arms) {
    
    if(parent.eql($null).boolVal)
      return simpleActToJava(name,decs,exports,defs,init,arms);
      else
        return extendedActToJava(name,decs,exports,parent,defs,init,arms);
  }
  private static ESLVal actToJava = new ESLVal(new Function(new ESLVal("actToJava"),null) { public ESLVal apply(ESLVal... args) { return actToJava(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal wrapListeners(ESLVal exports,ESLVal body) {
    
    {ESLVal p0 = new ESLVal("Pos",$zero,$zero);
      ESLVal t0 = $null;
      
      if(member.apply(new ESLVal("observeState"),exports).boolVal)
      return new ESLVal("Block",p0,ESLVal.list(body,new ESLVal("Let",p0,ESLVal.list(new ESLVal("Binding",p0,new ESLVal("$s"),t0,t0,new ESLVal("Apply",p0,new ESLVal("Var",p0,new ESLVal("observeState")),$nil))),new ESLVal("For",p0,new ESLVal("PVar",p0,new ESLVal("$o"),t0),new ESLVal("Var",p0,new ESLVal("$observers")),new ESLVal("Case",p0,$nil,ESLVal.list(new ESLVal("Apply",p0,new ESLVal("Var",p0,new ESLVal("observeMessage")),ESLVal.list(new ESLVal("Var",p0,new ESLVal("$m"))))),ESLVal.list(new ESLVal("BArm",p0,ESLVal.list(new ESLVal("PTerm",p0,new ESLVal("Something"),$nil,ESLVal.list(new ESLVal("PVar",p0,new ESLVal("$x"),$null)))),new ESLVal("BoolExp",p0,$true),new ESLVal("Send",p0,new ESLVal("Var",p0,new ESLVal("$o")),new ESLVal("Term",p0,new ESLVal("Transition"),$nil,ESLVal.list(new ESLVal("Self",p0),new ESLVal("Now",p0),new ESLVal("Var",p0,new ESLVal("$x")),new ESLVal("Var",p0,new ESLVal("$s")))))),new ESLVal("BArm",p0,ESLVal.list(new ESLVal("PTerm",p0,new ESLVal("Nothing"),$nil,$nil)),new ESLVal("BoolExp",p0,$true),new ESLVal("Block",p0,$nil))))))));
      else
        return body;
    }
  }
  private static ESLVal wrapListeners = new ESLVal(new Function(new ESLVal("wrapListeners"),null) { public ESLVal apply(ESLVal... args) { return wrapListeners(args[0],args[1]); }});
  private static ESLVal simpleActToJava(ESLVal name,ESLVal decs,ESLVal exports,ESLVal defs,ESLVal init,ESLVal arms) {
    
    {ESLVal timeArms = select.apply(isTimeArm,arms);
      
      {ESLVal nonTimeArms = reject.apply(isTimeArm,arms);
      
      {ESLVal timeCommand = ((Supplier<ESLVal>)() -> { 
          if(timeArms.eql($nil).boolVal)
            return new ESLVal("JBlock",$nil);
            else
              return timeArmsToJCommand(timeArms);
        }).get();
      
      {ESLVal observers = ((Supplier<ESLVal>)() -> { 
          if(member.apply(new ESLVal("observeState"),exports).boolVal)
            return ESLVal.list(new ESLVal("JField",new ESLVal("$observers"),$null,new ESLVal("JList",$null,$nil)));
            else
              return $nil;
        }).get();
      
      {ESLVal addObserver = ((Supplier<ESLVal>)() -> { 
          if(member.apply(new ESLVal("observeState"),exports).boolVal)
            return ESLVal.list(addObserverJField);
            else
              return $nil;
        }).get();
      
      {ESLVal xAdd = ((Supplier<ESLVal>)() -> { 
          if(member.apply(new ESLVal("observeState"),exports).boolVal)
            return ESLVal.list(new ESLVal("addObserver"));
            else
              return $nil;
        }).get();
      
      {ESLVal f = new ESLVal("FunExp",new ESLVal("Pos",$zero,$zero),name,ESLVal.list(new ESLVal("Dec",new ESLVal("Pos",$zero,$zero),new ESLVal("$m"),$null,$null)),new ESLVal("VoidType",new ESLVal("Pos",$zero,$zero)),wrapListeners(exports,new ESLVal("Case",new ESLVal("Pos",$zero,$zero),$nil,ESLVal.list(new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("$m"))),nonTimeArms)));
      ESLVal methods = new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal m = $l0.head();
              $l0 = $l0.tail();
              if(isFunBind.apply(m).boolVal) {$v.add(m);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(defs);
      ESLVal fields = new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal f = $l0.head();
              $l0 = $l0.tail();
              if(isBinding.apply(f).boolVal) {$v.add(f);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(defs);
      
      return new ESLVal("JBehaviour",exports.add(xAdd),new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal b = $l0.head();
            $l0 = $l0.tail();
            $v.add(defToField(b));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(fields).add(observers.add(addObserver)),new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal m = $l0.head();
            $l0 = $l0.tail();
            $v.add(defToMethod(m));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(methods),expToJExp(init),expToJExp(f),timeCommand);
    }
    }
    }
    }
    }
    }
    }
  }
  private static ESLVal simpleActToJava = new ESLVal(new Function(new ESLVal("simpleActToJava"),null) { public ESLVal apply(ESLVal... args) { return simpleActToJava(args[0],args[1],args[2],args[3],args[4],args[5]); }});
  private static ESLVal extendedActToJava(ESLVal name,ESLVal decs,ESLVal exports,ESLVal parent,ESLVal defs,ESLVal init,ESLVal arms) {
    
    {ESLVal p0 = new ESLVal("Pos",$zero,$zero);
      
      {ESLVal timeSuper = new ESLVal("BArm",p0,ESLVal.list(new ESLVal("PTerm",p0,new ESLVal("Time"),$nil,ESLVal.list(new ESLVal("PVar",p0,new ESLVal("$"),$null)))),new ESLVal("BoolExp",p0,$true),new ESLVal("SendTimeSuper",p0));
      
      {ESLVal timeArms = select.apply(isTimeArm,arms).add(ESLVal.list(timeSuper));
      
      {ESLVal messageSuper = new ESLVal("BArm",p0,ESLVal.list(new ESLVal("PVar",p0,new ESLVal("$m"),$null)),new ESLVal("BoolExp",p0,$true),new ESLVal("Block",p0,ESLVal.list(new ESLVal("SendSuper",p0,new ESLVal("Var",p0,new ESLVal("$m"))),new ESLVal("NullExp",p0))));
      
      {ESLVal nonTimeArms = reject.apply(isTimeArm,arms).add(ESLVal.list(messageSuper));
      
      {ESLVal timeCommand = ((Supplier<ESLVal>)() -> { 
          if(timeArms.eql($nil).boolVal)
            return new ESLVal("JBlock",$nil);
            else
              return timeArmsToJCommand(timeArms);
        }).get();
      
      {ESLVal f = new ESLVal("FunExp",new ESLVal("Pos",$zero,$zero),name,ESLVal.list(new ESLVal("Dec",new ESLVal("Pos",$zero,$zero),new ESLVal("$m"),$null,$null)),new ESLVal("VoidType",new ESLVal("Pos",$zero,$zero)),wrapListeners(exports,new ESLVal("Case",new ESLVal("Pos",$zero,$zero),$nil,ESLVal.list(new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("$m"))),nonTimeArms)));
      ESLVal methods = new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal m = $l0.head();
              $l0 = $l0.tail();
              if(isFunBind.apply(m).boolVal) {$v.add(m);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(defs);
      ESLVal fields = new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal f = $l0.head();
              $l0 = $l0.tail();
              if(isBinding.apply(f).boolVal) {$v.add(f);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(defs);
      
      return new ESLVal("JExtendedBehaviour",exports,expToJExp(parent),new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal b = $l0.head();
            $l0 = $l0.tail();
            $v.add(defToField(b));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(fields),new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal m = $l0.head();
            $l0 = $l0.tail();
            $v.add(defToMethod(m));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(methods),expToJExp(init),expToJExp(f),timeCommand);
    }
    }
    }
    }
    }
    }
    }
  }
  private static ESLVal extendedActToJava = new ESLVal(new Function(new ESLVal("extendedActToJava"),null) { public ESLVal apply(ESLVal... args) { return extendedActToJava(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal isTimeArm(ESLVal a) {
    
    {ESLVal _v1726 = a;
      
      switch(_v1726.termName) {
      case "BArm": {ESLVal $3354 = _v1726.termRef(0);
        ESLVal $3353 = _v1726.termRef(1);
        ESLVal $3352 = _v1726.termRef(2);
        ESLVal $3351 = _v1726.termRef(3);
        
        if($3353.isCons())
        {ESLVal $3355 = $3353.head();
          ESLVal $3356 = $3353.tail();
          
          switch($3355.termName) {
          case "PTerm": {ESLVal $3360 = $3355.termRef(0);
            ESLVal $3359 = $3355.termRef(1);
            ESLVal $3358 = $3355.termRef(2);
            ESLVal $3357 = $3355.termRef(3);
            
            switch($3359.strVal) {
            case "Time": if($3356.isCons())
              {ESLVal $3361 = $3356.head();
                ESLVal $3362 = $3356.tail();
                
                {ESLVal _v1789 = _v1726;
                
                return $false;
              }
              }
            else if($3356.isNil())
              {ESLVal l = $3354;
                
                {ESLVal pl = $3360;
                
                {ESLVal ts = $3358;
                
                {ESLVal ps = $3357;
                
                {ESLVal g = $3352;
                
                {ESLVal e = $3351;
                
                return $true;
              }
              }
              }
              }
              }
              }
            else {ESLVal _v1790 = _v1726;
                
                return $false;
              }
            default: {ESLVal _v1791 = _v1726;
              
              return $false;
            }
          }
          }
          default: {ESLVal _v1792 = _v1726;
            
            return $false;
          }
        }
        }
      else if($3353.isNil())
        {ESLVal _v1793 = _v1726;
          
          return $false;
        }
      else {ESLVal _v1794 = _v1726;
          
          return $false;
        }
      }
      default: {ESLVal _v1795 = _v1726;
        
        return $false;
      }
    }
    }
  }
  private static ESLVal isTimeArm = new ESLVal(new Function(new ESLVal("isTimeArm"),null) { public ESLVal apply(ESLVal... args) { return isTimeArm(args[0]); }});
  private static ESLVal timeArmsToJCommand(ESLVal arms) {
    
    {ESLVal _v1727 = arms;
      
      if(_v1727.isCons())
      {ESLVal $3363 = _v1727.head();
        ESLVal $3364 = _v1727.tail();
        
        switch($3363.termName) {
        case "BArm": {ESLVal $3368 = $3363.termRef(0);
          ESLVal $3367 = $3363.termRef(1);
          ESLVal $3366 = $3363.termRef(2);
          ESLVal $3365 = $3363.termRef(3);
          
          if($3367.isCons())
          {ESLVal $3369 = $3367.head();
            ESLVal $3370 = $3367.tail();
            
            switch($3369.termName) {
            case "PTerm": {ESLVal $3374 = $3369.termRef(0);
              ESLVal $3373 = $3369.termRef(1);
              ESLVal $3372 = $3369.termRef(2);
              ESLVal $3371 = $3369.termRef(3);
              
              switch($3373.strVal) {
              case "Time": if($3372.isCons())
                {ESLVal $3375 = $3372.head();
                  ESLVal $3376 = $3372.tail();
                  
                  return error(new ESLVal("case error at Pos(21694,22224)").add(ESLVal.list(_v1727)));
                }
              else if($3372.isNil())
                if($3371.isCons())
                  {ESLVal $3377 = $3371.head();
                    ESLVal $3378 = $3371.tail();
                    
                    switch($3377.termName) {
                    case "PVar": {ESLVal $3389 = $3377.termRef(0);
                      ESLVal $3388 = $3377.termRef(1);
                      ESLVal $3387 = $3377.termRef(2);
                      
                      if($3378.isCons())
                      {ESLVal $3390 = $3378.head();
                        ESLVal $3391 = $3378.tail();
                        
                        return error(new ESLVal("case error at Pos(21694,22224)").add(ESLVal.list(_v1727)));
                      }
                    else if($3378.isNil())
                      if($3370.isCons())
                        {ESLVal $3392 = $3370.head();
                          ESLVal $3393 = $3370.tail();
                          
                          return error(new ESLVal("case error at Pos(21694,22224)").add(ESLVal.list(_v1727)));
                        }
                      else if($3370.isNil())
                        {ESLVal l = $3368;
                          
                          {ESLVal tl = $3374;
                          
                          {ESLVal vl = $3389;
                          
                          {ESLVal n = $3388;
                          
                          {ESLVal t = $3387;
                          
                          {ESLVal g = $3366;
                          
                          {ESLVal e = $3365;
                          
                          {ESLVal _v1788 = $3364;
                          
                          return new ESLVal("JLet",ESLVal.list(new ESLVal("JField",n,$null,new ESLVal("JVar",new ESLVal("$t"),$null))),new ESLVal("JIfCommand",expToJExp(g),expToJCommand(e,$false),timeArmsToJCommand(_v1788)));
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                      else return error(new ESLVal("case error at Pos(21694,22224)").add(ESLVal.list(_v1727)));
                    else return error(new ESLVal("case error at Pos(21694,22224)").add(ESLVal.list(_v1727)));
                    }
                  case "PInt": {ESLVal $3380 = $3377.termRef(0);
                      ESLVal $3379 = $3377.termRef(1);
                      
                      if($3378.isCons())
                      {ESLVal $3381 = $3378.head();
                        ESLVal $3382 = $3378.tail();
                        
                        return error(new ESLVal("case error at Pos(21694,22224)").add(ESLVal.list(_v1727)));
                      }
                    else if($3378.isNil())
                      if($3370.isCons())
                        {ESLVal $3383 = $3370.head();
                          ESLVal $3384 = $3370.tail();
                          
                          return error(new ESLVal("case error at Pos(21694,22224)").add(ESLVal.list(_v1727)));
                        }
                      else if($3370.isNil())
                        switch($3366.termName) {
                          case "BoolExp": {ESLVal $3386 = $3366.termRef(0);
                            ESLVal $3385 = $3366.termRef(1);
                            
                            switch($3385.boolVal ? 1 : 0) {
                            case 1: {ESLVal l = $3368;
                              
                              {ESLVal tl = $3374;
                              
                              {ESLVal vl = $3380;
                              
                              {ESLVal n = $3379;
                              
                              {ESLVal bl = $3386;
                              
                              {ESLVal e = $3365;
                              
                              {ESLVal _v1787 = $3364;
                              
                              return new ESLVal("JIfCommand",new ESLVal("JBinExp",new ESLVal("JVar",new ESLVal("$t"),$null),new ESLVal("eq"),new ESLVal("JConstExp",new ESLVal("JConstInt",n))),expToJCommand(e,$false),timeArmsToJCommand(_v1787));
                            }
                            }
                            }
                            }
                            }
                            }
                            }
                            default: return error(new ESLVal("case error at Pos(21694,22224)").add(ESLVal.list(_v1727)));
                          }
                          }
                          default: return error(new ESLVal("case error at Pos(21694,22224)").add(ESLVal.list(_v1727)));
                        }
                      else return error(new ESLVal("case error at Pos(21694,22224)").add(ESLVal.list(_v1727)));
                    else return error(new ESLVal("case error at Pos(21694,22224)").add(ESLVal.list(_v1727)));
                    }
                    default: return error(new ESLVal("case error at Pos(21694,22224)").add(ESLVal.list(_v1727)));
                  }
                  }
                else if($3371.isNil())
                  return error(new ESLVal("case error at Pos(21694,22224)").add(ESLVal.list(_v1727)));
                else return error(new ESLVal("case error at Pos(21694,22224)").add(ESLVal.list(_v1727)));
              else return error(new ESLVal("case error at Pos(21694,22224)").add(ESLVal.list(_v1727)));
              default: return error(new ESLVal("case error at Pos(21694,22224)").add(ESLVal.list(_v1727)));
            }
            }
            default: return error(new ESLVal("case error at Pos(21694,22224)").add(ESLVal.list(_v1727)));
          }
          }
        else if($3367.isNil())
          return error(new ESLVal("case error at Pos(21694,22224)").add(ESLVal.list(_v1727)));
        else return error(new ESLVal("case error at Pos(21694,22224)").add(ESLVal.list(_v1727)));
        }
        default: return error(new ESLVal("case error at Pos(21694,22224)").add(ESLVal.list(_v1727)));
      }
      }
    else if(_v1727.isNil())
      return new ESLVal("JBlock",$nil);
    else return error(new ESLVal("case error at Pos(21694,22224)").add(ESLVal.list(_v1727)));
    }
  }
  private static ESLVal timeArmsToJCommand = new ESLVal(new Function(new ESLVal("timeArmsToJCommand"),null) { public ESLVal apply(ESLVal... args) { return timeArmsToJCommand(args[0]); }});
  private static ESLVal cmpToJExp(ESLVal e,ESLVal qs) {
    
    {ESLVal _v1728 = qs;
      
      if(_v1728.isCons())
      {ESLVal $3394 = _v1728.head();
        ESLVal $3395 = _v1728.tail();
        
        switch($3394.termName) {
        case "BQual": {ESLVal $3400 = $3394.termRef(0);
          ESLVal $3399 = $3394.termRef(1);
          ESLVal $3398 = $3394.termRef(2);
          
          {ESLVal l = $3400;
          
          {ESLVal p = $3399;
          
          {ESLVal v = $3398;
          
          {ESLVal _v1786 = $3395;
          
          {ESLVal f = new ESLVal("FunExp",new ESLVal("Pos",$zero,$zero),new ESLVal("StrExp",new ESLVal("Pos",$zero,$zero),new ESLVal("qual")),ESLVal.list(new ESLVal("Dec",new ESLVal("Pos",$zero,$zero),new ESLVal("$qualArg"),$null,$null)),$null,new ESLVal("Case",new ESLVal("Pos",$zero,$zero),$nil,ESLVal.list(new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("$qualArg"))),ESLVal.list(new ESLVal("BArm",new ESLVal("Pos",$zero,$zero),ESLVal.list(p),new ESLVal("BoolExp",new ESLVal("Pos",$zero,$zero),$true),new ESLVal("List",new ESLVal("Pos",$zero,$zero),ESLVal.list(new ESLVal("Cmp",new ESLVal("Pos",$zero,$zero),e,_v1786)))),new ESLVal("BArm",new ESLVal("Pos",$zero,$zero),ESLVal.list(new ESLVal("PVar",new ESLVal("Pos",$zero,$zero),new ESLVal("_0"),$null)),new ESLVal("BoolExp",new ESLVal("Pos",$zero,$zero),$true),new ESLVal("List",new ESLVal("Pos",$zero,$zero),$nil)))));
          
          return new ESLVal("JFlatten",new ESLVal("JFlatten",new ESLVal("JMapFun",expToJExp(f),expToJExp(v))));
        }
        }
        }
        }
        }
        }
      case "PQual": {ESLVal $3397 = $3394.termRef(0);
          ESLVal $3396 = $3394.termRef(1);
          
          {ESLVal l = $3397;
          
          {ESLVal p = $3396;
          
          {ESLVal _v1785 = $3395;
          
          return new ESLVal("JIfExp",expToJExp(p),cmpToJExp(e,_v1785),new ESLVal("JNil",$null));
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(22271,22939)").add(ESLVal.list(_v1728)));
      }
      }
    else if(_v1728.isNil())
      return new ESLVal("JList",$null,ESLVal.list(expToJExp(e)));
    else return error(new ESLVal("case error at Pos(22271,22939)").add(ESLVal.list(_v1728)));
    }
  }
  private static ESLVal cmpToJExp = new ESLVal(new Function(new ESLVal("cmpToJExp"),null) { public ESLVal apply(ESLVal... args) { return cmpToJExp(args[0],args[1]); }});
  public static ESLVal moduleToJava(ESLVal module) {
    
    {ESLVal _v1729 = module;
      
      switch(_v1729.termName) {
      case "Module": {ESLVal $3407 = _v1729.termRef(0);
        ESLVal $3406 = _v1729.termRef(1);
        ESLVal $3405 = _v1729.termRef(2);
        ESLVal $3404 = _v1729.termRef(3);
        ESLVal $3403 = _v1729.termRef(4);
        ESLVal $3402 = _v1729.termRef(5);
        ESLVal $3401 = _v1729.termRef(6);
        
        {ESLVal path = $3407;
        
        {ESLVal name = $3406;
        
        {ESLVal exports = $3405;
        
        {ESLVal imports = $3404;
        
        {ESLVal x = $3403;
        
        {ESLVal y = $3402;
        
        {ESLVal defs = $3401;
        
        {ESLVal _v1784 = expandFunDefs.apply(mergeFunDefs.apply(defs));
        
        {ESLVal methods = new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal m = $l0.head();
                $l0 = $l0.tail();
                if(isFunBind.apply(m).boolVal) {$v.add(m);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(_v1784);
        ESLVal fields = new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal f = $l0.head();
                $l0 = $l0.tail();
                if(isBinding.apply(f).boolVal) {$v.add(f);
          }
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(_v1784);
        
        return renameJVarsModule(new ESLVal("JModule",name,exports,imports,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal m = $l0.head();
              $l0 = $l0.tail();
              $v.add(defToMethod(m));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(methods),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal d = $l0.head();
              $l0 = $l0.tail();
              $v.add(defToField(d));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(fields)));
      }
      }
      }
      }
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(22977,23439)").add(ESLVal.list(_v1729)));
    }
    }
  }
  public static ESLVal moduleToJava = new ESLVal(new Function(new ESLVal("moduleToJava"),null) { public ESLVal apply(ESLVal... args) { return moduleToJava(args[0]); }});
  private static ESLVal renameJVarsModule(ESLVal m) {
    
    {ESLVal _v1730 = m;
      
      switch(_v1730.termName) {
      case "JModule": {ESLVal $3412 = _v1730.termRef(0);
        ESLVal $3411 = _v1730.termRef(1);
        ESLVal $3410 = _v1730.termRef(2);
        ESLVal $3409 = _v1730.termRef(3);
        ESLVal $3408 = _v1730.termRef(4);
        
        {ESLVal name = $3412;
        
        {ESLVal exports = $3411;
        
        {ESLVal imports = $3410;
        
        {ESLVal ms = $3409;
        
        {ESLVal fs = $3408;
        
        {ESLVal fieldNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1731 = $qualArg;
                
                switch(_v1731.termName) {
                case "JField": {ESLVal $3415 = _v1731.termRef(0);
                  ESLVal $3414 = _v1731.termRef(1);
                  ESLVal $3413 = _v1731.termRef(2);
                  
                  {ESLVal n = $3415;
                  
                  {ESLVal t = $3414;
                  
                  {ESLVal e = $3413;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1731;
                  
                  return $nil;
                }
              }
              }
            }
          }).map(fs).flatten().flatten();
        
        {ESLVal newFields = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1732 = $qualArg;
                
                switch(_v1732.termName) {
                case "JField": {ESLVal $3418 = _v1732.termRef(0);
                  ESLVal $3417 = _v1732.termRef(1);
                  ESLVal $3416 = _v1732.termRef(2);
                  
                  {ESLVal n = $3418;
                  
                  {ESLVal t = $3417;
                  
                  {ESLVal e = $3416;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp(e,fieldNames,emptyTable))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1732;
                  
                  return $nil;
                }
              }
              }
            }
          }).map(fs).flatten().flatten();
        ESLVal newMethods = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1733 = $qualArg;
                
                switch(_v1733.termName) {
                case "JMethod": {ESLVal $3421 = _v1733.termRef(0);
                  ESLVal $3420 = _v1733.termRef(1);
                  ESLVal $3419 = _v1733.termRef(2);
                  
                  {ESLVal n = $3421;
                  
                  {ESLVal args = $3420;
                  
                  {ESLVal body = $3419;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JMethod",n,args,renameJVarsCommand(body,fieldNames.add(new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      ESLVal _v1782 = $args[0];
                  {ESLVal _v1734 = _v1782;
                        
                        switch(_v1734.termName) {
                        case "JDec": {ESLVal $3423 = _v1734.termRef(0);
                          ESLVal $3422 = _v1734.termRef(1);
                          
                          {ESLVal _v1783 = $3423;
                          
                          {ESLVal t = $3422;
                          
                          return ESLVal.list(ESLVal.list(_v1783));
                        }
                        }
                        }
                        default: {ESLVal _0 = _v1734;
                          
                          return $nil;
                        }
                      }
                      }
                    }
                  }).map(args).flatten().flatten()),emptyTable))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1733;
                  
                  return $nil;
                }
              }
              }
            }
          }).map(ms).flatten().flatten();
        
        return new ESLVal("JModule",name,exports,imports,newMethods,newFields);
      }
      }
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(23479,24032)").add(ESLVal.list(_v1730)));
    }
    }
  }
  private static ESLVal renameJVarsModule = new ESLVal(new Function(new ESLVal("renameJVarsModule"),null) { public ESLVal apply(ESLVal... args) { return renameJVarsModule(args[0]); }});
  private static ESLVal renameJVarsExp(ESLVal e,ESLVal vars,ESLVal env) {
    
    {ESLVal _v1735 = e;
      
      switch(_v1735.termName) {
      case "JFun": {ESLVal $3505 = _v1735.termRef(0);
        ESLVal $3504 = _v1735.termRef(1);
        ESLVal $3503 = _v1735.termRef(2);
        ESLVal $3502 = _v1735.termRef(3);
        
        {ESLVal v0 = $3505;
        
        {ESLVal v1 = $3504;
        
        {ESLVal v2 = $3503;
        
        {ESLVal v3 = $3502;
        
        {ESLVal boundNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1739 = $qualArg;
                
                switch(_v1739.termName) {
                case "JDec": {ESLVal $3516 = _v1739.termRef(0);
                  ESLVal $3515 = _v1739.termRef(1);
                  
                  {ESLVal n = $3516;
                  
                  {ESLVal t = $3515;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                default: {ESLVal _0 = _v1739;
                  
                  return $nil;
                }
              }
              }
            }
          }).map(v1).flatten().flatten();
        
        if(exists.apply(new ESLVal(new Function(new ESLVal("fun426"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal n = $args[0];
      return member.apply(n,boundNames);
        }
      }),vars).boolVal)
        {ESLVal newNames = new java.util.function.Function<ESLVal,ESLVal>() {
              public ESLVal apply(ESLVal $l0) {
                ESLVal $a = $nil;
                java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                while(!$l0.isNil()) { 
                  ESLVal n = $l0.head();
                  $l0 = $l0.tail();
                  $v.add(newName());
                }
                for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                return $a;
              }}.apply(boundNames);
          
          {ESLVal env1 = addEntries.apply(boundNames,newNames,env);
          
          return new ESLVal("JFun",v0,new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal n = $l0.head();
                $l0 = $l0.tail();
                $v.add(new ESLVal("JDec",n,$null));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(newNames),v2,renameJVarsCommand(v3,boundNames.add(vars),env1));
        }
        }
        else
          return new ESLVal("JFun",v0,v1,v2,renameJVarsCommand(v3,boundNames.add(vars),env));
      }
      }
      }
      }
      }
      }
    case "JApply": {ESLVal $3501 = _v1735.termRef(0);
        ESLVal $3500 = _v1735.termRef(1);
        
        {ESLVal v0 = $3501;
        
        {ESLVal v1 = $3500;
        
        return new ESLVal("JApply",renameJVarsExp(v0,vars,env),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal v = $l0.head();
              $l0 = $l0.tail();
              $v.add(renameJVarsExp(v,vars,env));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1));
      }
      }
      }
    case "JArrayRef": {ESLVal $3499 = _v1735.termRef(0);
        ESLVal $3498 = _v1735.termRef(1);
        
        {ESLVal a = $3499;
        
        {ESLVal i = $3498;
        
        return new ESLVal("JArrayRef",renameJVarsExp(a,vars,env),renameJVarsExp(i,vars,env));
      }
      }
      }
    case "JArrayUpdate": {ESLVal $3497 = _v1735.termRef(0);
        ESLVal $3496 = _v1735.termRef(1);
        ESLVal $3495 = _v1735.termRef(2);
        
        {ESLVal a = $3497;
        
        {ESLVal i = $3496;
        
        {ESLVal v = $3495;
        
        return new ESLVal("JArrayUpdate",renameJVarsExp(a,vars,env),renameJVarsExp(i,vars,env),renameJVarsExp(v,vars,env));
      }
      }
      }
      }
    case "JBecome": {ESLVal $3494 = _v1735.termRef(0);
        ESLVal $3493 = _v1735.termRef(1);
        
        {ESLVal _v1781 = $3494;
        
        {ESLVal es = $3493;
        
        return new ESLVal("JBecome",renameJVarsExp(_v1781,vars,env),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal v = $l0.head();
              $l0 = $l0.tail();
              $v.add(renameJVarsExp(v,vars,env));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(es));
      }
      }
      }
    case "JBinExp": {ESLVal $3492 = _v1735.termRef(0);
        ESLVal $3491 = _v1735.termRef(1);
        ESLVal $3490 = _v1735.termRef(2);
        
        {ESLVal v0 = $3492;
        
        {ESLVal v1 = $3491;
        
        {ESLVal v2 = $3490;
        
        return new ESLVal("JBinExp",renameJVarsExp(v0,vars,env),v1,renameJVarsExp(v2,vars,env));
      }
      }
      }
      }
    case "JCommandExp": {ESLVal $3489 = _v1735.termRef(0);
        ESLVal $3488 = _v1735.termRef(1);
        
        {ESLVal v0 = $3489;
        
        {ESLVal v1 = $3488;
        
        return new ESLVal("JCommandExp",renameJVarsCommand(v0,vars,env),v1);
      }
      }
      }
    case "JIfExp": {ESLVal $3487 = _v1735.termRef(0);
        ESLVal $3486 = _v1735.termRef(1);
        ESLVal $3485 = _v1735.termRef(2);
        
        {ESLVal v0 = $3487;
        
        {ESLVal v1 = $3486;
        
        {ESLVal v2 = $3485;
        
        return new ESLVal("JIfExp",renameJVarsExp(v0,vars,env),renameJVarsExp(v1,vars,env),renameJVarsExp(v2,vars,env));
      }
      }
      }
      }
    case "JConstExp": {ESLVal $3484 = _v1735.termRef(0);
        
        {ESLVal v0 = $3484;
        
        return e;
      }
      }
    case "JTerm": {ESLVal $3483 = _v1735.termRef(0);
        ESLVal $3482 = _v1735.termRef(1);
        
        {ESLVal v0 = $3483;
        
        {ESLVal v1 = $3482;
        
        return new ESLVal("JTerm",v0,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal v = $l0.head();
              $l0 = $l0.tail();
              $v.add(renameJVarsExp(v,vars,env));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1));
      }
      }
      }
    case "JTermRef": {ESLVal $3481 = _v1735.termRef(0);
        ESLVal $3480 = _v1735.termRef(1);
        
        {ESLVal v0 = $3481;
        
        {ESLVal v1 = $3480;
        
        return new ESLVal("JTermRef",renameJVarsExp(v0,vars,env),v1);
      }
      }
      }
    case "JList": {ESLVal $3479 = _v1735.termRef(0);
        ESLVal $3478 = _v1735.termRef(1);
        
        {ESLVal v0 = $3479;
        
        {ESLVal v1 = $3478;
        
        return new ESLVal("JList",v0,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal v = $l0.head();
              $l0 = $l0.tail();
              $v.add(renameJVarsExp(v,vars,env));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1));
      }
      }
      }
    case "JSet": {ESLVal $3477 = _v1735.termRef(0);
        ESLVal $3476 = _v1735.termRef(1);
        
        {ESLVal v0 = $3477;
        
        {ESLVal v1 = $3476;
        
        return new ESLVal("JSet",v0,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal v = $l0.head();
              $l0 = $l0.tail();
              $v.add(renameJVarsExp(v,vars,env));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1));
      }
      }
      }
    case "JBag": {ESLVal $3475 = _v1735.termRef(0);
        ESLVal $3474 = _v1735.termRef(1);
        
        {ESLVal v0 = $3475;
        
        {ESLVal v1 = $3474;
        
        return new ESLVal("JBag",v0,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal v = $l0.head();
              $l0 = $l0.tail();
              $v.add(renameJVarsExp(v,vars,env));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v1));
      }
      }
      }
    case "JNil": {ESLVal $3473 = _v1735.termRef(0);
        
        {ESLVal v0 = $3473;
        
        return e;
      }
      }
    case "JNow": {
        return e;
      }
    case "JVar": {ESLVal $3472 = _v1735.termRef(0);
        ESLVal $3471 = _v1735.termRef(1);
        
        {ESLVal v0 = $3472;
        
        {ESLVal v1 = $3471;
        
        if(hasEntry.apply(v0,env).boolVal)
        return new ESLVal("JVar",lookup.apply(v0,env),v1);
        else
          return e;
      }
      }
      }
    case "JNull": {
        return e;
      }
    case "JError": {ESLVal $3470 = _v1735.termRef(0);
        
        {ESLVal v0 = $3470;
        
        return new ESLVal("JError",renameJVarsExp(v0,vars,env));
      }
      }
    case "JHead": {ESLVal $3469 = _v1735.termRef(0);
        
        {ESLVal v0 = $3469;
        
        return new ESLVal("JHead",renameJVarsExp(v0,vars,env));
      }
      }
    case "JTail": {ESLVal $3468 = _v1735.termRef(0);
        
        {ESLVal v0 = $3468;
        
        return new ESLVal("JTail",renameJVarsExp(v0,vars,env));
      }
      }
    case "JCastp": {ESLVal $3467 = _v1735.termRef(0);
        ESLVal $3466 = _v1735.termRef(1);
        ESLVal $3465 = _v1735.termRef(2);
        
        {ESLVal v0 = $3467;
        
        {ESLVal v1 = $3466;
        
        {ESLVal v2 = $3465;
        
        return new ESLVal("JCastp",v0,v1,renameJVarsExp(v2,vars,env));
      }
      }
      }
      }
    case "JCast": {ESLVal $3464 = _v1735.termRef(0);
        ESLVal $3463 = _v1735.termRef(1);
        
        {ESLVal v0 = $3464;
        
        {ESLVal v1 = $3463;
        
        return new ESLVal("JCast",v0,renameJVarsExp(v1,vars,env));
      }
      }
      }
    case "JCmpExp": {ESLVal $3462 = _v1735.termRef(0);
        
        {ESLVal cmp = $3462;
        
        return new ESLVal("JCmpExp",renameJVarsCmp(cmp,vars,env));
      }
      }
    case "JNot": {ESLVal $3461 = _v1735.termRef(0);
        
        {ESLVal _v1780 = $3461;
        
        return new ESLVal("JNot",renameJVarsExp(_v1780,vars,env));
      }
      }
    case "JNew": {ESLVal $3460 = _v1735.termRef(0);
        ESLVal $3459 = _v1735.termRef(1);
        
        {ESLVal b = $3460;
        
        {ESLVal args = $3459;
        
        return new ESLVal("JNew",renameJVarsExp(b,vars,env),new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal a = $l0.head();
              $l0 = $l0.tail();
              $v.add(renameJVarsExp(a,vars,env));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(args));
      }
      }
      }
    case "JNewArray": {ESLVal $3458 = _v1735.termRef(0);
        
        {ESLVal b = $3458;
        
        return new ESLVal("JNewArray",renameJVarsExp(b,vars,env));
      }
      }
    case "JNewJava": {ESLVal $3457 = _v1735.termRef(0);
        ESLVal $3456 = _v1735.termRef(1);
        
        {ESLVal n = $3457;
        
        {ESLVal args = $3456;
        
        return new ESLVal("JNewJava",n,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal a = $l0.head();
              $l0 = $l0.tail();
              $v.add(renameJVarsExp(a,vars,env));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(args));
      }
      }
      }
    case "JNewTable": {
        return new ESLVal("JNewTable",new ESLVal[]{});
      }
    case "JMapFun": {ESLVal $3455 = _v1735.termRef(0);
        ESLVal $3454 = _v1735.termRef(1);
        
        {ESLVal f = $3455;
        
        {ESLVal l = $3454;
        
        return new ESLVal("JMapFun",renameJVarsExp(f,vars,env),renameJVarsExp(l,vars,env));
      }
      }
      }
    case "JRecord": {ESLVal $3453 = _v1735.termRef(0);
        
        {ESLVal fs = $3453;
        
        return new ESLVal("JRecord",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v1738 = $qualArg;
              
              switch(_v1738.termName) {
              case "JField": {ESLVal $3514 = _v1738.termRef(0);
                ESLVal $3513 = _v1738.termRef(1);
                ESLVal $3512 = _v1738.termRef(2);
                
                {ESLVal n = $3514;
                
                {ESLVal t = $3513;
                
                {ESLVal _v1779 = $3512;
                
                return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp(_v1779,vars,env))));
              }
              }
              }
              }
              default: {ESLVal _0 = _v1738;
                
                return $nil;
              }
            }
            }
          }
        }).map(fs).flatten().flatten());
      }
      }
    case "JFlatten": {ESLVal $3452 = _v1735.termRef(0);
        
        {ESLVal _v1778 = $3452;
        
        return new ESLVal("JFlatten",renameJVarsExp(_v1778,vars,env));
      }
      }
    case "JSend": {ESLVal $3451 = _v1735.termRef(0);
        ESLVal $3450 = _v1735.termRef(1);
        ESLVal $3449 = _v1735.termRef(2);
        
        {ESLVal _v1777 = $3451;
        
        {ESLVal n = $3450;
        
        {ESLVal es = $3449;
        
        return new ESLVal("JSend",renameJVarsExp(_v1777,vars,env),n,new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(renameJVarsExp(e,vars,env));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(es));
      }
      }
      }
      }
    case "JSendSuper": {ESLVal $3448 = _v1735.termRef(0);
        
        {ESLVal _v1776 = $3448;
        
        return new ESLVal("JSendSuper",renameJVarsExp(_v1776,vars,env));
      }
      }
    case "JSendTimeSuper": {
        return new ESLVal("JSendTimeSuper",new ESLVal[]{});
      }
    case "JSelf": {
        return new ESLVal("JSelf",new ESLVal[]{});
      }
    case "JRef": {ESLVal $3447 = _v1735.termRef(0);
        ESLVal $3446 = _v1735.termRef(1);
        
        {ESLVal _v1775 = $3447;
        
        {ESLVal n = $3446;
        
        return new ESLVal("JRef",renameJVarsExp(_v1775,vars,env),n);
      }
      }
      }
    case "JRefSuper": {ESLVal $3445 = _v1735.termRef(0);
        
        {ESLVal n = $3445;
        
        return new ESLVal("JRefSuper",n);
      }
      }
    case "JBehaviour": {ESLVal $3444 = _v1735.termRef(0);
        ESLVal $3443 = _v1735.termRef(1);
        ESLVal $3442 = _v1735.termRef(2);
        ESLVal $3441 = _v1735.termRef(3);
        ESLVal $3440 = _v1735.termRef(4);
        ESLVal $3439 = _v1735.termRef(5);
        
        {ESLVal es = $3444;
        
        {ESLVal fs = $3443;
        
        {ESLVal methods = $3442;
        
        {ESLVal init = $3441;
        
        {ESLVal handler = $3440;
        
        {ESLVal time = $3439;
        
        {ESLVal newFields = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1737 = $qualArg;
                
                switch(_v1737.termName) {
                case "JField": {ESLVal $3511 = _v1737.termRef(0);
                  ESLVal $3510 = _v1737.termRef(1);
                  ESLVal $3509 = _v1737.termRef(2);
                  
                  {ESLVal n = $3511;
                  
                  {ESLVal t = $3510;
                  
                  {ESLVal _v1774 = $3509;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp(_v1774,vars,env))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1737;
                  
                  return $nil;
                }
              }
              }
            }
          }).map(fs).flatten().flatten();
        ESLVal newMethods = new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal m = $l0.head();
                $l0 = $l0.tail();
                $v.add(renameJVarsMethod(m,vars,env));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(methods);
        
        return new ESLVal("JBehaviour",es,newFields,newMethods,renameJVarsExp(init,vars,env),renameJVarsExp(handler,vars,env),renameJVarsCommand(time,vars,env));
      }
      }
      }
      }
      }
      }
      }
      }
    case "JExtendedBehaviour": {ESLVal $3438 = _v1735.termRef(0);
        ESLVal $3437 = _v1735.termRef(1);
        ESLVal $3436 = _v1735.termRef(2);
        ESLVal $3435 = _v1735.termRef(3);
        ESLVal $3434 = _v1735.termRef(4);
        ESLVal $3433 = _v1735.termRef(5);
        ESLVal $3432 = _v1735.termRef(6);
        
        {ESLVal es = $3438;
        
        {ESLVal parent = $3437;
        
        {ESLVal fs = $3436;
        
        {ESLVal methods = $3435;
        
        {ESLVal init = $3434;
        
        {ESLVal handler = $3433;
        
        {ESLVal time = $3432;
        
        {ESLVal newFields = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1736 = $qualArg;
                
                switch(_v1736.termName) {
                case "JField": {ESLVal $3508 = _v1736.termRef(0);
                  ESLVal $3507 = _v1736.termRef(1);
                  ESLVal $3506 = _v1736.termRef(2);
                  
                  {ESLVal n = $3508;
                  
                  {ESLVal t = $3507;
                  
                  {ESLVal _v1773 = $3506;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp(_v1773,vars,env))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1736;
                  
                  return $nil;
                }
              }
              }
            }
          }).map(fs).flatten().flatten();
        ESLVal newMethods = new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal m = $l0.head();
                $l0 = $l0.tail();
                $v.add(renameJVarsMethod(m,vars,env));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(methods);
        
        return new ESLVal("JExtendedBehaviour",es,renameJVarsExp(parent,vars,env),newFields,newMethods,renameJVarsExp(init,vars,env),renameJVarsExp(handler,vars,env),renameJVarsCommand(time,vars,env));
      }
      }
      }
      }
      }
      }
      }
      }
      }
    case "JTry": {ESLVal $3431 = _v1735.termRef(0);
        ESLVal $3430 = _v1735.termRef(1);
        ESLVal $3429 = _v1735.termRef(2);
        
        {ESLVal _v1772 = $3431;
        
        {ESLVal n = $3430;
        
        {ESLVal c = $3429;
        
        return new ESLVal("JTry",renameJVarsExp(_v1772,vars,env),n,renameJVarsCommand(c,vars,env));
      }
      }
      }
      }
    case "JProbably": {ESLVal $3428 = _v1735.termRef(0);
        ESLVal $3427 = _v1735.termRef(1);
        ESLVal $3426 = _v1735.termRef(2);
        
        {ESLVal _v1771 = $3428;
        
        {ESLVal e1 = $3427;
        
        {ESLVal e2 = $3426;
        
        return new ESLVal("JProbably",renameJVarsExp(_v1771,vars,env),renameJVarsExp(e1,vars,env),renameJVarsExp(e2,vars,env));
      }
      }
      }
      }
    case "JGrab": {ESLVal $3425 = _v1735.termRef(0);
        ESLVal $3424 = _v1735.termRef(1);
        
        {ESLVal es = $3425;
        
        {ESLVal c = $3424;
        
        return new ESLVal("JGrab",new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal e = $l0.head();
              $l0 = $l0.tail();
              $v.add(renameJVarsExp(e,vars,env));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(es),renameJVarsExp(c,vars,env));
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(24100,29054)").add(ESLVal.list(_v1735)));
    }
    }
  }
  private static ESLVal renameJVarsExp = new ESLVal(new Function(new ESLVal("renameJVarsExp"),null) { public ESLVal apply(ESLVal... args) { return renameJVarsExp(args[0],args[1],args[2]); }});
  private static ESLVal renameJVarsMethod(ESLVal m,ESLVal vars,ESLVal env) {
    
    {ESLVal _v1740 = m;
      
      switch(_v1740.termName) {
      case "JMethod": {ESLVal $3519 = _v1740.termRef(0);
        ESLVal $3518 = _v1740.termRef(1);
        ESLVal $3517 = _v1740.termRef(2);
        
        {ESLVal name = $3519;
        
        {ESLVal args = $3518;
        
        {ESLVal body = $3517;
        
        {ESLVal boundNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1741 = $qualArg;
                
                switch(_v1741.termName) {
                case "JDec": {ESLVal $3521 = _v1741.termRef(0);
                  ESLVal $3520 = _v1741.termRef(1);
                  
                  {ESLVal n = $3521;
                  
                  {ESLVal t = $3520;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                default: {ESLVal _0 = _v1741;
                  
                  return $nil;
                }
              }
              }
            }
          }).map(args).flatten().flatten();
        
        if(exists.apply(new ESLVal(new Function(new ESLVal("fun427"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal n = $args[0];
      return member.apply(n,boundNames);
        }
      }),vars).boolVal)
        {ESLVal newNames = new java.util.function.Function<ESLVal,ESLVal>() {
              public ESLVal apply(ESLVal $l0) {
                ESLVal $a = $nil;
                java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                while(!$l0.isNil()) { 
                  ESLVal n = $l0.head();
                  $l0 = $l0.tail();
                  $v.add(newName());
                }
                for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                return $a;
              }}.apply(boundNames);
          
          {ESLVal env1 = addEntries.apply(boundNames,newNames,env);
          
          return new ESLVal("JMethod",name,new java.util.function.Function<ESLVal,ESLVal>() {
            public ESLVal apply(ESLVal $l0) {
              ESLVal $a = $nil;
              java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
              while(!$l0.isNil()) { 
                ESLVal n = $l0.head();
                $l0 = $l0.tail();
                $v.add(new ESLVal("JDec",n,$null));
              }
              for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
              return $a;
            }}.apply(newNames),renameJVarsCommand(body,boundNames.add(vars),env1));
        }
        }
        else
          return new ESLVal("JMethod",name,args,renameJVarsCommand(body,boundNames.add(vars),env));
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(29138,29714)").add(ESLVal.list(_v1740)));
    }
    }
  }
  private static ESLVal renameJVarsMethod = new ESLVal(new Function(new ESLVal("renameJVarsMethod"),null) { public ESLVal apply(ESLVal... args) { return renameJVarsMethod(args[0],args[1],args[2]); }});
  private static ESLVal renameJVarsCmp(ESLVal c,ESLVal vars,ESLVal env) {
    
    {ESLVal _v1742 = c;
      
      switch(_v1742.termName) {
      case "JCmpList": {ESLVal $3530 = _v1742.termRef(0);
        
        {ESLVal e = $3530;
        
        return new ESLVal("JCmpList",renameJVarsExp(e,vars,env));
      }
      }
    case "JCmpOuter": {ESLVal $3529 = _v1742.termRef(0);
        ESLVal $3528 = _v1742.termRef(1);
        ESLVal $3527 = _v1742.termRef(2);
        
        {ESLVal n = $3529;
        
        {ESLVal e = $3528;
        
        {ESLVal _v1768 = $3527;
        
        {ESLVal _v1769 = remove.apply(n,vars);
        ESLVal _v1770 = addEntry.apply(n,n,env);
        
        return new ESLVal("JCmpOuter",n,renameJVarsExp(e,_v1769,_v1770),renameJVarsCmp(_v1768,_v1769,_v1770));
      }
      }
      }
      }
      }
    case "JCmpBind": {ESLVal $3526 = _v1742.termRef(0);
        ESLVal $3525 = _v1742.termRef(1);
        ESLVal $3524 = _v1742.termRef(2);
        
        {ESLVal n = $3526;
        
        {ESLVal e = $3525;
        
        {ESLVal _v1765 = $3524;
        
        {ESLVal _v1766 = remove.apply(n,vars);
        ESLVal _v1767 = addEntry.apply(n,n,env);
        
        return new ESLVal("JCmpBind",n,renameJVarsExp(e,_v1766,_v1767),renameJVarsCmp(_v1765,_v1766,_v1767));
      }
      }
      }
      }
      }
    case "JCmpIf": {ESLVal $3523 = _v1742.termRef(0);
        ESLVal $3522 = _v1742.termRef(1);
        
        {ESLVal e = $3523;
        
        {ESLVal _v1764 = $3522;
        
        return new ESLVal("JCmpIf",renameJVarsExp(e,vars,env),renameJVarsCmp(_v1764,vars,env));
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(29784,30365)").add(ESLVal.list(_v1742)));
    }
    }
  }
  private static ESLVal renameJVarsCmp = new ESLVal(new Function(new ESLVal("renameJVarsCmp"),null) { public ESLVal apply(ESLVal... args) { return renameJVarsCmp(args[0],args[1],args[2]); }});
  private static ESLVal newName() {
    
    {nameCount = nameCount.add($one);
    return new ESLVal("_v").add(nameCount);}
  }
  private static ESLVal newName = new ESLVal(new Function(new ESLVal("newName"),null) { public ESLVal apply(ESLVal... args) { return newName(); }});
  private static ESLVal renameJVarsCommand(ESLVal c,ESLVal vars,ESLVal env) {
    
    {ESLVal _v1743 = c;
      
      switch(_v1743.termName) {
      case "JBlock": {ESLVal $3571 = _v1743.termRef(0);
        
        {ESLVal v0 = $3571;
        
        return new ESLVal("JBlock",new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal c = $l0.head();
              $l0 = $l0.tail();
              $v.add(renameJVarsCommand(c,vars,env));
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(v0));
      }
      }
    case "JReturn": {ESLVal $3570 = _v1743.termRef(0);
        
        {ESLVal v0 = $3570;
        
        return new ESLVal("JReturn",renameJVarsExp(v0,vars,env));
      }
      }
    case "JSwitch": {ESLVal $3569 = _v1743.termRef(0);
        ESLVal $3568 = _v1743.termRef(1);
        ESLVal $3567 = _v1743.termRef(2);
        
        {ESLVal v0 = $3569;
        
        {ESLVal v1 = $3568;
        
        {ESLVal v2 = $3567;
        
        return error(new ESLVal("jswitch should not occur"));
      }
      }
      }
      }
    case "JSwitchList": {ESLVal $3566 = _v1743.termRef(0);
        ESLVal $3565 = _v1743.termRef(1);
        ESLVal $3564 = _v1743.termRef(2);
        ESLVal $3563 = _v1743.termRef(3);
        
        {ESLVal v0 = $3566;
        
        {ESLVal v1 = $3565;
        
        {ESLVal v2 = $3564;
        
        {ESLVal v3 = $3563;
        
        return new ESLVal("JSwitchList",renameJVarsExp(v0,vars,env),renameJVarsCommand(v1,vars,env),renameJVarsCommand(v2,vars,env),renameJVarsCommand(v3,vars,env));
      }
      }
      }
      }
      }
    case "JIfCommand": {ESLVal $3562 = _v1743.termRef(0);
        ESLVal $3561 = _v1743.termRef(1);
        ESLVal $3560 = _v1743.termRef(2);
        
        {ESLVal v0 = $3562;
        
        {ESLVal v1 = $3561;
        
        {ESLVal v2 = $3560;
        
        return new ESLVal("JIfCommand",renameJVarsExp(v0,vars,env),renameJVarsCommand(v1,vars,env),renameJVarsCommand(v2,vars,env));
      }
      }
      }
      }
    case "JCaseList": {ESLVal $3559 = _v1743.termRef(0);
        ESLVal $3558 = _v1743.termRef(1);
        ESLVal $3557 = _v1743.termRef(2);
        ESLVal $3556 = _v1743.termRef(3);
        
        {ESLVal v0 = $3559;
        
        {ESLVal v1 = $3558;
        
        {ESLVal v2 = $3557;
        
        {ESLVal v3 = $3556;
        
        return new ESLVal("JCaseList",renameJVarsExp(v0,vars,env),renameJVarsCommand(v1,vars,env),renameJVarsCommand(v2,vars,env),renameJVarsCommand(v3,vars,env));
      }
      }
      }
      }
      }
    case "JCaseInt": {ESLVal $3555 = _v1743.termRef(0);
        ESLVal $3554 = _v1743.termRef(1);
        ESLVal $3553 = _v1743.termRef(2);
        
        {ESLVal e = $3555;
        
        {ESLVal arms = $3554;
        
        {ESLVal alt = $3553;
        
        return new ESLVal("JCaseInt",renameJVarsExp(e,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v1756 = $qualArg;
              
              switch(_v1756.termName) {
              case "JIArm": {ESLVal $3607 = _v1756.termRef(0);
                ESLVal $3606 = _v1756.termRef(1);
                
                {ESLVal n = $3607;
                
                {ESLVal _v1763 = $3606;
                
                return ESLVal.list(ESLVal.list(new ESLVal("JIArm",n,renameJVarsCommand(_v1763,vars,env))));
              }
              }
              }
              default: {ESLVal _0 = _v1756;
                
                return $nil;
              }
            }
            }
          }
        }).map(arms).flatten().flatten(),renameJVarsCommand(alt,vars,env));
      }
      }
      }
      }
    case "JCaseStr": {ESLVal $3552 = _v1743.termRef(0);
        ESLVal $3551 = _v1743.termRef(1);
        ESLVal $3550 = _v1743.termRef(2);
        
        {ESLVal e = $3552;
        
        {ESLVal arms = $3551;
        
        {ESLVal alt = $3550;
        
        return new ESLVal("JCaseStr",renameJVarsExp(e,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v1755 = $qualArg;
              
              switch(_v1755.termName) {
              case "JSArm": {ESLVal $3605 = _v1755.termRef(0);
                ESLVal $3604 = _v1755.termRef(1);
                
                {ESLVal s = $3605;
                
                {ESLVal _v1762 = $3604;
                
                return ESLVal.list(ESLVal.list(new ESLVal("JSArm",s,renameJVarsCommand(_v1762,vars,env))));
              }
              }
              }
              default: {ESLVal _0 = _v1755;
                
                return $nil;
              }
            }
            }
          }
        }).map(arms).flatten().flatten(),renameJVarsCommand(alt,vars,env));
      }
      }
      }
      }
    case "JCaseBool": {ESLVal $3549 = _v1743.termRef(0);
        ESLVal $3548 = _v1743.termRef(1);
        ESLVal $3547 = _v1743.termRef(2);
        
        {ESLVal e = $3549;
        
        {ESLVal arms = $3548;
        
        {ESLVal alt = $3547;
        
        return new ESLVal("JCaseBool",renameJVarsExp(e,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v1754 = $qualArg;
              
              switch(_v1754.termName) {
              case "JBArm": {ESLVal $3603 = _v1754.termRef(0);
                ESLVal $3602 = _v1754.termRef(1);
                
                {ESLVal b = $3603;
                
                {ESLVal _v1761 = $3602;
                
                return ESLVal.list(ESLVal.list(new ESLVal("JBArm",b,renameJVarsCommand(_v1761,vars,env))));
              }
              }
              }
              default: {ESLVal _0 = _v1754;
                
                return $nil;
              }
            }
            }
          }
        }).map(arms).flatten().flatten(),renameJVarsCommand(alt,vars,env));
      }
      }
      }
      }
    case "JCaseTerm": {ESLVal $3546 = _v1743.termRef(0);
        ESLVal $3545 = _v1743.termRef(1);
        ESLVal $3544 = _v1743.termRef(2);
        
        {ESLVal e = $3546;
        
        {ESLVal arms = $3545;
        
        {ESLVal alt = $3544;
        
        return new ESLVal("JCaseTerm",renameJVarsExp(e,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v1753 = $qualArg;
              
              switch(_v1753.termName) {
              case "JTArm": {ESLVal $3601 = _v1753.termRef(0);
                ESLVal $3600 = _v1753.termRef(1);
                ESLVal $3599 = _v1753.termRef(2);
                
                {ESLVal n = $3601;
                
                {ESLVal i = $3600;
                
                {ESLVal _v1760 = $3599;
                
                return ESLVal.list(ESLVal.list(new ESLVal("JTArm",n,i,renameJVarsCommand(_v1760,vars,env))));
              }
              }
              }
              }
              default: {ESLVal _0 = _v1753;
                
                return $nil;
              }
            }
            }
          }
        }).map(arms).flatten().flatten(),renameJVarsCommand(alt,vars,env));
      }
      }
      }
      }
    case "JLet": {ESLVal $3543 = _v1743.termRef(0);
        ESLVal $3542 = _v1743.termRef(1);
        
        {ESLVal v0 = $3543;
        
        {ESLVal v1 = $3542;
        
        {ESLVal boundNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1750 = $qualArg;
                
                switch(_v1750.termName) {
                case "JField": {ESLVal $3592 = _v1750.termRef(0);
                  ESLVal $3591 = _v1750.termRef(1);
                  ESLVal $3590 = _v1750.termRef(2);
                  
                  {ESLVal n = $3592;
                  
                  {ESLVal t = $3591;
                  
                  {ESLVal e = $3590;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1750;
                  
                  return $nil;
                }
              }
              }
            }
          }).map(v0).flatten().flatten();
        
        if(exists.apply(new ESLVal(new Function(new ESLVal("fun428"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal n = $args[0];
      return member.apply(n,vars);
        }
      }),boundNames).boolVal)
        {ESLVal newNames = new java.util.function.Function<ESLVal,ESLVal>() {
              public ESLVal apply(ESLVal $l0) {
                ESLVal $a = $nil;
                java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                while(!$l0.isNil()) { 
                  ESLVal n = $l0.head();
                  $l0 = $l0.tail();
                  $v.add(newName());
                }
                for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                return $a;
              }}.apply(boundNames);
          
          {ESLVal env1 = addEntries.apply(boundNames,newNames,env);
          
          return new ESLVal("JLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1751 = $qualArg;
                
                switch(_v1751.termName) {
                case "JField": {ESLVal $3595 = _v1751.termRef(0);
                  ESLVal $3594 = _v1751.termRef(1);
                  ESLVal $3593 = _v1751.termRef(2);
                  
                  {ESLVal n = $3595;
                  
                  {ESLVal t = $3594;
                  
                  {ESLVal e = $3593;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",lookup.apply(n,env1),t,renameJVarsExp(e,vars,env))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1751;
                  
                  return $nil;
                }
              }
              }
            }
          }).map(v0).flatten().flatten(),renameJVarsCommand(v1,boundNames.add(vars),env1));
        }
        }
        else
          return new ESLVal("JLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v1752 = $qualArg;
                  
                  switch(_v1752.termName) {
                  case "JField": {ESLVal $3598 = _v1752.termRef(0);
                    ESLVal $3597 = _v1752.termRef(1);
                    ESLVal $3596 = _v1752.termRef(2);
                    
                    {ESLVal n = $3598;
                    
                    {ESLVal t = $3597;
                    
                    {ESLVal e = $3596;
                    
                    return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp(e,vars,env))));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v1752;
                    
                    return $nil;
                  }
                }
                }
              }
            }).map(v0).flatten().flatten(),renameJVarsCommand(v1,boundNames.add(vars),env));
      }
      }
      }
      }
    case "JPLet": {ESLVal $3541 = _v1743.termRef(0);
        ESLVal $3540 = _v1743.termRef(1);
        
        {ESLVal v0 = $3541;
        
        {ESLVal v1 = $3540;
        
        {ESLVal boundNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1747 = $qualArg;
                
                switch(_v1747.termName) {
                case "JField": {ESLVal $3583 = _v1747.termRef(0);
                  ESLVal $3582 = _v1747.termRef(1);
                  ESLVal $3581 = _v1747.termRef(2);
                  
                  {ESLVal n = $3583;
                  
                  {ESLVal t = $3582;
                  
                  {ESLVal e = $3581;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1747;
                  
                  return $nil;
                }
              }
              }
            }
          }).map(v0).flatten().flatten();
        
        if(exists.apply(new ESLVal(new Function(new ESLVal("fun429"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal n = $args[0];
      return member.apply(n,vars);
        }
      }),boundNames).boolVal)
        {ESLVal newNames = new java.util.function.Function<ESLVal,ESLVal>() {
              public ESLVal apply(ESLVal $l0) {
                ESLVal $a = $nil;
                java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                while(!$l0.isNil()) { 
                  ESLVal n = $l0.head();
                  $l0 = $l0.tail();
                  $v.add(newName());
                }
                for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                return $a;
              }}.apply(boundNames);
          
          {ESLVal env1 = addEntries.apply(boundNames,newNames,env);
          
          return new ESLVal("JPLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1748 = $qualArg;
                
                switch(_v1748.termName) {
                case "JField": {ESLVal $3586 = _v1748.termRef(0);
                  ESLVal $3585 = _v1748.termRef(1);
                  ESLVal $3584 = _v1748.termRef(2);
                  
                  {ESLVal n = $3586;
                  
                  {ESLVal t = $3585;
                  
                  {ESLVal e = $3584;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",lookup.apply(n,env1),t,renameJVarsExp(e,vars,env))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1748;
                  
                  return $nil;
                }
              }
              }
            }
          }).map(v0).flatten().flatten(),renameJVarsCommand(v1,boundNames.add(vars),env1));
        }
        }
        else
          return new ESLVal("JPLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v1749 = $qualArg;
                  
                  switch(_v1749.termName) {
                  case "JField": {ESLVal $3589 = _v1749.termRef(0);
                    ESLVal $3588 = _v1749.termRef(1);
                    ESLVal $3587 = _v1749.termRef(2);
                    
                    {ESLVal n = $3589;
                    
                    {ESLVal t = $3588;
                    
                    {ESLVal e = $3587;
                    
                    return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp(e,vars,env))));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v1749;
                    
                    return $nil;
                  }
                }
                }
              }
            }).map(v0).flatten().flatten(),renameJVarsCommand(v1,boundNames.add(vars),env));
      }
      }
      }
      }
    case "JLetRec": {ESLVal $3539 = _v1743.termRef(0);
        ESLVal $3538 = _v1743.termRef(1);
        
        {ESLVal v0 = $3539;
        
        {ESLVal v1 = $3538;
        
        {ESLVal boundNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1744 = $qualArg;
                
                switch(_v1744.termName) {
                case "JField": {ESLVal $3574 = _v1744.termRef(0);
                  ESLVal $3573 = _v1744.termRef(1);
                  ESLVal $3572 = _v1744.termRef(2);
                  
                  {ESLVal n = $3574;
                  
                  {ESLVal t = $3573;
                  
                  {ESLVal e = $3572;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1744;
                  
                  return $nil;
                }
              }
              }
            }
          }).map(v0).flatten().flatten();
        
        if(exists.apply(new ESLVal(new Function(new ESLVal("fun430"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal n = $args[0];
      return member.apply(n,vars);
        }
      }),boundNames).boolVal)
        {ESLVal newNames = new java.util.function.Function<ESLVal,ESLVal>() {
              public ESLVal apply(ESLVal $l0) {
                ESLVal $a = $nil;
                java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                while(!$l0.isNil()) { 
                  ESLVal n = $l0.head();
                  $l0 = $l0.tail();
                  $v.add(newName());
                }
                for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                return $a;
              }}.apply(boundNames);
          
          {ESLVal _v1759 = addEntries.apply(boundNames,newNames,env);
          
          return new ESLVal("JLetRec",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1745 = $qualArg;
                
                switch(_v1745.termName) {
                case "JField": {ESLVal $3577 = _v1745.termRef(0);
                  ESLVal $3576 = _v1745.termRef(1);
                  ESLVal $3575 = _v1745.termRef(2);
                  
                  {ESLVal n = $3577;
                  
                  {ESLVal t = $3576;
                  
                  {ESLVal e = $3575;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",lookup.apply(n,_v1759),t,renameJVarsExp(e,vars,_v1759))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1745;
                  
                  return $nil;
                }
              }
              }
            }
          }).map(v0).flatten().flatten(),renameJVarsCommand(v1,boundNames.add(vars),_v1759));
        }
        }
        else
          return new ESLVal("JLetRec",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v1746 = $qualArg;
                  
                  switch(_v1746.termName) {
                  case "JField": {ESLVal $3580 = _v1746.termRef(0);
                    ESLVal $3579 = _v1746.termRef(1);
                    ESLVal $3578 = _v1746.termRef(2);
                    
                    {ESLVal n = $3580;
                    
                    {ESLVal t = $3579;
                    
                    {ESLVal e = $3578;
                    
                    return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp(e,vars,env))));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v1746;
                    
                    return $nil;
                  }
                }
                }
              }
            }).map(v0).flatten().flatten(),renameJVarsCommand(v1,boundNames.add(vars),env));
      }
      }
      }
      }
    case "JStatement": {ESLVal $3537 = _v1743.termRef(0);
        
        {ESLVal e = $3537;
        
        return new ESLVal("JStatement",renameJVarsExp(e,vars,env));
      }
      }
    case "JUpdate": {ESLVal $3536 = _v1743.termRef(0);
        ESLVal $3535 = _v1743.termRef(1);
        
        {ESLVal name = $3536;
        
        {ESLVal value = $3535;
        
        if(hasEntry.apply(name,env).boolVal)
        return new ESLVal("JUpdate",lookup.apply(name,env),renameJVarsExp(value,vars,env));
        else
          {ESLVal v0 = $3536;
            
            {ESLVal v1 = $3535;
            
            return new ESLVal("JUpdate",v0,renameJVarsExp(v1,vars,env));
          }
          }
      }
      }
      }
    case "JFor": {ESLVal $3534 = _v1743.termRef(0);
        ESLVal $3533 = _v1743.termRef(1);
        ESLVal $3532 = _v1743.termRef(2);
        ESLVal $3531 = _v1743.termRef(3);
        
        {ESLVal l = $3534;
        
        {ESLVal n = $3533;
        
        {ESLVal e = $3532;
        
        {ESLVal _v1758 = $3531;
        
        return new ESLVal("JFor",l,n,renameJVarsExp(e,vars,env),renameJVarsCommand(_v1758,vars,env));
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(30603,35011)").add(ESLVal.list(_v1743)));
    }
    }
  }
  private static ESLVal renameJVarsCommand = new ESLVal(new Function(new ESLVal("renameJVarsCommand"),null) { public ESLVal apply(ESLVal... args) { return renameJVarsCommand(args[0],args[1],args[2]); }});
public static void main(String[] args) {
    newActor(main,new ESLVal(new Actor())); 
  }
}