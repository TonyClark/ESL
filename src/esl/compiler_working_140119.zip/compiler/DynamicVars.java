package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
import static esl.compiler.Types.*;
// import static esl.Lists.*;
import java.util.function.Supplier;
public class DynamicVars {
  public static ESLVal getSelf() { return $null; }
  
private static ESLVal decName(ESLVal d) {
    
    {ESLVal _v1010 = d;
      
      switch(_v1010.termName) {
      case "JDec": {ESLVal $1349 = _v1010.termRef(0);
        ESLVal $1348 = _v1010.termRef(1);
        
        {ESLVal n = $1349;
        
        {ESLVal t = $1348;
        
        return n;
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(137,182)").add(ESLVal.list(_v1010)));
    }
    }
  }
  private static ESLVal decName = new ESLVal(new Function(new ESLVal("decName"),null) { public ESLVal apply(ESLVal... args) { return decName(args[0]); }});
  private static ESLVal fieldName(ESLVal d) {
    
    {ESLVal _v1011 = d;
      
      switch(_v1011.termName) {
      case "JField": {ESLVal $1352 = _v1011.termRef(0);
        ESLVal $1351 = _v1011.termRef(1);
        ESLVal $1350 = _v1011.termRef(2);
        
        {ESLVal n = $1352;
        
        {ESLVal t = $1351;
        
        {ESLVal e = $1350;
        
        return n;
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(217,271)").add(ESLVal.list(_v1011)));
    }
    }
  }
  private static ESLVal fieldName = new ESLVal(new Function(new ESLVal("fieldName"),null) { public ESLVal apply(ESLVal... args) { return fieldName(args[0]); }});
  private static ESLVal fieldJExp(ESLVal d) {
    
    {ESLVal _v1012 = d;
      
      switch(_v1012.termName) {
      case "JField": {ESLVal $1355 = _v1012.termRef(0);
        ESLVal $1354 = _v1012.termRef(1);
        ESLVal $1353 = _v1012.termRef(2);
        
        {ESLVal n = $1355;
        
        {ESLVal t = $1354;
        
        {ESLVal e = $1353;
        
        return e;
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(307,361)").add(ESLVal.list(_v1012)));
    }
    }
  }
  private static ESLVal fieldJExp = new ESLVal(new Function(new ESLVal("fieldJExp"),null) { public ESLVal apply(ESLVal... args) { return fieldJExp(args[0]); }});
  public static ESLVal dynamicVarsJExp(ESLVal x) {
    
    {ESLVal _v1013 = x;
      
      switch(_v1013.termName) {
      case "JArrayRef": {ESLVal $1434 = _v1013.termRef(0);
        ESLVal $1433 = _v1013.termRef(1);
        
        {ESLVal a = $1434;
        
        {ESLVal i = $1433;
        
        return dynamicVarsJExp(a).add(dynamicVarsJExp(i));
      }
      }
      }
    case "JArrayUpdate": {ESLVal $1432 = _v1013.termRef(0);
        ESLVal $1431 = _v1013.termRef(1);
        ESLVal $1430 = _v1013.termRef(2);
        
        {ESLVal a = $1432;
        
        {ESLVal i = $1431;
        
        {ESLVal v = $1430;
        
        return dynamicVarsJExp(a).add(dynamicVarsJExp(i).add(dynamicVarsJExp(v)));
      }
      }
      }
      }
    case "JBecome": {ESLVal $1429 = _v1013.termRef(0);
        ESLVal $1428 = _v1013.termRef(1);
        
        {ESLVal e = $1429;
        
        {ESLVal es = $1428;
        
        return dynamicVarsJExp(e).add(flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun353"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1023 = $args[0];
        return dynamicVarsJExp(_v1023);
          }
        }),es)));
      }
      }
      }
    case "JFun": {ESLVal $1427 = _v1013.termRef(0);
        ESLVal $1426 = _v1013.termRef(1);
        ESLVal $1425 = _v1013.termRef(2);
        ESLVal $1424 = _v1013.termRef(3);
        
        {ESLVal v0 = $1427;
        
        {ESLVal v1 = $1426;
        
        {ESLVal v2 = $1425;
        
        {ESLVal v3 = $1424;
        
        return reject.apply(new ESLVal(new Function(new ESLVal("fun354"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal n = $args[0];
        return member.apply(n,map.apply(decName,v1));
          }
        }),dynamicVarsJCommand(v3));
      }
      }
      }
      }
      }
    case "JApply": {ESLVal $1423 = _v1013.termRef(0);
        ESLVal $1422 = _v1013.termRef(1);
        
        {ESLVal v0 = $1423;
        
        {ESLVal v1 = $1422;
        
        return dynamicVarsJExp(v0).add(flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun355"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal e = $args[0];
        return dynamicVarsJExp(e);
          }
        }),v1)));
      }
      }
      }
    case "JBinExp": {ESLVal $1421 = _v1013.termRef(0);
        ESLVal $1420 = _v1013.termRef(1);
        ESLVal $1419 = _v1013.termRef(2);
        
        {ESLVal v0 = $1421;
        
        {ESLVal v1 = $1420;
        
        {ESLVal v2 = $1419;
        
        return dynamicVarsJExp(v0).add(dynamicVarsJExp(v2));
      }
      }
      }
      }
    case "JCommandExp": {ESLVal $1418 = _v1013.termRef(0);
        ESLVal $1417 = _v1013.termRef(1);
        
        {ESLVal v0 = $1418;
        
        {ESLVal v1 = $1417;
        
        return dynamicVarsJCommand(v0);
      }
      }
      }
    case "JIfExp": {ESLVal $1416 = _v1013.termRef(0);
        ESLVal $1415 = _v1013.termRef(1);
        ESLVal $1414 = _v1013.termRef(2);
        
        {ESLVal v0 = $1416;
        
        {ESLVal v1 = $1415;
        
        {ESLVal v2 = $1414;
        
        return dynamicVarsJExp(v0).add(dynamicVarsJExp(v1).add(dynamicVarsJExp(v2)));
      }
      }
      }
      }
    case "JConstExp": {ESLVal $1413 = _v1013.termRef(0);
        
        {ESLVal v0 = $1413;
        
        return $nil;
      }
      }
    case "JCmpExp": {ESLVal $1412 = _v1013.termRef(0);
        
        {ESLVal c = $1412;
        
        return $nil;
      }
      }
    case "JTerm": {ESLVal $1411 = _v1013.termRef(0);
        ESLVal $1410 = _v1013.termRef(1);
        
        {ESLVal v0 = $1411;
        
        {ESLVal v1 = $1410;
        
        return flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun356"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal e = $args[0];
        return dynamicVarsJExp(e);
          }
        }),v1));
      }
      }
      }
    case "JTermRef": {ESLVal $1409 = _v1013.termRef(0);
        ESLVal $1408 = _v1013.termRef(1);
        
        {ESLVal v0 = $1409;
        
        {ESLVal v1 = $1408;
        
        return dynamicVarsJExp(v0);
      }
      }
      }
    case "JList": {ESLVal $1407 = _v1013.termRef(0);
        ESLVal $1406 = _v1013.termRef(1);
        
        {ESLVal v0 = $1407;
        
        {ESLVal v1 = $1406;
        
        return flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun357"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal e = $args[0];
        return dynamicVarsJExp(e);
          }
        }),v1));
      }
      }
      }
    case "JBag": {ESLVal $1405 = _v1013.termRef(0);
        ESLVal $1404 = _v1013.termRef(1);
        
        {ESLVal v0 = $1405;
        
        {ESLVal v1 = $1404;
        
        return flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun358"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal e = $args[0];
        return dynamicVarsJExp(e);
          }
        }),v1));
      }
      }
      }
    case "JSet": {ESLVal $1403 = _v1013.termRef(0);
        ESLVal $1402 = _v1013.termRef(1);
        
        {ESLVal v0 = $1403;
        
        {ESLVal v1 = $1402;
        
        return flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun359"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal e = $args[0];
        return dynamicVarsJExp(e);
          }
        }),v1));
      }
      }
      }
    case "JNil": {ESLVal $1401 = _v1013.termRef(0);
        
        {ESLVal v0 = $1401;
        
        return $nil;
      }
      }
    case "JVar": {ESLVal $1400 = _v1013.termRef(0);
        ESLVal $1399 = _v1013.termRef(1);
        
        {ESLVal v0 = $1400;
        
        {ESLVal v1 = $1399;
        
        return $nil;
      }
      }
      }
    case "JNull": {
        return $nil;
      }
    case "JNow": {
        return $nil;
      }
    case "JError": {ESLVal $1398 = _v1013.termRef(0);
        
        {ESLVal v0 = $1398;
        
        return dynamicVarsJExp(v0);
      }
      }
    case "JHead": {ESLVal $1397 = _v1013.termRef(0);
        
        {ESLVal v0 = $1397;
        
        return dynamicVarsJExp(v0);
      }
      }
    case "JTail": {ESLVal $1396 = _v1013.termRef(0);
        
        {ESLVal v0 = $1396;
        
        return dynamicVarsJExp(v0);
      }
      }
    case "JMapFun": {ESLVal $1395 = _v1013.termRef(0);
        ESLVal $1394 = _v1013.termRef(1);
        
        {ESLVal v0 = $1395;
        
        {ESLVal v1 = $1394;
        
        return dynamicVarsJExp(v0).add(dynamicVarsJExp(v1));
      }
      }
      }
    case "JFlatten": {ESLVal $1393 = _v1013.termRef(0);
        
        {ESLVal v0 = $1393;
        
        return dynamicVarsJExp(v0);
      }
      }
    case "JNot": {ESLVal $1392 = _v1013.termRef(0);
        
        {ESLVal v0 = $1392;
        
        return dynamicVarsJExp(v0);
      }
      }
    case "JBehaviour": {ESLVal $1391 = _v1013.termRef(0);
        ESLVal $1390 = _v1013.termRef(1);
        ESLVal $1389 = _v1013.termRef(2);
        ESLVal $1388 = _v1013.termRef(3);
        ESLVal $1387 = _v1013.termRef(4);
        ESLVal $1386 = _v1013.termRef(5);
        
        {ESLVal v0 = $1391;
        
        {ESLVal v1 = $1390;
        
        {ESLVal methods = $1389;
        
        {ESLVal v2 = $1388;
        
        {ESLVal v3 = $1387;
        
        {ESLVal v4 = $1386;
        
        return flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun360"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal d = $args[0];
        return dynamicVarsJFieldDef(d);
          }
        }),v1)).add(flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun361"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal d = $args[0];
        return dynamicVarsJMethodDef(d);
          }
        }),methods)).add(dynamicVarsJExp(v2).add(dynamicVarsJExp(v3).add(dynamicVarsJCommand(v4)))));
      }
      }
      }
      }
      }
      }
      }
    case "JExtendedBehaviour": {ESLVal $1385 = _v1013.termRef(0);
        ESLVal $1384 = _v1013.termRef(1);
        ESLVal $1383 = _v1013.termRef(2);
        ESLVal $1382 = _v1013.termRef(3);
        ESLVal $1381 = _v1013.termRef(4);
        ESLVal $1380 = _v1013.termRef(5);
        ESLVal $1379 = _v1013.termRef(6);
        
        {ESLVal v0 = $1385;
        
        {ESLVal parent = $1384;
        
        {ESLVal v1 = $1383;
        
        {ESLVal methods = $1382;
        
        {ESLVal v2 = $1381;
        
        {ESLVal v3 = $1380;
        
        {ESLVal v4 = $1379;
        
        return dynamicVarsJExp(parent).add(flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun362"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal d = $args[0];
        return dynamicVarsJFieldDef(d);
          }
        }),v1)).add(flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun363"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal d = $args[0];
        return dynamicVarsJMethodDef(d);
          }
        }),methods)).add(dynamicVarsJExp(v2).add(dynamicVarsJExp(v3).add(dynamicVarsJCommand(v4))))));
      }
      }
      }
      }
      }
      }
      }
      }
    case "JMethodCall": {ESLVal $1378 = _v1013.termRef(0);
        ESLVal $1377 = _v1013.termRef(1);
        
        {ESLVal name = $1378;
        
        {ESLVal args = $1377;
        
        return flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun364"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal e = $args[0];
        return dynamicVarsJExp(e);
          }
        }),args));
      }
      }
      }
    case "JNew": {ESLVal $1376 = _v1013.termRef(0);
        ESLVal $1375 = _v1013.termRef(1);
        
        {ESLVal v0 = $1376;
        
        {ESLVal v1 = $1375;
        
        return dynamicVarsJExp(v0).add(flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun365"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal e = $args[0];
        return dynamicVarsJExp(e);
          }
        }),v1)));
      }
      }
      }
    case "JNewArray": {ESLVal $1374 = _v1013.termRef(0);
        
        {ESLVal v0 = $1374;
        
        return dynamicVarsJExp(v0);
      }
      }
    case "JNewJava": {ESLVal $1373 = _v1013.termRef(0);
        ESLVal $1372 = _v1013.termRef(1);
        
        {ESLVal v0 = $1373;
        
        {ESLVal v1 = $1372;
        
        return flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun366"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal e = $args[0];
        return dynamicVarsJExp(e);
          }
        }),v1));
      }
      }
      }
    case "JNewTable": {
        return $nil;
      }
    case "JRecord": {ESLVal $1371 = _v1013.termRef(0);
        
        {ESLVal fs = $1371;
        
        return new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v1014 = $qualArg;
              
              switch(_v1014.termName) {
              case "JField": {ESLVal $1437 = _v1014.termRef(0);
                ESLVal $1436 = _v1014.termRef(1);
                ESLVal $1435 = _v1014.termRef(2);
                
                {ESLVal n = $1437;
                
                {ESLVal t = $1436;
                
                {ESLVal e = $1435;
                
                return ESLVal.list(new java.util.function.Function<ESLVal,ESLVal>() {
                  public ESLVal apply(ESLVal $l0) {
                    ESLVal $a = $nil;
                    java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                    while(!$l0.isNil()) { 
                      ESLVal v = $l0.head();
                      $l0 = $l0.tail();
                      $v.add(v);
                    }
                    for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                    return $a;
                  }}.apply(dynamicVarsJExp(e)));
              }
              }
              }
              }
              default: {ESLVal _0 = _v1014;
                
                return $nil;
              }
            }
            }
          }
        }).map(fs).flatten().flatten();
      }
      }
    case "JSend": {ESLVal $1370 = _v1013.termRef(0);
        ESLVal $1369 = _v1013.termRef(1);
        ESLVal $1368 = _v1013.termRef(2);
        
        {ESLVal v0 = $1370;
        
        {ESLVal v1 = $1369;
        
        {ESLVal v2 = $1368;
        
        return dynamicVarsJExp(v0).add(flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun367"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal e = $args[0];
        return dynamicVarsJExp(e);
          }
        }),v2)));
      }
      }
      }
      }
    case "JSendSuper": {ESLVal $1367 = _v1013.termRef(0);
        
        {ESLVal e = $1367;
        
        return dynamicVarsJExp(e);
      }
      }
    case "JSendTimeSuper": {
        return $nil;
      }
    case "JSelf": {
        return $nil;
      }
    case "JTry": {ESLVal $1366 = _v1013.termRef(0);
        ESLVal $1365 = _v1013.termRef(1);
        ESLVal $1364 = _v1013.termRef(2);
        
        {ESLVal e = $1366;
        
        {ESLVal n = $1365;
        
        {ESLVal c = $1364;
        
        return dynamicVarsJExp(e).add(dynamicVarsJCommand(c));
      }
      }
      }
      }
    case "JRef": {ESLVal $1363 = _v1013.termRef(0);
        ESLVal $1362 = _v1013.termRef(1);
        
        {ESLVal v0 = $1363;
        
        {ESLVal v1 = $1362;
        
        return dynamicVarsJExp(v0);
      }
      }
      }
    case "JRefSuper": {ESLVal $1361 = _v1013.termRef(0);
        
        {ESLVal n = $1361;
        
        return $nil;
      }
      }
    case "JGrab": {ESLVal $1360 = _v1013.termRef(0);
        ESLVal $1359 = _v1013.termRef(1);
        
        {ESLVal v0 = $1360;
        
        {ESLVal v1 = $1359;
        
        return flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun368"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal e = $args[0];
        return dynamicVarsJExp(e);
          }
        }),v0)).add(dynamicVarsJExp(v1));
      }
      }
      }
    case "JProbably": {ESLVal $1358 = _v1013.termRef(0);
        ESLVal $1357 = _v1013.termRef(1);
        ESLVal $1356 = _v1013.termRef(2);
        
        {ESLVal v0 = $1358;
        
        {ESLVal v1 = $1357;
        
        {ESLVal v2 = $1356;
        
        return dynamicVarsJExp(v0).add(dynamicVarsJExp(v1).add(dynamicVarsJExp(v2)));
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(437,4208)").add(ESLVal.list(_v1013)));
    }
    }
  }
  public static ESLVal dynamicVarsJExp = new ESLVal(new Function(new ESLVal("dynamicVarsJExp"),null) { public ESLVal apply(ESLVal... args) { return dynamicVarsJExp(args[0]); }});
  private static ESLVal dynamicVarsJFieldDef(ESLVal d) {
    
    {ESLVal _v1015 = d;
      
      switch(_v1015.termName) {
      case "JField": {ESLVal $1440 = _v1015.termRef(0);
        ESLVal $1439 = _v1015.termRef(1);
        ESLVal $1438 = _v1015.termRef(2);
        
        {ESLVal n = $1440;
        
        {ESLVal t = $1439;
        
        {ESLVal e = $1438;
        
        return dynamicVarsJExp(e);
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(4258,4329)").add(ESLVal.list(_v1015)));
    }
    }
  }
  private static ESLVal dynamicVarsJFieldDef = new ESLVal(new Function(new ESLVal("dynamicVarsJFieldDef"),null) { public ESLVal apply(ESLVal... args) { return dynamicVarsJFieldDef(args[0]); }});
  private static ESLVal dynamicVarsJMethodDef(ESLVal m) {
    
    {ESLVal _v1016 = m;
      
      switch(_v1016.termName) {
      case "JMethod": {ESLVal $1443 = _v1016.termRef(0);
        ESLVal $1442 = _v1016.termRef(1);
        ESLVal $1441 = _v1016.termRef(2);
        
        {ESLVal n = $1443;
        
        {ESLVal args = $1442;
        
        {ESLVal body = $1441;
        
        return reject.apply(new ESLVal(new Function(new ESLVal("fun369"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1022 = $args[0];
        return member.apply(_v1022,map.apply(decName,args));
          }
        }),dynamicVarsJCommand(body));
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(4379,4528)").add(ESLVal.list(_v1016)));
    }
    }
  }
  private static ESLVal dynamicVarsJMethodDef = new ESLVal(new Function(new ESLVal("dynamicVarsJMethodDef"),null) { public ESLVal apply(ESLVal... args) { return dynamicVarsJMethodDef(args[0]); }});
  private static ESLVal dynamicVarsJTermArm(ESLVal t) {
    
    {ESLVal _v1017 = t;
      
      switch(_v1017.termName) {
      case "JTArm": {ESLVal $1446 = _v1017.termRef(0);
        ESLVal $1445 = _v1017.termRef(1);
        ESLVal $1444 = _v1017.termRef(2);
        
        {ESLVal n = $1446;
        
        {ESLVal i = $1445;
        
        {ESLVal c = $1444;
        
        return dynamicVarsJCommand(c);
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(4575,4651)").add(ESLVal.list(_v1017)));
    }
    }
  }
  private static ESLVal dynamicVarsJTermArm = new ESLVal(new Function(new ESLVal("dynamicVarsJTermArm"),null) { public ESLVal apply(ESLVal... args) { return dynamicVarsJTermArm(args[0]); }});
  private static ESLVal dynamicVarsJIntArm(ESLVal t) {
    
    {ESLVal _v1018 = t;
      
      switch(_v1018.termName) {
      case "JIArm": {ESLVal $1448 = _v1018.termRef(0);
        ESLVal $1447 = _v1018.termRef(1);
        
        {ESLVal i = $1448;
        
        {ESLVal c = $1447;
        
        return dynamicVarsJCommand(c);
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(4696,4765)").add(ESLVal.list(_v1018)));
    }
    }
  }
  private static ESLVal dynamicVarsJIntArm = new ESLVal(new Function(new ESLVal("dynamicVarsJIntArm"),null) { public ESLVal apply(ESLVal... args) { return dynamicVarsJIntArm(args[0]); }});
  private static ESLVal dynamicVarsJStrArm(ESLVal t) {
    
    {ESLVal _v1019 = t;
      
      switch(_v1019.termName) {
      case "JSArm": {ESLVal $1450 = _v1019.termRef(0);
        ESLVal $1449 = _v1019.termRef(1);
        
        {ESLVal s = $1450;
        
        {ESLVal c = $1449;
        
        return dynamicVarsJCommand(c);
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(4810,4879)").add(ESLVal.list(_v1019)));
    }
    }
  }
  private static ESLVal dynamicVarsJStrArm = new ESLVal(new Function(new ESLVal("dynamicVarsJStrArm"),null) { public ESLVal apply(ESLVal... args) { return dynamicVarsJStrArm(args[0]); }});
  private static ESLVal dynamicVarsJBoolArm(ESLVal t) {
    
    {ESLVal _v1020 = t;
      
      switch(_v1020.termName) {
      case "JBArm": {ESLVal $1452 = _v1020.termRef(0);
        ESLVal $1451 = _v1020.termRef(1);
        
        {ESLVal b = $1452;
        
        {ESLVal c = $1451;
        
        return dynamicVarsJCommand(c);
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(4926,4997)").add(ESLVal.list(_v1020)));
    }
    }
  }
  private static ESLVal dynamicVarsJBoolArm = new ESLVal(new Function(new ESLVal("dynamicVarsJBoolArm"),null) { public ESLVal apply(ESLVal... args) { return dynamicVarsJBoolArm(args[0]); }});
  public static ESLVal dynamicVarsJCommand(ESLVal x) {
    
    {ESLVal _v1021 = x;
      
      switch(_v1021.termName) {
      case "JBlock": {ESLVal $1486 = _v1021.termRef(0);
        
        {ESLVal v0 = $1486;
        
        return flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun370"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal e = $args[0];
        return dynamicVarsJCommand(e);
          }
        }),v0));
      }
      }
    case "JReturn": {ESLVal $1485 = _v1021.termRef(0);
        
        {ESLVal v0 = $1485;
        
        return dynamicVarsJExp(v0);
      }
      }
    case "JIfCommand": {ESLVal $1484 = _v1021.termRef(0);
        ESLVal $1483 = _v1021.termRef(1);
        ESLVal $1482 = _v1021.termRef(2);
        
        {ESLVal v0 = $1484;
        
        {ESLVal v1 = $1483;
        
        {ESLVal v2 = $1482;
        
        return dynamicVarsJExp(v0).add(dynamicVarsJCommand(v1).add(dynamicVarsJCommand(v2)));
      }
      }
      }
      }
    case "JCaseList": {ESLVal $1481 = _v1021.termRef(0);
        ESLVal $1480 = _v1021.termRef(1);
        ESLVal $1479 = _v1021.termRef(2);
        ESLVal $1478 = _v1021.termRef(3);
        
        {ESLVal v0 = $1481;
        
        {ESLVal v1 = $1480;
        
        {ESLVal v2 = $1479;
        
        {ESLVal v3 = $1478;
        
        return dynamicVarsJExp(v0).add(dynamicVarsJCommand(v1).add(dynamicVarsJCommand(v2).add(dynamicVarsJCommand(v3))));
      }
      }
      }
      }
      }
    case "JCaseTerm": {ESLVal $1477 = _v1021.termRef(0);
        ESLVal $1476 = _v1021.termRef(1);
        ESLVal $1475 = _v1021.termRef(2);
        
        {ESLVal v0 = $1477;
        
        {ESLVal v1 = $1476;
        
        {ESLVal v2 = $1475;
        
        return dynamicVarsJExp(v0).add(flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun371"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal t = $args[0];
        return dynamicVarsJTermArm(t);
          }
        }),v1)).add(dynamicVarsJCommand(v2)));
      }
      }
      }
      }
    case "JCaseInt": {ESLVal $1474 = _v1021.termRef(0);
        ESLVal $1473 = _v1021.termRef(1);
        ESLVal $1472 = _v1021.termRef(2);
        
        {ESLVal v0 = $1474;
        
        {ESLVal v1 = $1473;
        
        {ESLVal v2 = $1472;
        
        return dynamicVarsJExp(v0).add(flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun372"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal t = $args[0];
        return dynamicVarsJIntArm(t);
          }
        }),v1)).add(dynamicVarsJCommand(v2)));
      }
      }
      }
      }
    case "JCaseStr": {ESLVal $1471 = _v1021.termRef(0);
        ESLVal $1470 = _v1021.termRef(1);
        ESLVal $1469 = _v1021.termRef(2);
        
        {ESLVal v0 = $1471;
        
        {ESLVal v1 = $1470;
        
        {ESLVal v2 = $1469;
        
        return dynamicVarsJExp(v0).add(flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun373"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal t = $args[0];
        return dynamicVarsJStrArm(t);
          }
        }),v1)).add(dynamicVarsJCommand(v2)));
      }
      }
      }
      }
    case "JCaseBool": {ESLVal $1468 = _v1021.termRef(0);
        ESLVal $1467 = _v1021.termRef(1);
        ESLVal $1466 = _v1021.termRef(2);
        
        {ESLVal v0 = $1468;
        
        {ESLVal v1 = $1467;
        
        {ESLVal v2 = $1466;
        
        return dynamicVarsJExp(v0).add(flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun374"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal t = $args[0];
        return dynamicVarsJBoolArm(t);
          }
        }),v1)).add(dynamicVarsJCommand(v2)));
      }
      }
      }
      }
    case "JLet": {ESLVal $1465 = _v1021.termRef(0);
        ESLVal $1464 = _v1021.termRef(1);
        
        {ESLVal v0 = $1465;
        
        {ESLVal v1 = $1464;
        
        return flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun375"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal f = $args[0];
        return dynamicVarsJExp(fieldJExp(f));
          }
        }),v0)).add(reject.apply(new ESLVal(new Function(new ESLVal("fun376"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal n = $args[0];
        return member.apply(n,map.apply(fieldName,v0));
          }
        }),dynamicVarsJCommand(v1)));
      }
      }
      }
    case "JPLet": {ESLVal $1463 = _v1021.termRef(0);
        ESLVal $1462 = _v1021.termRef(1);
        
        {ESLVal v0 = $1463;
        
        {ESLVal v1 = $1462;
        
        return flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun377"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal f = $args[0];
        return dynamicVarsJExp(fieldJExp(f));
          }
        }),v0)).add(reject.apply(new ESLVal(new Function(new ESLVal("fun378"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal n = $args[0];
        return member.apply(n,map.apply(fieldName,v0));
          }
        }),dynamicVarsJCommand(v1)));
      }
      }
      }
    case "JLetRec": {ESLVal $1461 = _v1021.termRef(0);
        ESLVal $1460 = _v1021.termRef(1);
        
        {ESLVal v0 = $1461;
        
        {ESLVal v1 = $1460;
        
        return reject.apply(new ESLVal(new Function(new ESLVal("fun379"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal n = $args[0];
        return member.apply(n,map.apply(fieldName,v0));
          }
        }),flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun380"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal f = $args[0];
        return dynamicVarsJExp(fieldJExp(f));
          }
        }),v0)).add(dynamicVarsJCommand(v1)));
      }
      }
      }
    case "JUpdate": {ESLVal $1459 = _v1021.termRef(0);
        ESLVal $1458 = _v1021.termRef(1);
        
        {ESLVal v0 = $1459;
        
        {ESLVal v1 = $1458;
        
        return ESLVal.list(v0).add(dynamicVarsJExp(v1));
      }
      }
      }
    case "JStatement": {ESLVal $1457 = _v1021.termRef(0);
        
        {ESLVal v0 = $1457;
        
        return dynamicVarsJExp(v0);
      }
      }
    case "JFor": {ESLVal $1456 = _v1021.termRef(0);
        ESLVal $1455 = _v1021.termRef(1);
        ESLVal $1454 = _v1021.termRef(2);
        ESLVal $1453 = _v1021.termRef(3);
        
        {ESLVal listName = $1456;
        
        {ESLVal v0 = $1455;
        
        {ESLVal v1 = $1454;
        
        {ESLVal v2 = $1453;
        
        return ESLVal.list(listName).add(dynamicVarsJExp(v1).add(dynamicVarsJCommand(v2)));
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(5087,7258)").add(ESLVal.list(_v1021)));
    }
    }
  }
  public static ESLVal dynamicVarsJCommand = new ESLVal(new Function(new ESLVal("dynamicVarsJCommand"),null) { public ESLVal apply(ESLVal... args) { return dynamicVarsJCommand(args[0]); }});
public static void main(String[] args) {
  }
}