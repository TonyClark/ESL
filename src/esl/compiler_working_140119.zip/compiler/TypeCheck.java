package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
// import static esl.Lists.*;
import static esl.compiler.Types.*;
import static esl.Tables.*;
import static esl.Displays.*;
import static esl.compiler.UnusedVars.*;
import static esl.compiler.Warnings.*;
import static esl.compiler.Strings.*;
import static esl.compiler.Info.*;
import java.util.function.Supplier;
public class TypeCheck {
  public static ESLVal getSelf() { return $null; }
  private static ESLVal p0 = new ESLVal("Pos",$zero,$zero);
  private static ESLVal actType0 = new ESLVal("ActType",p0,$nil,$nil);
  private static ESLVal contentType = new ESLVal("UnionType",p0,ESLVal.list(new ESLVal("TermType",p0,new ESLVal("RawText"),ESLVal.list(new ESLVal("StrType",p0))),new ESLVal("TermType",p0,new ESLVal("ESLSource"),ESLVal.list(new ESLVal("StrType",p0),new ESLVal("StrType",p0))),new ESLVal("TermType",p0,new ESLVal("JavaSource"),ESLVal.list(new ESLVal("StrType",p0),new ESLVal("StrType",p0),new ESLVal("StrType",p0)))));
  private static ESLVal editMessage = new ESLVal("MessageType",p0,ESLVal.list(new ESLVal("TermType",p0,new ESLVal("Edit"),ESLVal.list(contentType))));
  private static ESLVal env0 = ESLVal.list(new ESLVal("Map",new ESLVal("edb"),new ESLVal("ActType",p0,ESLVal.list(new ESLVal("Dec",p0,new ESLVal("button"),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("StrType",p0),new ESLVal("StrType",p0),new ESLVal("StrType",p0),new ESLVal("StrType",p0),new ESLVal("FunType",p0,$nil,new ESLVal("VoidType",p0))),new ESLVal("VoidType",p0)),$null),new ESLVal("Dec",p0,new ESLVal("display"),new ESLVal("ForallType",p0,ESLVal.list(new ESLVal("T")),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("StrType",p0),new ESLVal("VarType",p0,new ESLVal("T"))),new ESLVal("VarType",p0,new ESLVal("T")))),$null)),ESLVal.list(editMessage))),new ESLVal("Map",new ESLVal("kill"),new ESLVal("ForallType",p0,ESLVal.list(new ESLVal("T")),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("VarType",p0,new ESLVal("T"))),new ESLVal("VoidType",p0)))),new ESLVal("Map",new ESLVal("print"),new ESLVal("ForallType",p0,ESLVal.list(new ESLVal("T")),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("VarType",p0,new ESLVal("T"))),new ESLVal("VoidType",p0)))),new ESLVal("Map",new ESLVal("parse"),new ESLVal("ForallType",p0,ESLVal.list(new ESLVal("T")),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("StrType",p0)),new ESLVal("VarType",p0,new ESLVal("T"))))),new ESLVal("Map",new ESLVal("random"),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("IntType",p0)),new ESLVal("IntType",p0))),new ESLVal("Map",new ESLVal("wait"),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("IntType",p0)),new ESLVal("VoidType",p0))),new ESLVal("Map",new ESLVal("stopAll"),new ESLVal("FunType",p0,$nil,new ESLVal("VoidType",p0))),new ESLVal("Map",new ESLVal("isqrt"),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("IntType",p0)),new ESLVal("FloatType",p0))),new ESLVal("Map",new ESLVal("round"),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("FloatType",p0)),new ESLVal("IntType",p0))),new ESLVal("Map",new ESLVal("builtin"),new ESLVal("ForallType",p0,ESLVal.list(new ESLVal("T")),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("StrType",p0),new ESLVal("StrType",p0),new ESLVal("IntType",p0)),new ESLVal("VarType",p0,new ESLVal("T"))))));
  private static ESLVal cnstrEnv0 = ESLVal.list(new ESLVal("Map",new ESLVal("Time"),new ESLVal("UnionType",p0,ESLVal.list(new ESLVal("TermType",p0,new ESLVal("Time"),ESLVal.list(new ESLVal("IntType",p0)))))));
  private static ESLVal tenv0 = ESLVal.list(new ESLVal("Map",new ESLVal("EditType"),contentType),new ESLVal("Map",new ESLVal("Time"),new ESLVal("UnionType",p0,ESLVal.list(new ESLVal("TermType",p0,new ESLVal("Time"),ESLVal.list(new ESLVal("IntType",p0)))))),new ESLVal("Map",new ESLVal("Point"),new ESLVal("UnionType",p0,ESLVal.list(new ESLVal("TermType",p0,new ESLVal("Point"),ESLVal.list(new ESLVal("IntType",p0),new ESLVal("IntType",p0)))))));
  public static ESLVal main = new ESLVal(new Function(new ESLVal("main"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      return new ESLVal(new BehaviourAdapter(false,getSelf(),new ESLVal("main")) {
          

          public ESLVal handle(ESLVal $m) {{ESLVal _v1179 = $m;
            
            return error(new ESLVal("case error at Pos(0,0)").add(ESLVal.list(_v1179)));
          }}
          public ESLVal get(String name) {
            switch(name) {
              
              default: throw new Error("ref illegal " + self + "." + name);
            }
          }
        public void handleTime(ESLVal $t) {
          {}
        }
        public ESLVal init() {
            return ((Supplier<ESLVal>)() -> { 
                {new Function(new ESLVal("try"),getSelf()) {
                  public ESLVal apply(ESLVal... args) { 
                    try { 
                      return typeCheckModule(new ESLVal("esl/compiler/test1.esl"));
                    } catch(ESLError $exception) {
                      ESLVal $x = $exception.value;
                      {ESLVal _v1178 = $x;
                  
                  {ESLVal message = _v1178;
                  
                  return print.apply(new ESLVal("Type Error: ").add(message));
                }
                }
                    }
                  }
                }.apply();
                print.apply(new ESLVal("DONE"));
                return stopAll.apply();}
              }).get();
          }
        });
    }
  });
private static ESLVal ppPattern(ESLVal p) {
    
    {ESLVal _v1040 = p;
      
      switch(_v1040.termName) {
      case "PAdd": {ESLVal $1531 = _v1040.termRef(0);
        ESLVal $1530 = _v1040.termRef(1);
        ESLVal $1529 = _v1040.termRef(2);
        
        {ESLVal l = $1531;
        
        {ESLVal p1 = $1530;
        
        {ESLVal p2 = $1529;
        
        return ppPattern(p1).add(new ESLVal(" + ").add(ppPattern(p2)));
      }
      }
      }
      }
    case "PVar": {ESLVal $1528 = _v1040.termRef(0);
        ESLVal $1527 = _v1040.termRef(1);
        ESLVal $1526 = _v1040.termRef(2);
        
        {ESLVal l = $1528;
        
        {ESLVal n = $1527;
        
        {ESLVal t = $1526;
        
        return n;
      }
      }
      }
      }
    case "PTerm": {ESLVal $1523 = _v1040.termRef(0);
        ESLVal $1522 = _v1040.termRef(1);
        ESLVal $1521 = _v1040.termRef(2);
        ESLVal $1520 = _v1040.termRef(3);
        
        if($1521.isCons())
        {ESLVal $1524 = $1521.head();
          ESLVal $1525 = $1521.tail();
          
          {ESLVal l = $1523;
          
          {ESLVal n = $1522;
          
          {ESLVal ts = $1521;
          
          {ESLVal ps = $1520;
          
          return n.add(ppTypes(ts,$nil).add(new ESLVal("").add(ppPatterns(ps))));
        }
        }
        }
        }
        }
      else if($1521.isNil())
        {ESLVal l = $1523;
          
          {ESLVal n = $1522;
          
          {ESLVal ps = $1520;
          
          return n.add(ppPatterns(ps));
        }
        }
        }
      else {ESLVal l = $1523;
          
          {ESLVal n = $1522;
          
          {ESLVal ts = $1521;
          
          {ESLVal ps = $1520;
          
          return n.add(ppTypes(ts,$nil).add(new ESLVal("").add(ppPatterns(ps))));
        }
        }
        }
        }
      }
    case "PApplyType": {ESLVal $1519 = _v1040.termRef(0);
        ESLVal $1518 = _v1040.termRef(1);
        ESLVal $1517 = _v1040.termRef(2);
        
        {ESLVal l = $1519;
        
        {ESLVal _v1631 = $1518;
        
        {ESLVal ts = $1517;
        
        return ppPattern(_v1631).add(ppTypes(ts,$nil));
      }
      }
      }
      }
    case "PNil": {ESLVal $1516 = _v1040.termRef(0);
        
        {ESLVal l = $1516;
        
        return new ESLVal("[]");
      }
      }
    case "PEmptySet": {ESLVal $1515 = _v1040.termRef(0);
        
        {ESLVal l = $1515;
        
        return new ESLVal("Set{}");
      }
      }
    case "PEmptyBag": {ESLVal $1514 = _v1040.termRef(0);
        
        {ESLVal l = $1514;
        
        return new ESLVal("Bag{}");
      }
      }
    case "PInt": {ESLVal $1513 = _v1040.termRef(0);
        ESLVal $1512 = _v1040.termRef(1);
        
        {ESLVal l = $1513;
        
        {ESLVal n = $1512;
        
        return new ESLVal("").add(n);
      }
      }
      }
    case "PBool": {ESLVal $1511 = _v1040.termRef(0);
        ESLVal $1510 = _v1040.termRef(1);
        
        {ESLVal l = $1511;
        
        {ESLVal b = $1510;
        
        return new ESLVal("").add(b);
      }
      }
      }
    case "PStr": {ESLVal $1509 = _v1040.termRef(0);
        ESLVal $1508 = _v1040.termRef(1);
        
        {ESLVal l = $1509;
        
        {ESLVal s = $1508;
        
        return s;
      }
      }
      }
    case "PCons": {ESLVal $1507 = _v1040.termRef(0);
        ESLVal $1506 = _v1040.termRef(1);
        ESLVal $1505 = _v1040.termRef(2);
        
        {ESLVal l = $1507;
        
        {ESLVal h = $1506;
        
        {ESLVal t = $1505;
        
        return ppPattern(h).add(new ESLVal(":").add(ppPattern(t)));
      }
      }
      }
      }
    case "PSetCons": {ESLVal $1504 = _v1040.termRef(0);
        ESLVal $1503 = _v1040.termRef(1);
        ESLVal $1502 = _v1040.termRef(2);
        
        {ESLVal l = $1504;
        
        {ESLVal p1 = $1503;
        
        {ESLVal p2 = $1502;
        
        return new ESLVal("Set{").add(ppPattern(p1).add(new ESLVal(" | ").add(ppPattern(p2).add(new ESLVal("}")))));
      }
      }
      }
      }
    case "PBagCons": {ESLVal $1501 = _v1040.termRef(0);
        ESLVal $1500 = _v1040.termRef(1);
        ESLVal $1499 = _v1040.termRef(2);
        
        {ESLVal l = $1501;
        
        {ESLVal p1 = $1500;
        
        {ESLVal p2 = $1499;
        
        return new ESLVal("Bag{").add(ppPattern(p1).add(new ESLVal(" | ").add(ppPattern(p2).add(new ESLVal("}")))));
      }
      }
      }
      }
      default: {ESLVal _v1632 = _v1040;
        
        return new ESLVal("<unknown: ").add(_v1632.add(new ESLVal(">")));
      }
    }
    }
  }
  private static ESLVal ppPattern = new ESLVal(new Function(new ESLVal("ppPattern"),null) { public ESLVal apply(ESLVal... args) { return ppPattern(args[0]); }});
  private static ESLVal ppPatterns(ESLVal ps) {
    
    return map.apply(ppPattern,ps);
  }
  private static ESLVal ppPatterns = new ESLVal(new Function(new ESLVal("ppPatterns"),null) { public ESLVal apply(ESLVal... args) { return ppPatterns(args[0]); }});
  private static ESLVal ppTypeEnv(ESLVal env) {
    
    {ESLVal[] s = new ESLVal[]{new ESLVal("[")};
      
      {{
      ESLVal _v1043 = env;
      while(_v1043.isCons()) {
        ESLVal _v1042 = _v1043.headVal;
        {ESLVal _v1041 = new ESLVal(new Function(new ESLVal("forp"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                {ESLVal _v1044 = _v1042;
                  
                  switch(_v1044.termName) {
                  case "Map": {ESLVal $1533 = _v1044.termRef(0);
                    ESLVal $1532 = _v1044.termRef(1);
                    
                    {ESLVal n = $1533;
                    
                    {ESLVal t = $1532;
                    
                    {s[0] = s[0].add(n.add(new ESLVal("->").add(ppType(t,env).add(new ESLVal(",")))));
                  return $null;}
                  }
                  }
                  }
                  default: {ESLVal $$$ = _v1044;
                    
                    return $null;
                  }
                }
                }
              }
            });
          
          _v1041.apply();
        }
        _v1043 = _v1043.tailVal;}
    }
    return s[0].add(new ESLVal("]"));}
    }
  }
  private static ESLVal ppTypeEnv = new ESLVal(new Function(new ESLVal("ppTypeEnv"),null) { public ESLVal apply(ESLVal... args) { return ppTypeEnv(args[0]); }});
  private static ESLVal ppTypes(ESLVal ts,ESLVal env) {
    
    return map.apply(ppType0(env),ts);
  }
  private static ESLVal ppTypes = new ESLVal(new Function(new ESLVal("ppTypes"),null) { public ESLVal apply(ESLVal... args) { return ppTypes(args[0],args[1]); }});
  private static ESLVal getTypeName(ESLVal t0,ESLVal env) {
    
    {ESLVal[] name = new ESLVal[]{$null};
      
      {{
      ESLVal _v1047 = env;
      while(_v1047.isCons()) {
        ESLVal _v1046 = _v1047.headVal;
        {ESLVal _v1045 = new ESLVal(new Function(new ESLVal("forp"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                {ESLVal _v1048 = _v1046;
                  
                  switch(_v1048.termName) {
                  case "Map": {ESLVal $1535 = _v1048.termRef(0);
                    ESLVal $1534 = _v1048.termRef(1);
                    
                    {ESLVal n = $1535;
                    
                    {ESLVal t = $1534;
                    
                    if(typeEqual.apply(t0,t).boolVal)
                    {name[0] = n;
                    return $null;}
                    else
                      return $null;
                  }
                  }
                  }
                  default: {ESLVal $$$ = _v1048;
                    
                    return $null;
                  }
                }
                }
              }
            });
          
          _v1045.apply();
        }
        _v1047 = _v1047.tailVal;}
    }
    return name[0];}
    }
  }
  private static ESLVal getTypeName = new ESLVal(new Function(new ESLVal("getTypeName"),null) { public ESLVal apply(ESLVal... args) { return getTypeName(args[0],args[1]); }});
  private static ESLVal ppType0(ESLVal env) {
    
    return new ESLVal(new Function(new ESLVal("fun381"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal t = $args[0];
      return ppType(t,env);
        }
      });
  }
  private static ESLVal ppType0 = new ESLVal(new Function(new ESLVal("ppType0"),null) { public ESLVal apply(ESLVal... args) { return ppType0(args[0]); }});
  private static ESLVal ppHandlers(ESLVal handlers,ESLVal env) {
    
    {ESLVal _v1049 = handlers;
      
      if(_v1049.isCons())
      {ESLVal $1536 = _v1049.head();
        ESLVal $1537 = _v1049.tail();
        
        switch($1536.termName) {
        case "MessageType": {ESLVal $1539 = $1536.termRef(0);
          ESLVal $1538 = $1536.termRef(1);
          
          if($1538.isCons())
          {ESLVal $1540 = $1538.head();
            ESLVal $1541 = $1538.tail();
            
            {ESLVal l = $1539;
            
            {ESLVal t = $1540;
            
            {ESLVal ts = $1541;
            
            {ESLVal hs = $1537;
            
            return ppType(t,env).add(new ESLVal("; ").add(ppHandlers(hs,env)));
          }
          }
          }
          }
          }
        else if($1538.isNil())
          return error(new ESLVal("case error at Pos(5559,5693)").add(ESLVal.list(_v1049)));
        else return error(new ESLVal("case error at Pos(5559,5693)").add(ESLVal.list(_v1049)));
        }
        default: return error(new ESLVal("case error at Pos(5559,5693)").add(ESLVal.list(_v1049)));
      }
      }
    else if(_v1049.isNil())
      return new ESLVal("");
    else return error(new ESLVal("case error at Pos(5559,5693)").add(ESLVal.list(_v1049)));
    }
  }
  private static ESLVal ppHandlers = new ESLVal(new Function(new ESLVal("ppHandlers"),null) { public ESLVal apply(ESLVal... args) { return ppHandlers(args[0],args[1]); }});
  private static ESLVal ppDecs(ESLVal decs,ESLVal env) {
    
    {ESLVal _v1050 = decs;
      
      if(_v1050.isCons())
      {ESLVal $1542 = _v1050.head();
        ESLVal $1543 = _v1050.tail();
        
        switch($1542.termName) {
        case "Dec": {ESLVal $1547 = $1542.termRef(0);
          ESLVal $1546 = $1542.termRef(1);
          ESLVal $1545 = $1542.termRef(2);
          ESLVal $1544 = $1542.termRef(3);
          
          {ESLVal l = $1547;
          
          {ESLVal n = $1546;
          
          {ESLVal t = $1545;
          
          {ESLVal d = $1544;
          
          {ESLVal _v1630 = $1543;
          
          return n.add(new ESLVal("::").add(ppType(t,env).add(new ESLVal("; ").add(ppDecs(_v1630,env)))));
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(5734,5848)").add(ESLVal.list(_v1050)));
      }
      }
    else if(_v1050.isNil())
      return new ESLVal("");
    else return error(new ESLVal("case error at Pos(5734,5848)").add(ESLVal.list(_v1050)));
    }
  }
  private static ESLVal ppDecs = new ESLVal(new Function(new ESLVal("ppDecs"),null) { public ESLVal apply(ESLVal... args) { return ppDecs(args[0],args[1]); }});
  private static ESLVal ppType(ESLVal t,ESLVal env) {
    
    if(getTypeName(t,env).neql($null).boolVal)
      return getTypeName(t,env);
      else
        {ESLVal _v1051 = t;
          
          switch(_v1051.termName) {
          case "ActType": {ESLVal $1617 = _v1051.termRef(0);
            ESLVal $1616 = _v1051.termRef(1);
            ESLVal $1615 = _v1051.termRef(2);
            
            {ESLVal l = $1617;
            
            {ESLVal decs = $1616;
            
            {ESLVal handlers = $1615;
            
            return new ESLVal("Act { ").add(ppHandlers(handlers,env).add(new ESLVal(" }")));
          }
          }
          }
          }
        case "ApplyType": {ESLVal $1614 = _v1051.termRef(0);
            ESLVal $1613 = _v1051.termRef(1);
            ESLVal $1612 = _v1051.termRef(2);
            
            {ESLVal l = $1614;
            
            {ESLVal n = $1613;
            
            {ESLVal args = $1612;
            
            return n.add(map.apply(ppType0(env),args));
          }
          }
          }
          }
        case "ApplyTypeFun": {ESLVal $1611 = _v1051.termRef(0);
            ESLVal $1610 = _v1051.termRef(1);
            ESLVal $1609 = _v1051.termRef(2);
            
            {ESLVal l = $1611;
            
            {ESLVal op = $1610;
            
            {ESLVal args = $1609;
            
            return ppType(op,env).add(map.apply(ppType0(env),args));
          }
          }
          }
          }
        case "ArrayType": {ESLVal $1608 = _v1051.termRef(0);
            ESLVal $1607 = _v1051.termRef(1);
            
            {ESLVal l = $1608;
            
            {ESLVal _v1629 = $1607;
            
            return new ESLVal("Array[").add(ppType(_v1629,env).add(new ESLVal("]")));
          }
          }
          }
        case "BagType": {ESLVal $1606 = _v1051.termRef(0);
            ESLVal $1605 = _v1051.termRef(1);
            
            {ESLVal l = $1606;
            
            {ESLVal _v1628 = $1605;
            
            return new ESLVal("Set{").add(ppType(_v1628,env).add(new ESLVal("}")));
          }
          }
          }
        case "BoolType": {ESLVal $1604 = _v1051.termRef(0);
            
            {ESLVal l = $1604;
            
            return new ESLVal("Bool");
          }
          }
        case "ExtendedAct": {ESLVal $1603 = _v1051.termRef(0);
            ESLVal $1602 = _v1051.termRef(1);
            ESLVal $1601 = _v1051.termRef(2);
            ESLVal $1600 = _v1051.termRef(3);
            
            {ESLVal l = $1603;
            
            {ESLVal parent = $1602;
            
            {ESLVal decs = $1601;
            
            {ESLVal handlers = $1600;
            
            return new ESLVal("Act extends ").add(ppType(parent,env).add(new ESLVal(" { ").add(ppHandlers(handlers,env).add(new ESLVal(" }")))));
          }
          }
          }
          }
          }
        case "FloatType": {ESLVal $1599 = _v1051.termRef(0);
            
            {ESLVal l = $1599;
            
            return new ESLVal("Float");
          }
          }
        case "FieldType": {ESLVal $1598 = _v1051.termRef(0);
            ESLVal $1597 = _v1051.termRef(1);
            ESLVal $1596 = _v1051.termRef(2);
            
            {ESLVal l = $1598;
            
            {ESLVal n = $1597;
            
            {ESLVal _v1627 = $1596;
            
            return n.add(new ESLVal("::").add(ppType(_v1627,env)));
          }
          }
          }
          }
        case "ForallType": {ESLVal $1595 = _v1051.termRef(0);
            ESLVal $1594 = _v1051.termRef(1);
            ESLVal $1593 = _v1051.termRef(2);
            
            {ESLVal l = $1595;
            
            {ESLVal ns = $1594;
            
            {ESLVal _v1626 = $1593;
            
            return new ESLVal("Forall").add(ns.add(new ESLVal(".").add(ppType(_v1626,env))));
          }
          }
          }
          }
        case "FunType": {ESLVal $1592 = _v1051.termRef(0);
            ESLVal $1591 = _v1051.termRef(1);
            ESLVal $1590 = _v1051.termRef(2);
            
            {ESLVal l = $1592;
            
            {ESLVal d = $1591;
            
            {ESLVal r = $1590;
            
            return map.apply(ppType0(env),d).add(new ESLVal("->").add(ppType(r,env)));
          }
          }
          }
          }
        case "TaggedFunType": {ESLVal $1589 = _v1051.termRef(0);
            ESLVal $1588 = _v1051.termRef(1);
            ESLVal $1587 = _v1051.termRef(2);
            ESLVal $1586 = _v1051.termRef(3);
            
            {ESLVal l = $1589;
            
            {ESLVal d = $1588;
            
            {ESLVal p = $1587;
            
            {ESLVal r = $1586;
            
            return map.apply(ppType0(env),d).add(new ESLVal("->").add(ppType(r,env)));
          }
          }
          }
          }
          }
        case "IntType": {ESLVal $1585 = _v1051.termRef(0);
            
            {ESLVal l = $1585;
            
            return new ESLVal("Int");
          }
          }
        case "ListType": {ESLVal $1584 = _v1051.termRef(0);
            ESLVal $1583 = _v1051.termRef(1);
            
            {ESLVal l = $1584;
            
            {ESLVal _v1625 = $1583;
            
            return new ESLVal("[").add(ppType(_v1625,env).add(new ESLVal("]")));
          }
          }
          }
        case "NullType": {ESLVal $1582 = _v1051.termRef(0);
            
            {ESLVal l = $1582;
            
            return new ESLVal("Null");
          }
          }
        case "ObserverType": {ESLVal $1581 = _v1051.termRef(0);
            ESLVal $1580 = _v1051.termRef(1);
            ESLVal $1579 = _v1051.termRef(2);
            
            {ESLVal l = $1581;
            
            {ESLVal s = $1580;
            
            {ESLVal m = $1579;
            
            return new ESLVal("Observer[").add(ppType(s,env).add(new ESLVal(",").add(ppType(m,env).add(new ESLVal("]")))));
          }
          }
          }
          }
        case "ObservedType": {ESLVal $1578 = _v1051.termRef(0);
            ESLVal $1577 = _v1051.termRef(1);
            ESLVal $1576 = _v1051.termRef(2);
            
            {ESLVal l = $1578;
            
            {ESLVal s = $1577;
            
            {ESLVal m = $1576;
            
            return new ESLVal("Observed[").add(ppType(s,env).add(new ESLVal(",").add(ppType(m,env).add(new ESLVal("]")))));
          }
          }
          }
          }
        case "RecType": {ESLVal $1575 = _v1051.termRef(0);
            ESLVal $1574 = _v1051.termRef(1);
            ESLVal $1573 = _v1051.termRef(2);
            
            {ESLVal l = $1575;
            
            {ESLVal n = $1574;
            
            {ESLVal _v1624 = $1573;
            
            return new ESLVal("rec ").add(n.add(new ESLVal(".").add(ppType(_v1624,env))));
          }
          }
          }
          }
        case "RecordType": {ESLVal $1572 = _v1051.termRef(0);
            ESLVal $1571 = _v1051.termRef(1);
            
            {ESLVal l = $1572;
            
            {ESLVal fs = $1571;
            
            return new ESLVal("{").add(ppDecs(fs,env).add(new ESLVal("}")));
          }
          }
          }
        case "SetType": {ESLVal $1570 = _v1051.termRef(0);
            ESLVal $1569 = _v1051.termRef(1);
            
            {ESLVal l = $1570;
            
            {ESLVal _v1623 = $1569;
            
            return new ESLVal("Set{").add(ppType(_v1623,env).add(new ESLVal("}")));
          }
          }
          }
        case "StrType": {ESLVal $1568 = _v1051.termRef(0);
            
            {ESLVal l = $1568;
            
            return new ESLVal("Str");
          }
          }
        case "TableType": {ESLVal $1567 = _v1051.termRef(0);
            ESLVal $1566 = _v1051.termRef(1);
            ESLVal $1565 = _v1051.termRef(2);
            
            {ESLVal l = $1567;
            
            {ESLVal k = $1566;
            
            {ESLVal v = $1565;
            
            return new ESLVal("Hash[").add(ppType(k,env).add(new ESLVal(",").add(ppType(v,env).add(new ESLVal("]")))));
          }
          }
          }
          }
        case "TermType": {ESLVal $1564 = _v1051.termRef(0);
            ESLVal $1563 = _v1051.termRef(1);
            ESLVal $1562 = _v1051.termRef(2);
            
            {ESLVal l = $1564;
            
            {ESLVal n = $1563;
            
            {ESLVal ts = $1562;
            
            return n.add(map.apply(ppType0(env),ts));
          }
          }
          }
          }
        case "TypeFun": {ESLVal $1561 = _v1051.termRef(0);
            ESLVal $1560 = _v1051.termRef(1);
            ESLVal $1559 = _v1051.termRef(2);
            
            {ESLVal l = $1561;
            
            {ESLVal ns = $1560;
            
            {ESLVal _v1622 = $1559;
            
            return new ESLVal("Fun").add(ns.add(new ESLVal(".").add(ppType(_v1622,env))));
          }
          }
          }
          }
        case "UnfoldType": {ESLVal $1558 = _v1051.termRef(0);
            ESLVal $1557 = _v1051.termRef(1);
            
            {ESLVal l = $1558;
            
            {ESLVal _v1621 = $1557;
            
            return new ESLVal("unfold ").add(ppType(_v1621,env));
          }
          }
          }
        case "UnionType": {ESLVal $1556 = _v1051.termRef(0);
            ESLVal $1555 = _v1051.termRef(1);
            
            {ESLVal l = $1556;
            
            {ESLVal ts = $1555;
            
            return new ESLVal("union ").add(map.apply(ppType0(env),ts));
          }
          }
          }
        case "VarType": {ESLVal $1554 = _v1051.termRef(0);
            ESLVal $1553 = _v1051.termRef(1);
            
            {ESLVal l = $1554;
            
            {ESLVal n = $1553;
            
            return n;
          }
          }
          }
        case "VoidType": {ESLVal $1552 = _v1051.termRef(0);
            
            {ESLVal l = $1552;
            
            return new ESLVal("Void");
          }
          }
        case "UnionRef": {ESLVal $1551 = _v1051.termRef(0);
            ESLVal $1550 = _v1051.termRef(1);
            ESLVal $1549 = _v1051.termRef(2);
            
            {ESLVal l = $1551;
            
            {ESLVal _v1620 = $1550;
            
            {ESLVal n = $1549;
            
            return ppType(_v1620,env).add(new ESLVal(".").add(n));
          }
          }
          }
          }
        case "TypeClosure": {ESLVal $1548 = _v1051.termRef(0);
            
            {ESLVal f = $1548;
            
            return f.add(new ESLVal(""));
          }
          }
          default: {ESLVal x = _v1051;
            
            return new ESLVal("<unknown ").add(x.add(new ESLVal(">")));
          }
        }
        }
  }
  private static ESLVal ppType = new ESLVal(new Function(new ESLVal("ppType"),null) { public ESLVal apply(ESLVal... args) { return ppType(args[0],args[1]); }});
  private static ESLVal typeEnv(ESLVal defs) {
    
    {ESLVal _v1052 = defs;
      
      if(_v1052.isCons())
      {ESLVal $1618 = _v1052.head();
        ESLVal $1619 = _v1052.tail();
        
        switch($1618.termName) {
        case "TypeBind": {ESLVal $1627 = $1618.termRef(0);
          ESLVal $1626 = $1618.termRef(1);
          ESLVal $1625 = $1618.termRef(2);
          ESLVal $1624 = $1618.termRef(3);
          
          {ESLVal l = $1627;
          
          {ESLVal n = $1626;
          
          {ESLVal t = $1625;
          
          {ESLVal e = $1624;
          
          {ESLVal ds = $1619;
          
          return typeEnv(ds).cons(new ESLVal("Map",n,t));
        }
        }
        }
        }
        }
        }
      case "DataBind": {ESLVal $1623 = $1618.termRef(0);
          ESLVal $1622 = $1618.termRef(1);
          ESLVal $1621 = $1618.termRef(2);
          ESLVal $1620 = $1618.termRef(3);
          
          {ESLVal l = $1623;
          
          {ESLVal n = $1622;
          
          {ESLVal t = $1621;
          
          {ESLVal e = $1620;
          
          {ESLVal ds = $1619;
          
          return typeEnv(ds).cons(new ESLVal("Map",n,t));
        }
        }
        }
        }
        }
        }
        default: {ESLVal b = $1618;
          
          {ESLVal ds = $1619;
          
          return typeEnv(ds);
        }
        }
      }
      }
    else if(_v1052.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(8122,8365)").add(ESLVal.list(_v1052)));
    }
  }
  private static ESLVal typeEnv = new ESLVal(new Function(new ESLVal("typeEnv"),null) { public ESLVal apply(ESLVal... args) { return typeEnv(args[0]); }});
  private static ESLVal cnstrEnv(ESLVal defs,ESLVal env) {
    
    {ESLVal _v1053 = defs;
      
      if(_v1053.isCons())
      {ESLVal $1628 = _v1053.head();
        ESLVal $1629 = _v1053.tail();
        
        switch($1628.termName) {
        case "TypeBind": {ESLVal $1637 = $1628.termRef(0);
          ESLVal $1636 = $1628.termRef(1);
          ESLVal $1635 = $1628.termRef(2);
          ESLVal $1634 = $1628.termRef(3);
          
          switch($1635.termName) {
          case "RecType": {ESLVal $1642 = $1635.termRef(0);
            ESLVal $1641 = $1635.termRef(1);
            ESLVal $1640 = $1635.termRef(2);
            
            switch($1640.termName) {
            case "UnionType": {ESLVal $1644 = $1640.termRef(0);
              ESLVal $1643 = $1640.termRef(1);
              
              {ESLVal l = $1637;
              
              {ESLVal n = $1636;
              
              {ESLVal ll = $1642;
              
              {ESLVal m = $1641;
              
              {ESLVal lll = $1644;
              
              {ESLVal ts = $1643;
              
              {ESLVal e = $1634;
              
              {ESLVal ds = $1629;
              
              return getConstructors(l,lookupType.apply(n,env),lookupType.apply(n,env)).add(cnstrEnv(ds,env));
            }
            }
            }
            }
            }
            }
            }
            }
            }
            default: {ESLVal l = $1637;
              
              {ESLVal n = $1636;
              
              {ESLVal t = $1635;
              
              {ESLVal e = $1634;
              
              {ESLVal ds = $1629;
              
              return cnstrEnv(ds,env);
            }
            }
            }
            }
            }
          }
          }
        case "UnionType": {ESLVal $1639 = $1635.termRef(0);
            ESLVal $1638 = $1635.termRef(1);
            
            {ESLVal l = $1637;
            
            {ESLVal n = $1636;
            
            {ESLVal lll = $1639;
            
            {ESLVal ts = $1638;
            
            {ESLVal e = $1634;
            
            {ESLVal ds = $1629;
            
            return getConstructors(l,lookupType.apply(n,env),lookupType.apply(n,env)).add(cnstrEnv(ds,env));
          }
          }
          }
          }
          }
          }
          }
          default: {ESLVal l = $1637;
            
            {ESLVal n = $1636;
            
            {ESLVal t = $1635;
            
            {ESLVal e = $1634;
            
            {ESLVal ds = $1629;
            
            return cnstrEnv(ds,env);
          }
          }
          }
          }
          }
        }
        }
      case "DataBind": {ESLVal $1633 = $1628.termRef(0);
          ESLVal $1632 = $1628.termRef(1);
          ESLVal $1631 = $1628.termRef(2);
          ESLVal $1630 = $1628.termRef(3);
          
          {ESLVal l = $1633;
          
          {ESLVal n = $1632;
          
          {ESLVal t = $1631;
          
          {ESLVal e = $1630;
          
          {ESLVal ds = $1629;
          
          return getConstructors(l,lookupType.apply(n,env),lookupType.apply(n,env)).add(cnstrEnv(ds,env));
        }
        }
        }
        }
        }
        }
        default: {ESLVal b = $1628;
          
          {ESLVal ds = $1629;
          
          return cnstrEnv(ds,env);
        }
        }
      }
      }
    else if(_v1053.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(8497,9130)").add(ESLVal.list(_v1053)));
    }
  }
  private static ESLVal cnstrEnv = new ESLVal(new Function(new ESLVal("cnstrEnv"),null) { public ESLVal apply(ESLVal... args) { return cnstrEnv(args[0],args[1]); }});
  private static ESLVal getConstructors(ESLVal l,ESLVal dataType,ESLVal t) {
    
    {ESLVal _v1054 = t;
      
      switch(_v1054.termName) {
      case "RecType": {ESLVal $1652 = _v1054.termRef(0);
        ESLVal $1651 = _v1054.termRef(1);
        ESLVal $1650 = _v1054.termRef(2);
        
        {ESLVal _v1617 = $1652;
        
        {ESLVal n = $1651;
        
        {ESLVal _v1618 = $1650;
        
        return getConstructors(_v1617,dataType,_v1618);
      }
      }
      }
      }
    case "TypeFun": {ESLVal $1649 = _v1054.termRef(0);
        ESLVal $1648 = _v1054.termRef(1);
        ESLVal $1647 = _v1054.termRef(2);
        
        {ESLVal _v1615 = $1649;
        
        {ESLVal ns = $1648;
        
        {ESLVal _v1616 = $1647;
        
        return getConstructors(_v1615,dataType,_v1616);
      }
      }
      }
      }
    case "UnionType": {ESLVal $1646 = _v1054.termRef(0);
        ESLVal $1645 = _v1054.termRef(1);
        
        {ESLVal _v1612 = $1646;
        
        {ESLVal ts = $1645;
        
        return map.apply(new ESLVal(new Function(new ESLVal("fun382"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1613 = $args[0];
        {ESLVal _v1055 = _v1613;
              
              switch(_v1055.termName) {
              case "TermType": {ESLVal $1655 = _v1055.termRef(0);
                ESLVal $1654 = _v1055.termRef(1);
                ESLVal $1653 = _v1055.termRef(2);
                
                {ESLVal _v1614 = $1655;
                
                {ESLVal n = $1654;
                
                {ESLVal tts = $1653;
                
                return new ESLVal("Map",n,dataType);
              }
              }
              }
              }
              default: return error(new ESLVal("case error at Pos(9649,9715)").add(ESLVal.list(_v1055)));
            }
            }
          }
        }),ts);
      }
      }
      }
      default: {ESLVal _v1619 = _v1054;
        
        return error(new ESLVal("TypeError",l,new ESLVal("cannot extract constructors from ").add(ppType(_v1619,$nil))));
      }
    }
    }
  }
  private static ESLVal getConstructors = new ESLVal(new Function(new ESLVal("getConstructors"),null) { public ESLVal apply(ESLVal... args) { return getConstructors(args[0],args[1],args[2]); }});
  private static ESLVal checkFreeTypes(ESLVal e) {
    
    {ESLVal dom = typeEnvDom.apply(e);
      ESLVal ran = typeEnvRan.apply(e);
      
      {ESLVal freeNames = removeAll.apply(dom,flatten.apply(map.apply(typeFV,ran)));
      
      if(freeNames.eql($nil).boolVal)
      return $null;
      else
        return error(new ESLVal("TypeError",new ESLVal("Pos",$zero,$zero),new ESLVal("Unbound Types: ").add(freeNames)));
    }
    }
  }
  private static ESLVal checkFreeTypes = new ESLVal(new Function(new ESLVal("checkFreeTypes"),null) { public ESLVal apply(ESLVal... args) { return checkFreeTypes(args[0]); }});
  private static ESLVal checkSingletonTypes(ESLVal e) {
    
    {ESLVal _v1056 = e;
      
      if(_v1056.isCons())
      {ESLVal $1656 = _v1056.head();
        ESLVal $1657 = _v1056.tail();
        
        switch($1656.termName) {
        case "Map": {ESLVal $1659 = $1656.termRef(0);
          ESLVal $1658 = $1656.termRef(1);
          
          {ESLVal n = $1659;
          
          {ESLVal t = $1658;
          
          {ESLVal _v1611 = $1657;
          
          if(member.apply(n,typeEnvDom.apply(_v1611)).boolVal)
          return error(new ESLVal("TypeError",new ESLVal("Pos",$zero,$zero),new ESLVal("Duplicate type name: ").add(n)));
          else
            return checkSingletonTypes(_v1611);
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(10419,10640)").add(ESLVal.list(_v1056)));
      }
      }
    else if(_v1056.isNil())
      return $null;
    else return error(new ESLVal("case error at Pos(10419,10640)").add(ESLVal.list(_v1056)));
    }
  }
  private static ESLVal checkSingletonTypes = new ESLVal(new Function(new ESLVal("checkSingletonTypes"),null) { public ESLVal apply(ESLVal... args) { return checkSingletonTypes(args[0]); }});
  private static ESLVal checkSingletonConstructors(ESLVal cnstrEnv) {
    
    {ESLVal _v1057 = cnstrEnv;
      
      if(_v1057.isCons())
      {ESLVal $1660 = _v1057.head();
        ESLVal $1661 = _v1057.tail();
        
        switch($1660.termName) {
        case "Map": {ESLVal $1663 = $1660.termRef(0);
          ESLVal $1662 = $1660.termRef(1);
          
          {ESLVal n = $1663;
          
          {ESLVal t = $1662;
          
          {ESLVal _v1604 = $1661;
          
          if(member.apply(n,typeEnvDom.apply(_v1604)).boolVal)
          { LetRec letrec = new LetRec() {
            ESLVal throwError = new ESLVal(new Function(new ESLVal("throwError"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal _v1605 = $args[0];
              {ESLVal _v1058 = _v1605;
                    
                    switch(_v1058.termName) {
                    case "UnionType": {ESLVal $1674 = _v1058.termRef(0);
                      ESLVal $1673 = _v1058.termRef(1);
                      
                      {ESLVal l = $1674;
                      
                      {ESLVal ts = $1673;
                      
                      return error(new ESLVal("TypeError",l,new ESLVal("Duplicate constructor name: ").add(n)));
                    }
                    }
                    }
                  case "ForallType": {ESLVal $1672 = _v1058.termRef(0);
                      ESLVal $1671 = _v1058.termRef(1);
                      ESLVal $1670 = _v1058.termRef(2);
                      
                      {ESLVal l = $1672;
                      
                      {ESLVal ns = $1671;
                      
                      {ESLVal _v1609 = $1670;
                      
                      return throwError.apply(_v1609);
                    }
                    }
                    }
                    }
                  case "RecType": {ESLVal $1669 = _v1058.termRef(0);
                      ESLVal $1668 = _v1058.termRef(1);
                      ESLVal $1667 = _v1058.termRef(2);
                      
                      {ESLVal l = $1669;
                      
                      {ESLVal _v1607 = $1668;
                      
                      {ESLVal _v1608 = $1667;
                      
                      return throwError.apply(_v1608);
                    }
                    }
                    }
                    }
                  case "TypeFun": {ESLVal $1666 = _v1058.termRef(0);
                      ESLVal $1665 = _v1058.termRef(1);
                      ESLVal $1664 = _v1058.termRef(2);
                      
                      {ESLVal l = $1666;
                      
                      {ESLVal ns = $1665;
                      
                      {ESLVal _v1606 = $1664;
                      
                      return throwError.apply(_v1606);
                    }
                    }
                    }
                    }
                    default: {ESLVal _v1610 = _v1058;
                      
                      return error(new ESLVal("Duplicate constructor name: ").add(n.add(new ESLVal(" ").add(_v1610))));
                    }
                  }
                  }
                }
              });
            
            public ESLVal get(String name) {
              switch(name) {
                case "throwError": return throwError;
                
                default: throw new Error("cannot find letrec binding");
              }
              }
            };
          ESLVal throwError = letrec.get("throwError");
          
            return throwError.apply(t);}
          
          else
            return checkSingletonConstructors(_v1604);
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(10753,11408)").add(ESLVal.list(_v1057)));
      }
      }
    else if(_v1057.isNil())
      return $null;
    else return error(new ESLVal("case error at Pos(10753,11408)").add(ESLVal.list(_v1057)));
    }
  }
  private static ESLVal checkSingletonConstructors = new ESLVal(new Function(new ESLVal("checkSingletonConstructors"),null) { public ESLVal apply(ESLVal... args) { return checkSingletonConstructors(args[0]); }});
  private static ESLVal valueDefs(ESLVal defs) {
    
    {ESLVal _v1059 = defs;
      
      if(_v1059.isCons())
      {ESLVal $1675 = _v1059.head();
        ESLVal $1676 = _v1059.tail();
        
        switch($1675.termName) {
        case "TypeBind": {ESLVal $1688 = $1675.termRef(0);
          ESLVal $1687 = $1675.termRef(1);
          ESLVal $1686 = $1675.termRef(2);
          ESLVal $1685 = $1675.termRef(3);
          
          {ESLVal l = $1688;
          
          {ESLVal n = $1687;
          
          {ESLVal t = $1686;
          
          {ESLVal e = $1685;
          
          {ESLVal ds = $1676;
          
          return valueDefs(ds);
        }
        }
        }
        }
        }
        }
      case "DataBind": {ESLVal $1684 = $1675.termRef(0);
          ESLVal $1683 = $1675.termRef(1);
          ESLVal $1682 = $1675.termRef(2);
          ESLVal $1681 = $1675.termRef(3);
          
          {ESLVal l1 = $1684;
          
          {ESLVal n = $1683;
          
          {ESLVal t = $1682;
          
          {ESLVal e = $1681;
          
          {ESLVal ds = $1676;
          
          return valueDefs(ds);
        }
        }
        }
        }
        }
        }
      case "CnstrBind": {ESLVal $1680 = $1675.termRef(0);
          ESLVal $1679 = $1675.termRef(1);
          ESLVal $1678 = $1675.termRef(2);
          ESLVal $1677 = $1675.termRef(3);
          
          {ESLVal l1 = $1680;
          
          {ESLVal n = $1679;
          
          {ESLVal t = $1678;
          
          {ESLVal e = $1677;
          
          {ESLVal ds = $1676;
          
          return valueDefs(ds);
        }
        }
        }
        }
        }
        }
        default: {ESLVal b = $1675;
          
          {ESLVal ds = $1676;
          
          return valueDefs(ds).cons(b);
        }
        }
      }
      }
    else if(_v1059.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(11448,11758)").add(ESLVal.list(_v1059)));
    }
  }
  private static ESLVal valueDefs = new ESLVal(new Function(new ESLVal("valueDefs"),null) { public ESLVal apply(ESLVal... args) { return valueDefs(args[0]); }});
  private static ESLVal valueDefsToTEnv(ESLVal defs,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal _v1060 = defs;
      
      if(_v1060.isCons())
      {ESLVal $1689 = _v1060.head();
        ESLVal $1690 = _v1060.tail();
        
        switch($1689.termName) {
        case "FunBinds": {ESLVal $1704 = $1689.termRef(0);
          ESLVal $1703 = $1689.termRef(1);
          
          if($1703.isCons())
          {ESLVal $1705 = $1703.head();
            ESLVal $1706 = $1703.tail();
            
            switch($1705.termName) {
            case "FunCase": {ESLVal $1711 = $1705.termRef(0);
              ESLVal $1710 = $1705.termRef(1);
              ESLVal $1709 = $1705.termRef(2);
              ESLVal $1708 = $1705.termRef(3);
              ESLVal $1707 = $1705.termRef(4);
              
              {ESLVal n = $1704;
              
              {ESLVal l = $1711;
              
              {ESLVal args = $1710;
              
              {ESLVal t = $1709;
              
              {ESLVal g = $1708;
              
              {ESLVal e = $1707;
              
              {ESLVal cases = $1706;
              
              {ESLVal ds = $1690;
              
              return valueDefsToTEnv(ds,selfType,valueEnv,cnstrEnv,typeEnv).cons(new ESLVal("Map",n,substTypeEnv.apply(typeEnv,t)));
            }
            }
            }
            }
            }
            }
            }
            }
            }
            default: return error(new ESLVal("case error at Pos(11865,12398)").add(ESLVal.list(_v1060)));
          }
          }
        else if($1703.isNil())
          return error(new ESLVal("case error at Pos(11865,12398)").add(ESLVal.list(_v1060)));
        else return error(new ESLVal("case error at Pos(11865,12398)").add(ESLVal.list(_v1060)));
        }
      case "FunBind": {ESLVal $1702 = $1689.termRef(0);
          ESLVal $1701 = $1689.termRef(1);
          ESLVal $1700 = $1689.termRef(2);
          ESLVal $1699 = $1689.termRef(3);
          ESLVal $1698 = $1689.termRef(4);
          ESLVal $1697 = $1689.termRef(5);
          ESLVal $1696 = $1689.termRef(6);
          
          {ESLVal l = $1702;
          
          {ESLVal n = $1701;
          
          {ESLVal ps = $1700;
          
          {ESLVal t = $1699;
          
          {ESLVal st = $1698;
          
          {ESLVal b = $1697;
          
          {ESLVal g = $1696;
          
          {ESLVal ds = $1690;
          
          return valueDefsToTEnv(ds,selfType,valueEnv,cnstrEnv,typeEnv).cons(new ESLVal("Map",n,substTypeEnv.apply(typeEnv,t)));
        }
        }
        }
        }
        }
        }
        }
        }
        }
      case "Binding": {ESLVal $1695 = $1689.termRef(0);
          ESLVal $1694 = $1689.termRef(1);
          ESLVal $1693 = $1689.termRef(2);
          ESLVal $1692 = $1689.termRef(3);
          ESLVal $1691 = $1689.termRef(4);
          
          {ESLVal l = $1695;
          
          {ESLVal n = $1694;
          
          {ESLVal t = $1693;
          
          {ESLVal st = $1692;
          
          {ESLVal e = $1691;
          
          {ESLVal ds = $1690;
          
          return valueDefsToTEnv(ds,selfType,valueEnv,cnstrEnv,typeEnv).cons(new ESLVal("Map",n,substTypeEnv.apply(typeEnv,t)));
        }
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(11865,12398)").add(ESLVal.list(_v1060)));
      }
      }
    else if(_v1060.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(11865,12398)").add(ESLVal.list(_v1060)));
    }
  }
  private static ESLVal valueDefsToTEnv = new ESLVal(new Function(new ESLVal("valueDefsToTEnv"),null) { public ESLVal apply(ESLVal... args) { return valueDefsToTEnv(args[0],args[1],args[2],args[3],args[4]); }});
  private static ESLVal recordJustType(ESLVal e,ESLVal t) {
    
    {setTypeInfo.apply(e,new ESLVal("JustType",t));
    return t;}
  }
  private static ESLVal recordJustType = new ESLVal(new Function(new ESLVal("recordJustType"),null) { public ESLVal apply(ESLVal... args) { return recordJustType(args[0],args[1]); }});
  public static ESLVal typeCheckModule(ESLVal path) {
    
    {print.apply(new ESLVal("[ type check ").add(path.add(new ESLVal("]"))));
    return typeCheckModuleInternal(path,getCache.apply(),new ESLVal(new Function(new ESLVal("fun383"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal cache = $args[0];
      ESLVal valueEnv = $args[1];
      ESLVal cnstrEnv = $args[2];
      ESLVal typeEnv = $args[3];
      return $null;
        }
      }));}
  }
  public static ESLVal typeCheckModule = new ESLVal(new Function(new ESLVal("typeCheckModule"),null) { public ESLVal apply(ESLVal... args) { return typeCheckModule(args[0]); }});
  private static ESLVal typeCheckModuleInternal(ESLVal path,ESLVal cache,ESLVal handler) {
    
    if(hasEntry.apply(path,cache).boolVal)
      {ESLVal _v1061 = lookup.apply(path,cache);
        
        switch(_v1061.termName) {
        case "Typed": {ESLVal $1715 = _v1061.termRef(0);
          ESLVal $1714 = _v1061.termRef(1);
          ESLVal $1713 = _v1061.termRef(2);
          ESLVal $1712 = _v1061.termRef(3);
          
          {ESLVal m = $1715;
          
          {ESLVal vEnv = $1714;
          
          {ESLVal cEnv = $1713;
          
          {ESLVal tEnv = $1712;
          
          return handler.apply(cache,vEnv,cEnv,tEnv);
        }
        }
        }
        }
        }
      case "Undefined": {
          return error(new ESLVal("recursive reference to ").add(path));
        }
        default: return error(new ESLVal("case error at Pos(12886,13120)").add(ESLVal.list(_v1061)));
      }
      }
      else
        {ESLVal m = parse.apply(path);
          
          return typeCheckModuleCache(m,updateCache.apply(path,new ESLVal("Undefined",new ESLVal[]{}),cache),new ESLVal(new Function(new ESLVal("fun384"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1600 = $args[0];
          ESLVal _v1601 = $args[1];
          ESLVal _v1602 = $args[2];
          ESLVal _v1603 = $args[3];
          return handler.apply(updateCache.apply(path,new ESLVal("Typed",m,_v1601,_v1602,_v1603),_v1600),_v1601,_v1602,_v1603);
            }
          }));
        }
  }
  private static ESLVal typeCheckModuleInternal = new ESLVal(new Function(new ESLVal("typeCheckModuleInternal"),null) { public ESLVal apply(ESLVal... args) { return typeCheckModuleInternal(args[0],args[1],args[2]); }});
  public static ESLVal typeCheckEntryPoint(ESLVal module) {
    
    return typeCheckModuleCache(module,getCache.apply(),new ESLVal(new Function(new ESLVal("fun385"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal cache = $args[0];
      ESLVal valueEnv = $args[1];
      ESLVal cnstrEnv = $args[2];
      ESLVal typeEnv = $args[3];
      return $null;
        }
      }));
  }
  public static ESLVal typeCheckEntryPoint = new ESLVal(new Function(new ESLVal("typeCheckEntryPoint"),null) { public ESLVal apply(ESLVal... args) { return typeCheckEntryPoint(args[0]); }});
  private static ESLVal typeCheckModuleCache(ESLVal module,ESLVal cache,ESLVal handler) {
    
    return typeCheckModule0(module,cache,new ESLVal(new Function(new ESLVal("fun386"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal _v1596 = $args[0];
      ESLVal _v1597 = $args[1];
      ESLVal _v1598 = $args[2];
      ESLVal _v1599 = $args[3];
      {ESLVal _v1062 = module;
            
            switch(_v1062.termName) {
            case "Module": {ESLVal $1722 = _v1062.termRef(0);
              ESLVal $1721 = _v1062.termRef(1);
              ESLVal $1720 = _v1062.termRef(2);
              ESLVal $1719 = _v1062.termRef(3);
              ESLVal $1718 = _v1062.termRef(4);
              ESLVal $1717 = _v1062.termRef(5);
              ESLVal $1716 = _v1062.termRef(6);
              
              {ESLVal path = $1722;
              
              {ESLVal name = $1721;
              
              {ESLVal exports = $1720;
              
              {ESLVal imports = $1719;
              
              {ESLVal x = $1718;
              
              {ESLVal y = $1717;
              
              {ESLVal defs = $1716;
              
              return handler.apply(_v1596,restrictTypeEnv.apply(_v1597,exports),restrictTypeEnv.apply(_v1598,exports),restrictTypeEnv.apply(_v1599,exports));
            }
            }
            }
            }
            }
            }
            }
            }
            default: return error(new ESLVal("case error at Pos(14112,14370)").add(ESLVal.list(_v1062)));
          }
          }
        }
      }));
  }
  private static ESLVal typeCheckModuleCache = new ESLVal(new Function(new ESLVal("typeCheckModuleCache"),null) { public ESLVal apply(ESLVal... args) { return typeCheckModuleCache(args[0],args[1],args[2]); }});
  private static ESLVal typeCheckModule0(ESLVal module,ESLVal cache,ESLVal handler) {
    
    { LetRec letrec = new LetRec() {
      ESLVal _v1575 = new ESLVal(new Function(new ESLVal("processImports"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1583 = $args[0];
        ESLVal _v1584 = $args[1];
        ESLVal _v1585 = $args[2];
        {ESLVal _v1063 = _v1583;
              
              if(_v1063.isCons())
              {ESLVal $1723 = _v1063.head();
                ESLVal $1724 = _v1063.tail();
                
                {ESLVal path = $1723;
                
                {ESLVal _v1586 = $1724;
                
                {ESLVal _v1587 = _v1586;
                
                return typeCheckModuleInternal(path,_v1584,new ESLVal(new Function(new ESLVal("fun387"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal _v1588 = $args[0];
                ESLVal _v1589 = $args[1];
                ESLVal _v1590 = $args[2];
                ESLVal _v1591 = $args[3];
                return _v1575.apply(_v1587,_v1588,new ESLVal(new Function(new ESLVal("fun388"),getSelf()) {
                        public ESLVal apply(ESLVal... $args) {
                          ESLVal _v1592 = $args[0];
                      ESLVal _v1593 = $args[1];
                      ESLVal _v1594 = $args[2];
                      ESLVal _v1595 = $args[3];
                      return _v1585.apply(_v1592,_v1593.add(_v1589),_v1594.add(_v1590),_v1595.add(_v1591));
                        }
                      }));
                  }
                }));
              }
              }
              }
              }
            else if(_v1063.isNil())
              return _v1585.apply(_v1584,$nil,$nil,$nil);
            else return error(new ESLVal("case error at Pos(14750,15307)").add(ESLVal.list(_v1063)));
            }
          }
        });
      ESLVal _v1576 = new ESLVal(new Function(new ESLVal("main"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            {ESLVal _v1064 = module;
              
              switch(_v1064.termName) {
              case "Module": {ESLVal $1731 = _v1064.termRef(0);
                ESLVal $1730 = _v1064.termRef(1);
                ESLVal $1729 = _v1064.termRef(2);
                ESLVal $1728 = _v1064.termRef(3);
                ESLVal $1727 = _v1064.termRef(4);
                ESLVal $1726 = _v1064.termRef(5);
                ESLVal $1725 = _v1064.termRef(6);
                
                {ESLVal path = $1731;
                
                {ESLVal name = $1730;
                
                {ESLVal exports = $1729;
                
                {ESLVal imports = $1728;
                
                {ESLVal x = $1727;
                
                {ESLVal y = $1726;
                
                {ESLVal defs = $1725;
                
                return _v1575.apply(imports,cache,new ESLVal(new Function(new ESLVal("fun389"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal _v1577 = $args[0];
                ESLVal _v1578 = $args[1];
                ESLVal _v1579 = $args[2];
                ESLVal _v1580 = $args[3];
                {ESLVal _v1581 = typeEnv(defs);
                      ESLVal _v1582 = mergeFunDefs.apply(defs);
                      
                      {resetInfo.apply();
                    resetTypeInfo.apply();
                    resetWarnings.apply();
                    checkUnusedVars.apply(module);
                    checkDupBindings(_v1582);
                    checkFreeTypes(_v1581.add(_v1580.add(tenv0)));
                    checkSingletonTypes(_v1581);
                    {ESLVal typeEnv = recTypes(_v1581.add(_v1580.add(tenv0)));
                      
                      {ESLVal cnstrEnv = cnstrEnv(_v1582,typeEnv).add(_v1579.add(cnstrEnv0));
                      
                      {checkSingletonConstructors(cnstrEnv);
                    {ESLVal valueEnv = typeCheckValues(valueDefs(_v1582),theTypeNull,_v1578,typeEnv,cnstrEnv);
                      
                      return handler.apply(_v1577,valueEnv,cnstrEnv,typeEnv);
                    }}
                    }
                    }}
                    }
                  }
                }));
              }
              }
              }
              }
              }
              }
              }
              }
              default: return error(new ESLVal("case error at Pos(15336,16958)").add(ESLVal.list(_v1064)));
            }
            }
          }
        });
      
      public ESLVal get(String name) {
        switch(name) {
          case "_v1575": return _v1575;
          
          case "_v1576": return _v1576;
          
          default: throw new Error("cannot find letrec binding");
        }
        }
      };
    ESLVal _v1575 = letrec.get("_v1575");
    
    ESLVal _v1576 = letrec.get("_v1576");
    
      return _v1576.apply();}
    
  }
  private static ESLVal typeCheckModule0 = new ESLVal(new Function(new ESLVal("typeCheckModule0"),null) { public ESLVal apply(ESLVal... args) { return typeCheckModule0(args[0],args[1],args[2]); }});
  private static ESLVal typeCheckValues(ESLVal valueDefs,ESLVal selfType,ESLVal ivalueEnv,ESLVal typeEnv,ESLVal cnstrEnv) {
    
    {ESLVal valueEnv = valueDefsToTEnv(valueDefs,selfType,$nil,cnstrEnv,typeEnv).add(ivalueEnv.add(env0));
      
      {{
      ESLVal _v1065 = valueDefs;
      while(_v1065.isCons()) {
        ESLVal def = _v1065.headVal;
        typeCheckDef(def,selfType,valueEnv,valueEnv,cnstrEnv,typeEnv);
        _v1065 = _v1065.tailVal;}
    }
    return valueEnv;}
    }
  }
  private static ESLVal typeCheckValues = new ESLVal(new Function(new ESLVal("typeCheckValues"),null) { public ESLVal apply(ESLVal... args) { return typeCheckValues(args[0],args[1],args[2],args[3],args[4]); }});
  private static ESLVal genericize(ESLVal l,ESLVal t) {
    
    if(length.apply(typeFV(t)).eql($zero).boolVal)
      return t;
      else
        return new ESLVal("ForallType",l,typeFV(t),t);
  }
  private static ESLVal genericize = new ESLVal(new Function(new ESLVal("genericize"),null) { public ESLVal apply(ESLVal... args) { return genericize(args[0],args[1]); }});
  private static ESLVal checkPatterns(ESLVal l,ESLVal ps) {
    
    {ESLVal names = new java.util.function.Function<ESLVal,ESLVal>() {
          public ESLVal apply(ESLVal $l0) {
            ESLVal $a = $nil;
            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
            while(!$l0.isNil()) { 
              ESLVal p = $l0.head();
              $l0 = $l0.tail();
              ESLVal $l1 = patternNames.apply(p);
        while(!$l1.isNil()) {
          ESLVal n = $l1.head();
          $l1 = $l1.tail();
          $v.add(n);
        }
            }
            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
            return $a;
          }}.apply(ps);
      
      if(removeDups.apply(names).neql(names).boolVal)
      return error(new ESLVal("TypeError",l,new ESLVal("duplicate pattern variables")));
      else
        return $null;
    }
  }
  private static ESLVal checkPatterns = new ESLVal(new Function(new ESLVal("checkPatterns"),null) { public ESLVal apply(ESLVal... args) { return checkPatterns(args[0],args[1]); }});
  private static ESLVal typeCheckDef(ESLVal def,ESLVal selfType,ESLVal baseValueEnv,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal _v1066 = def;
      
      switch(_v1066.termName) {
      case "FunBinds": {ESLVal $1745 = _v1066.termRef(0);
        ESLVal $1744 = _v1066.termRef(1);
        
        {ESLVal n = $1745;
        
        {ESLVal cases = $1744;
        
        { LetRec letrec = new LetRec() {
        ESLVal checkArities = new ESLVal(new Function(new ESLVal("checkArities"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1572 = $args[0];
          ESLVal _v1573 = $args[1];
          {ESLVal _v1070 = _v1572;
                
                if(_v1070.isCons())
                {ESLVal $1755 = _v1070.head();
                  ESLVal $1756 = _v1070.tail();
                  
                  switch($1755.termName) {
                  case "FunCase": {ESLVal $1761 = $1755.termRef(0);
                    ESLVal $1760 = $1755.termRef(1);
                    ESLVal $1759 = $1755.termRef(2);
                    ESLVal $1758 = $1755.termRef(3);
                    ESLVal $1757 = $1755.termRef(4);
                    
                    {ESLVal l = $1761;
                    
                    {ESLVal args = $1760;
                    
                    {ESLVal t = $1759;
                    
                    {ESLVal g = $1758;
                    
                    {ESLVal e = $1757;
                    
                    {ESLVal _v1574 = $1756;
                    
                    if(_v1573.eql(new ESLVal(-1)).or(length.apply(args).eql(_v1573)).boolVal)
                    return checkArities.apply(_v1574,length.apply(args));
                    else
                      return error(new ESLVal("TypeError",l,new ESLVal("inconsistent overloaded arity")));
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(18165,18454)").add(ESLVal.list(_v1070)));
                }
                }
              else if(_v1070.isNil())
                return $null;
              else return error(new ESLVal("case error at Pos(18165,18454)").add(ESLVal.list(_v1070)));
              }
            }
          });
        ESLVal checkLoneVars = new ESLVal(new Function(new ESLVal("checkLoneVars"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1570 = $args[0];
          {ESLVal _v1071 = _v1570;
                
                if(_v1071.isCons())
                {ESLVal $1762 = _v1071.head();
                  ESLVal $1763 = _v1071.tail();
                  
                  switch($1762.termName) {
                  case "FunCase": {ESLVal $1768 = $1762.termRef(0);
                    ESLVal $1767 = $1762.termRef(1);
                    ESLVal $1766 = $1762.termRef(2);
                    ESLVal $1765 = $1762.termRef(3);
                    ESLVal $1764 = $1762.termRef(4);
                    
                    {ESLVal l = $1768;
                    
                    {ESLVal args = $1767;
                    
                    {ESLVal t = $1766;
                    
                    {ESLVal g = $1765;
                    
                    {ESLVal e = $1764;
                    
                    {ESLVal _v1571 = $1763;
                    
                    {{
                    ESLVal _v1072 = args;
                    while(_v1072.isCons()) {
                      ESLVal arg = _v1072.headVal;
                      checkLoneVar.apply(arg);
                      _v1072 = _v1072.tailVal;}
                  }
                  return checkLoneVars.apply(_v1571);}
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(18513,18748)").add(ESLVal.list(_v1071)));
                }
                }
              else if(_v1071.isNil())
                return $null;
              else return error(new ESLVal("case error at Pos(18513,18748)").add(ESLVal.list(_v1071)));
              }
            }
          });
        ESLVal checkLoneVar = new ESLVal(new Function(new ESLVal("checkLoneVar"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal p = $args[0];
          {ESLVal _v1073 = p;
                
                switch(_v1073.termName) {
                case "PVar": {ESLVal $1771 = _v1073.termRef(0);
                  ESLVal $1770 = _v1073.termRef(1);
                  ESLVal $1769 = _v1073.termRef(2);
                  
                  switch($1769.termName) {
                  case "VoidType": {ESLVal $1772 = $1769.termRef(0);
                    
                    {ESLVal l = $1771;
                    
                    {ESLVal _v1567 = $1770;
                    
                    {ESLVal tl = $1772;
                    
                    return error(new ESLVal("TypeError",l,new ESLVal("top level variables should be typed.")));
                  }
                  }
                  }
                  }
                  default: {ESLVal _v1568 = _v1073;
                    
                    return $null;
                  }
                }
                }
                default: {ESLVal _v1569 = _v1073;
                  
                  return $null;
                }
              }
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "checkArities": return checkArities;
            
            case "checkLoneVars": return checkLoneVars;
            
            case "checkLoneVar": return checkLoneVar;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal checkArities = letrec.get("checkArities");
      
      ESLVal checkLoneVars = letrec.get("checkLoneVars");
      
      ESLVal checkLoneVar = letrec.get("checkLoneVar");
      
        {checkArities.apply(cases,new ESLVal(-1));
      return checkLoneVars.apply(cases);}}
      
      }
      }
      }
    case "FunBind": {ESLVal $1743 = _v1066.termRef(0);
        ESLVal $1742 = _v1066.termRef(1);
        ESLVal $1741 = _v1066.termRef(2);
        ESLVal $1740 = _v1066.termRef(3);
        ESLVal $1739 = _v1066.termRef(4);
        ESLVal $1738 = _v1066.termRef(5);
        ESLVal $1737 = _v1066.termRef(6);
        
        {ESLVal l = $1743;
        
        {ESLVal n = $1742;
        
        {ESLVal ps = $1741;
        
        {ESLVal t = $1740;
        
        {ESLVal st = $1739;
        
        {ESLVal b = $1738;
        
        {ESLVal g = $1737;
        
        {checkPatterns(l,ps);
      {ESLVal argTypes = map.apply(new ESLVal(new Function(new ESLVal("fun390"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal p = $args[0];
          {ESLVal _v1067 = p;
                
                switch(_v1067.termName) {
                case "PVar": {ESLVal $1748 = _v1067.termRef(0);
                  ESLVal $1747 = _v1067.termRef(1);
                  ESLVal $1746 = _v1067.termRef(2);
                  
                  {ESLVal _v1561 = $1748;
                  
                  {ESLVal _v1562 = $1747;
                  
                  {ESLVal _v1563 = $1746;
                  
                  return substTypeEnv.apply(typeEnv,_v1563);
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(19380,19446)").add(ESLVal.list(_v1067)));
              }
              }
            }
          }),ps);
        ESLVal argNames = map.apply(new ESLVal(new Function(new ESLVal("fun391"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal p = $args[0];
          {ESLVal _v1068 = p;
                
                switch(_v1068.termName) {
                case "PVar": {ESLVal $1751 = _v1068.termRef(0);
                  ESLVal $1750 = _v1068.termRef(1);
                  ESLVal $1749 = _v1068.termRef(2);
                  
                  {ESLVal _v1558 = $1751;
                  
                  {ESLVal _v1559 = $1750;
                  
                  {ESLVal _v1560 = $1749;
                  
                  return _v1559;
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(19518,19562)").add(ESLVal.list(_v1068)));
              }
              }
            }
          }),ps);
        
        {ESLVal bodyType = guardedExpType(l,g,b,selfType,zipTypeEnv.apply(argNames,argTypes).add(baseValueEnv),cnstrEnv,typeEnv);
        
        {ESLVal fType = ((Supplier<ESLVal>)() -> { 
            {ESLVal _v1069 = t;
              
              switch(_v1069.termName) {
              case "ForallType": {ESLVal $1754 = _v1069.termRef(0);
                ESLVal $1753 = _v1069.termRef(1);
                ESLVal $1752 = _v1069.termRef(2);
                
                {ESLVal _v1564 = $1754;
                
                {ESLVal ns = $1753;
                
                {ESLVal _v1565 = $1752;
                
                return genericize(_v1564,new ESLVal("FunType",_v1564,argTypes,bodyType));
              }
              }
              }
              }
              default: {ESLVal _v1566 = _v1069;
                
                return new ESLVal("FunType",l,argTypes,bodyType);
              }
            }
            }
          }).get();
        ESLVal dType = substTypeEnv.apply(typeEnv,t);
        
        if(subType.apply(fType,dType).boolVal)
        return $null;
        else
          return error(new ESLVal("TypeError",l,new ESLVal("type of ").add(n.add(new ESLVal("::").add(ppType(fType,typeEnv).add(new ESLVal(" does not match declaration ").add(ppType(dType,typeEnv))))))));
      }
      }
      }}
      }
      }
      }
      }
      }
      }
      }
      }
    case "Binding": {ESLVal $1736 = _v1066.termRef(0);
        ESLVal $1735 = _v1066.termRef(1);
        ESLVal $1734 = _v1066.termRef(2);
        ESLVal $1733 = _v1066.termRef(3);
        ESLVal $1732 = _v1066.termRef(4);
        
        {ESLVal l = $1736;
        
        {ESLVal n = $1735;
        
        {ESLVal dt = $1734;
        
        {ESLVal st = $1733;
        
        {ESLVal e = $1732;
        
        {ESLVal valueType = expType(e,selfType,baseValueEnv,cnstrEnv,typeEnv);
        
        {ESLVal valueFV = typeFV(valueType);
        ESLVal declaredType = lookupType.apply(n,valueEnv);
        
        {ESLVal _v1557 = ((Supplier<ESLVal>)() -> { 
            if(valueFV.eql($nil).boolVal)
              return valueType;
              else
                return new ESLVal("ForallType",l,valueFV,valueType);
          }).get();
        
        if(subType.apply(_v1557,declaredType).boolVal)
        return $null;
        else
          return error(new ESLVal("TypeError",l,new ESLVal("type of ").add(n.add(new ESLVal(" ").add(ppType(_v1557,typeEnv).add(new ESLVal(" does not match declared type = ").add(ppType(declaredType,typeEnv))))))));
      }
      }
      }
      }
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(18046,20969)").add(ESLVal.list(_v1066)));
    }
    }
  }
  private static ESLVal typeCheckDef = new ESLVal(new Function(new ESLVal("typeCheckDef"),null) { public ESLVal apply(ESLVal... args) { return typeCheckDef(args[0],args[1],args[2],args[3],args[4],args[5]); }});
  private static ESLVal guardedExpType(ESLVal l,ESLVal g,ESLVal e,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal bt = expType(g,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(isBoolType.apply(bt).boolVal)
      return expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
      else
        return error(new ESLVal("TypeError",l,new ESLVal("guarded expression requires a boolean value: ").add(ppType(bt,typeEnv))));
    }
  }
  private static ESLVal guardedExpType = new ESLVal(new Function(new ESLVal("guardedExpType"),null) { public ESLVal apply(ESLVal... args) { return guardedExpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal expType(ESLVal e,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t = expType1(e,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(hasTypeInfo.apply(e).boolVal)
      return t;
      else
        return recordJustType(e,t);
    }
  }
  private static ESLVal expType = new ESLVal(new Function(new ESLVal("expType"),null) { public ESLVal apply(ESLVal... args) { return expType(args[0],args[1],args[2],args[3],args[4]); }});
  private static ESLVal expType1(ESLVal e,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal _v1074 = e;
      
      switch(_v1074.termName) {
      case "ActExp": {ESLVal $1908 = _v1074.termRef(0);
        ESLVal $1907 = _v1074.termRef(1);
        ESLVal $1906 = _v1074.termRef(2);
        ESLVal $1905 = _v1074.termRef(3);
        ESLVal $1904 = _v1074.termRef(4);
        ESLVal $1903 = _v1074.termRef(5);
        ESLVal $1902 = _v1074.termRef(6);
        ESLVal $1901 = _v1074.termRef(7);
        
        {ESLVal l = $1908;
        
        {ESLVal n = $1907;
        
        {ESLVal args = $1906;
        
        {ESLVal exports = $1905;
        
        {ESLVal parent = $1904;
        
        {ESLVal bindings = $1903;
        
        {ESLVal init = $1902;
        
        {ESLVal arms = $1901;
        
        return actType(l,n,args,parent,exports,bindings,init,arms,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
      }
      }
      }
      }
      }
    case "Apply": {ESLVal $1900 = _v1074.termRef(0);
        ESLVal $1899 = _v1074.termRef(1);
        ESLVal $1898 = _v1074.termRef(2);
        
        {ESLVal l = $1900;
        
        {ESLVal op = $1899;
        
        {ESLVal args = $1898;
        
        return applyType(l,op,args,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "ApplyTypeExp": {ESLVal $1897 = _v1074.termRef(0);
        ESLVal $1896 = _v1074.termRef(1);
        ESLVal $1895 = _v1074.termRef(2);
        
        {ESLVal l = $1897;
        
        {ESLVal _v1556 = $1896;
        
        {ESLVal ts = $1895;
        
        return applyTypeExp(l,_v1556,ts,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "ArrayUpdate": {ESLVal $1894 = _v1074.termRef(0);
        ESLVal $1893 = _v1074.termRef(1);
        ESLVal $1892 = _v1074.termRef(2);
        ESLVal $1891 = _v1074.termRef(3);
        
        {ESLVal l = $1894;
        
        {ESLVal a = $1893;
        
        {ESLVal i = $1892;
        
        {ESLVal v = $1891;
        
        return arrayUpdateType(l,a,i,v,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
      }
    case "ArrayRef": {ESLVal $1890 = _v1074.termRef(0);
        ESLVal $1889 = _v1074.termRef(1);
        ESLVal $1888 = _v1074.termRef(2);
        
        {ESLVal l = $1890;
        
        {ESLVal a = $1889;
        
        {ESLVal i = $1888;
        
        return arrayRefType(l,a,i,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "BagExp": {ESLVal $1887 = _v1074.termRef(0);
        ESLVal $1886 = _v1074.termRef(1);
        
        {ESLVal l = $1887;
        
        {ESLVal es = $1886;
        
        return bagType(l,es,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
    case "Become": {ESLVal $1885 = _v1074.termRef(0);
        ESLVal $1884 = _v1074.termRef(1);
        
        {ESLVal l = $1885;
        
        {ESLVal _v1555 = $1884;
        
        return becomeType(l,_v1555,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
    case "BinExp": {ESLVal $1883 = _v1074.termRef(0);
        ESLVal $1882 = _v1074.termRef(1);
        ESLVal $1881 = _v1074.termRef(2);
        ESLVal $1880 = _v1074.termRef(3);
        
        {ESLVal l = $1883;
        
        {ESLVal e1 = $1882;
        
        {ESLVal op = $1881;
        
        {ESLVal e2 = $1880;
        
        return binExpType(l,e1,op,e2,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
      }
    case "Block": {ESLVal $1879 = _v1074.termRef(0);
        ESLVal $1878 = _v1074.termRef(1);
        
        {ESLVal l = $1879;
        
        {ESLVal es = $1878;
        
        return blockType(l,es,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
    case "BoolExp": {ESLVal $1877 = _v1074.termRef(0);
        ESLVal $1876 = _v1074.termRef(1);
        
        {ESLVal l = $1877;
        
        {ESLVal b = $1876;
        
        return theTypeBool;
      }
      }
      }
    case "Case": {ESLVal $1875 = _v1074.termRef(0);
        ESLVal $1874 = _v1074.termRef(1);
        ESLVal $1873 = _v1074.termRef(2);
        ESLVal $1872 = _v1074.termRef(3);
        
        {ESLVal l = $1875;
        
        {ESLVal decs = $1874;
        
        {ESLVal es = $1873;
        
        {ESLVal arms = $1872;
        
        return caseType(l,es,arms,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
      }
    case "Cmp": {ESLVal $1871 = _v1074.termRef(0);
        ESLVal $1870 = _v1074.termRef(1);
        ESLVal $1869 = _v1074.termRef(2);
        
        {ESLVal l = $1871;
        
        {ESLVal _v1554 = $1870;
        
        {ESLVal qs = $1869;
        
        return cmpType(l,_v1554,qs,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "Grab": {ESLVal $1868 = _v1074.termRef(0);
        ESLVal $1867 = _v1074.termRef(1);
        ESLVal $1866 = _v1074.termRef(2);
        
        {ESLVal l = $1868;
        
        {ESLVal refs = $1867;
        
        {ESLVal _v1553 = $1866;
        
        return expType(_v1553,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "FloatExp": {ESLVal $1865 = _v1074.termRef(0);
        ESLVal $1864 = _v1074.termRef(1);
        
        {ESLVal l = $1865;
        
        {ESLVal f = $1864;
        
        return theTypeFloat;
      }
      }
      }
    case "Fold": {ESLVal $1863 = _v1074.termRef(0);
        ESLVal $1862 = _v1074.termRef(1);
        ESLVal $1861 = _v1074.termRef(2);
        
        {ESLVal l = $1863;
        
        {ESLVal t = $1862;
        
        {ESLVal _v1552 = $1861;
        
        return foldType(l,t,_v1552,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "For": {ESLVal $1860 = _v1074.termRef(0);
        ESLVal $1859 = _v1074.termRef(1);
        ESLVal $1858 = _v1074.termRef(2);
        ESLVal $1857 = _v1074.termRef(3);
        
        {ESLVal l = $1860;
        
        {ESLVal p = $1859;
        
        {ESLVal list = $1858;
        
        {ESLVal _v1551 = $1857;
        
        return forType(l,p,list,_v1551,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
      }
    case "FunExp": {ESLVal $1856 = _v1074.termRef(0);
        ESLVal $1855 = _v1074.termRef(1);
        ESLVal $1854 = _v1074.termRef(2);
        ESLVal $1853 = _v1074.termRef(3);
        ESLVal $1852 = _v1074.termRef(4);
        
        {ESLVal l = $1856;
        
        {ESLVal n = $1855;
        
        {ESLVal args = $1854;
        
        {ESLVal t = $1853;
        
        {ESLVal _v1550 = $1852;
        
        return funType(l,n,args,t,_v1550,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
      }
      }
    case "If": {ESLVal $1851 = _v1074.termRef(0);
        ESLVal $1850 = _v1074.termRef(1);
        ESLVal $1849 = _v1074.termRef(2);
        ESLVal $1848 = _v1074.termRef(3);
        
        {ESLVal l = $1851;
        
        {ESLVal e1 = $1850;
        
        {ESLVal e2 = $1849;
        
        {ESLVal e3 = $1848;
        
        return ifType(l,e1,e2,e3,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
      }
    case "IntExp": {ESLVal $1847 = _v1074.termRef(0);
        ESLVal $1846 = _v1074.termRef(1);
        
        {ESLVal l = $1847;
        
        {ESLVal n = $1846;
        
        return theTypeInt;
      }
      }
      }
    case "Let": {ESLVal $1845 = _v1074.termRef(0);
        ESLVal $1844 = _v1074.termRef(1);
        ESLVal $1843 = _v1074.termRef(2);
        
        {ESLVal l = $1845;
        
        {ESLVal bs = $1844;
        
        {ESLVal _v1549 = $1843;
        
        return letType(l,bs,_v1549,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "Letrec": {ESLVal $1842 = _v1074.termRef(0);
        ESLVal $1841 = _v1074.termRef(1);
        ESLVal $1840 = _v1074.termRef(2);
        
        {ESLVal l = $1842;
        
        {ESLVal bs = $1841;
        
        {ESLVal _v1548 = $1840;
        
        return letrecType(l,bs,_v1548,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "List": {ESLVal $1839 = _v1074.termRef(0);
        ESLVal $1838 = _v1074.termRef(1);
        
        {ESLVal l = $1839;
        
        {ESLVal es = $1838;
        
        return listType(l,es,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
    case "Now": {ESLVal $1837 = _v1074.termRef(0);
        
        {ESLVal l = $1837;
        
        return theTypeInt;
      }
      }
    case "Probably": {ESLVal $1836 = _v1074.termRef(0);
        ESLVal $1835 = _v1074.termRef(1);
        ESLVal $1834 = _v1074.termRef(2);
        ESLVal $1833 = _v1074.termRef(3);
        ESLVal $1832 = _v1074.termRef(4);
        
        {ESLVal l = $1836;
        
        {ESLVal p = $1835;
        
        {ESLVal t = $1834;
        
        {ESLVal e1 = $1833;
        
        {ESLVal e2 = $1832;
        
        return probablyType(l,p,t,e1,e2,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
      }
      }
    case "PLet": {ESLVal $1831 = _v1074.termRef(0);
        ESLVal $1830 = _v1074.termRef(1);
        ESLVal $1829 = _v1074.termRef(2);
        
        {ESLVal l = $1831;
        
        {ESLVal bs = $1830;
        
        {ESLVal _v1547 = $1829;
        
        return letType(l,bs,_v1547,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "Record": {ESLVal $1828 = _v1074.termRef(0);
        ESLVal $1827 = _v1074.termRef(1);
        
        {ESLVal l = $1828;
        
        {ESLVal fields = $1827;
        
        return recordType(l,fields,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
    case "Ref": {ESLVal $1826 = _v1074.termRef(0);
        ESLVal $1825 = _v1074.termRef(1);
        ESLVal $1824 = _v1074.termRef(2);
        
        {ESLVal l = $1826;
        
        {ESLVal _v1546 = $1825;
        
        {ESLVal n = $1824;
        
        return refType(l,_v1546,n,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "RefSuper": {ESLVal $1823 = _v1074.termRef(0);
        ESLVal $1822 = _v1074.termRef(1);
        
        {ESLVal l = $1823;
        
        {ESLVal n = $1822;
        
        return refType(l,new ESLVal("Var",l,new ESLVal("$super")),n,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
    case "Self": {ESLVal $1821 = _v1074.termRef(0);
        
        {ESLVal l = $1821;
        
        return selfType;
      }
      }
    case "Send": {ESLVal $1816 = _v1074.termRef(0);
        ESLVal $1815 = _v1074.termRef(1);
        ESLVal $1814 = _v1074.termRef(2);
        
        switch($1814.termName) {
        case "Term": {ESLVal $1820 = $1814.termRef(0);
          ESLVal $1819 = $1814.termRef(1);
          ESLVal $1818 = $1814.termRef(2);
          ESLVal $1817 = $1814.termRef(3);
          
          {ESLVal l = $1816;
          
          {ESLVal target = $1815;
          
          {ESLVal tl = $1820;
          
          {ESLVal n = $1819;
          
          {ESLVal ts = $1818;
          
          {ESLVal args = $1817;
          
          return sendType(l,target,n,args,selfType,valueEnv,cnstrEnv,typeEnv);
        }
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(21822,26732)").add(ESLVal.list(_v1074)));
      }
      }
    case "SendTimeSuper": {ESLVal $1813 = _v1074.termRef(0);
        
        {ESLVal l = $1813;
        
        return theTypeVoid;
      }
      }
    case "SendSuper": {ESLVal $1812 = _v1074.termRef(0);
        ESLVal $1811 = _v1074.termRef(1);
        
        {ESLVal l = $1812;
        
        {ESLVal _v1545 = $1811;
        
        return theTypeVoid;
      }
      }
      }
    case "SetExp": {ESLVal $1810 = _v1074.termRef(0);
        ESLVal $1809 = _v1074.termRef(1);
        
        {ESLVal l = $1810;
        
        {ESLVal es = $1809;
        
        return setType(l,es,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
    case "StrExp": {ESLVal $1808 = _v1074.termRef(0);
        ESLVal $1807 = _v1074.termRef(1);
        
        {ESLVal l = $1808;
        
        {ESLVal s = $1807;
        
        return theTypeStr;
      }
      }
      }
    case "Term": {ESLVal $1806 = _v1074.termRef(0);
        ESLVal $1805 = _v1074.termRef(1);
        ESLVal $1804 = _v1074.termRef(2);
        ESLVal $1803 = _v1074.termRef(3);
        
        {ESLVal l = $1806;
        
        {ESLVal n = $1805;
        
        {ESLVal ts = $1804;
        
        {ESLVal es = $1803;
        
        return termType(l,n,ts,es,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
      }
    case "Throw": {ESLVal $1802 = _v1074.termRef(0);
        ESLVal $1801 = _v1074.termRef(1);
        ESLVal $1800 = _v1074.termRef(2);
        
        {ESLVal l = $1802;
        
        {ESLVal t = $1801;
        
        {ESLVal _v1544 = $1800;
        
        return throwType(l,t,_v1544,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "Try": {ESLVal $1799 = _v1074.termRef(0);
        ESLVal $1798 = _v1074.termRef(1);
        ESLVal $1797 = _v1074.termRef(2);
        
        {ESLVal l = $1799;
        
        {ESLVal _v1543 = $1798;
        
        {ESLVal arms = $1797;
        
        return tryType(l,_v1543,arms,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "New": {ESLVal $1796 = _v1074.termRef(0);
        ESLVal $1795 = _v1074.termRef(1);
        ESLVal $1794 = _v1074.termRef(2);
        
        {ESLVal l = $1796;
        
        {ESLVal b = $1795;
        
        {ESLVal args = $1794;
        
        return newType(l,b,args,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "NewArray": {ESLVal $1793 = _v1074.termRef(0);
        ESLVal $1792 = _v1074.termRef(1);
        ESLVal $1791 = _v1074.termRef(2);
        
        {ESLVal l = $1793;
        
        {ESLVal t = $1792;
        
        {ESLVal i = $1791;
        
        return newArrayType(l,t,i,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "NewTable": {ESLVal $1790 = _v1074.termRef(0);
        ESLVal $1789 = _v1074.termRef(1);
        ESLVal $1788 = _v1074.termRef(2);
        
        {ESLVal l = $1790;
        
        {ESLVal key = $1789;
        
        {ESLVal value = $1788;
        
        return new ESLVal("TableType",l,substTypeEnv.apply(typeEnv,key),substTypeEnv.apply(typeEnv,value));
      }
      }
      }
      }
    case "NewJava": {ESLVal $1787 = _v1074.termRef(0);
        ESLVal $1786 = _v1074.termRef(1);
        ESLVal $1785 = _v1074.termRef(2);
        ESLVal $1784 = _v1074.termRef(3);
        
        {ESLVal l = $1787;
        
        {ESLVal path = $1786;
        
        {ESLVal t = $1785;
        
        {ESLVal args = $1784;
        
        {{
        ESLVal _v1075 = args;
        while(_v1075.isCons()) {
          ESLVal a = _v1075.headVal;
          expType(a,selfType,valueEnv,cnstrEnv,typeEnv);
          _v1075 = _v1075.tailVal;}
      }
      return substTypeEnv.apply(typeEnv,t);}
      }
      }
      }
      }
      }
    case "Not": {ESLVal $1783 = _v1074.termRef(0);
        ESLVal $1782 = _v1074.termRef(1);
        
        {ESLVal l = $1783;
        
        {ESLVal _v1542 = $1782;
        
        return notType(l,_v1542,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
    case "NullExp": {ESLVal $1781 = _v1074.termRef(0);
        
        {ESLVal l = $1781;
        
        return new ESLVal("ForallType",l,ESLVal.list(new ESLVal("T")),new ESLVal("VarType",l,new ESLVal("T")));
      }
      }
    case "Unfold": {ESLVal $1780 = _v1074.termRef(0);
        ESLVal $1779 = _v1074.termRef(1);
        ESLVal $1778 = _v1074.termRef(2);
        
        {ESLVal l = $1780;
        
        {ESLVal t = $1779;
        
        {ESLVal _v1541 = $1778;
        
        return unfoldTypeExp(l,t,_v1541,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "Update": {ESLVal $1777 = _v1074.termRef(0);
        ESLVal $1776 = _v1074.termRef(1);
        ESLVal $1775 = _v1074.termRef(2);
        
        {ESLVal l = $1777;
        
        {ESLVal n = $1776;
        
        {ESLVal _v1540 = $1775;
        
        return updateType(l,n,_v1540,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "Var": {ESLVal $1774 = _v1074.termRef(0);
        ESLVal $1773 = _v1074.termRef(1);
        
        {ESLVal l = $1774;
        
        {ESLVal n = $1773;
        
        return varType(l,n,valueEnv,typeEnv);
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(21822,26732)").add(ESLVal.list(_v1074)));
    }
    }
  }
  private static ESLVal expType1 = new ESLVal(new Function(new ESLVal("expType1"),null) { public ESLVal apply(ESLVal... args) { return expType1(args[0],args[1],args[2],args[3],args[4]); }});
  private static ESLVal throwType(ESLVal l,ESLVal t,ESLVal e,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal valType = expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
      
      return substTypeEnv.apply(typeEnv,t);
    }
  }
  private static ESLVal throwType = new ESLVal(new Function(new ESLVal("throwType"),null) { public ESLVal apply(ESLVal... args) { return throwType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal foldType(ESLVal l,ESLVal t,ESLVal e,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal eType = expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(typeEqual.apply(substTypeEnv.apply(typeEnv,t),eType).boolVal)
      return eType;
      else
        return error(new ESLVal("TypeError",l,new ESLVal("fold type ").add(ppType(t,typeEnv).add(new ESLVal(" does not equal ").add(ppType(eType,typeEnv))))));
    }
  }
  private static ESLVal foldType = new ESLVal(new Function(new ESLVal("foldType"),null) { public ESLVal apply(ESLVal... args) { return foldType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal unfoldTypeExp(ESLVal l,ESLVal t,ESLVal e,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal eType = expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal recType = substTypeEnv.apply(typeEnv,t);
      
      {ESLVal _v1076 = recType;
      
      switch(_v1076.termName) {
      case "RecType": {ESLVal $1911 = _v1076.termRef(0);
        ESLVal $1910 = _v1076.termRef(1);
        ESLVal $1909 = _v1076.termRef(2);
        
        {ESLVal rl = $1911;
        
        {ESLVal n = $1910;
        
        {ESLVal _v1538 = $1909;
        
        if(typeEqual.apply(substType.apply(eType,n,_v1538),eType).boolVal)
        return eType;
        else
          return error(new ESLVal("TypeError",l,new ESLVal("unfold type ").add(ppType(substType.apply(eType,n,_v1538),typeEnv).add(new ESLVal(" does not equal ").add(ppType(eType,typeEnv))))));
      }
      }
      }
      }
      default: {ESLVal _v1539 = _v1076;
        
        return error(new ESLVal("TypeError",l,new ESLVal("unfold type expects a rec type").add(ppType(recType,typeEnv))));
      }
    }
    }
    }
  }
  private static ESLVal unfoldTypeExp = new ESLVal(new Function(new ESLVal("unfoldTypeExp"),null) { public ESLVal apply(ESLVal... args) { return unfoldTypeExp(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal arrayUpdateType(ESLVal l,ESLVal a,ESLVal i,ESLVal v,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal aType = expType(a,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal iType = expType(i,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal vType = expType(v,selfType,valueEnv,cnstrEnv,typeEnv);
      
      {ESLVal _v1077 = aType;
      
      switch(_v1077.termName) {
      case "ArrayType": {ESLVal $1913 = _v1077.termRef(0);
        ESLVal $1912 = _v1077.termRef(1);
        
        {ESLVal al = $1913;
        
        {ESLVal t = $1912;
        
        if(isIntType.apply(iType).boolVal)
        if(typeEqual.apply(vType,t).boolVal)
          return aType;
          else
            return error(new ESLVal("TypeError",l,new ESLVal("value type ").add(vType.add(new ESLVal(" does not match array type ").add(t)))));
        else
          return error(new ESLVal("TypeError",l,new ESLVal("array index should be an integer ").add(i)));
      }
      }
      }
      default: {ESLVal t = _v1077;
        
        return error(new ESLVal("TypeError",l,new ESLVal("expecting an array ").add(aType)));
      }
    }
    }
    }
  }
  private static ESLVal arrayUpdateType = new ESLVal(new Function(new ESLVal("arrayUpdateType"),null) { public ESLVal apply(ESLVal... args) { return arrayUpdateType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7]); }});
  private static ESLVal arrayRefType(ESLVal l,ESLVal a,ESLVal i,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal aType = expType(a,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal iType = expType(i,selfType,valueEnv,cnstrEnv,typeEnv);
      
      {ESLVal _v1078 = aType;
      
      switch(_v1078.termName) {
      case "ArrayType": {ESLVal $1915 = _v1078.termRef(0);
        ESLVal $1914 = _v1078.termRef(1);
        
        {ESLVal al = $1915;
        
        {ESLVal t = $1914;
        
        if(isIntType.apply(iType).boolVal)
        return t;
        else
          return error(new ESLVal("TypeError",l,new ESLVal("array index should be an integer ").add(i)));
      }
      }
      }
      default: {ESLVal t = _v1078;
        
        return error(new ESLVal("TypeError",l,new ESLVal("expecting an array ").add(aType)));
      }
    }
    }
    }
  }
  private static ESLVal arrayRefType = new ESLVal(new Function(new ESLVal("arrayRefType"),null) { public ESLVal apply(ESLVal... args) { return arrayRefType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal newArrayType(ESLVal l,ESLVal t,ESLVal e,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal i = expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(isIntType.apply(i).boolVal)
      return new ESLVal("ArrayType",l,substTypeEnv.apply(typeEnv,t));
      else
        return error(new ESLVal("TypeError",l,new ESLVal("expecting an integer type: ").add(i)));
    }
  }
  private static ESLVal newArrayType = new ESLVal(new Function(new ESLVal("newArrayType"),null) { public ESLVal apply(ESLVal... args) { return newArrayType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal becomeType(ESLVal l,ESLVal e,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal bType = expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(typeEqual.apply(bType,selfType).boolVal)
      return bType;
      else
        return error(new ESLVal("TypeError",l,new ESLVal("expecting become to match self type: ").add(ppType(bType,typeEnv).add(new ESLVal(" ").add(ppType(selfType,typeEnv))))));
    }
  }
  private static ESLVal becomeType = new ESLVal(new Function(new ESLVal("becomeType"),null) { public ESLVal apply(ESLVal... args) { return becomeType(args[0],args[1],args[2],args[3],args[4],args[5]); }});
  private static ESLVal probablyType(ESLVal l,ESLVal p,ESLVal t,ESLVal e1,ESLVal e2,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal pt = expType(p,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(isIntType.apply(pt).boolVal)
      {ESLVal _v1535 = substTypeEnv.apply(typeEnv,t);
        ESLVal _v1536 = expType(e1,selfType,valueEnv,cnstrEnv,typeEnv);
        ESLVal _v1537 = expType(e2,selfType,valueEnv,cnstrEnv,typeEnv);
        
        if(typeEqual.apply(_v1535,_v1536).and(typeEqual.apply(_v1535,_v1537)).boolVal)
        return _v1535;
        else
          return error(new ESLVal("TypeError",l,new ESLVal("expecting probably arm types to agree: ").add(ppType(_v1536,typeEnv).add(new ESLVal(" ").add(ppType(_v1535,typeEnv).add(new ESLVal(" ").add(ppType(_v1537,typeEnv))))))));
      }
      else
        return error(new ESLVal("TypeError",l,new ESLVal("expecting an integer: ").add(ppType(pt,typeEnv))));
    }
  }
  private static ESLVal probablyType = new ESLVal(new Function(new ESLVal("probablyType"),null) { public ESLVal apply(ESLVal... args) { return probablyType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7],args[8]); }});
  private static ESLVal newType(ESLVal l,ESLVal b,ESLVal args,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    return expType(new ESLVal("Apply",l,b,args),selfType,valueEnv,cnstrEnv,typeEnv);
  }
  private static ESLVal newType = new ESLVal(new Function(new ESLVal("newType"),null) { public ESLVal apply(ESLVal... args) { return newType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal sendType(ESLVal l,ESLVal target,ESLVal n,ESLVal args,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal _v1079 = typeNF(derefType(expType(target,selfType,valueEnv,cnstrEnv,typeEnv)),typeEnv);
      
      switch(_v1079.termName) {
      case "ActType": {ESLVal $1918 = _v1079.termRef(0);
        ESLVal $1917 = _v1079.termRef(1);
        ESLVal $1916 = _v1079.termRef(2);
        
        {ESLVal al = $1918;
        
        {ESLVal exports = $1917;
        
        {ESLVal handlers = $1916;
        
        { LetRec letrec = new LetRec() {
        ESLVal findHandler = new ESLVal(new Function(new ESLVal("findHandler"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1525 = $args[0];
          {ESLVal _v1080 = _v1525;
                
                if(_v1080.isCons())
                {ESLVal $1919 = _v1080.head();
                  ESLVal $1920 = _v1080.tail();
                  
                  switch($1919.termName) {
                  case "MessageType": {ESLVal $1922 = $1919.termRef(0);
                    ESLVal $1921 = $1919.termRef(1);
                    
                    if($1921.isCons())
                    {ESLVal $1923 = $1921.head();
                      ESLVal $1924 = $1921.tail();
                      
                      switch($1923.termName) {
                      case "TermType": {ESLVal $1927 = $1923.termRef(0);
                        ESLVal $1926 = $1923.termRef(1);
                        ESLVal $1925 = $1923.termRef(2);
                        
                        if($1924.isCons())
                        {ESLVal $1928 = $1924.head();
                          ESLVal $1929 = $1924.tail();
                          
                          {ESLVal m = $1919;
                          
                          {ESLVal _v1526 = $1920;
                          
                          return findHandler.apply(_v1526);
                        }
                        }
                        }
                      else if($1924.isNil())
                        {ESLVal ml = $1922;
                          
                          {ESLVal tl = $1927;
                          
                          {ESLVal m = $1926;
                          
                          {ESLVal ts = $1925;
                          
                          {ESLVal rest = $1920;
                          
                          if(m.eql(n).boolVal)
                          return head.apply(_v1525);
                          else
                            {ESLVal _v1527 = $1919;
                              
                              {ESLVal _v1528 = $1920;
                              
                              return findHandler.apply(_v1528);
                            }
                            }
                        }
                        }
                        }
                        }
                        }
                      else {ESLVal m = $1919;
                          
                          {ESLVal _v1529 = $1920;
                          
                          return findHandler.apply(_v1529);
                        }
                        }
                      }
                      default: {ESLVal m = $1919;
                        
                        {ESLVal _v1530 = $1920;
                        
                        return findHandler.apply(_v1530);
                      }
                      }
                    }
                    }
                  else if($1921.isNil())
                    {ESLVal m = $1919;
                      
                      {ESLVal _v1531 = $1920;
                      
                      return findHandler.apply(_v1531);
                    }
                    }
                  else {ESLVal m = $1919;
                      
                      {ESLVal _v1532 = $1920;
                      
                      return findHandler.apply(_v1532);
                    }
                    }
                  }
                  default: {ESLVal m = $1919;
                    
                    {ESLVal _v1533 = $1920;
                    
                    return findHandler.apply(_v1533);
                  }
                  }
                }
                }
              else if(_v1080.isNil())
                return error(new ESLVal("TypeError",l,new ESLVal("cannot find message handler named ").add(n)));
              else return error(new ESLVal("case error at Pos(30926,31233)").add(ESLVal.list(_v1080)));
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "findHandler": return findHandler;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal findHandler = letrec.get("findHandler");
      
        {ESLVal _v1081 = findHandler.apply(handlers);
        
        switch(_v1081.termName) {
        case "MessageType": {ESLVal $1931 = _v1081.termRef(0);
          ESLVal $1930 = _v1081.termRef(1);
          
          if($1930.isCons())
          {ESLVal $1932 = $1930.head();
            ESLVal $1933 = $1930.tail();
            
            switch($1932.termName) {
            case "TermType": {ESLVal $1936 = $1932.termRef(0);
              ESLVal $1935 = $1932.termRef(1);
              ESLVal $1934 = $1932.termRef(2);
              
              if($1933.isCons())
              {ESLVal $1937 = $1933.head();
                ESLVal $1938 = $1933.tail();
                
                {ESLVal m = _v1081;
                
                return error(new ESLVal("TypeError",l,new ESLVal("cannot find message handler named ").add(n.add(new ESLVal(" in ").add(handlers)))));
              }
              }
            else if($1933.isNil())
              {ESLVal ml = $1931;
                
                {ESLVal tl = $1936;
                
                {ESLVal _v1534 = $1935;
                
                {ESLVal ts1 = $1934;
                
                {ESLVal ts2 = expTypes(args,selfType,valueEnv,cnstrEnv,typeEnv);
                
                if(length.apply(ts1).eql(length.apply(ts2)).boolVal)
                if(subTypes.apply(ts2,ts1).boolVal)
                  {expType(target,selfType,valueEnv,cnstrEnv,typeEnv);
                  return theTypeVoid;}
                  else
                    return error(new ESLVal("TypeError",l,new ESLVal("message argument types ").add(ppTypes(ts2,typeEnv).add(new ESLVal(" do not match expected types ").add(ppTypes(ts1,typeEnv))))));
                else
                  return error(new ESLVal("TypeError",l,new ESLVal("expecting ").add(length.apply(ts1).add(new ESLVal(" args, but received ").add(length.apply(ts2))))));
              }
              }
              }
              }
              }
            else {ESLVal m = _v1081;
                
                return error(new ESLVal("TypeError",l,new ESLVal("cannot find message handler named ").add(n.add(new ESLVal(" in ").add(handlers)))));
              }
            }
            default: {ESLVal m = _v1081;
              
              return error(new ESLVal("TypeError",l,new ESLVal("cannot find message handler named ").add(n.add(new ESLVal(" in ").add(handlers)))));
            }
          }
          }
        else if($1930.isNil())
          {ESLVal m = _v1081;
            
            return error(new ESLVal("TypeError",l,new ESLVal("cannot find message handler named ").add(n.add(new ESLVal(" in ").add(handlers)))));
          }
        else {ESLVal m = _v1081;
            
            return error(new ESLVal("TypeError",l,new ESLVal("cannot find message handler named ").add(n.add(new ESLVal(" in ").add(handlers)))));
          }
        }
        default: {ESLVal m = _v1081;
          
          return error(new ESLVal("TypeError",l,new ESLVal("cannot find message handler named ").add(n.add(new ESLVal(" in ").add(handlers)))));
        }
      }
      }}
      
      }
      }
      }
      }
      default: {ESLVal t = _v1079;
        
        return error(new ESLVal("TypeError",l,new ESLVal("expecting a behaviour type: ").add(typeNF(derefType(expType(target,selfType,valueEnv,cnstrEnv,typeEnv)),typeEnv))));
      }
    }
    }
  }
  private static ESLVal sendType = new ESLVal(new Function(new ESLVal("sendType"),null) { public ESLVal apply(ESLVal... args) { return sendType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7]); }});
  private static ESLVal actType(ESLVal l,ESLVal n,ESLVal args,ESLVal parent,ESLVal exports,ESLVal bindings,ESLVal init,ESLVal arms,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    { LetRec letrec = new LetRec() {
      ESLVal checkObservedMessage = new ESLVal(new Function(new ESLVal("checkObservedMessage"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            {ESLVal _v1082 = bindings;
              
              return $ndCase.apply(_v1082,ESLVal.list(new ESLVal("$selectMid",new ESLVal(new Function(new ESLVal("add"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $1940 = $args[0];
              ESLVal $1941 = $args[1];
              ESLVal $1942 = $args[2];
              ESLVal $1939 = $args[3];
              switch($1941.termName) {
                    case "FunBind": {ESLVal $1949 = $1941.termRef(0);
                      ESLVal $1948 = $1941.termRef(1);
                      ESLVal $1947 = $1941.termRef(2);
                      ESLVal $1946 = $1941.termRef(3);
                      ESLVal $1945 = $1941.termRef(4);
                      ESLVal $1944 = $1941.termRef(5);
                      ESLVal $1943 = $1941.termRef(6);
                      
                      switch($1948.strVal) {
                      case "observeMessage": {ESLVal bs1 = $1940;
                        
                        {ESLVal _v1517 = $1949;
                        
                        {ESLVal ps = $1947;
                        
                        {ESLVal t = $1946;
                        
                        {ESLVal st = $1945;
                        
                        {ESLVal g = $1944;
                        
                        {ESLVal e = $1943;
                        
                        {ESLVal bs2 = $1942;
                        
                        {ESLVal _v1083 = typeNF(t,typeEnv);
                        
                        switch(_v1083.termName) {
                        case "FunType": {ESLVal $1952 = _v1083.termRef(0);
                          ESLVal $1951 = _v1083.termRef(1);
                          ESLVal $1950 = _v1083.termRef(2);
                          
                          if($1951.isCons())
                          {ESLVal $1953 = $1951.head();
                            ESLVal $1954 = $1951.tail();
                            
                            if($1954.isCons())
                            {ESLVal $1955 = $1954.head();
                              ESLVal $1956 = $1954.tail();
                              
                              {ESLVal _v1518 = _v1083;
                              
                              return error(new ESLVal("TypeError",_v1517,new ESLVal("expecting observeMessage to have a type signature (In) -> Maybe[Out]")));
                            }
                            }
                          else if($1954.isNil())
                            {ESLVal fl = $1952;
                              
                              {ESLVal d = $1953;
                              
                              {ESLVal r = $1950;
                              
                              return checkObserveMessageDeclaration.apply(_v1517,d,r);
                            }
                            }
                            }
                          else {ESLVal _v1519 = _v1083;
                              
                              return error(new ESLVal("TypeError",_v1517,new ESLVal("expecting observeMessage to have a type signature (In) -> Maybe[Out]")));
                            }
                          }
                        else if($1951.isNil())
                          {ESLVal _v1520 = _v1083;
                            
                            return error(new ESLVal("TypeError",_v1517,new ESLVal("expecting observeMessage to have a type signature (In) -> Maybe[Out]")));
                          }
                        else {ESLVal _v1521 = _v1083;
                            
                            return error(new ESLVal("TypeError",_v1517,new ESLVal("expecting observeMessage to have a type signature (In) -> Maybe[Out]")));
                          }
                        }
                        default: {ESLVal _v1522 = _v1083;
                          
                          return error(new ESLVal("TypeError",_v1517,new ESLVal("expecting observeMessage to have a type signature (In) -> Maybe[Out]")));
                        }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      default: return $1939.apply();
                    }
                    }
                    default: return $1939.apply();
                  }
                }
              }))),new ESLVal(new Function(new ESLVal("listFail"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  {ESLVal bs = _v1082;
                    
                    return $null;
                  }
                }
              }));
            }
          }
        });
      ESLVal isTime = new ESLVal(new Function(new ESLVal("isTime"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal t = $args[0];
        {ESLVal _v1084 = t;
              
              switch(_v1084.termName) {
              case "TermType": {ESLVal $1959 = _v1084.termRef(0);
                ESLVal $1958 = _v1084.termRef(1);
                ESLVal $1957 = _v1084.termRef(2);
                
                switch($1958.strVal) {
                case "Time": {ESLVal _v1514 = $1959;
                  
                  {ESLVal ts = $1957;
                  
                  return $true;
                }
                }
                default: {ESLVal _v1515 = _v1084;
                  
                  return $false;
                }
              }
              }
              default: {ESLVal _v1516 = _v1084;
                
                return $false;
              }
            }
            }
          }
        });
      ESLVal checkObserveMessageDeclaration = new ESLVal(new Function(new ESLVal("checkObserveMessageDeclaration"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1511 = $args[0];
        ESLVal _v1512 = $args[1];
        ESLVal _v1513 = $args[2];
        if(typeEqual.apply(_v1512,new ESLVal("UnionType",_v1511,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v1085 = $qualArg;
                  
                  switch(_v1085.termName) {
                  case "MessageType": {ESLVal $1961 = _v1085.termRef(0);
                    ESLVal $1960 = _v1085.termRef(1);
                    
                    if($1960.isCons())
                    {ESLVal $1962 = $1960.head();
                      ESLVal $1963 = $1960.tail();
                      
                      if($1963.isCons())
                      {ESLVal $1964 = $1963.head();
                        ESLVal $1965 = $1963.tail();
                        
                        {ESLVal _0 = _v1085;
                        
                        return $nil;
                      }
                      }
                    else if($1963.isNil())
                      {ESLVal ml = $1961;
                        
                        {ESLVal t = $1962;
                        
                        return ESLVal.list(((Supplier<ESLVal>)() -> { 
                          if(isTime.apply(t).not().boolVal)
                            return ESLVal.list(t);
                            else
                              return $nil;
                        }).get());
                      }
                      }
                    else {ESLVal _0 = _v1085;
                        
                        return $nil;
                      }
                    }
                  else if($1960.isNil())
                    {ESLVal _0 = _v1085;
                      
                      return $nil;
                    }
                  else {ESLVal _0 = _v1085;
                      
                      return $nil;
                    }
                  }
                  default: {ESLVal _0 = _v1085;
                    
                    return $nil;
                  }
                }
                }
              }
            }).map(getMessageTypes.apply(arms)).flatten().flatten())).boolVal)
              {ESLVal _v1086 = typeNF(_v1513,typeEnv);
                
                switch(_v1086.termName) {
                case "UnionType": {ESLVal $1967 = _v1086.termRef(0);
                  ESLVal $1966 = _v1086.termRef(1);
                  
                  if($1966.isCons())
                  {ESLVal $1968 = $1966.head();
                    ESLVal $1969 = $1966.tail();
                    
                    switch($1968.termName) {
                    case "TermType": {ESLVal $1972 = $1968.termRef(0);
                      ESLVal $1971 = $1968.termRef(1);
                      ESLVal $1970 = $1968.termRef(2);
                      
                      switch($1971.strVal) {
                      case "Something": if($1970.isCons())
                        {ESLVal $1973 = $1970.head();
                          ESLVal $1974 = $1970.tail();
                          
                          if($1974.isCons())
                          {ESLVal $1975 = $1974.head();
                            ESLVal $1976 = $1974.tail();
                            
                            {ESLVal ms = _v1086;
                            
                            return error(new ESLVal("TypeError",_v1511,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1513)));
                          }
                          }
                        else if($1974.isNil())
                          if($1969.isCons())
                            {ESLVal $1977 = $1969.head();
                              ESLVal $1978 = $1969.tail();
                              
                              switch($1977.termName) {
                              case "TermType": {ESLVal $1981 = $1977.termRef(0);
                                ESLVal $1980 = $1977.termRef(1);
                                ESLVal $1979 = $1977.termRef(2);
                                
                                switch($1980.strVal) {
                                case "Nothing": if($1979.isCons())
                                  {ESLVal $1982 = $1979.head();
                                    ESLVal $1983 = $1979.tail();
                                    
                                    {ESLVal ms = _v1086;
                                    
                                    return error(new ESLVal("TypeError",_v1511,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1513)));
                                  }
                                  }
                                else if($1979.isNil())
                                  if($1978.isCons())
                                    {ESLVal $1984 = $1978.head();
                                      ESLVal $1985 = $1978.tail();
                                      
                                      {ESLVal ms = _v1086;
                                      
                                      return error(new ESLVal("TypeError",_v1511,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1513)));
                                    }
                                    }
                                  else if($1978.isNil())
                                    {ESLVal ul = $1967;
                                      
                                      {ESLVal l1 = $1972;
                                      
                                      {ESLVal t = $1973;
                                      
                                      {ESLVal l2 = $1981;
                                      
                                      return $null;
                                    }
                                    }
                                    }
                                    }
                                  else {ESLVal ms = _v1086;
                                      
                                      return error(new ESLVal("TypeError",_v1511,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1513)));
                                    }
                                else {ESLVal ms = _v1086;
                                    
                                    return error(new ESLVal("TypeError",_v1511,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1513)));
                                  }
                                default: {ESLVal ms = _v1086;
                                  
                                  return error(new ESLVal("TypeError",_v1511,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1513)));
                                }
                              }
                              }
                              default: {ESLVal ms = _v1086;
                                
                                return error(new ESLVal("TypeError",_v1511,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1513)));
                              }
                            }
                            }
                          else if($1969.isNil())
                            {ESLVal ms = _v1086;
                              
                              return error(new ESLVal("TypeError",_v1511,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1513)));
                            }
                          else {ESLVal ms = _v1086;
                              
                              return error(new ESLVal("TypeError",_v1511,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1513)));
                            }
                        else {ESLVal ms = _v1086;
                            
                            return error(new ESLVal("TypeError",_v1511,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1513)));
                          }
                        }
                      else if($1970.isNil())
                        {ESLVal ms = _v1086;
                          
                          return error(new ESLVal("TypeError",_v1511,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1513)));
                        }
                      else {ESLVal ms = _v1086;
                          
                          return error(new ESLVal("TypeError",_v1511,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1513)));
                        }
                    case "Nothing": if($1970.isCons())
                        {ESLVal $1986 = $1970.head();
                          ESLVal $1987 = $1970.tail();
                          
                          {ESLVal ms = _v1086;
                          
                          return error(new ESLVal("TypeError",_v1511,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1513)));
                        }
                        }
                      else if($1970.isNil())
                        if($1969.isCons())
                          {ESLVal $1988 = $1969.head();
                            ESLVal $1989 = $1969.tail();
                            
                            switch($1988.termName) {
                            case "TermType": {ESLVal $1992 = $1988.termRef(0);
                              ESLVal $1991 = $1988.termRef(1);
                              ESLVal $1990 = $1988.termRef(2);
                              
                              switch($1991.strVal) {
                              case "Something": if($1990.isCons())
                                {ESLVal $1993 = $1990.head();
                                  ESLVal $1994 = $1990.tail();
                                  
                                  if($1994.isCons())
                                  {ESLVal $1995 = $1994.head();
                                    ESLVal $1996 = $1994.tail();
                                    
                                    {ESLVal ms = _v1086;
                                    
                                    return error(new ESLVal("TypeError",_v1511,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1513)));
                                  }
                                  }
                                else if($1994.isNil())
                                  if($1989.isCons())
                                    {ESLVal $1997 = $1989.head();
                                      ESLVal $1998 = $1989.tail();
                                      
                                      {ESLVal ms = _v1086;
                                      
                                      return error(new ESLVal("TypeError",_v1511,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1513)));
                                    }
                                    }
                                  else if($1989.isNil())
                                    {ESLVal ul = $1967;
                                      
                                      {ESLVal l2 = $1972;
                                      
                                      {ESLVal l1 = $1992;
                                      
                                      {ESLVal t = $1993;
                                      
                                      return $null;
                                    }
                                    }
                                    }
                                    }
                                  else {ESLVal ms = _v1086;
                                      
                                      return error(new ESLVal("TypeError",_v1511,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1513)));
                                    }
                                else {ESLVal ms = _v1086;
                                    
                                    return error(new ESLVal("TypeError",_v1511,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1513)));
                                  }
                                }
                              else if($1990.isNil())
                                {ESLVal ms = _v1086;
                                  
                                  return error(new ESLVal("TypeError",_v1511,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1513)));
                                }
                              else {ESLVal ms = _v1086;
                                  
                                  return error(new ESLVal("TypeError",_v1511,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1513)));
                                }
                              default: {ESLVal ms = _v1086;
                                
                                return error(new ESLVal("TypeError",_v1511,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1513)));
                              }
                            }
                            }
                            default: {ESLVal ms = _v1086;
                              
                              return error(new ESLVal("TypeError",_v1511,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1513)));
                            }
                          }
                          }
                        else if($1969.isNil())
                          {ESLVal ms = _v1086;
                            
                            return error(new ESLVal("TypeError",_v1511,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1513)));
                          }
                        else {ESLVal ms = _v1086;
                            
                            return error(new ESLVal("TypeError",_v1511,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1513)));
                          }
                      else {ESLVal ms = _v1086;
                          
                          return error(new ESLVal("TypeError",_v1511,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1513)));
                        }
                      default: {ESLVal ms = _v1086;
                        
                        return error(new ESLVal("TypeError",_v1511,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1513)));
                      }
                    }
                    }
                    default: {ESLVal ms = _v1086;
                      
                      return error(new ESLVal("TypeError",_v1511,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1513)));
                    }
                  }
                  }
                else if($1966.isNil())
                  {ESLVal ms = _v1086;
                    
                    return error(new ESLVal("TypeError",_v1511,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1513)));
                  }
                else {ESLVal ms = _v1086;
                    
                    return error(new ESLVal("TypeError",_v1511,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1513)));
                  }
                }
                default: {ESLVal ms = _v1086;
                  
                  return error(new ESLVal("TypeError",_v1511,new ESLVal("observeMessage must return a value of type Maybe: ").add(_v1513)));
                }
              }
              }
              else
                return error(new ESLVal("TypeError",_v1511,new ESLVal("observeMessage must have an arg type that matches the message types of the behaviour type: ").add(ppType(_v1512,typeEnv).add(new ESLVal(" <> ").add(ppType(new ESLVal("UnionType",_v1511,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      ESLVal $qualArg = $args[0];
                  {ESLVal _v1087 = $qualArg;
                        
                        switch(_v1087.termName) {
                        case "MessageType": {ESLVal $2000 = _v1087.termRef(0);
                          ESLVal $1999 = _v1087.termRef(1);
                          
                          if($1999.isCons())
                          {ESLVal $2001 = $1999.head();
                            ESLVal $2002 = $1999.tail();
                            
                            if($2002.isCons())
                            {ESLVal $2003 = $2002.head();
                              ESLVal $2004 = $2002.tail();
                              
                              {ESLVal _0 = _v1087;
                              
                              return $nil;
                            }
                            }
                          else if($2002.isNil())
                            {ESLVal ml = $2000;
                              
                              {ESLVal t = $2001;
                              
                              return ESLVal.list(((Supplier<ESLVal>)() -> { 
                                if(isTime.apply(t).not().boolVal)
                                  return ESLVal.list(t);
                                  else
                                    return $nil;
                              }).get());
                            }
                            }
                          else {ESLVal _0 = _v1087;
                              
                              return $nil;
                            }
                          }
                        else if($1999.isNil())
                          {ESLVal _0 = _v1087;
                            
                            return $nil;
                          }
                        else {ESLVal _0 = _v1087;
                            
                            return $nil;
                          }
                        }
                        default: {ESLVal _0 = _v1087;
                          
                          return $nil;
                        }
                      }
                      }
                    }
                  }).map(getMessageTypes.apply(arms)).flatten().flatten()),typeEnv))))));
          }
        });
      ESLVal findLoc = new ESLVal(new Function(new ESLVal("findLoc"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1502 = $args[0];
        ESLVal _v1503 = $args[1];
        {ESLVal _v1088 = _v1503;
              
              if(_v1088.isCons())
              {ESLVal $2005 = _v1088.head();
                ESLVal $2006 = _v1088.tail();
                
                switch($2005.termName) {
                case "Binding": {ESLVal $2018 = $2005.termRef(0);
                  ESLVal $2017 = $2005.termRef(1);
                  ESLVal $2016 = $2005.termRef(2);
                  ESLVal $2015 = $2005.termRef(3);
                  ESLVal $2014 = $2005.termRef(4);
                  
                  {ESLVal _v1507 = $2018;
                  
                  {ESLVal m = $2017;
                  
                  {ESLVal t = $2016;
                  
                  {ESLVal st = $2015;
                  
                  {ESLVal e = $2014;
                  
                  {ESLVal _v1508 = $2006;
                  
                  if(m.eql(_v1502).boolVal)
                  return _v1507;
                  else
                    {ESLVal b = $2005;
                      
                      {ESLVal _v1509 = $2006;
                      
                      return findLoc.apply(_v1502,_v1509);
                    }
                    }
                }
                }
                }
                }
                }
                }
                }
              case "FunBind": {ESLVal $2013 = $2005.termRef(0);
                  ESLVal $2012 = $2005.termRef(1);
                  ESLVal $2011 = $2005.termRef(2);
                  ESLVal $2010 = $2005.termRef(3);
                  ESLVal $2009 = $2005.termRef(4);
                  ESLVal $2008 = $2005.termRef(5);
                  ESLVal $2007 = $2005.termRef(6);
                  
                  {ESLVal _v1504 = $2013;
                  
                  {ESLVal m = $2012;
                  
                  {ESLVal ps = $2011;
                  
                  {ESLVal t = $2010;
                  
                  {ESLVal st = $2009;
                  
                  {ESLVal g = $2008;
                  
                  {ESLVal e = $2007;
                  
                  {ESLVal _v1505 = $2006;
                  
                  if(m.eql(_v1502).boolVal)
                  return _v1504;
                  else
                    {ESLVal b = $2005;
                      
                      {ESLVal _v1506 = $2006;
                      
                      return findLoc.apply(_v1502,_v1506);
                    }
                    }
                }
                }
                }
                }
                }
                }
                }
                }
                }
                default: {ESLVal b = $2005;
                  
                  {ESLVal _v1510 = $2006;
                  
                  return findLoc.apply(_v1502,_v1510);
                }
                }
              }
              }
            else if(_v1088.isNil())
              return p0;
            else return error(new ESLVal("case error at Pos(34022,34326)").add(ESLVal.list(_v1088)));
            }
          }
        });
      ESLVal findType = new ESLVal(new Function(new ESLVal("findType"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1493 = $args[0];
        ESLVal _v1494 = $args[1];
        {ESLVal _v1089 = _v1494;
              
              if(_v1089.isCons())
              {ESLVal $2019 = _v1089.head();
                ESLVal $2020 = _v1089.tail();
                
                switch($2019.termName) {
                case "Binding": {ESLVal $2032 = $2019.termRef(0);
                  ESLVal $2031 = $2019.termRef(1);
                  ESLVal $2030 = $2019.termRef(2);
                  ESLVal $2029 = $2019.termRef(3);
                  ESLVal $2028 = $2019.termRef(4);
                  
                  {ESLVal _v1498 = $2032;
                  
                  {ESLVal m = $2031;
                  
                  {ESLVal t = $2030;
                  
                  {ESLVal st = $2029;
                  
                  {ESLVal e = $2028;
                  
                  {ESLVal _v1499 = $2020;
                  
                  if(m.eql(_v1493).boolVal)
                  return substTypeEnv.apply(typeEnv,t);
                  else
                    {ESLVal b = $2019;
                      
                      {ESLVal _v1500 = $2020;
                      
                      return findType.apply(_v1493,_v1500);
                    }
                    }
                }
                }
                }
                }
                }
                }
                }
              case "FunBind": {ESLVal $2027 = $2019.termRef(0);
                  ESLVal $2026 = $2019.termRef(1);
                  ESLVal $2025 = $2019.termRef(2);
                  ESLVal $2024 = $2019.termRef(3);
                  ESLVal $2023 = $2019.termRef(4);
                  ESLVal $2022 = $2019.termRef(5);
                  ESLVal $2021 = $2019.termRef(6);
                  
                  {ESLVal _v1495 = $2027;
                  
                  {ESLVal m = $2026;
                  
                  {ESLVal ps = $2025;
                  
                  {ESLVal t = $2024;
                  
                  {ESLVal st = $2023;
                  
                  {ESLVal g = $2022;
                  
                  {ESLVal e = $2021;
                  
                  {ESLVal _v1496 = $2020;
                  
                  if(m.eql(_v1493).boolVal)
                  return substTypeEnv.apply(typeEnv,t);
                  else
                    {ESLVal b = $2019;
                      
                      {ESLVal _v1497 = $2020;
                      
                      return findType.apply(_v1493,_v1497);
                    }
                    }
                }
                }
                }
                }
                }
                }
                }
                }
                }
                default: {ESLVal b = $2019;
                  
                  {ESLVal _v1501 = $2020;
                  
                  return findType.apply(_v1493,_v1501);
                }
                }
              }
              }
            else if(_v1089.isNil())
              return $null;
            else return error(new ESLVal("case error at Pos(34380,34737)").add(ESLVal.list(_v1089)));
            }
          }
        });
      ESLVal decs = new ESLVal(new Function(new ESLVal("decs"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1489 = $args[0];
        {ESLVal _v1090 = _v1489;
              
              if(_v1090.isCons())
              {ESLVal $2033 = _v1090.head();
                ESLVal $2034 = _v1090.tail();
                
                {ESLVal m = $2033;
                
                {ESLVal _v1490 = $2034;
                
                {ESLVal _v1491 = findType.apply(m,bindings);
                ESLVal _v1492 = findLoc.apply(m,bindings);
                
                if(_v1491.eql($null).boolVal)
                return error(new ESLVal("TypeError",_v1492,new ESLVal("cannot find exported name ").add(m)));
                else
                  return decs.apply(_v1490).cons(new ESLVal("Dec",_v1492,m,_v1491,_v1491));
              }
              }
              }
              }
            else if(_v1090.isNil())
              return $nil;
            else return error(new ESLVal("case error at Pos(34780,35111)").add(ESLVal.list(_v1090)));
            }
          }
        });
      ESLVal getMessageTypes = new ESLVal(new Function(new ESLVal("getMessageTypes"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1486 = $args[0];
        {ESLVal _v1091 = _v1486;
              
              if(_v1091.isCons())
              {ESLVal $2035 = _v1091.head();
                ESLVal $2036 = _v1091.tail();
                
                switch($2035.termName) {
                case "BArm": {ESLVal $2040 = $2035.termRef(0);
                  ESLVal $2039 = $2035.termRef(1);
                  ESLVal $2038 = $2035.termRef(2);
                  ESLVal $2037 = $2035.termRef(3);
                  
                  {ESLVal _v1487 = $2040;
                  
                  {ESLVal ps = $2039;
                  
                  {ESLVal g = $2038;
                  
                  {ESLVal e = $2037;
                  
                  {ESLVal _v1488 = $2036;
                  
                  return getMessageTypes.apply(_v1488).cons(getMessageType.apply(ps));
                }
                }
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(35162,35317)").add(ESLVal.list(_v1091)));
              }
              }
            else if(_v1091.isNil())
              return $nil;
            else return error(new ESLVal("case error at Pos(35162,35317)").add(ESLVal.list(_v1091)));
            }
          }
        });
      ESLVal getMessageType = new ESLVal(new Function(new ESLVal("getMessageType"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal ps = $args[0];
        {ESLVal _v1092 = ps;
              
              if(_v1092.isCons())
              {ESLVal $2041 = _v1092.head();
                ESLVal $2042 = _v1092.tail();
                
                switch($2041.termName) {
                case "PTerm": {ESLVal $2046 = $2041.termRef(0);
                  ESLVal $2045 = $2041.termRef(1);
                  ESLVal $2044 = $2041.termRef(2);
                  ESLVal $2043 = $2041.termRef(3);
                  
                  if($2042.isCons())
                  {ESLVal $2047 = $2042.head();
                    ESLVal $2048 = $2042.tail();
                    
                    return error(new ESLVal("case error at Pos(35367,35638)").add(ESLVal.list(_v1092)));
                  }
                else if($2042.isNil())
                  {ESLVal pl = $2046;
                    
                    {ESLVal termName = $2045;
                    
                    {ESLVal targs = $2044;
                    
                    {ESLVal _v1485 = $2043;
                    
                    {ESLVal ts = map.apply(new ESLVal(new Function(new ESLVal("fun392"),getSelf()) {
                        public ESLVal apply(ESLVal... $args) {
                          ESLVal p = $args[0];
                      return getPatternType(l,p,selfType,valueEnv,cnstrEnv,typeEnv);
                        }
                      }),_v1485);
                    
                    return new ESLVal("MessageType",pl,ESLVal.list(new ESLVal("TermType",pl,termName,ts)));
                  }
                  }
                  }
                  }
                  }
                else return error(new ESLVal("case error at Pos(35367,35638)").add(ESLVal.list(_v1092)));
                }
                default: return error(new ESLVal("case error at Pos(35367,35638)").add(ESLVal.list(_v1092)));
              }
              }
            else if(_v1092.isNil())
              return error(new ESLVal("case error at Pos(35367,35638)").add(ESLVal.list(_v1092)));
            else return error(new ESLVal("case error at Pos(35367,35638)").add(ESLVal.list(_v1092)));
            }
          }
        });
      ESLVal typeCheckArms = new ESLVal(new Function(new ESLVal("typeCheckArms"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1480 = $args[0];
        ESLVal _v1481 = $args[1];
        ESLVal _v1482 = $args[2];
        {ESLVal _v1093 = _v1480;
              
              if(_v1093.isCons())
              {ESLVal $2049 = _v1093.head();
                ESLVal $2050 = _v1093.tail();
                
                switch($2049.termName) {
                case "BArm": {ESLVal $2054 = $2049.termRef(0);
                  ESLVal $2053 = $2049.termRef(1);
                  ESLVal $2052 = $2049.termRef(2);
                  ESLVal $2051 = $2049.termRef(3);
                  
                  {ESLVal _v1483 = $2054;
                  
                  {ESLVal ps = $2053;
                  
                  {ESLVal g = $2052;
                  
                  {ESLVal e = $2051;
                  
                  {ESLVal _v1484 = $2050;
                  
                  {typeCheckArm.apply(_v1483,ps,g,e,_v1481,_v1482);
                return typeCheckArms.apply(_v1484,_v1481,_v1482);}
                }
                }
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(35714,35941)").add(ESLVal.list(_v1093)));
              }
              }
            else if(_v1093.isNil())
              return $null;
            else return error(new ESLVal("case error at Pos(35714,35941)").add(ESLVal.list(_v1093)));
            }
          }
        });
      ESLVal typeCheckArm = new ESLVal(new Function(new ESLVal("typeCheckArm"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1471 = $args[0];
        ESLVal _v1472 = $args[1];
        ESLVal _v1473 = $args[2];
        ESLVal _v1474 = $args[3];
        ESLVal _v1475 = $args[4];
        ESLVal _v1476 = $args[5];
        {ESLVal _v1094 = _v1472;
              
              if(_v1094.isCons())
              {ESLVal $2055 = _v1094.head();
                ESLVal $2056 = _v1094.tail();
                
                switch($2055.termName) {
                case "PTerm": {ESLVal $2060 = $2055.termRef(0);
                  ESLVal $2059 = $2055.termRef(1);
                  ESLVal $2058 = $2055.termRef(2);
                  ESLVal $2057 = $2055.termRef(3);
                  
                  if($2056.isCons())
                  {ESLVal $2061 = $2056.head();
                    ESLVal $2062 = $2056.tail();
                    
                    return error(new ESLVal("case error at Pos(36040,36489)").add(ESLVal.list(_v1094)));
                  }
                else if($2056.isNil())
                  {ESLVal pl = $2060;
                    
                    {ESLVal termName = $2059;
                    
                    {ESLVal targs = $2058;
                    
                    {ESLVal _v1477 = $2057;
                    
                    {ESLVal ts = map.apply(new ESLVal(new Function(new ESLVal("fun393"),getSelf()) {
                        public ESLVal apply(ESLVal... $args) {
                          ESLVal p = $args[0];
                      return getPatternType(_v1471,p,_v1475,_v1476,cnstrEnv,typeEnv);
                        }
                      }),_v1477);
                    
                    {patternTypes(_v1471,_v1477,ts,_v1475,_v1476,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun394"),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      ESLVal _v1478 = $args[0];
                  ESLVal _v1479 = $args[1];
                  return expType(_v1474,_v1475,_v1479,cnstrEnv,typeEnv);
                    }
                  }));
                  return $null;}
                  }
                  }
                  }
                  }
                  }
                else return error(new ESLVal("case error at Pos(36040,36489)").add(ESLVal.list(_v1094)));
                }
                default: return error(new ESLVal("case error at Pos(36040,36489)").add(ESLVal.list(_v1094)));
              }
              }
            else if(_v1094.isNil())
              return error(new ESLVal("case error at Pos(36040,36489)").add(ESLVal.list(_v1094)));
            else return error(new ESLVal("case error at Pos(36040,36489)").add(ESLVal.list(_v1094)));
            }
          }
        });
      
      public ESLVal get(String name) {
        switch(name) {
          case "checkObservedMessage": return checkObservedMessage;
          
          case "isTime": return isTime;
          
          case "checkObserveMessageDeclaration": return checkObserveMessageDeclaration;
          
          case "findLoc": return findLoc;
          
          case "findType": return findType;
          
          case "decs": return decs;
          
          case "getMessageTypes": return getMessageTypes;
          
          case "getMessageType": return getMessageType;
          
          case "typeCheckArms": return typeCheckArms;
          
          case "typeCheckArm": return typeCheckArm;
          
          default: throw new Error("cannot find letrec binding");
        }
        }
      };
    ESLVal checkObservedMessage = letrec.get("checkObservedMessage");
    
    ESLVal isTime = letrec.get("isTime");
    
    ESLVal checkObserveMessageDeclaration = letrec.get("checkObserveMessageDeclaration");
    
    ESLVal findLoc = letrec.get("findLoc");
    
    ESLVal findType = letrec.get("findType");
    
    ESLVal decs = letrec.get("decs");
    
    ESLVal getMessageTypes = letrec.get("getMessageTypes");
    
    ESLVal getMessageType = letrec.get("getMessageType");
    
    ESLVal typeCheckArms = letrec.get("typeCheckArms");
    
    ESLVal typeCheckArm = letrec.get("typeCheckArm");
    
      {ESLVal parentType = ((Supplier<ESLVal>)() -> { 
          if(parent.eql($null).boolVal)
            return actType0;
            else
              return expType(parent,selfType,valueEnv,cnstrEnv,typeEnv);
        }).get();
      ESLVal localEnv = parBind(bindings,selfType,valueEnv,cnstrEnv,typeEnv);
      
      {ESLVal exportedDecs = decs.apply(exports);
      
      {ESLVal messageTypes = getMessageTypes.apply(arms);
      
      {ESLVal _v1523 = new ESLVal("ExtendedAct",l,parentType,exportedDecs,messageTypes);
      ESLVal _v1524 = ESLVal.list(new ESLVal("Map",new ESLVal("$super"),parentType));
      
      {typeCheckExports(l,exportedDecs,bindings,_v1523,localEnv.add(valueEnv),typeEnv,cnstrEnv);
    typeCheckValues(valueDefs(bindings),_v1523,_v1524.add(localEnv.add(valueEnv)),typeEnv,cnstrEnv);
    expType(init,_v1523,_v1524.add(localEnv.add(valueEnv)),cnstrEnv,typeEnv);
    typeCheckArms.apply(arms,_v1523,_v1524.add(localEnv.add(valueEnv)));
    checkObservedMessage.apply();
    return _v1523;}
    }
    }
    }
    }}
    
  }
  private static ESLVal actType = new ESLVal(new Function(new ESLVal("actType"),null) { public ESLVal apply(ESLVal... args) { return actType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7],args[8],args[9],args[10],args[11]); }});
  private static ESLVal typeCheckExports(ESLVal l,ESLVal exports,ESLVal defs,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {{
      ESLVal _v1095 = exports;
      while(_v1095.isCons()) {
        ESLVal e = _v1095.headVal;
        if(exists.apply(new ESLVal(new Function(new ESLVal("fun395"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal b = $args[0];
        return bindingName.apply(b).eql(decName.apply(e)).and(typeEqual.apply(lookupType.apply(decName.apply(e),valueEnv),decType.apply(e)));
          }
        }),defs).boolVal)
          {}
          else
            error(new ESLVal("TypeError",l,new ESLVal(" cannot find export for ").add(decName.apply(e))));
        _v1095 = _v1095.tailVal;}
    }
    return $null;}
  }
  private static ESLVal typeCheckExports = new ESLVal(new Function(new ESLVal("typeCheckExports"),null) { public ESLVal apply(ESLVal... args) { return typeCheckExports(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal bTypeExports(ESLVal t) {
    
    {ESLVal _v1096 = t;
      
      switch(_v1096.termName) {
      case "ExtendedAct": {ESLVal $2073 = _v1096.termRef(0);
        ESLVal $2072 = _v1096.termRef(1);
        ESLVal $2071 = _v1096.termRef(2);
        ESLVal $2070 = _v1096.termRef(3);
        
        {ESLVal l = $2073;
        
        {ESLVal parent = $2072;
        
        {ESLVal exports = $2071;
        
        {ESLVal message = $2070;
        
        return bTypeExports(parent).add(exports);
      }
      }
      }
      }
      }
    case "ActType": {ESLVal $2069 = _v1096.termRef(0);
        ESLVal $2068 = _v1096.termRef(1);
        ESLVal $2067 = _v1096.termRef(2);
        
        {ESLVal l = $2069;
        
        {ESLVal exports = $2068;
        
        {ESLVal message = $2067;
        
        return exports;
      }
      }
      }
      }
    case "TypeClosure": {ESLVal $2066 = _v1096.termRef(0);
        
        {ESLVal f = $2066;
        
        return bTypeExports(f.apply());
      }
      }
    case "RecType": {ESLVal $2065 = _v1096.termRef(0);
        ESLVal $2064 = _v1096.termRef(1);
        ESLVal $2063 = _v1096.termRef(2);
        
        {ESLVal l = $2065;
        
        {ESLVal n = $2064;
        
        {ESLVal _v1470 = $2063;
        
        return bTypeExports(substType.apply(new ESLVal("RecType",l,n,_v1470),n,_v1470));
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(37915,38325)").add(ESLVal.list(_v1096)));
    }
    }
  }
  private static ESLVal bTypeExports = new ESLVal(new Function(new ESLVal("bTypeExports"),null) { public ESLVal apply(ESLVal... args) { return bTypeExports(args[0]); }});
  private static ESLVal cmpType(ESLVal l,ESLVal e,ESLVal qs,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal _v1097 = qs;
      
      if(_v1097.isCons())
      {ESLVal $2074 = _v1097.head();
        ESLVal $2075 = _v1097.tail();
        
        switch($2074.termName) {
        case "BQual": {ESLVal $2080 = $2074.termRef(0);
          ESLVal $2079 = $2074.termRef(1);
          ESLVal $2078 = $2074.termRef(2);
          
          {ESLVal _v1465 = $2080;
          
          {ESLVal p = $2079;
          
          {ESLVal list = $2078;
          
          {ESLVal _v1466 = $2075;
          
          {ESLVal lType = expType(list,selfType,valueEnv,cnstrEnv,typeEnv);
          
          {ESLVal _v1098 = lType;
          
          switch(_v1098.termName) {
          case "ListType": {ESLVal $2082 = _v1098.termRef(0);
            ESLVal $2081 = _v1098.termRef(1);
            
            {ESLVal ll = $2082;
            
            {ESLVal t = $2081;
            
            {ESLVal _v1467 = _v1466;
            
            return patternType(_v1465,p,substTypeEnv.apply(typeEnv,t),selfType,valueEnv,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun396"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v1468 = $args[0];
            ESLVal _v1469 = $args[1];
            return cmpType(_v1465,e,_v1467,selfType,_v1469,cnstrEnv,typeEnv);
              }
            }));
          }
          }
          }
          }
          default: {ESLVal t = _v1098;
            
            return error(new ESLVal("TypeError",_v1465,new ESLVal("qualifier binding expects a list: ").add(ppType(t,typeEnv))));
          }
        }
        }
        }
        }
        }
        }
        }
        }
      case "PQual": {ESLVal $2077 = $2074.termRef(0);
          ESLVal $2076 = $2074.termRef(1);
          
          {ESLVal _v1463 = $2077;
          
          {ESLVal b = $2076;
          
          {ESLVal _v1464 = $2075;
          
          {ESLVal bType = expType(b,selfType,valueEnv,cnstrEnv,typeEnv);
          
          if(isBoolType.apply(bType).boolVal)
          return cmpType(_v1463,e,_v1464,selfType,valueEnv,cnstrEnv,typeEnv);
          else
            return error(new ESLVal("TypeError",_v1463,new ESLVal("qualifier expects a boolean type: ").add(ppType(bType,typeEnv))));
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(38436,39422)").add(ESLVal.list(_v1097)));
      }
      }
    else if(_v1097.isNil())
      {ESLVal t = expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
        
        return new ESLVal("ListType",l,t);
      }
    else return error(new ESLVal("case error at Pos(38436,39422)").add(ESLVal.list(_v1097)));
    }
  }
  private static ESLVal cmpType = new ESLVal(new Function(new ESLVal("cmpType"),null) { public ESLVal apply(ESLVal... args) { return cmpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal updateType(ESLVal l,ESLVal n,ESLVal e,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t = lookupType.apply(n,valueEnv);
      
      if(t.eql($null).boolVal)
      return error(new ESLVal("TypeError",l,new ESLVal("unbound variable ").add(n)));
      else
        {ESLVal valueType = expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
          
          if(subType.apply(valueType,t).boolVal)
          return valueType;
          else
            return error(new ESLVal("TypeError",l,new ESLVal("type of variable ").add(n.add(new ESLVal("::").add(ppType(t,typeEnv).add(new ESLVal(" does not agree with value type ").add(ppType(valueType,typeEnv))))))));
        }
    }
  }
  private static ESLVal updateType = new ESLVal(new Function(new ESLVal("updateType"),null) { public ESLVal apply(ESLVal... args) { return updateType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal letType(ESLVal l,ESLVal bs,ESLVal e,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal env = parBind(bs,selfType,valueEnv,cnstrEnv,typeEnv);
      
      {{
      ESLVal _v1099 = bs;
      while(_v1099.isCons()) {
        ESLVal b = _v1099.headVal;
        typeCheckDef(b,selfType,valueEnv,env.add(valueEnv),cnstrEnv,typeEnv);
        _v1099 = _v1099.tailVal;}
    }
    return expType(e,selfType,env.add(valueEnv),cnstrEnv,typeEnv);}
    }
  }
  private static ESLVal letType = new ESLVal(new Function(new ESLVal("letType"),null) { public ESLVal apply(ESLVal... args) { return letType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal letrecType(ESLVal l,ESLVal bs,ESLVal e,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal env = recBind(bs,selfType,valueEnv,cnstrEnv,typeEnv);
      
      {{
      ESLVal _v1100 = bs;
      while(_v1100.isCons()) {
        ESLVal b = _v1100.headVal;
        typeCheckDef(b,selfType,env.add(valueEnv),env.add(valueEnv),cnstrEnv,typeEnv);
        _v1100 = _v1100.tailVal;}
    }
    return expType(e,selfType,env.add(valueEnv),cnstrEnv,typeEnv);}
    }
  }
  private static ESLVal letrecType = new ESLVal(new Function(new ESLVal("letrecType"),null) { public ESLVal apply(ESLVal... args) { return letrecType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal checkDupBindings(ESLVal bs) {
    
    {ESLVal _v1101 = bs;
      
      if(_v1101.isCons())
      {ESLVal $2083 = _v1101.head();
        ESLVal $2084 = _v1101.tail();
        
        {ESLVal b = $2083;
        
        {ESLVal _v1462 = $2084;
        
        if(member.apply(bindingName.apply(b),new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal b = $l0.head();
            $l0 = $l0.tail();
            $v.add(bindingName.apply(b));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(_v1462)).boolVal)
        return error(new ESLVal("TypeError",bindingLoc.apply(b),new ESLVal("duplicate definitions for ").add(bindingName.apply(b))));
        else
          return checkDupBindings(_v1462);
      }
      }
      }
    else if(_v1101.isNil())
      return $null;
    else return error(new ESLVal("case error at Pos(40668,40933)").add(ESLVal.list(_v1101)));
    }
  }
  private static ESLVal checkDupBindings = new ESLVal(new Function(new ESLVal("checkDupBindings"),null) { public ESLVal apply(ESLVal... args) { return checkDupBindings(args[0]); }});
  private static ESLVal parBind(ESLVal bs,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {checkDupBindings(bs);
    return valueDefsToTEnv(valueDefs(bs),selfType,valueEnv,cnstrEnv,typeEnv);}
  }
  private static ESLVal parBind = new ESLVal(new Function(new ESLVal("parBind"),null) { public ESLVal apply(ESLVal... args) { return parBind(args[0],args[1],args[2],args[3],args[4]); }});
  private static ESLVal recBind(ESLVal bs,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    return valueDefsToTEnv(valueDefs(bs),selfType,valueEnv,cnstrEnv,typeEnv);
  }
  private static ESLVal recBind = new ESLVal(new Function(new ESLVal("recBind"),null) { public ESLVal apply(ESLVal... args) { return recBind(args[0],args[1],args[2],args[3],args[4]); }});
  private static ESLVal caseType(ESLVal l,ESLVal es,ESLVal arms,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal ts1 = expTypes(es,selfType,valueEnv,cnstrEnv,typeEnv);
      
      {ESLVal ts2 = armTypes(arms,ts1,selfType,valueEnv,cnstrEnv,typeEnv);
      
      {checkCase(l,ts1,arms);
    if(allEqualTypes.apply(head.apply(ts2),tail.apply(ts2)).boolVal)
      return head.apply(ts2);
      else
        return error(new ESLVal("TypeError",l,new ESLVal("case arm types do not agree: ").add(ppTypes(ts1,typeEnv).add(new ESLVal(" ").add(ppTypes(ts2,typeEnv))))));}
    }
    }
  }
  private static ESLVal caseType = new ESLVal(new Function(new ESLVal("caseType"),null) { public ESLVal apply(ESLVal... args) { return caseType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal checkCase(ESLVal l,ESLVal valueTypes,ESLVal arms) {
    
    {ESLVal _v1102 = valueTypes;
      
      if(_v1102.isCons())
      {ESLVal $2085 = _v1102.head();
        ESLVal $2086 = _v1102.tail();
        
        switch($2085.termName) {
        case "UnionType": {ESLVal $2088 = $2085.termRef(0);
          ESLVal $2087 = $2085.termRef(1);
          
          {ESLVal ul = $2088;
          
          {ESLVal ts = $2087;
          
          {ESLVal _v1460 = $2086;
          
          {checkUnionAgainstArms(l,ts,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v1103 = $qualArg;
              
              switch(_v1103.termName) {
              case "BArm": {ESLVal $2092 = _v1103.termRef(0);
                ESLVal $2091 = _v1103.termRef(1);
                ESLVal $2090 = _v1103.termRef(2);
                ESLVal $2089 = _v1103.termRef(3);
                
                {ESLVal bl = $2092;
                
                {ESLVal patterns = $2091;
                
                {ESLVal guard = $2090;
                
                {ESLVal body = $2089;
                
                return ESLVal.list(ESLVal.list(head.apply(patterns)));
              }
              }
              }
              }
              }
              default: {ESLVal _0 = _v1103;
                
                return $nil;
              }
            }
            }
          }
        }).map(arms).flatten().flatten());
        return checkCase(l,_v1460,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1104 = $qualArg;
                
                switch(_v1104.termName) {
                case "BArm": {ESLVal $2096 = _v1104.termRef(0);
                  ESLVal $2095 = _v1104.termRef(1);
                  ESLVal $2094 = _v1104.termRef(2);
                  ESLVal $2093 = _v1104.termRef(3);
                  
                  {ESLVal bl = $2096;
                  
                  {ESLVal patterns = $2095;
                  
                  {ESLVal guard = $2094;
                  
                  {ESLVal body = $2093;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("BArm",bl,tail.apply(patterns),guard,body)));
                }
                }
                }
                }
                }
                default: {ESLVal _0 = _v1104;
                  
                  return $nil;
                }
              }
              }
            }
          }).map(arms).flatten().flatten());}
        }
        }
        }
        }
        default: {ESLVal t = $2085;
          
          {ESLVal _v1461 = $2086;
          
          return checkCase(l,_v1461,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1105 = $qualArg;
                
                switch(_v1105.termName) {
                case "BArm": {ESLVal $2100 = _v1105.termRef(0);
                  ESLVal $2099 = _v1105.termRef(1);
                  ESLVal $2098 = _v1105.termRef(2);
                  ESLVal $2097 = _v1105.termRef(3);
                  
                  {ESLVal bl = $2100;
                  
                  {ESLVal patterns = $2099;
                  
                  {ESLVal guard = $2098;
                  
                  {ESLVal body = $2097;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("BArm",bl,tail.apply(patterns),guard,body)));
                }
                }
                }
                }
                }
                default: {ESLVal _0 = _v1105;
                  
                  return $nil;
                }
              }
              }
            }
          }).map(arms).flatten().flatten());
        }
        }
      }
      }
    else if(_v1102.isNil())
      return $null;
    else return error(new ESLVal("case error at Pos(41919,42357)").add(ESLVal.list(_v1102)));
    }
  }
  private static ESLVal checkCase = new ESLVal(new Function(new ESLVal("checkCase"),null) { public ESLVal apply(ESLVal... args) { return checkCase(args[0],args[1],args[2]); }});
  private static ESLVal checkUnionAgainstArms(ESLVal l,ESLVal terms,ESLVal patterns) {
    
    {ESLVal isPVar = new ESLVal(new Function(new ESLVal("isPVar"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal p = $args[0];
        {ESLVal _v1106 = p;
              
              switch(_v1106.termName) {
              case "PVar": {ESLVal $2103 = _v1106.termRef(0);
                ESLVal $2102 = _v1106.termRef(1);
                ESLVal $2101 = _v1106.termRef(2);
                
                {ESLVal _v1459 = $2103;
                
                {ESLVal n = $2102;
                
                {ESLVal t = $2101;
                
                return $true;
              }
              }
              }
              }
              default: {ESLVal x = _v1106;
                
                return $false;
              }
            }
            }
          }
        });
      
      if(exists.apply(isPVar,patterns).not().boolVal)
      {ESLVal cnstrNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1107 = $qualArg;
                
                switch(_v1107.termName) {
                case "TermType": {ESLVal $2106 = _v1107.termRef(0);
                  ESLVal $2105 = _v1107.termRef(1);
                  ESLVal $2104 = _v1107.termRef(2);
                  
                  {ESLVal tl = $2106;
                  
                  {ESLVal n = $2105;
                  
                  {ESLVal ts = $2104;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1107;
                  
                  return $nil;
                }
              }
              }
            }
          }).map(terms).flatten().flatten();
        ESLVal patternNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1108 = $qualArg;
                
                switch(_v1108.termName) {
                case "PTerm": {ESLVal $2110 = _v1108.termRef(0);
                  ESLVal $2109 = _v1108.termRef(1);
                  ESLVal $2108 = _v1108.termRef(2);
                  ESLVal $2107 = _v1108.termRef(3);
                  
                  {ESLVal tl = $2110;
                  
                  {ESLVal n = $2109;
                  
                  {ESLVal ts = $2108;
                  
                  {ESLVal ps = $2107;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                }
                default: {ESLVal _0 = _v1108;
                  
                  return $nil;
                }
              }
              }
            }
          }).map(patterns).flatten().flatten();
        
        if(forall.apply(new ESLVal(new Function(new ESLVal("fun397"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal cnstrName = $args[0];
      return member.apply(cnstrName,patternNames);
        }
      }),cnstrNames).boolVal)
        return $null;
        else
          return addWarning.apply(l,new ESLVal("case handles constructors ").add(joinBy.apply(new ESLVal(44),patternNames).add(new ESLVal(" but is missing patterns matching constructors ").add(joinBy.apply(new ESLVal(44),removeAll.apply(patternNames,cnstrNames))))));
      }
      else
        return $null;
    }
  }
  private static ESLVal checkUnionAgainstArms = new ESLVal(new Function(new ESLVal("checkUnionAgainstArms"),null) { public ESLVal apply(ESLVal... args) { return checkUnionAgainstArms(args[0],args[1],args[2]); }});
  private static ESLVal tryType(ESLVal l,ESLVal e,ESLVal arms,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal ts1 = expTypes(ESLVal.list(e),selfType,valueEnv,cnstrEnv,typeEnv);
      
      {ESLVal ts2 = armTypes(arms,ts1,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(allEqualTypes.apply(head.apply(ts2),tail.apply(ts2)).boolVal)
      return head.apply(ts2);
      else
        return error(new ESLVal("TypeError",l,new ESLVal("try arm types do not agree: ").add(ppTypes(ts1,typeEnv).add(new ESLVal(" ").add(ppTypes(ts2,typeEnv))))));
    }
    }
  }
  private static ESLVal tryType = new ESLVal(new Function(new ESLVal("tryType"),null) { public ESLVal apply(ESLVal... args) { return tryType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal armTypes(ESLVal arms,ESLVal ts,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal _v1109 = arms;
      
      if(_v1109.isCons())
      {ESLVal $2111 = _v1109.head();
        ESLVal $2112 = _v1109.tail();
        
        {ESLVal a = $2111;
        
        {ESLVal _v1458 = $2112;
        
        return armTypes(_v1458,ts,selfType,valueEnv,cnstrEnv,typeEnv).cons(armType(a,ts,selfType,valueEnv,cnstrEnv,typeEnv));
      }
      }
      }
    else if(_v1109.isNil())
      return $nil;
    else return error(new ESLVal("case error at Pos(43592,43761)").add(ESLVal.list(_v1109)));
    }
  }
  private static ESLVal armTypes = new ESLVal(new Function(new ESLVal("armTypes"),null) { public ESLVal apply(ESLVal... args) { return armTypes(args[0],args[1],args[2],args[3],args[4],args[5]); }});
  private static ESLVal armType(ESLVal arm,ESLVal ts,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal _v1110 = arm;
      
      switch(_v1110.termName) {
      case "BArm": {ESLVal $2116 = _v1110.termRef(0);
        ESLVal $2115 = _v1110.termRef(1);
        ESLVal $2114 = _v1110.termRef(2);
        ESLVal $2113 = _v1110.termRef(3);
        
        {ESLVal l = $2116;
        
        {ESLVal ps = $2115;
        
        {ESLVal guard = $2114;
        
        {ESLVal exp = $2113;
        
        {checkPatterns(l,ps);
      if(length.apply(ps).eql(length.apply(ts)).boolVal)
        return patternTypes(l,ps,ts,selfType,valueEnv,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun398"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1456 = $args[0];
          ESLVal _v1457 = $args[1];
          return guardedExpType(l,guard,exp,selfType,_v1457,cnstrEnv,typeEnv);
            }
          }));
        else
          return error(new ESLVal("TypeError",l,new ESLVal("number of patterns ").add(length.apply(ps).add(new ESLVal(" does not match supplied values: ").add(length.apply(ts))))));}
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(43863,44324)").add(ESLVal.list(_v1110)));
    }
    }
  }
  private static ESLVal armType = new ESLVal(new Function(new ESLVal("armType"),null) { public ESLVal apply(ESLVal... args) { return armType(args[0],args[1],args[2],args[3],args[4],args[5]); }});
  private static ESLVal refType(ESLVal l,ESLVal e,ESLVal n,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    { LetRec letrec = new LetRec() {
      ESLVal t = derefType(expType(e,selfType,valueEnv,cnstrEnv,typeEnv));
      ESLVal findExport = new ESLVal(new Function(new ESLVal("findExport"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal decs = $args[0];
        {ESLVal _v1111 = decs;
              
              if(_v1111.isCons())
              {ESLVal $2117 = _v1111.head();
                ESLVal $2118 = _v1111.tail();
                
                switch($2117.termName) {
                case "Dec": {ESLVal $2122 = $2117.termRef(0);
                  ESLVal $2121 = $2117.termRef(1);
                  ESLVal $2120 = $2117.termRef(2);
                  ESLVal $2119 = $2117.termRef(3);
                  
                  {ESLVal _v1427 = $2122;
                  
                  {ESLVal m = $2121;
                  
                  {ESLVal t = $2120;
                  
                  {ESLVal st = $2119;
                  
                  {ESLVal _v1428 = $2118;
                  
                  if(m.eql(n).boolVal)
                  return t;
                  else
                    {ESLVal d = $2117;
                      
                      {ESLVal _v1429 = $2118;
                      
                      return findExport.apply(_v1429);
                    }
                    }
                }
                }
                }
                }
                }
                }
                default: {ESLVal d = $2117;
                  
                  {ESLVal _v1430 = $2118;
                  
                  return findExport.apply(_v1430);
                }
                }
              }
              }
            else if(_v1111.isNil())
              return $null;
            else return error(new ESLVal("case error at Pos(44552,44725)").add(ESLVal.list(_v1111)));
            }
          }
        });
      ESLVal findField = new ESLVal(new Function(new ESLVal("findField"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal fs = $args[0];
        {ESLVal _v1112 = fs;
              
              if(_v1112.isCons())
              {ESLVal $2123 = _v1112.head();
                ESLVal $2124 = _v1112.tail();
                
                switch($2123.termName) {
                case "Dec": {ESLVal $2128 = $2123.termRef(0);
                  ESLVal $2127 = $2123.termRef(1);
                  ESLVal $2126 = $2123.termRef(2);
                  ESLVal $2125 = $2123.termRef(3);
                  
                  {ESLVal _v1422 = $2128;
                  
                  {ESLVal m = $2127;
                  
                  {ESLVal t = $2126;
                  
                  {ESLVal ds = $2125;
                  
                  {ESLVal _v1423 = $2124;
                  
                  if(m.eql(n).boolVal)
                  return t;
                  else
                    {ESLVal _v1424 = $2123;
                      
                      {ESLVal _v1425 = $2124;
                      
                      return findField.apply(_v1425);
                    }
                    }
                }
                }
                }
                }
                }
                }
                default: {ESLVal t = $2123;
                  
                  {ESLVal _v1426 = $2124;
                  
                  return findField.apply(_v1426);
                }
                }
              }
              }
            else if(_v1112.isNil())
              return error(new ESLVal("TypeError",l,new ESLVal("cannot find field name ").add(n)));
            else return error(new ESLVal("case error at Pos(44766,44974)").add(ESLVal.list(_v1112)));
            }
          }
        });
      ESLVal exportsObserve = new ESLVal(new Function(new ESLVal("exportsObserve"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal exports = $args[0];
        {ESLVal _v1113 = exports;
              
              if(_v1113.isCons())
              {ESLVal $2129 = _v1113.head();
                ESLVal $2130 = _v1113.tail();
                
                switch($2129.termName) {
                case "Dec": {ESLVal $2134 = $2129.termRef(0);
                  ESLVal $2133 = $2129.termRef(1);
                  ESLVal $2132 = $2129.termRef(2);
                  ESLVal $2131 = $2129.termRef(3);
                  
                  switch($2133.strVal) {
                  case "observeState": switch($2132.termName) {
                    case "FunType": {ESLVal $2137 = $2132.termRef(0);
                      ESLVal $2136 = $2132.termRef(1);
                      ESLVal $2135 = $2132.termRef(2);
                      
                      if($2136.isCons())
                      {ESLVal $2138 = $2136.head();
                        ESLVal $2139 = $2136.tail();
                        
                        {ESLVal d = $2129;
                        
                        {ESLVal _v1417 = $2130;
                        
                        return exportsObserve.apply(_v1417);
                      }
                      }
                      }
                    else if($2136.isNil())
                      {ESLVal dl = $2134;
                        
                        {ESLVal fl = $2137;
                        
                        {ESLVal stateType = $2135;
                        
                        {ESLVal dt = $2131;
                        
                        {ESLVal x = $2130;
                        
                        return $true;
                      }
                      }
                      }
                      }
                      }
                    else {ESLVal d = $2129;
                        
                        {ESLVal _v1418 = $2130;
                        
                        return exportsObserve.apply(_v1418);
                      }
                      }
                    }
                    default: {ESLVal d = $2129;
                      
                      {ESLVal _v1419 = $2130;
                      
                      return exportsObserve.apply(_v1419);
                    }
                    }
                  }
                  default: {ESLVal d = $2129;
                    
                    {ESLVal _v1420 = $2130;
                    
                    return exportsObserve.apply(_v1420);
                  }
                  }
                }
                }
                default: {ESLVal d = $2129;
                  
                  {ESLVal _v1421 = $2130;
                  
                  return exportsObserve.apply(_v1421);
                }
                }
              }
              }
            else if(_v1113.isNil())
              return $false;
            else return error(new ESLVal("case error at Pos(45025,45184)").add(ESLVal.list(_v1113)));
            }
          }
        });
      ESLVal getObserver = new ESLVal(new Function(new ESLVal("getObserver"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1406 = $args[0];
        ESLVal _v1407 = $args[1];
        ESLVal _v1408 = $args[2];
        {ESLVal _v1114 = _v1407;
              
              return $ndCase.apply(_v1114,ESLVal.list(new ESLVal("$selectMid",new ESLVal(new Function(new ESLVal("add"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $2141 = $args[0];
              ESLVal $2142 = $args[1];
              ESLVal $2143 = $args[2];
              ESLVal $2140 = $args[3];
              switch($2142.termName) {
                    case "Dec": {ESLVal $2147 = $2142.termRef(0);
                      ESLVal $2146 = $2142.termRef(1);
                      ESLVal $2145 = $2142.termRef(2);
                      ESLVal $2144 = $2142.termRef(3);
                      
                      switch($2146.strVal) {
                      case "observeState": switch($2145.termName) {
                        case "FunType": {ESLVal $2150 = $2145.termRef(0);
                          ESLVal $2149 = $2145.termRef(1);
                          ESLVal $2148 = $2145.termRef(2);
                          
                          if($2149.isCons())
                          {ESLVal $2151 = $2149.head();
                            ESLVal $2152 = $2149.tail();
                            
                            return $2140.apply();
                          }
                        else if($2149.isNil())
                          {ESLVal e1 = $2141;
                            
                            {ESLVal dl = $2147;
                            
                            {ESLVal fl = $2150;
                            
                            {ESLVal stateType = $2148;
                            
                            {ESLVal dt = $2144;
                            
                            {ESLVal e2 = $2143;
                            
                            {ESLVal _v1115 = _v1407;
                            
                            return $ndCase.apply(_v1115,ESLVal.list(new ESLVal("$selectMid",new ESLVal(new Function(new ESLVal("add"),getSelf()) {
                              public ESLVal apply(ESLVal... $args) {
                                ESLVal $2154 = $args[0];
                            ESLVal $2155 = $args[1];
                            ESLVal $2156 = $args[2];
                            ESLVal $2153 = $args[3];
                            switch($2155.termName) {
                                  case "Dec": {ESLVal $2160 = $2155.termRef(0);
                                    ESLVal $2159 = $2155.termRef(1);
                                    ESLVal $2158 = $2155.termRef(2);
                                    ESLVal $2157 = $2155.termRef(3);
                                    
                                    switch($2159.strVal) {
                                    case "observeMessage": switch($2158.termName) {
                                      case "FunType": {ESLVal $2163 = $2158.termRef(0);
                                        ESLVal $2162 = $2158.termRef(1);
                                        ESLVal $2161 = $2158.termRef(2);
                                        
                                        if($2162.isCons())
                                        {ESLVal $2164 = $2162.head();
                                          ESLVal $2165 = $2162.tail();
                                          
                                          if($2165.isCons())
                                          {ESLVal $2166 = $2165.head();
                                            ESLVal $2167 = $2165.tail();
                                            
                                            return $2153.apply();
                                          }
                                        else if($2165.isNil())
                                          {ESLVal _v1409 = $2154;
                                            
                                            {ESLVal _v1410 = $2160;
                                            
                                            {ESLVal _v1411 = $2163;
                                            
                                            {ESLVal t = $2164;
                                            
                                            {ESLVal messageType = $2161;
                                            
                                            {ESLVal _v1412 = $2157;
                                            
                                            {ESLVal _v1413 = $2156;
                                            
                                            {ESLVal _v1116 = typeNF(messageType,typeEnv);
                                            
                                            switch(_v1116.termName) {
                                            case "UnionType": {ESLVal $2169 = _v1116.termRef(0);
                                              ESLVal $2168 = _v1116.termRef(1);
                                              
                                              return $ndCase.apply($2168,ESLVal.list(new ESLVal("$selectMid",new ESLVal(new Function(new ESLVal("add"),getSelf()) {
                                                public ESLVal apply(ESLVal... $args) {
                                                  ESLVal $2171 = $args[0];
                                              ESLVal $2172 = $args[1];
                                              ESLVal $2173 = $args[2];
                                              ESLVal $2170 = $args[3];
                                              switch($2172.termName) {
                                                    case "TermType": {ESLVal $2176 = $2172.termRef(0);
                                                      ESLVal $2175 = $2172.termRef(1);
                                                      ESLVal $2174 = $2172.termRef(2);
                                                      
                                                      switch($2175.strVal) {
                                                      case "Something": if($2174.isCons())
                                                        {ESLVal $2177 = $2174.head();
                                                          ESLVal $2178 = $2174.tail();
                                                          
                                                          if($2178.isCons())
                                                          {ESLVal $2179 = $2178.head();
                                                            ESLVal $2180 = $2178.tail();
                                                            
                                                            return $2170.apply();
                                                          }
                                                        else if($2178.isNil())
                                                          {ESLVal ul = $2169;
                                                            
                                                            {ESLVal ts1 = $2171;
                                                            
                                                            {ESLVal tl = $2176;
                                                            
                                                            {ESLVal _v1414 = $2177;
                                                            
                                                            {ESLVal ts2 = $2173;
                                                            
                                                            return new ESLVal("ObserverType",_v1406,stateType,_v1414);
                                                          }
                                                          }
                                                          }
                                                          }
                                                          }
                                                        else return $2170.apply();
                                                        }
                                                      else if($2174.isNil())
                                                        return $2170.apply();
                                                      else return $2170.apply();
                                                      default: return $2170.apply();
                                                    }
                                                    }
                                                    default: return $2170.apply();
                                                  }
                                                }
                                              }))),new ESLVal(new Function(new ESLVal("listFail"),getSelf()) {
                                                public ESLVal apply(ESLVal... $args) {
                                                  {ESLVal _v1415 = _v1116;
                                                    
                                                    return error(new ESLVal("TypeError",_v1406,new ESLVal("cannot find Something(t) for the message type: ").add(typeNF(messageType,typeEnv))));
                                                  }
                                                }
                                              }));
                                            }
                                            default: {ESLVal _v1416 = _v1116;
                                              
                                              return error(new ESLVal("TypeError",_v1406,new ESLVal("cannot find Something(t) for the message type: ").add(typeNF(messageType,typeEnv))));
                                            }
                                          }
                                          }
                                          }
                                          }
                                          }
                                          }
                                          }
                                          }
                                          }
                                        else return $2153.apply();
                                        }
                                      else if($2162.isNil())
                                        return $2153.apply();
                                      else return $2153.apply();
                                      }
                                      default: return $2153.apply();
                                    }
                                    default: return $2153.apply();
                                  }
                                  }
                                  default: return $2153.apply();
                                }
                              }
                            }))),new ESLVal(new Function(new ESLVal("listFail"),getSelf()) {
                              public ESLVal apply(ESLVal... $args) {
                                return error(new ESLVal("case error at Pos(45358,45780)").add(ESLVal.list(_v1115)));
                              }
                            }));
                          }
                          }
                          }
                          }
                          }
                          }
                          }
                        else return $2140.apply();
                        }
                        default: return $2140.apply();
                      }
                      default: return $2140.apply();
                    }
                    }
                    default: return $2140.apply();
                  }
                }
              }))),new ESLVal(new Function(new ESLVal("listFail"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  {ESLVal es = _v1114;
                    
                    return $null;
                  }
                }
              }));
            }
          }
        });
      
      public ESLVal get(String name) {
        switch(name) {
          case "t": return t;
          
          case "findExport": return findExport;
          
          case "findField": return findField;
          
          case "exportsObserve": return exportsObserve;
          
          case "getObserver": return getObserver;
          
          default: throw new Error("cannot find letrec binding");
        }
        }
      };
    ESLVal t = letrec.get("t");
    
    ESLVal findExport = letrec.get("findExport");
    
    ESLVal findField = letrec.get("findField");
    
    ESLVal exportsObserve = letrec.get("exportsObserve");
    
    ESLVal getObserver = letrec.get("getObserver");
    
      {ESLVal _v1117 = typeNF(t,typeEnv);
      
      switch(_v1117.termName) {
      case "StrType": {ESLVal $2194 = _v1117.termRef(0);
        
        {ESLVal sl = $2194;
        
        if(n.eql(new ESLVal("explode")).boolVal)
        return new ESLVal("ListType",sl,new ESLVal("IntType",sl));
        else
          {ESLVal _v1453 = $2194;
            
            if(n.eql(new ESLVal("writeDate")).boolVal)
            return theTypeFloat;
            else
              {ESLVal _v1454 = _v1117;
                
                return error(new ESLVal("TypeError",l,new ESLVal("expecting a record type, but received ").add(ppType(_v1454,typeEnv))));
              }
          }
      }
      }
    case "TableType": {ESLVal $2193 = _v1117.termRef(0);
        ESLVal $2192 = _v1117.termRef(1);
        ESLVal $2191 = _v1117.termRef(2);
        
        {ESLVal _v1436 = $2193;
        
        {ESLVal k = $2192;
        
        {ESLVal v = $2191;
        
        if(n.eql(new ESLVal("get")).boolVal)
        return new ESLVal("FunType",_v1436,ESLVal.list(k),v);
        else
          {ESLVal _v1437 = $2193;
            
            {ESLVal _v1438 = $2192;
            
            {ESLVal _v1439 = $2191;
            
            if(n.eql(new ESLVal("put")).boolVal)
            return new ESLVal("FunType",_v1437,ESLVal.list(_v1438,_v1439),t);
            else
              {ESLVal _v1440 = $2193;
                
                {ESLVal _v1441 = $2192;
                
                {ESLVal _v1442 = $2191;
                
                if(n.eql(new ESLVal("keys")).boolVal)
                return new ESLVal("ListType",_v1440,_v1441);
                else
                  {ESLVal _v1443 = $2193;
                    
                    {ESLVal _v1444 = $2192;
                    
                    {ESLVal _v1445 = $2191;
                    
                    if(n.eql(new ESLVal("vals")).boolVal)
                    return new ESLVal("ListType",_v1443,_v1445);
                    else
                      {ESLVal _v1446 = $2193;
                        
                        {ESLVal _v1447 = $2192;
                        
                        {ESLVal _v1448 = $2191;
                        
                        if(n.eql(new ESLVal("hasKey")).boolVal)
                        return new ESLVal("FunType",_v1446,ESLVal.list(_v1447),theTypeBool);
                        else
                          {ESLVal _v1449 = $2193;
                            
                            {ESLVal _v1450 = $2192;
                            
                            {ESLVal _v1451 = $2191;
                            
                            if(n.eql(new ESLVal("clear")).boolVal)
                            return new ESLVal("FunType",_v1449,$nil,theTypeVoid);
                            else
                              {ESLVal _v1452 = _v1117;
                                
                                return error(new ESLVal("TypeError",_v1449,new ESLVal("expecting a record type, but received ").add(ppType(_v1452,typeEnv))));
                              }
                          }
                          }
                          }
                      }
                      }
                      }
                  }
                  }
                  }
              }
              }
              }
          }
          }
          }
      }
      }
      }
      }
    case "ListType": {ESLVal $2190 = _v1117.termRef(0);
        ESLVal $2189 = _v1117.termRef(1);
        
        {ESLVal ll = $2190;
        
        {ESLVal _v1434 = $2189;
        
        if(n.eql(new ESLVal("implode")).boolVal)
        return theTypeStr;
        else
          {ESLVal _v1435 = _v1117;
            
            return error(new ESLVal("TypeError",l,new ESLVal("expecting a record type, but received ").add(ppType(_v1435,typeEnv))));
          }
      }
      }
      }
    case "RecordType": {ESLVal $2188 = _v1117.termRef(0);
        ESLVal $2187 = _v1117.termRef(1);
        
        {ESLVal rl = $2188;
        
        {ESLVal fs = $2187;
        
        return findField.apply(fs);
      }
      }
      }
    case "ObservedType": {ESLVal $2186 = _v1117.termRef(0);
        ESLVal $2185 = _v1117.termRef(1);
        ESLVal $2184 = _v1117.termRef(2);
        
        {ESLVal _v1432 = $2186;
        
        {ESLVal s = $2185;
        
        {ESLVal m = $2184;
        
        if(n.eql(new ESLVal("addObserver")).boolVal)
        return new ESLVal("FunType",_v1432,ESLVal.list(new ESLVal("ObserverType",_v1432,s,m)),theTypeVoid);
        else
          {ESLVal _v1433 = _v1117;
            
            return error(new ESLVal("TypeError",_v1432,new ESLVal("expecting a record type, but received ").add(ppType(_v1433,typeEnv))));
          }
      }
      }
      }
      }
    case "ActType": {ESLVal $2183 = _v1117.termRef(0);
        ESLVal $2182 = _v1117.termRef(1);
        ESLVal $2181 = _v1117.termRef(2);
        
        {ESLVal al = $2183;
        
        {ESLVal exports = $2182;
        
        {ESLVal handlers = $2181;
        
        if(n.eql(new ESLVal("addObserver")).and(exportsObserve.apply(exports)).boolVal)
        return new ESLVal("FunType",l,ESLVal.list(getObserver.apply(al,exports,handlers)),theTypeVoid);
        else
          {ESLVal _v1431 = findExport.apply(exports);
            
            if(_v1431.eql($null).boolVal)
            return error(new ESLVal("TypeError",l,new ESLVal("behaviour type does not export ").add(n)));
            else
              return substTypeEnv.apply(typeEnv,_v1431);
          }
      }
      }
      }
      }
      default: {ESLVal _v1455 = _v1117;
        
        return error(new ESLVal("TypeError",l,new ESLVal("expecting a record type, but received ").add(ppType(_v1455,typeEnv))));
      }
    }
    }}
    
  }
  private static ESLVal refType = new ESLVal(new Function(new ESLVal("refType"),null) { public ESLVal apply(ESLVal... args) { return refType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal derefType(ESLVal t) {
    
    {ESLVal _v1118 = t;
      
      switch(_v1118.termName) {
      case "TypeClosure": {ESLVal $2195 = _v1118.termRef(0);
        
        {ESLVal f = $2195;
        
        return derefType(f.apply());
      }
      }
      default: {ESLVal _v1405 = _v1118;
        
        return _v1405;
      }
    }
    }
  }
  private static ESLVal derefType = new ESLVal(new Function(new ESLVal("derefType"),null) { public ESLVal apply(ESLVal... args) { return derefType(args[0]); }});
  private static ESLVal recordType(ESLVal l,ESLVal fields,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    { LetRec letrec = new LetRec() {
      ESLVal fieldTypes = new ESLVal(new Function(new ESLVal("fieldTypes"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1399 = $args[0];
        {ESLVal _v1119 = _v1399;
              
              if(_v1119.isCons())
              {ESLVal $2196 = _v1119.head();
                ESLVal $2197 = _v1119.tail();
                
                switch($2196.termName) {
                case "Binding": {ESLVal $2202 = $2196.termRef(0);
                  ESLVal $2201 = $2196.termRef(1);
                  ESLVal $2200 = $2196.termRef(2);
                  ESLVal $2199 = $2196.termRef(3);
                  ESLVal $2198 = $2196.termRef(4);
                  
                  {ESLVal _v1400 = $2202;
                  
                  {ESLVal n = $2201;
                  
                  {ESLVal t = $2200;
                  
                  {ESLVal st = $2199;
                  
                  {ESLVal e = $2198;
                  
                  {ESLVal _v1401 = $2197;
                  
                  {ESLVal _v1402 = expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
                  
                  return fieldTypes.apply(_v1401).cons(new ESLVal("Dec",_v1400,n,_v1402,_v1402));
                }
                }
                }
                }
                }
                }
                }
                }
                default: {ESLVal _v1403 = _v1119;
                  
                  return error(new ESLVal("TypeError",l,new ESLVal("unknown field representation: ").add(_v1403)));
                }
              }
              }
            else if(_v1119.isNil())
              return $nil;
            else {ESLVal _v1404 = _v1119;
                
                return error(new ESLVal("TypeError",l,new ESLVal("unknown field representation: ").add(_v1404)));
              }
            }
          }
        });
      
      public ESLVal get(String name) {
        switch(name) {
          case "fieldTypes": return fieldTypes;
          
          default: throw new Error("cannot find letrec binding");
        }
        }
      };
    ESLVal fieldTypes = letrec.get("fieldTypes");
    
      return new ESLVal("RecordType",l,fieldTypes.apply(fields));}
    
  }
  private static ESLVal recordType = new ESLVal(new Function(new ESLVal("recordType"),null) { public ESLVal apply(ESLVal... args) { return recordType(args[0],args[1],args[2],args[3],args[4],args[5]); }});
  private static ESLVal forType(ESLVal l,ESLVal p,ESLVal list,ESLVal body,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal listType = expType(list,selfType,valueEnv,cnstrEnv,typeEnv);
      
      {ESLVal _v1120 = listType;
      
      switch(_v1120.termName) {
      case "ListType": {ESLVal $2204 = _v1120.termRef(0);
        ESLVal $2203 = _v1120.termRef(1);
        
        {ESLVal _v1396 = $2204;
        
        {ESLVal t = $2203;
        
        return patternType(_v1396,p,t,selfType,valueEnv,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun399"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1397 = $args[0];
        ESLVal _v1398 = $args[1];
        return expType(body,selfType,_v1398,cnstrEnv,typeEnv);
          }
        }));
      }
      }
      }
      default: {ESLVal t = _v1120;
        
        return error(new ESLVal("TypeError",l,new ESLVal("for type expects a list: ").add(list)));
      }
    }
    }
    }
  }
  private static ESLVal forType = new ESLVal(new Function(new ESLVal("forType"),null) { public ESLVal apply(ESLVal... args) { return forType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7]); }});
  private static ESLVal patternTypes(ESLVal l,ESLVal ps,ESLVal ts,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv,ESLVal f) {
    
    {ESLVal _v1121 = ps;
      ESLVal _v1122 = ts;
      
      if(_v1121.isCons())
      {ESLVal $2205 = _v1121.head();
        ESLVal $2206 = _v1121.tail();
        
        if(_v1122.isCons())
        {ESLVal $2207 = _v1122.head();
          ESLVal $2208 = _v1122.tail();
          
          {ESLVal p = $2205;
          
          {ESLVal _v1378 = $2206;
          
          {ESLVal t = $2207;
          
          {ESLVal _v1379 = $2208;
          
          {ESLVal _v1380 = _v1378;
          ESLVal _v1381 = _v1379;
          
          return patternType(l,p,t,selfType,valueEnv,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun400"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1382 = $args[0];
          ESLVal _v1383 = $args[1];
          return patternTypes(l,_v1380,_v1381,selfType,_v1383,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun401"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal _v1384 = $args[0];
                ESLVal _v1385 = $args[1];
                return f.apply(_v1384.cons(_v1382),_v1385);
                  }
                }));
            }
          }));
        }
        }
        }
        }
        }
        }
      else if(_v1122.isNil())
        {ESLVal _v1386 = _v1121;
          
          {ESLVal _v1387 = _v1122;
          
          return error(new ESLVal("TypeError",l,new ESLVal("somthing wrong with ").add(_v1386.add(new ESLVal(" ").add(_v1387)))));
        }
        }
      else {ESLVal _v1388 = _v1121;
          
          {ESLVal _v1389 = _v1122;
          
          return error(new ESLVal("TypeError",l,new ESLVal("somthing wrong with ").add(_v1388.add(new ESLVal(" ").add(_v1389)))));
        }
        }
      }
    else if(_v1121.isNil())
      if(_v1122.isCons())
        {ESLVal $2209 = _v1122.head();
          ESLVal $2210 = _v1122.tail();
          
          {ESLVal _v1390 = _v1121;
          
          {ESLVal _v1391 = _v1122;
          
          return error(new ESLVal("TypeError",l,new ESLVal("somthing wrong with ").add(_v1390.add(new ESLVal(" ").add(_v1391)))));
        }
        }
        }
      else if(_v1122.isNil())
        return f.apply($nil,valueEnv);
      else {ESLVal _v1392 = _v1121;
          
          {ESLVal _v1393 = _v1122;
          
          return error(new ESLVal("TypeError",l,new ESLVal("somthing wrong with ").add(_v1392.add(new ESLVal(" ").add(_v1393)))));
        }
        }
    else {ESLVal _v1394 = _v1121;
        
        {ESLVal _v1395 = _v1122;
        
        return error(new ESLVal("TypeError",l,new ESLVal("somthing wrong with ").add(_v1394.add(new ESLVal(" ").add(_v1395)))));
      }
      }
    }
  }
  private static ESLVal patternTypes = new ESLVal(new Function(new ESLVal("patternTypes"),null) { public ESLVal apply(ESLVal... args) { return patternTypes(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7]); }});
  private static ESLVal getPatternType(ESLVal l,ESLVal p,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal _v1123 = p;
      
      switch(_v1123.termName) {
      case "PApplyType": {ESLVal $2239 = _v1123.termRef(0);
        ESLVal $2238 = _v1123.termRef(1);
        ESLVal $2237 = _v1123.termRef(2);
        
        {ESLVal _v1375 = $2239;
        
        {ESLVal _v1376 = $2238;
        
        {ESLVal args = $2237;
        
        return error(new ESLVal("should this happen?"));
      }
      }
      }
      }
    case "PBool": {ESLVal $2236 = _v1123.termRef(0);
        ESLVal $2235 = _v1123.termRef(1);
        
        {ESLVal _v1374 = $2236;
        
        {ESLVal b = $2235;
        
        return theTypeBool;
      }
      }
      }
    case "PCons": {ESLVal $2234 = _v1123.termRef(0);
        ESLVal $2233 = _v1123.termRef(1);
        ESLVal $2232 = _v1123.termRef(2);
        
        {ESLVal _v1373 = $2234;
        
        {ESLVal hd = $2233;
        
        {ESLVal tl = $2232;
        
        return getPatternType(_v1373,tl,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "PBagCons": {ESLVal $2231 = _v1123.termRef(0);
        ESLVal $2230 = _v1123.termRef(1);
        ESLVal $2229 = _v1123.termRef(2);
        
        {ESLVal _v1372 = $2231;
        
        {ESLVal hd = $2230;
        
        {ESLVal tl = $2229;
        
        return getPatternType(_v1372,tl,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "PSetCons": {ESLVal $2228 = _v1123.termRef(0);
        ESLVal $2227 = _v1123.termRef(1);
        ESLVal $2226 = _v1123.termRef(2);
        
        {ESLVal _v1371 = $2228;
        
        {ESLVal hd = $2227;
        
        {ESLVal tl = $2226;
        
        return getPatternType(_v1371,tl,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "PNil": {ESLVal $2225 = _v1123.termRef(0);
        
        {ESLVal _v1370 = $2225;
        
        return new ESLVal("ForallType",_v1370,ESLVal.list(new ESLVal("T")),new ESLVal("ListType",_v1370,new ESLVal("VarType",_v1370,new ESLVal("T"))));
      }
      }
    case "PNull": {ESLVal $2224 = _v1123.termRef(0);
        
        {ESLVal _v1369 = $2224;
        
        return new ESLVal("ForallType",_v1369,ESLVal.list(new ESLVal("T")),new ESLVal("VarType",_v1369,new ESLVal("T")));
      }
      }
    case "PEmptyBag": {ESLVal $2223 = _v1123.termRef(0);
        
        {ESLVal _v1368 = $2223;
        
        return new ESLVal("ForallType",_v1368,ESLVal.list(new ESLVal("T")),new ESLVal("BagType",_v1368,new ESLVal("VarType",_v1368,new ESLVal("T"))));
      }
      }
    case "PEmptySet": {ESLVal $2222 = _v1123.termRef(0);
        
        {ESLVal _v1367 = $2222;
        
        return new ESLVal("ForallType",_v1367,ESLVal.list(new ESLVal("T")),new ESLVal("SetType",_v1367,new ESLVal("VarType",_v1367,new ESLVal("T"))));
      }
      }
    case "PInt": {ESLVal $2221 = _v1123.termRef(0);
        ESLVal $2220 = _v1123.termRef(1);
        
        {ESLVal _v1366 = $2221;
        
        {ESLVal n = $2220;
        
        return theTypeInt;
      }
      }
      }
    case "PVar": {ESLVal $2219 = _v1123.termRef(0);
        ESLVal $2218 = _v1123.termRef(1);
        ESLVal $2217 = _v1123.termRef(2);
        
        {ESLVal _v1365 = $2219;
        
        {ESLVal n = $2218;
        
        {ESLVal pt = $2217;
        
        return substTypeEnv.apply(typeEnv,pt);
      }
      }
      }
      }
    case "PStr": {ESLVal $2216 = _v1123.termRef(0);
        ESLVal $2215 = _v1123.termRef(1);
        
        {ESLVal _v1364 = $2216;
        
        {ESLVal s = $2215;
        
        return theTypeStr;
      }
      }
      }
    case "PTerm": {ESLVal $2214 = _v1123.termRef(0);
        ESLVal $2213 = _v1123.termRef(1);
        ESLVal $2212 = _v1123.termRef(2);
        ESLVal $2211 = _v1123.termRef(3);
        
        {ESLVal _v1363 = $2214;
        
        {ESLVal n = $2213;
        
        {ESLVal ts = $2212;
        
        {ESLVal ps = $2211;
        
        return lookupType.apply(n,cnstrEnv);
      }
      }
      }
      }
      }
      default: {ESLVal _v1377 = _v1123;
        
        return error(new ESLVal("TypeError",l,new ESLVal("unknown type of pattern: ").add(_v1377)));
      }
    }
    }
  }
  private static ESLVal getPatternType = new ESLVal(new Function(new ESLVal("getPatternType"),null) { public ESLVal apply(ESLVal... args) { return getPatternType(args[0],args[1],args[2],args[3],args[4],args[5]); }});
  private static ESLVal patternType(ESLVal l,ESLVal p,ESLVal t,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv,ESLVal f) {
    
    {ESLVal _v1124 = p;
      
      switch(_v1124.termName) {
      case "PAdd": {ESLVal $2271 = _v1124.termRef(0);
        ESLVal $2270 = _v1124.termRef(1);
        ESLVal $2269 = _v1124.termRef(2);
        
        {ESLVal _v1361 = $2271;
        
        {ESLVal p1 = $2270;
        
        {ESLVal p2 = $2269;
        
        return addPatternType(_v1361,p1,p2,t,selfType,valueEnv,cnstrEnv,typeEnv,f);
      }
      }
      }
      }
    case "PApplyType": {ESLVal $2268 = _v1124.termRef(0);
        ESLVal $2267 = _v1124.termRef(1);
        ESLVal $2266 = _v1124.termRef(2);
        
        {ESLVal _v1359 = $2268;
        
        {ESLVal _v1360 = $2267;
        
        {ESLVal args = $2266;
        
        return applyTypePatternType(_v1359,_v1360,substTypesEnv.apply(typeEnv,args),t,selfType,valueEnv,cnstrEnv,typeEnv,f);
      }
      }
      }
      }
    case "PBool": {ESLVal $2265 = _v1124.termRef(0);
        ESLVal $2264 = _v1124.termRef(1);
        
        {ESLVal _v1358 = $2265;
        
        {ESLVal b = $2264;
        
        if(isBoolType.apply(t).boolVal)
        return f.apply(theTypeBool,valueEnv);
        else
          return error(new ESLVal("TypeError",_v1358,new ESLVal("type mismatch: Bool and ").add(ppType(t,typeEnv))));
      }
      }
      }
    case "PBagCons": {ESLVal $2263 = _v1124.termRef(0);
        ESLVal $2262 = _v1124.termRef(1);
        ESLVal $2261 = _v1124.termRef(2);
        
        {ESLVal _v1355 = $2263;
        
        {ESLVal hd = $2262;
        
        {ESLVal tl = $2261;
        
        return bagConsPatternType(_v1355,hd,tl,t,selfType,valueEnv,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun402"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1356 = $args[0];
        ESLVal _v1357 = $args[1];
        return f.apply(new ESLVal("ListType",_v1355,_v1356),_v1357);
          }
        }));
      }
      }
      }
      }
    case "PSetCons": {ESLVal $2260 = _v1124.termRef(0);
        ESLVal $2259 = _v1124.termRef(1);
        ESLVal $2258 = _v1124.termRef(2);
        
        {ESLVal _v1352 = $2260;
        
        {ESLVal hd = $2259;
        
        {ESLVal tl = $2258;
        
        return setConsPatternType(_v1352,hd,tl,t,selfType,valueEnv,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun403"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1353 = $args[0];
        ESLVal _v1354 = $args[1];
        return f.apply(new ESLVal("ListType",_v1352,_v1353),_v1354);
          }
        }));
      }
      }
      }
      }
    case "PCons": {ESLVal $2257 = _v1124.termRef(0);
        ESLVal $2256 = _v1124.termRef(1);
        ESLVal $2255 = _v1124.termRef(2);
        
        {ESLVal _v1349 = $2257;
        
        {ESLVal hd = $2256;
        
        {ESLVal tl = $2255;
        
        return consPatternType(_v1349,hd,tl,t,selfType,valueEnv,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun404"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1350 = $args[0];
        ESLVal _v1351 = $args[1];
        return f.apply(new ESLVal("ListType",_v1349,_v1350),_v1351);
          }
        }));
      }
      }
      }
      }
    case "PNil": {ESLVal $2254 = _v1124.termRef(0);
        
        {ESLVal _v1348 = $2254;
        
        return nilType(_v1348,t,selfType,valueEnv,cnstrEnv,typeEnv,f);
      }
      }
    case "PNull": {ESLVal $2253 = _v1124.termRef(0);
        
        {ESLVal _v1347 = $2253;
        
        return f.apply(t,valueEnv);
      }
      }
    case "PEmptyBag": {ESLVal $2252 = _v1124.termRef(0);
        
        {ESLVal _v1346 = $2252;
        
        return emptyBagType(_v1346,t,selfType,valueEnv,cnstrEnv,typeEnv,f);
      }
      }
    case "PEmptySet": {ESLVal $2251 = _v1124.termRef(0);
        
        {ESLVal _v1345 = $2251;
        
        return emptySetType(_v1345,t,selfType,valueEnv,cnstrEnv,typeEnv,f);
      }
      }
    case "PInt": {ESLVal $2250 = _v1124.termRef(0);
        ESLVal $2249 = _v1124.termRef(1);
        
        {ESLVal _v1344 = $2250;
        
        {ESLVal n = $2249;
        
        if(isIntType.apply(t).boolVal)
        return f.apply(theTypeInt,valueEnv);
        else
          return error(new ESLVal("TypeError",_v1344,new ESLVal("type mismatch: Int and ").add(ppType(t,typeEnv))));
      }
      }
      }
    case "PVar": {ESLVal $2248 = _v1124.termRef(0);
        ESLVal $2247 = _v1124.termRef(1);
        ESLVal $2246 = _v1124.termRef(2);
        
        {ESLVal _v1343 = $2248;
        
        {ESLVal n = $2247;
        
        {ESLVal pt = $2246;
        
        return f.apply(t,ESLVal.list(new ESLVal("Map",n,t)).add(valueEnv));
      }
      }
      }
      }
    case "PStr": {ESLVal $2245 = _v1124.termRef(0);
        ESLVal $2244 = _v1124.termRef(1);
        
        {ESLVal _v1342 = $2245;
        
        {ESLVal s = $2244;
        
        if(isStrType.apply(t).boolVal)
        return f.apply(theTypeStr,valueEnv);
        else
          return error(new ESLVal("TypeError",_v1342,new ESLVal("type mismatch: Str and ").add(ppType(t,typeEnv))));
      }
      }
      }
    case "PTerm": {ESLVal $2243 = _v1124.termRef(0);
        ESLVal $2242 = _v1124.termRef(1);
        ESLVal $2241 = _v1124.termRef(2);
        ESLVal $2240 = _v1124.termRef(3);
        
        {ESLVal _v1341 = $2243;
        
        {ESLVal n = $2242;
        
        {ESLVal ts = $2241;
        
        {ESLVal ps = $2240;
        
        return termPatternType(_v1341,n,substTypesEnv.apply(typeEnv,ts),ps,t,selfType,valueEnv,cnstrEnv,typeEnv,f);
      }
      }
      }
      }
      }
      default: {ESLVal _v1362 = _v1124;
        
        return error(new ESLVal("TypeError",l,new ESLVal("unknown type of pattern: ").add(_v1362)));
      }
    }
    }
  }
  private static ESLVal patternType = new ESLVal(new Function(new ESLVal("patternType"),null) { public ESLVal apply(ESLVal... args) { return patternType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7]); }});
  private static ESLVal addPatternType(ESLVal l,ESLVal p1,ESLVal p2,ESLVal valueType,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv,ESLVal f) {
    
    return patternType(l,p1,valueType,selfType,valueEnv,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun405"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal _v1312 = $args[0];
      ESLVal _v1313 = $args[1];
      return patternType(l,p2,valueType,selfType,_v1313,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun406"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v1314 = $args[0];
            ESLVal _v1315 = $args[1];
            {ESLVal _v1125 = valueType;
                  
                  switch(_v1125.termName) {
                  case "ListType": {ESLVal $2274 = _v1125.termRef(0);
                    ESLVal $2273 = _v1125.termRef(1);
                    
                    {ESLVal tl = $2274;
                    
                    {ESLVal t = $2273;
                    
                    {ESLVal _v1126 = p1;
                    ESLVal _v1127 = p2;
                    
                    switch(_v1126.termName) {
                    case "PCons": {ESLVal $2307 = _v1126.termRef(0);
                      ESLVal $2306 = _v1126.termRef(1);
                      ESLVal $2305 = _v1126.termRef(2);
                      
                      switch($2305.termName) {
                      case "PNil": {ESLVal $2308 = $2305.termRef(0);
                        
                        switch(_v1127.termName) {
                        case "PVar": {ESLVal $2311 = _v1127.termRef(0);
                          ESLVal $2310 = _v1127.termRef(1);
                          ESLVal $2309 = _v1127.termRef(2);
                          
                          {ESLVal l1 = $2307;
                          
                          {ESLVal p = $2306;
                          
                          {ESLVal l3 = $2308;
                          
                          {ESLVal l4 = $2311;
                          
                          {ESLVal n2 = $2310;
                          
                          {ESLVal t2 = $2309;
                          
                          return f.apply(valueType,_v1315);
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal _v1335 = _v1126;
                          
                          {ESLVal _v1336 = _v1127;
                          
                          return error(new ESLVal("TypeError",l,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                        }
                        }
                      }
                      }
                      default: {ESLVal _v1337 = _v1126;
                        
                        {ESLVal _v1338 = _v1127;
                        
                        return error(new ESLVal("TypeError",l,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                      }
                      }
                    }
                    }
                  case "PVar": {ESLVal $2290 = _v1126.termRef(0);
                      ESLVal $2289 = _v1126.termRef(1);
                      ESLVal $2288 = _v1126.termRef(2);
                      
                      switch(_v1127.termName) {
                      case "PCons": {ESLVal $2303 = _v1127.termRef(0);
                        ESLVal $2302 = _v1127.termRef(1);
                        ESLVal $2301 = _v1127.termRef(2);
                        
                        switch($2301.termName) {
                        case "PNil": {ESLVal $2304 = $2301.termRef(0);
                          
                          {ESLVal l1 = $2290;
                          
                          {ESLVal n = $2289;
                          
                          {ESLVal _v1330 = $2288;
                          
                          {ESLVal l2 = $2303;
                          
                          {ESLVal p = $2302;
                          
                          {ESLVal l3 = $2304;
                          
                          return f.apply(valueType,_v1315);
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal _v1331 = _v1126;
                          
                          {ESLVal _v1332 = _v1127;
                          
                          return error(new ESLVal("TypeError",l,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                        }
                        }
                      }
                      }
                    case "PAdd": {ESLVal $2293 = _v1127.termRef(0);
                        ESLVal $2292 = _v1127.termRef(1);
                        ESLVal $2291 = _v1127.termRef(2);
                        
                        switch($2292.termName) {
                        case "PCons": {ESLVal $2296 = $2292.termRef(0);
                          ESLVal $2295 = $2292.termRef(1);
                          ESLVal $2294 = $2292.termRef(2);
                          
                          switch($2294.termName) {
                          case "PNil": {ESLVal $2297 = $2294.termRef(0);
                            
                            switch($2291.termName) {
                            case "PVar": {ESLVal $2300 = $2291.termRef(0);
                              ESLVal $2299 = $2291.termRef(1);
                              ESLVal $2298 = $2291.termRef(2);
                              
                              {ESLVal l1 = $2290;
                              
                              {ESLVal n1 = $2289;
                              
                              {ESLVal t1 = $2288;
                              
                              {ESLVal l2 = $2293;
                              
                              {ESLVal l3 = $2296;
                              
                              {ESLVal p = $2295;
                              
                              {ESLVal l5 = $2297;
                              
                              {ESLVal l6 = $2300;
                              
                              {ESLVal n3 = $2299;
                              
                              {ESLVal t3 = $2298;
                              
                              return f.apply(valueType,_v1315);
                            }
                            }
                            }
                            }
                            }
                            }
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v1324 = _v1126;
                              
                              {ESLVal _v1325 = _v1127;
                              
                              return error(new ESLVal("TypeError",l,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                            }
                            }
                          }
                          }
                          default: {ESLVal _v1326 = _v1126;
                            
                            {ESLVal _v1327 = _v1127;
                            
                            return error(new ESLVal("TypeError",l,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                          }
                          }
                        }
                        }
                        default: {ESLVal _v1328 = _v1126;
                          
                          {ESLVal _v1329 = _v1127;
                          
                          return error(new ESLVal("TypeError",l,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                        }
                        }
                      }
                      }
                      default: {ESLVal _v1333 = _v1126;
                        
                        {ESLVal _v1334 = _v1127;
                        
                        return error(new ESLVal("TypeError",l,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                      }
                      }
                    }
                    }
                  case "PAdd": {ESLVal $2277 = _v1126.termRef(0);
                      ESLVal $2276 = _v1126.termRef(1);
                      ESLVal $2275 = _v1126.termRef(2);
                      
                      switch($2276.termName) {
                      case "PVar": {ESLVal $2280 = $2276.termRef(0);
                        ESLVal $2279 = $2276.termRef(1);
                        ESLVal $2278 = $2276.termRef(2);
                        
                        switch($2275.termName) {
                        case "PCons": {ESLVal $2283 = $2275.termRef(0);
                          ESLVal $2282 = $2275.termRef(1);
                          ESLVal $2281 = $2275.termRef(2);
                          
                          switch($2281.termName) {
                          case "PNil": {ESLVal $2284 = $2281.termRef(0);
                            
                            switch(_v1127.termName) {
                            case "PVar": {ESLVal $2287 = _v1127.termRef(0);
                              ESLVal $2286 = _v1127.termRef(1);
                              ESLVal $2285 = _v1127.termRef(2);
                              
                              {ESLVal l1 = $2277;
                              
                              {ESLVal l2 = $2280;
                              
                              {ESLVal n1 = $2279;
                              
                              {ESLVal t1 = $2278;
                              
                              {ESLVal l3 = $2283;
                              
                              {ESLVal p = $2282;
                              
                              {ESLVal l5 = $2284;
                              
                              {ESLVal l6 = $2287;
                              
                              {ESLVal n3 = $2286;
                              
                              {ESLVal t3 = $2285;
                              
                              return f.apply(valueType,_v1315);
                            }
                            }
                            }
                            }
                            }
                            }
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v1316 = _v1126;
                              
                              {ESLVal _v1317 = _v1127;
                              
                              return error(new ESLVal("TypeError",l,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                            }
                            }
                          }
                          }
                          default: {ESLVal _v1318 = _v1126;
                            
                            {ESLVal _v1319 = _v1127;
                            
                            return error(new ESLVal("TypeError",l,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                          }
                          }
                        }
                        }
                        default: {ESLVal _v1320 = _v1126;
                          
                          {ESLVal _v1321 = _v1127;
                          
                          return error(new ESLVal("TypeError",l,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                        }
                        }
                      }
                      }
                      default: {ESLVal _v1322 = _v1126;
                        
                        {ESLVal _v1323 = _v1127;
                        
                        return error(new ESLVal("TypeError",l,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                      }
                      }
                    }
                    }
                    default: {ESLVal _v1339 = _v1126;
                      
                      {ESLVal _v1340 = _v1127;
                      
                      return error(new ESLVal("TypeError",l,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                    }
                    }
                  }
                  }
                  }
                  }
                  }
                case "TypeClosure": {ESLVal $2272 = _v1125.termRef(0);
                    
                    {ESLVal g = $2272;
                    
                    return addPatternType(l,p1,p2,g.apply(),selfType,_v1315,cnstrEnv,typeEnv,f);
                  }
                  }
                  default: {ESLVal t = _v1125;
                    
                    return error(new ESLVal("TypeError",l,new ESLVal("+ expects lists: ").add(ppType(valueType,typeEnv))));
                  }
                }
                }
              }
            }));
        }
      }));
  }
  private static ESLVal addPatternType = new ESLVal(new Function(new ESLVal("addPatternType"),null) { public ESLVal apply(ESLVal... args) { return addPatternType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7],args[8]); }});
  private static ESLVal applyTypePatternType(ESLVal l,ESLVal p,ESLVal args,ESLVal valueType,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv,ESLVal f) {
    
    return patternType(l,p,valueType,selfType,valueEnv,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun407"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal _v1308 = $args[0];
      ESLVal _v1309 = $args[1];
      {ESLVal _v1128 = typeNF(_v1308,typeEnv);
            
            switch(_v1128.termName) {
            case "TypeFun": {ESLVal $2317 = _v1128.termRef(0);
              ESLVal $2316 = _v1128.termRef(1);
              ESLVal $2315 = _v1128.termRef(2);
              
              {ESLVal fl = $2317;
              
              {ESLVal ns = $2316;
              
              {ESLVal t = $2315;
              
              if(length.apply(args).eql(length.apply(ns)).boolVal)
              {ESLVal _v1311 = substTypeEnv.apply(zipTypeEnv.apply(ns,args).add(typeEnv),t);
                
                if(typeEqual.apply(_v1311,valueType).boolVal)
                return f.apply(_v1311,_v1309);
                else
                  return error(new ESLVal("TypeError",l,new ESLVal("value type ").add(ppType(valueType,typeEnv).add(new ESLVal(" does not match pattern type ").add(ppType(_v1311,typeEnv).add(new ESLVal(" ").add(ppTypeEnv(typeEnv))))))));
              }
              else
                return error(new ESLVal("TypeError",l,new ESLVal("expecting ").add(length.apply(ns).add(new ESLVal(" args, but suplied with ").add(length.apply(args))))));
            }
            }
            }
            }
          case "ForallType": {ESLVal $2314 = _v1128.termRef(0);
              ESLVal $2313 = _v1128.termRef(1);
              ESLVal $2312 = _v1128.termRef(2);
              
              {ESLVal fl = $2314;
              
              {ESLVal ns = $2313;
              
              {ESLVal t = $2312;
              
              if(length.apply(args).eql(length.apply(ns)).boolVal)
              {ESLVal _v1310 = substTypeEnv.apply(zipTypeEnv.apply(ns,args).add(typeEnv),t);
                
                if(typeEqual.apply(_v1310,valueType).boolVal)
                return f.apply(_v1310,_v1309);
                else
                  return error(new ESLVal("TypeError",l,new ESLVal("value type ").add(ppType(valueType,typeEnv).add(new ESLVal(" does not match pattern type ").add(ppType(_v1310,typeEnv).add(new ESLVal(" ").add(ppTypeEnv(typeEnv))))))));
              }
              else
                return error(new ESLVal("TypeError",l,new ESLVal("expecting ").add(length.apply(ns).add(new ESLVal(" args, but suplied with ").add(length.apply(args))))));
            }
            }
            }
            }
            default: {ESLVal t = _v1128;
              
              return f.apply(t,_v1309);
            }
          }
          }
        }
      }));
  }
  private static ESLVal applyTypePatternType = new ESLVal(new Function(new ESLVal("applyTypePatternType"),null) { public ESLVal apply(ESLVal... args) { return applyTypePatternType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7],args[8]); }});
  private static ESLVal termPatternType(ESLVal l,ESLVal n,ESLVal genericArgs,ESLVal ps,ESLVal valueType,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv,ESLVal f) {
    
    {ESLVal patternType = getTermPatternType(l,n,genericArgs,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(typeEqual.apply(patternType,valueType).boolVal)
      {ESLVal _v1129 = typeNF(valueType,typeEnv);
        
        switch(_v1129.termName) {
        case "UnionType": {ESLVal $2319 = _v1129.termRef(0);
          ESLVal $2318 = _v1129.termRef(1);
          
          {ESLVal ul = $2319;
          
          {ESLVal cs = $2318;
          
          { LetRec letrec = new LetRec() {
          ESLVal getCnstrArgs = new ESLVal(new Function(new ESLVal("getCnstrArgs"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v1302 = $args[0];
            {ESLVal _v1130 = _v1302;
                  
                  if(_v1130.isCons())
                  {ESLVal $2320 = _v1130.head();
                    ESLVal $2321 = _v1130.tail();
                    
                    switch($2320.termName) {
                    case "TermType": {ESLVal $2324 = $2320.termRef(0);
                      ESLVal $2323 = $2320.termRef(1);
                      ESLVal $2322 = $2320.termRef(2);
                      
                      {ESLVal tl = $2324;
                      
                      {ESLVal m = $2323;
                      
                      {ESLVal args = $2322;
                      
                      {ESLVal _v1303 = $2321;
                      
                      if(m.eql(n).boolVal)
                      return args;
                      else
                        {ESLVal t = $2320;
                          
                          {ESLVal _v1304 = $2321;
                          
                          return getCnstrArgs.apply(_v1304);
                        }
                        }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal t = $2320;
                      
                      {ESLVal _v1305 = $2321;
                      
                      return getCnstrArgs.apply(_v1305);
                    }
                    }
                  }
                  }
                else if(_v1130.isNil())
                  return error(new ESLVal("TypeError",l,new ESLVal("cannot find constructor for ").add(n)));
                else return error(new ESLVal("case error at Pos(55274,55533)").add(ESLVal.list(_v1130)));
                }
              }
            });
          
          public ESLVal get(String name) {
            switch(name) {
              case "getCnstrArgs": return getCnstrArgs;
              
              default: throw new Error("cannot find letrec binding");
            }
            }
          };
        ESLVal getCnstrArgs = letrec.get("getCnstrArgs");
        
          {ESLVal argTypes = getCnstrArgs.apply(cs);
          
          if(length.apply(ps).eql(length.apply(argTypes)).boolVal)
          return patternTypes(l,ps,argTypes,selfType,valueEnv,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun408"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v1306 = $args[0];
            ESLVal _v1307 = $args[1];
            return f.apply(typeNF(valueType,typeEnv),_v1307);
              }
            }));
          else
            return error(new ESLVal("TypeError",l,new ESLVal("arity mismatch.")));
        }}
        
        }
        }
        }
        default: {ESLVal t = _v1129;
          
          return error(new ESLVal("TypeError",l,new ESLVal("expecting a data type: ").add(valueType)));
        }
      }
      }
      else
        return error(new ESLVal("TypeError",l,new ESLVal("term pattern type ").add(ppType(patternType,typeEnv).add(new ESLVal(" does not match supplied value type ").add(ppType(valueType,typeEnv))))));
    }
  }
  private static ESLVal termPatternType = new ESLVal(new Function(new ESLVal("termPatternType"),null) { public ESLVal apply(ESLVal... args) { return termPatternType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7],args[8],args[9]); }});
  private static ESLVal typeNF(ESLVal t,ESLVal typeEnv) {
    
    {ESLVal _v1131 = substTypeEnv.apply(typeEnv,t);
      
      switch(_v1131.termName) {
      case "ApplyTypeFun": {ESLVal $2335 = _v1131.termRef(0);
        ESLVal $2334 = _v1131.termRef(1);
        ESLVal $2333 = _v1131.termRef(2);
        
        {ESLVal l = $2335;
        
        {ESLVal op = $2334;
        
        {ESLVal args = $2333;
        
        {ESLVal _v1133 = typeNF(op,typeEnv);
        
        switch(_v1133.termName) {
        case "TypeFun": {ESLVal $2341 = _v1133.termRef(0);
          ESLVal $2340 = _v1133.termRef(1);
          ESLVal $2339 = _v1133.termRef(2);
          
          {ESLVal _v1298 = $2341;
          
          {ESLVal ns = $2340;
          
          {ESLVal _v1299 = $2339;
          
          if(length.apply(args).eql(length.apply(ns)).boolVal)
          return typeNF(substTypeEnv.apply(zipTypeEnv.apply(ns,args),_v1299),typeEnv);
          else
            return error(new ESLVal("TypeError",_v1298,new ESLVal("function arity error")));
        }
        }
        }
        }
        default: {ESLVal _v1300 = _v1133;
          
          return error(new ESLVal("TypeError",l,new ESLVal("expecting a type function: ").add(ppType(typeNF(op,typeEnv),typeEnv))));
        }
      }
      }
      }
      }
      }
      }
    case "TypeClosure": {ESLVal $2332 = _v1131.termRef(0);
        
        {ESLVal f = $2332;
        
        return typeNF(f.apply(),typeEnv);
      }
      }
    case "RecType": {ESLVal $2331 = _v1131.termRef(0);
        ESLVal $2330 = _v1131.termRef(1);
        ESLVal $2329 = _v1131.termRef(2);
        
        {ESLVal l = $2331;
        
        {ESLVal n = $2330;
        
        {ESLVal _v1297 = $2329;
        
        return typeNF(substType.apply(new ESLVal("RecType",l,n,_v1297),n,_v1297),typeEnv);
      }
      }
      }
      }
    case "ExtendedAct": {ESLVal $2328 = _v1131.termRef(0);
        ESLVal $2327 = _v1131.termRef(1);
        ESLVal $2326 = _v1131.termRef(2);
        ESLVal $2325 = _v1131.termRef(3);
        
        {ESLVal l1 = $2328;
        
        {ESLVal parent = $2327;
        
        {ESLVal decs1 = $2326;
        
        {ESLVal ms1 = $2325;
        
        {ESLVal _v1132 = typeNF(parent,typeEnv);
        
        switch(_v1132.termName) {
        case "ActType": {ESLVal $2338 = _v1132.termRef(0);
          ESLVal $2337 = _v1132.termRef(1);
          ESLVal $2336 = _v1132.termRef(2);
          
          {ESLVal l2 = $2338;
          
          {ESLVal decs2 = $2337;
          
          {ESLVal ms2 = $2336;
          
          return new ESLVal("ActType",l1,decs2.add(decs1),ms2.add(ms1));
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(56844,56979)").add(ESLVal.list(_v1132)));
      }
      }
      }
      }
      }
      }
      }
      default: {ESLVal _v1301 = _v1131;
        
        return _v1301;
      }
    }
    }
  }
  private static ESLVal typeNF = new ESLVal(new Function(new ESLVal("typeNF"),null) { public ESLVal apply(ESLVal... args) { return typeNF(args[0],args[1]); }});
  private static ESLVal getTermPatternType(ESLVal l,ESLVal n,ESLVal genericArgs,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t = lookupType.apply(n,cnstrEnv);
      
      if(t.eql($null).boolVal)
      return error(new ESLVal("TypeError",l,new ESLVal("unknown constructor ").add(n)));
      else
        if(length.apply(genericArgs).gre($zero).boolVal)
          return getGenericTermPatternType(l,t,genericArgs,selfType,valueEnv,cnstrEnv,typeEnv);
          else
            return t;
    }
  }
  private static ESLVal getTermPatternType = new ESLVal(new Function(new ESLVal("getTermPatternType"),null) { public ESLVal apply(ESLVal... args) { return getTermPatternType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal getGenericTermPatternType(ESLVal l,ESLVal t,ESLVal genericArgs,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal _v1134 = t;
      
      switch(_v1134.termName) {
      case "RecType": {ESLVal $2347 = _v1134.termRef(0);
        ESLVal $2346 = _v1134.termRef(1);
        ESLVal $2345 = _v1134.termRef(2);
        
        {ESLVal rl = $2347;
        
        {ESLVal rn = $2346;
        
        {ESLVal rt = $2345;
        
        return getGenericTermPatternType(l,substType.apply(new ESLVal("RecType",rl,rn,rt),rn,rt),genericArgs,selfType,valueEnv,cnstrEnv,typeEnv);
      }
      }
      }
      }
    case "TypeFun": {ESLVal $2344 = _v1134.termRef(0);
        ESLVal $2343 = _v1134.termRef(1);
        ESLVal $2342 = _v1134.termRef(2);
        
        {ESLVal al = $2344;
        
        {ESLVal ns = $2343;
        
        {ESLVal _v1295 = $2342;
        
        if(length.apply(ns).eql(length.apply(genericArgs)).boolVal)
        {ESLVal e = zipTypeEnv.apply(ns,genericArgs);
          
          return substTypeEnv.apply(e.add(typeEnv),_v1295);
        }
        else
          return error(new ESLVal("TypeError",l,new ESLVal("generic constructor mismatch")));
      }
      }
      }
      }
      default: {ESLVal _v1296 = _v1134;
        
        return error(new ESLVal("TypeError",l,new ESLVal("expecting a generic type: ").add(ppType(_v1296,typeEnv))));
      }
    }
    }
  }
  private static ESLVal getGenericTermPatternType = new ESLVal(new Function(new ESLVal("getGenericTermPatternType"),null) { public ESLVal apply(ESLVal... args) { return getGenericTermPatternType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal nilType(ESLVal l,ESLVal listType,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv,ESLVal f) {
    
    {ESLVal _v1135 = typeNF(listType,typeEnv);
      
      switch(_v1135.termName) {
      case "ListType": {ESLVal $2350 = _v1135.termRef(0);
        ESLVal $2349 = _v1135.termRef(1);
        
        {ESLVal ltl = $2350;
        
        {ESLVal et = $2349;
        
        return f.apply(new ESLVal("ForallType",l,ESLVal.list(new ESLVal("T")),new ESLVal("ListType",l,new ESLVal("VarType",l,new ESLVal("T")))),valueEnv);
      }
      }
      }
    case "TypeClosure": {ESLVal $2348 = _v1135.termRef(0);
        
        {ESLVal g = $2348;
        
        return nilType(l,g.apply(),selfType,valueEnv,cnstrEnv,typeEnv,f);
      }
      }
      default: {ESLVal _v1294 = _v1135;
        
        return error(new ESLVal("TypeError",l,new ESLVal("expecting a list type: ").add(ppType(_v1294,typeEnv))));
      }
    }
    }
  }
  private static ESLVal nilType = new ESLVal(new Function(new ESLVal("nilType"),null) { public ESLVal apply(ESLVal... args) { return nilType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal emptyBagType(ESLVal l,ESLVal bagType,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv,ESLVal f) {
    
    {ESLVal _v1136 = bagType;
      
      switch(_v1136.termName) {
      case "BagType": {ESLVal $2352 = _v1136.termRef(0);
        ESLVal $2351 = _v1136.termRef(1);
        
        {ESLVal ltl = $2352;
        
        {ESLVal et = $2351;
        
        return f.apply(new ESLVal("ForallType",l,ESLVal.list(new ESLVal("T")),new ESLVal("BagType",l,new ESLVal("VarType",l,new ESLVal("T")))),valueEnv);
      }
      }
      }
      default: {ESLVal _v1293 = _v1136;
        
        return error(new ESLVal("TypeError",l,new ESLVal("expecting a bag type: ").add(ppType(_v1293,typeEnv))));
      }
    }
    }
  }
  private static ESLVal emptyBagType = new ESLVal(new Function(new ESLVal("emptyBagType"),null) { public ESLVal apply(ESLVal... args) { return emptyBagType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal emptySetType(ESLVal l,ESLVal setType,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv,ESLVal f) {
    
    {ESLVal _v1137 = setType;
      
      switch(_v1137.termName) {
      case "SetType": {ESLVal $2354 = _v1137.termRef(0);
        ESLVal $2353 = _v1137.termRef(1);
        
        {ESLVal ltl = $2354;
        
        {ESLVal et = $2353;
        
        return f.apply(new ESLVal("ForallType",l,ESLVal.list(new ESLVal("T")),new ESLVal("SetType",l,new ESLVal("VarType",l,new ESLVal("T")))),valueEnv);
      }
      }
      }
      default: {ESLVal _v1292 = _v1137;
        
        return error(new ESLVal("TypeError",l,new ESLVal("expecting a set type: ").add(ppType(_v1292,typeEnv))));
      }
    }
    }
  }
  private static ESLVal emptySetType = new ESLVal(new Function(new ESLVal("emptySetType"),null) { public ESLVal apply(ESLVal... args) { return emptySetType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal consPatternType(ESLVal l,ESLVal h,ESLVal t,ESLVal listType,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv,ESLVal f) {
    
    {ESLVal _v1138 = typeNF(listType,typeEnv);
      
      switch(_v1138.termName) {
      case "ListType": {ESLVal $2357 = _v1138.termRef(0);
        ESLVal $2356 = _v1138.termRef(1);
        
        {ESLVal ltl = $2357;
        
        {ESLVal et = $2356;
        
        return patternType(l,h,substTypeEnv.apply(typeEnv,et),selfType,valueEnv,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun409"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1287 = $args[0];
        ESLVal _v1288 = $args[1];
        return patternType(l,t,listType,selfType,_v1288,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun410"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal _v1289 = $args[0];
              ESLVal _v1290 = $args[1];
              return f.apply(_v1287,_v1290);
                }
              }));
          }
        }));
      }
      }
      }
    case "TypeClosure": {ESLVal $2355 = _v1138.termRef(0);
        
        {ESLVal g = $2355;
        
        return consPatternType(l,h,t,g.apply(),selfType,valueEnv,cnstrEnv,typeEnv,f);
      }
      }
      default: {ESLVal _v1291 = _v1138;
        
        return error(new ESLVal("TypeError",l,new ESLVal("expecting a list type: ").add(ppType(_v1291,typeEnv))));
      }
    }
    }
  }
  private static ESLVal consPatternType = new ESLVal(new Function(new ESLVal("consPatternType"),null) { public ESLVal apply(ESLVal... args) { return consPatternType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7],args[8]); }});
  private static ESLVal bagConsPatternType(ESLVal l,ESLVal h,ESLVal t,ESLVal bagType,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv,ESLVal f) {
    
    {ESLVal _v1139 = bagType;
      
      switch(_v1139.termName) {
      case "BagType": {ESLVal $2359 = _v1139.termRef(0);
        ESLVal $2358 = _v1139.termRef(1);
        
        {ESLVal ltl = $2359;
        
        {ESLVal et = $2358;
        
        return patternType(l,h,substTypeEnv.apply(typeEnv,et),selfType,valueEnv,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun411"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1282 = $args[0];
        ESLVal _v1283 = $args[1];
        return patternType(l,t,bagType,selfType,_v1283,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun412"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal _v1284 = $args[0];
              ESLVal _v1285 = $args[1];
              return f.apply(_v1282,_v1285);
                }
              }));
          }
        }));
      }
      }
      }
      default: {ESLVal _v1286 = _v1139;
        
        return error(new ESLVal("TypeError",l,new ESLVal("expecting a bag type: ").add(ppType(_v1286,typeEnv))));
      }
    }
    }
  }
  private static ESLVal bagConsPatternType = new ESLVal(new Function(new ESLVal("bagConsPatternType"),null) { public ESLVal apply(ESLVal... args) { return bagConsPatternType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7],args[8]); }});
  private static ESLVal setConsPatternType(ESLVal l,ESLVal h,ESLVal t,ESLVal setType,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv,ESLVal f) {
    
    {ESLVal _v1140 = setType;
      
      switch(_v1140.termName) {
      case "SetType": {ESLVal $2361 = _v1140.termRef(0);
        ESLVal $2360 = _v1140.termRef(1);
        
        {ESLVal ltl = $2361;
        
        {ESLVal et = $2360;
        
        return patternType(l,h,substTypeEnv.apply(typeEnv,et),selfType,valueEnv,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun413"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1277 = $args[0];
        ESLVal _v1278 = $args[1];
        return patternType(l,t,setType,selfType,_v1278,cnstrEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun414"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal _v1279 = $args[0];
              ESLVal _v1280 = $args[1];
              return f.apply(_v1277,_v1280);
                }
              }));
          }
        }));
      }
      }
      }
      default: {ESLVal _v1281 = _v1140;
        
        return error(new ESLVal("TypeError",l,new ESLVal("expecting a set type: ").add(ppType(_v1281,typeEnv))));
      }
    }
    }
  }
  private static ESLVal setConsPatternType = new ESLVal(new Function(new ESLVal("setConsPatternType"),null) { public ESLVal apply(ESLVal... args) { return setConsPatternType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7],args[8]); }});
  private static ESLVal binExpType(ESLVal l,ESLVal e1,ESLVal op,ESLVal e2,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal _v1141 = op;
      
      switch(_v1141.strVal) {
      case "+": return plusExpType(l,e1,e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case "-": return subExpType(l,e1,e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case "*": return mulExpType(l,e1,e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case "/": return divExpType(l,e1,e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case ":": return consExpType(l,e1,e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case "=": return eqlExpType(l,e1,e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case "<>": return neqlExpType(l,e1,e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case "and": return andExpType(l,e1,e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case "andalso": return andExpType(l,e1,e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case "or": return orExpType(l,e1,e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case "orelse": return orExpType(l,e1,e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case ">": return compareExpType(l,e1,new ESLVal(">"),e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case ">=": return compareExpType(l,e1,new ESLVal(">="),e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case "<": return compareExpType(l,e1,new ESLVal("<"),e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case "<=": return compareExpType(l,e1,new ESLVal("<="),e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case "..": return dotDotExpType(l,e1,e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case "%": return percentExpType(l,e1,e2,selfType,valueEnv,cnstrEnv,typeEnv);
    case "@": return atExpType(l,e1,e2,selfType,valueEnv,cnstrEnv,typeEnv);
      default: {ESLVal _v1276 = _v1141;
        
        return error(new ESLVal("TypeError",l,new ESLVal("unknown operator: ").add(_v1276)));
      }
    }
    }
  }
  private static ESLVal binExpType = new ESLVal(new Function(new ESLVal("binExpType"),null) { public ESLVal apply(ESLVal... args) { return binExpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7]); }});
  private static ESLVal andExpType(ESLVal l,ESLVal e1,ESLVal e2,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t1 = expType(e1,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal t2 = expType(e2,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(isBoolType.apply(t1).and(isBoolType.apply(t2)).boolVal)
      return t1;
      else
        return error(new ESLVal("TypeError",l,new ESLVal("and expects boolean arguments: ").add(ppType(t1,typeEnv).add(new ESLVal(" ").add(ppType(t2,typeEnv))))));
    }
  }
  private static ESLVal andExpType = new ESLVal(new Function(new ESLVal("andExpType"),null) { public ESLVal apply(ESLVal... args) { return andExpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal atExpType(ESLVal l,ESLVal e1,ESLVal e2,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t1 = expType(e1,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal t2 = expType(e2,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(typeEqual.apply(t1,t2).boolVal)
      return t1;
      else
        return error(new ESLVal("TypeError",l,new ESLVal("@ expects arguments to be same type: ").add(ppType(t1,typeEnv).add(new ESLVal(" ").add(ppType(t2,typeEnv))))));
    }
  }
  private static ESLVal atExpType = new ESLVal(new Function(new ESLVal("atExpType"),null) { public ESLVal apply(ESLVal... args) { return atExpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal dotDotExpType(ESLVal l,ESLVal e1,ESLVal e2,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t1 = expType(e1,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal t2 = expType(e2,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(isIntType.apply(t1).and(isIntType.apply(t2)).boolVal)
      return new ESLVal("ListType",l,theTypeInt);
      else
        return error(new ESLVal("TypeError",l,new ESLVal(".. expects integer arguments: ").add(ppType(t1,typeEnv).add(new ESLVal(" ").add(ppType(t2,typeEnv))))));
    }
  }
  private static ESLVal dotDotExpType = new ESLVal(new Function(new ESLVal("dotDotExpType"),null) { public ESLVal apply(ESLVal... args) { return dotDotExpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal percentExpType(ESLVal l,ESLVal e1,ESLVal e2,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t1 = expType(e1,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal t2 = expType(e2,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(isIntType.apply(t1).and(isIntType.apply(t2)).boolVal)
      return theTypeInt;
      else
        return error(new ESLVal("TypeError",l,new ESLVal("% expects integer arguments: ").add(ppType(t1,typeEnv).add(new ESLVal(" ").add(ppType(t2,typeEnv))))));
    }
  }
  private static ESLVal percentExpType = new ESLVal(new Function(new ESLVal("percentExpType"),null) { public ESLVal apply(ESLVal... args) { return percentExpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal compareExpType(ESLVal l,ESLVal e1,ESLVal op,ESLVal e2,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t1 = expType(e1,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal t2 = expType(e2,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(isNumType.apply(t1).and(isNumType.apply(t2)).boolVal)
      return new ESLVal("BoolType",l);
      else
        return error(new ESLVal("TypeError",l,op.add(new ESLVal(" expects numeric arguments: ").add(ppType(t1,typeEnv).add(new ESLVal(" ").add(ppType(t2,typeEnv)))))));
    }
  }
  private static ESLVal compareExpType = new ESLVal(new Function(new ESLVal("compareExpType"),null) { public ESLVal apply(ESLVal... args) { return compareExpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7]); }});
  private static ESLVal orExpType(ESLVal l,ESLVal e1,ESLVal e2,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t1 = expType(e1,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal t2 = expType(e2,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(isBoolType.apply(t1).and(isBoolType.apply(t2)).boolVal)
      return t1;
      else
        return error(new ESLVal("TypeError",l,new ESLVal("or expects boolean arguments: ").add(ppType(t1,typeEnv).add(new ESLVal(" ").add(ppType(t2,typeEnv))))));
    }
  }
  private static ESLVal orExpType = new ESLVal(new Function(new ESLVal("orExpType"),null) { public ESLVal apply(ESLVal... args) { return orExpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal eqlExpType(ESLVal l,ESLVal e1,ESLVal e2,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t1 = expType(e1,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal t2 = expType(e2,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(typeEqual.apply(t1,t2).boolVal)
      return theTypeBool;
      else
        return error(new ESLVal("TypeError",l,new ESLVal("= expects types to agree: ").add(ppType(t1,typeEnv).add(new ESLVal(" <> ").add(ppType(t2,typeEnv))))));
    }
  }
  private static ESLVal eqlExpType = new ESLVal(new Function(new ESLVal("eqlExpType"),null) { public ESLVal apply(ESLVal... args) { return eqlExpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal neqlExpType(ESLVal l,ESLVal e1,ESLVal e2,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t1 = expType(e1,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal t2 = expType(e2,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(typeEqual.apply(t1,t2).boolVal)
      return theTypeBool;
      else
        return error(new ESLVal("TypeError",l,new ESLVal("<> expects types to agree: ").add(ppType(t1,typeEnv).add(new ESLVal(" <> ").add(ppType(t2,typeEnv))))));
    }
  }
  private static ESLVal neqlExpType = new ESLVal(new Function(new ESLVal("neqlExpType"),null) { public ESLVal apply(ESLVal... args) { return neqlExpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal consExpType(ESLVal l,ESLVal e1,ESLVal e2,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t1 = typeNF(expType(e1,selfType,valueEnv,cnstrEnv,typeEnv),typeEnv);
      ESLVal t2 = typeNF(expType(e2,selfType,valueEnv,cnstrEnv,typeEnv),typeEnv);
      
      {ESLVal _v1142 = t2;
      ESLVal _v1143 = t1;
      
      switch(_v1142.termName) {
      case "ListType": {ESLVal $2363 = _v1142.termRef(0);
        ESLVal $2362 = _v1142.termRef(1);
        
        {ESLVal _v1275 = $2363;
        
        {ESLVal elementType = $2362;
        
        {ESLVal headType = _v1143;
        
        if(subType.apply(headType,elementType).boolVal)
        return t2;
        else
          return error(new ESLVal("TypeError",_v1275,new ESLVal(": expects head type ").add(ppType(headType,typeEnv).add(new ESLVal(" and element type ").add(ppType(elementType,typeEnv).add(new ESLVal(" to agree")))))));
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(66034,66315)").add(ESLVal.list(_v1142,_v1143)));
    }
    }
    }
  }
  private static ESLVal consExpType = new ESLVal(new Function(new ESLVal("consExpType"),null) { public ESLVal apply(ESLVal... args) { return consExpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal divExpType(ESLVal l,ESLVal e1,ESLVal e2,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t1 = expType(e1,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal t2 = expType(e2,selfType,valueEnv,cnstrEnv,typeEnv);
      
      {ESLVal _v1144 = t1;
      ESLVal _v1145 = t2;
      
      switch(_v1144.termName) {
      case "IntType": {ESLVal $2366 = _v1144.termRef(0);
        
        switch(_v1145.termName) {
        case "IntType": {ESLVal $2367 = _v1145.termRef(0);
          
          {ESLVal l1 = $2366;
          
          {ESLVal l2 = $2367;
          
          return t1;
        }
        }
        }
        default: {ESLVal _v1271 = _v1144;
          
          {ESLVal _v1272 = _v1145;
          
          return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for /: ").add(ppType(_v1271,typeEnv).add(new ESLVal(" and ").add(ppType(_v1272,typeEnv))))));
        }
        }
      }
      }
    case "FloatType": {ESLVal $2364 = _v1144.termRef(0);
        
        switch(_v1145.termName) {
        case "FloatType": {ESLVal $2365 = _v1145.termRef(0);
          
          {ESLVal l1 = $2364;
          
          {ESLVal l2 = $2365;
          
          return t1;
        }
        }
        }
        default: {ESLVal _v1269 = _v1144;
          
          {ESLVal _v1270 = _v1145;
          
          return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for /: ").add(ppType(_v1269,typeEnv).add(new ESLVal(" and ").add(ppType(_v1270,typeEnv))))));
        }
        }
      }
      }
      default: {ESLVal _v1273 = _v1144;
        
        {ESLVal _v1274 = _v1145;
        
        return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for /: ").add(ppType(_v1273,typeEnv).add(new ESLVal(" and ").add(ppType(_v1274,typeEnv))))));
      }
      }
    }
    }
    }
  }
  private static ESLVal divExpType = new ESLVal(new Function(new ESLVal("divExpType"),null) { public ESLVal apply(ESLVal... args) { return divExpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal mulExpType(ESLVal l,ESLVal e1,ESLVal e2,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t1 = expType(e1,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal t2 = expType(e2,selfType,valueEnv,cnstrEnv,typeEnv);
      
      {ESLVal _v1146 = t1;
      ESLVal _v1147 = t2;
      
      switch(_v1146.termName) {
      case "IntType": {ESLVal $2371 = _v1146.termRef(0);
        
        switch(_v1147.termName) {
        case "IntType": {ESLVal $2373 = _v1147.termRef(0);
          
          {ESLVal l1 = $2371;
          
          {ESLVal l2 = $2373;
          
          return t1;
        }
        }
        }
      case "FloatType": {ESLVal $2372 = _v1147.termRef(0);
          
          {ESLVal l1 = $2371;
          
          {ESLVal l2 = $2372;
          
          return t2;
        }
        }
        }
        default: {ESLVal _v1265 = _v1146;
          
          {ESLVal _v1266 = _v1147;
          
          return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for *: ").add(ppType(_v1265,typeEnv).add(new ESLVal(" and ").add(ppType(_v1266,typeEnv))))));
        }
        }
      }
      }
    case "FloatType": {ESLVal $2368 = _v1146.termRef(0);
        
        switch(_v1147.termName) {
        case "FloatType": {ESLVal $2370 = _v1147.termRef(0);
          
          {ESLVal l1 = $2368;
          
          {ESLVal l2 = $2370;
          
          return t1;
        }
        }
        }
      case "IntType": {ESLVal $2369 = _v1147.termRef(0);
          
          {ESLVal l1 = $2368;
          
          {ESLVal l2 = $2369;
          
          return t1;
        }
        }
        }
        default: {ESLVal _v1263 = _v1146;
          
          {ESLVal _v1264 = _v1147;
          
          return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for *: ").add(ppType(_v1263,typeEnv).add(new ESLVal(" and ").add(ppType(_v1264,typeEnv))))));
        }
        }
      }
      }
      default: {ESLVal _v1267 = _v1146;
        
        {ESLVal _v1268 = _v1147;
        
        return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for *: ").add(ppType(_v1267,typeEnv).add(new ESLVal(" and ").add(ppType(_v1268,typeEnv))))));
      }
      }
    }
    }
    }
  }
  private static ESLVal mulExpType = new ESLVal(new Function(new ESLVal("mulExpType"),null) { public ESLVal apply(ESLVal... args) { return mulExpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal subExpType(ESLVal l,ESLVal e1,ESLVal e2,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t1 = expType(e1,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal t2 = expType(e2,selfType,valueEnv,cnstrEnv,typeEnv);
      
      {ESLVal _v1148 = t1;
      ESLVal _v1149 = t2;
      
      switch(_v1148.termName) {
      case "IntType": {ESLVal $2377 = _v1148.termRef(0);
        
        switch(_v1149.termName) {
        case "IntType": {ESLVal $2379 = _v1149.termRef(0);
          
          {ESLVal l1 = $2377;
          
          {ESLVal l2 = $2379;
          
          return t1;
        }
        }
        }
      case "FloatType": {ESLVal $2378 = _v1149.termRef(0);
          
          {ESLVal l1 = $2377;
          
          {ESLVal l2 = $2378;
          
          return t2;
        }
        }
        }
        default: {ESLVal _v1259 = _v1148;
          
          {ESLVal _v1260 = _v1149;
          
          return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for -: ").add(ppType(_v1259,typeEnv).add(new ESLVal(" and ").add(ppType(_v1260,typeEnv))))));
        }
        }
      }
      }
    case "FloatType": {ESLVal $2374 = _v1148.termRef(0);
        
        switch(_v1149.termName) {
        case "FloatType": {ESLVal $2376 = _v1149.termRef(0);
          
          {ESLVal l1 = $2374;
          
          {ESLVal l2 = $2376;
          
          return t1;
        }
        }
        }
      case "IntType": {ESLVal $2375 = _v1149.termRef(0);
          
          {ESLVal l1 = $2374;
          
          {ESLVal l2 = $2375;
          
          return t1;
        }
        }
        }
        default: {ESLVal _v1257 = _v1148;
          
          {ESLVal _v1258 = _v1149;
          
          return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for -: ").add(ppType(_v1257,typeEnv).add(new ESLVal(" and ").add(ppType(_v1258,typeEnv))))));
        }
        }
      }
      }
      default: {ESLVal _v1261 = _v1148;
        
        {ESLVal _v1262 = _v1149;
        
        return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for -: ").add(ppType(_v1261,typeEnv).add(new ESLVal(" and ").add(ppType(_v1262,typeEnv))))));
      }
      }
    }
    }
    }
  }
  private static ESLVal subExpType = new ESLVal(new Function(new ESLVal("subExpType"),null) { public ESLVal apply(ESLVal... args) { return subExpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal plusExpType(ESLVal l,ESLVal e1,ESLVal e2,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t1 = expType(e1,selfType,valueEnv,cnstrEnv,typeEnv);
      ESLVal t2 = expType(e2,selfType,valueEnv,cnstrEnv,typeEnv);
      
      {ESLVal _v1150 = t1;
      ESLVal _v1151 = t2;
      
      switch(_v1150.termName) {
      case "StrType": {ESLVal $2393 = _v1150.termRef(0);
        
        {ESLVal _v1251 = $2393;
        
        {ESLVal _v1252 = _v1151;
        
        return t1;
      }
      }
      }
    case "IntType": {ESLVal $2391 = _v1150.termRef(0);
        
        switch(_v1151.termName) {
        case "IntType": {ESLVal $2392 = _v1151.termRef(0);
          
          {ESLVal l1 = $2391;
          
          {ESLVal l2 = $2392;
          
          return t1;
        }
        }
        }
        default: switch(_v1151.termName) {
          case "StrType": {ESLVal $2380 = _v1151.termRef(0);
            
            {ESLVal _v1247 = _v1150;
            
            {ESLVal _v1248 = $2380;
            
            return t2;
          }
          }
          }
          default: {ESLVal _v1249 = _v1150;
            
            {ESLVal _v1250 = _v1151;
            
            return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for +: ").add(ppType(_v1249,typeEnv).add(new ESLVal(" and ").add(ppType(_v1250,typeEnv))))));
          }
          }
        }
      }
      }
    case "FloatType": {ESLVal $2389 = _v1150.termRef(0);
        
        switch(_v1151.termName) {
        case "FloatType": {ESLVal $2390 = _v1151.termRef(0);
          
          {ESLVal l1 = $2389;
          
          {ESLVal l2 = $2390;
          
          return t1;
        }
        }
        }
        default: switch(_v1151.termName) {
          case "StrType": {ESLVal $2380 = _v1151.termRef(0);
            
            {ESLVal _v1243 = _v1150;
            
            {ESLVal _v1244 = $2380;
            
            return t2;
          }
          }
          }
          default: {ESLVal _v1245 = _v1150;
            
            {ESLVal _v1246 = _v1151;
            
            return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for +: ").add(ppType(_v1245,typeEnv).add(new ESLVal(" and ").add(ppType(_v1246,typeEnv))))));
          }
          }
        }
      }
      }
    case "ListType": {ESLVal $2386 = _v1150.termRef(0);
        ESLVal $2385 = _v1150.termRef(1);
        
        switch(_v1151.termName) {
        case "ListType": {ESLVal $2388 = _v1151.termRef(0);
          ESLVal $2387 = _v1151.termRef(1);
          
          {ESLVal l1 = $2386;
          
          {ESLVal _v1233 = $2385;
          
          {ESLVal l2 = $2388;
          
          {ESLVal _v1234 = $2387;
          
          if(typeEqual.apply(_v1233,_v1234).boolVal)
          return new ESLVal("ListType",l1,_v1233);
          else
            switch(_v1151.termName) {
              case "StrType": {ESLVal $2380 = _v1151.termRef(0);
                
                {ESLVal _v1235 = _v1150;
                
                {ESLVal _v1236 = $2380;
                
                return _v1234;
              }
              }
              }
              default: {ESLVal _v1237 = _v1150;
                
                {ESLVal _v1238 = _v1151;
                
                return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for +: ").add(ppType(_v1237,typeEnv).add(new ESLVal(" and ").add(ppType(_v1238,typeEnv))))));
              }
              }
            }
        }
        }
        }
        }
        }
        default: switch(_v1151.termName) {
          case "StrType": {ESLVal $2380 = _v1151.termRef(0);
            
            {ESLVal _v1239 = _v1150;
            
            {ESLVal _v1240 = $2380;
            
            return t2;
          }
          }
          }
          default: {ESLVal _v1241 = _v1150;
            
            {ESLVal _v1242 = _v1151;
            
            return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for +: ").add(ppType(_v1241,typeEnv).add(new ESLVal(" and ").add(ppType(_v1242,typeEnv))))));
          }
          }
        }
      }
      }
    case "SetType": {ESLVal $2382 = _v1150.termRef(0);
        ESLVal $2381 = _v1150.termRef(1);
        
        switch(_v1151.termName) {
        case "SetType": {ESLVal $2384 = _v1151.termRef(0);
          ESLVal $2383 = _v1151.termRef(1);
          
          {ESLVal l1 = $2382;
          
          {ESLVal _v1223 = $2381;
          
          {ESLVal l2 = $2384;
          
          {ESLVal _v1224 = $2383;
          
          if(typeEqual.apply(_v1223,_v1224).boolVal)
          return new ESLVal("SetType",l1,_v1223);
          else
            switch(_v1151.termName) {
              case "StrType": {ESLVal $2380 = _v1151.termRef(0);
                
                {ESLVal _v1225 = _v1150;
                
                {ESLVal _v1226 = $2380;
                
                return _v1224;
              }
              }
              }
              default: {ESLVal _v1227 = _v1150;
                
                {ESLVal _v1228 = _v1151;
                
                return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for +: ").add(ppType(_v1227,typeEnv).add(new ESLVal(" and ").add(ppType(_v1228,typeEnv))))));
              }
              }
            }
        }
        }
        }
        }
        }
        default: switch(_v1151.termName) {
          case "StrType": {ESLVal $2380 = _v1151.termRef(0);
            
            {ESLVal _v1229 = _v1150;
            
            {ESLVal _v1230 = $2380;
            
            return t2;
          }
          }
          }
          default: {ESLVal _v1231 = _v1150;
            
            {ESLVal _v1232 = _v1151;
            
            return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for +: ").add(ppType(_v1231,typeEnv).add(new ESLVal(" and ").add(ppType(_v1232,typeEnv))))));
          }
          }
        }
      }
      }
      default: switch(_v1151.termName) {
        case "StrType": {ESLVal $2380 = _v1151.termRef(0);
          
          {ESLVal _v1253 = _v1150;
          
          {ESLVal _v1254 = $2380;
          
          return t2;
        }
        }
        }
        default: {ESLVal _v1255 = _v1150;
          
          {ESLVal _v1256 = _v1151;
          
          return error(new ESLVal("TypeError",l,new ESLVal("incomptible types for +: ").add(ppType(_v1255,typeEnv).add(new ESLVal(" and ").add(ppType(_v1256,typeEnv))))));
        }
        }
      }
    }
    }
    }
  }
  private static ESLVal plusExpType = new ESLVal(new Function(new ESLVal("plusExpType"),null) { public ESLVal apply(ESLVal... args) { return plusExpType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal applyTypeExp(ESLVal l,ESLVal e,ESLVal ts,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal _v1219 = substTypesEnv.apply(typeEnv,ts);
      ESLVal _v1220 = expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
      
      {ESLVal _v1152 = _v1220;
      
      switch(_v1152.termName) {
      case "ForallType": {ESLVal $2396 = _v1152.termRef(0);
        ESLVal $2395 = _v1152.termRef(1);
        ESLVal $2394 = _v1152.termRef(2);
        
        {ESLVal l1 = $2396;
        
        {ESLVal ns = $2395;
        
        {ESLVal _v1221 = $2394;
        
        if(length.apply(ns).eql(length.apply(_v1219)).boolVal)
        {ESLVal env = zipTypeEnv.apply(ns,_v1219);
          
          return substTypeEnv.apply(env.add(valueEnv),_v1221);
        }
        else
          return error(new ESLVal("TypeError",l,new ESLVal("universal type expects ").add(length.apply(ns).add(new ESLVal(" types, but supplied with ").add(length.apply(_v1219))))));
      }
      }
      }
      }
      default: {ESLVal _v1222 = _v1152;
        
        return error(new ESLVal("TypeError",l,new ESLVal("expecting a universal type: ").add(_v1222)));
      }
    }
    }
    }
  }
  private static ESLVal applyTypeExp = new ESLVal(new Function(new ESLVal("applyTypeExp"),null) { public ESLVal apply(ESLVal... args) { return applyTypeExp(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal expTypes(ESLVal es,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    return map.apply(new ESLVal(new Function(new ESLVal("fun415"),getSelf()) {
        public ESLVal apply(ESLVal... $args) {
          ESLVal e = $args[0];
      return expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
        }
      }),es);
  }
  private static ESLVal expTypes = new ESLVal(new Function(new ESLVal("expTypes"),null) { public ESLVal apply(ESLVal... args) { return expTypes(args[0],args[1],args[2],args[3],args[4]); }});
  private static ESLVal applyType(ESLVal l,ESLVal op,ESLVal args,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal _v1153 = typeNF(expType(op,selfType,valueEnv,cnstrEnv,typeEnv),typeEnv);
      
      switch(_v1153.termName) {
      case "FunType": {ESLVal $2399 = _v1153.termRef(0);
        ESLVal $2398 = _v1153.termRef(1);
        ESLVal $2397 = _v1153.termRef(2);
        
        {ESLVal l1 = $2399;
        
        {ESLVal domain = $2398;
        
        {ESLVal range = $2397;
        
        {ESLVal supplied = expTypes(args,selfType,valueEnv,cnstrEnv,typeEnv);
        
        if(length.apply(domain).eql(length.apply(supplied)).boolVal)
        if(subTypes.apply(supplied,domain).boolVal)
          return range;
          else
            return error(new ESLVal("TypeError",l,new ESLVal("supplied argument types ").add(ppTypes(supplied,typeEnv).add(new ESLVal(" do not match function domain ").add(ppTypes(domain,typeEnv))))));
        else
          return error(new ESLVal("TypeError",l,new ESLVal("expecting ").add(length.apply(domain).add(new ESLVal(" args, but supplied with ").add(length.apply(supplied))))));
      }
      }
      }
      }
      }
      default: {ESLVal t = _v1153;
        
        return error(new ESLVal("TypeError",l,new ESLVal("unknown type for apply: ").add(ppType(t,typeEnv))));
      }
    }
    }
  }
  private static ESLVal applyType = new ESLVal(new Function(new ESLVal("applyType"),null) { public ESLVal apply(ESLVal... args) { return applyType(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal ifType(ESLVal l,ESLVal e1,ESLVal e2,ESLVal e3,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal testType = expType(e1,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(isBoolType.apply(testType).boolVal)
      {ESLVal conseqType = expType(e2,selfType,valueEnv,cnstrEnv,typeEnv);
        ESLVal altType = expType(e3,selfType,valueEnv,cnstrEnv,typeEnv);
        
        if(typeEqual.apply(conseqType,altType).boolVal)
        return conseqType;
        else
          return error(new ESLVal("TypeError",l,new ESLVal("conseq and alt types do not agree: ").add(ppType(conseqType,typeEnv).add(new ESLVal(" ").add(ppType(altType,typeEnv))))));
      }
      else
        return error(new ESLVal("if expects a bool ").add(ppType(testType,typeEnv)));
    }
  }
  private static ESLVal ifType = new ESLVal(new Function(new ESLVal("ifType"),null) { public ESLVal apply(ESLVal... args) { return ifType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7]); }});
  private static ESLVal checkDecs(ESLVal ds) {
    
    {ESLVal _v1154 = ds;
      
      if(_v1154.isCons())
      {ESLVal $2400 = _v1154.head();
        ESLVal $2401 = _v1154.tail();
        
        {ESLVal d = $2400;
        
        {ESLVal _v1218 = $2401;
        
        if(member.apply(decName.apply(d),new java.util.function.Function<ESLVal,ESLVal>() {
        public ESLVal apply(ESLVal $l0) {
          ESLVal $a = $nil;
          java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
          while(!$l0.isNil()) { 
            ESLVal d = $l0.head();
            $l0 = $l0.tail();
            $v.add(decName.apply(d));
          }
          for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
          return $a;
        }}.apply(_v1218)).boolVal)
        return error(new ESLVal("TypeError",decLoc.apply(d),new ESLVal(" duplicate argument ").add(decName.apply(d))));
        else
          return checkDecs(_v1218);
      }
      }
      }
    else if(_v1154.isNil())
      return $null;
    else return error(new ESLVal("case error at Pos(71181,71414)").add(ESLVal.list(_v1154)));
    }
  }
  private static ESLVal checkDecs = new ESLVal(new Function(new ESLVal("checkDecs"),null) { public ESLVal apply(ESLVal... args) { return checkDecs(args[0]); }});
  private static ESLVal funType(ESLVal l,ESLVal n,ESLVal args,ESLVal t,ESLVal e,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {checkDecs(args);
    {ESLVal nType = expType(n,selfType,valueEnv,cnstrEnv,typeEnv);
      
      if(isStrType.apply(nType).boolVal)
      {ESLVal declaredType = substTypeEnv.apply(typeEnv,t);
        
        return decTypes(args,valueEnv,typeEnv,new ESLVal(new Function(new ESLVal("fun416"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1216 = $args[0];
        ESLVal _v1217 = $args[1];
        {ESLVal actualRange = expType(e,selfType,_v1217,cnstrEnv,typeEnv);
              
              if(subType.apply(new ESLVal("FunType",l,_v1216,actualRange),declaredType).boolVal)
              return new ESLVal("FunType",l,_v1216,actualRange);
              else
                return error(new ESLVal("TypeError",l,new ESLVal("function declared type ").add(ppType(declaredType,typeEnv).add(new ESLVal(" but is ").add(ppType(new ESLVal("FunType",l,_v1216,actualRange),typeEnv))))));
            }
          }
        }));
      }
      else
        return error(new ESLVal("TypeError",l,new ESLVal("expecting a string for a function name: ").add(n)));
    }}
  }
  private static ESLVal funType = new ESLVal(new Function(new ESLVal("funType"),null) { public ESLVal apply(ESLVal... args) { return funType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7],args[8]); }});
  private static ESLVal decTypes(ESLVal decs,ESLVal valueEnv,ESLVal typeEnv,ESLVal consumer) {
    
    { LetRec letrec = new LetRec() {
      ESLVal processDecs = new ESLVal(new Function(new ESLVal("processDecs"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1213 = $args[0];
        ESLVal _v1214 = $args[1];
        {ESLVal _v1155 = _v1213;
              
              if(_v1155.isCons())
              {ESLVal $2402 = _v1155.head();
                ESLVal $2403 = _v1155.tail();
                
                switch($2402.termName) {
                case "Dec": {ESLVal $2407 = $2402.termRef(0);
                  ESLVal $2406 = $2402.termRef(1);
                  ESLVal $2405 = $2402.termRef(2);
                  ESLVal $2404 = $2402.termRef(3);
                  
                  {ESLVal l = $2407;
                  
                  {ESLVal n = $2406;
                  
                  {ESLVal t = $2405;
                  
                  {ESLVal st = $2404;
                  
                  {ESLVal _v1215 = $2403;
                  
                  return processDecs.apply(_v1215,_v1214.cons(new ESLVal("Map",n,substTypeEnv.apply(typeEnv,t))));
                }
                }
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(72607,72832)").add(ESLVal.list(_v1155)));
              }
              }
            else if(_v1155.isNil())
              return consumer.apply(reverse.apply(typeEnvRan.apply(_v1214)),_v1214.add(valueEnv));
            else return error(new ESLVal("case error at Pos(72607,72832)").add(ESLVal.list(_v1155)));
            }
          }
        });
      
      public ESLVal get(String name) {
        switch(name) {
          case "processDecs": return processDecs;
          
          default: throw new Error("cannot find letrec binding");
        }
        }
      };
    ESLVal processDecs = letrec.get("processDecs");
    
      return processDecs.apply(decs,$nil);}
    
  }
  private static ESLVal decTypes = new ESLVal(new Function(new ESLVal("decTypes"),null) { public ESLVal apply(ESLVal... args) { return decTypes(args[0],args[1],args[2],args[3]); }});
  private static ESLVal termType(ESLVal l,ESLVal n,ESLVal ts,ESLVal es,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal t0 = lookupType.apply(n,cnstrEnv);
      
      if(t0.eql($null).boolVal)
      return error(new ESLVal("TypeError",l,new ESLVal("cannot find cnstr ").add(n)));
      else
        {ESLVal t = unfoldIf(t0);
          
          return termTypeCheckUnion(t,l,n,ts,es,selfType,valueEnv,cnstrEnv,typeEnv);
        }
    }
  }
  private static ESLVal termType = new ESLVal(new Function(new ESLVal("termType"),null) { public ESLVal apply(ESLVal... args) { return termType(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7]); }});
  private static ESLVal termTypeCheckUnion(ESLVal t,ESLVal l,ESLVal n,ESLVal ts,ESLVal es,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    if(t.eql($null).boolVal)
      return error(new ESLVal("TypeError",l,new ESLVal("cannot find constructor ").add(n)));
      else
        {ESLVal _v1156 = t;
          
          switch(_v1156.termName) {
          case "TypeFun": {ESLVal $2412 = _v1156.termRef(0);
            ESLVal $2411 = _v1156.termRef(1);
            ESLVal $2410 = _v1156.termRef(2);
            
            {ESLVal lf = $2412;
            
            {ESLVal ns = $2411;
            
            {ESLVal body = $2410;
            
            if(length.apply(ns).eql(length.apply(ts)).boolVal)
            {ESLVal args = map.apply(new ESLVal(new Function(new ESLVal("fun417"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal _v1211 = $args[0];
                return substTypeEnv.apply(typeEnv,_v1211);
                  }
                }),ts);
              
              {ESLVal _v1157 = substTypeEnv.apply(zipTypeEnv.apply(ns,args),body);
              
              switch(_v1157.termName) {
              case "UnionType": {ESLVal $2414 = _v1157.termRef(0);
                ESLVal $2413 = _v1157.termRef(1);
                
                {ESLVal l1 = $2414;
                
                {ESLVal terms = $2413;
                
                {ESLVal ts2 = findTermArgTypes(n,terms);
                
                if(length.apply(es).eql(length.apply(ts2)).boolVal)
                {checkTermArgTypes(l,es,ts2,selfType,valueEnv,cnstrEnv,typeEnv);
                return new ESLVal("UnionType",l1,terms);}
                else
                  return error(new ESLVal("TypeError",l,n.add(new ESLVal(" expects ").add(length.apply(ts2).add(new ESLVal(" args, but you supplied ").add(length.apply(es)))))));
              }
              }
              }
              }
              default: return error(new ESLVal("case error at Pos(73705,74267)").add(ESLVal.list(_v1157)));
            }
            }
            }
            else
              return error(new ESLVal("TypeError",l,new ESLVal("generic constructor ").add(n.add(new ESLVal(" expects ").add(length.apply(ns).add(new ESLVal(" type arguments, but received ").add(length.apply(ts))))))));
          }
          }
          }
          }
        case "UnionType": {ESLVal $2409 = _v1156.termRef(0);
            ESLVal $2408 = _v1156.termRef(1);
            
            {ESLVal l1 = $2409;
            
            {ESLVal terms = $2408;
            
            {ESLVal ts2 = findTermArgTypes(n,terms);
            
            if(length.apply(ts).neql($zero).boolVal)
            return error(new ESLVal("TypeError",l,new ESLVal("generic application of non-generic constructior: ").add(n)));
            else
              if(length.apply(es).eql(length.apply(ts2)).boolVal)
                {checkTermArgTypes(l,es,ts2,selfType,valueEnv,cnstrEnv,typeEnv);
                return t;}
                else
                  return error(new ESLVal("TypeError",l,n.add(new ESLVal(" expects ").add(length.apply(ts2).add(new ESLVal(" args, but you supplied ").add(length.apply(es)))))));
          }
          }
          }
          }
          default: {ESLVal _v1212 = _v1156;
            
            return error(new ESLVal("TypeError",l,new ESLVal("expecting a union type for ").add(n.add(new ESLVal(" but got ").add(ppType(_v1212,typeEnv))))));
          }
        }
        }
  }
  private static ESLVal termTypeCheckUnion = new ESLVal(new Function(new ESLVal("termTypeCheckUnion"),null) { public ESLVal apply(ESLVal... args) { return termTypeCheckUnion(args[0],args[1],args[2],args[3],args[4],args[5],args[6],args[7],args[8]); }});
  private static ESLVal unfoldIf(ESLVal t) {
    
    {ESLVal _v1158 = t;
      
      switch(_v1158.termName) {
      case "RecType": {ESLVal $2417 = _v1158.termRef(0);
        ESLVal $2416 = _v1158.termRef(1);
        ESLVal $2415 = _v1158.termRef(2);
        
        {ESLVal l = $2417;
        
        {ESLVal n = $2416;
        
        {ESLVal _v1209 = $2415;
        
        return unfoldIf(unfoldType.apply(l,n,_v1209));
      }
      }
      }
      }
      default: {ESLVal _v1210 = _v1158;
        
        return _v1210;
      }
    }
    }
  }
  private static ESLVal unfoldIf = new ESLVal(new Function(new ESLVal("unfoldIf"),null) { public ESLVal apply(ESLVal... args) { return unfoldIf(args[0]); }});
  private static ESLVal findTermArgTypes(ESLVal n,ESLVal terms) {
    
    {ESLVal _v1159 = terms;
      
      if(_v1159.isCons())
      {ESLVal $2418 = _v1159.head();
        ESLVal $2419 = _v1159.tail();
        
        switch($2418.termName) {
        case "TermType": {ESLVal $2422 = $2418.termRef(0);
          ESLVal $2421 = $2418.termRef(1);
          ESLVal $2420 = $2418.termRef(2);
          
          {ESLVal l = $2422;
          
          {ESLVal nn = $2421;
          
          {ESLVal ts = $2420;
          
          {ESLVal _v1207 = $2419;
          
          if(nn.eql(n).boolVal)
          return ts;
          else
            {ESLVal t = $2418;
              
              {ESLVal _v1208 = $2419;
              
              return findTermArgTypes(n,_v1208);
            }
            }
        }
        }
        }
        }
        }
        default: {ESLVal t = $2418;
          
          {ESLVal ts = $2419;
          
          return findTermArgTypes(n,ts);
        }
        }
      }
      }
    else if(_v1159.isNil())
      return error(new ESLVal("cannot find constructor ").add(n));
    else return error(new ESLVal("case error at Pos(75275,75475)").add(ESLVal.list(_v1159)));
    }
  }
  private static ESLVal findTermArgTypes = new ESLVal(new Function(new ESLVal("findTermArgTypes"),null) { public ESLVal apply(ESLVal... args) { return findTermArgTypes(args[0],args[1]); }});
  private static ESLVal checkTermArgTypes(ESLVal l,ESLVal es,ESLVal ts,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal _v1160 = es;
      ESLVal _v1161 = ts;
      
      if(_v1160.isCons())
      {ESLVal $2423 = _v1160.head();
        ESLVal $2424 = _v1160.tail();
        
        if(_v1161.isCons())
        {ESLVal $2425 = _v1161.head();
          ESLVal $2426 = _v1161.tail();
          
          {ESLVal e = $2423;
          
          {ESLVal _v1205 = $2424;
          
          {ESLVal t = $2425;
          
          {ESLVal _v1206 = $2426;
          
          {ESLVal tt = expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
          
          if(typeEqual.apply(t,tt).boolVal)
          return checkTermArgTypes(l,_v1205,_v1206,selfType,valueEnv,cnstrEnv,typeEnv);
          else
            return error(new ESLVal("TypeError",l,new ESLVal("expected constructor arg type ").add(ppType(t,typeEnv).add(new ESLVal(" but supplied ").add(ppType(tt,typeEnv))))));
        }
        }
        }
        }
        }
        }
      else if(_v1161.isNil())
        return error(new ESLVal("case error at Pos(75593,76015)").add(ESLVal.list(_v1160,_v1161)));
      else return error(new ESLVal("case error at Pos(75593,76015)").add(ESLVal.list(_v1160,_v1161)));
      }
    else if(_v1160.isNil())
      if(_v1161.isCons())
        {ESLVal $2427 = _v1161.head();
          ESLVal $2428 = _v1161.tail();
          
          return error(new ESLVal("case error at Pos(75593,76015)").add(ESLVal.list(_v1160,_v1161)));
        }
      else if(_v1161.isNil())
        return $null;
      else return error(new ESLVal("case error at Pos(75593,76015)").add(ESLVal.list(_v1160,_v1161)));
    else return error(new ESLVal("case error at Pos(75593,76015)").add(ESLVal.list(_v1160,_v1161)));
    }
  }
  private static ESLVal checkTermArgTypes = new ESLVal(new Function(new ESLVal("checkTermArgTypes"),null) { public ESLVal apply(ESLVal... args) { return checkTermArgTypes(args[0],args[1],args[2],args[3],args[4],args[5],args[6]); }});
  private static ESLVal notType(ESLVal l,ESLVal e,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal _v1162 = expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
      
      switch(_v1162.termName) {
      case "BoolType": {ESLVal $2429 = _v1162.termRef(0);
        
        {ESLVal _v1204 = $2429;
        
        return theTypeBool;
      }
      }
      default: {ESLVal t = _v1162;
        
        return error(new ESLVal("TypeError",l,new ESLVal("expecting a boolean: ").add(ppType(t,typeEnv))));
      }
    }
    }
  }
  private static ESLVal notType = new ESLVal(new Function(new ESLVal("notType"),null) { public ESLVal apply(ESLVal... args) { return notType(args[0],args[1],args[2],args[3],args[4],args[5]); }});
  private static ESLVal varType(ESLVal l,ESLVal n,ESLVal valueEnv,ESLVal typeEnv) {
    
    {ESLVal t = lookupType.apply(n,valueEnv);
      
      if(t.eql($null).boolVal)
      return error(new ESLVal("TypeError",l,new ESLVal("unbound variable ").add(n)));
      else
        {ESLVal _v1163 = t;
          
          switch(_v1163.termName) {
          case "TypeClosure": {ESLVal $2430 = _v1163.termRef(0);
            
            {ESLVal f = $2430;
            
            return f.apply();
          }
          }
          default: {ESLVal _v1203 = _v1163;
            
            return _v1203;
          }
        }
        }
    }
  }
  private static ESLVal varType = new ESLVal(new Function(new ESLVal("varType"),null) { public ESLVal apply(ESLVal... args) { return varType(args[0],args[1],args[2],args[3]); }});
  private static ESLVal blockType(ESLVal l,ESLVal es,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    {ESLVal[] t = new ESLVal[]{theTypeVoid};
      
      {{
      ESLVal _v1164 = es;
      while(_v1164.isCons()) {
        ESLVal e = _v1164.headVal;
        t[0] = expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
        _v1164 = _v1164.tailVal;}
    }
    return t[0];}
    }
  }
  private static ESLVal blockType = new ESLVal(new Function(new ESLVal("blockType"),null) { public ESLVal apply(ESLVal... args) { return blockType(args[0],args[1],args[2],args[3],args[4],args[5]); }});
  private static ESLVal listType(ESLVal l,ESLVal es,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    if(es.eql($nil).boolVal)
      return new ESLVal("ForallType",l,ESLVal.list(new ESLVal("T")),new ESLVal("ListType",l,new ESLVal("VarType",l,new ESLVal("T"))));
      else
        {ESLVal ts = map.apply(new ESLVal(new Function(new ESLVal("fun418"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal e = $args[0];
            return expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
              }
            }),es);
          
          if(allEqualTypes.apply(head.apply(ts),tail.apply(ts)).boolVal)
          return new ESLVal("ListType",l,head.apply(ts));
          else
            return error(new ESLVal("TypeError",l,new ESLVal("lists should have elements of the same type: ").add(es)));
        }
  }
  private static ESLVal listType = new ESLVal(new Function(new ESLVal("listType"),null) { public ESLVal apply(ESLVal... args) { return listType(args[0],args[1],args[2],args[3],args[4],args[5]); }});
  private static ESLVal setType(ESLVal l,ESLVal es,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    if(es.eql($nil).boolVal)
      return new ESLVal("ForallType",l,ESLVal.list(new ESLVal("T")),new ESLVal("SetType",l,new ESLVal("VarType",l,new ESLVal("T"))));
      else
        {ESLVal ts = map.apply(new ESLVal(new Function(new ESLVal("fun419"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal e = $args[0];
            return expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
              }
            }),es);
          
          if(allEqualTypes.apply(head.apply(ts),tail.apply(ts)).boolVal)
          return new ESLVal("SetType",l,head.apply(ts));
          else
            return error(new ESLVal("TypeError",l,new ESLVal("sets should have elements of the same type: ").add(es)));
        }
  }
  private static ESLVal setType = new ESLVal(new Function(new ESLVal("setType"),null) { public ESLVal apply(ESLVal... args) { return setType(args[0],args[1],args[2],args[3],args[4],args[5]); }});
  private static ESLVal bagType(ESLVal l,ESLVal es,ESLVal selfType,ESLVal valueEnv,ESLVal cnstrEnv,ESLVal typeEnv) {
    
    if(es.eql($nil).boolVal)
      return new ESLVal("ForallType",l,ESLVal.list(new ESLVal("T")),new ESLVal("BagType",l,new ESLVal("VarType",l,new ESLVal("T"))));
      else
        {ESLVal ts = map.apply(new ESLVal(new Function(new ESLVal("fun420"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal e = $args[0];
            return expType(e,selfType,valueEnv,cnstrEnv,typeEnv);
              }
            }),es);
          
          if(allEqualTypes.apply(head.apply(ts),tail.apply(ts)).boolVal)
          return new ESLVal("BagType",l,head.apply(ts));
          else
            return error(new ESLVal("TypeError",l,new ESLVal("bags should have elements of the same type: ").add(es)));
        }
  }
  private static ESLVal bagType = new ESLVal(new Function(new ESLVal("bagType"),null) { public ESLVal apply(ESLVal... args) { return bagType(args[0],args[1],args[2],args[3],args[4],args[5]); }});
  private static ESLVal recTypes(ESLVal env) {
    
    { LetRec letrec = new LetRec() {
      ESLVal fixEnv = new ESLVal(new Function(new ESLVal("fixEnv"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1202 = $args[0];
        {ESLVal[] e = new ESLVal[]{$null};
              
              {ESLVal fenv = new java.util.function.Function<ESLVal,ESLVal>() {
                  public ESLVal apply(ESLVal $l0) {
                    ESLVal $a = $nil;
                    java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                    while(!$l0.isNil()) { 
                      ESLVal t = $l0.head();
                      $l0 = $l0.tail();
                      ESLVal $l1 = typeFV(t);
                while(!$l1.isNil()) {
                  ESLVal n = $l1.head();
                  $l1 = $l1.tail();
                  $v.add(new ESLVal("Map",n,new ESLVal("TypeClosure",new ESLVal(new Function(new ESLVal("lookup: ").add(n),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      return lookupType.apply(n,e[0]);
                    }
                  }))));
                }
                    }
                    for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                    return $a;
                  }}.apply(typeEnvRan.apply(_v1202));
              
              {ESLVal env1 = substOnce.apply(_v1202,fenv);
              
              {e[0] = env1;
            return env1;}
            }
            }
            }
          }
        });
      ESLVal introduceRecTypes = new ESLVal(new Function(new ESLVal("introduceRecTypes"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1201 = $args[0];
        {ESLVal _v1165 = _v1201;
              
              if(_v1165.isCons())
              {ESLVal $2431 = _v1165.head();
                ESLVal $2432 = _v1165.tail();
                
                switch($2431.termName) {
                case "Map": {ESLVal $2434 = $2431.termRef(0);
                  ESLVal $2433 = $2431.termRef(1);
                  
                  switch($2433.termName) {
                  case "RecordType": {ESLVal $2436 = $2433.termRef(0);
                    ESLVal $2435 = $2433.termRef(1);
                    
                    {ESLVal n = $2434;
                    
                    {ESLVal l = $2436;
                    
                    {ESLVal fs = $2435;
                    
                    {ESLVal e = $2432;
                    
                    return introduceRecTypes.apply(e).cons(new ESLVal("Map",n,new ESLVal("RecordType",l,fs)));
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal n = $2434;
                    
                    {ESLVal t = $2433;
                    
                    {ESLVal e = $2432;
                    
                    if(member.apply(n,typeFV(t)).boolVal)
                    return introduceRecTypes.apply(e).cons(new ESLVal("Map",n,new ESLVal("RecType",p0,n,t)));
                    else
                      return introduceRecTypes.apply(e).cons(new ESLVal("Map",n,t));
                  }
                  }
                  }
                }
                }
                default: return error(new ESLVal("case error at Pos(78578,78892)").add(ESLVal.list(_v1165)));
              }
              }
            else if(_v1165.isNil())
              return _v1201;
            else return error(new ESLVal("case error at Pos(78578,78892)").add(ESLVal.list(_v1165)));
            }
          }
        });
      ESLVal substOnce = new ESLVal(new Function(new ESLVal("substOnce"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1199 = $args[0];
        ESLVal _v1200 = $args[1];
        {ESLVal map1 = new ESLVal(new Function(new ESLVal("map1"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal m = $args[0];
                {ESLVal _v1166 = m;
                      
                      switch(_v1166.termName) {
                      case "Map": {ESLVal $2438 = _v1166.termRef(0);
                        ESLVal $2437 = _v1166.termRef(1);
                        
                        {ESLVal n = $2438;
                        
                        {ESLVal t = $2437;
                        
                        return new ESLVal("Map",n,substTypeEnv.apply(new java.util.function.Function<ESLVal,ESLVal>() {
                          public ESLVal apply(ESLVal $l0) {
                            ESLVal $a = $nil;
                            java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();
                            while(!$l0.isNil()) { 
                              ESLVal n = $l0.head();
                              $l0 = $l0.tail();
                              $v.add(new ESLVal("Map",n,lookupType.apply(n,_v1200)));
                            }
                            for(int i = $v.size()-1; i >= 0; i--) $a = new ESLVal($v.get(i),$a);
                            return $a;
                          }}.apply(typeFV(t)),t));
                      }
                      }
                      }
                      default: return error(new ESLVal("case error at Pos(79002,79133)").add(ESLVal.list(_v1166)));
                    }
                    }
                  }
                });
              
              return map.apply(map1,_v1199);
            }
          }
        });
      
      public ESLVal get(String name) {
        switch(name) {
          case "fixEnv": return fixEnv;
          
          case "introduceRecTypes": return introduceRecTypes;
          
          case "substOnce": return substOnce;
          
          default: throw new Error("cannot find letrec binding");
        }
        }
      };
    ESLVal fixEnv = letrec.get("fixEnv");
    
    ESLVal introduceRecTypes = letrec.get("introduceRecTypes");
    
    ESLVal substOnce = letrec.get("substOnce");
    
      return fixEnv.apply(introduceRecTypes.apply(env));}
    
  }
  private static ESLVal recTypes = new ESLVal(new Function(new ESLVal("recTypes"),null) { public ESLVal apply(ESLVal... args) { return recTypes(args[0]); }});
  private static ESLVal typeFV(ESLVal t) {
    
    return removeDups.apply(varTypeNames(typeFV1(t,$nil)));
  }
  private static ESLVal typeFV = new ESLVal(new Function(new ESLVal("typeFV"),null) { public ESLVal apply(ESLVal... args) { return typeFV(args[0]); }});
  private static ESLVal varTypeNames(ESLVal vs) {
    
    return map.apply(varTypeName,vs);
  }
  private static ESLVal varTypeNames = new ESLVal(new Function(new ESLVal("varTypeNames"),null) { public ESLVal apply(ESLVal... args) { return varTypeNames(args[0]); }});
  private static ESLVal varTypeName(ESLVal t) {
    
    {ESLVal _v1167 = t;
      
      switch(_v1167.termName) {
      case "VarType": {ESLVal $2440 = _v1167.termRef(0);
        ESLVal $2439 = _v1167.termRef(1);
        
        {ESLVal l = $2440;
        
        {ESLVal n = $2439;
        
        return n;
      }
      }
      }
      default: {ESLVal x = _v1167;
        
        return new ESLVal("<var>");
      }
    }
    }
  }
  private static ESLVal varTypeName = new ESLVal(new Function(new ESLVal("varTypeName"),null) { public ESLVal apply(ESLVal... args) { return varTypeName(args[0]); }});
  private static ESLVal tdecsFV1(ESLVal decs,ESLVal fv) {
    
    {ESLVal _v1168 = decs;
      
      if(_v1168.isCons())
      {ESLVal $2441 = _v1168.head();
        ESLVal $2442 = _v1168.tail();
        
        {ESLVal d = $2441;
        
        {ESLVal ds = $2442;
        
        return tdecFV1(d,tdecsFV1(ds,fv));
      }
      }
      }
    else if(_v1168.isNil())
      return fv;
    else return error(new ESLVal("case error at Pos(79519,79608)").add(ESLVal.list(_v1168)));
    }
  }
  private static ESLVal tdecsFV1 = new ESLVal(new Function(new ESLVal("tdecsFV1"),null) { public ESLVal apply(ESLVal... args) { return tdecsFV1(args[0],args[1]); }});
  private static ESLVal tdecFV1(ESLVal d,ESLVal fv) {
    
    {ESLVal _v1169 = d;
      
      switch(_v1169.termName) {
      case "Dec": {ESLVal $2446 = _v1169.termRef(0);
        ESLVal $2445 = _v1169.termRef(1);
        ESLVal $2444 = _v1169.termRef(2);
        ESLVal $2443 = _v1169.termRef(3);
        
        {ESLVal l = $2446;
        
        {ESLVal n = $2445;
        
        {ESLVal t = $2444;
        
        {ESLVal st = $2443;
        
        return typeFV1(t,fv);
      }
      }
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(79652,79731)").add(ESLVal.list(_v1169)));
    }
    }
  }
  private static ESLVal tdecFV1 = new ESLVal(new Function(new ESLVal("tdecFV1"),null) { public ESLVal apply(ESLVal... args) { return tdecFV1(args[0],args[1]); }});
  private static ESLVal handlersFV1(ESLVal handlers,ESLVal fv) {
    
    {ESLVal _v1170 = handlers;
      
      if(_v1170.isCons())
      {ESLVal $2447 = _v1170.head();
        ESLVal $2448 = _v1170.tail();
        
        {ESLVal m = $2447;
        
        {ESLVal hs = $2448;
        
        return handlerFV1(m,handlersFV1(hs,fv));
      }
      }
      }
    else if(_v1170.isNil())
      return fv;
    else return error(new ESLVal("case error at Pos(79789,79891)").add(ESLVal.list(_v1170)));
    }
  }
  private static ESLVal handlersFV1 = new ESLVal(new Function(new ESLVal("handlersFV1"),null) { public ESLVal apply(ESLVal... args) { return handlersFV1(args[0],args[1]); }});
  private static ESLVal handlerFV1(ESLVal m,ESLVal fv) {
    
    {ESLVal _v1171 = m;
      
      switch(_v1171.termName) {
      case "MessageType": {ESLVal $2450 = _v1171.termRef(0);
        ESLVal $2449 = _v1171.termRef(1);
        
        {ESLVal l = $2450;
        
        {ESLVal ts = $2449;
        
        return typesFV1(ts,fv);
      }
      }
      }
      default: return error(new ESLVal("case error at Pos(79939,80015)").add(ESLVal.list(_v1171)));
    }
    }
  }
  private static ESLVal handlerFV1 = new ESLVal(new Function(new ESLVal("handlerFV1"),null) { public ESLVal apply(ESLVal... args) { return handlerFV1(args[0],args[1]); }});
  private static ESLVal typesFV1(ESLVal ts,ESLVal fv) {
    
    {ESLVal _v1172 = ts;
      
      if(_v1172.isCons())
      {ESLVal $2451 = _v1172.head();
        ESLVal $2452 = _v1172.tail();
        
        {ESLVal t = $2451;
        
        {ESLVal _v1198 = $2452;
        
        return typeFV1(t,typesFV1(_v1198,fv));
      }
      }
      }
    else if(_v1172.isNil())
      return fv;
    else return error(new ESLVal("case error at Pos(80064,80151)").add(ESLVal.list(_v1172)));
    }
  }
  private static ESLVal typesFV1 = new ESLVal(new Function(new ESLVal("typesFV1"),null) { public ESLVal apply(ESLVal... args) { return typesFV1(args[0],args[1]); }});
  private static ESLVal typeFV1(ESLVal t,ESLVal fv) {
    
    {ESLVal _v1173 = t;
      
      switch(_v1173.termName) {
      case "ArrayType": {ESLVal $2518 = _v1173.termRef(0);
        ESLVal $2517 = _v1173.termRef(1);
        
        {ESLVal l = $2518;
        
        {ESLVal _v1197 = $2517;
        
        return typeFV1(_v1197,fv);
      }
      }
      }
    case "ActType": {ESLVal $2516 = _v1173.termRef(0);
        ESLVal $2515 = _v1173.termRef(1);
        ESLVal $2514 = _v1173.termRef(2);
        
        {ESLVal l = $2516;
        
        {ESLVal decs = $2515;
        
        {ESLVal handlers = $2514;
        
        return tdecsFV1(decs,handlersFV1(handlers,fv));
      }
      }
      }
      }
    case "ExtendedAct": {ESLVal $2513 = _v1173.termRef(0);
        ESLVal $2512 = _v1173.termRef(1);
        ESLVal $2511 = _v1173.termRef(2);
        ESLVal $2510 = _v1173.termRef(3);
        
        {ESLVal l = $2513;
        
        {ESLVal parent = $2512;
        
        {ESLVal decs = $2511;
        
        {ESLVal handlers = $2510;
        
        return tdecsFV1(decs,handlersFV1(handlers,typeFV1(parent,fv)));
      }
      }
      }
      }
      }
    case "ApplyType": {ESLVal $2509 = _v1173.termRef(0);
        ESLVal $2508 = _v1173.termRef(1);
        ESLVal $2507 = _v1173.termRef(2);
        
        {ESLVal l = $2509;
        
        {ESLVal n = $2508;
        
        {ESLVal types = $2507;
        
        return typesFV1(types,fv.cons(new ESLVal("VarType",l,n)));
      }
      }
      }
      }
    case "ApplyTypeFun": {ESLVal $2506 = _v1173.termRef(0);
        ESLVal $2505 = _v1173.termRef(1);
        ESLVal $2504 = _v1173.termRef(2);
        
        {ESLVal l = $2506;
        
        {ESLVal op = $2505;
        
        {ESLVal args = $2504;
        
        return typesFV1(args,typeFV1(op,fv));
      }
      }
      }
      }
    case "BoolType": {ESLVal $2503 = _v1173.termRef(0);
        
        {ESLVal l = $2503;
        
        return fv;
      }
      }
    case "FieldType": {ESLVal $2502 = _v1173.termRef(0);
        ESLVal $2501 = _v1173.termRef(1);
        ESLVal $2500 = _v1173.termRef(2);
        
        {ESLVal l = $2502;
        
        {ESLVal n = $2501;
        
        {ESLVal _v1196 = $2500;
        
        return typeFV1(_v1196,fv);
      }
      }
      }
      }
    case "FloatType": {ESLVal $2499 = _v1173.termRef(0);
        
        {ESLVal l = $2499;
        
        return fv;
      }
      }
    case "ForallType": {ESLVal $2498 = _v1173.termRef(0);
        ESLVal $2497 = _v1173.termRef(1);
        ESLVal $2496 = _v1173.termRef(2);
        
        {ESLVal l = $2498;
        
        {ESLVal ns = $2497;
        
        {ESLVal _v1193 = $2496;
        
        return filter.apply(new ESLVal(new Function(new ESLVal("fun421"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1194 = $args[0];
        {ESLVal _v1177 = _v1194;
              
              switch(_v1177.termName) {
              case "VarType": {ESLVal $2528 = _v1177.termRef(0);
                ESLVal $2527 = _v1177.termRef(1);
                
                {ESLVal _v1195 = $2528;
                
                {ESLVal n = $2527;
                
                return member.apply(n,ns).not();
              }
              }
              }
              default: return error(new ESLVal("case error at Pos(80990,81050)").add(ESLVal.list(_v1177)));
            }
            }
          }
        }),typeFV1(_v1193,$nil)).add(fv);
      }
      }
      }
      }
    case "FunType": {ESLVal $2495 = _v1173.termRef(0);
        ESLVal $2494 = _v1173.termRef(1);
        ESLVal $2493 = _v1173.termRef(2);
        
        {ESLVal l = $2495;
        
        {ESLVal d = $2494;
        
        {ESLVal r = $2493;
        
        return typesFV1(d,typeFV1(r,fv));
      }
      }
      }
      }
    case "IntType": {ESLVal $2492 = _v1173.termRef(0);
        
        {ESLVal l = $2492;
        
        return fv;
      }
      }
    case "ListType": {ESLVal $2491 = _v1173.termRef(0);
        ESLVal $2490 = _v1173.termRef(1);
        
        {ESLVal l = $2491;
        
        {ESLVal _v1192 = $2490;
        
        return typeFV1(_v1192,fv);
      }
      }
      }
    case "BagType": {ESLVal $2489 = _v1173.termRef(0);
        ESLVal $2488 = _v1173.termRef(1);
        
        {ESLVal l = $2489;
        
        {ESLVal _v1191 = $2488;
        
        return typeFV1(_v1191,fv);
      }
      }
      }
    case "SetType": {ESLVal $2487 = _v1173.termRef(0);
        ESLVal $2486 = _v1173.termRef(1);
        
        {ESLVal l = $2487;
        
        {ESLVal _v1190 = $2486;
        
        return typeFV1(_v1190,fv);
      }
      }
      }
    case "NullType": {ESLVal $2485 = _v1173.termRef(0);
        
        {ESLVal l = $2485;
        
        return fv;
      }
      }
    case "ObserverType": {ESLVal $2484 = _v1173.termRef(0);
        ESLVal $2483 = _v1173.termRef(1);
        ESLVal $2482 = _v1173.termRef(2);
        
        {ESLVal l = $2484;
        
        {ESLVal s = $2483;
        
        {ESLVal m = $2482;
        
        return typeFV1(s,typeFV1(m,fv));
      }
      }
      }
      }
    case "ObservedType": {ESLVal $2481 = _v1173.termRef(0);
        ESLVal $2480 = _v1173.termRef(1);
        ESLVal $2479 = _v1173.termRef(2);
        
        {ESLVal l = $2481;
        
        {ESLVal s = $2480;
        
        {ESLVal m = $2479;
        
        return typeFV1(s,typeFV1(m,fv));
      }
      }
      }
      }
    case "RecordType": {ESLVal $2478 = _v1173.termRef(0);
        ESLVal $2477 = _v1173.termRef(1);
        
        {ESLVal l = $2478;
        
        {ESLVal fs = $2477;
        
        return typesFV1(new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v1176 = $qualArg;
              
              switch(_v1176.termName) {
              case "Dec": {ESLVal $2526 = _v1176.termRef(0);
                ESLVal $2525 = _v1176.termRef(1);
                ESLVal $2524 = _v1176.termRef(2);
                ESLVal $2523 = _v1176.termRef(3);
                
                {ESLVal _v1188 = $2526;
                
                {ESLVal n = $2525;
                
                {ESLVal _v1189 = $2524;
                
                {ESLVal dt = $2523;
                
                return ESLVal.list(ESLVal.list(_v1189));
              }
              }
              }
              }
              }
              default: {ESLVal _0 = _v1176;
                
                return $nil;
              }
            }
            }
          }
        }).map(fs).flatten().flatten(),fv);
      }
      }
      }
    case "RecType": {ESLVal $2476 = _v1173.termRef(0);
        ESLVal $2475 = _v1173.termRef(1);
        ESLVal $2474 = _v1173.termRef(2);
        
        {ESLVal l = $2476;
        
        {ESLVal a = $2475;
        
        {ESLVal _v1185 = $2474;
        
        return filter.apply(new ESLVal(new Function(new ESLVal("fun422"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1186 = $args[0];
        {ESLVal _v1175 = _v1186;
              
              switch(_v1175.termName) {
              case "VarType": {ESLVal $2522 = _v1175.termRef(0);
                ESLVal $2521 = _v1175.termRef(1);
                
                {ESLVal _v1187 = $2522;
                
                {ESLVal n = $2521;
                
                return n.eql(a).not();
              }
              }
              }
              default: return error(new ESLVal("case error at Pos(81631,81679)").add(ESLVal.list(_v1175)));
            }
            }
          }
        }),typeFV1(_v1185,$nil)).add(fv);
      }
      }
      }
      }
    case "StrType": {ESLVal $2473 = _v1173.termRef(0);
        
        {ESLVal l = $2473;
        
        return fv;
      }
      }
    case "TableType": {ESLVal $2472 = _v1173.termRef(0);
        ESLVal $2471 = _v1173.termRef(1);
        ESLVal $2470 = _v1173.termRef(2);
        
        {ESLVal l = $2472;
        
        {ESLVal k = $2471;
        
        {ESLVal v = $2470;
        
        return typeFV1(k,typeFV1(v,fv));
      }
      }
      }
      }
    case "TypeClosure": {ESLVal $2469 = _v1173.termRef(0);
        
        {ESLVal f = $2469;
        
        return $nil;
      }
      }
    case "TermType": {ESLVal $2468 = _v1173.termRef(0);
        ESLVal $2467 = _v1173.termRef(1);
        ESLVal $2466 = _v1173.termRef(2);
        
        {ESLVal l = $2468;
        
        {ESLVal n = $2467;
        
        {ESLVal ts = $2466;
        
        return typesFV1(ts,fv);
      }
      }
      }
      }
    case "TypeFun": {ESLVal $2465 = _v1173.termRef(0);
        ESLVal $2464 = _v1173.termRef(1);
        ESLVal $2463 = _v1173.termRef(2);
        
        {ESLVal l = $2465;
        
        {ESLVal ns = $2464;
        
        {ESLVal _v1182 = $2463;
        
        return filter.apply(new ESLVal(new Function(new ESLVal("fun423"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1183 = $args[0];
        {ESLVal _v1174 = _v1183;
              
              switch(_v1174.termName) {
              case "VarType": {ESLVal $2520 = _v1174.termRef(0);
                ESLVal $2519 = _v1174.termRef(1);
                
                {ESLVal _v1184 = $2520;
                
                {ESLVal n = $2519;
                
                return member.apply(n,ns).not();
              }
              }
              }
              default: return error(new ESLVal("case error at Pos(81975,82035)").add(ESLVal.list(_v1174)));
            }
            }
          }
        }),typeFV1(_v1182,$nil)).add(fv);
      }
      }
      }
      }
    case "UnfoldType": {ESLVal $2462 = _v1173.termRef(0);
        ESLVal $2461 = _v1173.termRef(1);
        
        {ESLVal l = $2462;
        
        {ESLVal _v1181 = $2461;
        
        return typeFV1(_v1181,fv);
      }
      }
      }
    case "UnionType": {ESLVal $2460 = _v1173.termRef(0);
        ESLVal $2459 = _v1173.termRef(1);
        
        {ESLVal l = $2460;
        
        {ESLVal ts = $2459;
        
        return typesFV1(ts,fv);
      }
      }
      }
    case "VarType": {ESLVal $2458 = _v1173.termRef(0);
        ESLVal $2457 = _v1173.termRef(1);
        
        {ESLVal l = $2458;
        
        {ESLVal n = $2457;
        
        return fv.cons(t);
      }
      }
      }
    case "VoidType": {ESLVal $2456 = _v1173.termRef(0);
        
        {ESLVal l = $2456;
        
        return fv;
      }
      }
    case "UnionRef": {ESLVal $2455 = _v1173.termRef(0);
        ESLVal $2454 = _v1173.termRef(1);
        ESLVal $2453 = _v1173.termRef(2);
        
        {ESLVal l = $2455;
        
        {ESLVal _v1180 = $2454;
        
        {ESLVal n = $2453;
        
        return typeFV1(_v1180,fv);
      }
      }
      }
      }
      default: {ESLVal x = _v1173;
        
        return error(x);
      }
    }
    }
  }
  private static ESLVal typeFV1 = new ESLVal(new Function(new ESLVal("typeFV1"),null) { public ESLVal apply(ESLVal... args) { return typeFV1(args[0],args[1]); }});
public static void main(String[] args) {
    newActor(main,new ESLVal(new Actor())); 
  }
}