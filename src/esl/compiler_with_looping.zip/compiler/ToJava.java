package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
import static esl.Tables.*;
// import static esl.Lists.*;
import static esl.compiler.Cases.*;
import static esl.compiler.Types.*;
import java.util.function.Supplier;
public class ToJava {
  public static ESLVal getSelf() { return $null; }
  private static ESLVal defToField = new ESLVal(new Function(new ESLVal("defToField"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d = $args[0];
  {ESLVal _v1998 = d;
        
        switch(_v1998.termName) {
        case "Binding": {ESLVal $2822 = _v1998.termRef(0);
          ESLVal $2821 = _v1998.termRef(1);
          ESLVal $2820 = _v1998.termRef(2);
          ESLVal $2819 = _v1998.termRef(3);
          ESLVal $2818 = _v1998.termRef(4);
          
          {ESLVal l = $2822;
          
          {ESLVal n = $2821;
          
          {ESLVal t = $2820;
          
          {ESLVal st = $2819;
          
          {ESLVal e = $2818;
          
          return new ESLVal("JField",n,$null,expToJExp.apply(e));
        }
        }
        }
        }
        }
        }
      case "FunBind": {ESLVal $2815 = _v1998.termRef(0);
          ESLVal $2814 = _v1998.termRef(1);
          ESLVal $2813 = _v1998.termRef(2);
          ESLVal $2812 = _v1998.termRef(3);
          ESLVal $2811 = _v1998.termRef(4);
          ESLVal $2810 = _v1998.termRef(5);
          ESLVal $2809 = _v1998.termRef(6);
          
          switch($2809.termName) {
          case "BoolExp": {ESLVal $2817 = $2809.termRef(0);
            ESLVal $2816 = $2809.termRef(1);
            
            switch($2816.boolVal ? 1 : 0) {
            case 1: {ESLVal l = $2815;
              
              {ESLVal n = $2814;
              
              {ESLVal args = $2813;
              
              {ESLVal t = $2812;
              
              {ESLVal st = $2811;
              
              {ESLVal e = $2810;
              
              {ESLVal bl = $2817;
              
              {ESLVal formals = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal $qualArg = $args[0];
                {ESLVal _v1999 = $qualArg;
                      
                      switch(_v1999.termName) {
                      case "PVar": {ESLVal $2825 = _v1999.termRef(0);
                        ESLVal $2824 = _v1999.termRef(1);
                        ESLVal $2823 = _v1999.termRef(2);
                        
                        {ESLVal _v2092 = $2825;
                        
                        {ESLVal _v2093 = $2824;
                        
                        {ESLVal _v2094 = $2823;
                        
                        return ESLVal.list(ESLVal.list(new ESLVal("Dec",_v2092,_v2093,_v2094,st)));
                      }
                      }
                      }
                      }
                      default: {ESLVal _0 = _v1999;
                        
                        return ESLVal.list();
                      }
                    }
                    }
                  }
                }).map(args).flatten().flatten();
              
              return new ESLVal("JField",n,$null,expToJExp.apply(new ESLVal("FunExp",l,new ESLVal("StrExp",l,n),formals,t,e)));
            }
            }
            }
            }
            }
            }
            }
            }
            default: {ESLVal l = $2815;
              
              {ESLVal n = $2814;
              
              {ESLVal args = $2813;
              
              {ESLVal t = $2812;
              
              {ESLVal st = $2811;
              
              {ESLVal e = $2810;
              
              {ESLVal g = $2809;
              
              {ESLVal formals = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal $qualArg = $args[0];
                {ESLVal _v2000 = $qualArg;
                      
                      switch(_v2000.termName) {
                      case "PVar": {ESLVal $2828 = _v2000.termRef(0);
                        ESLVal $2827 = _v2000.termRef(1);
                        ESLVal $2826 = _v2000.termRef(2);
                        
                        {ESLVal _v2095 = $2828;
                        
                        {ESLVal _v2096 = $2827;
                        
                        {ESLVal _v2097 = $2826;
                        
                        return ESLVal.list(ESLVal.list(new ESLVal("Dec",_v2095,_v2096,_v2097,st)));
                      }
                      }
                      }
                      }
                      default: {ESLVal _0 = _v2000;
                        
                        return ESLVal.list();
                      }
                    }
                    }
                  }
                }).map(args).flatten().flatten();
              
              return new ESLVal("JField",n,$null,expToJExp.apply(new ESLVal("FunExp",l,new ESLVal("StrExp",l,n),formals,t,new ESLVal("If",l,g,e,new ESLVal("Throw",l,t,new ESLVal("StrExp",l,new ESLVal("guard failed for ").add(n)))))));
            }
            }
            }
            }
            }
            }
            }
            }
          }
          }
          default: {ESLVal l = $2815;
            
            {ESLVal n = $2814;
            
            {ESLVal args = $2813;
            
            {ESLVal t = $2812;
            
            {ESLVal st = $2811;
            
            {ESLVal e = $2810;
            
            {ESLVal g = $2809;
            
            {ESLVal formals = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v2001 = $qualArg;
                    
                    switch(_v2001.termName) {
                    case "PVar": {ESLVal $2831 = _v2001.termRef(0);
                      ESLVal $2830 = _v2001.termRef(1);
                      ESLVal $2829 = _v2001.termRef(2);
                      
                      {ESLVal _v2098 = $2831;
                      
                      {ESLVal _v2099 = $2830;
                      
                      {ESLVal _v2100 = $2829;
                      
                      return ESLVal.list(ESLVal.list(new ESLVal("Dec",_v2098,_v2099,_v2100,st)));
                    }
                    }
                    }
                    }
                    default: {ESLVal _0 = _v2001;
                      
                      return ESLVal.list();
                    }
                  }
                  }
                }
              }).map(args).flatten().flatten();
            
            return new ESLVal("JField",n,$null,expToJExp.apply(new ESLVal("FunExp",l,new ESLVal("StrExp",l,n),formals,t,new ESLVal("If",l,g,e,new ESLVal("Throw",l,t,new ESLVal("StrExp",l,new ESLVal("guard failed for ").add(n)))))));
          }
          }
          }
          }
          }
          }
          }
          }
        }
        }
        default: return error(new ESLVal("case error at Pos(172,825)").add(ESLVal.list(_v1998)));
      }
      }
    }
  });
  private static ESLVal decToJDec = new ESLVal(new Function(new ESLVal("decToJDec"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d = $args[0];
  {ESLVal _v1997 = d;
        
        switch(_v1997.termName) {
        case "Dec": {ESLVal $2808 = _v1997.termRef(0);
          ESLVal $2807 = _v1997.termRef(1);
          ESLVal $2806 = _v1997.termRef(2);
          ESLVal $2805 = _v1997.termRef(3);
          
          {ESLVal l = $2808;
          
          {ESLVal n = $2807;
          
          {ESLVal t = $2806;
          
          {ESLVal st = $2805;
          
          return new ESLVal("JDec",n,$null);
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(869,945)").add(ESLVal.list(_v1997)));
      }
      }
    }
  });
  private static ESLVal expsToJCommands = new ESLVal(new Function(new ESLVal("expsToJCommands"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal cs = $args[0];
  ESLVal isLast = $args[1];
  {ESLVal _v1996 = cs;
        
        if(_v1996.isCons())
        {ESLVal $2801 = _v1996.head();
          ESLVal $2802 = _v1996.tail();
          
          if($2802.isCons())
          {ESLVal $2803 = $2802.head();
            ESLVal $2804 = $2802.tail();
            
            {ESLVal c = $2801;
            
            {ESLVal _v2090 = $2802;
            
            return expsToJCommands.apply(_v2090,isLast).cons(expToJCommand.apply(c,$false));
          }
          }
          }
        else if($2802.isNil())
          {ESLVal c = $2801;
            
            return ESLVal.list(expToJCommand.apply(c,isLast));
          }
        else {ESLVal c = $2801;
            
            {ESLVal _v2091 = $2802;
            
            return expsToJCommands.apply(_v2091,isLast).cons(expToJCommand.apply(c,$false));
          }
          }
        }
      else if(_v1996.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(1004,1164)").add(ESLVal.list(_v1996)));
      }
    }
  });
  private static ESLVal expToJCommand = new ESLVal(new Function(new ESLVal("expToJCommand"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal c = $args[0];
  ESLVal isLast = $args[1];
  {ESLVal _v1989 = c;
        
        switch(_v1989.termName) {
        case "Block": {ESLVal $2796 = _v1989.termRef(0);
          ESLVal $2795 = _v1989.termRef(1);
          
          if($2795.isCons())
          {ESLVal $2797 = $2795.head();
            ESLVal $2798 = $2795.tail();
            
            if($2798.isCons())
            {ESLVal $2799 = $2798.head();
              ESLVal $2800 = $2798.tail();
              
              {ESLVal l = $2796;
              
              {ESLVal es = $2795;
              
              return new ESLVal("JBlock",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v1993 = $qualArg;
                    
                    {ESLVal e = _v1993;
                    
                    return ESLVal.list(ESLVal.list(expToJCommand.apply(e,$false)));
                  }
                  }
                }
              }).map(butlast.apply(es)).flatten().flatten().add(ESLVal.list(expToJCommand.apply(last.apply(es),isLast))));
            }
            }
            }
          else if($2798.isNil())
            {ESLVal l = $2796;
              
              {ESLVal e = $2797;
              
              return expToJCommand.apply(e,isLast);
            }
            }
          else {ESLVal l = $2796;
              
              {ESLVal es = $2795;
              
              return new ESLVal("JBlock",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v1994 = $qualArg;
                    
                    {ESLVal e = _v1994;
                    
                    return ESLVal.list(ESLVal.list(expToJCommand.apply(e,$false)));
                  }
                  }
                }
              }).map(butlast.apply(es)).flatten().flatten().add(ESLVal.list(expToJCommand.apply(last.apply(es),isLast))));
            }
            }
          }
        else if($2795.isNil())
          {ESLVal l = $2796;
            
            if(isLast.boolVal)
            return new ESLVal("JReturn",new ESLVal("JNull",new ESLVal[]{}));
            else
              {ESLVal _v2088 = $2796;
                
                return new ESLVal("JBlock",$nil);
              }
          }
        else {ESLVal l = $2796;
            
            {ESLVal es = $2795;
            
            return new ESLVal("JBlock",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v1995 = $qualArg;
                  
                  {ESLVal e = _v1995;
                  
                  return ESLVal.list(ESLVal.list(expToJCommand.apply(e,$false)));
                }
                }
              }
            }).map(butlast.apply(es)).flatten().flatten().add(ESLVal.list(expToJCommand.apply(last.apply(es),isLast))));
          }
          }
        }
      case "Update": {ESLVal $2794 = _v1989.termRef(0);
          ESLVal $2793 = _v1989.termRef(1);
          ESLVal $2792 = _v1989.termRef(2);
          
          {ESLVal l = $2794;
          
          {ESLVal n = $2793;
          
          {ESLVal e = $2792;
          
          if(isLast.boolVal)
          return new ESLVal("JBlock",ESLVal.list(new ESLVal("JUpdate",n,expToJExp.apply(e)),new ESLVal("JReturn",new ESLVal("JNull",new ESLVal[]{}))));
          else
            {ESLVal _v2085 = $2794;
              
              {ESLVal _v2086 = $2793;
              
              {ESLVal _v2087 = $2792;
              
              return new ESLVal("JUpdate",_v2086,expToJExp.apply(_v2087));
            }
            }
            }
        }
        }
        }
        }
      case "If": {ESLVal $2791 = _v1989.termRef(0);
          ESLVal $2790 = _v1989.termRef(1);
          ESLVal $2789 = _v1989.termRef(2);
          ESLVal $2788 = _v1989.termRef(3);
          
          {ESLVal l = $2791;
          
          {ESLVal e1 = $2790;
          
          {ESLVal e2 = $2789;
          
          {ESLVal e3 = $2788;
          
          return new ESLVal("JIfCommand",expToJExp.apply(e1),expToJCommand.apply(e2,isLast),expToJCommand.apply(e3,isLast));
        }
        }
        }
        }
        }
      case "CaseList": {ESLVal $2787 = _v1989.termRef(0);
          ESLVal $2786 = _v1989.termRef(1);
          ESLVal $2785 = _v1989.termRef(2);
          ESLVal $2784 = _v1989.termRef(3);
          ESLVal $2783 = _v1989.termRef(4);
          
          {ESLVal l = $2787;
          
          {ESLVal e = $2786;
          
          {ESLVal cons = $2785;
          
          {ESLVal nil = $2784;
          
          {ESLVal alt = $2783;
          
          return new ESLVal("JCaseList",expToJExp.apply(e),expToJCommand.apply(cons,isLast),expToJCommand.apply(nil,isLast),expToJCommand.apply(alt,isLast));
        }
        }
        }
        }
        }
        }
      case "CaseTerm": {ESLVal $2782 = _v1989.termRef(0);
          ESLVal $2781 = _v1989.termRef(1);
          ESLVal $2780 = _v1989.termRef(2);
          ESLVal $2779 = _v1989.termRef(3);
          
          {ESLVal l = $2782;
          
          {ESLVal e = $2781;
          
          {ESLVal arms = $2780;
          
          {ESLVal alt = $2779;
          
          return new ESLVal("JCaseTerm",expToJExp.apply(e),termArmsToJTermArms.apply(arms,isLast),expToJCommand.apply(alt,isLast));
        }
        }
        }
        }
        }
      case "CaseInt": {ESLVal $2778 = _v1989.termRef(0);
          ESLVal $2777 = _v1989.termRef(1);
          ESLVal $2776 = _v1989.termRef(2);
          ESLVal $2775 = _v1989.termRef(3);
          
          {ESLVal l = $2778;
          
          {ESLVal e = $2777;
          
          {ESLVal arms = $2776;
          
          {ESLVal alt = $2775;
          
          return new ESLVal("JCaseInt",expToJExp.apply(e),intArmsToJIntArms.apply(arms,isLast),expToJCommand.apply(alt,isLast));
        }
        }
        }
        }
        }
      case "CaseStr": {ESLVal $2774 = _v1989.termRef(0);
          ESLVal $2773 = _v1989.termRef(1);
          ESLVal $2772 = _v1989.termRef(2);
          ESLVal $2771 = _v1989.termRef(3);
          
          {ESLVal l = $2774;
          
          {ESLVal e = $2773;
          
          {ESLVal arms = $2772;
          
          {ESLVal alt = $2771;
          
          return new ESLVal("JCaseStr",expToJExp.apply(e),strArmsToJStrArms.apply(arms,isLast),expToJCommand.apply(alt,isLast));
        }
        }
        }
        }
        }
      case "CaseBool": {ESLVal $2770 = _v1989.termRef(0);
          ESLVal $2769 = _v1989.termRef(1);
          ESLVal $2768 = _v1989.termRef(2);
          ESLVal $2767 = _v1989.termRef(3);
          
          {ESLVal l = $2770;
          
          {ESLVal e = $2769;
          
          {ESLVal arms = $2768;
          
          {ESLVal alt = $2767;
          
          return new ESLVal("JCaseBool",expToJExp.apply(e),boolArmsToJBoolArms.apply(arms,isLast),expToJCommand.apply(alt,isLast));
        }
        }
        }
        }
        }
      case "Let": {ESLVal $2766 = _v1989.termRef(0);
          ESLVal $2765 = _v1989.termRef(1);
          ESLVal $2764 = _v1989.termRef(2);
          
          {ESLVal l = $2766;
          
          {ESLVal bs = $2765;
          
          {ESLVal e = $2764;
          
          return new ESLVal("JLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1992 = $qualArg;
                
                {ESLVal b = _v1992;
                
                return ESLVal.list(ESLVal.list(defToField.apply(b)));
              }
              }
            }
          }).map(bs).flatten().flatten(),expToJCommand.apply(e,isLast));
        }
        }
        }
        }
      case "Letrec": {ESLVal $2763 = _v1989.termRef(0);
          ESLVal $2762 = _v1989.termRef(1);
          ESLVal $2761 = _v1989.termRef(2);
          
          {ESLVal l = $2763;
          
          {ESLVal bs = $2762;
          
          {ESLVal e = $2761;
          
          return new ESLVal("JLetRec",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1991 = $qualArg;
                
                {ESLVal b = _v1991;
                
                return ESLVal.list(ESLVal.list(defToField.apply(b)));
              }
              }
            }
          }).map(bs).flatten().flatten(),expToJCommand.apply(e,$true));
        }
        }
        }
        }
      case "For": {ESLVal $2757 = _v1989.termRef(0);
          ESLVal $2756 = _v1989.termRef(1);
          ESLVal $2755 = _v1989.termRef(2);
          ESLVal $2754 = _v1989.termRef(3);
          
          switch($2756.termName) {
          case "PVar": {ESLVal $2760 = $2756.termRef(0);
            ESLVal $2759 = $2756.termRef(1);
            ESLVal $2758 = $2756.termRef(2);
            
            {ESLVal l1 = $2757;
            
            {ESLVal l2 = $2760;
            
            {ESLVal n = $2759;
            
            {ESLVal t = $2758;
            
            {ESLVal e = $2755;
            
            {ESLVal b = $2754;
            
            if(isLast.boolVal)
            return new ESLVal("JBlock",ESLVal.list(new ESLVal("JFor",newName.apply(),n,expToJExp.apply(e),expToJCommand.apply(b,$false)),new ESLVal("JReturn",new ESLVal("JNull",new ESLVal[]{}))));
            else
              {ESLVal _v2079 = $2757;
                
                {ESLVal _v2080 = $2760;
                
                {ESLVal _v2081 = $2759;
                
                {ESLVal _v2082 = $2758;
                
                {ESLVal _v2083 = $2755;
                
                {ESLVal _v2084 = $2754;
                
                return new ESLVal("JFor",newName.apply(),_v2081,expToJExp.apply(_v2083),expToJCommand.apply(_v2084,$false));
              }
              }
              }
              }
              }
              }
          }
          }
          }
          }
          }
          }
          }
          default: {ESLVal l = $2757;
            
            {ESLVal p = $2756;
            
            {ESLVal e = $2755;
            
            {ESLVal b = $2754;
            
            {ESLVal opName = newName.apply();
            ESLVal varName = newName.apply();
            
            return expToJCommand.apply(new ESLVal("For",l,new ESLVal("PVar",l,varName,$null),e,new ESLVal("Let",l,ESLVal.list(new ESLVal("Binding",l,opName,$null,$null,new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("forp")),ESLVal.list(),$null,new ESLVal("Case",l,$nil,ESLVal.list(new ESLVal("Var",l,varName)),ESLVal.list(new ESLVal("BArm",l,ESLVal.list(p),new ESLVal("BoolExp",l,$true),b),new ESLVal("BArm",l,ESLVal.list(new ESLVal("PVar",l,new ESLVal("$$$"),$null)),new ESLVal("BoolExp",l,$true),new ESLVal("Block",l,ESLVal.list()))))))),new ESLVal("Apply",l,new ESLVal("Var",l,opName),ESLVal.list()))),isLast);
          }
          }
          }
          }
          }
        }
        }
      case "PLet": {ESLVal $2753 = _v1989.termRef(0);
          ESLVal $2752 = _v1989.termRef(1);
          ESLVal $2751 = _v1989.termRef(2);
          
          {ESLVal l = $2753;
          
          {ESLVal bs = $2752;
          
          {ESLVal e = $2751;
          
          return new ESLVal("JPLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1990 = $qualArg;
                
                {ESLVal b = _v1990;
                
                return ESLVal.list(ESLVal.list(defToField.apply(b)));
              }
              }
            }
          }).map(bs).flatten().flatten(),expToJCommand.apply(e,isLast));
        }
        }
        }
        }
        default: {ESLVal e = _v1989;
          
          if(isLast.boolVal)
          return new ESLVal("JReturn",expToJExp.apply(e));
          else
            {ESLVal _v2089 = _v1989;
              
              return new ESLVal("JStatement",expToJExp.apply(_v2089));
            }
        }
      }
      }
    }
  });
  private static ESLVal expsToJExps = new ESLVal(new Function(new ESLVal("expsToJExps"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal es = $args[0];
  return map.apply(new ESLVal(new Function(new ESLVal("fun936"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal e = $args[0];
        return expToJExp.apply(e);
          }
        }),es);
    }
  });
  private static ESLVal termArmsToJTermArms = new ESLVal(new Function(new ESLVal("termArmsToJTermArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  ESLVal isLast = $args[1];
  {ESLVal _v1988 = arms;
        
        if(_v1988.isCons())
        {ESLVal $2747 = _v1988.head();
          ESLVal $2748 = _v1988.tail();
          
          switch($2747.termName) {
          case "TArm": {ESLVal $2750 = $2747.termRef(0);
            ESLVal $2749 = $2747.termRef(1);
            
            {ESLVal n = $2750;
            
            {ESLVal e = $2749;
            
            {ESLVal _v2078 = $2748;
            
            return termArmsToJTermArms.apply(_v2078,isLast).cons(new ESLVal("JTArm",n,$zero,expToJCommand.apply(e,isLast)));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(4366,4535)").add(ESLVal.list(_v1988)));
        }
        }
      else if(_v1988.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(4366,4535)").add(ESLVal.list(_v1988)));
      }
    }
  });
  private static ESLVal intArmsToJIntArms = new ESLVal(new Function(new ESLVal("intArmsToJIntArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  ESLVal isLast = $args[1];
  {ESLVal _v1987 = arms;
        
        if(_v1987.isCons())
        {ESLVal $2743 = _v1987.head();
          ESLVal $2744 = _v1987.tail();
          
          switch($2743.termName) {
          case "IArm": {ESLVal $2746 = $2743.termRef(0);
            ESLVal $2745 = $2743.termRef(1);
            
            {ESLVal n = $2746;
            
            {ESLVal e = $2745;
            
            {ESLVal _v2077 = $2744;
            
            return intArmsToJIntArms.apply(_v2077,isLast).cons(new ESLVal("JIArm",n,expToJCommand.apply(e,isLast)));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(4604,4768)").add(ESLVal.list(_v1987)));
        }
        }
      else if(_v1987.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(4604,4768)").add(ESLVal.list(_v1987)));
      }
    }
  });
  private static ESLVal strArmsToJStrArms = new ESLVal(new Function(new ESLVal("strArmsToJStrArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  ESLVal isLast = $args[1];
  {ESLVal _v1986 = arms;
        
        if(_v1986.isCons())
        {ESLVal $2739 = _v1986.head();
          ESLVal $2740 = _v1986.tail();
          
          switch($2739.termName) {
          case "SArm": {ESLVal $2742 = $2739.termRef(0);
            ESLVal $2741 = $2739.termRef(1);
            
            {ESLVal s = $2742;
            
            {ESLVal e = $2741;
            
            {ESLVal _v2076 = $2740;
            
            return strArmsToJStrArms.apply(_v2076,isLast).cons(new ESLVal("JSArm",s,expToJCommand.apply(e,isLast)));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(4837,5001)").add(ESLVal.list(_v1986)));
        }
        }
      else if(_v1986.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(4837,5001)").add(ESLVal.list(_v1986)));
      }
    }
  });
  private static ESLVal boolArmsToJBoolArms = new ESLVal(new Function(new ESLVal("boolArmsToJBoolArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  ESLVal isLast = $args[1];
  {ESLVal _v1985 = arms;
        
        if(_v1985.isCons())
        {ESLVal $2735 = _v1985.head();
          ESLVal $2736 = _v1985.tail();
          
          switch($2735.termName) {
          case "BoolArm": {ESLVal $2738 = $2735.termRef(0);
            ESLVal $2737 = $2735.termRef(1);
            
            {ESLVal b = $2738;
            
            {ESLVal e = $2737;
            
            {ESLVal _v2075 = $2736;
            
            return boolArmsToJBoolArms.apply(_v2075,isLast).cons(new ESLVal("JBArm",b,expToJCommand.apply(e,isLast)));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(5076,5249)").add(ESLVal.list(_v1985)));
        }
        }
      else if(_v1985.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(5076,5249)").add(ESLVal.list(_v1985)));
      }
    }
  });
  private static ESLVal opToJOp = new ESLVal(new Function(new ESLVal("opToJOp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal op = $args[0];
  {ESLVal _v1984 = op;
        
        switch(_v1984.strVal) {
        case "@": return new ESLVal("at");
      case "+": return new ESLVal("add");
      case "-": return new ESLVal("sub");
      case "*": return new ESLVal("mul");
      case "/": return new ESLVal("div");
      case "%": return new ESLVal("mod");
      case ">": return new ESLVal("gre");
      case ">=": return new ESLVal("greql");
      case "<": return new ESLVal("less");
      case "<=": return new ESLVal("lesseql");
      case "=": return new ESLVal("eql");
      case "<>": return new ESLVal("neql");
      case ":": return new ESLVal("cons");
      case "..": return new ESLVal("to");
      case "or": return new ESLVal("or");
      case "and": return new ESLVal("and");
      case "andalso": return new ESLVal("andalso");
      case "orelse": return new ESLVal("orelse");
        default: return error(new ESLVal("case error at Pos(5277,5646)").add(ESLVal.list(_v1984)));
      }
      }
    }
  });
  private static ESLVal caseToJExp = new ESLVal(new Function(new ESLVal("caseToJExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  {ESLVal bindings = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1981 = $qualArg;
                
                {ESLVal e = _v1981;
                
                return ESLVal.list(ESLVal.list(new ESLVal("Binding",l,newName.apply(),$null,$null,e)));
              }
              }
            }
          }).map(es).flatten().flatten();
        
        {ESLVal names = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1982 = $qualArg;
                
                switch(_v1982.termName) {
                case "Binding": {ESLVal $2734 = _v1982.termRef(0);
                  ESLVal $2733 = _v1982.termRef(1);
                  ESLVal $2732 = _v1982.termRef(2);
                  ESLVal $2731 = _v1982.termRef(3);
                  ESLVal $2730 = _v1982.termRef(4);
                  
                  {ESLVal _v2074 = $2734;
                  
                  {ESLVal n = $2733;
                  
                  {ESLVal dt = $2732;
                  
                  {ESLVal t = $2731;
                  
                  {ESLVal e = $2730;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _0 = _v1982;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(bindings).flatten().flatten();
        
        return expToJExp.apply(new ESLVal("Let",l,bindings,translateCases.apply(new ESLVal("Case",l,ESLVal.list(),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v1983 = $qualArg;
              
              {ESLVal n = _v1983;
              
              return ESLVal.list(ESLVal.list(new ESLVal("Var",l,n)));
            }
            }
          }
        }).map(names).flatten().flatten(),arms))));
      }
      }
    }
  });
  private static ESLVal expToJExp = new ESLVal(new Function(new ESLVal("expToJExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  {ESLVal _v1978 = e;
        
        switch(_v1978.termName) {
        case "Apply": {ESLVal $2724 = _v1978.termRef(0);
          ESLVal $2723 = _v1978.termRef(1);
          ESLVal $2722 = _v1978.termRef(2);
          
          {ESLVal l = $2724;
          
          {ESLVal op = $2723;
          
          {ESLVal args = $2722;
          
          return new ESLVal("JApply",expToJExp.apply(op),expsToJExps.apply(args));
        }
        }
        }
        }
      case "ArrayUpdate": {ESLVal $2721 = _v1978.termRef(0);
          ESLVal $2720 = _v1978.termRef(1);
          ESLVal $2719 = _v1978.termRef(2);
          ESLVal $2718 = _v1978.termRef(3);
          
          {ESLVal l = $2721;
          
          {ESLVal a = $2720;
          
          {ESLVal i = $2719;
          
          {ESLVal v = $2718;
          
          return new ESLVal("JArrayUpdate",expToJExp.apply(a),expToJExp.apply(i),expToJExp.apply(v));
        }
        }
        }
        }
        }
      case "ArrayRef": {ESLVal $2717 = _v1978.termRef(0);
          ESLVal $2716 = _v1978.termRef(1);
          ESLVal $2715 = _v1978.termRef(2);
          
          {ESLVal l = $2717;
          
          {ESLVal a = $2716;
          
          {ESLVal i = $2715;
          
          return new ESLVal("JArrayRef",expToJExp.apply(a),expToJExp.apply(i));
        }
        }
        }
        }
      case "IntExp": {ESLVal $2714 = _v1978.termRef(0);
          ESLVal $2713 = _v1978.termRef(1);
          
          {ESLVal l = $2714;
          
          {ESLVal n = $2713;
          
          return new ESLVal("JConstExp",new ESLVal("JConstInt",n));
        }
        }
        }
      case "StrExp": {ESLVal $2712 = _v1978.termRef(0);
          ESLVal $2711 = _v1978.termRef(1);
          
          {ESLVal l = $2712;
          
          {ESLVal s = $2711;
          
          return new ESLVal("JConstExp",new ESLVal("JConstStr",s));
        }
        }
        }
      case "BoolExp": {ESLVal $2710 = _v1978.termRef(0);
          ESLVal $2709 = _v1978.termRef(1);
          
          {ESLVal l = $2710;
          
          {ESLVal b = $2709;
          
          return new ESLVal("JConstExp",new ESLVal("JConstBool",b));
        }
        }
        }
      case "FloatExp": {ESLVal $2708 = _v1978.termRef(0);
          ESLVal $2707 = _v1978.termRef(1);
          
          {ESLVal l = $2708;
          
          {ESLVal f = $2707;
          
          return new ESLVal("JConstExp",new ESLVal("JConstDouble",f));
        }
        }
        }
      case "ApplyTypeExp": {ESLVal $2693 = _v1978.termRef(0);
          ESLVal $2692 = _v1978.termRef(1);
          ESLVal $2691 = _v1978.termRef(2);
          
          switch($2692.termName) {
          case "List": {ESLVal $2700 = $2692.termRef(0);
            ESLVal $2699 = $2692.termRef(1);
            
            if($2699.isCons())
            {ESLVal $2701 = $2699.head();
              ESLVal $2702 = $2699.tail();
              
              {ESLVal l = $2693;
              
              {ESLVal _v2067 = $2692;
              
              {ESLVal ts = $2691;
              
              return expToJExp.apply(_v2067);
            }
            }
            }
            }
          else if($2699.isNil())
            if($2691.isCons())
              {ESLVal $2703 = $2691.head();
                ESLVal $2704 = $2691.tail();
                
                if($2704.isCons())
                {ESLVal $2705 = $2704.head();
                  ESLVal $2706 = $2704.tail();
                  
                  {ESLVal l = $2693;
                  
                  {ESLVal _v2068 = $2692;
                  
                  {ESLVal ts = $2691;
                  
                  return expToJExp.apply(_v2068);
                }
                }
                }
                }
              else if($2704.isNil())
                {ESLVal l1 = $2693;
                  
                  {ESLVal l2 = $2700;
                  
                  {ESLVal t = $2703;
                  
                  return new ESLVal("JNil",$null);
                }
                }
                }
              else {ESLVal l = $2693;
                  
                  {ESLVal _v2069 = $2692;
                  
                  {ESLVal ts = $2691;
                  
                  return expToJExp.apply(_v2069);
                }
                }
                }
              }
            else if($2691.isNil())
              {ESLVal l = $2693;
                
                {ESLVal _v2070 = $2692;
                
                {ESLVal ts = $2691;
                
                return expToJExp.apply(_v2070);
              }
              }
              }
            else {ESLVal l = $2693;
                
                {ESLVal _v2071 = $2692;
                
                {ESLVal ts = $2691;
                
                return expToJExp.apply(_v2071);
              }
              }
              }
          else {ESLVal l = $2693;
              
              {ESLVal _v2072 = $2692;
              
              {ESLVal ts = $2691;
              
              return expToJExp.apply(_v2072);
            }
            }
            }
          }
        case "NullExp": {ESLVal $2694 = $2692.termRef(0);
            
            if($2691.isCons())
            {ESLVal $2695 = $2691.head();
              ESLVal $2696 = $2691.tail();
              
              if($2696.isCons())
              {ESLVal $2697 = $2696.head();
                ESLVal $2698 = $2696.tail();
                
                {ESLVal l = $2693;
                
                {ESLVal _v2063 = $2692;
                
                {ESLVal ts = $2691;
                
                return expToJExp.apply(_v2063);
              }
              }
              }
              }
            else if($2696.isNil())
              {ESLVal l1 = $2693;
                
                {ESLVal l2 = $2694;
                
                {ESLVal t = $2695;
                
                return new ESLVal("JNull",new ESLVal[]{});
              }
              }
              }
            else {ESLVal l = $2693;
                
                {ESLVal _v2064 = $2692;
                
                {ESLVal ts = $2691;
                
                return expToJExp.apply(_v2064);
              }
              }
              }
            }
          else if($2691.isNil())
            {ESLVal l = $2693;
              
              {ESLVal _v2065 = $2692;
              
              {ESLVal ts = $2691;
              
              return expToJExp.apply(_v2065);
            }
            }
            }
          else {ESLVal l = $2693;
              
              {ESLVal _v2066 = $2692;
              
              {ESLVal ts = $2691;
              
              return expToJExp.apply(_v2066);
            }
            }
            }
          }
          default: {ESLVal l = $2693;
            
            {ESLVal _v2073 = $2692;
            
            {ESLVal ts = $2691;
            
            return expToJExp.apply(_v2073);
          }
          }
          }
        }
        }
      case "List": {ESLVal $2690 = _v1978.termRef(0);
          ESLVal $2689 = _v1978.termRef(1);
          
          {ESLVal l = $2690;
          
          {ESLVal es = $2689;
          
          return new ESLVal("JList",$null,expsToJExps.apply(es));
        }
        }
        }
      case "SetExp": {ESLVal $2688 = _v1978.termRef(0);
          ESLVal $2687 = _v1978.termRef(1);
          
          {ESLVal l = $2688;
          
          {ESLVal es = $2687;
          
          return new ESLVal("JSet",$null,expsToJExps.apply(es));
        }
        }
        }
      case "BagExp": {ESLVal $2686 = _v1978.termRef(0);
          ESLVal $2685 = _v1978.termRef(1);
          
          {ESLVal l = $2686;
          
          {ESLVal es = $2685;
          
          return new ESLVal("JBag",$null,expsToJExps.apply(es));
        }
        }
        }
      case "Term": {ESLVal $2684 = _v1978.termRef(0);
          ESLVal $2683 = _v1978.termRef(1);
          ESLVal $2682 = _v1978.termRef(2);
          ESLVal $2681 = _v1978.termRef(3);
          
          {ESLVal l = $2684;
          
          {ESLVal n = $2683;
          
          {ESLVal ts = $2682;
          
          {ESLVal es = $2681;
          
          return new ESLVal("JTerm",n,expsToJExps.apply(es));
        }
        }
        }
        }
        }
      case "Case": {ESLVal $2680 = _v1978.termRef(0);
          ESLVal $2679 = _v1978.termRef(1);
          ESLVal $2678 = _v1978.termRef(2);
          ESLVal $2677 = _v1978.termRef(3);
          
          {ESLVal l = $2680;
          
          {ESLVal ds = $2679;
          
          {ESLVal es = $2678;
          
          {ESLVal arms = $2677;
          
          return caseToJExp.apply(l,es,arms);
        }
        }
        }
        }
        }
      case "CaseAdd": {ESLVal $2676 = _v1978.termRef(0);
          ESLVal $2675 = _v1978.termRef(1);
          ESLVal $2674 = _v1978.termRef(2);
          ESLVal $2673 = _v1978.termRef(3);
          
          {ESLVal l = $2676;
          
          {ESLVal s = $2675;
          
          {ESLVal handler = $2674;
          
          {ESLVal fail = $2673;
          
          return expToJExp.apply(new ESLVal("Apply",l,new ESLVal("Var",l,new ESLVal("$ndCase")),ESLVal.list(s,handler,fail)));
        }
        }
        }
        }
        }
      case "CaseList": {ESLVal $2672 = _v1978.termRef(0);
          ESLVal $2671 = _v1978.termRef(1);
          ESLVal $2670 = _v1978.termRef(2);
          ESLVal $2669 = _v1978.termRef(3);
          ESLVal $2668 = _v1978.termRef(4);
          
          {ESLVal l = $2672;
          
          {ESLVal list = $2671;
          
          {ESLVal cons = $2670;
          
          {ESLVal nil = $2669;
          
          {ESLVal alt = $2668;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
        }
        }
      case "CaseTerm": {ESLVal $2667 = _v1978.termRef(0);
          ESLVal $2666 = _v1978.termRef(1);
          ESLVal $2665 = _v1978.termRef(2);
          ESLVal $2664 = _v1978.termRef(3);
          
          {ESLVal l = $2667;
          
          {ESLVal list = $2666;
          
          {ESLVal arms = $2665;
          
          {ESLVal alt = $2664;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
        }
      case "CaseStr": {ESLVal $2663 = _v1978.termRef(0);
          ESLVal $2662 = _v1978.termRef(1);
          ESLVal $2661 = _v1978.termRef(2);
          ESLVal $2660 = _v1978.termRef(3);
          
          {ESLVal l = $2663;
          
          {ESLVal s = $2662;
          
          {ESLVal arms = $2661;
          
          {ESLVal alt = $2660;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
        }
      case "CaseBool": {ESLVal $2659 = _v1978.termRef(0);
          ESLVal $2658 = _v1978.termRef(1);
          ESLVal $2657 = _v1978.termRef(2);
          ESLVal $2656 = _v1978.termRef(3);
          
          {ESLVal l = $2659;
          
          {ESLVal s = $2658;
          
          {ESLVal arms = $2657;
          
          {ESLVal alt = $2656;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
        }
      case "CaseSet": {ESLVal $2655 = _v1978.termRef(0);
          ESLVal $2654 = _v1978.termRef(1);
          ESLVal $2653 = _v1978.termRef(2);
          ESLVal $2652 = _v1978.termRef(3);
          
          {ESLVal l = $2655;
          
          {ESLVal s = $2654;
          
          {ESLVal handler = $2653;
          
          {ESLVal fail = $2652;
          
          return expToJExp.apply(new ESLVal("Apply",l,new ESLVal("Var",l,new ESLVal("$ndCase")),ESLVal.list(s,handler,fail)));
        }
        }
        }
        }
        }
      case "Head": {ESLVal $2651 = _v1978.termRef(0);
          
          {ESLVal _v2062 = $2651;
          
          return new ESLVal("JHead",expToJExp.apply(_v2062));
        }
        }
      case "Tail": {ESLVal $2650 = _v1978.termRef(0);
          
          {ESLVal _v2061 = $2650;
          
          return new ESLVal("JTail",expToJExp.apply(_v2061));
        }
        }
      case "CaseError": {ESLVal $2649 = _v1978.termRef(0);
          ESLVal $2648 = _v1978.termRef(1);
          
          {ESLVal l = $2649;
          
          {ESLVal _v2060 = $2648;
          
          return new ESLVal("JError",new ESLVal("JBinExp",new ESLVal("JConstExp",new ESLVal("JConstStr",new ESLVal("case error at ").add(l))),new ESLVal("add"),expToJExp.apply(_v2060)));
        }
        }
        }
      case "NullExp": {ESLVal $2647 = _v1978.termRef(0);
          
          {ESLVal l = $2647;
          
          return new ESLVal("JNull",new ESLVal[]{});
        }
        }
      case "Var": {ESLVal $2646 = _v1978.termRef(0);
          ESLVal $2645 = _v1978.termRef(1);
          
          {ESLVal l = $2646;
          
          {ESLVal n = $2645;
          
          return new ESLVal("JVar",n,$null);
        }
        }
        }
      case "Let": {ESLVal $2644 = _v1978.termRef(0);
          ESLVal $2643 = _v1978.termRef(1);
          ESLVal $2642 = _v1978.termRef(2);
          
          {ESLVal l = $2644;
          
          {ESLVal bs = $2643;
          
          {ESLVal body = $2642;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
      case "Letrec": {ESLVal $2641 = _v1978.termRef(0);
          ESLVal $2640 = _v1978.termRef(1);
          ESLVal $2639 = _v1978.termRef(2);
          
          {ESLVal l = $2641;
          
          {ESLVal bs = $2640;
          
          {ESLVal body = $2639;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
      case "Throw": {ESLVal $2638 = _v1978.termRef(0);
          ESLVal $2637 = _v1978.termRef(1);
          ESLVal $2636 = _v1978.termRef(2);
          
          {ESLVal l = $2638;
          
          {ESLVal t = $2637;
          
          {ESLVal _v2059 = $2636;
          
          return new ESLVal("JError",expToJExp.apply(_v2059));
        }
        }
        }
        }
      case "BinExp": {ESLVal $2635 = _v1978.termRef(0);
          ESLVal $2634 = _v1978.termRef(1);
          ESLVal $2633 = _v1978.termRef(2);
          ESLVal $2632 = _v1978.termRef(3);
          
          {ESLVal l = $2635;
          
          {ESLVal e1 = $2634;
          
          {ESLVal op = $2633;
          
          {ESLVal e2 = $2632;
          
          return new ESLVal("JBinExp",expToJExp.apply(e1),opToJOp.apply(op),expToJExp.apply(e2));
        }
        }
        }
        }
        }
      case "Become": {ESLVal $2628 = _v1978.termRef(0);
          ESLVal $2627 = _v1978.termRef(1);
          
          switch($2627.termName) {
          case "Apply": {ESLVal $2631 = $2627.termRef(0);
            ESLVal $2630 = $2627.termRef(1);
            ESLVal $2629 = $2627.termRef(2);
            
            {ESLVal l = $2628;
            
            {ESLVal al = $2631;
            
            {ESLVal b = $2630;
            
            {ESLVal args = $2629;
            
            return new ESLVal("JBecome",expToJExp.apply(b),expsToJExps.apply(args));
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(6004,14628)").add(ESLVal.list(_v1978)));
        }
        }
      case "Block": {ESLVal $2622 = _v1978.termRef(0);
          ESLVal $2621 = _v1978.termRef(1);
          
          if($2621.isCons())
          {ESLVal $2623 = $2621.head();
            ESLVal $2624 = $2621.tail();
            
            if($2624.isCons())
            {ESLVal $2625 = $2624.head();
              ESLVal $2626 = $2624.tail();
              
              {ESLVal l = $2622;
              
              {ESLVal es = $2621;
              
              return new ESLVal("JCommandExp",new ESLVal("JBlock",expsToJCommands.apply(es,$true)),$null);
            }
            }
            }
          else if($2624.isNil())
            {ESLVal l = $2622;
              
              {ESLVal _v2058 = $2623;
              
              return expToJExp.apply(_v2058);
            }
            }
          else {ESLVal l = $2622;
              
              {ESLVal es = $2621;
              
              return new ESLVal("JCommandExp",new ESLVal("JBlock",expsToJCommands.apply(es,$true)),$null);
            }
            }
          }
        else if($2621.isNil())
          {ESLVal l = $2622;
            
            return new ESLVal("JNull",new ESLVal[]{});
          }
        else {ESLVal l = $2622;
            
            {ESLVal es = $2621;
            
            return new ESLVal("JCommandExp",new ESLVal("JBlock",expsToJCommands.apply(es,$true)),$null);
          }
          }
        }
      case "If": {ESLVal $2620 = _v1978.termRef(0);
          ESLVal $2619 = _v1978.termRef(1);
          ESLVal $2618 = _v1978.termRef(2);
          ESLVal $2617 = _v1978.termRef(3);
          
          {ESLVal l = $2620;
          
          {ESLVal e1 = $2619;
          
          {ESLVal e2 = $2618;
          
          {ESLVal e3 = $2617;
          
          return new ESLVal("JCommandExp",new ESLVal("JIfCommand",expToJExp.apply(e1),expToJCommand.apply(e2,$true),expToJCommand.apply(e3,$true)),$null);
        }
        }
        }
        }
        }
      case "FunExp": {ESLVal $2616 = _v1978.termRef(0);
          ESLVal $2615 = _v1978.termRef(1);
          ESLVal $2614 = _v1978.termRef(2);
          ESLVal $2613 = _v1978.termRef(3);
          ESLVal $2612 = _v1978.termRef(4);
          
          {ESLVal l = $2616;
          
          {ESLVal n = $2615;
          
          {ESLVal args = $2614;
          
          {ESLVal t = $2613;
          
          {ESLVal body = $2612;
          
          return new ESLVal("JFun",expToJExp.apply(n),map.apply(new ESLVal(new Function(new ESLVal("fun937"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal d = $args[0];
          return decToJDec.apply(d);
            }
          }),args),new ESLVal("JFunType",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1980 = $qualArg;
                
                {ESLVal a = _v1980;
                
                return ESLVal.list(ESLVal.list($null));
              }
              }
            }
          }).map(args).flatten().flatten(),$null),expToJCommand.apply(body,$true));
        }
        }
        }
        }
        }
        }
      case "TermRef": {ESLVal $2611 = _v1978.termRef(0);
          ESLVal $2610 = _v1978.termRef(1);
          
          {ESLVal _v2057 = $2611;
          
          {ESLVal i = $2610;
          
          return new ESLVal("JTermRef",expToJExp.apply(_v2057),i);
        }
        }
        }
      case "Cmp": {ESLVal $2609 = _v1978.termRef(0);
          ESLVal $2608 = _v1978.termRef(1);
          ESLVal $2607 = _v1978.termRef(2);
          
          {ESLVal l = $2609;
          
          {ESLVal _v2053 = $2608;
          
          {ESLVal qs = $2607;
          
          if(exists.apply(isBindingQualifier,qs).and(forall.apply(isSimpleQualifier,qs)).boolVal)
          return new ESLVal("JCmpExp",cmpToJCmp.apply(_v2053,qs));
          else
            {ESLVal _v2054 = $2609;
              
              {ESLVal _v2055 = $2608;
              
              {ESLVal _v2056 = $2607;
              
              return cmpToJExp.apply(_v2055,_v2056);
            }
            }
            }
        }
        }
        }
        }
      case "Not": {ESLVal $2606 = _v1978.termRef(0);
          ESLVal $2605 = _v1978.termRef(1);
          
          {ESLVal l = $2606;
          
          {ESLVal _v2052 = $2605;
          
          return new ESLVal("JNot",expToJExp.apply(_v2052));
        }
        }
        }
      case "New": {ESLVal $2604 = _v1978.termRef(0);
          ESLVal $2603 = _v1978.termRef(1);
          ESLVal $2602 = _v1978.termRef(2);
          
          {ESLVal l = $2604;
          
          {ESLVal b = $2603;
          
          {ESLVal args = $2602;
          
          return new ESLVal("JNew",expToJExp.apply(b),expsToJExps.apply(args));
        }
        }
        }
        }
      case "NewArray": {ESLVal $2601 = _v1978.termRef(0);
          ESLVal $2600 = _v1978.termRef(1);
          ESLVal $2599 = _v1978.termRef(2);
          
          {ESLVal l = $2601;
          
          {ESLVal t = $2600;
          
          {ESLVal i = $2599;
          
          return new ESLVal("JNewArray",expToJExp.apply(i));
        }
        }
        }
        }
      case "NewJava": {ESLVal $2598 = _v1978.termRef(0);
          ESLVal $2597 = _v1978.termRef(1);
          ESLVal $2596 = _v1978.termRef(2);
          ESLVal $2595 = _v1978.termRef(3);
          
          {ESLVal l = $2598;
          
          {ESLVal n = $2597;
          
          {ESLVal t = $2596;
          
          {ESLVal args = $2595;
          
          return new ESLVal("JNewJava",n,expsToJExps.apply(args));
        }
        }
        }
        }
        }
      case "NewTable": {ESLVal $2594 = _v1978.termRef(0);
          ESLVal $2593 = _v1978.termRef(1);
          ESLVal $2592 = _v1978.termRef(2);
          
          {ESLVal l = $2594;
          
          {ESLVal key = $2593;
          
          {ESLVal value = $2592;
          
          return new ESLVal("JNewTable",new ESLVal[]{});
        }
        }
        }
        }
      case "Record": {ESLVal $2591 = _v1978.termRef(0);
          ESLVal $2590 = _v1978.termRef(1);
          
          {ESLVal l = $2591;
          
          {ESLVal fs = $2590;
          
          return new ESLVal("JRecord",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1979 = $qualArg;
                
                switch(_v1979.termName) {
                case "Binding": {ESLVal $2729 = _v1979.termRef(0);
                  ESLVal $2728 = _v1979.termRef(1);
                  ESLVal $2727 = _v1979.termRef(2);
                  ESLVal $2726 = _v1979.termRef(3);
                  ESLVal $2725 = _v1979.termRef(4);
                  
                  {ESLVal bl = $2729;
                  
                  {ESLVal n = $2728;
                  
                  {ESLVal t = $2727;
                  
                  {ESLVal dt = $2726;
                  
                  {ESLVal _v2051 = $2725;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",n,$null,expToJExp.apply(_v2051))));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _0 = _v1979;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten());
        }
        }
        }
      case "Send": {ESLVal $2585 = _v1978.termRef(0);
          ESLVal $2584 = _v1978.termRef(1);
          ESLVal $2583 = _v1978.termRef(2);
          
          switch($2583.termName) {
          case "Term": {ESLVal $2589 = $2583.termRef(0);
            ESLVal $2588 = $2583.termRef(1);
            ESLVal $2587 = $2583.termRef(2);
            ESLVal $2586 = $2583.termRef(3);
            
            {ESLVal l = $2585;
            
            {ESLVal a = $2584;
            
            {ESLVal lt = $2589;
            
            {ESLVal n = $2588;
            
            {ESLVal ts = $2587;
            
            {ESLVal es = $2586;
            
            return new ESLVal("JSend",expToJExp.apply(a),n,expsToJExps.apply(es));
          }
          }
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(6004,14628)").add(ESLVal.list(_v1978)));
        }
        }
      case "SendTimeSuper": {ESLVal $2582 = _v1978.termRef(0);
          
          {ESLVal l = $2582;
          
          return new ESLVal("JSendTimeSuper",new ESLVal[]{});
        }
        }
      case "SendSuper": {ESLVal $2581 = _v1978.termRef(0);
          ESLVal $2580 = _v1978.termRef(1);
          
          {ESLVal l = $2581;
          
          {ESLVal _v2050 = $2580;
          
          return new ESLVal("JSendSuper",expToJExp.apply(_v2050));
        }
        }
        }
      case "Self": {ESLVal $2579 = _v1978.termRef(0);
          
          {ESLVal l = $2579;
          
          return new ESLVal("JSelf",new ESLVal[]{});
        }
        }
      case "Fold": {ESLVal $2578 = _v1978.termRef(0);
          ESLVal $2577 = _v1978.termRef(1);
          ESLVal $2576 = _v1978.termRef(2);
          
          {ESLVal l = $2578;
          
          {ESLVal t = $2577;
          
          {ESLVal _v2049 = $2576;
          
          return expToJExp.apply(_v2049);
        }
        }
        }
        }
      case "Now": {ESLVal $2575 = _v1978.termRef(0);
          
          {ESLVal l = $2575;
          
          return new ESLVal("JNow",new ESLVal[]{});
        }
        }
      case "Ref": {ESLVal $2574 = _v1978.termRef(0);
          ESLVal $2573 = _v1978.termRef(1);
          ESLVal $2572 = _v1978.termRef(2);
          
          {ESLVal l = $2574;
          
          {ESLVal _v2048 = $2573;
          
          {ESLVal n = $2572;
          
          return new ESLVal("JRef",expToJExp.apply(_v2048),n);
        }
        }
        }
        }
      case "RefSuper": {ESLVal $2571 = _v1978.termRef(0);
          ESLVal $2570 = _v1978.termRef(1);
          
          {ESLVal l = $2571;
          
          {ESLVal n = $2570;
          
          return new ESLVal("JRefSuper",n);
        }
        }
        }
      case "For": {ESLVal $2569 = _v1978.termRef(0);
          ESLVal $2568 = _v1978.termRef(1);
          ESLVal $2567 = _v1978.termRef(2);
          ESLVal $2566 = _v1978.termRef(3);
          
          {ESLVal l1 = $2569;
          
          {ESLVal p = $2568;
          
          {ESLVal l2 = $2567;
          
          {ESLVal c = $2566;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
        }
      case "Grab": {ESLVal $2565 = _v1978.termRef(0);
          ESLVal $2564 = _v1978.termRef(1);
          ESLVal $2563 = _v1978.termRef(2);
          
          {ESLVal l = $2565;
          
          {ESLVal refs = $2564;
          
          {ESLVal _v2047 = $2563;
          
          return new ESLVal("JGrab",refsToJExps.apply(refs),expToJExp.apply(_v2047));
        }
        }
        }
        }
      case "Update": {ESLVal $2562 = _v1978.termRef(0);
          ESLVal $2561 = _v1978.termRef(1);
          ESLVal $2560 = _v1978.termRef(2);
          
          {ESLVal l = $2562;
          
          {ESLVal n = $2561;
          
          {ESLVal v = $2560;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
      case "Probably": {ESLVal $2559 = _v1978.termRef(0);
          ESLVal $2558 = _v1978.termRef(1);
          ESLVal $2557 = _v1978.termRef(2);
          ESLVal $2556 = _v1978.termRef(3);
          ESLVal $2555 = _v1978.termRef(4);
          
          {ESLVal l = $2559;
          
          {ESLVal _v2046 = $2558;
          
          {ESLVal t = $2557;
          
          {ESLVal e1 = $2556;
          
          {ESLVal e2 = $2555;
          
          return new ESLVal("JProbably",expToJExp.apply(_v2046),expToJExp.apply(e1),expToJExp.apply(e2));
        }
        }
        }
        }
        }
        }
      case "Try": {ESLVal $2554 = _v1978.termRef(0);
          ESLVal $2553 = _v1978.termRef(1);
          ESLVal $2552 = _v1978.termRef(2);
          
          {ESLVal l = $2554;
          
          {ESLVal _v2045 = $2553;
          
          {ESLVal arms = $2552;
          
          return new ESLVal("JTry",expToJExp.apply(_v2045),new ESLVal("$x"),expToJCommand.apply(new ESLVal("Case",l,$nil,ESLVal.list(new ESLVal("Var",l,new ESLVal("$x"))),arms),$true));
        }
        }
        }
        }
      case "ActExp": {ESLVal $2551 = _v1978.termRef(0);
          ESLVal $2550 = _v1978.termRef(1);
          ESLVal $2549 = _v1978.termRef(2);
          ESLVal $2548 = _v1978.termRef(3);
          ESLVal $2547 = _v1978.termRef(4);
          ESLVal $2546 = _v1978.termRef(5);
          ESLVal $2545 = _v1978.termRef(6);
          ESLVal $2544 = _v1978.termRef(7);
          
          {ESLVal l = $2551;
          
          {ESLVal name = $2550;
          
          {ESLVal decs = $2549;
          
          {ESLVal exports = $2548;
          
          {ESLVal parent = $2547;
          
          {ESLVal defs = $2546;
          
          {ESLVal init = $2545;
          
          {ESLVal arms = $2544;
          
          return actToJava.apply(name,decs,exports,parent,defs,init,arms);
        }
        }
        }
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(6004,14628)").add(ESLVal.list(_v1978)));
      }
      }
    }
  });
  private static ESLVal isSimpleQualifier = new ESLVal(new Function(new ESLVal("isSimpleQualifier"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal q = $args[0];
  {ESLVal _v1977 = q;
        
        switch(_v1977.termName) {
        case "BQual": {ESLVal $2540 = _v1977.termRef(0);
          ESLVal $2539 = _v1977.termRef(1);
          ESLVal $2538 = _v1977.termRef(2);
          
          switch($2539.termName) {
          case "PVar": {ESLVal $2543 = $2539.termRef(0);
            ESLVal $2542 = $2539.termRef(1);
            ESLVal $2541 = $2539.termRef(2);
            
            {ESLVal l = $2540;
            
            {ESLVal vl = $2543;
            
            {ESLVal n = $2542;
            
            {ESLVal t = $2541;
            
            {ESLVal e = $2538;
            
            return $true;
          }
          }
          }
          }
          }
          }
          default: {ESLVal l = $2540;
            
            {ESLVal p = $2539;
            
            {ESLVal e = $2538;
            
            return $false;
          }
          }
          }
        }
        }
        default: {ESLVal _v2044 = _v1977;
          
          return $true;
        }
      }
      }
    }
  });
  private static ESLVal isBindingQualifier = new ESLVal(new Function(new ESLVal("isBindingQualifier"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal q = $args[0];
  {ESLVal _v1976 = q;
        
        switch(_v1976.termName) {
        case "BQual": {ESLVal $2537 = _v1976.termRef(0);
          ESLVal $2536 = _v1976.termRef(1);
          ESLVal $2535 = _v1976.termRef(2);
          
          {ESLVal l = $2537;
          
          {ESLVal p = $2536;
          
          {ESLVal e = $2535;
          
          return $true;
        }
        }
        }
        }
        default: {ESLVal _v2043 = _v1976;
          
          return $false;
        }
      }
      }
    }
  });
  private static ESLVal cmpToJCmp = new ESLVal(new Function(new ESLVal("cmpToJCmp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  ESLVal qs = $args[1];
  LetRec letrec = new LetRec() {
        ESLVal inner = new ESLVal(new Function(new ESLVal("inner"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v2038 = $args[0];
          {ESLVal _v1974 = _v2038;
                
                if(_v1974.isCons())
                {ESLVal $2515 = _v1974.head();
                  ESLVal $2516 = _v1974.tail();
                  
                  switch($2515.termName) {
                  case "BQual": {ESLVal $2521 = $2515.termRef(0);
                    ESLVal $2520 = $2515.termRef(1);
                    ESLVal $2519 = $2515.termRef(2);
                    
                    switch($2520.termName) {
                    case "PVar": {ESLVal $2524 = $2520.termRef(0);
                      ESLVal $2523 = $2520.termRef(1);
                      ESLVal $2522 = $2520.termRef(2);
                      
                      {ESLVal l = $2521;
                      
                      {ESLVal vl = $2524;
                      
                      {ESLVal n = $2523;
                      
                      {ESLVal t = $2522;
                      
                      {ESLVal listExp = $2519;
                      
                      {ESLVal _v2040 = $2516;
                      
                      return new ESLVal("JCmpBind",n,expToJExp.apply(listExp),inner.apply(_v2040));
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: return error(new ESLVal("case error at Pos(15031,15229)").add(ESLVal.list(_v1974)));
                  }
                  }
                case "PQual": {ESLVal $2518 = $2515.termRef(0);
                    ESLVal $2517 = $2515.termRef(1);
                    
                    {ESLVal l = $2518;
                    
                    {ESLVal p = $2517;
                    
                    {ESLVal _v2039 = $2516;
                    
                    return new ESLVal("JCmpIf",expToJExp.apply(p),inner.apply(_v2039));
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(15031,15229)").add(ESLVal.list(_v1974)));
                }
                }
              else if(_v1974.isNil())
                return new ESLVal("JCmpList",expToJExp.apply(e));
              else return error(new ESLVal("case error at Pos(15031,15229)").add(ESLVal.list(_v1974)));
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "inner": return inner;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal inner = letrec.get("inner");
      
        {ESLVal _v1975 = qs;
        
        if(_v1975.isCons())
        {ESLVal $2525 = _v1975.head();
          ESLVal $2526 = _v1975.tail();
          
          switch($2525.termName) {
          case "BQual": {ESLVal $2531 = $2525.termRef(0);
            ESLVal $2530 = $2525.termRef(1);
            ESLVal $2529 = $2525.termRef(2);
            
            switch($2530.termName) {
            case "PVar": {ESLVal $2534 = $2530.termRef(0);
              ESLVal $2533 = $2530.termRef(1);
              ESLVal $2532 = $2530.termRef(2);
              
              {ESLVal l = $2531;
              
              {ESLVal vl = $2534;
              
              {ESLVal n = $2533;
              
              {ESLVal t = $2532;
              
              {ESLVal listExp = $2529;
              
              {ESLVal _v2042 = $2526;
              
              return new ESLVal("JCmpOuter",n,expToJExp.apply(listExp),inner.apply(_v2042));
            }
            }
            }
            }
            }
            }
            }
            default: return error(new ESLVal("case error at Pos(15241,15438)").add(ESLVal.list(_v1975)));
          }
          }
        case "PQual": {ESLVal $2528 = $2525.termRef(0);
            ESLVal $2527 = $2525.termRef(1);
            
            {ESLVal l = $2528;
            
            {ESLVal p = $2527;
            
            {ESLVal _v2041 = $2526;
            
            return new ESLVal("JCmpIf",expToJExp.apply(p),cmpToJCmp.apply(e,_v2041));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(15241,15438)").add(ESLVal.list(_v1975)));
        }
        }
      else if(_v1975.isNil())
        return new ESLVal("JCmpList",expToJExp.apply(e));
      else return error(new ESLVal("case error at Pos(15241,15438)").add(ESLVal.list(_v1975)));
      }
      
    }
  });
  private static ESLVal refsToJExps = new ESLVal(new Function(new ESLVal("refsToJExps"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal refs = $args[0];
  {ESLVal _v1973 = refs;
        
        if(_v1973.isCons())
        {ESLVal $2506 = _v1973.head();
          ESLVal $2507 = _v1973.tail();
          
          switch($2506.termName) {
          case "VarDynamicRef": {ESLVal $2512 = $2506.termRef(0);
            ESLVal $2511 = $2506.termRef(1);
            
            switch($2511.termName) {
            case "Var": {ESLVal $2514 = $2511.termRef(0);
              ESLVal $2513 = $2511.termRef(1);
              
              {ESLVal l = $2512;
              
              {ESLVal vl = $2514;
              
              {ESLVal n = $2513;
              
              {ESLVal _v2037 = $2507;
              
              return refsToJExps.apply(_v2037).cons(new ESLVal("JVar",n,$null));
            }
            }
            }
            }
            }
            default: return error(new ESLVal("case error at Pos(15485,15726)").add(ESLVal.list(_v1973)));
          }
          }
        case "ActorDynamicRef": {ESLVal $2510 = $2506.termRef(0);
            ESLVal $2509 = $2506.termRef(1);
            ESLVal $2508 = $2506.termRef(2);
            
            {ESLVal l = $2510;
            
            {ESLVal e = $2509;
            
            {ESLVal n = $2508;
            
            {ESLVal _v2036 = $2507;
            
            return refsToJExps.apply(_v2036).cons(new ESLVal("JRef",expToJExp.apply(e),n));
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(15485,15726)").add(ESLVal.list(_v1973)));
        }
        }
      else if(_v1973.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(15485,15726)").add(ESLVal.list(_v1973)));
      }
    }
  });
  private static ESLVal actToJava = new ESLVal(new Function(new ESLVal("actToJava"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal name = $args[0];
  ESLVal decs = $args[1];
  ESLVal exports = $args[2];
  ESLVal parent = $args[3];
  ESLVal defs = $args[4];
  ESLVal init = $args[5];
  ESLVal arms = $args[6];
  if(parent.eql($null).boolVal)
        return simpleActToJava.apply(name,decs,exports,defs,init,arms);
        else
          return extendedActToJava.apply(name,decs,exports,parent,defs,init,arms);
    }
  });
  private static ESLVal simpleActToJava = new ESLVal(new Function(new ESLVal("simpleActToJava"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal name = $args[0];
  ESLVal decs = $args[1];
  ESLVal exports = $args[2];
  ESLVal defs = $args[3];
  ESLVal init = $args[4];
  ESLVal arms = $args[5];
  {ESLVal timeArms = select.apply(isTimeArm,arms);
        
        {ESLVal nonTimeArms = reject.apply(isTimeArm,arms);
        
        {ESLVal timeCommand = ((Supplier<ESLVal>)() -> { 
            if(timeArms.eql(ESLVal.list()).boolVal)
              return new ESLVal("JBlock",ESLVal.list());
              else
                return timeArmsToJCommand.apply(timeArms);
          }).get();
        
        {ESLVal f = new ESLVal("FunExp",new ESLVal("Pos",$zero,$zero),name,ESLVal.list(new ESLVal("Dec",new ESLVal("Pos",$zero,$zero),new ESLVal("$m"),$null,$null)),new ESLVal("VoidType",new ESLVal("Pos",$zero,$zero)),new ESLVal("Case",new ESLVal("Pos",$zero,$zero),$nil,ESLVal.list(new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("$m"))),nonTimeArms));
        
        return new ESLVal("JBehaviour",exports,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v1972 = $qualArg;
              
              {ESLVal b = _v1972;
              
              return ESLVal.list(ESLVal.list(defToField.apply(b)));
            }
            }
          }
        }).map(defs).flatten().flatten(),expToJExp.apply(init),expToJExp.apply(f),timeCommand);
      }
      }
      }
      }
    }
  });
  private static ESLVal extendedActToJava = new ESLVal(new Function(new ESLVal("extendedActToJava"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal name = $args[0];
  ESLVal decs = $args[1];
  ESLVal exports = $args[2];
  ESLVal parent = $args[3];
  ESLVal defs = $args[4];
  ESLVal init = $args[5];
  ESLVal arms = $args[6];
  {ESLVal p0 = new ESLVal("Pos",$zero,$zero);
        
        {ESLVal timeSuper = new ESLVal("BArm",p0,ESLVal.list(new ESLVal("PTerm",p0,new ESLVal("Time"),ESLVal.list(),ESLVal.list(new ESLVal("PVar",p0,new ESLVal("$"),$null)))),new ESLVal("BoolExp",p0,$true),new ESLVal("SendTimeSuper",p0));
        
        {ESLVal timeArms = select.apply(isTimeArm,arms).add(ESLVal.list(timeSuper));
        
        {ESLVal messageSuper = new ESLVal("BArm",p0,ESLVal.list(new ESLVal("PVar",p0,new ESLVal("$m"),$null)),new ESLVal("BoolExp",p0,$true),new ESLVal("Block",p0,ESLVal.list(new ESLVal("SendSuper",p0,new ESLVal("Var",p0,new ESLVal("$m"))),new ESLVal("NullExp",p0))));
        
        {ESLVal nonTimeArms = reject.apply(isTimeArm,arms).add(ESLVal.list(messageSuper));
        
        {ESLVal timeCommand = ((Supplier<ESLVal>)() -> { 
            if(timeArms.eql(ESLVal.list()).boolVal)
              return new ESLVal("JBlock",ESLVal.list());
              else
                return timeArmsToJCommand.apply(timeArms);
          }).get();
        
        {ESLVal f = new ESLVal("FunExp",new ESLVal("Pos",$zero,$zero),name,ESLVal.list(new ESLVal("Dec",new ESLVal("Pos",$zero,$zero),new ESLVal("$m"),$null,$null)),new ESLVal("VoidType",new ESLVal("Pos",$zero,$zero)),new ESLVal("Case",new ESLVal("Pos",$zero,$zero),$nil,ESLVal.list(new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("$m"))),nonTimeArms));
        
        return new ESLVal("JExtendedBehaviour",exports,expToJExp.apply(parent),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v1971 = $qualArg;
              
              {ESLVal b = _v1971;
              
              return ESLVal.list(ESLVal.list(defToField.apply(b)));
            }
            }
          }
        }).map(defs).flatten().flatten(),expToJExp.apply(init),expToJExp.apply(f),timeCommand);
      }
      }
      }
      }
      }
      }
      }
    }
  });
  private static ESLVal isTimeArm = new ESLVal(new Function(new ESLVal("isTimeArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal a = $args[0];
  {ESLVal _v1970 = a;
        
        switch(_v1970.termName) {
        case "BArm": {ESLVal $2497 = _v1970.termRef(0);
          ESLVal $2496 = _v1970.termRef(1);
          ESLVal $2495 = _v1970.termRef(2);
          ESLVal $2494 = _v1970.termRef(3);
          
          if($2496.isCons())
          {ESLVal $2498 = $2496.head();
            ESLVal $2499 = $2496.tail();
            
            switch($2498.termName) {
            case "PTerm": {ESLVal $2503 = $2498.termRef(0);
              ESLVal $2502 = $2498.termRef(1);
              ESLVal $2501 = $2498.termRef(2);
              ESLVal $2500 = $2498.termRef(3);
              
              switch($2502.strVal) {
              case "Time": if($2499.isCons())
                {ESLVal $2504 = $2499.head();
                  ESLVal $2505 = $2499.tail();
                  
                  {ESLVal _v2029 = _v1970;
                  
                  return $false;
                }
                }
              else if($2499.isNil())
                {ESLVal l = $2497;
                  
                  {ESLVal pl = $2503;
                  
                  {ESLVal ts = $2501;
                  
                  {ESLVal ps = $2500;
                  
                  {ESLVal g = $2495;
                  
                  {ESLVal e = $2494;
                  
                  return $true;
                }
                }
                }
                }
                }
                }
              else {ESLVal _v2030 = _v1970;
                  
                  return $false;
                }
              default: {ESLVal _v2031 = _v1970;
                
                return $false;
              }
            }
            }
            default: {ESLVal _v2032 = _v1970;
              
              return $false;
            }
          }
          }
        else if($2496.isNil())
          {ESLVal _v2033 = _v1970;
            
            return $false;
          }
        else {ESLVal _v2034 = _v1970;
            
            return $false;
          }
        }
        default: {ESLVal _v2035 = _v1970;
          
          return $false;
        }
      }
      }
    }
  });
  private static ESLVal timeArmsToJCommand = new ESLVal(new Function(new ESLVal("timeArmsToJCommand"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  {ESLVal _v1969 = arms;
        
        if(_v1969.isCons())
        {ESLVal $2463 = _v1969.head();
          ESLVal $2464 = _v1969.tail();
          
          switch($2463.termName) {
          case "BArm": {ESLVal $2468 = $2463.termRef(0);
            ESLVal $2467 = $2463.termRef(1);
            ESLVal $2466 = $2463.termRef(2);
            ESLVal $2465 = $2463.termRef(3);
            
            if($2467.isCons())
            {ESLVal $2469 = $2467.head();
              ESLVal $2470 = $2467.tail();
              
              switch($2469.termName) {
              case "PTerm": {ESLVal $2474 = $2469.termRef(0);
                ESLVal $2473 = $2469.termRef(1);
                ESLVal $2472 = $2469.termRef(2);
                ESLVal $2471 = $2469.termRef(3);
                
                switch($2473.strVal) {
                case "Time": if($2472.isCons())
                  {ESLVal $2475 = $2472.head();
                    ESLVal $2476 = $2472.tail();
                    
                    return error(new ESLVal("case error at Pos(17827,18357)").add(ESLVal.list(_v1969)));
                  }
                else if($2472.isNil())
                  if($2471.isCons())
                    {ESLVal $2477 = $2471.head();
                      ESLVal $2478 = $2471.tail();
                      
                      switch($2477.termName) {
                      case "PVar": {ESLVal $2489 = $2477.termRef(0);
                        ESLVal $2488 = $2477.termRef(1);
                        ESLVal $2487 = $2477.termRef(2);
                        
                        if($2478.isCons())
                        {ESLVal $2490 = $2478.head();
                          ESLVal $2491 = $2478.tail();
                          
                          return error(new ESLVal("case error at Pos(17827,18357)").add(ESLVal.list(_v1969)));
                        }
                      else if($2478.isNil())
                        if($2470.isCons())
                          {ESLVal $2492 = $2470.head();
                            ESLVal $2493 = $2470.tail();
                            
                            return error(new ESLVal("case error at Pos(17827,18357)").add(ESLVal.list(_v1969)));
                          }
                        else if($2470.isNil())
                          {ESLVal l = $2468;
                            
                            {ESLVal tl = $2474;
                            
                            {ESLVal vl = $2489;
                            
                            {ESLVal n = $2488;
                            
                            {ESLVal t = $2487;
                            
                            {ESLVal g = $2466;
                            
                            {ESLVal e = $2465;
                            
                            {ESLVal _v2028 = $2464;
                            
                            return new ESLVal("JLet",ESLVal.list(new ESLVal("JField",n,$null,new ESLVal("JVar",new ESLVal("$t"),$null))),new ESLVal("JIfCommand",expToJExp.apply(g),expToJCommand.apply(e,$false),timeArmsToJCommand.apply(_v2028)));
                          }
                          }
                          }
                          }
                          }
                          }
                          }
                          }
                        else return error(new ESLVal("case error at Pos(17827,18357)").add(ESLVal.list(_v1969)));
                      else return error(new ESLVal("case error at Pos(17827,18357)").add(ESLVal.list(_v1969)));
                      }
                    case "PInt": {ESLVal $2480 = $2477.termRef(0);
                        ESLVal $2479 = $2477.termRef(1);
                        
                        if($2478.isCons())
                        {ESLVal $2481 = $2478.head();
                          ESLVal $2482 = $2478.tail();
                          
                          return error(new ESLVal("case error at Pos(17827,18357)").add(ESLVal.list(_v1969)));
                        }
                      else if($2478.isNil())
                        if($2470.isCons())
                          {ESLVal $2483 = $2470.head();
                            ESLVal $2484 = $2470.tail();
                            
                            return error(new ESLVal("case error at Pos(17827,18357)").add(ESLVal.list(_v1969)));
                          }
                        else if($2470.isNil())
                          switch($2466.termName) {
                            case "BoolExp": {ESLVal $2486 = $2466.termRef(0);
                              ESLVal $2485 = $2466.termRef(1);
                              
                              switch($2485.boolVal ? 1 : 0) {
                              case 1: {ESLVal l = $2468;
                                
                                {ESLVal tl = $2474;
                                
                                {ESLVal vl = $2480;
                                
                                {ESLVal n = $2479;
                                
                                {ESLVal bl = $2486;
                                
                                {ESLVal e = $2465;
                                
                                {ESLVal _v2027 = $2464;
                                
                                return new ESLVal("JIfCommand",new ESLVal("JBinExp",new ESLVal("JVar",new ESLVal("$t"),$null),new ESLVal("eq"),new ESLVal("JConstExp",new ESLVal("JConstInt",n))),expToJCommand.apply(e,$false),timeArmsToJCommand.apply(_v2027));
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              default: return error(new ESLVal("case error at Pos(17827,18357)").add(ESLVal.list(_v1969)));
                            }
                            }
                            default: return error(new ESLVal("case error at Pos(17827,18357)").add(ESLVal.list(_v1969)));
                          }
                        else return error(new ESLVal("case error at Pos(17827,18357)").add(ESLVal.list(_v1969)));
                      else return error(new ESLVal("case error at Pos(17827,18357)").add(ESLVal.list(_v1969)));
                      }
                      default: return error(new ESLVal("case error at Pos(17827,18357)").add(ESLVal.list(_v1969)));
                    }
                    }
                  else if($2471.isNil())
                    return error(new ESLVal("case error at Pos(17827,18357)").add(ESLVal.list(_v1969)));
                  else return error(new ESLVal("case error at Pos(17827,18357)").add(ESLVal.list(_v1969)));
                else return error(new ESLVal("case error at Pos(17827,18357)").add(ESLVal.list(_v1969)));
                default: return error(new ESLVal("case error at Pos(17827,18357)").add(ESLVal.list(_v1969)));
              }
              }
              default: return error(new ESLVal("case error at Pos(17827,18357)").add(ESLVal.list(_v1969)));
            }
            }
          else if($2467.isNil())
            return error(new ESLVal("case error at Pos(17827,18357)").add(ESLVal.list(_v1969)));
          else return error(new ESLVal("case error at Pos(17827,18357)").add(ESLVal.list(_v1969)));
          }
          default: return error(new ESLVal("case error at Pos(17827,18357)").add(ESLVal.list(_v1969)));
        }
        }
      else if(_v1969.isNil())
        return new ESLVal("JBlock",ESLVal.list());
      else return error(new ESLVal("case error at Pos(17827,18357)").add(ESLVal.list(_v1969)));
      }
    }
  });
  private static ESLVal cmpToJExp = new ESLVal(new Function(new ESLVal("cmpToJExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  ESLVal qs = $args[1];
  {ESLVal _v1968 = qs;
        
        if(_v1968.isCons())
        {ESLVal $2456 = _v1968.head();
          ESLVal $2457 = _v1968.tail();
          
          switch($2456.termName) {
          case "BQual": {ESLVal $2462 = $2456.termRef(0);
            ESLVal $2461 = $2456.termRef(1);
            ESLVal $2460 = $2456.termRef(2);
            
            {ESLVal l = $2462;
            
            {ESLVal p = $2461;
            
            {ESLVal v = $2460;
            
            {ESLVal _v2026 = $2457;
            
            {ESLVal f = new ESLVal("FunExp",new ESLVal("Pos",$zero,$zero),new ESLVal("StrExp",new ESLVal("Pos",$zero,$zero),new ESLVal("qual")),ESLVal.list(new ESLVal("Dec",new ESLVal("Pos",$zero,$zero),new ESLVal("$qualArg"),$null,$null)),$null,new ESLVal("Case",new ESLVal("Pos",$zero,$zero),ESLVal.list(),ESLVal.list(new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("$qualArg"))),ESLVal.list(new ESLVal("BArm",new ESLVal("Pos",$zero,$zero),ESLVal.list(p),new ESLVal("BoolExp",new ESLVal("Pos",$zero,$zero),$true),new ESLVal("List",new ESLVal("Pos",$zero,$zero),ESLVal.list(new ESLVal("Cmp",new ESLVal("Pos",$zero,$zero),e,_v2026)))),new ESLVal("BArm",new ESLVal("Pos",$zero,$zero),ESLVal.list(new ESLVal("PVar",new ESLVal("Pos",$zero,$zero),new ESLVal("_0"),$null)),new ESLVal("BoolExp",new ESLVal("Pos",$zero,$zero),$true),new ESLVal("List",new ESLVal("Pos",$zero,$zero),$nil)))));
            
            return new ESLVal("JFlatten",new ESLVal("JFlatten",new ESLVal("JMapFun",expToJExp.apply(f),expToJExp.apply(v))));
          }
          }
          }
          }
          }
          }
        case "PQual": {ESLVal $2459 = $2456.termRef(0);
            ESLVal $2458 = $2456.termRef(1);
            
            {ESLVal l = $2459;
            
            {ESLVal p = $2458;
            
            {ESLVal _v2025 = $2457;
            
            return new ESLVal("JIfExp",expToJExp.apply(p),cmpToJExp.apply(e,_v2025),new ESLVal("JNil",$null));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(18404,19072)").add(ESLVal.list(_v1968)));
        }
        }
      else if(_v1968.isNil())
        return new ESLVal("JList",$null,ESLVal.list(expToJExp.apply(e)));
      else return error(new ESLVal("case error at Pos(18404,19072)").add(ESLVal.list(_v1968)));
      }
    }
  });
  public static ESLVal moduleToJava = new ESLVal(new Function(new ESLVal("moduleToJava"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal module = $args[0];
  {ESLVal _v1966 = module;
        
        switch(_v1966.termName) {
        case "Module": {ESLVal $2455 = _v1966.termRef(0);
          ESLVal $2454 = _v1966.termRef(1);
          ESLVal $2453 = _v1966.termRef(2);
          ESLVal $2452 = _v1966.termRef(3);
          ESLVal $2451 = _v1966.termRef(4);
          ESLVal $2450 = _v1966.termRef(5);
          ESLVal $2449 = _v1966.termRef(6);
          
          {ESLVal path = $2455;
          
          {ESLVal name = $2454;
          
          {ESLVal exports = $2453;
          
          {ESLVal imports = $2452;
          
          {ESLVal x = $2451;
          
          {ESLVal y = $2450;
          
          {ESLVal defs = $2449;
          
          return renameJVarsModule.apply(new ESLVal("JModule",name,exports,imports,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1967 = $qualArg;
                
                {ESLVal d = _v1967;
                
                return ESLVal.list((isBinding.apply(d).or(isFunBind.apply(d)).boolVal) ? (ESLVal.list(defToField.apply(d))) : ($nil));
              }
              }
            }
          }).map(expandFunDefs.apply(mergeFunDefs.apply(defs))).flatten().flatten()));
        }
        }
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(19110,19383)").add(ESLVal.list(_v1966)));
      }
      }
    }
  });
  private static ESLVal renameJVarsModule = new ESLVal(new Function(new ESLVal("renameJVarsModule"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal m = $args[0];
  {ESLVal _v1963 = m;
        
        switch(_v1963.termName) {
        case "JModule": {ESLVal $2442 = _v1963.termRef(0);
          ESLVal $2441 = _v1963.termRef(1);
          ESLVal $2440 = _v1963.termRef(2);
          ESLVal $2439 = _v1963.termRef(3);
          
          {ESLVal name = $2442;
          
          {ESLVal exports = $2441;
          
          {ESLVal imports = $2440;
          
          {ESLVal fs = $2439;
          
          {ESLVal fieldNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v1964 = $qualArg;
                  
                  switch(_v1964.termName) {
                  case "JField": {ESLVal $2445 = _v1964.termRef(0);
                    ESLVal $2444 = _v1964.termRef(1);
                    ESLVal $2443 = _v1964.termRef(2);
                    
                    {ESLVal n = $2445;
                    
                    {ESLVal t = $2444;
                    
                    {ESLVal e = $2443;
                    
                    return ESLVal.list(ESLVal.list(n));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v1964;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(fs).flatten().flatten();
          
          return new ESLVal("JModule",name,exports,imports,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1965 = $qualArg;
                
                switch(_v1965.termName) {
                case "JField": {ESLVal $2448 = _v1965.termRef(0);
                  ESLVal $2447 = _v1965.termRef(1);
                  ESLVal $2446 = _v1965.termRef(2);
                  
                  {ESLVal n = $2448;
                  
                  {ESLVal t = $2447;
                  
                  {ESLVal e = $2446;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(e,fieldNames,emptyTable))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1965;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten());
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(19423,19730)").add(ESLVal.list(_v1963)));
      }
      }
    }
  });
  private static ESLVal renameJVarsExp = new ESLVal(new Function(new ESLVal("renameJVarsExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  ESLVal vars = $args[1];
  ESLVal env = $args[2];
  {ESLVal _v1946 = e;
        
        switch(_v1946.termName) {
        case "JFun": {ESLVal $2427 = _v1946.termRef(0);
          ESLVal $2426 = _v1946.termRef(1);
          ESLVal $2425 = _v1946.termRef(2);
          ESLVal $2424 = _v1946.termRef(3);
          
          {ESLVal v0 = $2427;
          
          {ESLVal v1 = $2426;
          
          {ESLVal v2 = $2425;
          
          {ESLVal v3 = $2424;
          
          {ESLVal boundNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v1960 = $qualArg;
                  
                  switch(_v1960.termName) {
                  case "JDec": {ESLVal $2438 = _v1960.termRef(0);
                    ESLVal $2437 = _v1960.termRef(1);
                    
                    {ESLVal n = $2438;
                    
                    {ESLVal t = $2437;
                    
                    return ESLVal.list(ESLVal.list(n));
                  }
                  }
                  }
                  default: {ESLVal _0 = _v1960;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v1).flatten().flatten();
          
          if(exists.apply(new ESLVal(new Function(new ESLVal("fun938"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal n = $args[0];
        return member.apply(n,boundNames);
          }
        }),vars).boolVal)
          {ESLVal newNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v1961 = $qualArg;
                    
                    {ESLVal n = _v1961;
                    
                    return ESLVal.list(ESLVal.list(newName.apply()));
                  }
                  }
                }
              }).map(boundNames).flatten().flatten();
            
            {ESLVal env1 = addEntries.apply(boundNames,newNames,env);
            
            return new ESLVal("JFun",v0,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v1962 = $qualArg;
                  
                  {ESLVal n = _v1962;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JDec",n,$null)));
                }
                }
              }
            }).map(newNames).flatten().flatten(),v2,renameJVarsCommand.apply(v3,boundNames.add(vars),env1));
          }
          }
          else
            return new ESLVal("JFun",v0,v1,v2,renameJVarsCommand.apply(v3,boundNames.add(vars),env));
        }
        }
        }
        }
        }
        }
      case "JApply": {ESLVal $2423 = _v1946.termRef(0);
          ESLVal $2422 = _v1946.termRef(1);
          
          {ESLVal v0 = $2423;
          
          {ESLVal v1 = $2422;
          
          return new ESLVal("JApply",renameJVarsExp.apply(v0,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1959 = $qualArg;
                
                {ESLVal v = _v1959;
                
                return ESLVal.list(ESLVal.list(renameJVarsExp.apply(v,vars,env)));
              }
              }
            }
          }).map(v1).flatten().flatten());
        }
        }
        }
      case "JArrayRef": {ESLVal $2421 = _v1946.termRef(0);
          ESLVal $2420 = _v1946.termRef(1);
          
          {ESLVal a = $2421;
          
          {ESLVal i = $2420;
          
          return new ESLVal("JArrayRef",renameJVarsExp.apply(a,vars,env),renameJVarsExp.apply(i,vars,env));
        }
        }
        }
      case "JArrayUpdate": {ESLVal $2419 = _v1946.termRef(0);
          ESLVal $2418 = _v1946.termRef(1);
          ESLVal $2417 = _v1946.termRef(2);
          
          {ESLVal a = $2419;
          
          {ESLVal i = $2418;
          
          {ESLVal v = $2417;
          
          return new ESLVal("JArrayUpdate",renameJVarsExp.apply(a,vars,env),renameJVarsExp.apply(i,vars,env),renameJVarsExp.apply(v,vars,env));
        }
        }
        }
        }
      case "JBecome": {ESLVal $2416 = _v1946.termRef(0);
          ESLVal $2415 = _v1946.termRef(1);
          
          {ESLVal _v2024 = $2416;
          
          {ESLVal es = $2415;
          
          return new ESLVal("JBecome",renameJVarsExp.apply(_v2024,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1958 = $qualArg;
                
                {ESLVal v = _v1958;
                
                return ESLVal.list(ESLVal.list(renameJVarsExp.apply(v,vars,env)));
              }
              }
            }
          }).map(es).flatten().flatten());
        }
        }
        }
      case "JBinExp": {ESLVal $2414 = _v1946.termRef(0);
          ESLVal $2413 = _v1946.termRef(1);
          ESLVal $2412 = _v1946.termRef(2);
          
          {ESLVal v0 = $2414;
          
          {ESLVal v1 = $2413;
          
          {ESLVal v2 = $2412;
          
          return new ESLVal("JBinExp",renameJVarsExp.apply(v0,vars,env),v1,renameJVarsExp.apply(v2,vars,env));
        }
        }
        }
        }
      case "JCommandExp": {ESLVal $2411 = _v1946.termRef(0);
          ESLVal $2410 = _v1946.termRef(1);
          
          {ESLVal v0 = $2411;
          
          {ESLVal v1 = $2410;
          
          return new ESLVal("JCommandExp",renameJVarsCommand.apply(v0,vars,env),v1);
        }
        }
        }
      case "JIfExp": {ESLVal $2409 = _v1946.termRef(0);
          ESLVal $2408 = _v1946.termRef(1);
          ESLVal $2407 = _v1946.termRef(2);
          
          {ESLVal v0 = $2409;
          
          {ESLVal v1 = $2408;
          
          {ESLVal v2 = $2407;
          
          return new ESLVal("JIfExp",renameJVarsExp.apply(v0,vars,env),renameJVarsExp.apply(v1,vars,env),renameJVarsExp.apply(v2,vars,env));
        }
        }
        }
        }
      case "JConstExp": {ESLVal $2406 = _v1946.termRef(0);
          
          {ESLVal v0 = $2406;
          
          return e;
        }
        }
      case "JTerm": {ESLVal $2405 = _v1946.termRef(0);
          ESLVal $2404 = _v1946.termRef(1);
          
          {ESLVal v0 = $2405;
          
          {ESLVal v1 = $2404;
          
          return new ESLVal("JTerm",v0,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1957 = $qualArg;
                
                {ESLVal v = _v1957;
                
                return ESLVal.list(ESLVal.list(renameJVarsExp.apply(v,vars,env)));
              }
              }
            }
          }).map(v1).flatten().flatten());
        }
        }
        }
      case "JTermRef": {ESLVal $2403 = _v1946.termRef(0);
          ESLVal $2402 = _v1946.termRef(1);
          
          {ESLVal v0 = $2403;
          
          {ESLVal v1 = $2402;
          
          return new ESLVal("JTermRef",renameJVarsExp.apply(v0,vars,env),v1);
        }
        }
        }
      case "JList": {ESLVal $2401 = _v1946.termRef(0);
          ESLVal $2400 = _v1946.termRef(1);
          
          {ESLVal v0 = $2401;
          
          {ESLVal v1 = $2400;
          
          return new ESLVal("JList",v0,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1956 = $qualArg;
                
                {ESLVal v = _v1956;
                
                return ESLVal.list(ESLVal.list(renameJVarsExp.apply(v,vars,env)));
              }
              }
            }
          }).map(v1).flatten().flatten());
        }
        }
        }
      case "JSet": {ESLVal $2399 = _v1946.termRef(0);
          ESLVal $2398 = _v1946.termRef(1);
          
          {ESLVal v0 = $2399;
          
          {ESLVal v1 = $2398;
          
          return new ESLVal("JSet",v0,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1955 = $qualArg;
                
                {ESLVal v = _v1955;
                
                return ESLVal.list(ESLVal.list(renameJVarsExp.apply(v,vars,env)));
              }
              }
            }
          }).map(v1).flatten().flatten());
        }
        }
        }
      case "JBag": {ESLVal $2397 = _v1946.termRef(0);
          ESLVal $2396 = _v1946.termRef(1);
          
          {ESLVal v0 = $2397;
          
          {ESLVal v1 = $2396;
          
          return new ESLVal("JBag",v0,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1954 = $qualArg;
                
                {ESLVal v = _v1954;
                
                return ESLVal.list(ESLVal.list(renameJVarsExp.apply(v,vars,env)));
              }
              }
            }
          }).map(v1).flatten().flatten());
        }
        }
        }
      case "JNil": {ESLVal $2395 = _v1946.termRef(0);
          
          {ESLVal v0 = $2395;
          
          return e;
        }
        }
      case "JNow": {
          return e;
        }
      case "JVar": {ESLVal $2394 = _v1946.termRef(0);
          ESLVal $2393 = _v1946.termRef(1);
          
          {ESLVal v0 = $2394;
          
          {ESLVal v1 = $2393;
          
          if(hasEntry.apply(v0,env).boolVal)
          return new ESLVal("JVar",lookup.apply(v0,env),v1);
          else
            return e;
        }
        }
        }
      case "JNull": {
          return e;
        }
      case "JError": {ESLVal $2392 = _v1946.termRef(0);
          
          {ESLVal v0 = $2392;
          
          return new ESLVal("JError",renameJVarsExp.apply(v0,vars,env));
        }
        }
      case "JHead": {ESLVal $2391 = _v1946.termRef(0);
          
          {ESLVal v0 = $2391;
          
          return new ESLVal("JHead",renameJVarsExp.apply(v0,vars,env));
        }
        }
      case "JTail": {ESLVal $2390 = _v1946.termRef(0);
          
          {ESLVal v0 = $2390;
          
          return new ESLVal("JTail",renameJVarsExp.apply(v0,vars,env));
        }
        }
      case "JCastp": {ESLVal $2389 = _v1946.termRef(0);
          ESLVal $2388 = _v1946.termRef(1);
          ESLVal $2387 = _v1946.termRef(2);
          
          {ESLVal v0 = $2389;
          
          {ESLVal v1 = $2388;
          
          {ESLVal v2 = $2387;
          
          return new ESLVal("JCastp",v0,v1,renameJVarsExp.apply(v2,vars,env));
        }
        }
        }
        }
      case "JCast": {ESLVal $2386 = _v1946.termRef(0);
          ESLVal $2385 = _v1946.termRef(1);
          
          {ESLVal v0 = $2386;
          
          {ESLVal v1 = $2385;
          
          return new ESLVal("JCast",v0,renameJVarsExp.apply(v1,vars,env));
        }
        }
        }
      case "JCmpExp": {ESLVal $2384 = _v1946.termRef(0);
          
          {ESLVal cmp = $2384;
          
          return new ESLVal("JCmpExp",renameJVarsCmp.apply(cmp,vars,env));
        }
        }
      case "JNot": {ESLVal $2383 = _v1946.termRef(0);
          
          {ESLVal _v2023 = $2383;
          
          return new ESLVal("JNot",renameJVarsExp.apply(_v2023,vars,env));
        }
        }
      case "JNew": {ESLVal $2382 = _v1946.termRef(0);
          ESLVal $2381 = _v1946.termRef(1);
          
          {ESLVal b = $2382;
          
          {ESLVal args = $2381;
          
          return new ESLVal("JNew",renameJVarsExp.apply(b,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1953 = $qualArg;
                
                {ESLVal a = _v1953;
                
                return ESLVal.list(ESLVal.list(renameJVarsExp.apply(a,vars,env)));
              }
              }
            }
          }).map(args).flatten().flatten());
        }
        }
        }
      case "JNewArray": {ESLVal $2380 = _v1946.termRef(0);
          
          {ESLVal b = $2380;
          
          return new ESLVal("JNewArray",renameJVarsExp.apply(b,vars,env));
        }
        }
      case "JNewJava": {ESLVal $2379 = _v1946.termRef(0);
          ESLVal $2378 = _v1946.termRef(1);
          
          {ESLVal n = $2379;
          
          {ESLVal args = $2378;
          
          return new ESLVal("JNewJava",n,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1952 = $qualArg;
                
                {ESLVal a = _v1952;
                
                return ESLVal.list(ESLVal.list(renameJVarsExp.apply(a,vars,env)));
              }
              }
            }
          }).map(args).flatten().flatten());
        }
        }
        }
      case "JNewTable": {
          return new ESLVal("JNewTable",new ESLVal[]{});
        }
      case "JMapFun": {ESLVal $2377 = _v1946.termRef(0);
          ESLVal $2376 = _v1946.termRef(1);
          
          {ESLVal f = $2377;
          
          {ESLVal l = $2376;
          
          return new ESLVal("JMapFun",renameJVarsExp.apply(f,vars,env),renameJVarsExp.apply(l,vars,env));
        }
        }
        }
      case "JRecord": {ESLVal $2375 = _v1946.termRef(0);
          
          {ESLVal fs = $2375;
          
          return new ESLVal("JRecord",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1951 = $qualArg;
                
                switch(_v1951.termName) {
                case "JField": {ESLVal $2436 = _v1951.termRef(0);
                  ESLVal $2435 = _v1951.termRef(1);
                  ESLVal $2434 = _v1951.termRef(2);
                  
                  {ESLVal n = $2436;
                  
                  {ESLVal t = $2435;
                  
                  {ESLVal _v2022 = $2434;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(_v2022,vars,env))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1951;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten());
        }
        }
      case "JFlatten": {ESLVal $2374 = _v1946.termRef(0);
          
          {ESLVal _v2021 = $2374;
          
          return new ESLVal("JFlatten",renameJVarsExp.apply(_v2021,vars,env));
        }
        }
      case "JSend": {ESLVal $2373 = _v1946.termRef(0);
          ESLVal $2372 = _v1946.termRef(1);
          ESLVal $2371 = _v1946.termRef(2);
          
          {ESLVal _v2019 = $2373;
          
          {ESLVal n = $2372;
          
          {ESLVal es = $2371;
          
          return new ESLVal("JSend",renameJVarsExp.apply(_v2019,vars,env),n,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1950 = $qualArg;
                
                {ESLVal _v2020 = _v1950;
                
                return ESLVal.list(ESLVal.list(renameJVarsExp.apply(_v2020,vars,env)));
              }
              }
            }
          }).map(es).flatten().flatten());
        }
        }
        }
        }
      case "JSendSuper": {ESLVal $2370 = _v1946.termRef(0);
          
          {ESLVal _v2018 = $2370;
          
          return new ESLVal("JSendSuper",renameJVarsExp.apply(_v2018,vars,env));
        }
        }
      case "JSendTimeSuper": {
          return new ESLVal("JSendTimeSuper",new ESLVal[]{});
        }
      case "JSelf": {
          return new ESLVal("JSelf",new ESLVal[]{});
        }
      case "JRef": {ESLVal $2369 = _v1946.termRef(0);
          ESLVal $2368 = _v1946.termRef(1);
          
          {ESLVal _v2017 = $2369;
          
          {ESLVal n = $2368;
          
          return new ESLVal("JRef",renameJVarsExp.apply(_v2017,vars,env),n);
        }
        }
        }
      case "JRefSuper": {ESLVal $2367 = _v1946.termRef(0);
          
          {ESLVal n = $2367;
          
          return new ESLVal("JRefSuper",n);
        }
        }
      case "JBehaviour": {ESLVal $2366 = _v1946.termRef(0);
          ESLVal $2365 = _v1946.termRef(1);
          ESLVal $2364 = _v1946.termRef(2);
          ESLVal $2363 = _v1946.termRef(3);
          ESLVal $2362 = _v1946.termRef(4);
          
          {ESLVal es = $2366;
          
          {ESLVal fs = $2365;
          
          {ESLVal init = $2364;
          
          {ESLVal handler = $2363;
          
          {ESLVal time = $2362;
          
          return new ESLVal("JBehaviour",es,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1949 = $qualArg;
                
                switch(_v1949.termName) {
                case "JField": {ESLVal $2433 = _v1949.termRef(0);
                  ESLVal $2432 = _v1949.termRef(1);
                  ESLVal $2431 = _v1949.termRef(2);
                  
                  {ESLVal n = $2433;
                  
                  {ESLVal t = $2432;
                  
                  {ESLVal _v2016 = $2431;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(_v2016,vars,env))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1949;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten(),renameJVarsExp.apply(init,vars,env),renameJVarsExp.apply(handler,vars,env),renameJVarsCommand.apply(time,vars,env));
        }
        }
        }
        }
        }
        }
      case "JExtendedBehaviour": {ESLVal $2361 = _v1946.termRef(0);
          ESLVal $2360 = _v1946.termRef(1);
          ESLVal $2359 = _v1946.termRef(2);
          ESLVal $2358 = _v1946.termRef(3);
          ESLVal $2357 = _v1946.termRef(4);
          ESLVal $2356 = _v1946.termRef(5);
          
          {ESLVal es = $2361;
          
          {ESLVal parent = $2360;
          
          {ESLVal fs = $2359;
          
          {ESLVal init = $2358;
          
          {ESLVal handler = $2357;
          
          {ESLVal time = $2356;
          
          return new ESLVal("JExtendedBehaviour",es,renameJVarsExp.apply(parent,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1948 = $qualArg;
                
                switch(_v1948.termName) {
                case "JField": {ESLVal $2430 = _v1948.termRef(0);
                  ESLVal $2429 = _v1948.termRef(1);
                  ESLVal $2428 = _v1948.termRef(2);
                  
                  {ESLVal n = $2430;
                  
                  {ESLVal t = $2429;
                  
                  {ESLVal _v2015 = $2428;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(_v2015,vars,env))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1948;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten(),renameJVarsExp.apply(init,vars,env),renameJVarsExp.apply(handler,vars,env),renameJVarsCommand.apply(time,vars,env));
        }
        }
        }
        }
        }
        }
        }
      case "JTry": {ESLVal $2355 = _v1946.termRef(0);
          ESLVal $2354 = _v1946.termRef(1);
          ESLVal $2353 = _v1946.termRef(2);
          
          {ESLVal _v2014 = $2355;
          
          {ESLVal n = $2354;
          
          {ESLVal c = $2353;
          
          return new ESLVal("JTry",renameJVarsExp.apply(_v2014,vars,env),n,renameJVarsCommand.apply(c,vars,env));
        }
        }
        }
        }
      case "JProbably": {ESLVal $2352 = _v1946.termRef(0);
          ESLVal $2351 = _v1946.termRef(1);
          ESLVal $2350 = _v1946.termRef(2);
          
          {ESLVal _v2013 = $2352;
          
          {ESLVal e1 = $2351;
          
          {ESLVal e2 = $2350;
          
          return new ESLVal("JProbably",renameJVarsExp.apply(_v2013,vars,env),renameJVarsExp.apply(e1,vars,env),renameJVarsExp.apply(e2,vars,env));
        }
        }
        }
        }
      case "JGrab": {ESLVal $2349 = _v1946.termRef(0);
          ESLVal $2348 = _v1946.termRef(1);
          
          {ESLVal es = $2349;
          
          {ESLVal c = $2348;
          
          return new ESLVal("JGrab",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1947 = $qualArg;
                
                {ESLVal _v2012 = _v1947;
                
                return ESLVal.list(ESLVal.list(renameJVarsExp.apply(_v2012,vars,env)));
              }
              }
            }
          }).map(es).flatten().flatten(),renameJVarsExp.apply(c,vars,env));
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(19800,24444)").add(ESLVal.list(_v1946)));
      }
      }
    }
  });
  private static ESLVal renameJVarsCmp = new ESLVal(new Function(new ESLVal("renameJVarsCmp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal c = $args[0];
  ESLVal vars = $args[1];
  ESLVal env = $args[2];
  {ESLVal _v1945 = c;
        
        switch(_v1945.termName) {
        case "JCmpList": {ESLVal $2347 = _v1945.termRef(0);
          
          {ESLVal e = $2347;
          
          return new ESLVal("JCmpList",renameJVarsExp.apply(e,vars,env));
        }
        }
      case "JCmpOuter": {ESLVal $2346 = _v1945.termRef(0);
          ESLVal $2345 = _v1945.termRef(1);
          ESLVal $2344 = _v1945.termRef(2);
          
          {ESLVal n = $2346;
          
          {ESLVal e = $2345;
          
          {ESLVal _v2011 = $2344;
          
          return new ESLVal("JCmpOuter",n,renameJVarsExp.apply(e,vars,env),renameJVarsCmp.apply(_v2011,vars,env));
        }
        }
        }
        }
      case "JCmpBind": {ESLVal $2343 = _v1945.termRef(0);
          ESLVal $2342 = _v1945.termRef(1);
          ESLVal $2341 = _v1945.termRef(2);
          
          {ESLVal n = $2343;
          
          {ESLVal e = $2342;
          
          {ESLVal _v2010 = $2341;
          
          return new ESLVal("JCmpBind",n,renameJVarsExp.apply(e,vars,env),renameJVarsCmp.apply(_v2010,vars,env));
        }
        }
        }
        }
      case "JCmpIf": {ESLVal $2340 = _v1945.termRef(0);
          ESLVal $2339 = _v1945.termRef(1);
          
          {ESLVal e = $2340;
          
          {ESLVal _v2009 = $2339;
          
          return new ESLVal("JCmpIf",renameJVarsExp.apply(e,vars,env),renameJVarsCmp.apply(_v2009,vars,env));
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(24519,24852)").add(ESLVal.list(_v1945)));
      }
      }
    }
  });
  private static ESLVal nameCount = $zero;
  private static ESLVal newName = new ESLVal(new Function(new ESLVal("newName"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      {nameCount = nameCount.add($one);
      return new ESLVal("_v").add(nameCount);}
    }
  });
  private static ESLVal renameJVarsCommand = new ESLVal(new Function(new ESLVal("renameJVarsCommand"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal c = $args[0];
  ESLVal vars = $args[1];
  ESLVal env = $args[2];
  {ESLVal _v1927 = c;
        
        switch(_v1927.termName) {
        case "JBlock": {ESLVal $2302 = _v1927.termRef(0);
          
          {ESLVal v0 = $2302;
          
          return new ESLVal("JBlock",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1944 = $qualArg;
                
                {ESLVal _v2008 = _v1944;
                
                return ESLVal.list(ESLVal.list(renameJVarsCommand.apply(_v2008,vars,env)));
              }
              }
            }
          }).map(v0).flatten().flatten());
        }
        }
      case "JReturn": {ESLVal $2301 = _v1927.termRef(0);
          
          {ESLVal v0 = $2301;
          
          return new ESLVal("JReturn",renameJVarsExp.apply(v0,vars,env));
        }
        }
      case "JSwitch": {ESLVal $2300 = _v1927.termRef(0);
          ESLVal $2299 = _v1927.termRef(1);
          ESLVal $2298 = _v1927.termRef(2);
          
          {ESLVal v0 = $2300;
          
          {ESLVal v1 = $2299;
          
          {ESLVal v2 = $2298;
          
          return error(new ESLVal("jswitch should not occur"));
        }
        }
        }
        }
      case "JSwitchList": {ESLVal $2297 = _v1927.termRef(0);
          ESLVal $2296 = _v1927.termRef(1);
          ESLVal $2295 = _v1927.termRef(2);
          ESLVal $2294 = _v1927.termRef(3);
          
          {ESLVal v0 = $2297;
          
          {ESLVal v1 = $2296;
          
          {ESLVal v2 = $2295;
          
          {ESLVal v3 = $2294;
          
          return new ESLVal("JSwitchList",renameJVarsExp.apply(v0,vars,env),renameJVarsCommand.apply(v1,vars,env),renameJVarsCommand.apply(v2,vars,env),renameJVarsCommand.apply(v3,vars,env));
        }
        }
        }
        }
        }
      case "JIfCommand": {ESLVal $2293 = _v1927.termRef(0);
          ESLVal $2292 = _v1927.termRef(1);
          ESLVal $2291 = _v1927.termRef(2);
          
          {ESLVal v0 = $2293;
          
          {ESLVal v1 = $2292;
          
          {ESLVal v2 = $2291;
          
          return new ESLVal("JIfCommand",renameJVarsExp.apply(v0,vars,env),renameJVarsCommand.apply(v1,vars,env),renameJVarsCommand.apply(v2,vars,env));
        }
        }
        }
        }
      case "JCaseList": {ESLVal $2290 = _v1927.termRef(0);
          ESLVal $2289 = _v1927.termRef(1);
          ESLVal $2288 = _v1927.termRef(2);
          ESLVal $2287 = _v1927.termRef(3);
          
          {ESLVal v0 = $2290;
          
          {ESLVal v1 = $2289;
          
          {ESLVal v2 = $2288;
          
          {ESLVal v3 = $2287;
          
          return new ESLVal("JCaseList",renameJVarsExp.apply(v0,vars,env),renameJVarsCommand.apply(v1,vars,env),renameJVarsCommand.apply(v2,vars,env),renameJVarsCommand.apply(v3,vars,env));
        }
        }
        }
        }
        }
      case "JCaseInt": {ESLVal $2286 = _v1927.termRef(0);
          ESLVal $2285 = _v1927.termRef(1);
          ESLVal $2284 = _v1927.termRef(2);
          
          {ESLVal e = $2286;
          
          {ESLVal arms = $2285;
          
          {ESLVal alt = $2284;
          
          return new ESLVal("JCaseInt",renameJVarsExp.apply(e,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1943 = $qualArg;
                
                switch(_v1943.termName) {
                case "JIArm": {ESLVal $2338 = _v1943.termRef(0);
                  ESLVal $2337 = _v1943.termRef(1);
                  
                  {ESLVal n = $2338;
                  
                  {ESLVal _v2007 = $2337;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JIArm",n,renameJVarsCommand.apply(_v2007,vars,env))));
                }
                }
                }
                default: {ESLVal _0 = _v1943;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten(),renameJVarsCommand.apply(alt,vars,env));
        }
        }
        }
        }
      case "JCaseStr": {ESLVal $2283 = _v1927.termRef(0);
          ESLVal $2282 = _v1927.termRef(1);
          ESLVal $2281 = _v1927.termRef(2);
          
          {ESLVal e = $2283;
          
          {ESLVal arms = $2282;
          
          {ESLVal alt = $2281;
          
          return new ESLVal("JCaseStr",renameJVarsExp.apply(e,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1942 = $qualArg;
                
                switch(_v1942.termName) {
                case "JSArm": {ESLVal $2336 = _v1942.termRef(0);
                  ESLVal $2335 = _v1942.termRef(1);
                  
                  {ESLVal s = $2336;
                  
                  {ESLVal _v2006 = $2335;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JSArm",s,renameJVarsCommand.apply(_v2006,vars,env))));
                }
                }
                }
                default: {ESLVal _0 = _v1942;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten(),renameJVarsCommand.apply(alt,vars,env));
        }
        }
        }
        }
      case "JCaseBool": {ESLVal $2280 = _v1927.termRef(0);
          ESLVal $2279 = _v1927.termRef(1);
          ESLVal $2278 = _v1927.termRef(2);
          
          {ESLVal e = $2280;
          
          {ESLVal arms = $2279;
          
          {ESLVal alt = $2278;
          
          return new ESLVal("JCaseBool",renameJVarsExp.apply(e,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1941 = $qualArg;
                
                switch(_v1941.termName) {
                case "JBArm": {ESLVal $2334 = _v1941.termRef(0);
                  ESLVal $2333 = _v1941.termRef(1);
                  
                  {ESLVal b = $2334;
                  
                  {ESLVal _v2005 = $2333;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JBArm",b,renameJVarsCommand.apply(_v2005,vars,env))));
                }
                }
                }
                default: {ESLVal _0 = _v1941;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten(),renameJVarsCommand.apply(alt,vars,env));
        }
        }
        }
        }
      case "JCaseTerm": {ESLVal $2277 = _v1927.termRef(0);
          ESLVal $2276 = _v1927.termRef(1);
          ESLVal $2275 = _v1927.termRef(2);
          
          {ESLVal e = $2277;
          
          {ESLVal arms = $2276;
          
          {ESLVal alt = $2275;
          
          return new ESLVal("JCaseTerm",renameJVarsExp.apply(e,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v1940 = $qualArg;
                
                switch(_v1940.termName) {
                case "JTArm": {ESLVal $2332 = _v1940.termRef(0);
                  ESLVal $2331 = _v1940.termRef(1);
                  ESLVal $2330 = _v1940.termRef(2);
                  
                  {ESLVal n = $2332;
                  
                  {ESLVal i = $2331;
                  
                  {ESLVal _v2004 = $2330;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JTArm",n,i,renameJVarsCommand.apply(_v2004,vars,env))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v1940;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten(),renameJVarsCommand.apply(alt,vars,env));
        }
        }
        }
        }
      case "JLet": {ESLVal $2274 = _v1927.termRef(0);
          ESLVal $2273 = _v1927.termRef(1);
          
          {ESLVal v0 = $2274;
          
          {ESLVal v1 = $2273;
          
          {ESLVal boundNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v1936 = $qualArg;
                  
                  switch(_v1936.termName) {
                  case "JField": {ESLVal $2323 = _v1936.termRef(0);
                    ESLVal $2322 = _v1936.termRef(1);
                    ESLVal $2321 = _v1936.termRef(2);
                    
                    {ESLVal n = $2323;
                    
                    {ESLVal t = $2322;
                    
                    {ESLVal e = $2321;
                    
                    return ESLVal.list(ESLVal.list(n));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v1936;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten();
          
          if(exists.apply(new ESLVal(new Function(new ESLVal("fun939"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal n = $args[0];
        return member.apply(n,vars);
          }
        }),boundNames).boolVal)
          {ESLVal newNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v1937 = $qualArg;
                    
                    {ESLVal n = _v1937;
                    
                    return ESLVal.list(ESLVal.list(newName.apply()));
                  }
                  }
                }
              }).map(boundNames).flatten().flatten();
            
            {ESLVal env1 = addEntries.apply(boundNames,newNames,env);
            
            return new ESLVal("JLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v1938 = $qualArg;
                  
                  switch(_v1938.termName) {
                  case "JField": {ESLVal $2326 = _v1938.termRef(0);
                    ESLVal $2325 = _v1938.termRef(1);
                    ESLVal $2324 = _v1938.termRef(2);
                    
                    {ESLVal n = $2326;
                    
                    {ESLVal t = $2325;
                    
                    {ESLVal e = $2324;
                    
                    return ESLVal.list(ESLVal.list(new ESLVal("JField",lookup.apply(n,env1),t,renameJVarsExp.apply(e,vars,env))));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v1938;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten(),renameJVarsCommand.apply(v1,boundNames.add(vars),env1));
          }
          }
          else
            return new ESLVal("JLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v1939 = $qualArg;
                    
                    switch(_v1939.termName) {
                    case "JField": {ESLVal $2329 = _v1939.termRef(0);
                      ESLVal $2328 = _v1939.termRef(1);
                      ESLVal $2327 = _v1939.termRef(2);
                      
                      {ESLVal n = $2329;
                      
                      {ESLVal t = $2328;
                      
                      {ESLVal e = $2327;
                      
                      return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(e,vars,env))));
                    }
                    }
                    }
                    }
                    default: {ESLVal _0 = _v1939;
                      
                      return ESLVal.list();
                    }
                  }
                  }
                }
              }).map(v0).flatten().flatten(),renameJVarsCommand.apply(v1,boundNames.add(vars),env));
        }
        }
        }
        }
      case "JPLet": {ESLVal $2272 = _v1927.termRef(0);
          ESLVal $2271 = _v1927.termRef(1);
          
          {ESLVal v0 = $2272;
          
          {ESLVal v1 = $2271;
          
          {ESLVal boundNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v1932 = $qualArg;
                  
                  switch(_v1932.termName) {
                  case "JField": {ESLVal $2314 = _v1932.termRef(0);
                    ESLVal $2313 = _v1932.termRef(1);
                    ESLVal $2312 = _v1932.termRef(2);
                    
                    {ESLVal n = $2314;
                    
                    {ESLVal t = $2313;
                    
                    {ESLVal e = $2312;
                    
                    return ESLVal.list(ESLVal.list(n));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v1932;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten();
          
          if(exists.apply(new ESLVal(new Function(new ESLVal("fun940"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal n = $args[0];
        return member.apply(n,vars);
          }
        }),boundNames).boolVal)
          {ESLVal newNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v1933 = $qualArg;
                    
                    {ESLVal n = _v1933;
                    
                    return ESLVal.list(ESLVal.list(newName.apply()));
                  }
                  }
                }
              }).map(boundNames).flatten().flatten();
            
            {ESLVal env1 = addEntries.apply(boundNames,newNames,env);
            
            return new ESLVal("JPLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v1934 = $qualArg;
                  
                  switch(_v1934.termName) {
                  case "JField": {ESLVal $2317 = _v1934.termRef(0);
                    ESLVal $2316 = _v1934.termRef(1);
                    ESLVal $2315 = _v1934.termRef(2);
                    
                    {ESLVal n = $2317;
                    
                    {ESLVal t = $2316;
                    
                    {ESLVal e = $2315;
                    
                    return ESLVal.list(ESLVal.list(new ESLVal("JField",lookup.apply(n,env1),t,renameJVarsExp.apply(e,vars,env))));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v1934;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten(),renameJVarsCommand.apply(v1,boundNames.add(vars),env1));
          }
          }
          else
            return new ESLVal("JPLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v1935 = $qualArg;
                    
                    switch(_v1935.termName) {
                    case "JField": {ESLVal $2320 = _v1935.termRef(0);
                      ESLVal $2319 = _v1935.termRef(1);
                      ESLVal $2318 = _v1935.termRef(2);
                      
                      {ESLVal n = $2320;
                      
                      {ESLVal t = $2319;
                      
                      {ESLVal e = $2318;
                      
                      return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(e,vars,env))));
                    }
                    }
                    }
                    }
                    default: {ESLVal _0 = _v1935;
                      
                      return ESLVal.list();
                    }
                  }
                  }
                }
              }).map(v0).flatten().flatten(),renameJVarsCommand.apply(v1,boundNames.add(vars),env));
        }
        }
        }
        }
      case "JLetRec": {ESLVal $2270 = _v1927.termRef(0);
          ESLVal $2269 = _v1927.termRef(1);
          
          {ESLVal v0 = $2270;
          
          {ESLVal v1 = $2269;
          
          {ESLVal boundNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v1928 = $qualArg;
                  
                  switch(_v1928.termName) {
                  case "JField": {ESLVal $2305 = _v1928.termRef(0);
                    ESLVal $2304 = _v1928.termRef(1);
                    ESLVal $2303 = _v1928.termRef(2);
                    
                    {ESLVal n = $2305;
                    
                    {ESLVal t = $2304;
                    
                    {ESLVal e = $2303;
                    
                    return ESLVal.list(ESLVal.list(n));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v1928;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten();
          
          if(exists.apply(new ESLVal(new Function(new ESLVal("fun941"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal n = $args[0];
        return member.apply(n,vars);
          }
        }),boundNames).boolVal)
          {ESLVal newNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v1929 = $qualArg;
                    
                    {ESLVal n = _v1929;
                    
                    return ESLVal.list(ESLVal.list(newName.apply()));
                  }
                  }
                }
              }).map(boundNames).flatten().flatten();
            
            {ESLVal _v2003 = addEntries.apply(boundNames,newNames,env);
            
            return new ESLVal("JLetRec",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v1930 = $qualArg;
                  
                  switch(_v1930.termName) {
                  case "JField": {ESLVal $2308 = _v1930.termRef(0);
                    ESLVal $2307 = _v1930.termRef(1);
                    ESLVal $2306 = _v1930.termRef(2);
                    
                    {ESLVal n = $2308;
                    
                    {ESLVal t = $2307;
                    
                    {ESLVal e = $2306;
                    
                    return ESLVal.list(ESLVal.list(new ESLVal("JField",lookup.apply(n,_v2003),t,renameJVarsExp.apply(e,vars,_v2003))));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v1930;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten(),renameJVarsCommand.apply(v1,boundNames.add(vars),_v2003));
          }
          }
          else
            return new ESLVal("JLetRec",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v1931 = $qualArg;
                    
                    switch(_v1931.termName) {
                    case "JField": {ESLVal $2311 = _v1931.termRef(0);
                      ESLVal $2310 = _v1931.termRef(1);
                      ESLVal $2309 = _v1931.termRef(2);
                      
                      {ESLVal n = $2311;
                      
                      {ESLVal t = $2310;
                      
                      {ESLVal e = $2309;
                      
                      return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(e,vars,env))));
                    }
                    }
                    }
                    }
                    default: {ESLVal _0 = _v1931;
                      
                      return ESLVal.list();
                    }
                  }
                  }
                }
              }).map(v0).flatten().flatten(),renameJVarsCommand.apply(v1,boundNames.add(vars),env));
        }
        }
        }
        }
      case "JStatement": {ESLVal $2268 = _v1927.termRef(0);
          
          {ESLVal e = $2268;
          
          return new ESLVal("JStatement",renameJVarsExp.apply(e,vars,env));
        }
        }
      case "JUpdate": {ESLVal $2267 = _v1927.termRef(0);
          ESLVal $2266 = _v1927.termRef(1);
          
          {ESLVal name = $2267;
          
          {ESLVal value = $2266;
          
          if(hasEntry.apply(name,env).boolVal)
          return new ESLVal("JUpdate",lookup.apply(name,env),renameJVarsExp.apply(value,vars,env));
          else
            {ESLVal v0 = $2267;
              
              {ESLVal v1 = $2266;
              
              return new ESLVal("JUpdate",v0,renameJVarsExp.apply(v1,vars,env));
            }
            }
        }
        }
        }
      case "JFor": {ESLVal $2265 = _v1927.termRef(0);
          ESLVal $2264 = _v1927.termRef(1);
          ESLVal $2263 = _v1927.termRef(2);
          ESLVal $2262 = _v1927.termRef(3);
          
          {ESLVal l = $2265;
          
          {ESLVal n = $2264;
          
          {ESLVal e = $2263;
          
          {ESLVal _v2002 = $2262;
          
          return new ESLVal("JFor",l,n,renameJVarsExp.apply(e,vars,env),renameJVarsCommand.apply(_v2002,vars,env));
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(25090,29498)").add(ESLVal.list(_v1927)));
      }
      }
    }
  });
  public static ESLVal main = new ESLVal(new Function(new ESLVal("main"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      return new ESLVal(new BehaviourAdapter(true,getSelf(),new ESLVal("main")) {
          
          public ESLVal handle(ESLVal $m) {{ESLVal _v1926 = $m;
            
            return error(new ESLVal("case error at Pos(0,0)").add(ESLVal.list(_v1926)));
          }}
          public ESLVal get(String name) {
            switch(name) {
              
              default: throw new Error("ref illegal " + self + "." + name);
            }
          }
        public void handleTime(ESLVal $t) {
          {ESLVal n = $t;
            
            if($true.boolVal)
            {print.apply(new ESLVal("").add(emptyTable));
            stopAll.apply();}
            else
              {}
          }
        }
        public ESLVal init() {
            return $null;
          }
        });
    }
  });
public static void main(String[] args) {
    newActor(main,new ESLVal(new Actor())); 
  }
}