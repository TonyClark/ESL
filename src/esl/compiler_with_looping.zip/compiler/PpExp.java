package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
// import static esl.Lists.*;
import static esl.compiler.Types.*;
import static esl.compiler.DynamicVars.*;
import static esl.compiler.Strings.*;
import java.util.function.Supplier;
public class PpExp {
  public static ESLVal getSelf() { return $null; }
  private static ESLVal p0 = new ESLVal("Pos",$zero,$zero);
  private static ESLVal indentStr = new ESLVal(new Function(new ESLVal("indentStr"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  if(indent.eql($zero).boolVal)
        return new ESLVal("");
        else
          return new ESLVal(" ").add(indentStr.apply(indent.sub($one)));
    }
  });
  private static ESLVal nl = new ESLVal(new Function(new ESLVal("nl"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  return new ESLVal("\n").add(indentStr.apply(indent));
    }
  });
  private static ESLVal ppJoin = new ESLVal(new Function(new ESLVal("ppJoin"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal ss = $args[1];
  {ESLVal _v59 = ss;
        
        if(_v59.isCons())
        {ESLVal $498 = _v59.head();
          ESLVal $499 = _v59.tail();
          
          if($499.isCons())
          {ESLVal $500 = $499.head();
            ESLVal $501 = $499.tail();
            
            if($501.isCons())
            {ESLVal $502 = $501.head();
              ESLVal $503 = $501.tail();
              
              {ESLVal s = $498;
              
              {ESLVal _v136 = $499;
              
              return s.add(nl.apply(indent).add(ppJoin.apply(indent,_v136)));
            }
            }
            }
          else if($501.isNil())
            {ESLVal s1 = $498;
              
              {ESLVal s2 = $500;
              
              return s1.add(nl.apply(indent).add(s2));
            }
            }
          else {ESLVal s = $498;
              
              {ESLVal _v137 = $499;
              
              return s.add(nl.apply(indent).add(ppJoin.apply(indent,_v137)));
            }
            }
          }
        else if($499.isNil())
          {ESLVal s = $498;
            
            return s;
          }
        else {ESLVal s = $498;
            
            {ESLVal _v138 = $499;
            
            return s.add(nl.apply(indent).add(ppJoin.apply(indent,_v138)));
          }
          }
        }
      else if(_v59.isNil())
        return new ESLVal("");
      else return error(new ESLVal("case error at Pos(441,599)").add(ESLVal.list(_v59)));
      }
    }
  });
  public static ESLVal ppTypeEnv = new ESLVal(new Function(new ESLVal("ppTypeEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal env = $args[0];
  {ESLVal[] s = new ESLVal[]{new ESLVal("[")};
        
        {{
        ESLVal _v57 = env;
        while(_v57.isCons()) {
          ESLVal _v56 = _v57.headVal;
          {ESLVal _v55 = new ESLVal(new Function(new ESLVal("forp"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  {ESLVal _v58 = _v56;
                    
                    switch(_v58.termName) {
                    case "Map": {ESLVal $497 = _v58.termRef(0);
                      ESLVal $496 = _v58.termRef(1);
                      
                      {ESLVal n = $497;
                      
                      {ESLVal t = $496;
                      
                      {s[0] = s[0].add(n.add(new ESLVal("->").add(ppType.apply(t).add(new ESLVal(",")))));
                    return $null;}
                    }
                    }
                    }
                    default: {ESLVal $$$ = _v58;
                      
                      return $null;
                    }
                  }
                  }
                }
              });
            
            _v55.apply();
          }
          _v57 = _v57.tailVal;}
      }
      return s[0].add(new ESLVal("]"));}
      }
    }
  });
  public static ESLVal ppTypes = new ESLVal(new Function(new ESLVal("ppTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal ts = $args[0];
  return map.apply(ppType,ts);
    }
  });
  public static ESLVal ppType = new ESLVal(new Function(new ESLVal("ppType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v54 = t;
        
        switch(_v54.termName) {
        case "ActType": {ESLVal $495 = _v54.termRef(0);
          ESLVal $494 = _v54.termRef(1);
          ESLVal $493 = _v54.termRef(2);
          
          {ESLVal l = $495;
          
          {ESLVal decs = $494;
          
          {ESLVal handlers = $493;
          
          return new ESLVal("").add(t);
        }
        }
        }
        }
      case "ApplyType": {ESLVal $492 = _v54.termRef(0);
          ESLVal $491 = _v54.termRef(1);
          ESLVal $490 = _v54.termRef(2);
          
          {ESLVal l = $492;
          
          {ESLVal n = $491;
          
          {ESLVal args = $490;
          
          return n.add(map.apply(ppType,args));
        }
        }
        }
        }
      case "ApplyTypeFun": {ESLVal $489 = _v54.termRef(0);
          ESLVal $488 = _v54.termRef(1);
          ESLVal $487 = _v54.termRef(2);
          
          {ESLVal l = $489;
          
          {ESLVal op = $488;
          
          {ESLVal args = $487;
          
          return ppType.apply(op).add(map.apply(ppType,args));
        }
        }
        }
        }
      case "ArrayType": {ESLVal $486 = _v54.termRef(0);
          ESLVal $485 = _v54.termRef(1);
          
          {ESLVal l = $486;
          
          {ESLVal _v135 = $485;
          
          return new ESLVal("Array[").add(ppType.apply(_v135).add(new ESLVal("]")));
        }
        }
        }
      case "BoolType": {ESLVal $484 = _v54.termRef(0);
          
          {ESLVal l = $484;
          
          return new ESLVal("Bool");
        }
        }
      case "FloatType": {ESLVal $483 = _v54.termRef(0);
          
          {ESLVal l = $483;
          
          return new ESLVal("Float");
        }
        }
      case "FieldType": {ESLVal $482 = _v54.termRef(0);
          ESLVal $481 = _v54.termRef(1);
          ESLVal $480 = _v54.termRef(2);
          
          {ESLVal l = $482;
          
          {ESLVal n = $481;
          
          {ESLVal _v134 = $480;
          
          return n.add(new ESLVal("::").add(ppType.apply(_v134)));
        }
        }
        }
        }
      case "ForallType": {ESLVal $479 = _v54.termRef(0);
          ESLVal $478 = _v54.termRef(1);
          ESLVal $477 = _v54.termRef(2);
          
          {ESLVal l = $479;
          
          {ESLVal ns = $478;
          
          {ESLVal _v133 = $477;
          
          return new ESLVal("Forall").add(ns.add(new ESLVal(".").add(ppType.apply(_v133))));
        }
        }
        }
        }
      case "FunType": {ESLVal $476 = _v54.termRef(0);
          ESLVal $475 = _v54.termRef(1);
          ESLVal $474 = _v54.termRef(2);
          
          {ESLVal l = $476;
          
          {ESLVal d = $475;
          
          {ESLVal r = $474;
          
          return map.apply(ppType,d).add(new ESLVal("->").add(ppType.apply(r)));
        }
        }
        }
        }
      case "TaggedFunType": {ESLVal $473 = _v54.termRef(0);
          ESLVal $472 = _v54.termRef(1);
          ESLVal $471 = _v54.termRef(2);
          ESLVal $470 = _v54.termRef(3);
          
          {ESLVal l = $473;
          
          {ESLVal d = $472;
          
          {ESLVal p = $471;
          
          {ESLVal r = $470;
          
          return map.apply(ppType,d).add(new ESLVal("->").add(ppType.apply(r)));
        }
        }
        }
        }
        }
      case "IntType": {ESLVal $469 = _v54.termRef(0);
          
          {ESLVal l = $469;
          
          return new ESLVal("Int");
        }
        }
      case "ListType": {ESLVal $468 = _v54.termRef(0);
          ESLVal $467 = _v54.termRef(1);
          
          {ESLVal l = $468;
          
          {ESLVal _v132 = $467;
          
          return new ESLVal("[").add(ppType.apply(_v132).add(new ESLVal("]")));
        }
        }
        }
      case "NullType": {ESLVal $466 = _v54.termRef(0);
          
          {ESLVal l = $466;
          
          return new ESLVal("Null");
        }
        }
      case "RecType": {ESLVal $465 = _v54.termRef(0);
          ESLVal $464 = _v54.termRef(1);
          ESLVal $463 = _v54.termRef(2);
          
          {ESLVal l = $465;
          
          {ESLVal n = $464;
          
          {ESLVal _v131 = $463;
          
          return new ESLVal("rec ").add(n.add(new ESLVal(".").add(ppType.apply(_v131))));
        }
        }
        }
        }
      case "RecordType": {ESLVal $462 = _v54.termRef(0);
          ESLVal $461 = _v54.termRef(1);
          
          {ESLVal l = $462;
          
          {ESLVal fs = $461;
          
          return new ESLVal("{").add(fs.add(new ESLVal("}")));
        }
        }
        }
      case "StrType": {ESLVal $460 = _v54.termRef(0);
          
          {ESLVal l = $460;
          
          return new ESLVal("Str");
        }
        }
      case "TableType": {ESLVal $459 = _v54.termRef(0);
          ESLVal $458 = _v54.termRef(1);
          ESLVal $457 = _v54.termRef(2);
          
          {ESLVal l = $459;
          
          {ESLVal k = $458;
          
          {ESLVal v = $457;
          
          return new ESLVal("Hash[").add(ppType.apply(k).add(new ESLVal(",").add(ppType.apply(v).add(new ESLVal("]")))));
        }
        }
        }
        }
      case "TermType": {ESLVal $456 = _v54.termRef(0);
          ESLVal $455 = _v54.termRef(1);
          ESLVal $454 = _v54.termRef(2);
          
          {ESLVal l = $456;
          
          {ESLVal n = $455;
          
          {ESLVal ts = $454;
          
          return n.add(map.apply(ppType,ts));
        }
        }
        }
        }
      case "TypeFun": {ESLVal $453 = _v54.termRef(0);
          ESLVal $452 = _v54.termRef(1);
          ESLVal $451 = _v54.termRef(2);
          
          {ESLVal l = $453;
          
          {ESLVal ns = $452;
          
          {ESLVal _v130 = $451;
          
          return new ESLVal("Fun").add(ns.add(new ESLVal(".").add(ppType.apply(_v130))));
        }
        }
        }
        }
      case "UnfoldType": {ESLVal $450 = _v54.termRef(0);
          ESLVal $449 = _v54.termRef(1);
          
          {ESLVal l = $450;
          
          {ESLVal _v129 = $449;
          
          return new ESLVal("unfold ").add(ppType.apply(_v129));
        }
        }
        }
      case "UnionType": {ESLVal $448 = _v54.termRef(0);
          ESLVal $447 = _v54.termRef(1);
          
          {ESLVal l = $448;
          
          {ESLVal ts = $447;
          
          return new ESLVal("union ").add(map.apply(ppType,ts));
        }
        }
        }
      case "VarType": {ESLVal $446 = _v54.termRef(0);
          ESLVal $445 = _v54.termRef(1);
          
          {ESLVal l = $446;
          
          {ESLVal n = $445;
          
          return n;
        }
        }
        }
      case "VoidType": {ESLVal $444 = _v54.termRef(0);
          
          {ESLVal l = $444;
          
          return new ESLVal("Void");
        }
        }
      case "UnionRef": {ESLVal $443 = _v54.termRef(0);
          ESLVal $442 = _v54.termRef(1);
          ESLVal $441 = _v54.termRef(2);
          
          {ESLVal l = $443;
          
          {ESLVal _v128 = $442;
          
          {ESLVal n = $441;
          
          return ppType.apply(_v128).add(new ESLVal(".").add(n));
        }
        }
        }
        }
      case "TypeClosure": {ESLVal $440 = _v54.termRef(0);
          
          {ESLVal f = $440;
          
          return f.add(new ESLVal(""));
        }
        }
        default: {ESLVal x = _v54;
          
          return new ESLVal("<unknown ").add(x.add(new ESLVal(">")));
        }
      }
      }
    }
  });
  public static ESLVal ppExps = new ESLVal(new Function(new ESLVal("ppExps"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal exps = $args[1];
  ESLVal sep = $args[2];
  {ESLVal _v53 = exps;
        
        if(_v53.isCons())
        {ESLVal $436 = _v53.head();
          ESLVal $437 = _v53.tail();
          
          if($437.isCons())
          {ESLVal $438 = $437.head();
            ESLVal $439 = $437.tail();
            
            {ESLVal e1 = $436;
            
            {ESLVal e2 = $438;
            
            {ESLVal es = $439;
            
            return ppExp.apply(indent,e1).add(sep.add(ppExps.apply(indent,es.cons(e2),sep)));
          }
          }
          }
          }
        else if($437.isNil())
          {ESLVal e = $436;
            
            return ppExp.apply(indent,e);
          }
        else return error(new ESLVal("case error at Pos(2412,2570)").add(ESLVal.list(_v53)));
        }
      else if(_v53.isNil())
        return new ESLVal("");
      else return error(new ESLVal("case error at Pos(2412,2570)").add(ESLVal.list(_v53)));
      }
    }
  });
  private static ESLVal ppPattern = new ESLVal(new Function(new ESLVal("ppPattern"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v52 = p;
        
        switch(_v52.termName) {
        case "PVar": {ESLVal $435 = _v52.termRef(0);
          ESLVal $434 = _v52.termRef(1);
          ESLVal $433 = _v52.termRef(2);
          
          {ESLVal l = $435;
          
          {ESLVal n = $434;
          
          {ESLVal t = $433;
          
          return n;
        }
        }
        }
        }
      case "PTerm": {ESLVal $430 = _v52.termRef(0);
          ESLVal $429 = _v52.termRef(1);
          ESLVal $428 = _v52.termRef(2);
          ESLVal $427 = _v52.termRef(3);
          
          if($428.isCons())
          {ESLVal $431 = $428.head();
            ESLVal $432 = $428.tail();
            
            {ESLVal l = $430;
            
            {ESLVal n = $429;
            
            {ESLVal ts = $428;
            
            {ESLVal ps = $427;
            
            return n.add(ppPatterns.apply(ps));
          }
          }
          }
          }
          }
        else if($428.isNil())
          {ESLVal l = $430;
            
            {ESLVal n = $429;
            
            {ESLVal ps = $427;
            
            return n.add(ppPatterns.apply(ps));
          }
          }
          }
        else {ESLVal l = $430;
            
            {ESLVal n = $429;
            
            {ESLVal ts = $428;
            
            {ESLVal ps = $427;
            
            return n.add(ppPatterns.apply(ps));
          }
          }
          }
          }
        }
      case "PApplyType": {ESLVal $426 = _v52.termRef(0);
          ESLVal $425 = _v52.termRef(1);
          ESLVal $424 = _v52.termRef(2);
          
          {ESLVal l = $426;
          
          {ESLVal _v126 = $425;
          
          {ESLVal ts = $424;
          
          return ppPattern.apply(_v126);
        }
        }
        }
        }
      case "PNil": {ESLVal $423 = _v52.termRef(0);
          
          {ESLVal l = $423;
          
          return new ESLVal("[]");
        }
        }
      case "PInt": {ESLVal $422 = _v52.termRef(0);
          ESLVal $421 = _v52.termRef(1);
          
          {ESLVal l = $422;
          
          {ESLVal n = $421;
          
          return new ESLVal("").add(n);
        }
        }
        }
      case "PBool": {ESLVal $420 = _v52.termRef(0);
          ESLVal $419 = _v52.termRef(1);
          
          {ESLVal l = $420;
          
          {ESLVal b = $419;
          
          return new ESLVal("").add(b);
        }
        }
        }
      case "PStr": {ESLVal $418 = _v52.termRef(0);
          ESLVal $417 = _v52.termRef(1);
          
          {ESLVal l = $418;
          
          {ESLVal s = $417;
          
          return new ESLVal("\'").add(s.add(new ESLVal("\'")));
        }
        }
        }
      case "PCons": {ESLVal $416 = _v52.termRef(0);
          ESLVal $415 = _v52.termRef(1);
          ESLVal $414 = _v52.termRef(2);
          
          {ESLVal l = $416;
          
          {ESLVal h = $415;
          
          {ESLVal t = $414;
          
          return ppPattern.apply(h).add(new ESLVal(":").add(ppPattern.apply(t)));
        }
        }
        }
        }
        default: {ESLVal _v127 = _v52;
          
          return new ESLVal("<unknown: ").add(_v127.add(new ESLVal(">")));
        }
      }
      }
    }
  });
  private static ESLVal ppPatterns = new ESLVal(new Function(new ESLVal("ppPatterns"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal ps = $args[0];
  return map.apply(ppPattern,ps);
    }
  });
  public static ESLVal ppExp = new ESLVal(new Function(new ESLVal("ppExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal exp = $args[1];
  {ESLVal _v51 = exp;
        
        switch(_v51.termName) {
        case "Module": {ESLVal $413 = _v51.termRef(0);
          ESLVal $412 = _v51.termRef(1);
          ESLVal $411 = _v51.termRef(2);
          ESLVal $410 = _v51.termRef(3);
          ESLVal $409 = _v51.termRef(4);
          ESLVal $408 = _v51.termRef(5);
          ESLVal $407 = _v51.termRef(6);
          
          {ESLVal path = $413;
          
          {ESLVal name = $412;
          
          {ESLVal exports = $411;
          
          {ESLVal imports = $410;
          
          {ESLVal x = $409;
          
          {ESLVal y = $408;
          
          {ESLVal defs = $407;
          
          return new ESLVal("module ").add(name.add(new ESLVal("{").add(nl.apply(indent.add(new ESLVal(2))).add(ppBinds.apply(indent.add(new ESLVal(2)),defs).add(nl.apply(indent).add(new ESLVal("}")))))));
        }
        }
        }
        }
        }
        }
        }
        }
      case "Var": {ESLVal $406 = _v51.termRef(0);
          ESLVal $405 = _v51.termRef(1);
          
          {ESLVal l = $406;
          
          {ESLVal n = $405;
          
          return n;
        }
        }
        }
      case "StrExp": {ESLVal $404 = _v51.termRef(0);
          ESLVal $403 = _v51.termRef(1);
          
          {ESLVal l = $404;
          
          {ESLVal v = $403;
          
          return new ESLVal("\'").add(v.add(new ESLVal("\'")));
        }
        }
        }
      case "IntExp": {ESLVal $402 = _v51.termRef(0);
          ESLVal $401 = _v51.termRef(1);
          
          {ESLVal l = $402;
          
          {ESLVal v = $401;
          
          return v.add(new ESLVal(""));
        }
        }
        }
      case "BoolExp": {ESLVal $400 = _v51.termRef(0);
          ESLVal $399 = _v51.termRef(1);
          
          {ESLVal l = $400;
          
          {ESLVal v = $399;
          
          return v.add(new ESLVal(""));
        }
        }
        }
      case "NullExp": {ESLVal $398 = _v51.termRef(0);
          
          {ESLVal l = $398;
          
          return new ESLVal("null");
        }
        }
      case "FloatExp": {ESLVal $397 = _v51.termRef(0);
          ESLVal $396 = _v51.termRef(1);
          
          {ESLVal l = $397;
          
          {ESLVal f = $396;
          
          return f.add(new ESLVal(""));
        }
        }
        }
      case "Apply": {ESLVal $395 = _v51.termRef(0);
          ESLVal $394 = _v51.termRef(1);
          ESLVal $393 = _v51.termRef(2);
          
          {ESLVal l = $395;
          
          {ESLVal op = $394;
          
          {ESLVal args = $393;
          
          return ppExp.apply(indent,op).add(new ESLVal("(").add(ppExps.apply(indent,args,new ESLVal(",")).add(new ESLVal(")"))));
        }
        }
        }
        }
      case "ApplyTypeExp": {ESLVal $392 = _v51.termRef(0);
          ESLVal $391 = _v51.termRef(1);
          ESLVal $390 = _v51.termRef(2);
          
          {ESLVal l = $392;
          
          {ESLVal op = $391;
          
          {ESLVal args = $390;
          
          return ppExp.apply(indent,op);
        }
        }
        }
        }
      case "Block": {ESLVal $389 = _v51.termRef(0);
          ESLVal $388 = _v51.termRef(1);
          
          {ESLVal l = $389;
          
          {ESLVal es = $388;
          
          return new ESLVal("{").add(nl.apply(indent.add(new ESLVal(2))).add(ppExps.apply(indent.add(new ESLVal(2)),es,new ESLVal(";")).add(nl.apply(indent).add(new ESLVal("}")))));
        }
        }
        }
      case "Case": {ESLVal $387 = _v51.termRef(0);
          ESLVal $386 = _v51.termRef(1);
          ESLVal $385 = _v51.termRef(2);
          ESLVal $384 = _v51.termRef(3);
          
          {ESLVal l = $387;
          
          {ESLVal ds = $386;
          
          {ESLVal es = $385;
          
          {ESLVal as = $384;
          
          return new ESLVal("case ").add(ppExps.apply(indent,es,new ESLVal(",")).add(new ESLVal(" {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun620"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal a = $args[0];
          return ppArm.apply(indent,a);
            }
          }),as)).add(nl.apply(indent).add(new ESLVal("}")))))));
        }
        }
        }
        }
        }
      case "CaseTerm": {ESLVal $383 = _v51.termRef(0);
          ESLVal $382 = _v51.termRef(1);
          ESLVal $381 = _v51.termRef(2);
          ESLVal $380 = _v51.termRef(3);
          
          {ESLVal l = $383;
          
          {ESLVal e = $382;
          
          {ESLVal arms = $381;
          
          {ESLVal alt = $380;
          
          return new ESLVal("caseTerm ").add(ppExp.apply(indent,e).add(new ESLVal(" {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun621"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal a = $args[0];
          return ppCaseTermArm.apply(indent.add(new ESLVal(2)),a);
            }
          }),arms)).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("else ").add(ppExp.apply(indent.add(new ESLVal(4)),alt).add(nl.apply(indent).add(new ESLVal("}"))))))))));
        }
        }
        }
        }
        }
      case "CaseList": {ESLVal $379 = _v51.termRef(0);
          ESLVal $378 = _v51.termRef(1);
          ESLVal $377 = _v51.termRef(2);
          ESLVal $376 = _v51.termRef(3);
          ESLVal $375 = _v51.termRef(4);
          
          {ESLVal l = $379;
          
          {ESLVal e = $378;
          
          {ESLVal cons = $377;
          
          {ESLVal nil = $376;
          
          {ESLVal alt = $375;
          
          return new ESLVal("caseList ").add(ppExp.apply(indent,e).add(new ESLVal(" {").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("CONS ->").add(nl.apply(indent.add(new ESLVal(4))).add(ppExp.apply(indent.add(new ESLVal(4)),cons).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("NIL ->").add(nl.apply(indent.add(new ESLVal(4))).add(ppExp.apply(indent.add(new ESLVal(4)),nil).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("else ").add(ppExp.apply(indent.add(new ESLVal(4)),alt).add(nl.apply(indent).add(new ESLVal("}"))))))))))))))));
        }
        }
        }
        }
        }
        }
      case "CaseInt": {ESLVal $374 = _v51.termRef(0);
          ESLVal $373 = _v51.termRef(1);
          ESLVal $372 = _v51.termRef(2);
          ESLVal $371 = _v51.termRef(3);
          
          {ESLVal l = $374;
          
          {ESLVal e = $373;
          
          {ESLVal arms = $372;
          
          {ESLVal alt = $371;
          
          return new ESLVal("caseInt ").add(ppExp.apply(indent,e).add(new ESLVal(" {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun622"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal a = $args[0];
          return ppCaseIntsArm.apply(indent.add(new ESLVal(2)),a);
            }
          }),arms)).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("else ").add(ppExp.apply(indent.add(new ESLVal(4)),alt).add(nl.apply(indent).add(new ESLVal("}"))))))))));
        }
        }
        }
        }
        }
      case "CaseStr": {ESLVal $370 = _v51.termRef(0);
          ESLVal $369 = _v51.termRef(1);
          ESLVal $368 = _v51.termRef(2);
          ESLVal $367 = _v51.termRef(3);
          
          {ESLVal l = $370;
          
          {ESLVal e = $369;
          
          {ESLVal arms = $368;
          
          {ESLVal alt = $367;
          
          return new ESLVal("caseStr ").add(ppExp.apply(indent,e).add(new ESLVal(" {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun623"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal a = $args[0];
          return ppCaseStrsArm.apply(indent.add(new ESLVal(2)),a);
            }
          }),arms)).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("else ").add(ppExp.apply(indent.add(new ESLVal(4)),alt).add(nl.apply(indent).add(new ESLVal("}"))))))))));
        }
        }
        }
        }
        }
      case "CaseBool": {ESLVal $366 = _v51.termRef(0);
          ESLVal $365 = _v51.termRef(1);
          ESLVal $364 = _v51.termRef(2);
          ESLVal $363 = _v51.termRef(3);
          
          {ESLVal l = $366;
          
          {ESLVal e = $365;
          
          {ESLVal arms = $364;
          
          {ESLVal alt = $363;
          
          return new ESLVal("caseBool ").add(ppExp.apply(indent,e).add(new ESLVal(" {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun624"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal a = $args[0];
          return ppCaseBoolsArm.apply(indent.add(new ESLVal(2)),a);
            }
          }),arms)).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("else ").add(ppExp.apply(indent.add(new ESLVal(4)),alt).add(nl.apply(indent).add(new ESLVal("}"))))))))));
        }
        }
        }
        }
        }
      case "CaseError": {ESLVal $362 = _v51.termRef(0);
          ESLVal $361 = _v51.termRef(1);
          
          {ESLVal l = $362;
          
          {ESLVal e = $361;
          
          return new ESLVal("caseError()");
        }
        }
        }
      case "Head": {ESLVal $360 = _v51.termRef(0);
          
          {ESLVal e = $360;
          
          return new ESLVal("head(").add(ppExp.apply(indent,e).add(new ESLVal(")")));
        }
        }
      case "Tail": {ESLVal $359 = _v51.termRef(0);
          
          {ESLVal e = $359;
          
          return new ESLVal("tail(").add(ppExp.apply(indent,e).add(new ESLVal(")")));
        }
        }
      case "Cons": {ESLVal $358 = _v51.termRef(0);
          ESLVal $357 = _v51.termRef(1);
          
          {ESLVal h = $358;
          
          {ESLVal t = $357;
          
          return new ESLVal("cons(").add(ppExp.apply(indent,h).add(new ESLVal(",").add(ppExp.apply(indent,t).add(new ESLVal(")")))));
        }
        }
        }
      case "If": {ESLVal $356 = _v51.termRef(0);
          ESLVal $355 = _v51.termRef(1);
          ESLVal $354 = _v51.termRef(2);
          ESLVal $353 = _v51.termRef(3);
          
          {ESLVal l = $356;
          
          {ESLVal e1 = $355;
          
          {ESLVal e2 = $354;
          
          {ESLVal e3 = $353;
          
          return new ESLVal("if ").add(ppExp.apply(indent,e1).add(nl.apply(indent).add(new ESLVal("then").add(nl.apply(indent.add(new ESLVal(2))).add(ppExp.apply(indent.add(new ESLVal(2)),e2).add(nl.apply(indent).add(new ESLVal("else").add(nl.apply(indent.add(new ESLVal(2))).add(ppExp.apply(indent.add(new ESLVal(2)),e3))))))))));
        }
        }
        }
        }
        }
      case "FunExp": {ESLVal $352 = _v51.termRef(0);
          ESLVal $351 = _v51.termRef(1);
          ESLVal $350 = _v51.termRef(2);
          ESLVal $349 = _v51.termRef(3);
          ESLVal $348 = _v51.termRef(4);
          
          {ESLVal l = $352;
          
          {ESLVal n = $351;
          
          {ESLVal args = $350;
          
          {ESLVal t = $349;
          
          {ESLVal e = $348;
          
          return new ESLVal("fun(").add(ppDecs.apply(indent,args).add(new ESLVal(")::").add(ppType.apply(t).add(new ESLVal(" ").add(ppExp.apply(indent.add(new ESLVal(2)),e))))));
        }
        }
        }
        }
        }
        }
      case "Let": {ESLVal $347 = _v51.termRef(0);
          ESLVal $346 = _v51.termRef(1);
          ESLVal $345 = _v51.termRef(2);
          
          {ESLVal l = $347;
          
          {ESLVal bs = $346;
          
          {ESLVal e = $345;
          
          return new ESLVal("let ").add(ppBinds.apply(indent.add(new ESLVal(4)),bs).add(nl.apply(indent).add(new ESLVal("in ").add(ppExp.apply(indent.add(new ESLVal(3)),e)))));
        }
        }
        }
        }
      case "Letrec": {ESLVal $344 = _v51.termRef(0);
          ESLVal $343 = _v51.termRef(1);
          ESLVal $342 = _v51.termRef(2);
          
          {ESLVal l = $344;
          
          {ESLVal bs = $343;
          
          {ESLVal e = $342;
          
          return new ESLVal("letrec ").add(ppBinds.apply(indent.add(new ESLVal(7)),bs).add(nl.apply(indent).add(new ESLVal("in ").add(ppExp.apply(indent.add(new ESLVal(3)),e)))));
        }
        }
        }
        }
      case "List": {ESLVal $341 = _v51.termRef(0);
          ESLVal $340 = _v51.termRef(1);
          
          {ESLVal l = $341;
          
          {ESLVal es = $340;
          
          return new ESLVal("[").add(ppExps.apply(indent,es,new ESLVal(",")).add(new ESLVal("]")));
        }
        }
        }
      case "Throw": {ESLVal $339 = _v51.termRef(0);
          ESLVal $338 = _v51.termRef(1);
          ESLVal $337 = _v51.termRef(2);
          
          {ESLVal l = $339;
          
          {ESLVal t = $338;
          
          {ESLVal e = $337;
          
          return new ESLVal("throw ").add(ppExp.apply(indent,e));
        }
        }
        }
        }
      case "Term": {ESLVal $336 = _v51.termRef(0);
          ESLVal $335 = _v51.termRef(1);
          ESLVal $334 = _v51.termRef(2);
          ESLVal $333 = _v51.termRef(3);
          
          {ESLVal l = $336;
          
          {ESLVal n = $335;
          
          {ESLVal ts = $334;
          
          {ESLVal es = $333;
          
          return n.add(new ESLVal("(").add(ppExps.apply(indent,es,new ESLVal(",")).add(new ESLVal(")"))));
        }
        }
        }
        }
        }
      case "TermRef": {ESLVal $332 = _v51.termRef(0);
          ESLVal $331 = _v51.termRef(1);
          
          {ESLVal e = $332;
          
          {ESLVal n = $331;
          
          return new ESLVal("termRef(").add(ppExp.apply(indent,e).add(new ESLVal(",").add(n.add(new ESLVal(")")))));
        }
        }
        }
      case "BinExp": {ESLVal $330 = _v51.termRef(0);
          ESLVal $329 = _v51.termRef(1);
          ESLVal $328 = _v51.termRef(2);
          ESLVal $327 = _v51.termRef(3);
          
          {ESLVal l = $330;
          
          {ESLVal e1 = $329;
          
          {ESLVal op = $328;
          
          {ESLVal e2 = $327;
          
          return ppExp.apply(indent,e1).add(op.add(ppExp.apply(indent,e2)));
        }
        }
        }
        }
        }
      case "Update": {ESLVal $326 = _v51.termRef(0);
          ESLVal $325 = _v51.termRef(1);
          ESLVal $324 = _v51.termRef(2);
          
          {ESLVal l = $326;
          
          {ESLVal n = $325;
          
          {ESLVal e = $324;
          
          return n.add(new ESLVal(" := ").add(ppExp.apply(indent,e)));
        }
        }
        }
        }
      case "NewArray": {ESLVal $323 = _v51.termRef(0);
          ESLVal $322 = _v51.termRef(1);
          ESLVal $321 = _v51.termRef(2);
          
          {ESLVal l = $323;
          
          {ESLVal t = $322;
          
          {ESLVal n = $321;
          
          return new ESLVal("new Array[").add(ppType.apply(t).add(new ESLVal("](").add(ppExp.apply(indent,n).add(new ESLVal(")")))));
        }
        }
        }
        }
      case "For": {ESLVal $320 = _v51.termRef(0);
          ESLVal $319 = _v51.termRef(1);
          ESLVal $318 = _v51.termRef(2);
          ESLVal $317 = _v51.termRef(3);
          
          {ESLVal l = $320;
          
          {ESLVal p = $319;
          
          {ESLVal e1 = $318;
          
          {ESLVal e2 = $317;
          
          return new ESLVal("for ").add(ppPattern.apply(p).add(new ESLVal(" in ").add(ppExp.apply(indent,e1).add(new ESLVal(" do {").add(nl.apply(indent.add(new ESLVal(2))).add(ppExp.apply(indent.add(new ESLVal(2)),e2).add(new ESLVal("}"))))))));
        }
        }
        }
        }
        }
      case "Try": {ESLVal $316 = _v51.termRef(0);
          ESLVal $315 = _v51.termRef(1);
          ESLVal $314 = _v51.termRef(2);
          
          {ESLVal l = $316;
          
          {ESLVal e = $315;
          
          {ESLVal as = $314;
          
          return new ESLVal("try ").add(ppExp.apply(indent,e).add(new ESLVal(" {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun625"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal a = $args[0];
          return ppArm.apply(indent,a);
            }
          }),as)).add(nl.apply(indent).add(new ESLVal("}")))))));
        }
        }
        }
        }
      case "ActExp": {ESLVal $313 = _v51.termRef(0);
          ESLVal $312 = _v51.termRef(1);
          ESLVal $311 = _v51.termRef(2);
          ESLVal $310 = _v51.termRef(3);
          ESLVal $309 = _v51.termRef(4);
          ESLVal $308 = _v51.termRef(5);
          ESLVal $307 = _v51.termRef(6);
          ESLVal $306 = _v51.termRef(7);
          
          {ESLVal l = $313;
          
          {ESLVal n = $312;
          
          {ESLVal args = $311;
          
          {ESLVal x = $310;
          
          {ESLVal parent = $309;
          
          {ESLVal locals = $308;
          
          {ESLVal init = $307;
          
          {ESLVal handlers = $306;
          
          return new ESLVal("act ").add(ppExp.apply(indent,n).add(new ESLVal("(").add(ppDecs.apply(indent,args).add(new ESLVal(") {").add(nl.apply(indent.add(new ESLVal(2))).add(ppBinds.apply(indent.add(new ESLVal(5)),locals).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("-> ").add(ppExp.apply(indent.add(new ESLVal(4)),init).add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun626"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal a = $args[0];
          return ppArm.apply(indent,a);
            }
          }),handlers)).add(nl.apply(indent).add(new ESLVal("}"))))))))))))));
        }
        }
        }
        }
        }
        }
        }
        }
        }
      case "Self": {ESLVal $305 = _v51.termRef(0);
          
          {ESLVal l = $305;
          
          return new ESLVal("self");
        }
        }
      case "Ref": {ESLVal $304 = _v51.termRef(0);
          ESLVal $303 = _v51.termRef(1);
          ESLVal $302 = _v51.termRef(2);
          
          {ESLVal l = $304;
          
          {ESLVal e = $303;
          
          {ESLVal n = $302;
          
          return ppExp.apply(indent,e).add(new ESLVal(".").add(n));
        }
        }
        }
        }
      case "Send": {ESLVal $301 = _v51.termRef(0);
          ESLVal $300 = _v51.termRef(1);
          ESLVal $299 = _v51.termRef(2);
          
          {ESLVal l = $301;
          
          {ESLVal target = $300;
          
          {ESLVal message = $299;
          
          return ppExp.apply(indent,target).add(new ESLVal(" <- ").add(ppExp.apply(indent,message)));
        }
        }
        }
        }
      case "Cmp": {ESLVal $298 = _v51.termRef(0);
          ESLVal $297 = _v51.termRef(1);
          ESLVal $296 = _v51.termRef(2);
          
          {ESLVal l = $298;
          
          {ESLVal e = $297;
          
          {ESLVal qs = $296;
          
          return new ESLVal("[").add(ppExp.apply(indent,e).add(new ESLVal(" | ").add(ppJoin.apply(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun627"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal q = $args[0];
          return ppQual.apply(indent,q);
            }
          }),qs)).add(new ESLVal("]")))));
        }
        }
        }
        }
      case "New": {ESLVal $295 = _v51.termRef(0);
          ESLVal $294 = _v51.termRef(1);
          ESLVal $293 = _v51.termRef(2);
          
          {ESLVal l = $295;
          
          {ESLVal b = $294;
          
          {ESLVal args = $293;
          
          return new ESLVal("new ").add(ppExp.apply(indent,b).add(new ESLVal("(").add(ppExps.apply(indent,args,new ESLVal(",")).add(new ESLVal(")")))));
        }
        }
        }
        }
      case "NewJava": {ESLVal $292 = _v51.termRef(0);
          ESLVal $291 = _v51.termRef(1);
          ESLVal $290 = _v51.termRef(2);
          ESLVal $289 = _v51.termRef(3);
          
          {ESLVal l = $292;
          
          {ESLVal className = $291;
          
          {ESLVal t = $290;
          
          {ESLVal args = $289;
          
          return new ESLVal("javaNew[").add(ppType.apply(t).add(new ESLVal("](\' + className + ").add(ppExps.apply(indent,args,new ESLVal(",")).add(new ESLVal(")")))));
        }
        }
        }
        }
        }
      case "Grab": {ESLVal $288 = _v51.termRef(0);
          ESLVal $287 = _v51.termRef(1);
          ESLVal $286 = _v51.termRef(2);
          
          {ESLVal l = $288;
          
          {ESLVal rs = $287;
          
          {ESLVal e = $286;
          
          return new ESLVal("*********grab");
        }
        }
        }
        }
      case "Probably": {ESLVal $285 = _v51.termRef(0);
          ESLVal $284 = _v51.termRef(1);
          ESLVal $283 = _v51.termRef(2);
          ESLVal $282 = _v51.termRef(3);
          ESLVal $281 = _v51.termRef(4);
          
          {ESLVal l = $285;
          
          {ESLVal p = $284;
          
          {ESLVal t = $283;
          
          {ESLVal e1 = $282;
          
          {ESLVal e2 = $281;
          
          return new ESLVal("**** probably");
        }
        }
        }
        }
        }
        }
      case "Not": {ESLVal $280 = _v51.termRef(0);
          ESLVal $279 = _v51.termRef(1);
          
          {ESLVal l = $280;
          
          {ESLVal e = $279;
          
          return new ESLVal("not(").add(ppExp.apply(indent,e).add(new ESLVal(")")));
        }
        }
        }
      case "Fold": {ESLVal $278 = _v51.termRef(0);
          ESLVal $277 = _v51.termRef(1);
          ESLVal $276 = _v51.termRef(2);
          
          {ESLVal l = $278;
          
          {ESLVal t = $277;
          
          {ESLVal e = $276;
          
          return new ESLVal("******** fold");
        }
        }
        }
        }
      case "Unfold": {ESLVal $275 = _v51.termRef(0);
          ESLVal $274 = _v51.termRef(1);
          ESLVal $273 = _v51.termRef(2);
          
          {ESLVal l = $275;
          
          {ESLVal t = $274;
          
          {ESLVal e = $273;
          
          return new ESLVal("******unfold");
        }
        }
        }
        }
      case "Now": {ESLVal $272 = _v51.termRef(0);
          
          {ESLVal l = $272;
          
          return new ESLVal("now");
        }
        }
      case "Become": {ESLVal $271 = _v51.termRef(0);
          ESLVal $270 = _v51.termRef(1);
          
          {ESLVal l = $271;
          
          {ESLVal e = $270;
          
          return new ESLVal("become ").add(ppExp.apply(indent,e));
        }
        }
        }
      case "ArrayRef": {ESLVal $269 = _v51.termRef(0);
          ESLVal $268 = _v51.termRef(1);
          ESLVal $267 = _v51.termRef(2);
          
          {ESLVal l = $269;
          
          {ESLVal a = $268;
          
          {ESLVal i = $267;
          
          return ppExp.apply(indent,a).add(new ESLVal("[").add(ppExp.apply(indent,i).add(new ESLVal("]"))));
        }
        }
        }
        }
      case "ArrayUpdate": {ESLVal $266 = _v51.termRef(0);
          ESLVal $265 = _v51.termRef(1);
          ESLVal $264 = _v51.termRef(2);
          ESLVal $263 = _v51.termRef(3);
          
          {ESLVal l = $266;
          
          {ESLVal a = $265;
          
          {ESLVal i = $264;
          
          {ESLVal v = $263;
          
          return ppExp.apply(indent,a).add(new ESLVal("[").add(ppExp.apply(indent,i).add(new ESLVal("] := ").add(ppExp.apply(indent,v)))));
        }
        }
        }
        }
        }
        default: {ESLVal x = _v51;
          
          return error(new ESLVal("ppExp: ").add(x));
        }
      }
      }
    }
  });
  private static ESLVal ppQual = new ESLVal(new Function(new ESLVal("ppQual"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal q = $args[1];
  return new ESLVal("qualifier: ").add(q);
    }
  });
  private static ESLVal ppDecs = new ESLVal(new Function(new ESLVal("ppDecs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal bs = $args[1];
  return ppJoin.apply(indent,map.apply(new ESLVal(new Function(new ESLVal("fun628"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal b = $args[0];
        return ppDec.apply(indent,b);
          }
        }),bs));
    }
  });
  private static ESLVal ppDec = new ESLVal(new Function(new ESLVal("ppDec"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal d = $args[1];
  {ESLVal _v50 = d;
        
        switch(_v50.termName) {
        case "Dec": {ESLVal $262 = _v50.termRef(0);
          ESLVal $261 = _v50.termRef(1);
          ESLVal $260 = _v50.termRef(2);
          ESLVal $259 = _v50.termRef(3);
          
          {ESLVal l = $262;
          
          {ESLVal n = $261;
          
          {ESLVal dt = $260;
          
          {ESLVal t = $259;
          
          return n.add(new ESLVal("::").add(ppType.apply(t)));
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(9558,9635)").add(ESLVal.list(_v50)));
      }
      }
    }
  });
  private static ESLVal ppBinds = new ESLVal(new Function(new ESLVal("ppBinds"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal bs = $args[1];
  return ppJoin.apply(indent,map.apply(new ESLVal(new Function(new ESLVal("fun629"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal b = $args[0];
        return ppBind.apply(indent,b);
          }
        }),bs));
    }
  });
  private static ESLVal ppBind = new ESLVal(new Function(new ESLVal("ppBind"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal b = $args[1];
  {ESLVal _v49 = b;
        
        switch(_v49.termName) {
        case "Binding": {ESLVal $258 = _v49.termRef(0);
          ESLVal $257 = _v49.termRef(1);
          ESLVal $256 = _v49.termRef(2);
          ESLVal $255 = _v49.termRef(3);
          ESLVal $254 = _v49.termRef(4);
          
          {ESLVal l = $258;
          
          {ESLVal name = $257;
          
          {ESLVal t = $256;
          
          {ESLVal st = $255;
          
          {ESLVal value = $254;
          
          return name.add(new ESLVal("=").add(ppExp.apply(indent,value).add(new ESLVal(";"))));
        }
        }
        }
        }
        }
        }
      case "TypeBind": {ESLVal $253 = _v49.termRef(0);
          ESLVal $252 = _v49.termRef(1);
          ESLVal $251 = _v49.termRef(2);
          ESLVal $250 = _v49.termRef(3);
          
          {ESLVal l = $253;
          
          {ESLVal name = $252;
          
          {ESLVal t = $251;
          
          {ESLVal ignore = $250;
          
          return new ESLVal("type ").add(name);
        }
        }
        }
        }
        }
      case "DataBind": {ESLVal $249 = _v49.termRef(0);
          ESLVal $248 = _v49.termRef(1);
          ESLVal $247 = _v49.termRef(2);
          ESLVal $246 = _v49.termRef(3);
          
          {ESLVal l = $249;
          
          {ESLVal name = $248;
          
          {ESLVal t = $247;
          
          {ESLVal ignore = $246;
          
          return new ESLVal("data ").add(name);
        }
        }
        }
        }
        }
      case "FunBind": {ESLVal $245 = _v49.termRef(0);
          ESLVal $244 = _v49.termRef(1);
          ESLVal $243 = _v49.termRef(2);
          ESLVal $242 = _v49.termRef(3);
          ESLVal $241 = _v49.termRef(4);
          ESLVal $240 = _v49.termRef(5);
          ESLVal $239 = _v49.termRef(6);
          
          {ESLVal l = $245;
          
          {ESLVal name = $244;
          
          {ESLVal args = $243;
          
          {ESLVal t = $242;
          
          {ESLVal st = $241;
          
          {ESLVal body = $240;
          
          {ESLVal guard = $239;
          
          return name.add(new ESLVal("(").add(ppPatterns.apply(args).add(new ESLVal(") = ").add(nl.apply(indent.add(new ESLVal(2))).add(ppExp.apply(indent.add(new ESLVal(2)),body))))));
        }
        }
        }
        }
        }
        }
        }
        }
      case "CnstrBind": {ESLVal $238 = _v49.termRef(0);
          ESLVal $237 = _v49.termRef(1);
          ESLVal $236 = _v49.termRef(2);
          ESLVal $235 = _v49.termRef(3);
          
          {ESLVal l = $238;
          
          {ESLVal name = $237;
          
          {ESLVal t = $236;
          
          {ESLVal ignore = $235;
          
          return name;
        }
        }
        }
        }
        }
        default: {ESLVal x = _v49;
          
          return error(new ESLVal("ppBind: ").add(x));
        }
      }
      }
    }
  });
  public static ESLVal ppArm = new ESLVal(new Function(new ESLVal("ppArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal a = $args[1];
  {ESLVal _v48 = a;
        
        switch(_v48.termName) {
        case "BArm": {ESLVal $234 = _v48.termRef(0);
          ESLVal $233 = _v48.termRef(1);
          ESLVal $232 = _v48.termRef(2);
          ESLVal $231 = _v48.termRef(3);
          
          {ESLVal l = $234;
          
          {ESLVal ps = $233;
          
          {ESLVal guard = $232;
          
          {ESLVal e = $231;
          
          return ppPatterns.apply(ps).add(new ESLVal(" -> ").add(nl.apply(indent.add(new ESLVal(2))).add(ppExp.apply(indent.add(new ESLVal(2)),e))));
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(10420,10558)").add(ESLVal.list(_v48)));
      }
      }
    }
  });
  public static ESLVal ppArms = new ESLVal(new Function(new ESLVal("ppArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal arms = $args[1];
  return ppJoin.apply(indent,map.apply(new ESLVal(new Function(new ESLVal("fun630"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return ppArm.apply(indent,a);
          }
        }),arms));
    }
  });
  private static ESLVal ppCaseTermArm = new ESLVal(new Function(new ESLVal("ppCaseTermArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal a = $args[1];
  {ESLVal _v47 = a;
        
        switch(_v47.termName) {
        case "TArm": {ESLVal $230 = _v47.termRef(0);
          ESLVal $229 = _v47.termRef(1);
          
          {ESLVal n = $230;
          
          {ESLVal e = $229;
          
          return n.add(new ESLVal(" -> ").add(nl.apply(indent.add(new ESLVal(2))).add(ppExp.apply(indent.add(new ESLVal(2)),e))));
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(10720,10820)").add(ESLVal.list(_v47)));
      }
      }
    }
  });
  private static ESLVal ppCaseIntsArm = new ESLVal(new Function(new ESLVal("ppCaseIntsArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal a = $args[1];
  {ESLVal _v46 = a;
        
        switch(_v46.termName) {
        case "IArm": {ESLVal $228 = _v46.termRef(0);
          ESLVal $227 = _v46.termRef(1);
          
          {ESLVal n = $228;
          
          {ESLVal e = $227;
          
          return n.add(new ESLVal(" -> ").add(nl.apply(indent.add(new ESLVal(2))).add(ppExp.apply(indent.add(new ESLVal(2)),e))));
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(10876,10976)").add(ESLVal.list(_v46)));
      }
      }
    }
  });
  private static ESLVal ppCaseStrsArm = new ESLVal(new Function(new ESLVal("ppCaseStrsArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal a = $args[1];
  {ESLVal _v45 = a;
        
        switch(_v45.termName) {
        case "SArm": {ESLVal $226 = _v45.termRef(0);
          ESLVal $225 = _v45.termRef(1);
          
          {ESLVal n = $226;
          
          {ESLVal e = $225;
          
          return new ESLVal("\'").add(n.add(new ESLVal("\'").add(new ESLVal(" -> ").add(nl.apply(indent.add(new ESLVal(2))).add(ppExp.apply(indent.add(new ESLVal(2)),e))))));
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(11032,11146)").add(ESLVal.list(_v45)));
      }
      }
    }
  });
  private static ESLVal ppCaseBoolsArm = new ESLVal(new Function(new ESLVal("ppCaseBoolsArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal a = $args[1];
  {ESLVal _v44 = a;
        
        switch(_v44.termName) {
        case "BoolArm": {ESLVal $224 = _v44.termRef(0);
          ESLVal $223 = _v44.termRef(1);
          
          {ESLVal b = $224;
          
          {ESLVal e = $223;
          
          return b.add(new ESLVal(" -> ").add(nl.apply(indent.add(new ESLVal(2))).add(ppExp.apply(indent.add(new ESLVal(2)),e))));
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(11204,11308)").add(ESLVal.list(_v44)));
      }
      }
    }
  });
  private static ESLVal getImport = new ESLVal(new Function(new ESLVal("getImport"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal sourceFile = $args[0];
  {ESLVal path = toPath.apply(sourceFile);
        
        {ESLVal p = pathToJavaPackage.apply(path);
        ESLVal className = pathToJavaClassName.apply(path);
        
        {ESLVal _v43 = sourceFile;
        
        switch(_v43.strVal) {
        case "esl/lists.esl": return new ESLVal("// import static ").add(p.add(new ESLVal(".").add(className.add(new ESLVal(".*;")))));
        default: {ESLVal x = _v43;
          
          return new ESLVal("import static ").add(p.add(new ESLVal(".").add(className.add(new ESLVal(".*;")))));
        }
      }
      }
      }
      }
    }
  });
  public static ESLVal ppJModule = new ESLVal(new Function(new ESLVal("ppJModule"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal name = $args[0];
  ESLVal p = $args[1];
  ESLVal m = $args[2];
  {ESLVal _v41 = m;
        
        switch(_v41.termName) {
        case "JModule": {ESLVal $222 = _v41.termRef(0);
          ESLVal $221 = _v41.termRef(1);
          ESLVal $220 = _v41.termRef(2);
          ESLVal $219 = _v41.termRef(3);
          
          {ESLVal n = $222;
          
          {ESLVal exports = $221;
          
          {ESLVal imports = $220;
          
          {ESLVal fields = $219;
          
          return new ESLVal("package ").add(p.add(new ESLVal(";").add(nl.apply($zero).add(new ESLVal("import esl.lib.*;").add(nl.apply($zero).add(new ESLVal("import static esl.lib.Lib.*;").add(nl.apply($zero).add(ppJoin.apply($zero,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v42 = $qualArg;
                
                {ESLVal i = _v42;
                
                return ESLVal.list(ESLVal.list(getImport.apply(i)));
              }
              }
            }
          }).map(imports).flatten().flatten()).add(nl.apply($zero).add(new ESLVal("import java.util.function.Supplier;").add(nl.apply($zero).add(new ESLVal("public class ").add(name.add(new ESLVal(" {").add(nl.apply(new ESLVal(2)).add(new ESLVal("public static ESLVal getSelf() { return $null; }").add(nl.apply(new ESLVal(2)).add(ppJoin.apply(new ESLVal(2),map.apply(new ESLVal(new Function(new ESLVal("fun631"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal f = $args[0];
          return ppJModuleField.apply(new ESLVal(2),exports,f);
            }
          }),fields)).add(nl.apply($zero).add(new ESLVal("public static void main(String[] args) {").add(nl.apply(new ESLVal(2)).add(((Supplier<ESLVal>)() -> { 
            if(member.apply(new ESLVal("main"),exports).boolVal)
              return new ESLVal("  newActor(main,new ESLVal(new Actor())); ").add(nl.apply(new ESLVal(2)));
              else
                return new ESLVal("");
          }).get().add(new ESLVal("}").add(nl.apply($zero).add(new ESLVal("}"))))))))))))))))))))))))));
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(11703,12465)").add(ESLVal.list(_v41)));
      }
      }
    }
  });
  private static ESLVal ppJModuleField = new ESLVal(new Function(new ESLVal("ppJModuleField"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal exports = $args[1];
  ESLVal f = $args[2];
  {ESLVal _v40 = f;
        
        switch(_v40.termName) {
        case "JField": {ESLVal $218 = _v40.termRef(0);
          ESLVal $217 = _v40.termRef(1);
          ESLVal $216 = _v40.termRef(2);
          
          switch($218.strVal) {
          case "edb": switch($216.termName) {
            case "JNull": {
              {ESLVal t = $217;
              
              return new ESLVal("// static ESLVal edb = null;");
            }
            }
            default: {ESLVal n = $218;
              
              {ESLVal t = $217;
              
              {ESLVal e = $216;
              
              return ((Supplier<ESLVal>)() -> { 
                if(member.apply(n,exports).boolVal)
                  return new ESLVal("public ");
                  else
                    return new ESLVal("private ");
              }).get().add(new ESLVal("static ESLVal ").add(n.add(new ESLVal(" = ").add(ppJExp.apply(indent,ESLVal.list(),e).add(new ESLVal(";"))))));
            }
            }
            }
          }
          default: {ESLVal n = $218;
            
            {ESLVal t = $217;
            
            {ESLVal e = $216;
            
            return ((Supplier<ESLVal>)() -> { 
              if(member.apply(n,exports).boolVal)
                return new ESLVal("public ");
                else
                  return new ESLVal("private ");
            }).get().add(new ESLVal("static ESLVal ").add(n.add(new ESLVal(" = ").add(ppJExp.apply(indent,ESLVal.list(),e).add(new ESLVal(";"))))));
          }
          }
          }
        }
        }
        default: return error(new ESLVal("case error at Pos(12534,12784)").add(ESLVal.list(_v40)));
      }
      }
    }
  });
  private static ESLVal ppJExps = new ESLVal(new Function(new ESLVal("ppJExps"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal exps = $args[2];
  ESLVal sep = $args[3];
  {ESLVal _v39 = exps;
        
        if(_v39.isCons())
        {ESLVal $212 = _v39.head();
          ESLVal $213 = _v39.tail();
          
          if($213.isCons())
          {ESLVal $214 = $213.head();
            ESLVal $215 = $213.tail();
            
            {ESLVal e1 = $212;
            
            {ESLVal e2 = $214;
            
            {ESLVal es = $215;
            
            return ppJExp.apply(indent,dynamics,e1).add(sep.add(ppJExps.apply(indent,dynamics,es.cons(e2),sep)));
          }
          }
          }
          }
        else if($213.isNil())
          {ESLVal e = $212;
            
            return ppJExp.apply(indent,dynamics,e);
          }
        else return error(new ESLVal("case error at Pos(12854,13048)").add(ESLVal.list(_v39)));
        }
      else if(_v39.isNil())
        return new ESLVal("");
      else return error(new ESLVal("case error at Pos(12854,13048)").add(ESLVal.list(_v39)));
      }
    }
  });
  private static ESLVal ppJDecs = new ESLVal(new Function(new ESLVal("ppJDecs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal decs = $args[1];
  ESLVal sep = $args[2];
  {ESLVal _v38 = decs;
        
        if(_v38.isCons())
        {ESLVal $208 = _v38.head();
          ESLVal $209 = _v38.tail();
          
          if($209.isCons())
          {ESLVal $210 = $209.head();
            ESLVal $211 = $209.tail();
            
            {ESLVal e1 = $208;
            
            {ESLVal e2 = $210;
            
            {ESLVal es = $211;
            
            return pJDec.apply(indent,e1).add(sep.add(ppJDecs.apply(indent,es.cons(e2),sep)));
          }
          }
          }
          }
        else if($209.isNil())
          {ESLVal e = $208;
            
            return pJDec.apply(indent,e);
          }
        else return error(new ESLVal("case error at Pos(13110,13322)").add(ESLVal.list(_v38)));
        }
      else if(_v38.isNil())
        return new ESLVal("");
      else return error(new ESLVal("case error at Pos(13110,13322)").add(ESLVal.list(_v38)));
      }
    }
  });
  private static ESLVal pJDec = new ESLVal(new Function(new ESLVal("pJDec"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal d = $args[1];
  {ESLVal _v37 = d;
        
        switch(_v37.termName) {
        case "JDec": {ESLVal $207 = _v37.termRef(0);
          ESLVal $206 = _v37.termRef(1);
          
          {ESLVal n = $207;
          
          {ESLVal t = $206;
          
          return new ESLVal("ESLVal ").add(n);
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(13368,13424)").add(ESLVal.list(_v37)));
      }
      }
    }
  });
  private static ESLVal ppJExp = new ESLVal(new Function(new ESLVal("ppJExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal e = $args[2];
  {ESLVal _v32 = e;
        
        switch(_v32.termName) {
        case "JArrayRef": {ESLVal $199 = _v32.termRef(0);
          ESLVal $198 = _v32.termRef(1);
          
          {ESLVal a = $199;
          
          {ESLVal i = $198;
          
          return ppJExp.apply(indent,dynamics,a).add(new ESLVal(".array[").add(ppJExp.apply(indent,dynamics,i).add(new ESLVal(".intVal]"))));
        }
        }
        }
      case "JArrayUpdate": {ESLVal $197 = _v32.termRef(0);
          ESLVal $196 = _v32.termRef(1);
          ESLVal $195 = _v32.termRef(2);
          
          {ESLVal a = $197;
          
          {ESLVal i = $196;
          
          {ESLVal v = $195;
          
          return ppJExp.apply(indent,dynamics,a).add(new ESLVal(".array[").add(ppJExp.apply(indent,dynamics,i).add(new ESLVal(".intVal] = ").add(ppJExp.apply(indent,dynamics,v)))));
        }
        }
        }
        }
      case "JBecome": {ESLVal $192 = _v32.termRef(0);
          ESLVal $191 = _v32.termRef(1);
          
          if($191.isCons())
          {ESLVal $193 = $191.head();
            ESLVal $194 = $191.tail();
            
            {ESLVal _v122 = $192;
            
            {ESLVal es = $191;
            
            return new ESLVal("become(").add(ppJExp.apply(indent.add(new ESLVal(2)),dynamics,_v122).add(new ESLVal(",getSelf(),").add(ppJExps.apply(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")")))));
          }
          }
          }
        else if($191.isNil())
          {ESLVal _v123 = $192;
            
            return new ESLVal("become(").add(ppJExp.apply(indent.add(new ESLVal(2)),dynamics,_v123).add(new ESLVal(",getSelf())")));
          }
        else {ESLVal _v124 = $192;
            
            {ESLVal es = $191;
            
            return new ESLVal("become(").add(ppJExp.apply(indent.add(new ESLVal(2)),dynamics,_v124).add(new ESLVal(",getSelf(),").add(ppJExps.apply(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")")))));
          }
          }
        }
      case "JConstExp": {ESLVal $186 = _v32.termRef(0);
          
          switch($186.termName) {
          case "JConstInt": {ESLVal $190 = $186.termRef(0);
            
            switch($190.intVal) {
            case 0: return new ESLVal("$zero");
          case 1: return new ESLVal("$one");
            default: {ESLVal n = $190;
              
              return new ESLVal("new ESLVal(").add(n.add(new ESLVal(")")));
            }
          }
          }
        case "JConstBool": {ESLVal $189 = $186.termRef(0);
            
            switch($189.boolVal ? 1 : 0) {
            case 1: return new ESLVal("$true");
          case 0: return new ESLVal("$false");
            default: {ESLVal _v120 = _v32;
              
              return new ESLVal("********** unknown expression: ").add(_v120);
            }
          }
          }
        case "JConstStr": {ESLVal $188 = $186.termRef(0);
            
            {ESLVal s = $188;
            
            return new ESLVal("new ESLVal(\"").add(javaString.apply(s).add(new ESLVal("\")")));
          }
          }
        case "JConstDouble": {ESLVal $187 = $186.termRef(0);
            
            {ESLVal d = $187;
            
            return new ESLVal("new ESLVal(").add(d.add(new ESLVal(")")));
          }
          }
          default: {ESLVal _v121 = _v32;
            
            return new ESLVal("********** unknown expression: ").add(_v121);
          }
        }
        }
      case "JNot": {ESLVal $185 = _v32.termRef(0);
          
          {ESLVal _v119 = $185;
          
          return ppJExp.apply(indent,dynamics,_v119).add(new ESLVal(".not()"));
        }
        }
      case "JNil": {ESLVal $184 = _v32.termRef(0);
          
          {ESLVal t = $184;
          
          return new ESLVal("$nil");
        }
        }
      case "JList": {ESLVal $183 = _v32.termRef(0);
          ESLVal $182 = _v32.termRef(1);
          
          {ESLVal t = $183;
          
          {ESLVal es = $182;
          
          return ppJListExp.apply(indent,dynamics,t,es);
        }
        }
        }
      case "JSet": {ESLVal $181 = _v32.termRef(0);
          ESLVal $180 = _v32.termRef(1);
          
          {ESLVal t = $181;
          
          {ESLVal es = $180;
          
          return ppJSetExp.apply(indent,dynamics,t,es);
        }
        }
        }
      case "JBag": {ESLVal $179 = _v32.termRef(0);
          ESLVal $178 = _v32.termRef(1);
          
          {ESLVal t = $179;
          
          {ESLVal es = $178;
          
          return ppJBagExp.apply(indent,dynamics,t,es);
        }
        }
        }
      case "JTerm": {ESLVal $175 = _v32.termRef(0);
          ESLVal $174 = _v32.termRef(1);
          
          if($174.isCons())
          {ESLVal $176 = $174.head();
            ESLVal $177 = $174.tail();
            
            {ESLVal n = $175;
            
            {ESLVal es = $174;
            
            return new ESLVal("new ESLVal(\"").add(n.add(new ESLVal("\",").add(ppJExps.apply(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")")))));
          }
          }
          }
        else if($174.isNil())
          {ESLVal n = $175;
            
            return new ESLVal("new ESLVal(\"").add(n.add(new ESLVal("\",new ESLVal[]{})")));
          }
        else {ESLVal n = $175;
            
            {ESLVal es = $174;
            
            return new ESLVal("new ESLVal(\"").add(n.add(new ESLVal("\",").add(ppJExps.apply(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")")))));
          }
          }
        }
      case "JFun": {ESLVal $173 = _v32.termRef(0);
          ESLVal $172 = _v32.termRef(1);
          ESLVal $171 = _v32.termRef(2);
          ESLVal $170 = _v32.termRef(3);
          
          {ESLVal n = $173;
          
          {ESLVal args = $172;
          
          {ESLVal t = $171;
          
          {ESLVal body = $170;
          
          return ppJFun.apply(indent,dynamics,n,args,t,body);
        }
        }
        }
        }
        }
      case "JBinExp": {ESLVal $169 = _v32.termRef(0);
          ESLVal $168 = _v32.termRef(1);
          ESLVal $167 = _v32.termRef(2);
          
          switch($168.strVal) {
          case "at": {ESLVal e1 = $169;
            
            {ESLVal e2 = $167;
            
            return new ESLVal("at(() -> { return ").add(ppJExp.apply(indent,dynamics,e1).add(new ESLVal("; },() -> { return ").add(ppJExp.apply(indent,dynamics,e2).add(new ESLVal("; })")))));
          }
          }
        case "==": {ESLVal e1 = $169;
            
            {ESLVal e2 = $167;
            
            return ppJExp.apply(indent,dynamics,e1).add(new ESLVal(".equals(").add(ppJExp.apply(indent,dynamics,e2).add(new ESLVal(")"))));
          }
          }
        case "cons": {ESLVal e1 = $169;
            
            {ESLVal e2 = $167;
            
            return ppJExp.apply(indent,dynamics,e2).add(new ESLVal(".cons(").add(ppJExp.apply(indent,dynamics,e1).add(new ESLVal(")"))));
          }
          }
          default: {ESLVal e1 = $169;
            
            {ESLVal op = $168;
            
            {ESLVal e2 = $167;
            
            return ppJExp.apply(indent,dynamics,e1).add(new ESLVal(".").add(op.add(new ESLVal("(").add(ppJExp.apply(indent,dynamics,e2).add(new ESLVal(")"))))));
          }
          }
          }
        }
        }
      case "JCmpExp": {ESLVal $166 = _v32.termRef(0);
          
          {ESLVal c = $166;
          
          return ppJCmp.apply(indent,dynamics,c);
        }
        }
      case "JNull": {
          return new ESLVal("$null");
        }
      case "JNow": {
          return new ESLVal("now()");
        }
      case "JVar": {ESLVal $165 = _v32.termRef(0);
          ESLVal $164 = _v32.termRef(1);
          
          {ESLVal n = $165;
          
          {ESLVal t = $164;
          
          if(member.apply(n,dynamics).boolVal)
          return n.add(new ESLVal("[0]"));
          else
            {ESLVal _v117 = $165;
              
              {ESLVal _v118 = $164;
              
              return _v117;
            }
            }
        }
        }
        }
      case "JError": {ESLVal $163 = _v32.termRef(0);
          
          {ESLVal _v116 = $163;
          
          return new ESLVal("error(").add(ppJExp.apply(indent,dynamics,_v116).add(new ESLVal(")")));
        }
        }
      case "JApply": {ESLVal $162 = _v32.termRef(0);
          ESLVal $161 = _v32.termRef(1);
          
          {ESLVal _v115 = $162;
          
          {ESLVal es = $161;
          
          return ppJExp.apply(indent,dynamics,_v115).add(new ESLVal(".apply(").add(ppJExps.apply(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")"))));
        }
        }
        }
      case "JCommandExp": {ESLVal $160 = _v32.termRef(0);
          ESLVal $159 = _v32.termRef(1);
          
          {ESLVal c = $160;
          
          {ESLVal t = $159;
          
          return new ESLVal("((Supplier<ESLVal>)() -> { ").add(nl.apply(indent.add(new ESLVal(2))).add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,c).add(nl.apply(indent).add(new ESLVal("}).get()")))));
        }
        }
        }
      case "JIfExp": {ESLVal $158 = _v32.termRef(0);
          ESLVal $157 = _v32.termRef(1);
          ESLVal $156 = _v32.termRef(2);
          
          {ESLVal _v114 = $158;
          
          {ESLVal e1 = $157;
          
          {ESLVal e2 = $156;
          
          return new ESLVal("(").add(ppJExp.apply(indent,dynamics,_v114).add(new ESLVal(".boolVal) ? (").add(ppJExp.apply(indent,dynamics,e1).add(new ESLVal(") : (").add(ppJExp.apply(indent,dynamics,e2).add(new ESLVal(")")))))));
        }
        }
        }
        }
      case "JHead": {ESLVal $155 = _v32.termRef(0);
          
          {ESLVal _v113 = $155;
          
          return ppJExp.apply(indent,dynamics,_v113).add(new ESLVal(".head()"));
        }
        }
      case "JTail": {ESLVal $154 = _v32.termRef(0);
          
          {ESLVal _v112 = $154;
          
          return ppJExp.apply(indent,dynamics,_v112).add(new ESLVal(".tail()"));
        }
        }
      case "JTermRef": {ESLVal $153 = _v32.termRef(0);
          ESLVal $152 = _v32.termRef(1);
          
          {ESLVal _v111 = $153;
          
          {ESLVal n = $152;
          
          return ppJExp.apply(indent,dynamics,_v111).add(new ESLVal(".termRef(").add(n.add(new ESLVal(")"))));
        }
        }
        }
      case "JMapFun": {ESLVal $151 = _v32.termRef(0);
          ESLVal $150 = _v32.termRef(1);
          
          {ESLVal f = $151;
          
          {ESLVal l = $150;
          
          return ppJExp.apply(indent,dynamics,f).add(new ESLVal(".map(").add(ppJExp.apply(indent,dynamics,l).add(new ESLVal(")"))));
        }
        }
        }
      case "JFlatten": {ESLVal $149 = _v32.termRef(0);
          
          {ESLVal ls = $149;
          
          return ppJExp.apply(indent,dynamics,ls).add(new ESLVal(".flatten()"));
        }
        }
      case "JBehaviour": {ESLVal $144 = _v32.termRef(0);
          ESLVal $143 = _v32.termRef(1);
          ESLVal $142 = _v32.termRef(2);
          ESLVal $141 = _v32.termRef(3);
          ESLVal $140 = _v32.termRef(4);
          
          switch($141.termName) {
          case "JFun": {ESLVal $148 = $141.termRef(0);
            ESLVal $147 = $141.termRef(1);
            ESLVal $146 = $141.termRef(2);
            ESLVal $145 = $141.termRef(3);
            
            {ESLVal es = $144;
            
            {ESLVal fs = $143;
            
            {ESLVal init = $142;
            
            {ESLVal n = $148;
            
            {ESLVal args = $147;
            
            {ESLVal t = $146;
            
            {ESLVal body = $145;
            
            {ESLVal time = $140;
            
            return new ESLVal("new ESLVal(new BehaviourAdapter(").add(((Supplier<ESLVal>)() -> { 
              if(time.eql(new ESLVal("JBlock",ESLVal.list())).boolVal)
                return new ESLVal("false");
                else
                  return new ESLVal("true");
            }).get().add(new ESLVal(",getSelf(),").add(ppJExp.apply(indent,dynamics,n).add(new ESLVal(") {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJFields.apply(indent.add(new ESLVal(2)),dynamics,fs).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal handle(ESLVal $m) {").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,body).add(new ESLVal("}").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal get(String name) {").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("switch(name) {").add(nl.apply(indent.add(new ESLVal(6))).add(ppJoin.apply(indent.add(new ESLVal(6)),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v36 = $qualArg;
                  
                  {ESLVal _v109 = _v36;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("case \"").add(_v109.add(new ESLVal("\": return ").add(_v109.add(new ESLVal(";")))))));
                }
                }
              }
            }).map(es).flatten().flatten()).add(nl.apply(indent.add(new ESLVal(6))).add(new ESLVal("default: throw new Error(\"ref illegal \" + self + \".\" + name);").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("}").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("}").add(nl.apply(indent).add(new ESLVal("public void handleTime(ESLVal $t) {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,time).add(nl.apply(indent).add(new ESLVal("}").add(nl.apply(indent).add(new ESLVal("public ESLVal init() {").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("return ").add(ppJExp.apply(indent.add(new ESLVal(6)),dynamics,init).add(new ESLVal(";").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("}").add(nl.apply(indent).add(new ESLVal("})")))))))))))))))))))))))))))))))))))))));
          }
          }
          }
          }
          }
          }
          }
          }
          }
          default: {ESLVal _v110 = _v32;
            
            return new ESLVal("********** unknown expression: ").add(_v110);
          }
        }
        }
      case "JExtendedBehaviour": {ESLVal $135 = _v32.termRef(0);
          ESLVal $134 = _v32.termRef(1);
          ESLVal $133 = _v32.termRef(2);
          ESLVal $132 = _v32.termRef(3);
          ESLVal $131 = _v32.termRef(4);
          ESLVal $130 = _v32.termRef(5);
          
          switch($131.termName) {
          case "JFun": {ESLVal $139 = $131.termRef(0);
            ESLVal $138 = $131.termRef(1);
            ESLVal $137 = $131.termRef(2);
            ESLVal $136 = $131.termRef(3);
            
            {ESLVal es = $135;
            
            {ESLVal parent = $134;
            
            {ESLVal fs = $133;
            
            {ESLVal init = $132;
            
            {ESLVal n = $139;
            
            {ESLVal args = $138;
            
            {ESLVal t = $137;
            
            {ESLVal body = $136;
            
            {ESLVal time = $130;
            
            return new ESLVal("new ESLVal(new BehaviourAdapter(").add(ppBehaviourParent.apply(indent,dynamics,parent).add(new ESLVal(",").add(((Supplier<ESLVal>)() -> { 
              if(time.eql(new ESLVal("JBlock",ESLVal.list())).boolVal)
                return new ESLVal("false");
                else
                  return new ESLVal("true");
            }).get().add(new ESLVal(",getSelf(),").add(ppJExp.apply(indent,dynamics,n).add(new ESLVal(") {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJFields.apply(indent.add(new ESLVal(2)),dynamics,fs).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal handle(ESLVal $m) {").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,body).add(new ESLVal("}").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal get(String name) {").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("switch(name) {").add(nl.apply(indent.add(new ESLVal(6))).add(ppJoin.apply(indent.add(new ESLVal(6)),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v35 = $qualArg;
                  
                  {ESLVal _v107 = _v35;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("case \"").add(_v107.add(new ESLVal("\": return ").add(_v107.add(new ESLVal(";")))))));
                }
                }
              }
            }).map(es).flatten().flatten()).add(nl.apply(indent.add(new ESLVal(6))).add(new ESLVal("default: return refSuper(name);").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("}").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("}").add(nl.apply(indent).add(new ESLVal("public void handleTime(ESLVal $t) {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,time).add(nl.apply(indent).add(new ESLVal("}").add(nl.apply(indent).add(new ESLVal("public ESLVal init() {").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("return ").add(ppJExp.apply(indent.add(new ESLVal(6)),dynamics,init).add(new ESLVal(";").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("}").add(nl.apply(indent).add(new ESLVal("})")))))))))))))))))))))))))))))))))))))))));
          }
          }
          }
          }
          }
          }
          }
          }
          }
          }
          default: {ESLVal _v108 = _v32;
            
            return new ESLVal("********** unknown expression: ").add(_v108);
          }
        }
        }
      case "JNew": {ESLVal $127 = _v32.termRef(0);
          ESLVal $126 = _v32.termRef(1);
          
          if($126.isCons())
          {ESLVal $128 = $126.head();
            ESLVal $129 = $126.tail();
            
            {ESLVal b = $127;
            
            {ESLVal args = $126;
            
            return new ESLVal("newActor(").add(ppJExp.apply(indent,dynamics,b).add(new ESLVal(",new ESLVal(new Actor()),").add(ppJExps.apply(indent,dynamics,args,new ESLVal(",")).add(new ESLVal(")")))));
          }
          }
          }
        else if($126.isNil())
          {ESLVal b = $127;
            
            return new ESLVal("newActor(").add(ppJExp.apply(indent,dynamics,b).add(new ESLVal(",new ESLVal(new Actor()))")));
          }
        else {ESLVal b = $127;
            
            {ESLVal args = $126;
            
            return new ESLVal("newActor(").add(ppJExp.apply(indent,dynamics,b).add(new ESLVal(",new ESLVal(new Actor()),").add(ppJExps.apply(indent,dynamics,args,new ESLVal(",")).add(new ESLVal(")")))));
          }
          }
        }
      case "JNewArray": {ESLVal $125 = _v32.termRef(0);
          
          {ESLVal i = $125;
          
          return new ESLVal("newArray(").add(ppJExp.apply(indent,dynamics,i).add(new ESLVal(".intVal)")));
        }
        }
      case "JNewTable": {
          return new ESLVal("newTable()");
        }
      case "JNewJava": {ESLVal $122 = _v32.termRef(0);
          ESLVal $121 = _v32.termRef(1);
          
          if($121.isCons())
          {ESLVal $123 = $121.head();
            ESLVal $124 = $121.tail();
            
            {ESLVal n = $122;
            
            {ESLVal args = $121;
            
            return new ESLVal("newJavaActor(\"").add(n.add(new ESLVal("\",").add(ppJExps.apply(indent,dynamics,args,new ESLVal(",")).add(new ESLVal(")")))));
          }
          }
          }
        else if($121.isNil())
          {ESLVal n = $122;
            
            return new ESLVal("newJavaActor(\"").add(n.add(new ESLVal("\")")));
          }
        else {ESLVal n = $122;
            
            {ESLVal args = $121;
            
            return new ESLVal("newJavaActor(\"").add(n.add(new ESLVal("\",").add(ppJExps.apply(indent,dynamics,args,new ESLVal(",")).add(new ESLVal(")")))));
          }
          }
        }
      case "JRecord": {ESLVal $120 = _v32.termRef(0);
          
          {ESLVal fs = $120;
          
          return new ESLVal("newRecord(new ESLVal[]{").add(ppJExps.apply(indent,dynamics,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v33 = $qualArg;
                
                switch(_v33.termName) {
                case "JField": {ESLVal $202 = _v33.termRef(0);
                  ESLVal $201 = _v33.termRef(1);
                  ESLVal $200 = _v33.termRef(2);
                  
                  {ESLVal n = $202;
                  
                  {ESLVal t = $201;
                  
                  {ESLVal _v105 = $200;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JConstExp",new ESLVal("JConstStr",n))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v33;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten(),new ESLVal(",")).add(new ESLVal("},").add(ppJExps.apply(indent,dynamics,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v34 = $qualArg;
                
                switch(_v34.termName) {
                case "JField": {ESLVal $205 = _v34.termRef(0);
                  ESLVal $204 = _v34.termRef(1);
                  ESLVal $203 = _v34.termRef(2);
                  
                  {ESLVal n = $205;
                  
                  {ESLVal t = $204;
                  
                  {ESLVal _v106 = $203;
                  
                  return ESLVal.list(ESLVal.list(_v106));
                }
                }
                }
                }
                default: {ESLVal _0 = _v34;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten(),new ESLVal(",")).add(new ESLVal(")")))));
        }
        }
      case "JSend": {ESLVal $117 = _v32.termRef(0);
          ESLVal $116 = _v32.termRef(1);
          ESLVal $115 = _v32.termRef(2);
          
          if($115.isCons())
          {ESLVal $118 = $115.head();
            ESLVal $119 = $115.tail();
            
            {ESLVal _v102 = $117;
            
            {ESLVal m = $116;
            
            {ESLVal args = $115;
            
            return new ESLVal("Lib.send(").add(ppJExp.apply(indent,dynamics,_v102).add(new ESLVal(",\"").add(m.add(new ESLVal("\",").add(ppJExps.apply(indent,dynamics,args,new ESLVal(",")).add(new ESLVal(")")))))));
          }
          }
          }
          }
        else if($115.isNil())
          {ESLVal _v103 = $117;
            
            {ESLVal m = $116;
            
            return new ESLVal("Lib.send(").add(ppJExp.apply(indent,dynamics,_v103).add(new ESLVal(",\"").add(m.add(new ESLVal("\")")))));
          }
          }
        else {ESLVal _v104 = $117;
            
            {ESLVal m = $116;
            
            {ESLVal args = $115;
            
            return new ESLVal("Lib.send(").add(ppJExp.apply(indent,dynamics,_v104).add(new ESLVal(",\"").add(m.add(new ESLVal("\",").add(ppJExps.apply(indent,dynamics,args,new ESLVal(",")).add(new ESLVal(")")))))));
          }
          }
          }
        }
      case "JSendSuper": {ESLVal $114 = _v32.termRef(0);
          
          {ESLVal _v101 = $114;
          
          return new ESLVal("sendSuper(").add(ppJExp.apply(indent,dynamics,_v101).add(new ESLVal(")")));
        }
        }
      case "JSendTimeSuper": {
          return new ESLVal("sendTimeSuper($t)");
        }
      case "JSelf": {
          return new ESLVal("getSelf()");
        }
      case "JRef": {ESLVal $113 = _v32.termRef(0);
          ESLVal $112 = _v32.termRef(1);
          
          {ESLVal _v100 = $113;
          
          {ESLVal n = $112;
          
          return ppJExp.apply(indent,dynamics,_v100).add(new ESLVal(".ref(\"").add(n.add(new ESLVal("\")"))));
        }
        }
        }
      case "JRefSuper": {ESLVal $111 = _v32.termRef(0);
          
          {ESLVal n = $111;
          
          return new ESLVal("refSuper(\"").add(n.add(new ESLVal("\")")));
        }
        }
      case "JGrab": {ESLVal $110 = _v32.termRef(0);
          ESLVal $109 = _v32.termRef(1);
          
          {ESLVal es = $110;
          
          {ESLVal c = $109;
          
          return new ESLVal("lock(new Function(new ESLVal(\"grab\"),getSelf()) {").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal apply(ESLVal ...args) { ").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("return ").add(ppJExp.apply(indent,dynamics,c).add(new ESLVal(";").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("}},").add(ppJExps.apply(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")")))))))))));
        }
        }
        }
      case "JTry": {ESLVal $108 = _v32.termRef(0);
          ESLVal $107 = _v32.termRef(1);
          ESLVal $106 = _v32.termRef(2);
          
          {ESLVal _v99 = $108;
          
          {ESLVal n = $107;
          
          {ESLVal c = $106;
          
          return new ESLVal("new Function(new ESLVal(\"try\"),getSelf()) {").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal apply(ESLVal... args) { ").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("try { ").add(nl.apply(indent.add(new ESLVal(6))).add(new ESLVal("return ").add(ppJExp.apply(indent.add(new ESLVal(4)),dynamics,_v99).add(new ESLVal(";").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("} catch(ESLError $exception) {").add(nl.apply(indent.add(new ESLVal(6))).add(new ESLVal("ESLVal ").add(n.add(new ESLVal(" = $exception.value;").add(nl.apply(indent.add(new ESLVal(6))).add(ppJCommand.apply(indent,dynamics,c).add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("}").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("}").add(nl.apply(indent).add(new ESLVal("}.apply()")))))))))))))))))))))));
        }
        }
        }
        }
      case "JProbably": {ESLVal $105 = _v32.termRef(0);
          ESLVal $104 = _v32.termRef(1);
          ESLVal $103 = _v32.termRef(2);
          
          {ESLVal _v98 = $105;
          
          {ESLVal e1 = $104;
          
          {ESLVal e2 = $103;
          
          return new ESLVal("probably(").add(ppJExp.apply(indent,dynamics,_v98).add(new ESLVal(",").add(ppJExp.apply(indent,dynamics,probFun.apply(e1)).add(new ESLVal(",").add(ppJExp.apply(indent,dynamics,probFun.apply(e2)).add(new ESLVal(")")))))));
        }
        }
        }
        }
        default: {ESLVal _v125 = _v32;
          
          return new ESLVal("********** unknown expression: ").add(_v125);
        }
      }
      }
    }
  });
  private static ESLVal ppJCmp = new ESLVal(new Function(new ESLVal("ppJCmp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal c = $args[2];
  LetRec letrec = new LetRec() {
        ESLVal inner = new ESLVal(new Function(new ESLVal("inner"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v93 = $args[0];
          ESLVal _v92 = $args[1];
          ESLVal _v91 = $args[2];
          {ESLVal _v30 = _v91;
                
                switch(_v30.termName) {
                case "JCmpBind": {ESLVal $99 = _v30.termRef(0);
                  ESLVal $98 = _v30.termRef(1);
                  ESLVal $97 = _v30.termRef(2);
                  
                  {ESLVal n = $99;
                  
                  {ESLVal e = $98;
                  
                  {ESLVal _v95 = $97;
                  
                  return new ESLVal("ESLVal $l").add(_v92.add(new ESLVal(" = ").add(ppJExp.apply(_v93,dynamics,e).add(new ESLVal(";").add(nl.apply(_v93).add(new ESLVal("while(!$l").add(_v92.add(new ESLVal(".isNil()) {").add(nl.apply(_v93.add(new ESLVal(2))).add(new ESLVal("ESLVal ").add(n.add(new ESLVal(" = $l").add(_v92.add(new ESLVal(".head();").add(nl.apply(_v93.add(new ESLVal(2))).add(new ESLVal("$l").add(_v92.add(new ESLVal(" = $l").add(_v92.add(new ESLVal(".tail();").add(nl.apply(_v93.add(new ESLVal(2))).add(inner.apply(_v93.add(new ESLVal(2)),_v92.add($one),_v95).add(nl.apply(_v93).add(new ESLVal("}")))))))))))))))))))))))));
                }
                }
                }
                }
              case "JCmpList": {ESLVal $96 = _v30.termRef(0);
                  
                  {ESLVal e = $96;
                  
                  return new ESLVal("$v.add(").add(ppJExp.apply(_v93,dynamics,e).add(new ESLVal(");")));
                }
                }
              case "JCmpIf": {ESLVal $95 = _v30.termRef(0);
                  ESLVal $94 = _v30.termRef(1);
                  
                  {ESLVal e = $95;
                  
                  {ESLVal _v94 = $94;
                  
                  return new ESLVal("if(").add(ppJExp.apply(_v93,dynamics,e).add(new ESLVal(".boolVal) {").add(inner.apply(_v93,_v92,_v94).add(nl.apply(_v93).add(new ESLVal("}"))))));
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(21280,21881)").add(ESLVal.list(_v30)));
              }
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "inner": return inner;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal inner = letrec.get("inner");
      
        {ESLVal _v31 = c;
        
        switch(_v31.termName) {
        case "JCmpOuter": {ESLVal $102 = _v31.termRef(0);
          ESLVal $101 = _v31.termRef(1);
          ESLVal $100 = _v31.termRef(2);
          
          {ESLVal n = $102;
          
          {ESLVal e = $101;
          
          {ESLVal _v96 = $100;
          
          return new ESLVal("new java.util.function.Function<ESLVal,ESLVal>() {").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal apply(ESLVal $l0) {").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("ESLVal $a = $nil;").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("java.util.Vector<ESLVal> $v = new java.util.Vector<ESLVal>();").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("while(!$l0.isNil()) { ").add(nl.apply(indent.add(new ESLVal(6))).add(new ESLVal("ESLVal ").add(n.add(new ESLVal(" = $l0.head();").add(nl.apply(indent.add(new ESLVal(6))).add(new ESLVal("$l0 = $l0.tail();").add(nl.apply(indent.add(new ESLVal(6))).add(inner.apply(indent,$one,_v96).add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("}").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("for(ESLVal $x : $v) $a = new ESLVal($x,$a);").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("return $a;").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("}}.apply(").add(ppJExp.apply(indent,dynamics,e).add(new ESLVal(")")))))))))))))))))))))))))));
        }
        }
        }
        }
        default: {ESLVal _v97 = _v31;
          
          return new ESLVal("// Illegal Comprehension ").add(_v97);
        }
      }
      }
      
    }
  });
  private static ESLVal ppBehaviourParent = new ESLVal(new Function(new ESLVal("ppBehaviourParent"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal e = $args[2];
  {ESLVal _v29 = e;
        
        switch(_v29.termName) {
        case "JApply": {ESLVal $93 = _v29.termRef(0);
          ESLVal $92 = _v29.termRef(1);
          
          {ESLVal op = $93;
          
          {ESLVal args = $92;
          
          return new ESLVal("getParent(getSelf(),").add(ppJExp.apply(indent,dynamics,op).add(new ESLVal(",").add(ppJExps.apply(indent,dynamics,args,new ESLVal(",")).add(new ESLVal(")")))));
        }
        }
        }
        default: {ESLVal _v90 = _v29;
          
          return ppJExp.apply(indent,dynamics,_v90);
        }
      }
      }
    }
  });
  private static ESLVal probFun = new ESLVal(new Function(new ESLVal("probFun"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  return new ESLVal("JFun",new ESLVal("JConstExp",new ESLVal("JConstStr",new ESLVal("probFun"))),ESLVal.list(),$null,new ESLVal("JReturn",e));
    }
  });
  private static ESLVal ppJFun = new ESLVal(new Function(new ESLVal("ppJFun"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal n = $args[2];
  ESLVal args = $args[3];
  ESLVal t = $args[4];
  ESLVal body = $args[5];
  {ESLVal freeDynamics = dynamicVarsJCommand.apply(body);
        ESLVal argNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v25 = $qualArg;
                
                switch(_v25.termName) {
                case "JDec": {ESLVal $89 = _v25.termRef(0);
                  ESLVal $88 = _v25.termRef(1);
                  
                  {ESLVal _v86 = $89;
                  
                  {ESLVal _v87 = $88;
                  
                  return ESLVal.list(ESLVal.list(_v86));
                }
                }
                }
                default: {ESLVal _0 = _v25;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(args).flatten().flatten();
        
        {ESLVal boundDynamics = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v26 = $qualArg;
                
                {ESLVal d = _v26;
                
                return ESLVal.list((member.apply(d,freeDynamics).boolVal) ? (ESLVal.list(d)) : ($nil));
              }
              }
            }
          }).map(argNames).flatten().flatten();
        
        {ESLVal dom = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v27 = $qualArg;
                
                switch(_v27.termName) {
                case "JDec": {ESLVal $91 = _v27.termRef(0);
                  ESLVal $90 = _v27.termRef(1);
                  
                  {ESLVal _v88 = $91;
                  
                  {ESLVal _v89 = $90;
                  
                  return ESLVal.list(ESLVal.list(_v89));
                }
                }
                }
                default: {ESLVal _0 = _v27;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(args).flatten().flatten();
        ESLVal ran = t;
        
        return new ESLVal("new ESLVal(new Function(").add(ppJExp.apply(indent,dynamics,n).add(new ESLVal(",getSelf()) {").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal apply(ESLVal... $args) {").add(nl.apply(indent.add(new ESLVal(4))).add(ppFunArgs.apply(indent,$zero,args,boundDynamics).add(ppJCommand.apply(indent.add(new ESLVal(4)),boundDynamics.add(new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v28 = $qualArg;
              
              {ESLVal d = _v28;
              
              return ESLVal.list((member.apply(d,argNames).not().boolVal) ? (ESLVal.list(d)) : ($nil));
            }
            }
          }
        }).map(dynamics).flatten().flatten()),body).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("}").add(nl.apply(indent).add(new ESLVal("})"))))))))))));
      }
      }
      }
    }
  });
  private static ESLVal ppFunArgs = new ESLVal(new Function(new ESLVal("ppFunArgs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal i = $args[1];
  ESLVal args = $args[2];
  ESLVal dynamicArgs = $args[3];
  {ESLVal _v24 = args;
        
        if(_v24.isCons())
        {ESLVal $84 = _v24.head();
          ESLVal $85 = _v24.tail();
          
          switch($84.termName) {
          case "JDec": {ESLVal $87 = $84.termRef(0);
            ESLVal $86 = $84.termRef(1);
            
            {ESLVal n = $87;
            
            {ESLVal t = $86;
            
            {ESLVal _v82 = $85;
            
            if(member.apply(n,dynamicArgs).boolVal)
            return new ESLVal("ESLVal[] ").add(n.add(new ESLVal(" = new ESLVal[]{$args[").add(i.add(new ESLVal("]};").add(nl.apply(indent).add(ppFunArgs.apply(indent,i.add($one),_v82,dynamicArgs)))))));
            else
              {ESLVal _v83 = $87;
                
                {ESLVal _v84 = $86;
                
                {ESLVal _v85 = $85;
                
                return new ESLVal("ESLVal ").add(_v83.add(new ESLVal(" = $args[").add(i.add(new ESLVal("];").add(nl.apply(indent).add(ppFunArgs.apply(indent,i.add($one),_v85,dynamicArgs)))))));
              }
              }
              }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(23840,24234)").add(ESLVal.list(_v24)));
        }
        }
      else if(_v24.isNil())
        return new ESLVal("");
      else return error(new ESLVal("case error at Pos(23840,24234)").add(ESLVal.list(_v24)));
      }
    }
  });
  private static ESLVal ppJCommand = new ESLVal(new Function(new ESLVal("ppJCommand"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal c = $args[2];
  {ESLVal _v14 = c;
        
        switch(_v14.termName) {
        case "JIfCommand": {ESLVal $62 = _v14.termRef(0);
          ESLVal $61 = _v14.termRef(1);
          ESLVal $60 = _v14.termRef(2);
          
          {ESLVal e = $62;
          
          {ESLVal c1 = $61;
          
          {ESLVal c2 = $60;
          
          return new ESLVal("if(").add(ppJExp.apply(indent,dynamics,e).add(new ESLVal(".boolVal)").add(nl.apply(indent.add(new ESLVal(2))).add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,c1).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("else").add(nl.apply(indent.add(new ESLVal(4))).add(ppJCommand.apply(indent.add(new ESLVal(4)),dynamics,c2)))))))));
        }
        }
        }
        }
      case "JReturn": {ESLVal $57 = _v14.termRef(0);
          
          switch($57.termName) {
          case "JCommandExp": {ESLVal $59 = $57.termRef(0);
            ESLVal $58 = $57.termRef(1);
            
            {ESLVal _v80 = $59;
            
            {ESLVal t = $58;
            
            return ppJCommand.apply(indent,dynamics,_v80);
          }
          }
          }
          default: {ESLVal e = $57;
            
            return new ESLVal("return ").add(ppJExp.apply(indent.add(new ESLVal(2)),dynamics,e).add(new ESLVal(";")));
          }
        }
        }
      case "JCaseList": {ESLVal $56 = _v14.termRef(0);
          ESLVal $55 = _v14.termRef(1);
          ESLVal $54 = _v14.termRef(2);
          ESLVal $53 = _v14.termRef(3);
          
          {ESLVal l = $56;
          
          {ESLVal cons = $55;
          
          {ESLVal nil = $54;
          
          {ESLVal alt = $53;
          
          return new ESLVal("if(").add(ppJExp.apply(indent,dynamics,l).add(new ESLVal(".isCons())").add(nl.apply(indent.add(new ESLVal(2))).add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,cons).add(nl.apply(indent).add(new ESLVal("else if(").add(ppJExp.apply(indent,dynamics,l).add(new ESLVal(".isNil())").add(nl.apply(indent.add(new ESLVal(2))).add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,nil).add(nl.apply(indent).add(new ESLVal("else ").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,alt))))))))))))));
        }
        }
        }
        }
        }
      case "JCaseTerm": {ESLVal $52 = _v14.termRef(0);
          ESLVal $51 = _v14.termRef(1);
          ESLVal $50 = _v14.termRef(2);
          
          {ESLVal e = $52;
          
          {ESLVal arms = $51;
          
          {ESLVal alt = $50;
          
          return new ESLVal("switch(").add(ppJExp.apply(indent,dynamics,e).add(new ESLVal(".termName) {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v23 = $qualArg;
                
                switch(_v23.termName) {
                case "JTArm": {ESLVal $83 = _v23.termRef(0);
                  ESLVal $82 = _v23.termRef(1);
                  ESLVal $81 = _v23.termRef(2);
                  
                  {ESLVal n = $83;
                  
                  {ESLVal i = $82;
                  
                  {ESLVal _v79 = $81;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("case \"").add(n.add(new ESLVal("\": ").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,_v79))))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v23;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten()).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("default: ").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,alt).add(nl.apply(indent).add(new ESLVal("}"))))))))));
        }
        }
        }
        }
      case "JCaseInt": {ESLVal $49 = _v14.termRef(0);
          ESLVal $48 = _v14.termRef(1);
          ESLVal $47 = _v14.termRef(2);
          
          {ESLVal e = $49;
          
          {ESLVal arms = $48;
          
          {ESLVal alt = $47;
          
          return new ESLVal("switch(").add(ppJExp.apply(indent,dynamics,e).add(new ESLVal(".intVal) {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v22 = $qualArg;
                
                switch(_v22.termName) {
                case "JIArm": {ESLVal $80 = _v22.termRef(0);
                  ESLVal $79 = _v22.termRef(1);
                  
                  {ESLVal n = $80;
                  
                  {ESLVal _v78 = $79;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("case ").add(n.add(new ESLVal(": ").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,_v78))))));
                }
                }
                }
                default: {ESLVal _0 = _v22;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten()).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("default: ").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,alt).add(nl.apply(indent).add(new ESLVal("}"))))))))));
        }
        }
        }
        }
      case "JCaseStr": {ESLVal $46 = _v14.termRef(0);
          ESLVal $45 = _v14.termRef(1);
          ESLVal $44 = _v14.termRef(2);
          
          {ESLVal e = $46;
          
          {ESLVal arms = $45;
          
          {ESLVal alt = $44;
          
          return new ESLVal("switch(").add(ppJExp.apply(indent,dynamics,e).add(new ESLVal(".strVal) {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v21 = $qualArg;
                
                switch(_v21.termName) {
                case "JSArm": {ESLVal $78 = _v21.termRef(0);
                  ESLVal $77 = _v21.termRef(1);
                  
                  {ESLVal s = $78;
                  
                  {ESLVal _v77 = $77;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("case \"").add(s.add(new ESLVal("\": ").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,_v77))))));
                }
                }
                }
                default: {ESLVal _0 = _v21;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten()).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("default: ").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,alt).add(nl.apply(indent).add(new ESLVal("}"))))))))));
        }
        }
        }
        }
      case "JCaseBool": {ESLVal $43 = _v14.termRef(0);
          ESLVal $42 = _v14.termRef(1);
          ESLVal $41 = _v14.termRef(2);
          
          {ESLVal e = $43;
          
          {ESLVal arms = $42;
          
          {ESLVal alt = $41;
          
          return new ESLVal("switch(").add(ppJExp.apply(indent,dynamics,e).add(new ESLVal(".boolVal ? 1 : 0) {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v20 = $qualArg;
                
                switch(_v20.termName) {
                case "JBArm": {ESLVal $76 = _v20.termRef(0);
                  ESLVal $75 = _v20.termRef(1);
                  
                  {ESLVal b = $76;
                  
                  {ESLVal _v76 = $75;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("case ").add(((Supplier<ESLVal>)() -> { 
                    if(b.boolVal)
                      return $one;
                      else
                        return $zero;
                  }).get().add(new ESLVal(": ").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,_v76))))));
                }
                }
                }
                default: {ESLVal _0 = _v20;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten()).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("default: ").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,alt).add(nl.apply(indent).add(new ESLVal("}"))))))))));
        }
        }
        }
        }
      case "JLet": {ESLVal $40 = _v14.termRef(0);
          ESLVal $39 = _v14.termRef(1);
          
          {ESLVal bs = $40;
          
          {ESLVal _v75 = $39;
          
          {ESLVal boundVars = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v19 = $qualArg;
                  
                  switch(_v19.termName) {
                  case "JField": {ESLVal $74 = _v19.termRef(0);
                    ESLVal $73 = _v19.termRef(1);
                    ESLVal $72 = _v19.termRef(2);
                    
                    {ESLVal n = $74;
                    
                    {ESLVal t = $73;
                    
                    {ESLVal e = $72;
                    
                    return ESLVal.list(ESLVal.list(n));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v19;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(bs).flatten().flatten();
          ESLVal dynamicVars = dynamicVarsJCommand.apply(_v75);
          
          {ESLVal boundDynamicVars = filter.apply(new ESLVal(new Function(new ESLVal("fun632"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal s = $args[0];
            return member.apply(s,dynamicVars);
              }
            }),boundVars);
          
          return new ESLVal("{").add(ppJFields.apply(indent.add(new ESLVal(2)),dynamics.add(boundDynamicVars),bs).add(nl.apply(indent.add(new ESLVal(2))).add(ppJCommand.apply(indent,dynamics.add(boundDynamicVars),_v75).add(nl.apply(indent).add(new ESLVal("}"))))));
        }
        }
        }
        }
        }
      case "JLetRec": {ESLVal $38 = _v14.termRef(0);
          ESLVal $37 = _v14.termRef(1);
          
          {ESLVal bs = $38;
          
          {ESLVal _v74 = $37;
          
          return new ESLVal("LetRec letrec = new LetRec() {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJFields.apply(indent.add(new ESLVal(2)),dynamics,bs).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal get(String name) {").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("switch(name) {").add(nl.apply(indent.add(new ESLVal(6))).add(ppJoin.apply(indent.add(new ESLVal(6)),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v17 = $qualArg;
                
                switch(_v17.termName) {
                case "JField": {ESLVal $68 = _v17.termRef(0);
                  ESLVal $67 = _v17.termRef(1);
                  ESLVal $66 = _v17.termRef(2);
                  
                  {ESLVal n = $68;
                  
                  {ESLVal t = $67;
                  
                  {ESLVal e = $66;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("case \"").add(n.add(new ESLVal("\": return ").add(n.add(new ESLVal(";").add(nl.apply(indent.add(new ESLVal(6))))))))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v17;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(bs).flatten().flatten()).add(nl.apply(indent.add(new ESLVal(6))).add(new ESLVal("default: throw new Error(\"cannot find letrec binding\");").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("}").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("}").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("};").add(nl.apply(indent).add(ppJoin.apply(indent,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v18 = $qualArg;
                
                switch(_v18.termName) {
                case "JField": {ESLVal $71 = _v18.termRef(0);
                  ESLVal $70 = _v18.termRef(1);
                  ESLVal $69 = _v18.termRef(2);
                  
                  {ESLVal n = $71;
                  
                  {ESLVal t = $70;
                  
                  {ESLVal e = $69;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("ESLVal ").add(n.add(new ESLVal(" = letrec.get(\"").add(n.add(new ESLVal("\");").add(nl.apply(indent))))))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v18;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(bs).flatten().flatten()).add(nl.apply(indent.add(new ESLVal(2))).add(ppJCommand.apply(indent,dynamics,_v74).add(nl.apply(indent))))))))))))))))))))));
        }
        }
        }
      case "JPLet": {ESLVal $36 = _v14.termRef(0);
          ESLVal $35 = _v14.termRef(1);
          
          {ESLVal bs = $36;
          
          {ESLVal _v73 = $35;
          
          {ESLVal boundVars = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v16 = $qualArg;
                  
                  switch(_v16.termName) {
                  case "JField": {ESLVal $65 = _v16.termRef(0);
                    ESLVal $64 = _v16.termRef(1);
                    ESLVal $63 = _v16.termRef(2);
                    
                    {ESLVal n = $65;
                    
                    {ESLVal t = $64;
                    
                    {ESLVal e = $63;
                    
                    return ESLVal.list(ESLVal.list(n));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v16;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(bs).flatten().flatten();
          ESLVal dynamicVars = dynamicVarsJCommand.apply(_v73);
          
          {ESLVal boundDynamicVars = filter.apply(new ESLVal(new Function(new ESLVal("fun633"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal s = $args[0];
            return member.apply(s,dynamicVars);
              }
            }),boundVars);
          
          return new ESLVal("{").add(ppJParFields.apply(indent.add(new ESLVal(2)),dynamics.add(boundDynamicVars),bs).add(nl.apply(indent.add(new ESLVal(2))).add(ppJCommand.apply(indent,dynamics.add(boundDynamicVars),_v73).add(nl.apply(indent).add(new ESLVal("}"))))));
        }
        }
        }
        }
        }
      case "JBlock": {ESLVal $34 = _v14.termRef(0);
          
          {ESLVal cs = $34;
          
          return new ESLVal("{").add(ppJoin.apply(indent,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v15 = $qualArg;
                
                {ESLVal _v72 = _v15;
                
                return ESLVal.list(ESLVal.list(ppJCommand.apply(indent,dynamics,_v72)));
              }
              }
            }
          }).map(cs).flatten().flatten()).add(new ESLVal("}")));
        }
        }
      case "JUpdate": {ESLVal $33 = _v14.termRef(0);
          ESLVal $32 = _v14.termRef(1);
          
          {ESLVal n = $33;
          
          {ESLVal e = $32;
          
          if(member.apply(n,dynamics).boolVal)
          return n.add(new ESLVal("[0] = ").add(ppJExp.apply(indent,dynamics,e).add(new ESLVal(";"))));
          else
            {ESLVal _v70 = $33;
              
              {ESLVal _v71 = $32;
              
              return _v70.add(new ESLVal(" = ").add(ppJExp.apply(indent,dynamics,_v71).add(new ESLVal(";"))));
            }
            }
        }
        }
        }
      case "JFor": {ESLVal $31 = _v14.termRef(0);
          ESLVal $30 = _v14.termRef(1);
          ESLVal $29 = _v14.termRef(2);
          ESLVal $28 = _v14.termRef(3);
          
          {ESLVal listName = $31;
          
          {ESLVal varName = $30;
          
          {ESLVal e = $29;
          
          {ESLVal _v69 = $28;
          
          return new ESLVal("{").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("ESLVal ").add(listName.add(new ESLVal(" = ").add(ppJExp.apply(indent.add(new ESLVal(2)),dynamics,e).add(new ESLVal(";").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("while(").add(listName.add(new ESLVal(".isCons()) {").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("ESLVal ").add(varName.add(new ESLVal(" = ").add(listName.add(new ESLVal(".headVal;").add(nl.apply(indent.add(new ESLVal(4))).add(ppJCommand.apply(indent.add(new ESLVal(4)),dynamics,_v69).add(nl.apply(indent.add(new ESLVal(4))).add(listName.add(new ESLVal(" = ").add(listName.add(new ESLVal(".tailVal;").add(new ESLVal("}").add(nl.apply(indent).add(new ESLVal("}")))))))))))))))))))))))))));
        }
        }
        }
        }
        }
      case "JStatement": {ESLVal $27 = _v14.termRef(0);
          
          {ESLVal e = $27;
          
          return ppJExp.apply(indent,dynamics,e).add(new ESLVal(";"));
        }
        }
        default: {ESLVal _v81 = _v14;
          
          return new ESLVal("******* unknown command: ").add(_v81);
        }
      }
      }
    }
  });
  private static ESLVal ppJParFields = new ESLVal(new Function(new ESLVal("ppJParFields"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal bs = $args[2];
  LetRec letrec = new LetRec() {
        ESLVal vals = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v13 = $qualArg;
                
                switch(_v13.termName) {
                case "JField": {ESLVal $26 = _v13.termRef(0);
                  ESLVal $25 = _v13.termRef(1);
                  ESLVal $24 = _v13.termRef(2);
                  
                  {ESLVal n = $26;
                  
                  {ESLVal t = $25;
                  
                  {ESLVal e = $24;
                  
                  return ESLVal.list(ESLVal.list(e));
                }
                }
                }
                }
                default: {ESLVal _0 = _v13;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(bs).flatten().flatten();
        ESLVal names = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v12 = $qualArg;
                
                switch(_v12.termName) {
                case "JField": {ESLVal $23 = _v12.termRef(0);
                  ESLVal $22 = _v12.termRef(1);
                  ESLVal $21 = _v12.termRef(2);
                  
                  {ESLVal n = $23;
                  
                  {ESLVal t = $22;
                  
                  {ESLVal e = $21;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                default: {ESLVal _0 = _v12;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(bs).flatten().flatten();
        ESLVal doVals = new ESLVal(new Function(new ESLVal("doVals"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal vals = $args[0];
          {ESLVal _v11 = vals;
                
                if(_v11.isCons())
                {ESLVal $17 = _v11.head();
                  ESLVal $18 = _v11.tail();
                  
                  if($18.isCons())
                  {ESLVal $19 = $18.head();
                    ESLVal $20 = $18.tail();
                    
                    {ESLVal v = $17;
                    
                    {ESLVal vs = $18;
                    
                    return new ESLVal("() -> ").add(ppJExp.apply(indent,dynamics,v).add(new ESLVal(",").add(doVals.apply(vs))));
                  }
                  }
                  }
                else if($18.isNil())
                  {ESLVal v = $17;
                    
                    return new ESLVal("() -> ").add(ppJExp.apply(indent,dynamics,v));
                  }
                else {ESLVal v = $17;
                    
                    {ESLVal vs = $18;
                    
                    return new ESLVal("() -> ").add(ppJExp.apply(indent,dynamics,v).add(new ESLVal(",").add(doVals.apply(vs))));
                  }
                  }
                }
              else if(_v11.isNil())
                return new ESLVal("");
              else return error(new ESLVal("case error at Pos(29347,29510)").add(ESLVal.list(_v11)));
              }
            }
          });
        ESLVal bindNames = new ESLVal(new Function(new ESLVal("bindNames"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal ns = $args[0];
          ESLVal i = $args[1];
          {ESLVal _v10 = ns;
                
                if(_v10.isCons())
                {ESLVal $15 = _v10.head();
                  ESLVal $16 = _v10.tail();
                  
                  {ESLVal n = $15;
                  
                  {ESLVal _v66 = $16;
                  
                  if(member.apply(n,dynamics).boolVal)
                  return new ESLVal("ESLVal[] ").add(n.add(new ESLVal("= new ESLVal[]{$p[").add(i.add(new ESLVal("]};").add(nl.apply(indent).add(bindNames.apply(_v66,i.add($one))))))));
                  else
                    {ESLVal _v67 = $15;
                      
                      {ESLVal _v68 = $16;
                      
                      return new ESLVal("ESLVal ").add(_v67.add(new ESLVal("= $p[").add(i.add(new ESLVal("];").add(nl.apply(indent).add(bindNames.apply(_v68,i.add($one))))))));
                    }
                    }
                }
                }
                }
              else if(_v10.isNil())
                return new ESLVal("");
              else return error(new ESLVal("case error at Pos(29556,29806)").add(ESLVal.list(_v10)));
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "vals": return vals;
            
            case "names": return names;
            
            case "doVals": return doVals;
            
            case "bindNames": return bindNames;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal vals = letrec.get("vals");
      
      ESLVal names = letrec.get("names");
      
      ESLVal doVals = letrec.get("doVals");
      
      ESLVal bindNames = letrec.get("bindNames");
      
        return new ESLVal("ESLVal[] $p = plet(new Supplier[]{").add(doVals.apply(vals).add(new ESLVal("});").add(nl.apply(indent).add(bindNames.apply(names,$zero)))));
      
    }
  });
  private static ESLVal ppJFields = new ESLVal(new Function(new ESLVal("ppJFields"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal bs = $args[2];
  {ESLVal _v9 = bs;
        
        if(_v9.isCons())
        {ESLVal $13 = _v9.head();
          ESLVal $14 = _v9.tail();
          
          {ESLVal f = $13;
          
          {ESLVal _v65 = $14;
          
          return ppFieldDef.apply(indent,dynamics,f).add(nl.apply(indent).add(ppJFields.apply(indent,dynamics,_v65)));
        }
        }
        }
      else if(_v9.isNil())
        return new ESLVal("");
      else return error(new ESLVal("case error at Pos(29975,30125)").add(ESLVal.list(_v9)));
      }
    }
  });
  private static ESLVal ppFieldDef = new ESLVal(new Function(new ESLVal("ppFieldDef"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal f = $args[2];
  {ESLVal _v8 = f;
        
        switch(_v8.termName) {
        case "JField": {ESLVal $12 = _v8.termRef(0);
          ESLVal $11 = _v8.termRef(1);
          ESLVal $10 = _v8.termRef(2);
          
          {ESLVal n = $12;
          
          {ESLVal t = $11;
          
          {ESLVal e = $10;
          
          if(member.apply(n,dynamics).boolVal)
          return new ESLVal("ESLVal[] ").add(n.add(new ESLVal(" = new ESLVal[]{").add(ppJExp.apply(indent.add(new ESLVal(2)),dynamics,e).add(new ESLVal("};")))));
          else
            {ESLVal _v62 = $12;
              
              {ESLVal _v63 = $11;
              
              {ESLVal _v64 = $10;
              
              return new ESLVal("ESLVal ").add(_v62.add(new ESLVal(" = ").add(ppJExp.apply(indent.add(new ESLVal(2)),dynamics,_v64).add(new ESLVal(";")))));
            }
            }
            }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(30189,30443)").add(ESLVal.list(_v8)));
      }
      }
    }
  });
  private static ESLVal ppJTerm = new ESLVal(new Function(new ESLVal("ppJTerm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal n = $args[2];
  ESLVal es = $args[3];
  {ESLVal _v7 = es;
        
        if(_v7.isCons())
        {ESLVal $8 = _v7.head();
          ESLVal $9 = _v7.tail();
          
          {ESLVal _v60 = _v7;
          
          return new ESLVal("new Term(\"").add(n.add(new ESLVal("\",").add(ppJExps.apply(indent,dynamics,_v60,new ESLVal(",")).add(new ESLVal(")")))));
        }
        }
      else if(_v7.isNil())
        return new ESLVal("new Term(\"").add(n.add(new ESLVal("\")")));
      else {ESLVal _v61 = _v7;
          
          return new ESLVal("new Term(\"").add(n.add(new ESLVal("\",").add(ppJExps.apply(indent,dynamics,_v61,new ESLVal(",")).add(new ESLVal(")")))));
        }
      }
    }
  });
  private static ESLVal ppJListExp = new ESLVal(new Function(new ESLVal("ppJListExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal t = $args[2];
  ESLVal es = $args[3];
  return new ESLVal("ESLVal.list(").add(ppJExps.apply(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")")));
    }
  });
  private static ESLVal ppJSetExp = new ESLVal(new Function(new ESLVal("ppJSetExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal t = $args[2];
  ESLVal es = $args[3];
  return new ESLVal("ESLVal.set(").add(ppJExps.apply(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")")));
    }
  });
  private static ESLVal ppJBagExp = new ESLVal(new Function(new ESLVal("ppJBagExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal t = $args[2];
  ESLVal es = $args[3];
  return new ESLVal("ESLVal.bag(").add(ppJExps.apply(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")")));
    }
  });
  public static ESLVal main = new ESLVal(new Function(new ESLVal("main"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      return new ESLVal(new BehaviourAdapter(true,getSelf(),new ESLVal("main")) {
          
          public ESLVal handle(ESLVal $m) {{ESLVal _v6 = $m;
            
            return error(new ESLVal("case error at Pos(0,0)").add(ESLVal.list(_v6)));
          }}
          public ESLVal get(String name) {
            switch(name) {
              
              default: throw new Error("ref illegal " + self + "." + name);
            }
          }
        public void handleTime(ESLVal $t) {
          {ESLVal t = $t;
            
            if($true.boolVal)
            {new Function(new ESLVal("try"),getSelf()) {
              public ESLVal apply(ESLVal... args) { 
                try { 
                  return print.apply(ppExp.apply($zero,parse.apply(new ESLVal("esl/compiler/test1.esl"))));
                } catch(ESLError $exception) {
                  ESLVal $x = $exception.value;
                  {ESLVal _v5 = $x;
              
              {ESLVal message = _v5;
              
              return print.apply(new ESLVal("PP Error: ").add(message));
            }
            }
                }
              }
            }.apply();
            print.apply(new ESLVal("DONE"));
            stopAll.apply();}
            else
              {}
          }
        }
        public ESLVal init() {
            return $null;
          }
        });
    }
  });
public static void main(String[] args) {
    newActor(main,new ESLVal(new Actor())); 
  }
}