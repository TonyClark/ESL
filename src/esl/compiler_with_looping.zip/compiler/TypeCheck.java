package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
// import static esl.Lists.*;
import static esl.compiler.Types.*;
import static esl.Tables.*;
import java.util.function.Supplier;
public class TypeCheck {
  public static ESLVal getSelf() { return $null; }
  private static ESLVal ppPattern = new ESLVal(new Function(new ESLVal("ppPattern"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v972 = p;
        
        switch(_v972.termName) {
        case "PAdd": {ESLVal $2247 = _v972.termRef(0);
          ESLVal $2246 = _v972.termRef(1);
          ESLVal $2245 = _v972.termRef(2);
          
          {ESLVal l = $2247;
          
          {ESLVal p1 = $2246;
          
          {ESLVal p2 = $2245;
          
          return ppPattern.apply(p1).add(new ESLVal(" + ").add(ppPattern.apply(p2)));
        }
        }
        }
        }
      case "PVar": {ESLVal $2244 = _v972.termRef(0);
          ESLVal $2243 = _v972.termRef(1);
          ESLVal $2242 = _v972.termRef(2);
          
          {ESLVal l = $2244;
          
          {ESLVal n = $2243;
          
          {ESLVal t = $2242;
          
          return n;
        }
        }
        }
        }
      case "PTerm": {ESLVal $2239 = _v972.termRef(0);
          ESLVal $2238 = _v972.termRef(1);
          ESLVal $2237 = _v972.termRef(2);
          ESLVal $2236 = _v972.termRef(3);
          
          if($2237.isCons())
          {ESLVal $2240 = $2237.head();
            ESLVal $2241 = $2237.tail();
            
            {ESLVal l = $2239;
            
            {ESLVal n = $2238;
            
            {ESLVal ts = $2237;
            
            {ESLVal ps = $2236;
            
            return n.add(ppTypes.apply(ts,ESLVal.list()).add(new ESLVal("").add(ppPatterns.apply(ps))));
          }
          }
          }
          }
          }
        else if($2237.isNil())
          {ESLVal l = $2239;
            
            {ESLVal n = $2238;
            
            {ESLVal ps = $2236;
            
            return n.add(ppPatterns.apply(ps));
          }
          }
          }
        else {ESLVal l = $2239;
            
            {ESLVal n = $2238;
            
            {ESLVal ts = $2237;
            
            {ESLVal ps = $2236;
            
            return n.add(ppTypes.apply(ts,ESLVal.list()).add(new ESLVal("").add(ppPatterns.apply(ps))));
          }
          }
          }
          }
        }
      case "PApplyType": {ESLVal $2235 = _v972.termRef(0);
          ESLVal $2234 = _v972.termRef(1);
          ESLVal $2233 = _v972.termRef(2);
          
          {ESLVal l = $2235;
          
          {ESLVal _v1912 = $2234;
          
          {ESLVal ts = $2233;
          
          return ppPattern.apply(_v1912).add(ppTypes.apply(ts,ESLVal.list()));
        }
        }
        }
        }
      case "PNil": {ESLVal $2232 = _v972.termRef(0);
          
          {ESLVal l = $2232;
          
          return new ESLVal("[]");
        }
        }
      case "PEmptySet": {ESLVal $2231 = _v972.termRef(0);
          
          {ESLVal l = $2231;
          
          return new ESLVal("Set{}");
        }
        }
      case "PEmptyBag": {ESLVal $2230 = _v972.termRef(0);
          
          {ESLVal l = $2230;
          
          return new ESLVal("Bag{}");
        }
        }
      case "PInt": {ESLVal $2229 = _v972.termRef(0);
          ESLVal $2228 = _v972.termRef(1);
          
          {ESLVal l = $2229;
          
          {ESLVal n = $2228;
          
          return new ESLVal("").add(n);
        }
        }
        }
      case "PBool": {ESLVal $2227 = _v972.termRef(0);
          ESLVal $2226 = _v972.termRef(1);
          
          {ESLVal l = $2227;
          
          {ESLVal b = $2226;
          
          return new ESLVal("").add(b);
        }
        }
        }
      case "PStr": {ESLVal $2225 = _v972.termRef(0);
          ESLVal $2224 = _v972.termRef(1);
          
          {ESLVal l = $2225;
          
          {ESLVal s = $2224;
          
          return s;
        }
        }
        }
      case "PCons": {ESLVal $2223 = _v972.termRef(0);
          ESLVal $2222 = _v972.termRef(1);
          ESLVal $2221 = _v972.termRef(2);
          
          {ESLVal l = $2223;
          
          {ESLVal h = $2222;
          
          {ESLVal t = $2221;
          
          return ppPattern.apply(h).add(new ESLVal(":").add(ppPattern.apply(t)));
        }
        }
        }
        }
      case "PSetCons": {ESLVal $2220 = _v972.termRef(0);
          ESLVal $2219 = _v972.termRef(1);
          ESLVal $2218 = _v972.termRef(2);
          
          {ESLVal l = $2220;
          
          {ESLVal p1 = $2219;
          
          {ESLVal p2 = $2218;
          
          return new ESLVal("Set{").add(ppPattern.apply(p1).add(new ESLVal(" | ").add(ppPattern.apply(p2).add(new ESLVal("}")))));
        }
        }
        }
        }
      case "PBagCons": {ESLVal $2217 = _v972.termRef(0);
          ESLVal $2216 = _v972.termRef(1);
          ESLVal $2215 = _v972.termRef(2);
          
          {ESLVal l = $2217;
          
          {ESLVal p1 = $2216;
          
          {ESLVal p2 = $2215;
          
          return new ESLVal("Bag{").add(ppPattern.apply(p1).add(new ESLVal(" | ").add(ppPattern.apply(p2).add(new ESLVal("}")))));
        }
        }
        }
        }
        default: {ESLVal _v1913 = _v972;
          
          return new ESLVal("<unknown: ").add(_v1913.add(new ESLVal(">")));
        }
      }
      }
    }
  });
  private static ESLVal ppPatterns = new ESLVal(new Function(new ESLVal("ppPatterns"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal ps = $args[0];
  return map.apply(ppPattern,ps);
    }
  });
  private static ESLVal p0 = new ESLVal("Pos",$zero,$zero);
  private static ESLVal actType0 = new ESLVal("ActType",p0,ESLVal.list(),ESLVal.list());
  private static ESLVal contentType = new ESLVal("UnionType",p0,ESLVal.list(new ESLVal("TermType",p0,new ESLVal("RawText"),ESLVal.list(new ESLVal("StrType",p0))),new ESLVal("TermType",p0,new ESLVal("ESLSource"),ESLVal.list(new ESLVal("StrType",p0),new ESLVal("StrType",p0))),new ESLVal("TermType",p0,new ESLVal("JavaSource"),ESLVal.list(new ESLVal("StrType",p0),new ESLVal("StrType",p0),new ESLVal("StrType",p0)))));
  private static ESLVal editMessage = new ESLVal("MessageType",p0,ESLVal.list(new ESLVal("TermType",p0,new ESLVal("Edit"),ESLVal.list(contentType))));
  private static ESLVal env0 = ESLVal.list(new ESLVal("Map",new ESLVal("edb"),new ESLVal("ActType",p0,ESLVal.list(new ESLVal("Dec",p0,new ESLVal("button"),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("StrType",p0),new ESLVal("StrType",p0),new ESLVal("StrType",p0),new ESLVal("StrType",p0),new ESLVal("FunType",p0,ESLVal.list(),new ESLVal("VoidType",p0))),new ESLVal("VoidType",p0)),$null),new ESLVal("Dec",p0,new ESLVal("display"),new ESLVal("ForallType",p0,ESLVal.list(new ESLVal("T")),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("StrType",p0),new ESLVal("VarType",p0,new ESLVal("T"))),new ESLVal("VarType",p0,new ESLVal("T")))),$null)),ESLVal.list(editMessage))),new ESLVal("Map",new ESLVal("kill"),new ESLVal("ForallType",p0,ESLVal.list(new ESLVal("T")),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("VarType",p0,new ESLVal("T"))),new ESLVal("VoidType",p0)))),new ESLVal("Map",new ESLVal("print"),new ESLVal("ForallType",p0,ESLVal.list(new ESLVal("T")),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("VarType",p0,new ESLVal("T"))),new ESLVal("VoidType",p0)))),new ESLVal("Map",new ESLVal("parse"),new ESLVal("ForallType",p0,ESLVal.list(new ESLVal("T")),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("StrType",p0)),new ESLVal("VarType",p0,new ESLVal("T"))))),new ESLVal("Map",new ESLVal("random"),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("IntType",p0)),new ESLVal("IntType",p0))),new ESLVal("Map",new ESLVal("wait"),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("IntType",p0)),new ESLVal("VoidType",p0))),new ESLVal("Map",new ESLVal("stopAll"),new ESLVal("FunType",p0,ESLVal.list(),new ESLVal("VoidType",p0))),new ESLVal("Map",new ESLVal("isqrt"),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("IntType",p0)),new ESLVal("FloatType",p0))),new ESLVal("Map",new ESLVal("builtin"),new ESLVal("ForallType",p0,ESLVal.list(new ESLVal("T")),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("StrType",p0),new ESLVal("StrType",p0),new ESLVal("IntType",p0)),new ESLVal("VarType",p0,new ESLVal("T"))))));
  private static ESLVal cnstrEnv0 = ESLVal.list(new ESLVal("Map",new ESLVal("Time"),new ESLVal("UnionType",p0,ESLVal.list(new ESLVal("TermType",p0,new ESLVal("Time"),ESLVal.list(new ESLVal("IntType",p0)))))));
  private static ESLVal tenv0 = ESLVal.list(new ESLVal("Map",new ESLVal("EditType"),contentType),new ESLVal("Map",new ESLVal("Time"),new ESLVal("UnionType",p0,ESLVal.list(new ESLVal("TermType",p0,new ESLVal("Time"),ESLVal.list(new ESLVal("IntType",p0)))))),new ESLVal("Map",new ESLVal("Point"),new ESLVal("UnionType",p0,ESLVal.list(new ESLVal("TermType",p0,new ESLVal("Point"),ESLVal.list(new ESLVal("IntType",p0),new ESLVal("IntType",p0)))))));
  private static ESLVal ppTypeEnv = new ESLVal(new Function(new ESLVal("ppTypeEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal env = $args[0];
  {ESLVal[] s = new ESLVal[]{new ESLVal("[")};
        
        {{
        ESLVal _v970 = env;
        while(_v970.isCons()) {
          ESLVal _v969 = _v970.headVal;
          {ESLVal _v968 = new ESLVal(new Function(new ESLVal("forp"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  {ESLVal _v971 = _v969;
                    
                    switch(_v971.termName) {
                    case "Map": {ESLVal $2214 = _v971.termRef(0);
                      ESLVal $2213 = _v971.termRef(1);
                      
                      {ESLVal n = $2214;
                      
                      {ESLVal t = $2213;
                      
                      {s[0] = s[0].add(n.add(new ESLVal("->").add(ppType.apply(t,env).add(new ESLVal(",")))));
                    return $null;}
                    }
                    }
                    }
                    default: {ESLVal $$$ = _v971;
                      
                      return $null;
                    }
                  }
                  }
                }
              });
            
            _v968.apply();
          }
          _v970 = _v970.tailVal;}
      }
      return s[0].add(new ESLVal("]"));}
      }
    }
  });
  private static ESLVal ppTypes = new ESLVal(new Function(new ESLVal("ppTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal ts = $args[0];
  ESLVal env = $args[1];
  return map.apply(ppType0.apply(env),ts);
    }
  });
  private static ESLVal getTypeName = new ESLVal(new Function(new ESLVal("getTypeName"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t0 = $args[0];
  ESLVal env = $args[1];
  {ESLVal[] name = new ESLVal[]{$null};
        
        {{
        ESLVal _v966 = env;
        while(_v966.isCons()) {
          ESLVal _v965 = _v966.headVal;
          {ESLVal _v964 = new ESLVal(new Function(new ESLVal("forp"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  {ESLVal _v967 = _v965;
                    
                    switch(_v967.termName) {
                    case "Map": {ESLVal $2212 = _v967.termRef(0);
                      ESLVal $2211 = _v967.termRef(1);
                      
                      {ESLVal n = $2212;
                      
                      {ESLVal t = $2211;
                      
                      if(typeEqual.apply(t0,t).boolVal)
                      {name[0] = n;
                      return $null;}
                      else
                        return $null;
                    }
                    }
                    }
                    default: {ESLVal $$$ = _v967;
                      
                      return $null;
                    }
                  }
                  }
                }
              });
            
            _v964.apply();
          }
          _v966 = _v966.tailVal;}
      }
      return name[0];}
      }
    }
  });
  private static ESLVal ppType0 = new ESLVal(new Function(new ESLVal("ppType0"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal env = $args[0];
  return new ESLVal(new Function(new ESLVal("fun828"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal t = $args[0];
        return ppType.apply(t,env);
          }
        });
    }
  });
  private static ESLVal ppHandlers = new ESLVal(new Function(new ESLVal("ppHandlers"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal handlers = $args[0];
  ESLVal env = $args[1];
  {ESLVal _v963 = handlers;
        
        if(_v963.isCons())
        {ESLVal $2205 = _v963.head();
          ESLVal $2206 = _v963.tail();
          
          switch($2205.termName) {
          case "MessageType": {ESLVal $2208 = $2205.termRef(0);
            ESLVal $2207 = $2205.termRef(1);
            
            if($2207.isCons())
            {ESLVal $2209 = $2207.head();
              ESLVal $2210 = $2207.tail();
              
              {ESLVal l = $2208;
              
              {ESLVal t = $2209;
              
              {ESLVal ts = $2210;
              
              {ESLVal hs = $2206;
              
              return ppType.apply(t,env).add(new ESLVal("; ").add(ppHandlers.apply(hs,env)));
            }
            }
            }
            }
            }
          else if($2207.isNil())
            return error(new ESLVal("case error at Pos(5351,5485)").add(ESLVal.list(_v963)));
          else return error(new ESLVal("case error at Pos(5351,5485)").add(ESLVal.list(_v963)));
          }
          default: return error(new ESLVal("case error at Pos(5351,5485)").add(ESLVal.list(_v963)));
        }
        }
      else if(_v963.isNil())
        return new ESLVal("");
      else return error(new ESLVal("case error at Pos(5351,5485)").add(ESLVal.list(_v963)));
      }
    }
  });
  private static ESLVal ppDecs = new ESLVal(new Function(new ESLVal("ppDecs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal decs = $args[0];
  ESLVal env = $args[1];
  {ESLVal _v962 = decs;
        
        if(_v962.isCons())
        {ESLVal $2199 = _v962.head();
          ESLVal $2200 = _v962.tail();
          
          switch($2199.termName) {
          case "Dec": {ESLVal $2204 = $2199.termRef(0);
            ESLVal $2203 = $2199.termRef(1);
            ESLVal $2202 = $2199.termRef(2);
            ESLVal $2201 = $2199.termRef(3);
            
            {ESLVal l = $2204;
            
            {ESLVal n = $2203;
            
            {ESLVal t = $2202;
            
            {ESLVal d = $2201;
            
            {ESLVal _v1911 = $2200;
            
            return n.add(new ESLVal("::").add(ppType.apply(t,env).add(new ESLVal("; ").add(ppDecs.apply(_v1911,env)))));
          }
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(5526,5640)").add(ESLVal.list(_v962)));
        }
        }
      else if(_v962.isNil())
        return new ESLVal("");
      else return error(new ESLVal("case error at Pos(5526,5640)").add(ESLVal.list(_v962)));
      }
    }
  });
  private static ESLVal ppType = new ESLVal(new Function(new ESLVal("ppType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  ESLVal env = $args[1];
  if(getTypeName.apply(t,env).neql($null).boolVal)
        return getTypeName.apply(t,env);
        else
          {ESLVal _v961 = t;
            
            switch(_v961.termName) {
            case "ActType": {ESLVal $2198 = _v961.termRef(0);
              ESLVal $2197 = _v961.termRef(1);
              ESLVal $2196 = _v961.termRef(2);
              
              {ESLVal l = $2198;
              
              {ESLVal decs = $2197;
              
              {ESLVal handlers = $2196;
              
              return new ESLVal("Act { ").add(ppHandlers.apply(handlers,env).add(new ESLVal(" }")));
            }
            }
            }
            }
          case "ApplyType": {ESLVal $2195 = _v961.termRef(0);
              ESLVal $2194 = _v961.termRef(1);
              ESLVal $2193 = _v961.termRef(2);
              
              {ESLVal l = $2195;
              
              {ESLVal n = $2194;
              
              {ESLVal args = $2193;
              
              return n.add(map.apply(ppType0.apply(env),args));
            }
            }
            }
            }
          case "ApplyTypeFun": {ESLVal $2192 = _v961.termRef(0);
              ESLVal $2191 = _v961.termRef(1);
              ESLVal $2190 = _v961.termRef(2);
              
              {ESLVal l = $2192;
              
              {ESLVal op = $2191;
              
              {ESLVal args = $2190;
              
              return ppType.apply(op,env).add(map.apply(ppType0.apply(env),args));
            }
            }
            }
            }
          case "ArrayType": {ESLVal $2189 = _v961.termRef(0);
              ESLVal $2188 = _v961.termRef(1);
              
              {ESLVal l = $2189;
              
              {ESLVal _v1910 = $2188;
              
              return new ESLVal("Array[").add(ppType.apply(_v1910,env).add(new ESLVal("]")));
            }
            }
            }
          case "BagType": {ESLVal $2187 = _v961.termRef(0);
              ESLVal $2186 = _v961.termRef(1);
              
              {ESLVal l = $2187;
              
              {ESLVal _v1909 = $2186;
              
              return new ESLVal("Set{").add(ppType.apply(_v1909,env).add(new ESLVal("}")));
            }
            }
            }
          case "BoolType": {ESLVal $2185 = _v961.termRef(0);
              
              {ESLVal l = $2185;
              
              return new ESLVal("Bool");
            }
            }
          case "ExtendedAct": {ESLVal $2184 = _v961.termRef(0);
              ESLVal $2183 = _v961.termRef(1);
              ESLVal $2182 = _v961.termRef(2);
              ESLVal $2181 = _v961.termRef(3);
              
              {ESLVal l = $2184;
              
              {ESLVal parent = $2183;
              
              {ESLVal decs = $2182;
              
              {ESLVal handlers = $2181;
              
              return new ESLVal("Act extends ").add(ppType.apply(parent,env).add(new ESLVal(" { ").add(ppHandlers.apply(handlers,env).add(new ESLVal(" }")))));
            }
            }
            }
            }
            }
          case "FloatType": {ESLVal $2180 = _v961.termRef(0);
              
              {ESLVal l = $2180;
              
              return new ESLVal("Float");
            }
            }
          case "FieldType": {ESLVal $2179 = _v961.termRef(0);
              ESLVal $2178 = _v961.termRef(1);
              ESLVal $2177 = _v961.termRef(2);
              
              {ESLVal l = $2179;
              
              {ESLVal n = $2178;
              
              {ESLVal _v1908 = $2177;
              
              return n.add(new ESLVal("::").add(ppType.apply(_v1908,env)));
            }
            }
            }
            }
          case "ForallType": {ESLVal $2176 = _v961.termRef(0);
              ESLVal $2175 = _v961.termRef(1);
              ESLVal $2174 = _v961.termRef(2);
              
              {ESLVal l = $2176;
              
              {ESLVal ns = $2175;
              
              {ESLVal _v1907 = $2174;
              
              return new ESLVal("Forall").add(ns.add(new ESLVal(".").add(ppType.apply(_v1907,env))));
            }
            }
            }
            }
          case "FunType": {ESLVal $2173 = _v961.termRef(0);
              ESLVal $2172 = _v961.termRef(1);
              ESLVal $2171 = _v961.termRef(2);
              
              {ESLVal l = $2173;
              
              {ESLVal d = $2172;
              
              {ESLVal r = $2171;
              
              return map.apply(ppType0.apply(env),d).add(new ESLVal("->").add(ppType.apply(r,env)));
            }
            }
            }
            }
          case "TaggedFunType": {ESLVal $2170 = _v961.termRef(0);
              ESLVal $2169 = _v961.termRef(1);
              ESLVal $2168 = _v961.termRef(2);
              ESLVal $2167 = _v961.termRef(3);
              
              {ESLVal l = $2170;
              
              {ESLVal d = $2169;
              
              {ESLVal p = $2168;
              
              {ESLVal r = $2167;
              
              return map.apply(ppType0.apply(env),d).add(new ESLVal("->").add(ppType.apply(r,env)));
            }
            }
            }
            }
            }
          case "IntType": {ESLVal $2166 = _v961.termRef(0);
              
              {ESLVal l = $2166;
              
              return new ESLVal("Int");
            }
            }
          case "ListType": {ESLVal $2165 = _v961.termRef(0);
              ESLVal $2164 = _v961.termRef(1);
              
              {ESLVal l = $2165;
              
              {ESLVal _v1906 = $2164;
              
              return new ESLVal("[").add(ppType.apply(_v1906,env).add(new ESLVal("]")));
            }
            }
            }
          case "NullType": {ESLVal $2163 = _v961.termRef(0);
              
              {ESLVal l = $2163;
              
              return new ESLVal("Null");
            }
            }
          case "RecType": {ESLVal $2162 = _v961.termRef(0);
              ESLVal $2161 = _v961.termRef(1);
              ESLVal $2160 = _v961.termRef(2);
              
              {ESLVal l = $2162;
              
              {ESLVal n = $2161;
              
              {ESLVal _v1905 = $2160;
              
              return new ESLVal("rec ").add(n.add(new ESLVal(".").add(ppType.apply(_v1905,env))));
            }
            }
            }
            }
          case "RecordType": {ESLVal $2159 = _v961.termRef(0);
              ESLVal $2158 = _v961.termRef(1);
              
              {ESLVal l = $2159;
              
              {ESLVal fs = $2158;
              
              return new ESLVal("{").add(ppDecs.apply(fs,env).add(new ESLVal("}")));
            }
            }
            }
          case "SetType": {ESLVal $2157 = _v961.termRef(0);
              ESLVal $2156 = _v961.termRef(1);
              
              {ESLVal l = $2157;
              
              {ESLVal _v1904 = $2156;
              
              return new ESLVal("Set{").add(ppType.apply(_v1904,env).add(new ESLVal("}")));
            }
            }
            }
          case "StrType": {ESLVal $2155 = _v961.termRef(0);
              
              {ESLVal l = $2155;
              
              return new ESLVal("Str");
            }
            }
          case "TableType": {ESLVal $2154 = _v961.termRef(0);
              ESLVal $2153 = _v961.termRef(1);
              ESLVal $2152 = _v961.termRef(2);
              
              {ESLVal l = $2154;
              
              {ESLVal k = $2153;
              
              {ESLVal v = $2152;
              
              return new ESLVal("Hash[").add(ppType.apply(k,env).add(new ESLVal(",").add(ppType.apply(v,env).add(new ESLVal("]")))));
            }
            }
            }
            }
          case "TermType": {ESLVal $2151 = _v961.termRef(0);
              ESLVal $2150 = _v961.termRef(1);
              ESLVal $2149 = _v961.termRef(2);
              
              {ESLVal l = $2151;
              
              {ESLVal n = $2150;
              
              {ESLVal ts = $2149;
              
              return n.add(map.apply(ppType0.apply(env),ts));
            }
            }
            }
            }
          case "TypeFun": {ESLVal $2148 = _v961.termRef(0);
              ESLVal $2147 = _v961.termRef(1);
              ESLVal $2146 = _v961.termRef(2);
              
              {ESLVal l = $2148;
              
              {ESLVal ns = $2147;
              
              {ESLVal _v1903 = $2146;
              
              return new ESLVal("Fun").add(ns.add(new ESLVal(".").add(ppType.apply(_v1903,env))));
            }
            }
            }
            }
          case "UnfoldType": {ESLVal $2145 = _v961.termRef(0);
              ESLVal $2144 = _v961.termRef(1);
              
              {ESLVal l = $2145;
              
              {ESLVal _v1902 = $2144;
              
              return new ESLVal("unfold ").add(ppType.apply(_v1902,env));
            }
            }
            }
          case "UnionType": {ESLVal $2143 = _v961.termRef(0);
              ESLVal $2142 = _v961.termRef(1);
              
              {ESLVal l = $2143;
              
              {ESLVal ts = $2142;
              
              return new ESLVal("union ").add(map.apply(ppType0.apply(env),ts));
            }
            }
            }
          case "VarType": {ESLVal $2141 = _v961.termRef(0);
              ESLVal $2140 = _v961.termRef(1);
              
              {ESLVal l = $2141;
              
              {ESLVal n = $2140;
              
              return n;
            }
            }
            }
          case "VoidType": {ESLVal $2139 = _v961.termRef(0);
              
              {ESLVal l = $2139;
              
              return new ESLVal("Void");
            }
            }
          case "UnionRef": {ESLVal $2138 = _v961.termRef(0);
              ESLVal $2137 = _v961.termRef(1);
              ESLVal $2136 = _v961.termRef(2);
              
              {ESLVal l = $2138;
              
              {ESLVal _v1901 = $2137;
              
              {ESLVal n = $2136;
              
              return ppType.apply(_v1901,env).add(new ESLVal(".").add(n));
            }
            }
            }
            }
          case "TypeClosure": {ESLVal $2135 = _v961.termRef(0);
              
              {ESLVal f = $2135;
              
              return f.add(new ESLVal(""));
            }
            }
            default: {ESLVal x = _v961;
              
              return new ESLVal("<unknown ").add(x.add(new ESLVal(">")));
            }
          }
          }
    }
  });
  private static ESLVal typeEnv = new ESLVal(new Function(new ESLVal("typeEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal defs = $args[0];
  {ESLVal _v960 = defs;
        
        if(_v960.isCons())
        {ESLVal $2125 = _v960.head();
          ESLVal $2126 = _v960.tail();
          
          switch($2125.termName) {
          case "TypeBind": {ESLVal $2134 = $2125.termRef(0);
            ESLVal $2133 = $2125.termRef(1);
            ESLVal $2132 = $2125.termRef(2);
            ESLVal $2131 = $2125.termRef(3);
            
            {ESLVal l = $2134;
            
            {ESLVal n = $2133;
            
            {ESLVal t = $2132;
            
            {ESLVal e = $2131;
            
            {ESLVal ds = $2126;
            
            return typeEnv.apply(ds).cons(new ESLVal("Map",n,t));
          }
          }
          }
          }
          }
          }
        case "DataBind": {ESLVal $2130 = $2125.termRef(0);
            ESLVal $2129 = $2125.termRef(1);
            ESLVal $2128 = $2125.termRef(2);
            ESLVal $2127 = $2125.termRef(3);
            
            {ESLVal l = $2130;
            
            {ESLVal n = $2129;
            
            {ESLVal t = $2128;
            
            {ESLVal e = $2127;
            
            {ESLVal ds = $2126;
            
            return typeEnv.apply(ds).cons(new ESLVal("Map",n,t));
          }
          }
          }
          }
          }
          }
          default: {ESLVal b = $2125;
            
            {ESLVal ds = $2126;
            
            return typeEnv.apply(ds);
          }
          }
        }
        }
      else if(_v960.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(7713,7956)").add(ESLVal.list(_v960)));
      }
    }
  });
  private static ESLVal cnstrEnv = new ESLVal(new Function(new ESLVal("cnstrEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal defs = $args[0];
  ESLVal env = $args[1];
  {ESLVal _v959 = defs;
        
        if(_v959.isCons())
        {ESLVal $2108 = _v959.head();
          ESLVal $2109 = _v959.tail();
          
          switch($2108.termName) {
          case "TypeBind": {ESLVal $2117 = $2108.termRef(0);
            ESLVal $2116 = $2108.termRef(1);
            ESLVal $2115 = $2108.termRef(2);
            ESLVal $2114 = $2108.termRef(3);
            
            switch($2115.termName) {
            case "RecType": {ESLVal $2122 = $2115.termRef(0);
              ESLVal $2121 = $2115.termRef(1);
              ESLVal $2120 = $2115.termRef(2);
              
              switch($2120.termName) {
              case "UnionType": {ESLVal $2124 = $2120.termRef(0);
                ESLVal $2123 = $2120.termRef(1);
                
                {ESLVal l = $2117;
                
                {ESLVal n = $2116;
                
                {ESLVal ll = $2122;
                
                {ESLVal m = $2121;
                
                {ESLVal lll = $2124;
                
                {ESLVal ts = $2123;
                
                {ESLVal e = $2114;
                
                {ESLVal ds = $2109;
                
                return getConstructors.apply(l,lookupType.apply(n,env),lookupType.apply(n,env)).add(cnstrEnv.apply(ds,env));
              }
              }
              }
              }
              }
              }
              }
              }
              }
              default: {ESLVal l = $2117;
                
                {ESLVal n = $2116;
                
                {ESLVal t = $2115;
                
                {ESLVal e = $2114;
                
                {ESLVal ds = $2109;
                
                return cnstrEnv.apply(ds,env);
              }
              }
              }
              }
              }
            }
            }
          case "UnionType": {ESLVal $2119 = $2115.termRef(0);
              ESLVal $2118 = $2115.termRef(1);
              
              {ESLVal l = $2117;
              
              {ESLVal n = $2116;
              
              {ESLVal lll = $2119;
              
              {ESLVal ts = $2118;
              
              {ESLVal e = $2114;
              
              {ESLVal ds = $2109;
              
              return getConstructors.apply(l,lookupType.apply(n,env),lookupType.apply(n,env)).add(cnstrEnv.apply(ds,env));
            }
            }
            }
            }
            }
            }
            }
            default: {ESLVal l = $2117;
              
              {ESLVal n = $2116;
              
              {ESLVal t = $2115;
              
              {ESLVal e = $2114;
              
              {ESLVal ds = $2109;
              
              return cnstrEnv.apply(ds,env);
            }
            }
            }
            }
            }
          }
          }
        case "DataBind": {ESLVal $2113 = $2108.termRef(0);
            ESLVal $2112 = $2108.termRef(1);
            ESLVal $2111 = $2108.termRef(2);
            ESLVal $2110 = $2108.termRef(3);
            
            {ESLVal l = $2113;
            
            {ESLVal n = $2112;
            
            {ESLVal t = $2111;
            
            {ESLVal e = $2110;
            
            {ESLVal ds = $2109;
            
            return getConstructors.apply(l,lookupType.apply(n,env),lookupType.apply(n,env)).add(cnstrEnv.apply(ds,env));
          }
          }
          }
          }
          }
          }
          default: {ESLVal b = $2108;
            
            {ESLVal ds = $2109;
            
            return cnstrEnv.apply(ds,env);
          }
          }
        }
        }
      else if(_v959.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(8088,8721)").add(ESLVal.list(_v959)));
      }
    }
  });
  private static ESLVal getConstructors = new ESLVal(new Function(new ESLVal("getConstructors"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal dataType = $args[1];
  ESLVal t = $args[2];
  {ESLVal _v957 = t;
        
        switch(_v957.termName) {
        case "RecType": {ESLVal $2104 = _v957.termRef(0);
          ESLVal $2103 = _v957.termRef(1);
          ESLVal $2102 = _v957.termRef(2);
          
          {ESLVal _v1898 = $2104;
          
          {ESLVal n = $2103;
          
          {ESLVal _v1899 = $2102;
          
          return getConstructors.apply(_v1898,dataType,_v1899);
        }
        }
        }
        }
      case "TypeFun": {ESLVal $2101 = _v957.termRef(0);
          ESLVal $2100 = _v957.termRef(1);
          ESLVal $2099 = _v957.termRef(2);
          
          {ESLVal _v1896 = $2101;
          
          {ESLVal ns = $2100;
          
          {ESLVal _v1897 = $2099;
          
          return getConstructors.apply(_v1896,dataType,_v1897);
        }
        }
        }
        }
      case "UnionType": {ESLVal $2098 = _v957.termRef(0);
          ESLVal $2097 = _v957.termRef(1);
          
          {ESLVal _v1893 = $2098;
          
          {ESLVal ts = $2097;
          
          return map.apply(new ESLVal(new Function(new ESLVal("fun829"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1894 = $args[0];
          {ESLVal _v958 = _v1894;
                
                switch(_v958.termName) {
                case "TermType": {ESLVal $2107 = _v958.termRef(0);
                  ESLVal $2106 = _v958.termRef(1);
                  ESLVal $2105 = _v958.termRef(2);
                  
                  {ESLVal _v1895 = $2107;
                  
                  {ESLVal n = $2106;
                  
                  {ESLVal tts = $2105;
                  
                  return new ESLVal("Map",n,dataType);
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(9240,9306)").add(ESLVal.list(_v958)));
              }
              }
            }
          }),ts);
        }
        }
        }
        default: {ESLVal _v1900 = _v957;
          
          return error(new ESLVal("TypeError",l,new ESLVal("cannot extract constructors from ").add(ppType.apply(_v1900,ESLVal.list()))));
        }
      }
      }
    }
  });
  private static ESLVal checkFreeTypes = new ESLVal(new Function(new ESLVal("checkFreeTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  {ESLVal dom = typeEnvDom.apply(e);
        ESLVal ran = typeEnvRan.apply(e);
        
        {ESLVal freeNames = removeAll.apply(dom,flatten.apply(map.apply(typeFV,ran)));
        
        if(freeNames.eql($nil).boolVal)
        return $null;
        else
          return error(new ESLVal("TypeError",new ESLVal("Pos",$zero,$zero),new ESLVal("Unbound Types: ").add(freeNames)));
      }
      }
    }
  });
  private static ESLVal checkSingletonTypes = new ESLVal(new Function(new ESLVal("checkSingletonTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  {ESLVal _v956 = e;
        
        if(_v956.isCons())
        {ESLVal $2093 = _v956.head();
          ESLVal $2094 = _v956.tail();
          
          switch($2093.termName) {
          case "Map": {ESLVal $2096 = $2093.termRef(0);
            ESLVal $2095 = $2093.termRef(1);
            
            {ESLVal n = $2096;
            
            {ESLVal t = $2095;
            
            {ESLVal _v1892 = $2094;
            
            if(member.apply(n,typeEnvDom.apply(_v1892)).boolVal)
            return error(new ESLVal("TypeError",new ESLVal("Pos",$zero,$zero),new ESLVal("Duplicate type name: ").add(n)));
            else
              return checkSingletonTypes.apply(_v1892);
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(10010,10231)").add(ESLVal.list(_v956)));
        }
        }
      else if(_v956.isNil())
        return $null;
      else return error(new ESLVal("case error at Pos(10010,10231)").add(ESLVal.list(_v956)));
      }
    }
  });
  private static ESLVal checkSingletonConstructors = new ESLVal(new Function(new ESLVal("checkSingletonConstructors"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  {ESLVal _v955 = e;
        
        if(_v955.isCons())
        {ESLVal $2089 = _v955.head();
          ESLVal $2090 = _v955.tail();
          
          switch($2089.termName) {
          case "Map": {ESLVal $2092 = $2089.termRef(0);
            ESLVal $2091 = $2089.termRef(1);
            
            {ESLVal n = $2092;
            
            {ESLVal t = $2091;
            
            {ESLVal _v1891 = $2090;
            
            if(member.apply(n,typeEnvDom.apply(_v1891)).boolVal)
            return error(new ESLVal("Duplicate constructor name: ").add(n));
            else
              return checkSingletonConstructors.apply(_v1891);
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(10337,10552)").add(ESLVal.list(_v955)));
        }
        }
      else if(_v955.isNil())
        return $null;
      else return error(new ESLVal("case error at Pos(10337,10552)").add(ESLVal.list(_v955)));
      }
    }
  });
  private static ESLVal valueDefs = new ESLVal(new Function(new ESLVal("valueDefs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal defs = $args[0];
  {ESLVal _v954 = defs;
        
        if(_v954.isCons())
        {ESLVal $2075 = _v954.head();
          ESLVal $2076 = _v954.tail();
          
          switch($2075.termName) {
          case "TypeBind": {ESLVal $2088 = $2075.termRef(0);
            ESLVal $2087 = $2075.termRef(1);
            ESLVal $2086 = $2075.termRef(2);
            ESLVal $2085 = $2075.termRef(3);
            
            {ESLVal l = $2088;
            
            {ESLVal n = $2087;
            
            {ESLVal t = $2086;
            
            {ESLVal e = $2085;
            
            {ESLVal ds = $2076;
            
            return valueDefs.apply(ds);
          }
          }
          }
          }
          }
          }
        case "DataBind": {ESLVal $2084 = $2075.termRef(0);
            ESLVal $2083 = $2075.termRef(1);
            ESLVal $2082 = $2075.termRef(2);
            ESLVal $2081 = $2075.termRef(3);
            
            {ESLVal l1 = $2084;
            
            {ESLVal n = $2083;
            
            {ESLVal t = $2082;
            
            {ESLVal e = $2081;
            
            {ESLVal ds = $2076;
            
            return valueDefs.apply(ds);
          }
          }
          }
          }
          }
          }
        case "CnstrBind": {ESLVal $2080 = $2075.termRef(0);
            ESLVal $2079 = $2075.termRef(1);
            ESLVal $2078 = $2075.termRef(2);
            ESLVal $2077 = $2075.termRef(3);
            
            {ESLVal l1 = $2080;
            
            {ESLVal n = $2079;
            
            {ESLVal t = $2078;
            
            {ESLVal e = $2077;
            
            {ESLVal ds = $2076;
            
            return valueDefs.apply(ds);
          }
          }
          }
          }
          }
          }
          default: {ESLVal b = $2075;
            
            {ESLVal ds = $2076;
            
            return valueDefs.apply(ds).cons(b);
          }
          }
        }
        }
      else if(_v954.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(10593,10903)").add(ESLVal.list(_v954)));
      }
    }
  });
  private static ESLVal valueDefsToTEnv = new ESLVal(new Function(new ESLVal("valueDefsToTEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1890 = $args[0];
  ESLVal _v1889 = $args[1];
  ESLVal _v1888 = $args[2];
  ESLVal _v1887 = $args[3];
  ESLVal _v1886 = $args[4];
  {ESLVal _v953 = _v1890;
        
        if(_v953.isCons())
        {ESLVal $2052 = _v953.head();
          ESLVal $2053 = _v953.tail();
          
          switch($2052.termName) {
          case "FunBinds": {ESLVal $2067 = $2052.termRef(0);
            ESLVal $2066 = $2052.termRef(1);
            
            if($2066.isCons())
            {ESLVal $2068 = $2066.head();
              ESLVal $2069 = $2066.tail();
              
              switch($2068.termName) {
              case "FunCase": {ESLVal $2074 = $2068.termRef(0);
                ESLVal $2073 = $2068.termRef(1);
                ESLVal $2072 = $2068.termRef(2);
                ESLVal $2071 = $2068.termRef(3);
                ESLVal $2070 = $2068.termRef(4);
                
                {ESLVal n = $2067;
                
                {ESLVal l = $2074;
                
                {ESLVal args = $2073;
                
                {ESLVal t = $2072;
                
                {ESLVal g = $2071;
                
                {ESLVal e = $2070;
                
                {ESLVal cases = $2069;
                
                {ESLVal ds = $2053;
                
                return valueDefsToTEnv.apply(ds,_v1889,_v1888,_v1887,_v1886).cons(new ESLVal("Map",n,substTypeEnv.apply(_v1886,t)));
              }
              }
              }
              }
              }
              }
              }
              }
              }
              default: return error(new ESLVal("case error at Pos(11010,11543)").add(ESLVal.list(_v953)));
            }
            }
          else if($2066.isNil())
            return error(new ESLVal("case error at Pos(11010,11543)").add(ESLVal.list(_v953)));
          else return error(new ESLVal("case error at Pos(11010,11543)").add(ESLVal.list(_v953)));
          }
        case "FunBind": {ESLVal $2065 = $2052.termRef(0);
            ESLVal $2064 = $2052.termRef(1);
            ESLVal $2063 = $2052.termRef(2);
            ESLVal $2062 = $2052.termRef(3);
            ESLVal $2061 = $2052.termRef(4);
            ESLVal $2060 = $2052.termRef(5);
            ESLVal $2059 = $2052.termRef(6);
            
            {ESLVal l = $2065;
            
            {ESLVal n = $2064;
            
            {ESLVal ps = $2063;
            
            {ESLVal t = $2062;
            
            {ESLVal st = $2061;
            
            {ESLVal b = $2060;
            
            {ESLVal g = $2059;
            
            {ESLVal ds = $2053;
            
            return valueDefsToTEnv.apply(ds,_v1889,_v1888,_v1887,_v1886).cons(new ESLVal("Map",n,substTypeEnv.apply(_v1886,t)));
          }
          }
          }
          }
          }
          }
          }
          }
          }
        case "Binding": {ESLVal $2058 = $2052.termRef(0);
            ESLVal $2057 = $2052.termRef(1);
            ESLVal $2056 = $2052.termRef(2);
            ESLVal $2055 = $2052.termRef(3);
            ESLVal $2054 = $2052.termRef(4);
            
            {ESLVal l = $2058;
            
            {ESLVal n = $2057;
            
            {ESLVal t = $2056;
            
            {ESLVal st = $2055;
            
            {ESLVal e = $2054;
            
            {ESLVal ds = $2053;
            
            return valueDefsToTEnv.apply(ds,_v1889,_v1888,_v1887,_v1886).cons(new ESLVal("Map",n,substTypeEnv.apply(_v1886,t)));
          }
          }
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(11010,11543)").add(ESLVal.list(_v953)));
        }
        }
      else if(_v953.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(11010,11543)").add(ESLVal.list(_v953)));
      }
    }
  });
  public static ESLVal typeCheckModule = new ESLVal(new Function(new ESLVal("typeCheckModule"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal path = $args[0];
  {print.apply(new ESLVal("[ type check ").add(path.add(new ESLVal("]"))));
      return typeCheckModuleInternal.apply(path,emptyTable,new ESLVal(new Function(new ESLVal("fun830"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1885 = $args[0];
        ESLVal _v1884 = $args[1];
        ESLVal _v1883 = $args[2];
        ESLVal _v1882 = $args[3];
        return $null;
          }
        }));}
    }
  });
  private static ESLVal typeCheckModuleInternal = new ESLVal(new Function(new ESLVal("typeCheckModuleInternal"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal path = $args[0];
  ESLVal cache = $args[1];
  ESLVal handler = $args[2];
  if(hasEntry.apply(path,cache).boolVal)
        {ESLVal _v952 = lookup.apply(path,cache);
          
          switch(_v952.termName) {
          case "Typed": {ESLVal $2051 = _v952.termRef(0);
            ESLVal $2050 = _v952.termRef(1);
            ESLVal $2049 = _v952.termRef(2);
            ESLVal $2048 = _v952.termRef(3);
            
            {ESLVal m = $2051;
            
            {ESLVal vEnv = $2050;
            
            {ESLVal cEnv = $2049;
            
            {ESLVal tEnv = $2048;
            
            return handler.apply(cache,vEnv,cEnv,tEnv);
          }
          }
          }
          }
          }
        case "Undefined": {
            return error(new ESLVal("recursive reference to ").add(path));
          }
          default: return error(new ESLVal("case error at Pos(12012,12246)").add(ESLVal.list(_v952)));
        }
        }
        else
          {ESLVal m = parse.apply(path);
            
            return typeCheckModuleCache.apply(m,addEntry.apply(path,new ESLVal("Undefined",new ESLVal[]{}),cache),new ESLVal(new Function(new ESLVal("fun831"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v1881 = $args[0];
            ESLVal _v1880 = $args[1];
            ESLVal _v1879 = $args[2];
            ESLVal _v1878 = $args[3];
            return handler.apply(addEntry.apply(path,new ESLVal("Typed",m,_v1880,_v1879,_v1878),_v1881),_v1880,_v1879,_v1878);
              }
            }));
          }
    }
  });
  public static ESLVal typeCheckEntryPoint = new ESLVal(new Function(new ESLVal("typeCheckEntryPoint"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal module = $args[0];
  return typeCheckModuleCache.apply(module,emptyTable,new ESLVal(new Function(new ESLVal("fun832"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1877 = $args[0];
        ESLVal _v1876 = $args[1];
        ESLVal _v1875 = $args[2];
        ESLVal _v1874 = $args[3];
        return $null;
          }
        }));
    }
  });
  private static ESLVal typeCheckModuleCache = new ESLVal(new Function(new ESLVal("typeCheckModuleCache"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal module = $args[0];
  ESLVal cache = $args[1];
  ESLVal handler = $args[2];
  return typeCheckModule0.apply(module,cache,new ESLVal(new Function(new ESLVal("fun833"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1873 = $args[0];
        ESLVal _v1872 = $args[1];
        ESLVal _v1871 = $args[2];
        ESLVal _v1870 = $args[3];
        {ESLVal _v951 = module;
              
              switch(_v951.termName) {
              case "Module": {ESLVal $2047 = _v951.termRef(0);
                ESLVal $2046 = _v951.termRef(1);
                ESLVal $2045 = _v951.termRef(2);
                ESLVal $2044 = _v951.termRef(3);
                ESLVal $2043 = _v951.termRef(4);
                ESLVal $2042 = _v951.termRef(5);
                ESLVal $2041 = _v951.termRef(6);
                
                {ESLVal path = $2047;
                
                {ESLVal name = $2046;
                
                {ESLVal exports = $2045;
                
                {ESLVal imports = $2044;
                
                {ESLVal x = $2043;
                
                {ESLVal y = $2042;
                
                {ESLVal defs = $2041;
                
                return handler.apply(_v1873,restrictTypeEnv.apply(_v1872,exports),restrictTypeEnv.apply(_v1871,exports),restrictTypeEnv.apply(_v1870,exports));
              }
              }
              }
              }
              }
              }
              }
              }
              default: return error(new ESLVal("case error at Pos(12988,13246)").add(ESLVal.list(_v951)));
            }
            }
          }
        }));
    }
  });
  private static ESLVal typeCheckModule0 = new ESLVal(new Function(new ESLVal("typeCheckModule0"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal module = $args[0];
  ESLVal cache = $args[1];
  ESLVal handler = $args[2];
  LetRec letrec = new LetRec() {
        ESLVal _v1848 = new ESLVal(new Function(new ESLVal("processImports"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1859 = $args[0];
          ESLVal _v1858 = $args[1];
          ESLVal _v1857 = $args[2];
          {ESLVal _v950 = _v1859;
                
                if(_v950.isCons())
                {ESLVal $2039 = _v950.head();
                  ESLVal $2040 = _v950.tail();
                  
                  {ESLVal path = $2039;
                  
                  {ESLVal _v1860 = $2040;
                  
                  {ESLVal _v1861 = _v1860;
                  
                  return typeCheckModuleInternal.apply(path,_v1858,new ESLVal(new Function(new ESLVal("fun834"),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      ESLVal _v1865 = $args[0];
                  ESLVal _v1864 = $args[1];
                  ESLVal _v1863 = $args[2];
                  ESLVal _v1862 = $args[3];
                  return _v1848.apply(_v1861,_v1865,new ESLVal(new Function(new ESLVal("fun835"),getSelf()) {
                          public ESLVal apply(ESLVal... $args) {
                            ESLVal _v1869 = $args[0];
                        ESLVal _v1868 = $args[1];
                        ESLVal _v1867 = $args[2];
                        ESLVal _v1866 = $args[3];
                        return _v1857.apply(_v1869,_v1868.add(_v1864),_v1867.add(_v1863),_v1866.add(_v1862));
                          }
                        }));
                    }
                  }));
                }
                }
                }
                }
              else if(_v950.isNil())
                return _v1857.apply(_v1858,$nil,$nil,$nil);
              else return error(new ESLVal("case error at Pos(13626,14183)").add(ESLVal.list(_v950)));
              }
            }
          });
        ESLVal _v1847 = new ESLVal(new Function(new ESLVal("main"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              {ESLVal _v949 = module;
                
                switch(_v949.termName) {
                case "Module": {ESLVal $2038 = _v949.termRef(0);
                  ESLVal $2037 = _v949.termRef(1);
                  ESLVal $2036 = _v949.termRef(2);
                  ESLVal $2035 = _v949.termRef(3);
                  ESLVal $2034 = _v949.termRef(4);
                  ESLVal $2033 = _v949.termRef(5);
                  ESLVal $2032 = _v949.termRef(6);
                  
                  {ESLVal path = $2038;
                  
                  {ESLVal name = $2037;
                  
                  {ESLVal exports = $2036;
                  
                  {ESLVal imports = $2035;
                  
                  {ESLVal x = $2034;
                  
                  {ESLVal y = $2033;
                  
                  {ESLVal defs = $2032;
                  
                  return _v1848.apply(imports,cache,new ESLVal(new Function(new ESLVal("fun836"),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      ESLVal _v1852 = $args[0];
                  ESLVal _v1851 = $args[1];
                  ESLVal _v1850 = $args[2];
                  ESLVal _v1849 = $args[3];
                  {ESLVal _v1854 = typeEnv.apply(defs);
                        ESLVal _v1853 = mergeFunDefs.apply(defs);
                        
                        {checkDupBindings.apply(_v1853);
                      checkFreeTypes.apply(_v1854.add(_v1849.add(tenv0)));
                      checkSingletonTypes.apply(_v1854);
                      {ESLVal _v1855 = recTypes.apply(_v1854.add(_v1849.add(tenv0)));
                        
                        {ESLVal _v1856 = cnstrEnv.apply(_v1853,_v1855).add(_v1850.add(cnstrEnv0));
                        
                        {checkSingletonConstructors.apply(_v1856);
                      {ESLVal valueEnv = typeCheckValues.apply(valueDefs.apply(_v1853),new ESLVal("NullType",p0),_v1851,_v1855,_v1856);
                        
                        return handler.apply(_v1852,valueEnv,_v1856,_v1855);
                      }}
                      }
                      }}
                      }
                    }
                  }));
                }
                }
                }
                }
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(14212,15754)").add(ESLVal.list(_v949)));
              }
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "_v1848": return _v1848;
            
            case "_v1847": return _v1847;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal _v1848 = letrec.get("_v1848");
      
      ESLVal _v1847 = letrec.get("_v1847");
      
        return _v1847.apply();
      
    }
  });
  private static ESLVal typeCheckValues = new ESLVal(new Function(new ESLVal("typeCheckValues"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1846 = $args[0];
  ESLVal _v1845 = $args[1];
  ESLVal _v1844 = $args[2];
  ESLVal _v1843 = $args[3];
  ESLVal _v1842 = $args[4];
  {ESLVal valueEnv = valueDefsToTEnv.apply(_v1846,_v1845,$nil,_v1842,_v1843).add(_v1844.add(env0));
        
        {{
        ESLVal _v948 = _v1846;
        while(_v948.isCons()) {
          ESLVal def = _v948.headVal;
          typeCheckDef.apply(def,_v1845,valueEnv,valueEnv,_v1842,_v1843);
          _v948 = _v948.tailVal;}
      }
      return valueEnv;}
      }
    }
  });
  private static ESLVal genericize = new ESLVal(new Function(new ESLVal("genericize"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal t = $args[1];
  if(length.apply(typeFV.apply(t)).eql($zero).boolVal)
        return t;
        else
          return new ESLVal("ForallType",l,typeFV.apply(t),t);
    }
  });
  private static ESLVal checkPatterns = new ESLVal(new Function(new ESLVal("checkPatterns"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal ps = $args[1];
  {ESLVal names = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v946 = $qualArg;
                
                {ESLVal p = _v946;
                
                return ESLVal.list(new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal _v1841 = $args[0];
                {ESLVal _v947 = _v1841;
                      
                      {ESLVal n = _v947;
                      
                      return ESLVal.list(ESLVal.list(n));
                    }
                    }
                  }
                }).map(patternNames.apply(p)).flatten().flatten());
              }
              }
            }
          }).map(ps).flatten().flatten();
        
        if(removeDups.apply(names).neql(names).boolVal)
        return error(new ESLVal("TypeError",l,new ESLVal("duplicate pattern variables")));
        else
          return $null;
      }
    }
  });
  private static ESLVal typeCheckDef = new ESLVal(new Function(new ESLVal("typeCheckDef"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1822 = $args[0];
  ESLVal _v1821 = $args[1];
  ESLVal _v1820 = $args[2];
  ESLVal _v1819 = $args[3];
  ESLVal _v1818 = $args[4];
  ESLVal _v1817 = $args[5];
  {ESLVal _v938 = _v1822;
        
        switch(_v938.termName) {
        case "FunBinds": {ESLVal $2004 = _v938.termRef(0);
          ESLVal $2003 = _v938.termRef(1);
          
          {ESLVal n = $2004;
          
          {ESLVal cases = $2003;
          
          LetRec letrec = new LetRec() {
          ESLVal checkArities = new ESLVal(new Function(new ESLVal("checkArities"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v1839 = $args[0];
            ESLVal _v1838 = $args[1];
            {ESLVal _v945 = _v1839;
                  
                  if(_v945.isCons())
                  {ESLVal $2025 = _v945.head();
                    ESLVal $2026 = _v945.tail();
                    
                    switch($2025.termName) {
                    case "FunCase": {ESLVal $2031 = $2025.termRef(0);
                      ESLVal $2030 = $2025.termRef(1);
                      ESLVal $2029 = $2025.termRef(2);
                      ESLVal $2028 = $2025.termRef(3);
                      ESLVal $2027 = $2025.termRef(4);
                      
                      {ESLVal l = $2031;
                      
                      {ESLVal args = $2030;
                      
                      {ESLVal t = $2029;
                      
                      {ESLVal g = $2028;
                      
                      {ESLVal e = $2027;
                      
                      {ESLVal _v1840 = $2026;
                      
                      if(_v1838.eql(new ESLVal(-1)).or(length.apply(args).eql(_v1838)).boolVal)
                      return checkArities.apply(_v1840,length.apply(args));
                      else
                        return error(new ESLVal("TypeError",l,new ESLVal("inconsistent overloaded arity")));
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: return error(new ESLVal("case error at Pos(16961,17250)").add(ESLVal.list(_v945)));
                  }
                  }
                else if(_v945.isNil())
                  return $null;
                else return error(new ESLVal("case error at Pos(16961,17250)").add(ESLVal.list(_v945)));
                }
              }
            });
          ESLVal checkLoneVars = new ESLVal(new Function(new ESLVal("checkLoneVars"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v1836 = $args[0];
            {ESLVal _v943 = _v1836;
                  
                  if(_v943.isCons())
                  {ESLVal $2018 = _v943.head();
                    ESLVal $2019 = _v943.tail();
                    
                    switch($2018.termName) {
                    case "FunCase": {ESLVal $2024 = $2018.termRef(0);
                      ESLVal $2023 = $2018.termRef(1);
                      ESLVal $2022 = $2018.termRef(2);
                      ESLVal $2021 = $2018.termRef(3);
                      ESLVal $2020 = $2018.termRef(4);
                      
                      {ESLVal l = $2024;
                      
                      {ESLVal args = $2023;
                      
                      {ESLVal t = $2022;
                      
                      {ESLVal g = $2021;
                      
                      {ESLVal e = $2020;
                      
                      {ESLVal _v1837 = $2019;
                      
                      {{
                      ESLVal _v944 = args;
                      while(_v944.isCons()) {
                        ESLVal arg = _v944.headVal;
                        checkLoneVar.apply(arg);
                        _v944 = _v944.tailVal;}
                    }
                    return checkLoneVars.apply(_v1837);}
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: return error(new ESLVal("case error at Pos(17309,17544)").add(ESLVal.list(_v943)));
                  }
                  }
                else if(_v943.isNil())
                  return $null;
                else return error(new ESLVal("case error at Pos(17309,17544)").add(ESLVal.list(_v943)));
                }
              }
            });
          ESLVal checkLoneVar = new ESLVal(new Function(new ESLVal("checkLoneVar"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal p = $args[0];
            {ESLVal _v942 = p;
                  
                  switch(_v942.termName) {
                  case "PVar": {ESLVal $2016 = _v942.termRef(0);
                    ESLVal $2015 = _v942.termRef(1);
                    ESLVal $2014 = _v942.termRef(2);
                    
                    switch($2014.termName) {
                    case "VoidType": {ESLVal $2017 = $2014.termRef(0);
                      
                      {ESLVal l = $2016;
                      
                      {ESLVal _v1833 = $2015;
                      
                      {ESLVal tl = $2017;
                      
                      return error(new ESLVal("TypeError",l,new ESLVal("top level variables should be typed.")));
                    }
                    }
                    }
                    }
                    default: {ESLVal _v1834 = _v942;
                      
                      return $null;
                    }
                  }
                  }
                  default: {ESLVal _v1835 = _v942;
                    
                    return $null;
                  }
                }
                }
              }
            });
          
          public ESLVal get(String name) {
            switch(name) {
              case "checkArities": return checkArities;
              
              case "checkLoneVars": return checkLoneVars;
              
              case "checkLoneVar": return checkLoneVar;
              
              default: throw new Error("cannot find letrec binding");
            }
            }
          };
        ESLVal checkArities = letrec.get("checkArities");
        
        ESLVal checkLoneVars = letrec.get("checkLoneVars");
        
        ESLVal checkLoneVar = letrec.get("checkLoneVar");
        
          {checkArities.apply(cases,new ESLVal(-1));
        return checkLoneVars.apply(cases);}
        
        }
        }
        }
      case "FunBind": {ESLVal $2002 = _v938.termRef(0);
          ESLVal $2001 = _v938.termRef(1);
          ESLVal $2000 = _v938.termRef(2);
          ESLVal $1999 = _v938.termRef(3);
          ESLVal $1998 = _v938.termRef(4);
          ESLVal $1997 = _v938.termRef(5);
          ESLVal $1996 = _v938.termRef(6);
          
          {ESLVal l = $2002;
          
          {ESLVal n = $2001;
          
          {ESLVal ps = $2000;
          
          {ESLVal t = $1999;
          
          {ESLVal st = $1998;
          
          {ESLVal b = $1997;
          
          {ESLVal g = $1996;
          
          {checkPatterns.apply(l,ps);
        {ESLVal argTypes = map.apply(new ESLVal(new Function(new ESLVal("fun837"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal p = $args[0];
            {ESLVal _v940 = p;
                  
                  switch(_v940.termName) {
                  case "PVar": {ESLVal $2010 = _v940.termRef(0);
                    ESLVal $2009 = _v940.termRef(1);
                    ESLVal $2008 = _v940.termRef(2);
                    
                    {ESLVal _v1827 = $2010;
                    
                    {ESLVal _v1828 = $2009;
                    
                    {ESLVal _v1829 = $2008;
                    
                    return substTypeEnv.apply(_v1817,_v1829);
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(18176,18242)").add(ESLVal.list(_v940)));
                }
                }
              }
            }),ps);
          ESLVal argNames = map.apply(new ESLVal(new Function(new ESLVal("fun838"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal p = $args[0];
            {ESLVal _v939 = p;
                  
                  switch(_v939.termName) {
                  case "PVar": {ESLVal $2007 = _v939.termRef(0);
                    ESLVal $2006 = _v939.termRef(1);
                    ESLVal $2005 = _v939.termRef(2);
                    
                    {ESLVal _v1824 = $2007;
                    
                    {ESLVal _v1825 = $2006;
                    
                    {ESLVal _v1826 = $2005;
                    
                    return _v1825;
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(18314,18358)").add(ESLVal.list(_v939)));
                }
                }
              }
            }),ps);
          
          {ESLVal bodyType = guardedExpType.apply(l,g,b,_v1821,zipTypeEnv.apply(argNames,argTypes).add(_v1820),_v1818,_v1817);
          
          {ESLVal fType = ((Supplier<ESLVal>)() -> { 
              {ESLVal _v941 = t;
                
                switch(_v941.termName) {
                case "ForallType": {ESLVal $2013 = _v941.termRef(0);
                  ESLVal $2012 = _v941.termRef(1);
                  ESLVal $2011 = _v941.termRef(2);
                  
                  {ESLVal _v1830 = $2013;
                  
                  {ESLVal ns = $2012;
                  
                  {ESLVal _v1831 = $2011;
                  
                  return genericize.apply(_v1830,new ESLVal("FunType",_v1830,argTypes,bodyType));
                }
                }
                }
                }
                default: {ESLVal _v1832 = _v941;
                  
                  return new ESLVal("FunType",l,argTypes,bodyType);
                }
              }
              }
            }).get();
          ESLVal dType = substTypeEnv.apply(_v1817,t);
          
          if(subType.apply(fType,dType).boolVal)
          return $null;
          else
            return error(new ESLVal("TypeError",l,new ESLVal("type of ").add(n.add(new ESLVal("::").add(ppType.apply(fType,_v1817).add(new ESLVal(" does not match declaration ").add(ppType.apply(dType,_v1817))))))));
        }
        }
        }}
        }
        }
        }
        }
        }
        }
        }
        }
      case "Binding": {ESLVal $1995 = _v938.termRef(0);
          ESLVal $1994 = _v938.termRef(1);
          ESLVal $1993 = _v938.termRef(2);
          ESLVal $1992 = _v938.termRef(3);
          ESLVal $1991 = _v938.termRef(4);
          
          {ESLVal l = $1995;
          
          {ESLVal n = $1994;
          
          {ESLVal dt = $1993;
          
          {ESLVal st = $1992;
          
          {ESLVal e = $1991;
          
          {ESLVal valueType = expType.apply(e,_v1821,_v1820,_v1818,_v1817);
          
          {ESLVal valueFV = typeFV.apply(valueType);
          ESLVal declaredType = lookupType.apply(n,_v1819);
          
          {ESLVal _v1823 = ((Supplier<ESLVal>)() -> { 
              if(valueFV.eql($nil).boolVal)
                return valueType;
                else
                  return new ESLVal("ForallType",l,valueFV,valueType);
            }).get();
          
          if(subType.apply(_v1823,declaredType).boolVal)
          return $null;
          else
            return error(new ESLVal("TypeError",l,new ESLVal("type of ").add(n.add(new ESLVal(" ").add(ppType.apply(_v1823,_v1817).add(new ESLVal(" does not match declared type = ").add(ppType.apply(declaredType,_v1817))))))));
        }
        }
        }
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(16842,19765)").add(ESLVal.list(_v938)));
      }
      }
    }
  });
  private static ESLVal guardedExpType = new ESLVal(new Function(new ESLVal("guardedExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1816 = $args[0];
  ESLVal _v1815 = $args[1];
  ESLVal _v1814 = $args[2];
  ESLVal _v1813 = $args[3];
  ESLVal _v1812 = $args[4];
  ESLVal _v1811 = $args[5];
  ESLVal _v1810 = $args[6];
  {ESLVal bt = expType.apply(_v1815,_v1813,_v1812,_v1811,_v1810);
        
        if(isBoolType.apply(bt).boolVal)
        return expType.apply(_v1814,_v1813,_v1812,_v1811,_v1810);
        else
          return error(new ESLVal("TypeError",_v1816,new ESLVal("guarded expression requires a boolean value: ").add(ppType.apply(bt,_v1810))));
      }
    }
  });
  private static ESLVal expType = new ESLVal(new Function(new ESLVal("expType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1792 = $args[0];
  ESLVal _v1791 = $args[1];
  ESLVal _v1790 = $args[2];
  ESLVal _v1789 = $args[3];
  ESLVal _v1788 = $args[4];
  {ESLVal _v936 = _v1792;
        
        switch(_v936.termName) {
        case "ActExp": {ESLVal $1990 = _v936.termRef(0);
          ESLVal $1989 = _v936.termRef(1);
          ESLVal $1988 = _v936.termRef(2);
          ESLVal $1987 = _v936.termRef(3);
          ESLVal $1986 = _v936.termRef(4);
          ESLVal $1985 = _v936.termRef(5);
          ESLVal $1984 = _v936.termRef(6);
          ESLVal $1983 = _v936.termRef(7);
          
          {ESLVal l = $1990;
          
          {ESLVal n = $1989;
          
          {ESLVal args = $1988;
          
          {ESLVal exports = $1987;
          
          {ESLVal parent = $1986;
          
          {ESLVal bindings = $1985;
          
          {ESLVal init = $1984;
          
          {ESLVal arms = $1983;
          
          return actType.apply(l,n,args,parent,exports,bindings,init,arms,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
        }
        }
        }
        }
        }
        }
      case "Apply": {ESLVal $1982 = _v936.termRef(0);
          ESLVal $1981 = _v936.termRef(1);
          ESLVal $1980 = _v936.termRef(2);
          
          {ESLVal l = $1982;
          
          {ESLVal op = $1981;
          
          {ESLVal args = $1980;
          
          return applyType.apply(l,op,args,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
        }
      case "ApplyTypeExp": {ESLVal $1979 = _v936.termRef(0);
          ESLVal $1978 = _v936.termRef(1);
          ESLVal $1977 = _v936.termRef(2);
          
          {ESLVal l = $1979;
          
          {ESLVal _v1809 = $1978;
          
          {ESLVal ts = $1977;
          
          return applyTypeExp.apply(l,_v1809,ts,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
        }
      case "ArrayUpdate": {ESLVal $1976 = _v936.termRef(0);
          ESLVal $1975 = _v936.termRef(1);
          ESLVal $1974 = _v936.termRef(2);
          ESLVal $1973 = _v936.termRef(3);
          
          {ESLVal l = $1976;
          
          {ESLVal a = $1975;
          
          {ESLVal i = $1974;
          
          {ESLVal v = $1973;
          
          return arrayUpdateType.apply(l,a,i,v,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
        }
        }
      case "ArrayRef": {ESLVal $1972 = _v936.termRef(0);
          ESLVal $1971 = _v936.termRef(1);
          ESLVal $1970 = _v936.termRef(2);
          
          {ESLVal l = $1972;
          
          {ESLVal a = $1971;
          
          {ESLVal i = $1970;
          
          return arrayRefType.apply(l,a,i,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
        }
      case "BagExp": {ESLVal $1969 = _v936.termRef(0);
          ESLVal $1968 = _v936.termRef(1);
          
          {ESLVal l = $1969;
          
          {ESLVal es = $1968;
          
          return bagType.apply(l,es,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
      case "Become": {ESLVal $1967 = _v936.termRef(0);
          ESLVal $1966 = _v936.termRef(1);
          
          {ESLVal l = $1967;
          
          {ESLVal _v1808 = $1966;
          
          return becomeType.apply(l,_v1808,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
      case "BinExp": {ESLVal $1965 = _v936.termRef(0);
          ESLVal $1964 = _v936.termRef(1);
          ESLVal $1963 = _v936.termRef(2);
          ESLVal $1962 = _v936.termRef(3);
          
          {ESLVal l = $1965;
          
          {ESLVal e1 = $1964;
          
          {ESLVal op = $1963;
          
          {ESLVal e2 = $1962;
          
          return binExpType.apply(l,e1,op,e2,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
        }
        }
      case "Block": {ESLVal $1961 = _v936.termRef(0);
          ESLVal $1960 = _v936.termRef(1);
          
          {ESLVal l = $1961;
          
          {ESLVal es = $1960;
          
          return blockType.apply(l,es,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
      case "BoolExp": {ESLVal $1959 = _v936.termRef(0);
          ESLVal $1958 = _v936.termRef(1);
          
          {ESLVal l = $1959;
          
          {ESLVal b = $1958;
          
          return new ESLVal("BoolType",l);
        }
        }
        }
      case "Case": {ESLVal $1957 = _v936.termRef(0);
          ESLVal $1956 = _v936.termRef(1);
          ESLVal $1955 = _v936.termRef(2);
          ESLVal $1954 = _v936.termRef(3);
          
          {ESLVal l = $1957;
          
          {ESLVal decs = $1956;
          
          {ESLVal es = $1955;
          
          {ESLVal arms = $1954;
          
          return caseType.apply(l,es,arms,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
        }
        }
      case "Cmp": {ESLVal $1953 = _v936.termRef(0);
          ESLVal $1952 = _v936.termRef(1);
          ESLVal $1951 = _v936.termRef(2);
          
          {ESLVal l = $1953;
          
          {ESLVal _v1807 = $1952;
          
          {ESLVal qs = $1951;
          
          return cmpType.apply(l,_v1807,qs,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
        }
      case "Grab": {ESLVal $1950 = _v936.termRef(0);
          ESLVal $1949 = _v936.termRef(1);
          ESLVal $1948 = _v936.termRef(2);
          
          {ESLVal l = $1950;
          
          {ESLVal refs = $1949;
          
          {ESLVal _v1806 = $1948;
          
          return expType.apply(_v1806,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
        }
      case "FloatExp": {ESLVal $1947 = _v936.termRef(0);
          ESLVal $1946 = _v936.termRef(1);
          
          {ESLVal l = $1947;
          
          {ESLVal f = $1946;
          
          return new ESLVal("FloatType",l);
        }
        }
        }
      case "Fold": {ESLVal $1945 = _v936.termRef(0);
          ESLVal $1944 = _v936.termRef(1);
          ESLVal $1943 = _v936.termRef(2);
          
          {ESLVal l = $1945;
          
          {ESLVal t = $1944;
          
          {ESLVal _v1805 = $1943;
          
          return foldType.apply(l,t,_v1805,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
        }
      case "For": {ESLVal $1942 = _v936.termRef(0);
          ESLVal $1941 = _v936.termRef(1);
          ESLVal $1940 = _v936.termRef(2);
          ESLVal $1939 = _v936.termRef(3);
          
          {ESLVal l = $1942;
          
          {ESLVal p = $1941;
          
          {ESLVal list = $1940;
          
          {ESLVal _v1804 = $1939;
          
          return forType.apply(l,p,list,_v1804,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
        }
        }
      case "FunExp": {ESLVal $1938 = _v936.termRef(0);
          ESLVal $1937 = _v936.termRef(1);
          ESLVal $1936 = _v936.termRef(2);
          ESLVal $1935 = _v936.termRef(3);
          ESLVal $1934 = _v936.termRef(4);
          
          {ESLVal l = $1938;
          
          {ESLVal n = $1937;
          
          {ESLVal args = $1936;
          
          {ESLVal t = $1935;
          
          {ESLVal _v1803 = $1934;
          
          return funType.apply(l,n,args,t,_v1803,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
        }
        }
        }
      case "If": {ESLVal $1933 = _v936.termRef(0);
          ESLVal $1932 = _v936.termRef(1);
          ESLVal $1931 = _v936.termRef(2);
          ESLVal $1930 = _v936.termRef(3);
          
          {ESLVal l = $1933;
          
          {ESLVal e1 = $1932;
          
          {ESLVal e2 = $1931;
          
          {ESLVal e3 = $1930;
          
          return ifType.apply(l,e1,e2,e3,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
        }
        }
      case "IntExp": {ESLVal $1929 = _v936.termRef(0);
          ESLVal $1928 = _v936.termRef(1);
          
          {ESLVal l = $1929;
          
          {ESLVal n = $1928;
          
          return new ESLVal("IntType",l);
        }
        }
        }
      case "Let": {ESLVal $1927 = _v936.termRef(0);
          ESLVal $1926 = _v936.termRef(1);
          ESLVal $1925 = _v936.termRef(2);
          
          {ESLVal l = $1927;
          
          {ESLVal bs = $1926;
          
          {ESLVal _v1802 = $1925;
          
          return letType.apply(l,bs,_v1802,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
        }
      case "Letrec": {ESLVal $1924 = _v936.termRef(0);
          ESLVal $1923 = _v936.termRef(1);
          ESLVal $1922 = _v936.termRef(2);
          
          {ESLVal l = $1924;
          
          {ESLVal bs = $1923;
          
          {ESLVal _v1801 = $1922;
          
          return letrecType.apply(l,bs,_v1801,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
        }
      case "List": {ESLVal $1921 = _v936.termRef(0);
          ESLVal $1920 = _v936.termRef(1);
          
          {ESLVal l = $1921;
          
          {ESLVal es = $1920;
          
          return listType.apply(l,es,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
      case "Now": {ESLVal $1919 = _v936.termRef(0);
          
          {ESLVal l = $1919;
          
          return new ESLVal("IntType",l);
        }
        }
      case "Probably": {ESLVal $1918 = _v936.termRef(0);
          ESLVal $1917 = _v936.termRef(1);
          ESLVal $1916 = _v936.termRef(2);
          ESLVal $1915 = _v936.termRef(3);
          ESLVal $1914 = _v936.termRef(4);
          
          {ESLVal l = $1918;
          
          {ESLVal p = $1917;
          
          {ESLVal t = $1916;
          
          {ESLVal e1 = $1915;
          
          {ESLVal e2 = $1914;
          
          return probablyType.apply(l,p,t,e1,e2,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
        }
        }
        }
      case "PLet": {ESLVal $1913 = _v936.termRef(0);
          ESLVal $1912 = _v936.termRef(1);
          ESLVal $1911 = _v936.termRef(2);
          
          {ESLVal l = $1913;
          
          {ESLVal bs = $1912;
          
          {ESLVal _v1800 = $1911;
          
          return letType.apply(l,bs,_v1800,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
        }
      case "Record": {ESLVal $1910 = _v936.termRef(0);
          ESLVal $1909 = _v936.termRef(1);
          
          {ESLVal l = $1910;
          
          {ESLVal fields = $1909;
          
          return recordType.apply(l,fields,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
      case "Ref": {ESLVal $1908 = _v936.termRef(0);
          ESLVal $1907 = _v936.termRef(1);
          ESLVal $1906 = _v936.termRef(2);
          
          {ESLVal l = $1908;
          
          {ESLVal _v1799 = $1907;
          
          {ESLVal n = $1906;
          
          return refType.apply(l,_v1799,n,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
        }
      case "RefSuper": {ESLVal $1905 = _v936.termRef(0);
          ESLVal $1904 = _v936.termRef(1);
          
          {ESLVal l = $1905;
          
          {ESLVal n = $1904;
          
          return refType.apply(l,new ESLVal("Var",l,new ESLVal("$super")),n,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
      case "Self": {ESLVal $1903 = _v936.termRef(0);
          
          {ESLVal l = $1903;
          
          return _v1791;
        }
        }
      case "Send": {ESLVal $1898 = _v936.termRef(0);
          ESLVal $1897 = _v936.termRef(1);
          ESLVal $1896 = _v936.termRef(2);
          
          switch($1896.termName) {
          case "Term": {ESLVal $1902 = $1896.termRef(0);
            ESLVal $1901 = $1896.termRef(1);
            ESLVal $1900 = $1896.termRef(2);
            ESLVal $1899 = $1896.termRef(3);
            
            {ESLVal l = $1898;
            
            {ESLVal target = $1897;
            
            {ESLVal tl = $1902;
            
            {ESLVal n = $1901;
            
            {ESLVal ts = $1900;
            
            {ESLVal args = $1899;
            
            return sendType.apply(l,target,n,args,_v1791,_v1790,_v1789,_v1788);
          }
          }
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(20243,24296)").add(ESLVal.list(_v936)));
        }
        }
      case "SendTimeSuper": {ESLVal $1895 = _v936.termRef(0);
          
          {ESLVal l = $1895;
          
          return new ESLVal("VoidType",l);
        }
        }
      case "SendSuper": {ESLVal $1894 = _v936.termRef(0);
          ESLVal $1893 = _v936.termRef(1);
          
          {ESLVal l = $1894;
          
          {ESLVal _v1798 = $1893;
          
          return new ESLVal("VoidType",l);
        }
        }
        }
      case "SetExp": {ESLVal $1892 = _v936.termRef(0);
          ESLVal $1891 = _v936.termRef(1);
          
          {ESLVal l = $1892;
          
          {ESLVal es = $1891;
          
          return setType.apply(l,es,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
      case "StrExp": {ESLVal $1890 = _v936.termRef(0);
          ESLVal $1889 = _v936.termRef(1);
          
          {ESLVal l = $1890;
          
          {ESLVal s = $1889;
          
          return new ESLVal("StrType",l);
        }
        }
        }
      case "Term": {ESLVal $1888 = _v936.termRef(0);
          ESLVal $1887 = _v936.termRef(1);
          ESLVal $1886 = _v936.termRef(2);
          ESLVal $1885 = _v936.termRef(3);
          
          {ESLVal l = $1888;
          
          {ESLVal n = $1887;
          
          {ESLVal ts = $1886;
          
          {ESLVal es = $1885;
          
          return termType.apply(l,n,ts,es,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
        }
        }
      case "Throw": {ESLVal $1884 = _v936.termRef(0);
          ESLVal $1883 = _v936.termRef(1);
          ESLVal $1882 = _v936.termRef(2);
          
          {ESLVal l = $1884;
          
          {ESLVal t = $1883;
          
          {ESLVal _v1797 = $1882;
          
          return throwType.apply(l,t,_v1797,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
        }
      case "Try": {ESLVal $1881 = _v936.termRef(0);
          ESLVal $1880 = _v936.termRef(1);
          ESLVal $1879 = _v936.termRef(2);
          
          {ESLVal l = $1881;
          
          {ESLVal _v1796 = $1880;
          
          {ESLVal arms = $1879;
          
          return tryType.apply(l,_v1796,arms,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
        }
      case "New": {ESLVal $1878 = _v936.termRef(0);
          ESLVal $1877 = _v936.termRef(1);
          ESLVal $1876 = _v936.termRef(2);
          
          {ESLVal l = $1878;
          
          {ESLVal b = $1877;
          
          {ESLVal args = $1876;
          
          return newType.apply(l,b,args,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
        }
      case "NewArray": {ESLVal $1875 = _v936.termRef(0);
          ESLVal $1874 = _v936.termRef(1);
          ESLVal $1873 = _v936.termRef(2);
          
          {ESLVal l = $1875;
          
          {ESLVal t = $1874;
          
          {ESLVal i = $1873;
          
          return newArrayType.apply(l,t,i,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
        }
      case "NewTable": {ESLVal $1872 = _v936.termRef(0);
          ESLVal $1871 = _v936.termRef(1);
          ESLVal $1870 = _v936.termRef(2);
          
          {ESLVal l = $1872;
          
          {ESLVal key = $1871;
          
          {ESLVal value = $1870;
          
          return new ESLVal("TableType",l,substTypeEnv.apply(_v1788,key),substTypeEnv.apply(_v1788,value));
        }
        }
        }
        }
      case "NewJava": {ESLVal $1869 = _v936.termRef(0);
          ESLVal $1868 = _v936.termRef(1);
          ESLVal $1867 = _v936.termRef(2);
          ESLVal $1866 = _v936.termRef(3);
          
          {ESLVal l = $1869;
          
          {ESLVal path = $1868;
          
          {ESLVal t = $1867;
          
          {ESLVal args = $1866;
          
          {{
          ESLVal _v937 = args;
          while(_v937.isCons()) {
            ESLVal a = _v937.headVal;
            expType.apply(a,_v1791,_v1790,_v1789,_v1788);
            _v937 = _v937.tailVal;}
        }
        return substTypeEnv.apply(_v1788,t);}
        }
        }
        }
        }
        }
      case "Not": {ESLVal $1865 = _v936.termRef(0);
          ESLVal $1864 = _v936.termRef(1);
          
          {ESLVal l = $1865;
          
          {ESLVal _v1795 = $1864;
          
          return notType.apply(l,_v1795,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
      case "NullExp": {ESLVal $1863 = _v936.termRef(0);
          
          {ESLVal l = $1863;
          
          return new ESLVal("ForallType",l,ESLVal.list(new ESLVal("T")),new ESLVal("VarType",l,new ESLVal("T")));
        }
        }
      case "Unfold": {ESLVal $1862 = _v936.termRef(0);
          ESLVal $1861 = _v936.termRef(1);
          ESLVal $1860 = _v936.termRef(2);
          
          {ESLVal l = $1862;
          
          {ESLVal t = $1861;
          
          {ESLVal _v1794 = $1860;
          
          return unfoldTypeExp.apply(l,t,_v1794,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
        }
      case "Update": {ESLVal $1859 = _v936.termRef(0);
          ESLVal $1858 = _v936.termRef(1);
          ESLVal $1857 = _v936.termRef(2);
          
          {ESLVal l = $1859;
          
          {ESLVal n = $1858;
          
          {ESLVal _v1793 = $1857;
          
          return updateType.apply(l,n,_v1793,_v1791,_v1790,_v1789,_v1788);
        }
        }
        }
        }
      case "Var": {ESLVal $1856 = _v936.termRef(0);
          ESLVal $1855 = _v936.termRef(1);
          
          {ESLVal l = $1856;
          
          {ESLVal n = $1855;
          
          return varType.apply(l,n,_v1790);
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(20243,24296)").add(ESLVal.list(_v936)));
      }
      }
    }
  });
  private static ESLVal throwType = new ESLVal(new Function(new ESLVal("throwType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1787 = $args[0];
  ESLVal _v1786 = $args[1];
  ESLVal _v1785 = $args[2];
  ESLVal _v1784 = $args[3];
  ESLVal _v1783 = $args[4];
  ESLVal _v1782 = $args[5];
  ESLVal _v1781 = $args[6];
  {ESLVal valType = expType.apply(_v1785,_v1784,_v1783,_v1782,_v1781);
        
        return substTypeEnv.apply(_v1781,_v1786);
      }
    }
  });
  private static ESLVal foldType = new ESLVal(new Function(new ESLVal("foldType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1780 = $args[0];
  ESLVal _v1779 = $args[1];
  ESLVal _v1778 = $args[2];
  ESLVal _v1777 = $args[3];
  ESLVal _v1776 = $args[4];
  ESLVal _v1775 = $args[5];
  ESLVal _v1774 = $args[6];
  {ESLVal eType = expType.apply(_v1778,_v1777,_v1776,_v1775,_v1774);
        
        if(typeEqual.apply(substTypeEnv.apply(_v1774,_v1779),eType).boolVal)
        return eType;
        else
          return error(new ESLVal("TypeError",_v1780,new ESLVal("fold type ").add(ppType.apply(_v1779,_v1774).add(new ESLVal(" does not equal ").add(ppType.apply(eType,_v1774))))));
      }
    }
  });
  private static ESLVal unfoldTypeExp = new ESLVal(new Function(new ESLVal("unfoldTypeExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1771 = $args[0];
  ESLVal _v1770 = $args[1];
  ESLVal _v1769 = $args[2];
  ESLVal _v1768 = $args[3];
  ESLVal _v1767 = $args[4];
  ESLVal _v1766 = $args[5];
  ESLVal _v1765 = $args[6];
  {ESLVal eType = expType.apply(_v1769,_v1768,_v1767,_v1766,_v1765);
        ESLVal recType = substTypeEnv.apply(_v1765,_v1770);
        
        {ESLVal _v935 = recType;
        
        switch(_v935.termName) {
        case "RecType": {ESLVal $1854 = _v935.termRef(0);
          ESLVal $1853 = _v935.termRef(1);
          ESLVal $1852 = _v935.termRef(2);
          
          {ESLVal rl = $1854;
          
          {ESLVal n = $1853;
          
          {ESLVal _v1772 = $1852;
          
          if(typeEqual.apply(substType.apply(eType,n,_v1772),eType).boolVal)
          return eType;
          else
            return error(new ESLVal("TypeError",_v1771,new ESLVal("unfold type ").add(ppType.apply(substType.apply(eType,n,_v1772),_v1765).add(new ESLVal(" does not equal ").add(ppType.apply(eType,_v1765))))));
        }
        }
        }
        }
        default: {ESLVal _v1773 = _v935;
          
          return error(new ESLVal("TypeError",_v1771,new ESLVal("unfold type expects a rec type").add(ppType.apply(recType,_v1765))));
        }
      }
      }
      }
    }
  });
  private static ESLVal arrayUpdateType = new ESLVal(new Function(new ESLVal("arrayUpdateType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1764 = $args[0];
  ESLVal _v1763 = $args[1];
  ESLVal _v1762 = $args[2];
  ESLVal _v1761 = $args[3];
  ESLVal _v1760 = $args[4];
  ESLVal _v1759 = $args[5];
  ESLVal _v1758 = $args[6];
  ESLVal _v1757 = $args[7];
  {ESLVal aType = expType.apply(_v1763,_v1760,_v1759,_v1758,_v1757);
        ESLVal iType = expType.apply(_v1762,_v1760,_v1759,_v1758,_v1757);
        ESLVal vType = expType.apply(_v1761,_v1760,_v1759,_v1758,_v1757);
        
        {ESLVal _v934 = aType;
        
        switch(_v934.termName) {
        case "ArrayType": {ESLVal $1851 = _v934.termRef(0);
          ESLVal $1850 = _v934.termRef(1);
          
          {ESLVal al = $1851;
          
          {ESLVal t = $1850;
          
          if(isIntType.apply(iType).boolVal)
          if(typeEqual.apply(vType,t).boolVal)
            return aType;
            else
              return error(new ESLVal("TypeError",_v1764,new ESLVal("value type ").add(vType.add(new ESLVal(" does not match array type ").add(t)))));
          else
            return error(new ESLVal("TypeError",_v1764,new ESLVal("array index should be an integer ").add(_v1762)));
        }
        }
        }
        default: {ESLVal t = _v934;
          
          return error(new ESLVal("TypeError",_v1764,new ESLVal("expecting an array ").add(aType)));
        }
      }
      }
      }
    }
  });
  private static ESLVal arrayRefType = new ESLVal(new Function(new ESLVal("arrayRefType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1756 = $args[0];
  ESLVal _v1755 = $args[1];
  ESLVal _v1754 = $args[2];
  ESLVal _v1753 = $args[3];
  ESLVal _v1752 = $args[4];
  ESLVal _v1751 = $args[5];
  ESLVal _v1750 = $args[6];
  {ESLVal aType = expType.apply(_v1755,_v1753,_v1752,_v1751,_v1750);
        ESLVal iType = expType.apply(_v1754,_v1753,_v1752,_v1751,_v1750);
        
        {ESLVal _v933 = aType;
        
        switch(_v933.termName) {
        case "ArrayType": {ESLVal $1849 = _v933.termRef(0);
          ESLVal $1848 = _v933.termRef(1);
          
          {ESLVal al = $1849;
          
          {ESLVal t = $1848;
          
          if(isIntType.apply(iType).boolVal)
          return t;
          else
            return error(new ESLVal("TypeError",_v1756,new ESLVal("array index should be an integer ").add(_v1754)));
        }
        }
        }
        default: {ESLVal t = _v933;
          
          return error(new ESLVal("TypeError",_v1756,new ESLVal("expecting an array ").add(aType)));
        }
      }
      }
      }
    }
  });
  private static ESLVal newArrayType = new ESLVal(new Function(new ESLVal("newArrayType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1749 = $args[0];
  ESLVal _v1748 = $args[1];
  ESLVal _v1747 = $args[2];
  ESLVal _v1746 = $args[3];
  ESLVal _v1745 = $args[4];
  ESLVal _v1744 = $args[5];
  ESLVal _v1743 = $args[6];
  {ESLVal i = expType.apply(_v1747,_v1746,_v1745,_v1744,_v1743);
        
        if(isIntType.apply(i).boolVal)
        return new ESLVal("ArrayType",_v1749,substTypeEnv.apply(_v1743,_v1748));
        else
          return error(new ESLVal("TypeError",_v1749,new ESLVal("expecting an integer type: ").add(i)));
      }
    }
  });
  private static ESLVal becomeType = new ESLVal(new Function(new ESLVal("becomeType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1742 = $args[0];
  ESLVal _v1741 = $args[1];
  ESLVal _v1740 = $args[2];
  ESLVal _v1739 = $args[3];
  ESLVal _v1738 = $args[4];
  ESLVal _v1737 = $args[5];
  {ESLVal bType = expType.apply(_v1741,_v1740,_v1739,_v1738,_v1737);
        
        if(typeEqual.apply(bType,_v1740).boolVal)
        return bType;
        else
          return error(new ESLVal("TypeError",_v1742,new ESLVal("expecting become to match self type: ").add(ppType.apply(bType,_v1737).add(new ESLVal(" ").add(ppType.apply(_v1740,_v1737))))));
      }
    }
  });
  private static ESLVal probablyType = new ESLVal(new Function(new ESLVal("probablyType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1733 = $args[0];
  ESLVal _v1732 = $args[1];
  ESLVal _v1731 = $args[2];
  ESLVal _v1730 = $args[3];
  ESLVal _v1729 = $args[4];
  ESLVal _v1728 = $args[5];
  ESLVal _v1727 = $args[6];
  ESLVal _v1726 = $args[7];
  ESLVal _v1725 = $args[8];
  {ESLVal pt = expType.apply(_v1732,_v1728,_v1727,_v1726,_v1725);
        
        if(isIntType.apply(pt).boolVal)
        {ESLVal _v1736 = substTypeEnv.apply(_v1725,_v1731);
          ESLVal _v1735 = expType.apply(_v1730,_v1728,_v1727,_v1726,_v1725);
          ESLVal _v1734 = expType.apply(_v1729,_v1728,_v1727,_v1726,_v1725);
          
          if(typeEqual.apply(_v1736,_v1735).and(typeEqual.apply(_v1736,_v1734)).boolVal)
          return _v1736;
          else
            return error(new ESLVal("TypeError",_v1733,new ESLVal("expecting probably arm types to agree: ").add(ppType.apply(_v1735,_v1725).add(new ESLVal(" ").add(ppType.apply(_v1736,_v1725).add(new ESLVal(" ").add(ppType.apply(_v1734,_v1725))))))));
        }
        else
          return error(new ESLVal("TypeError",_v1733,new ESLVal("expecting an integer: ").add(ppType.apply(pt,_v1725))));
      }
    }
  });
  private static ESLVal newType = new ESLVal(new Function(new ESLVal("newType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1724 = $args[0];
  ESLVal _v1723 = $args[1];
  ESLVal _v1722 = $args[2];
  ESLVal _v1721 = $args[3];
  ESLVal _v1720 = $args[4];
  ESLVal _v1719 = $args[5];
  ESLVal _v1718 = $args[6];
  return expType.apply(new ESLVal("Apply",_v1724,_v1723,_v1722),_v1721,_v1720,_v1719,_v1718);
    }
  });
  private static ESLVal sendType = new ESLVal(new Function(new ESLVal("sendType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1707 = $args[0];
  ESLVal _v1706 = $args[1];
  ESLVal _v1705 = $args[2];
  ESLVal _v1704 = $args[3];
  ESLVal _v1703 = $args[4];
  ESLVal _v1702 = $args[5];
  ESLVal _v1701 = $args[6];
  ESLVal _v1700 = $args[7];
  {ESLVal _v930 = typeNF.apply(derefType.apply(expType.apply(_v1706,_v1703,_v1702,_v1701,_v1700)),_v1700);
        
        switch(_v930.termName) {
        case "ActType": {ESLVal $1827 = _v930.termRef(0);
          ESLVal $1826 = _v930.termRef(1);
          ESLVal $1825 = _v930.termRef(2);
          
          {ESLVal al = $1827;
          
          {ESLVal exports = $1826;
          
          {ESLVal handlers = $1825;
          
          LetRec letrec = new LetRec() {
          ESLVal findHandler = new ESLVal(new Function(new ESLVal("findHandler"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v1708 = $args[0];
            {ESLVal _v931 = _v1708;
                  
                  if(_v931.isCons())
                  {ESLVal $1828 = _v931.head();
                    ESLVal $1829 = _v931.tail();
                    
                    switch($1828.termName) {
                    case "MessageType": {ESLVal $1831 = $1828.termRef(0);
                      ESLVal $1830 = $1828.termRef(1);
                      
                      if($1830.isCons())
                      {ESLVal $1832 = $1830.head();
                        ESLVal $1833 = $1830.tail();
                        
                        switch($1832.termName) {
                        case "TermType": {ESLVal $1836 = $1832.termRef(0);
                          ESLVal $1835 = $1832.termRef(1);
                          ESLVal $1834 = $1832.termRef(2);
                          
                          if($1833.isCons())
                          {ESLVal $1837 = $1833.head();
                            ESLVal $1838 = $1833.tail();
                            
                            {ESLVal m = $1828;
                            
                            {ESLVal _v1709 = $1829;
                            
                            return findHandler.apply(_v1709);
                          }
                          }
                          }
                        else if($1833.isNil())
                          {ESLVal ml = $1831;
                            
                            {ESLVal tl = $1836;
                            
                            {ESLVal m = $1835;
                            
                            {ESLVal ts = $1834;
                            
                            {ESLVal rest = $1829;
                            
                            if(m.eql(_v1705).boolVal)
                            return head.apply(_v1708);
                            else
                              {ESLVal _v1710 = $1828;
                                
                                {ESLVal _v1711 = $1829;
                                
                                return findHandler.apply(_v1711);
                              }
                              }
                          }
                          }
                          }
                          }
                          }
                        else {ESLVal m = $1828;
                            
                            {ESLVal _v1712 = $1829;
                            
                            return findHandler.apply(_v1712);
                          }
                          }
                        }
                        default: {ESLVal m = $1828;
                          
                          {ESLVal _v1713 = $1829;
                          
                          return findHandler.apply(_v1713);
                        }
                        }
                      }
                      }
                    else if($1830.isNil())
                      {ESLVal m = $1828;
                        
                        {ESLVal _v1714 = $1829;
                        
                        return findHandler.apply(_v1714);
                      }
                      }
                    else {ESLVal m = $1828;
                        
                        {ESLVal _v1715 = $1829;
                        
                        return findHandler.apply(_v1715);
                      }
                      }
                    }
                    default: {ESLVal m = $1828;
                      
                      {ESLVal _v1716 = $1829;
                      
                      return findHandler.apply(_v1716);
                    }
                    }
                  }
                  }
                else if(_v931.isNil())
                  return error(new ESLVal("TypeError",_v1707,new ESLVal("cannot find message handler named ").add(_v1705)));
                else return error(new ESLVal("case error at Pos(28491,28798)").add(ESLVal.list(_v931)));
                }
              }
            });
          
          public ESLVal get(String name) {
            switch(name) {
              case "findHandler": return findHandler;
              
              default: throw new Error("cannot find letrec binding");
            }
            }
          };
        ESLVal findHandler = letrec.get("findHandler");
        
          {ESLVal _v932 = findHandler.apply(handlers);
          
          switch(_v932.termName) {
          case "MessageType": {ESLVal $1840 = _v932.termRef(0);
            ESLVal $1839 = _v932.termRef(1);
            
            if($1839.isCons())
            {ESLVal $1841 = $1839.head();
              ESLVal $1842 = $1839.tail();
              
              switch($1841.termName) {
              case "TermType": {ESLVal $1845 = $1841.termRef(0);
                ESLVal $1844 = $1841.termRef(1);
                ESLVal $1843 = $1841.termRef(2);
                
                if($1842.isCons())
                {ESLVal $1846 = $1842.head();
                  ESLVal $1847 = $1842.tail();
                  
                  {ESLVal m = _v932;
                  
                  return error(new ESLVal("TypeError",_v1707,new ESLVal("cannot find message handler named ").add(_v1705.add(new ESLVal(" in ").add(handlers)))));
                }
                }
              else if($1842.isNil())
                {ESLVal ml = $1840;
                  
                  {ESLVal tl = $1845;
                  
                  {ESLVal _v1717 = $1844;
                  
                  {ESLVal ts1 = $1843;
                  
                  {ESLVal ts2 = expTypes.apply(_v1704,_v1703,_v1702,_v1701,_v1700);
                  
                  if(length.apply(ts1).eql(length.apply(ts2)).boolVal)
                  if(subTypes.apply(ts2,ts1).boolVal)
                    {expType.apply(_v1706,_v1703,_v1702,_v1701,_v1700);
                    return new ESLVal("VoidType",_v1707);}
                    else
                      return error(new ESLVal("TypeError",_v1707,new ESLVal("message argument types ").add(ppTypes.apply(ts2,_v1700).add(new ESLVal(" do not match expected types ").add(ppTypes.apply(ts1,_v1700))))));
                  else
                    return error(new ESLVal("TypeError",_v1707,new ESLVal("expecting ").add(length.apply(ts1).add(new ESLVal(" args, but received ").add(length.apply(ts2))))));
                }
                }
                }
                }
                }
              else {ESLVal m = _v932;
                  
                  return error(new ESLVal("TypeError",_v1707,new ESLVal("cannot find message handler named ").add(_v1705.add(new ESLVal(" in ").add(handlers)))));
                }
              }
              default: {ESLVal m = _v932;
                
                return error(new ESLVal("TypeError",_v1707,new ESLVal("cannot find message handler named ").add(_v1705.add(new ESLVal(" in ").add(handlers)))));
              }
            }
            }
          else if($1839.isNil())
            {ESLVal m = _v932;
              
              return error(new ESLVal("TypeError",_v1707,new ESLVal("cannot find message handler named ").add(_v1705.add(new ESLVal(" in ").add(handlers)))));
            }
          else {ESLVal m = _v932;
              
              return error(new ESLVal("TypeError",_v1707,new ESLVal("cannot find message handler named ").add(_v1705.add(new ESLVal(" in ").add(handlers)))));
            }
          }
          default: {ESLVal m = _v932;
            
            return error(new ESLVal("TypeError",_v1707,new ESLVal("cannot find message handler named ").add(_v1705.add(new ESLVal(" in ").add(handlers)))));
          }
        }
        }
        
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(28276,29624)").add(ESLVal.list(_v930)));
      }
      }
    }
  });
  private static ESLVal actType = new ESLVal(new Function(new ESLVal("actType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1657 = $args[0];
  ESLVal _v1656 = $args[1];
  ESLVal _v1655 = $args[2];
  ESLVal _v1654 = $args[3];
  ESLVal _v1653 = $args[4];
  ESLVal _v1652 = $args[5];
  ESLVal _v1651 = $args[6];
  ESLVal _v1650 = $args[7];
  ESLVal _v1649 = $args[8];
  ESLVal _v1648 = $args[9];
  ESLVal _v1647 = $args[10];
  ESLVal _v1646 = $args[11];
  LetRec letrec = new LetRec() {
        ESLVal findLoc = new ESLVal(new Function(new ESLVal("findLoc"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1690 = $args[0];
          ESLVal _v1689 = $args[1];
          {ESLVal _v929 = _v1689;
                
                if(_v929.isCons())
                {ESLVal $1811 = _v929.head();
                  ESLVal $1812 = _v929.tail();
                  
                  switch($1811.termName) {
                  case "Binding": {ESLVal $1824 = $1811.termRef(0);
                    ESLVal $1823 = $1811.termRef(1);
                    ESLVal $1822 = $1811.termRef(2);
                    ESLVal $1821 = $1811.termRef(3);
                    ESLVal $1820 = $1811.termRef(4);
                    
                    {ESLVal _v1694 = $1824;
                    
                    {ESLVal m = $1823;
                    
                    {ESLVal t = $1822;
                    
                    {ESLVal st = $1821;
                    
                    {ESLVal e = $1820;
                    
                    {ESLVal _v1695 = $1812;
                    
                    if(m.eql(_v1690).boolVal)
                    return _v1694;
                    else
                      {ESLVal b = $1811;
                        
                        {ESLVal _v1696 = $1812;
                        
                        return findLoc.apply(_v1690,_v1696);
                      }
                      }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                case "FunBind": {ESLVal $1819 = $1811.termRef(0);
                    ESLVal $1818 = $1811.termRef(1);
                    ESLVal $1817 = $1811.termRef(2);
                    ESLVal $1816 = $1811.termRef(3);
                    ESLVal $1815 = $1811.termRef(4);
                    ESLVal $1814 = $1811.termRef(5);
                    ESLVal $1813 = $1811.termRef(6);
                    
                    {ESLVal _v1691 = $1819;
                    
                    {ESLVal m = $1818;
                    
                    {ESLVal ps = $1817;
                    
                    {ESLVal t = $1816;
                    
                    {ESLVal st = $1815;
                    
                    {ESLVal g = $1814;
                    
                    {ESLVal e = $1813;
                    
                    {ESLVal _v1692 = $1812;
                    
                    if(m.eql(_v1690).boolVal)
                    return _v1691;
                    else
                      {ESLVal b = $1811;
                        
                        {ESLVal _v1693 = $1812;
                        
                        return findLoc.apply(_v1690,_v1693);
                      }
                      }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal b = $1811;
                    
                    {ESLVal _v1697 = $1812;
                    
                    return findLoc.apply(_v1690,_v1697);
                  }
                  }
                }
                }
              else if(_v929.isNil())
                return p0;
              else return error(new ESLVal("case error at Pos(30134,30438)").add(ESLVal.list(_v929)));
              }
            }
          });
        ESLVal findType = new ESLVal(new Function(new ESLVal("findType"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1681 = $args[0];
          ESLVal _v1680 = $args[1];
          {ESLVal _v928 = _v1680;
                
                if(_v928.isCons())
                {ESLVal $1797 = _v928.head();
                  ESLVal $1798 = _v928.tail();
                  
                  switch($1797.termName) {
                  case "Binding": {ESLVal $1810 = $1797.termRef(0);
                    ESLVal $1809 = $1797.termRef(1);
                    ESLVal $1808 = $1797.termRef(2);
                    ESLVal $1807 = $1797.termRef(3);
                    ESLVal $1806 = $1797.termRef(4);
                    
                    {ESLVal _v1685 = $1810;
                    
                    {ESLVal m = $1809;
                    
                    {ESLVal t = $1808;
                    
                    {ESLVal st = $1807;
                    
                    {ESLVal e = $1806;
                    
                    {ESLVal _v1686 = $1798;
                    
                    if(m.eql(_v1681).boolVal)
                    return substTypeEnv.apply(_v1646,t);
                    else
                      {ESLVal b = $1797;
                        
                        {ESLVal _v1687 = $1798;
                        
                        return findType.apply(_v1681,_v1687);
                      }
                      }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                case "FunBind": {ESLVal $1805 = $1797.termRef(0);
                    ESLVal $1804 = $1797.termRef(1);
                    ESLVal $1803 = $1797.termRef(2);
                    ESLVal $1802 = $1797.termRef(3);
                    ESLVal $1801 = $1797.termRef(4);
                    ESLVal $1800 = $1797.termRef(5);
                    ESLVal $1799 = $1797.termRef(6);
                    
                    {ESLVal _v1682 = $1805;
                    
                    {ESLVal m = $1804;
                    
                    {ESLVal ps = $1803;
                    
                    {ESLVal t = $1802;
                    
                    {ESLVal st = $1801;
                    
                    {ESLVal g = $1800;
                    
                    {ESLVal e = $1799;
                    
                    {ESLVal _v1683 = $1798;
                    
                    if(m.eql(_v1681).boolVal)
                    return substTypeEnv.apply(_v1646,t);
                    else
                      {ESLVal b = $1797;
                        
                        {ESLVal _v1684 = $1798;
                        
                        return findType.apply(_v1681,_v1684);
                      }
                      }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal b = $1797;
                    
                    {ESLVal _v1688 = $1798;
                    
                    return findType.apply(_v1681,_v1688);
                  }
                  }
                }
                }
              else if(_v928.isNil())
                return $null;
              else return error(new ESLVal("case error at Pos(30492,30849)").add(ESLVal.list(_v928)));
              }
            }
          });
        ESLVal decs = new ESLVal(new Function(new ESLVal("decs"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1676 = $args[0];
          {ESLVal _v927 = _v1676;
                
                if(_v927.isCons())
                {ESLVal $1795 = _v927.head();
                  ESLVal $1796 = _v927.tail();
                  
                  {ESLVal m = $1795;
                  
                  {ESLVal _v1677 = $1796;
                  
                  {ESLVal _v1679 = findType.apply(m,_v1652);
                  ESLVal _v1678 = findLoc.apply(m,_v1652);
                  
                  if(_v1679.eql($null).boolVal)
                  return error(new ESLVal("TypeError",_v1678,new ESLVal("cannot find exported name ").add(m)));
                  else
                    return decs.apply(_v1677).cons(new ESLVal("Dec",_v1678,m,_v1679,_v1679));
                }
                }
                }
                }
              else if(_v927.isNil())
                return $nil;
              else return error(new ESLVal("case error at Pos(30891,31222)").add(ESLVal.list(_v927)));
              }
            }
          });
        ESLVal getMessageTypes = new ESLVal(new Function(new ESLVal("getMessageTypes"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1673 = $args[0];
          {ESLVal _v926 = _v1673;
                
                if(_v926.isCons())
                {ESLVal $1789 = _v926.head();
                  ESLVal $1790 = _v926.tail();
                  
                  switch($1789.termName) {
                  case "BArm": {ESLVal $1794 = $1789.termRef(0);
                    ESLVal $1793 = $1789.termRef(1);
                    ESLVal $1792 = $1789.termRef(2);
                    ESLVal $1791 = $1789.termRef(3);
                    
                    {ESLVal _v1674 = $1794;
                    
                    {ESLVal ps = $1793;
                    
                    {ESLVal g = $1792;
                    
                    {ESLVal e = $1791;
                    
                    {ESLVal _v1675 = $1790;
                    
                    return getMessageTypes.apply(_v1675).cons(getMessageType.apply(ps));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(31273,31428)").add(ESLVal.list(_v926)));
                }
                }
              else if(_v926.isNil())
                return $nil;
              else return error(new ESLVal("case error at Pos(31273,31428)").add(ESLVal.list(_v926)));
              }
            }
          });
        ESLVal getMessageType = new ESLVal(new Function(new ESLVal("getMessageType"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal ps = $args[0];
          {ESLVal _v925 = ps;
                
                if(_v925.isCons())
                {ESLVal $1781 = _v925.head();
                  ESLVal $1782 = _v925.tail();
                  
                  switch($1781.termName) {
                  case "PTerm": {ESLVal $1786 = $1781.termRef(0);
                    ESLVal $1785 = $1781.termRef(1);
                    ESLVal $1784 = $1781.termRef(2);
                    ESLVal $1783 = $1781.termRef(3);
                    
                    if($1782.isCons())
                    {ESLVal $1787 = $1782.head();
                      ESLVal $1788 = $1782.tail();
                      
                      return error(new ESLVal("case error at Pos(31478,31749)").add(ESLVal.list(_v925)));
                    }
                  else if($1782.isNil())
                    {ESLVal pl = $1786;
                      
                      {ESLVal termName = $1785;
                      
                      {ESLVal targs = $1784;
                      
                      {ESLVal _v1672 = $1783;
                      
                      {ESLVal ts = map.apply(new ESLVal(new Function(new ESLVal("fun839"),getSelf()) {
                          public ESLVal apply(ESLVal... $args) {
                            ESLVal p = $args[0];
                        return getPatternType.apply(_v1657,p,_v1649,_v1648,_v1647,_v1646);
                          }
                        }),_v1672);
                      
                      return new ESLVal("MessageType",pl,ESLVal.list(new ESLVal("TermType",pl,termName,ts)));
                    }
                    }
                    }
                    }
                    }
                  else return error(new ESLVal("case error at Pos(31478,31749)").add(ESLVal.list(_v925)));
                  }
                  default: return error(new ESLVal("case error at Pos(31478,31749)").add(ESLVal.list(_v925)));
                }
                }
              else if(_v925.isNil())
                return error(new ESLVal("case error at Pos(31478,31749)").add(ESLVal.list(_v925)));
              else return error(new ESLVal("case error at Pos(31478,31749)").add(ESLVal.list(_v925)));
              }
            }
          });
        ESLVal typeCheckArms = new ESLVal(new Function(new ESLVal("typeCheckArms"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1669 = $args[0];
          ESLVal _v1668 = $args[1];
          ESLVal _v1667 = $args[2];
          {ESLVal _v924 = _v1669;
                
                if(_v924.isCons())
                {ESLVal $1775 = _v924.head();
                  ESLVal $1776 = _v924.tail();
                  
                  switch($1775.termName) {
                  case "BArm": {ESLVal $1780 = $1775.termRef(0);
                    ESLVal $1779 = $1775.termRef(1);
                    ESLVal $1778 = $1775.termRef(2);
                    ESLVal $1777 = $1775.termRef(3);
                    
                    {ESLVal _v1670 = $1780;
                    
                    {ESLVal ps = $1779;
                    
                    {ESLVal g = $1778;
                    
                    {ESLVal e = $1777;
                    
                    {ESLVal _v1671 = $1776;
                    
                    {typeCheckArm.apply(_v1670,ps,g,e,_v1668,_v1667);
                  return typeCheckArms.apply(_v1671,_v1668,_v1667);}
                  }
                  }
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(31825,32052)").add(ESLVal.list(_v924)));
                }
                }
              else if(_v924.isNil())
                return $null;
              else return error(new ESLVal("case error at Pos(31825,32052)").add(ESLVal.list(_v924)));
              }
            }
          });
        ESLVal typeCheckArm = new ESLVal(new Function(new ESLVal("typeCheckArm"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1663 = $args[0];
          ESLVal _v1662 = $args[1];
          ESLVal _v1661 = $args[2];
          ESLVal _v1660 = $args[3];
          ESLVal _v1659 = $args[4];
          ESLVal _v1658 = $args[5];
          {ESLVal _v923 = _v1662;
                
                if(_v923.isCons())
                {ESLVal $1767 = _v923.head();
                  ESLVal $1768 = _v923.tail();
                  
                  switch($1767.termName) {
                  case "PTerm": {ESLVal $1772 = $1767.termRef(0);
                    ESLVal $1771 = $1767.termRef(1);
                    ESLVal $1770 = $1767.termRef(2);
                    ESLVal $1769 = $1767.termRef(3);
                    
                    if($1768.isCons())
                    {ESLVal $1773 = $1768.head();
                      ESLVal $1774 = $1768.tail();
                      
                      return error(new ESLVal("case error at Pos(32151,32600)").add(ESLVal.list(_v923)));
                    }
                  else if($1768.isNil())
                    {ESLVal pl = $1772;
                      
                      {ESLVal termName = $1771;
                      
                      {ESLVal targs = $1770;
                      
                      {ESLVal _v1664 = $1769;
                      
                      {ESLVal ts = map.apply(new ESLVal(new Function(new ESLVal("fun840"),getSelf()) {
                          public ESLVal apply(ESLVal... $args) {
                            ESLVal p = $args[0];
                        return getPatternType.apply(_v1663,p,_v1659,_v1658,_v1647,_v1646);
                          }
                        }),_v1664);
                      
                      {patternTypes.apply(_v1663,_v1664,ts,_v1659,_v1658,_v1647,_v1646,new ESLVal(new Function(new ESLVal("fun841"),getSelf()) {
                      public ESLVal apply(ESLVal... $args) {
                        ESLVal _v1666 = $args[0];
                    ESLVal _v1665 = $args[1];
                    return expType.apply(_v1660,_v1659,_v1665,_v1647,_v1646);
                      }
                    }));
                    return $null;}
                    }
                    }
                    }
                    }
                    }
                  else return error(new ESLVal("case error at Pos(32151,32600)").add(ESLVal.list(_v923)));
                  }
                  default: return error(new ESLVal("case error at Pos(32151,32600)").add(ESLVal.list(_v923)));
                }
                }
              else if(_v923.isNil())
                return error(new ESLVal("case error at Pos(32151,32600)").add(ESLVal.list(_v923)));
              else return error(new ESLVal("case error at Pos(32151,32600)").add(ESLVal.list(_v923)));
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "findLoc": return findLoc;
            
            case "findType": return findType;
            
            case "decs": return decs;
            
            case "getMessageTypes": return getMessageTypes;
            
            case "getMessageType": return getMessageType;
            
            case "typeCheckArms": return typeCheckArms;
            
            case "typeCheckArm": return typeCheckArm;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal findLoc = letrec.get("findLoc");
      
      ESLVal findType = letrec.get("findType");
      
      ESLVal decs = letrec.get("decs");
      
      ESLVal getMessageTypes = letrec.get("getMessageTypes");
      
      ESLVal getMessageType = letrec.get("getMessageType");
      
      ESLVal typeCheckArms = letrec.get("typeCheckArms");
      
      ESLVal typeCheckArm = letrec.get("typeCheckArm");
      
        {ESLVal parentType = ((Supplier<ESLVal>)() -> { 
            if(_v1654.eql($null).boolVal)
              return actType0;
              else
                return expType.apply(_v1654,_v1649,_v1648,_v1647,_v1646);
          }).get();
        ESLVal localEnv = parBind.apply(_v1652,_v1649,_v1648,_v1647,_v1646);
        
        {ESLVal exportedDecs = decs.apply(_v1653);
        
        {ESLVal messageTypes = getMessageTypes.apply(_v1650);
        
        {ESLVal _v1699 = new ESLVal("ExtendedAct",_v1657,parentType,exportedDecs,messageTypes);
        ESLVal _v1698 = ESLVal.list(new ESLVal("Map",new ESLVal("$super"),parentType));
        
        {typeCheckExports.apply(_v1657,exportedDecs,_v1652,_v1699,localEnv.add(_v1648),_v1646,_v1647);
      typeCheckValues.apply(valueDefs.apply(_v1652),_v1699,_v1698.add(localEnv.add(_v1648)),_v1646,_v1647);
      expType.apply(_v1651,_v1699,_v1698.add(localEnv.add(_v1648)),_v1647,_v1646);
      typeCheckArms.apply(_v1650,_v1699,_v1698.add(localEnv.add(_v1648)));
      return _v1699;}
      }
      }
      }
      }
      
    }
  });
  private static ESLVal typeCheckExports = new ESLVal(new Function(new ESLVal("typeCheckExports"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1645 = $args[0];
  ESLVal _v1644 = $args[1];
  ESLVal _v1643 = $args[2];
  ESLVal _v1642 = $args[3];
  ESLVal _v1641 = $args[4];
  ESLVal _v1640 = $args[5];
  ESLVal _v1639 = $args[6];
  {{
        ESLVal _v922 = _v1644;
        while(_v922.isCons()) {
          ESLVal e = _v922.headVal;
          if(exists.apply(new ESLVal(new Function(new ESLVal("fun842"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal b = $args[0];
          return bindingName.apply(b).eql(decName.apply(e)).and(typeEqual.apply(lookupType.apply(decName.apply(e),_v1641),decType.apply(e)));
            }
          }),_v1643).boolVal)
            {}
            else
              error(new ESLVal("TypeError",_v1645,new ESLVal(" cannot find export for ").add(decName.apply(e))));
          _v922 = _v922.tailVal;}
      }
      return $null;}
    }
  });
  private static ESLVal bTypeExports = new ESLVal(new Function(new ESLVal("bTypeExports"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v921 = t;
        
        switch(_v921.termName) {
        case "ExtendedAct": {ESLVal $1766 = _v921.termRef(0);
          ESLVal $1765 = _v921.termRef(1);
          ESLVal $1764 = _v921.termRef(2);
          ESLVal $1763 = _v921.termRef(3);
          
          {ESLVal l = $1766;
          
          {ESLVal parent = $1765;
          
          {ESLVal exports = $1764;
          
          {ESLVal message = $1763;
          
          return bTypeExports.apply(parent).add(exports);
        }
        }
        }
        }
        }
      case "ActType": {ESLVal $1762 = _v921.termRef(0);
          ESLVal $1761 = _v921.termRef(1);
          ESLVal $1760 = _v921.termRef(2);
          
          {ESLVal l = $1762;
          
          {ESLVal exports = $1761;
          
          {ESLVal message = $1760;
          
          return exports;
        }
        }
        }
        }
      case "TypeClosure": {ESLVal $1759 = _v921.termRef(0);
          
          {ESLVal f = $1759;
          
          return bTypeExports.apply(f.apply());
        }
        }
      case "RecType": {ESLVal $1758 = _v921.termRef(0);
          ESLVal $1757 = _v921.termRef(1);
          ESLVal $1756 = _v921.termRef(2);
          
          {ESLVal l = $1758;
          
          {ESLVal n = $1757;
          
          {ESLVal _v1638 = $1756;
          
          return bTypeExports.apply(substType.apply(new ESLVal("RecType",l,n,_v1638),n,_v1638));
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(33996,34406)").add(ESLVal.list(_v921)));
      }
      }
    }
  });
  private static ESLVal cmpType = new ESLVal(new Function(new ESLVal("cmpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1630 = $args[0];
  ESLVal _v1629 = $args[1];
  ESLVal _v1628 = $args[2];
  ESLVal _v1627 = $args[3];
  ESLVal _v1626 = $args[4];
  ESLVal _v1625 = $args[5];
  ESLVal _v1624 = $args[6];
  {ESLVal _v919 = _v1628;
        
        if(_v919.isCons())
        {ESLVal $1747 = _v919.head();
          ESLVal $1748 = _v919.tail();
          
          switch($1747.termName) {
          case "BQual": {ESLVal $1753 = $1747.termRef(0);
            ESLVal $1752 = $1747.termRef(1);
            ESLVal $1751 = $1747.termRef(2);
            
            {ESLVal _v1633 = $1753;
            
            {ESLVal p = $1752;
            
            {ESLVal list = $1751;
            
            {ESLVal _v1634 = $1748;
            
            {ESLVal lType = expType.apply(list,_v1627,_v1626,_v1625,_v1624);
            
            {ESLVal _v920 = lType;
            
            switch(_v920.termName) {
            case "ListType": {ESLVal $1755 = _v920.termRef(0);
              ESLVal $1754 = _v920.termRef(1);
              
              {ESLVal ll = $1755;
              
              {ESLVal t = $1754;
              
              {ESLVal _v1635 = _v1634;
              
              return patternType.apply(_v1633,p,substTypeEnv.apply(_v1624,t),_v1627,_v1626,_v1625,_v1624,new ESLVal(new Function(new ESLVal("fun843"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal _v1637 = $args[0];
              ESLVal _v1636 = $args[1];
              return cmpType.apply(_v1633,_v1629,_v1635,_v1627,_v1636,_v1625,_v1624);
                }
              }));
            }
            }
            }
            }
            default: {ESLVal t = _v920;
              
              return error(new ESLVal("TypeError",_v1633,new ESLVal("qualifier binding expects a list: ").add(ppType.apply(t,_v1624))));
            }
          }
          }
          }
          }
          }
          }
          }
          }
        case "PQual": {ESLVal $1750 = $1747.termRef(0);
            ESLVal $1749 = $1747.termRef(1);
            
            {ESLVal _v1631 = $1750;
            
            {ESLVal b = $1749;
            
            {ESLVal _v1632 = $1748;
            
            {ESLVal bType = expType.apply(b,_v1627,_v1626,_v1625,_v1624);
            
            if(isBoolType.apply(bType).boolVal)
            return cmpType.apply(_v1631,_v1629,_v1632,_v1627,_v1626,_v1625,_v1624);
            else
              return error(new ESLVal("TypeError",_v1631,new ESLVal("qualifier expects a boolean type: ").add(ppType.apply(bType,_v1624))));
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(34517,35503)").add(ESLVal.list(_v919)));
        }
        }
      else if(_v919.isNil())
        {ESLVal t = expType.apply(_v1629,_v1627,_v1626,_v1625,_v1624);
          
          return new ESLVal("ListType",_v1630,t);
        }
      else return error(new ESLVal("case error at Pos(34517,35503)").add(ESLVal.list(_v919)));
      }
    }
  });
  private static ESLVal updateType = new ESLVal(new Function(new ESLVal("updateType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1623 = $args[0];
  ESLVal _v1622 = $args[1];
  ESLVal _v1621 = $args[2];
  ESLVal _v1620 = $args[3];
  ESLVal _v1619 = $args[4];
  ESLVal _v1618 = $args[5];
  ESLVal _v1617 = $args[6];
  {ESLVal t = lookupType.apply(_v1622,_v1619);
        
        if(t.eql($null).boolVal)
        return error(new ESLVal("TypeError",_v1623,new ESLVal("unbound variable ").add(_v1622)));
        else
          {ESLVal valueType = expType.apply(_v1621,_v1620,_v1619,_v1618,_v1617);
            
            if(typeEqual.apply(valueType,t).boolVal)
            return valueType;
            else
              return error(new ESLVal("TypeError",_v1623,new ESLVal("type of variable ").add(_v1622.add(new ESLVal("::").add(ppType.apply(t,_v1617).add(new ESLVal(" does not agree with value type ").add(ppType.apply(valueType,_v1617))))))));
          }
      }
    }
  });
  private static ESLVal letType = new ESLVal(new Function(new ESLVal("letType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1616 = $args[0];
  ESLVal _v1615 = $args[1];
  ESLVal _v1614 = $args[2];
  ESLVal _v1613 = $args[3];
  ESLVal _v1612 = $args[4];
  ESLVal _v1611 = $args[5];
  ESLVal _v1610 = $args[6];
  {ESLVal env = parBind.apply(_v1615,_v1613,_v1612,_v1611,_v1610);
        
        {{
        ESLVal _v918 = _v1615;
        while(_v918.isCons()) {
          ESLVal b = _v918.headVal;
          typeCheckDef.apply(b,_v1613,_v1612,env.add(_v1612),_v1611,_v1610);
          _v918 = _v918.tailVal;}
      }
      return expType.apply(_v1614,_v1613,env.add(_v1612),_v1611,_v1610);}
      }
    }
  });
  private static ESLVal letrecType = new ESLVal(new Function(new ESLVal("letrecType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1609 = $args[0];
  ESLVal _v1608 = $args[1];
  ESLVal _v1607 = $args[2];
  ESLVal _v1606 = $args[3];
  ESLVal _v1605 = $args[4];
  ESLVal _v1604 = $args[5];
  ESLVal _v1603 = $args[6];
  {ESLVal env = recBind.apply(_v1608,_v1606,_v1605,_v1604,_v1603);
        
        {{
        ESLVal _v917 = _v1608;
        while(_v917.isCons()) {
          ESLVal b = _v917.headVal;
          typeCheckDef.apply(b,_v1606,env.add(_v1605),env.add(_v1605),_v1604,_v1603);
          _v917 = _v917.tailVal;}
      }
      return expType.apply(_v1607,_v1606,env.add(_v1605),_v1604,_v1603);}
      }
    }
  });
  private static ESLVal checkDupBindings = new ESLVal(new Function(new ESLVal("checkDupBindings"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal bs = $args[0];
  {ESLVal _v915 = bs;
        
        if(_v915.isCons())
        {ESLVal $1745 = _v915.head();
          ESLVal $1746 = _v915.tail();
          
          {ESLVal b = $1745;
          
          {ESLVal _v1601 = $1746;
          
          if(member.apply(bindingName.apply(b),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v916 = $qualArg;
              
              {ESLVal _v1602 = _v916;
              
              return ESLVal.list(ESLVal.list(bindingName.apply(_v1602)));
            }
            }
          }
        }).map(_v1601).flatten().flatten()).boolVal)
          return error(new ESLVal("TypeError",bindingLoc.apply(b),new ESLVal("duplicate definitions for ").add(bindingName.apply(b))));
          else
            return checkDupBindings.apply(_v1601);
        }
        }
        }
      else if(_v915.isNil())
        return $null;
      else return error(new ESLVal("case error at Pos(36751,37016)").add(ESLVal.list(_v915)));
      }
    }
  });
  private static ESLVal parBind = new ESLVal(new Function(new ESLVal("parBind"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1600 = $args[0];
  ESLVal _v1599 = $args[1];
  ESLVal _v1598 = $args[2];
  ESLVal _v1597 = $args[3];
  ESLVal _v1596 = $args[4];
  {checkDupBindings.apply(_v1600);
      return valueDefsToTEnv.apply(valueDefs.apply(_v1600),_v1599,_v1598,_v1597,_v1596);}
    }
  });
  private static ESLVal recBind = new ESLVal(new Function(new ESLVal("recBind"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1595 = $args[0];
  ESLVal _v1594 = $args[1];
  ESLVal _v1593 = $args[2];
  ESLVal _v1592 = $args[3];
  ESLVal _v1591 = $args[4];
  return valueDefsToTEnv.apply(valueDefs.apply(_v1595),_v1594,_v1593,_v1592,_v1591);
    }
  });
  private static ESLVal caseType = new ESLVal(new Function(new ESLVal("caseType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1590 = $args[0];
  ESLVal _v1589 = $args[1];
  ESLVal _v1588 = $args[2];
  ESLVal _v1587 = $args[3];
  ESLVal _v1586 = $args[4];
  ESLVal _v1585 = $args[5];
  ESLVal _v1584 = $args[6];
  {ESLVal ts1 = expTypes.apply(_v1589,_v1587,_v1586,_v1585,_v1584);
        
        {ESLVal ts2 = armTypes.apply(_v1588,ts1,_v1587,_v1586,_v1585,_v1584);
        
        if(allEqualTypes.apply(head.apply(ts2),tail.apply(ts2)).boolVal)
        return head.apply(ts2);
        else
          return error(new ESLVal("TypeError",_v1590,new ESLVal("case arm types do not agree: ").add(ppTypes.apply(ts1,_v1584).add(new ESLVal(" ").add(ppTypes.apply(ts2,_v1584))))));
      }
      }
    }
  });
  private static ESLVal tryType = new ESLVal(new Function(new ESLVal("tryType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1583 = $args[0];
  ESLVal _v1582 = $args[1];
  ESLVal _v1581 = $args[2];
  ESLVal _v1580 = $args[3];
  ESLVal _v1579 = $args[4];
  ESLVal _v1578 = $args[5];
  ESLVal _v1577 = $args[6];
  {ESLVal ts1 = expTypes.apply(ESLVal.list(_v1582),_v1580,_v1579,_v1578,_v1577);
        
        {ESLVal ts2 = armTypes.apply(_v1581,ts1,_v1580,_v1579,_v1578,_v1577);
        
        if(allEqualTypes.apply(head.apply(ts2),tail.apply(ts2)).boolVal)
        return head.apply(ts2);
        else
          return error(new ESLVal("TypeError",_v1583,new ESLVal("try arm types do not agree: ").add(ppTypes.apply(ts1,_v1577).add(new ESLVal(" ").add(ppTypes.apply(ts2,_v1577))))));
      }
      }
    }
  });
  private static ESLVal armTypes = new ESLVal(new Function(new ESLVal("armTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1575 = $args[0];
  ESLVal _v1574 = $args[1];
  ESLVal _v1573 = $args[2];
  ESLVal _v1572 = $args[3];
  ESLVal _v1571 = $args[4];
  ESLVal _v1570 = $args[5];
  {ESLVal _v914 = _v1575;
        
        if(_v914.isCons())
        {ESLVal $1743 = _v914.head();
          ESLVal $1744 = _v914.tail();
          
          {ESLVal a = $1743;
          
          {ESLVal _v1576 = $1744;
          
          return armTypes.apply(_v1576,_v1574,_v1573,_v1572,_v1571,_v1570).cons(armType.apply(a,_v1574,_v1573,_v1572,_v1571,_v1570));
        }
        }
        }
      else if(_v914.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(38381,38550)").add(ESLVal.list(_v914)));
      }
    }
  });
  private static ESLVal armType = new ESLVal(new Function(new ESLVal("armType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1567 = $args[0];
  ESLVal _v1566 = $args[1];
  ESLVal _v1565 = $args[2];
  ESLVal _v1564 = $args[3];
  ESLVal _v1563 = $args[4];
  ESLVal _v1562 = $args[5];
  {ESLVal _v913 = _v1567;
        
        switch(_v913.termName) {
        case "BArm": {ESLVal $1742 = _v913.termRef(0);
          ESLVal $1741 = _v913.termRef(1);
          ESLVal $1740 = _v913.termRef(2);
          ESLVal $1739 = _v913.termRef(3);
          
          {ESLVal l = $1742;
          
          {ESLVal ps = $1741;
          
          {ESLVal guard = $1740;
          
          {ESLVal exp = $1739;
          
          {checkPatterns.apply(l,ps);
        if(length.apply(ps).eql(length.apply(_v1566)).boolVal)
          return patternTypes.apply(l,ps,_v1566,_v1565,_v1564,_v1563,_v1562,new ESLVal(new Function(new ESLVal("fun844"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v1569 = $args[0];
            ESLVal _v1568 = $args[1];
            return guardedExpType.apply(l,guard,exp,_v1565,_v1568,_v1563,_v1562);
              }
            }));
          else
            return error(new ESLVal("TypeError",l,new ESLVal("number of patterns ").add(length.apply(ps).add(new ESLVal(" does not match supplied values: ").add(length.apply(_v1566))))));}
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(38652,39113)").add(ESLVal.list(_v913)));
      }
      }
    }
  });
  private static ESLVal refType = new ESLVal(new Function(new ESLVal("refType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1532 = $args[0];
  ESLVal _v1531 = $args[1];
  ESLVal _v1530 = $args[2];
  ESLVal _v1529 = $args[3];
  ESLVal _v1528 = $args[4];
  ESLVal _v1527 = $args[5];
  ESLVal _v1526 = $args[6];
  LetRec letrec = new LetRec() {
        ESLVal t = derefType.apply(expType.apply(_v1531,_v1529,_v1528,_v1527,_v1526));
        ESLVal findExport = new ESLVal(new Function(new ESLVal("findExport"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal decs = $args[0];
          {ESLVal _v911 = decs;
                
                if(_v911.isCons())
                {ESLVal $1722 = _v911.head();
                  ESLVal $1723 = _v911.tail();
                  
                  switch($1722.termName) {
                  case "Dec": {ESLVal $1727 = $1722.termRef(0);
                    ESLVal $1726 = $1722.termRef(1);
                    ESLVal $1725 = $1722.termRef(2);
                    ESLVal $1724 = $1722.termRef(3);
                    
                    {ESLVal _v1538 = $1727;
                    
                    {ESLVal m = $1726;
                    
                    {ESLVal t = $1725;
                    
                    {ESLVal st = $1724;
                    
                    {ESLVal _v1539 = $1723;
                    
                    if(m.eql(_v1530).boolVal)
                    return t;
                    else
                      {ESLVal d = $1722;
                        
                        {ESLVal _v1540 = $1723;
                        
                        return findExport.apply(_v1540);
                      }
                      }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal d = $1722;
                    
                    {ESLVal _v1541 = $1723;
                    
                    return findExport.apply(_v1541);
                  }
                  }
                }
                }
              else if(_v911.isNil())
                return $null;
              else return error(new ESLVal("case error at Pos(39341,39514)").add(ESLVal.list(_v911)));
              }
            }
          });
        ESLVal findField = new ESLVal(new Function(new ESLVal("findField"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal fs = $args[0];
          {ESLVal _v910 = fs;
                
                if(_v910.isCons())
                {ESLVal $1716 = _v910.head();
                  ESLVal $1717 = _v910.tail();
                  
                  switch($1716.termName) {
                  case "Dec": {ESLVal $1721 = $1716.termRef(0);
                    ESLVal $1720 = $1716.termRef(1);
                    ESLVal $1719 = $1716.termRef(2);
                    ESLVal $1718 = $1716.termRef(3);
                    
                    {ESLVal _v1533 = $1721;
                    
                    {ESLVal m = $1720;
                    
                    {ESLVal t = $1719;
                    
                    {ESLVal ds = $1718;
                    
                    {ESLVal _v1534 = $1717;
                    
                    if(m.eql(_v1530).boolVal)
                    return t;
                    else
                      {ESLVal _v1535 = $1716;
                        
                        {ESLVal _v1536 = $1717;
                        
                        return findField.apply(_v1536);
                      }
                      }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal t = $1716;
                    
                    {ESLVal _v1537 = $1717;
                    
                    return findField.apply(_v1537);
                  }
                  }
                }
                }
              else if(_v910.isNil())
                return error(new ESLVal("TypeError",_v1532,new ESLVal("cannot find field name ").add(_v1530)));
              else return error(new ESLVal("case error at Pos(39555,39763)").add(ESLVal.list(_v910)));
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "t": return t;
            
            case "findExport": return findExport;
            
            case "findField": return findField;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal t = letrec.get("t");
      
      ESLVal findExport = letrec.get("findExport");
      
      ESLVal findField = letrec.get("findField");
      
        {ESLVal _v912 = typeNF.apply(t,_v1526);
        
        switch(_v912.termName) {
        case "StrType": {ESLVal $1738 = _v912.termRef(0);
          
          {ESLVal sl = $1738;
          
          if(_v1530.eql(new ESLVal("explode")).boolVal)
          return new ESLVal("ListType",sl,new ESLVal("IntType",sl));
          else
            {ESLVal _v1559 = $1738;
              
              if(_v1530.eql(new ESLVal("writeDate")).boolVal)
              return new ESLVal("FloatType",_v1559);
              else
                {ESLVal _v1560 = _v912;
                  
                  return error(new ESLVal("TypeError",_v1532,new ESLVal("expecting a record type, but received ").add(ppType.apply(_v1560,_v1526))));
                }
            }
        }
        }
      case "TableType": {ESLVal $1737 = _v912.termRef(0);
          ESLVal $1736 = _v912.termRef(1);
          ESLVal $1735 = _v912.termRef(2);
          
          {ESLVal _v1545 = $1737;
          
          {ESLVal k = $1736;
          
          {ESLVal v = $1735;
          
          if(_v1530.eql(new ESLVal("get")).boolVal)
          return new ESLVal("FunType",_v1545,ESLVal.list(k),v);
          else
            {ESLVal _v1546 = $1737;
              
              {ESLVal _v1547 = $1736;
              
              {ESLVal _v1548 = $1735;
              
              if(_v1530.eql(new ESLVal("put")).boolVal)
              return new ESLVal("FunType",_v1546,ESLVal.list(_v1547,_v1548),t);
              else
                {ESLVal _v1549 = $1737;
                  
                  {ESLVal _v1550 = $1736;
                  
                  {ESLVal _v1551 = $1735;
                  
                  if(_v1530.eql(new ESLVal("keys")).boolVal)
                  return new ESLVal("ListType",_v1549,_v1550);
                  else
                    {ESLVal _v1552 = $1737;
                      
                      {ESLVal _v1553 = $1736;
                      
                      {ESLVal _v1554 = $1735;
                      
                      if(_v1530.eql(new ESLVal("vals")).boolVal)
                      return new ESLVal("ListType",_v1552,_v1554);
                      else
                        {ESLVal _v1555 = $1737;
                          
                          {ESLVal _v1556 = $1736;
                          
                          {ESLVal _v1557 = $1735;
                          
                          if(_v1530.eql(new ESLVal("hasKey")).boolVal)
                          return new ESLVal("FunType",_v1555,ESLVal.list(_v1556),new ESLVal("BoolType",_v1555));
                          else
                            {ESLVal _v1558 = _v912;
                              
                              return error(new ESLVal("TypeError",_v1555,new ESLVal("expecting a record type, but received ").add(ppType.apply(_v1558,_v1526))));
                            }
                        }
                        }
                        }
                    }
                    }
                    }
                }
                }
                }
            }
            }
            }
        }
        }
        }
        }
      case "ListType": {ESLVal $1734 = _v912.termRef(0);
          ESLVal $1733 = _v912.termRef(1);
          
          {ESLVal ll = $1734;
          
          {ESLVal _v1543 = $1733;
          
          if(_v1530.eql(new ESLVal("implode")).boolVal)
          return new ESLVal("StrType",ll);
          else
            {ESLVal _v1544 = _v912;
              
              return error(new ESLVal("TypeError",_v1532,new ESLVal("expecting a record type, but received ").add(ppType.apply(_v1544,_v1526))));
            }
        }
        }
        }
      case "RecordType": {ESLVal $1732 = _v912.termRef(0);
          ESLVal $1731 = _v912.termRef(1);
          
          {ESLVal rl = $1732;
          
          {ESLVal fs = $1731;
          
          return findField.apply(fs);
        }
        }
        }
      case "ActType": {ESLVal $1730 = _v912.termRef(0);
          ESLVal $1729 = _v912.termRef(1);
          ESLVal $1728 = _v912.termRef(2);
          
          {ESLVal al = $1730;
          
          {ESLVal exports = $1729;
          
          {ESLVal handlers = $1728;
          
          {ESLVal _v1542 = findExport.apply(exports);
          
          if(_v1542.eql($null).boolVal)
          return error(new ESLVal("TypeError",_v1532,new ESLVal("behaviour type does not export ").add(_v1530)));
          else
            return substTypeEnv.apply(_v1526,_v1542);
        }
        }
        }
        }
        }
        default: {ESLVal _v1561 = _v912;
          
          return error(new ESLVal("TypeError",_v1532,new ESLVal("expecting a record type, but received ").add(ppType.apply(_v1561,_v1526))));
        }
      }
      }
      
    }
  });
  private static ESLVal derefType = new ESLVal(new Function(new ESLVal("derefType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v909 = t;
        
        switch(_v909.termName) {
        case "TypeClosure": {ESLVal $1715 = _v909.termRef(0);
          
          {ESLVal f = $1715;
          
          return derefType.apply(f.apply());
        }
        }
        default: {ESLVal _v1525 = _v909;
          
          return _v1525;
        }
      }
      }
    }
  });
  private static ESLVal recordType = new ESLVal(new Function(new ESLVal("recordType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1518 = $args[0];
  ESLVal _v1517 = $args[1];
  ESLVal _v1516 = $args[2];
  ESLVal _v1515 = $args[3];
  ESLVal _v1514 = $args[4];
  ESLVal _v1513 = $args[5];
  LetRec letrec = new LetRec() {
        ESLVal fieldTypes = new ESLVal(new Function(new ESLVal("fieldTypes"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1519 = $args[0];
          {ESLVal _v908 = _v1519;
                
                if(_v908.isCons())
                {ESLVal $1708 = _v908.head();
                  ESLVal $1709 = _v908.tail();
                  
                  switch($1708.termName) {
                  case "Binding": {ESLVal $1714 = $1708.termRef(0);
                    ESLVal $1713 = $1708.termRef(1);
                    ESLVal $1712 = $1708.termRef(2);
                    ESLVal $1711 = $1708.termRef(3);
                    ESLVal $1710 = $1708.termRef(4);
                    
                    {ESLVal _v1520 = $1714;
                    
                    {ESLVal n = $1713;
                    
                    {ESLVal t = $1712;
                    
                    {ESLVal st = $1711;
                    
                    {ESLVal e = $1710;
                    
                    {ESLVal _v1521 = $1709;
                    
                    {ESLVal _v1522 = expType.apply(e,_v1516,_v1515,_v1514,_v1513);
                    
                    return fieldTypes.apply(_v1521).cons(new ESLVal("Dec",_v1520,n,_v1522,_v1522));
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v1523 = _v908;
                    
                    return error(new ESLVal("TypeError",_v1518,new ESLVal("unknown field representation: ").add(_v1523)));
                  }
                }
                }
              else if(_v908.isNil())
                return $nil;
              else {ESLVal _v1524 = _v908;
                  
                  return error(new ESLVal("TypeError",_v1518,new ESLVal("unknown field representation: ").add(_v1524)));
                }
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "fieldTypes": return fieldTypes;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal fieldTypes = letrec.get("fieldTypes");
      
        return new ESLVal("RecordType",_v1518,fieldTypes.apply(_v1517));
      
    }
  });
  private static ESLVal forType = new ESLVal(new Function(new ESLVal("forType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1508 = $args[0];
  ESLVal _v1507 = $args[1];
  ESLVal _v1506 = $args[2];
  ESLVal _v1505 = $args[3];
  ESLVal _v1504 = $args[4];
  ESLVal _v1503 = $args[5];
  ESLVal _v1502 = $args[6];
  ESLVal _v1501 = $args[7];
  {ESLVal _v1509 = expType.apply(_v1506,_v1504,_v1503,_v1502,_v1501);
        
        {ESLVal _v907 = _v1509;
        
        switch(_v907.termName) {
        case "ListType": {ESLVal $1707 = _v907.termRef(0);
          ESLVal $1706 = _v907.termRef(1);
          
          {ESLVal _v1510 = $1707;
          
          {ESLVal t = $1706;
          
          return patternType.apply(_v1510,_v1507,t,_v1504,_v1503,_v1502,_v1501,new ESLVal(new Function(new ESLVal("fun845"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1512 = $args[0];
          ESLVal _v1511 = $args[1];
          return expType.apply(_v1505,_v1504,_v1511,_v1502,_v1501);
            }
          }));
        }
        }
        }
        default: {ESLVal t = _v907;
          
          return error(new ESLVal("TypeError",_v1508,new ESLVal("for type expects a list: ").add(_v1506)));
        }
      }
      }
      }
    }
  });
  private static ESLVal patternTypes = new ESLVal(new Function(new ESLVal("patternTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1482 = $args[0];
  ESLVal _v1481 = $args[1];
  ESLVal _v1480 = $args[2];
  ESLVal _v1479 = $args[3];
  ESLVal _v1478 = $args[4];
  ESLVal _v1477 = $args[5];
  ESLVal _v1476 = $args[6];
  ESLVal _v1475 = $args[7];
  {ESLVal _v906 = _v1481;
        ESLVal _v905 = _v1480;
        
        if(_v906.isCons())
        {ESLVal $1700 = _v906.head();
          ESLVal $1701 = _v906.tail();
          
          if(_v905.isCons())
          {ESLVal $1702 = _v905.head();
            ESLVal $1703 = _v905.tail();
            
            {ESLVal p = $1700;
            
            {ESLVal _v1483 = $1701;
            
            {ESLVal t = $1702;
            
            {ESLVal _v1484 = $1703;
            
            {ESLVal _v1486 = _v1483;
            ESLVal _v1485 = _v1484;
            
            return patternType.apply(_v1482,p,t,_v1479,_v1478,_v1477,_v1476,new ESLVal(new Function(new ESLVal("fun846"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v1488 = $args[0];
            ESLVal _v1487 = $args[1];
            return patternTypes.apply(_v1482,_v1486,_v1485,_v1479,_v1487,_v1477,_v1476,new ESLVal(new Function(new ESLVal("fun847"),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      ESLVal _v1490 = $args[0];
                  ESLVal _v1489 = $args[1];
                  return _v1475.apply(_v1490.cons(_v1488),_v1489);
                    }
                  }));
              }
            }));
          }
          }
          }
          }
          }
          }
        else if(_v905.isNil())
          {ESLVal _v1491 = _v906;
            
            {ESLVal _v1492 = _v905;
            
            return error(new ESLVal("TypeError",_v1482,new ESLVal("somthing wrong with ").add(_v1491.add(new ESLVal(" ").add(_v1492)))));
          }
          }
        else {ESLVal _v1493 = _v906;
            
            {ESLVal _v1494 = _v905;
            
            return error(new ESLVal("TypeError",_v1482,new ESLVal("somthing wrong with ").add(_v1493.add(new ESLVal(" ").add(_v1494)))));
          }
          }
        }
      else if(_v906.isNil())
        if(_v905.isCons())
          {ESLVal $1704 = _v905.head();
            ESLVal $1705 = _v905.tail();
            
            {ESLVal _v1495 = _v906;
            
            {ESLVal _v1496 = _v905;
            
            return error(new ESLVal("TypeError",_v1482,new ESLVal("somthing wrong with ").add(_v1495.add(new ESLVal(" ").add(_v1496)))));
          }
          }
          }
        else if(_v905.isNil())
          return _v1475.apply($nil,_v1478);
        else {ESLVal _v1497 = _v906;
            
            {ESLVal _v1498 = _v905;
            
            return error(new ESLVal("TypeError",_v1482,new ESLVal("somthing wrong with ").add(_v1497.add(new ESLVal(" ").add(_v1498)))));
          }
          }
      else {ESLVal _v1499 = _v906;
          
          {ESLVal _v1500 = _v905;
          
          return error(new ESLVal("TypeError",_v1482,new ESLVal("somthing wrong with ").add(_v1499.add(new ESLVal(" ").add(_v1500)))));
        }
        }
      }
    }
  });
  private static ESLVal getPatternType = new ESLVal(new Function(new ESLVal("getPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1459 = $args[0];
  ESLVal _v1458 = $args[1];
  ESLVal _v1457 = $args[2];
  ESLVal _v1456 = $args[3];
  ESLVal _v1455 = $args[4];
  ESLVal _v1454 = $args[5];
  {ESLVal _v904 = _v1458;
        
        switch(_v904.termName) {
        case "PApplyType": {ESLVal $1699 = _v904.termRef(0);
          ESLVal $1698 = _v904.termRef(1);
          ESLVal $1697 = _v904.termRef(2);
          
          {ESLVal _v1472 = $1699;
          
          {ESLVal _v1473 = $1698;
          
          {ESLVal args = $1697;
          
          return error(new ESLVal("should this happen?"));
        }
        }
        }
        }
      case "PBool": {ESLVal $1696 = _v904.termRef(0);
          ESLVal $1695 = _v904.termRef(1);
          
          {ESLVal _v1471 = $1696;
          
          {ESLVal b = $1695;
          
          return new ESLVal("BoolType",_v1471);
        }
        }
        }
      case "PCons": {ESLVal $1694 = _v904.termRef(0);
          ESLVal $1693 = _v904.termRef(1);
          ESLVal $1692 = _v904.termRef(2);
          
          {ESLVal _v1470 = $1694;
          
          {ESLVal hd = $1693;
          
          {ESLVal tl = $1692;
          
          return getPatternType.apply(_v1470,tl,_v1457,_v1456,_v1455,_v1454);
        }
        }
        }
        }
      case "PBagCons": {ESLVal $1691 = _v904.termRef(0);
          ESLVal $1690 = _v904.termRef(1);
          ESLVal $1689 = _v904.termRef(2);
          
          {ESLVal _v1469 = $1691;
          
          {ESLVal hd = $1690;
          
          {ESLVal tl = $1689;
          
          return getPatternType.apply(_v1469,tl,_v1457,_v1456,_v1455,_v1454);
        }
        }
        }
        }
      case "PSetCons": {ESLVal $1688 = _v904.termRef(0);
          ESLVal $1687 = _v904.termRef(1);
          ESLVal $1686 = _v904.termRef(2);
          
          {ESLVal _v1468 = $1688;
          
          {ESLVal hd = $1687;
          
          {ESLVal tl = $1686;
          
          return getPatternType.apply(_v1468,tl,_v1457,_v1456,_v1455,_v1454);
        }
        }
        }
        }
      case "PNil": {ESLVal $1685 = _v904.termRef(0);
          
          {ESLVal _v1467 = $1685;
          
          return new ESLVal("ForallType",_v1467,ESLVal.list(new ESLVal("T")),new ESLVal("ListType",_v1467,new ESLVal("VarType",_v1467,new ESLVal("T"))));
        }
        }
      case "PNull": {ESLVal $1684 = _v904.termRef(0);
          
          {ESLVal _v1466 = $1684;
          
          return new ESLVal("ForallType",_v1466,ESLVal.list(new ESLVal("T")),new ESLVal("VarType",_v1466,new ESLVal("T")));
        }
        }
      case "PEmptyBag": {ESLVal $1683 = _v904.termRef(0);
          
          {ESLVal _v1465 = $1683;
          
          return new ESLVal("ForallType",_v1465,ESLVal.list(new ESLVal("T")),new ESLVal("BagType",_v1465,new ESLVal("VarType",_v1465,new ESLVal("T"))));
        }
        }
      case "PEmptySet": {ESLVal $1682 = _v904.termRef(0);
          
          {ESLVal _v1464 = $1682;
          
          return new ESLVal("ForallType",_v1464,ESLVal.list(new ESLVal("T")),new ESLVal("SetType",_v1464,new ESLVal("VarType",_v1464,new ESLVal("T"))));
        }
        }
      case "PInt": {ESLVal $1681 = _v904.termRef(0);
          ESLVal $1680 = _v904.termRef(1);
          
          {ESLVal _v1463 = $1681;
          
          {ESLVal n = $1680;
          
          return new ESLVal("IntType",_v1463);
        }
        }
        }
      case "PVar": {ESLVal $1679 = _v904.termRef(0);
          ESLVal $1678 = _v904.termRef(1);
          ESLVal $1677 = _v904.termRef(2);
          
          {ESLVal _v1462 = $1679;
          
          {ESLVal n = $1678;
          
          {ESLVal pt = $1677;
          
          return substTypeEnv.apply(_v1454,pt);
        }
        }
        }
        }
      case "PStr": {ESLVal $1676 = _v904.termRef(0);
          ESLVal $1675 = _v904.termRef(1);
          
          {ESLVal _v1461 = $1676;
          
          {ESLVal s = $1675;
          
          return new ESLVal("StrType",_v1461);
        }
        }
        }
      case "PTerm": {ESLVal $1674 = _v904.termRef(0);
          ESLVal $1673 = _v904.termRef(1);
          ESLVal $1672 = _v904.termRef(2);
          ESLVal $1671 = _v904.termRef(3);
          
          {ESLVal _v1460 = $1674;
          
          {ESLVal n = $1673;
          
          {ESLVal ts = $1672;
          
          {ESLVal ps = $1671;
          
          return lookupType.apply(n,_v1455);
        }
        }
        }
        }
        }
        default: {ESLVal _v1474 = _v904;
          
          return error(new ESLVal("TypeError",_v1459,new ESLVal("unknown type of pattern: ").add(_v1474)));
        }
      }
      }
    }
  });
  private static ESLVal patternType = new ESLVal(new Function(new ESLVal("patternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1431 = $args[0];
  ESLVal _v1430 = $args[1];
  ESLVal _v1429 = $args[2];
  ESLVal _v1428 = $args[3];
  ESLVal _v1427 = $args[4];
  ESLVal _v1426 = $args[5];
  ESLVal _v1425 = $args[6];
  ESLVal _v1424 = $args[7];
  {ESLVal _v903 = _v1430;
        
        switch(_v903.termName) {
        case "PAdd": {ESLVal $1670 = _v903.termRef(0);
          ESLVal $1669 = _v903.termRef(1);
          ESLVal $1668 = _v903.termRef(2);
          
          {ESLVal _v1452 = $1670;
          
          {ESLVal p1 = $1669;
          
          {ESLVal p2 = $1668;
          
          return addPatternType.apply(_v1452,p1,p2,_v1429,_v1428,_v1427,_v1426,_v1425,_v1424);
        }
        }
        }
        }
      case "PApplyType": {ESLVal $1667 = _v903.termRef(0);
          ESLVal $1666 = _v903.termRef(1);
          ESLVal $1665 = _v903.termRef(2);
          
          {ESLVal _v1450 = $1667;
          
          {ESLVal _v1451 = $1666;
          
          {ESLVal args = $1665;
          
          return applyTypePatternType.apply(_v1450,_v1451,substTypesEnv.apply(_v1425,args),_v1429,_v1428,_v1427,_v1426,_v1425,_v1424);
        }
        }
        }
        }
      case "PBool": {ESLVal $1664 = _v903.termRef(0);
          ESLVal $1663 = _v903.termRef(1);
          
          {ESLVal _v1449 = $1664;
          
          {ESLVal b = $1663;
          
          if(isBoolType.apply(_v1429).boolVal)
          return _v1424.apply(new ESLVal("BoolType",_v1449),_v1427);
          else
            return error(new ESLVal("TypeError",_v1449,new ESLVal("type mismatch: Bool and ").add(ppType.apply(_v1429,_v1425))));
        }
        }
        }
      case "PBagCons": {ESLVal $1662 = _v903.termRef(0);
          ESLVal $1661 = _v903.termRef(1);
          ESLVal $1660 = _v903.termRef(2);
          
          {ESLVal _v1446 = $1662;
          
          {ESLVal hd = $1661;
          
          {ESLVal tl = $1660;
          
          return bagConsPatternType.apply(_v1446,hd,tl,_v1429,_v1428,_v1427,_v1426,_v1425,new ESLVal(new Function(new ESLVal("fun848"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1448 = $args[0];
          ESLVal _v1447 = $args[1];
          return _v1424.apply(new ESLVal("ListType",_v1446,_v1448),_v1447);
            }
          }));
        }
        }
        }
        }
      case "PSetCons": {ESLVal $1659 = _v903.termRef(0);
          ESLVal $1658 = _v903.termRef(1);
          ESLVal $1657 = _v903.termRef(2);
          
          {ESLVal _v1443 = $1659;
          
          {ESLVal hd = $1658;
          
          {ESLVal tl = $1657;
          
          return setConsPatternType.apply(_v1443,hd,tl,_v1429,_v1428,_v1427,_v1426,_v1425,new ESLVal(new Function(new ESLVal("fun849"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1445 = $args[0];
          ESLVal _v1444 = $args[1];
          return _v1424.apply(new ESLVal("ListType",_v1443,_v1445),_v1444);
            }
          }));
        }
        }
        }
        }
      case "PCons": {ESLVal $1656 = _v903.termRef(0);
          ESLVal $1655 = _v903.termRef(1);
          ESLVal $1654 = _v903.termRef(2);
          
          {ESLVal _v1440 = $1656;
          
          {ESLVal hd = $1655;
          
          {ESLVal tl = $1654;
          
          return consPatternType.apply(_v1440,hd,tl,_v1429,_v1428,_v1427,_v1426,_v1425,new ESLVal(new Function(new ESLVal("fun850"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1442 = $args[0];
          ESLVal _v1441 = $args[1];
          return _v1424.apply(new ESLVal("ListType",_v1440,_v1442),_v1441);
            }
          }));
        }
        }
        }
        }
      case "PNil": {ESLVal $1653 = _v903.termRef(0);
          
          {ESLVal _v1439 = $1653;
          
          return nilType.apply(_v1439,_v1429,_v1428,_v1427,_v1426,_v1425,_v1424);
        }
        }
      case "PNull": {ESLVal $1652 = _v903.termRef(0);
          
          {ESLVal _v1438 = $1652;
          
          return _v1424.apply(_v1429,_v1427);
        }
        }
      case "PEmptyBag": {ESLVal $1651 = _v903.termRef(0);
          
          {ESLVal _v1437 = $1651;
          
          return emptyBagType.apply(_v1437,_v1429,_v1428,_v1427,_v1426,_v1425,_v1424);
        }
        }
      case "PEmptySet": {ESLVal $1650 = _v903.termRef(0);
          
          {ESLVal _v1436 = $1650;
          
          return emptySetType.apply(_v1436,_v1429,_v1428,_v1427,_v1426,_v1425,_v1424);
        }
        }
      case "PInt": {ESLVal $1649 = _v903.termRef(0);
          ESLVal $1648 = _v903.termRef(1);
          
          {ESLVal _v1435 = $1649;
          
          {ESLVal n = $1648;
          
          if(isIntType.apply(_v1429).boolVal)
          return _v1424.apply(new ESLVal("IntType",_v1435),_v1427);
          else
            return error(new ESLVal("TypeError",_v1435,new ESLVal("type mismatch: Int and ").add(ppType.apply(_v1429,_v1425))));
        }
        }
        }
      case "PVar": {ESLVal $1647 = _v903.termRef(0);
          ESLVal $1646 = _v903.termRef(1);
          ESLVal $1645 = _v903.termRef(2);
          
          {ESLVal _v1434 = $1647;
          
          {ESLVal n = $1646;
          
          {ESLVal pt = $1645;
          
          return _v1424.apply(_v1429,ESLVal.list(new ESLVal("Map",n,_v1429)).add(_v1427));
        }
        }
        }
        }
      case "PStr": {ESLVal $1644 = _v903.termRef(0);
          ESLVal $1643 = _v903.termRef(1);
          
          {ESLVal _v1433 = $1644;
          
          {ESLVal s = $1643;
          
          if(isStrType.apply(_v1429).boolVal)
          return _v1424.apply(new ESLVal("StrType",_v1433),_v1427);
          else
            return error(new ESLVal("TypeError",_v1433,new ESLVal("type mismatch: Str and ").add(ppType.apply(_v1429,_v1425))));
        }
        }
        }
      case "PTerm": {ESLVal $1642 = _v903.termRef(0);
          ESLVal $1641 = _v903.termRef(1);
          ESLVal $1640 = _v903.termRef(2);
          ESLVal $1639 = _v903.termRef(3);
          
          {ESLVal _v1432 = $1642;
          
          {ESLVal n = $1641;
          
          {ESLVal ts = $1640;
          
          {ESLVal ps = $1639;
          
          return termPatternType.apply(_v1432,n,substTypesEnv.apply(_v1425,ts),ps,_v1429,_v1428,_v1427,_v1426,_v1425,_v1424);
        }
        }
        }
        }
        }
        default: {ESLVal _v1453 = _v903;
          
          return error(new ESLVal("TypeError",_v1431,new ESLVal("unknown type of pattern: ").add(_v1453)));
        }
      }
      }
    }
  });
  private static ESLVal addPatternType = new ESLVal(new Function(new ESLVal("addPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1394 = $args[0];
  ESLVal _v1393 = $args[1];
  ESLVal _v1392 = $args[2];
  ESLVal _v1391 = $args[3];
  ESLVal _v1390 = $args[4];
  ESLVal _v1389 = $args[5];
  ESLVal _v1388 = $args[6];
  ESLVal _v1387 = $args[7];
  ESLVal _v1386 = $args[8];
  return patternType.apply(_v1394,_v1393,_v1391,_v1390,_v1389,_v1388,_v1387,new ESLVal(new Function(new ESLVal("fun851"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1396 = $args[0];
        ESLVal _v1395 = $args[1];
        return patternType.apply(_v1394,_v1392,_v1391,_v1390,_v1395,_v1388,_v1387,new ESLVal(new Function(new ESLVal("fun852"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal _v1398 = $args[0];
              ESLVal _v1397 = $args[1];
              {ESLVal _v900 = _v1391;
                    
                    switch(_v900.termName) {
                    case "ListType": {ESLVal $1601 = _v900.termRef(0);
                      ESLVal $1600 = _v900.termRef(1);
                      
                      {ESLVal tl = $1601;
                      
                      {ESLVal t = $1600;
                      
                      {ESLVal _v902 = _v1393;
                      ESLVal _v901 = _v1392;
                      
                      switch(_v902.termName) {
                      case "PCons": {ESLVal $1634 = _v902.termRef(0);
                        ESLVal $1633 = _v902.termRef(1);
                        ESLVal $1632 = _v902.termRef(2);
                        
                        switch($1632.termName) {
                        case "PNil": {ESLVal $1635 = $1632.termRef(0);
                          
                          switch(_v901.termName) {
                          case "PVar": {ESLVal $1638 = _v901.termRef(0);
                            ESLVal $1637 = _v901.termRef(1);
                            ESLVal $1636 = _v901.termRef(2);
                            
                            {ESLVal l1 = $1634;
                            
                            {ESLVal p = $1633;
                            
                            {ESLVal l3 = $1635;
                            
                            {ESLVal l4 = $1638;
                            
                            {ESLVal n2 = $1637;
                            
                            {ESLVal t2 = $1636;
                            
                            return _v1386.apply(_v1391,_v1397);
                          }
                          }
                          }
                          }
                          }
                          }
                          }
                          default: {ESLVal _v1418 = _v902;
                            
                            {ESLVal _v1419 = _v901;
                            
                            return error(new ESLVal("TypeError",_v1394,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                          }
                          }
                        }
                        }
                        default: {ESLVal _v1420 = _v902;
                          
                          {ESLVal _v1421 = _v901;
                          
                          return error(new ESLVal("TypeError",_v1394,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                        }
                        }
                      }
                      }
                    case "PVar": {ESLVal $1617 = _v902.termRef(0);
                        ESLVal $1616 = _v902.termRef(1);
                        ESLVal $1615 = _v902.termRef(2);
                        
                        switch(_v901.termName) {
                        case "PCons": {ESLVal $1630 = _v901.termRef(0);
                          ESLVal $1629 = _v901.termRef(1);
                          ESLVal $1628 = _v901.termRef(2);
                          
                          switch($1628.termName) {
                          case "PNil": {ESLVal $1631 = $1628.termRef(0);
                            
                            {ESLVal l1 = $1617;
                            
                            {ESLVal n = $1616;
                            
                            {ESLVal _v1413 = $1615;
                            
                            {ESLVal l2 = $1630;
                            
                            {ESLVal p = $1629;
                            
                            {ESLVal l3 = $1631;
                            
                            return _v1386.apply(_v1391,_v1397);
                          }
                          }
                          }
                          }
                          }
                          }
                          }
                          default: {ESLVal _v1414 = _v902;
                            
                            {ESLVal _v1415 = _v901;
                            
                            return error(new ESLVal("TypeError",_v1394,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                          }
                          }
                        }
                        }
                      case "PAdd": {ESLVal $1620 = _v901.termRef(0);
                          ESLVal $1619 = _v901.termRef(1);
                          ESLVal $1618 = _v901.termRef(2);
                          
                          switch($1619.termName) {
                          case "PCons": {ESLVal $1623 = $1619.termRef(0);
                            ESLVal $1622 = $1619.termRef(1);
                            ESLVal $1621 = $1619.termRef(2);
                            
                            switch($1621.termName) {
                            case "PNil": {ESLVal $1624 = $1621.termRef(0);
                              
                              switch($1618.termName) {
                              case "PVar": {ESLVal $1627 = $1618.termRef(0);
                                ESLVal $1626 = $1618.termRef(1);
                                ESLVal $1625 = $1618.termRef(2);
                                
                                {ESLVal l1 = $1617;
                                
                                {ESLVal n1 = $1616;
                                
                                {ESLVal t1 = $1615;
                                
                                {ESLVal l2 = $1620;
                                
                                {ESLVal l3 = $1623;
                                
                                {ESLVal p = $1622;
                                
                                {ESLVal l5 = $1624;
                                
                                {ESLVal l6 = $1627;
                                
                                {ESLVal n3 = $1626;
                                
                                {ESLVal t3 = $1625;
                                
                                return _v1386.apply(_v1391,_v1397);
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              default: {ESLVal _v1407 = _v902;
                                
                                {ESLVal _v1408 = _v901;
                                
                                return error(new ESLVal("TypeError",_v1394,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                              }
                              }
                            }
                            }
                            default: {ESLVal _v1409 = _v902;
                              
                              {ESLVal _v1410 = _v901;
                              
                              return error(new ESLVal("TypeError",_v1394,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                            }
                            }
                          }
                          }
                          default: {ESLVal _v1411 = _v902;
                            
                            {ESLVal _v1412 = _v901;
                            
                            return error(new ESLVal("TypeError",_v1394,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                          }
                          }
                        }
                        }
                        default: {ESLVal _v1416 = _v902;
                          
                          {ESLVal _v1417 = _v901;
                          
                          return error(new ESLVal("TypeError",_v1394,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                        }
                        }
                      }
                      }
                    case "PAdd": {ESLVal $1604 = _v902.termRef(0);
                        ESLVal $1603 = _v902.termRef(1);
                        ESLVal $1602 = _v902.termRef(2);
                        
                        switch($1603.termName) {
                        case "PVar": {ESLVal $1607 = $1603.termRef(0);
                          ESLVal $1606 = $1603.termRef(1);
                          ESLVal $1605 = $1603.termRef(2);
                          
                          switch($1602.termName) {
                          case "PCons": {ESLVal $1610 = $1602.termRef(0);
                            ESLVal $1609 = $1602.termRef(1);
                            ESLVal $1608 = $1602.termRef(2);
                            
                            switch($1608.termName) {
                            case "PNil": {ESLVal $1611 = $1608.termRef(0);
                              
                              switch(_v901.termName) {
                              case "PVar": {ESLVal $1614 = _v901.termRef(0);
                                ESLVal $1613 = _v901.termRef(1);
                                ESLVal $1612 = _v901.termRef(2);
                                
                                {ESLVal l1 = $1604;
                                
                                {ESLVal l2 = $1607;
                                
                                {ESLVal n1 = $1606;
                                
                                {ESLVal t1 = $1605;
                                
                                {ESLVal l3 = $1610;
                                
                                {ESLVal p = $1609;
                                
                                {ESLVal l5 = $1611;
                                
                                {ESLVal l6 = $1614;
                                
                                {ESLVal n3 = $1613;
                                
                                {ESLVal t3 = $1612;
                                
                                return _v1386.apply(_v1391,_v1397);
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              default: {ESLVal _v1399 = _v902;
                                
                                {ESLVal _v1400 = _v901;
                                
                                return error(new ESLVal("TypeError",_v1394,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                              }
                              }
                            }
                            }
                            default: {ESLVal _v1401 = _v902;
                              
                              {ESLVal _v1402 = _v901;
                              
                              return error(new ESLVal("TypeError",_v1394,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                            }
                            }
                          }
                          }
                          default: {ESLVal _v1403 = _v902;
                            
                            {ESLVal _v1404 = _v901;
                            
                            return error(new ESLVal("TypeError",_v1394,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                          }
                          }
                        }
                        }
                        default: {ESLVal _v1405 = _v902;
                          
                          {ESLVal _v1406 = _v901;
                          
                          return error(new ESLVal("TypeError",_v1394,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                        }
                        }
                      }
                      }
                      default: {ESLVal _v1422 = _v902;
                        
                        {ESLVal _v1423 = _v901;
                        
                        return error(new ESLVal("TypeError",_v1394,new ESLVal("patterns must be [p] + p, p + [p] + p, or p + [p]")));
                      }
                      }
                    }
                    }
                    }
                    }
                    }
                  case "TypeClosure": {ESLVal $1599 = _v900.termRef(0);
                      
                      {ESLVal g = $1599;
                      
                      return addPatternType.apply(_v1394,_v1393,_v1392,g.apply(),_v1390,_v1397,_v1388,_v1387,_v1386);
                    }
                    }
                    default: {ESLVal t = _v900;
                      
                      return error(new ESLVal("TypeError",_v1394,new ESLVal("+ expects lists: ").add(ppType.apply(_v1391,_v1387))));
                    }
                  }
                  }
                }
              }));
          }
        }));
    }
  });
  private static ESLVal applyTypePatternType = new ESLVal(new Function(new ESLVal("applyTypePatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1381 = $args[0];
  ESLVal _v1380 = $args[1];
  ESLVal _v1379 = $args[2];
  ESLVal _v1378 = $args[3];
  ESLVal _v1377 = $args[4];
  ESLVal _v1376 = $args[5];
  ESLVal _v1375 = $args[6];
  ESLVal _v1374 = $args[7];
  ESLVal _v1373 = $args[8];
  return patternType.apply(_v1381,_v1380,_v1378,_v1377,_v1376,_v1375,_v1374,new ESLVal(new Function(new ESLVal("fun853"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1383 = $args[0];
        ESLVal _v1382 = $args[1];
        {ESLVal _v899 = typeNF.apply(_v1383,_v1374);
              
              switch(_v899.termName) {
              case "TypeFun": {ESLVal $1598 = _v899.termRef(0);
                ESLVal $1597 = _v899.termRef(1);
                ESLVal $1596 = _v899.termRef(2);
                
                {ESLVal fl = $1598;
                
                {ESLVal ns = $1597;
                
                {ESLVal t = $1596;
                
                if(length.apply(_v1379).eql(length.apply(ns)).boolVal)
                {ESLVal _v1385 = substTypeEnv.apply(zipTypeEnv.apply(ns,_v1379).add(_v1374),t);
                  
                  if(typeEqual.apply(_v1385,_v1378).boolVal)
                  return _v1373.apply(_v1385,_v1382);
                  else
                    return error(new ESLVal("TypeError",_v1381,new ESLVal("value type ").add(ppType.apply(_v1378,_v1374).add(new ESLVal(" does not match pattern type ").add(ppType.apply(_v1385,_v1374).add(new ESLVal(" ").add(ppTypeEnv.apply(_v1374))))))));
                }
                else
                  return error(new ESLVal("TypeError",_v1381,new ESLVal("expecting ").add(length.apply(ns).add(new ESLVal(" args, but suplied with ").add(length.apply(_v1379))))));
              }
              }
              }
              }
            case "ForallType": {ESLVal $1595 = _v899.termRef(0);
                ESLVal $1594 = _v899.termRef(1);
                ESLVal $1593 = _v899.termRef(2);
                
                {ESLVal fl = $1595;
                
                {ESLVal ns = $1594;
                
                {ESLVal t = $1593;
                
                if(length.apply(_v1379).eql(length.apply(ns)).boolVal)
                {ESLVal _v1384 = substTypeEnv.apply(zipTypeEnv.apply(ns,_v1379).add(_v1374),t);
                  
                  if(typeEqual.apply(_v1384,_v1378).boolVal)
                  return _v1373.apply(_v1384,_v1382);
                  else
                    return error(new ESLVal("TypeError",_v1381,new ESLVal("value type ").add(ppType.apply(_v1378,_v1374).add(new ESLVal(" does not match pattern type ").add(ppType.apply(_v1384,_v1374).add(new ESLVal(" ").add(ppTypeEnv.apply(_v1374))))))));
                }
                else
                  return error(new ESLVal("TypeError",_v1381,new ESLVal("expecting ").add(length.apply(ns).add(new ESLVal(" args, but suplied with ").add(length.apply(_v1379))))));
              }
              }
              }
              }
              default: {ESLVal t = _v899;
                
                return _v1373.apply(t,_v1382);
              }
            }
            }
          }
        }));
    }
  });
  private static ESLVal termPatternType = new ESLVal(new Function(new ESLVal("termPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1365 = $args[0];
  ESLVal _v1364 = $args[1];
  ESLVal _v1363 = $args[2];
  ESLVal _v1362 = $args[3];
  ESLVal _v1361 = $args[4];
  ESLVal _v1360 = $args[5];
  ESLVal _v1359 = $args[6];
  ESLVal _v1358 = $args[7];
  ESLVal _v1357 = $args[8];
  ESLVal _v1356 = $args[9];
  {ESLVal _v1366 = getTermPatternType.apply(_v1365,_v1364,_v1363,_v1360,_v1359,_v1358,_v1357);
        
        if(typeEqual.apply(_v1366,_v1361).boolVal)
        {ESLVal _v897 = typeNF.apply(_v1361,_v1357);
          
          switch(_v897.termName) {
          case "UnionType": {ESLVal $1587 = _v897.termRef(0);
            ESLVal $1586 = _v897.termRef(1);
            
            {ESLVal ul = $1587;
            
            {ESLVal cs = $1586;
            
            LetRec letrec = new LetRec() {
            ESLVal getCnstrArgs = new ESLVal(new Function(new ESLVal("getCnstrArgs"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal _v1367 = $args[0];
              {ESLVal _v898 = _v1367;
                    
                    if(_v898.isCons())
                    {ESLVal $1588 = _v898.head();
                      ESLVal $1589 = _v898.tail();
                      
                      switch($1588.termName) {
                      case "TermType": {ESLVal $1592 = $1588.termRef(0);
                        ESLVal $1591 = $1588.termRef(1);
                        ESLVal $1590 = $1588.termRef(2);
                        
                        {ESLVal tl = $1592;
                        
                        {ESLVal m = $1591;
                        
                        {ESLVal args = $1590;
                        
                        {ESLVal _v1368 = $1589;
                        
                        if(m.eql(_v1364).boolVal)
                        return args;
                        else
                          {ESLVal t = $1588;
                            
                            {ESLVal _v1369 = $1589;
                            
                            return getCnstrArgs.apply(_v1369);
                          }
                          }
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal t = $1588;
                        
                        {ESLVal _v1370 = $1589;
                        
                        return getCnstrArgs.apply(_v1370);
                      }
                      }
                    }
                    }
                  else if(_v898.isNil())
                    return error(new ESLVal("TypeError",_v1365,new ESLVal("cannot find constructor for ").add(_v1364)));
                  else return error(new ESLVal("case error at Pos(48971,49230)").add(ESLVal.list(_v898)));
                  }
                }
              });
            
            public ESLVal get(String name) {
              switch(name) {
                case "getCnstrArgs": return getCnstrArgs;
                
                default: throw new Error("cannot find letrec binding");
              }
              }
            };
          ESLVal getCnstrArgs = letrec.get("getCnstrArgs");
          
            {ESLVal argTypes = getCnstrArgs.apply(cs);
            
            if(length.apply(_v1362).eql(length.apply(argTypes)).boolVal)
            return patternTypes.apply(_v1365,_v1362,argTypes,_v1360,_v1359,_v1358,_v1357,new ESLVal(new Function(new ESLVal("fun854"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal _v1372 = $args[0];
              ESLVal _v1371 = $args[1];
              return _v1356.apply(typeNF.apply(_v1361,_v1357),_v1371);
                }
              }));
            else
              return error(new ESLVal("TypeError",_v1365,new ESLVal("arity mismatch.")));
          }
          
          }
          }
          }
          default: {ESLVal t = _v897;
            
            return error(new ESLVal("TypeError",_v1365,new ESLVal("expecting a data type: ").add(_v1361)));
          }
        }
        }
        else
          return error(new ESLVal("TypeError",_v1365,new ESLVal("term pattern type ").add(ppType.apply(_v1366,_v1357).add(new ESLVal(" does not match supplied value type ").add(ppType.apply(_v1361,_v1357))))));
      }
    }
  });
  private static ESLVal typeNF = new ESLVal(new Function(new ESLVal("typeNF"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1350 = $args[0];
  ESLVal _v1349 = $args[1];
  {ESLVal _v894 = substTypeEnv.apply(_v1349,_v1350);
        
        switch(_v894.termName) {
        case "ApplyTypeFun": {ESLVal $1579 = _v894.termRef(0);
          ESLVal $1578 = _v894.termRef(1);
          ESLVal $1577 = _v894.termRef(2);
          
          {ESLVal l = $1579;
          
          {ESLVal op = $1578;
          
          {ESLVal args = $1577;
          
          {ESLVal _v896 = typeNF.apply(op,_v1349);
          
          switch(_v896.termName) {
          case "TypeFun": {ESLVal $1585 = _v896.termRef(0);
            ESLVal $1584 = _v896.termRef(1);
            ESLVal $1583 = _v896.termRef(2);
            
            {ESLVal _v1352 = $1585;
            
            {ESLVal ns = $1584;
            
            {ESLVal _v1353 = $1583;
            
            if(length.apply(args).eql(length.apply(ns)).boolVal)
            return typeNF.apply(substTypeEnv.apply(zipTypeEnv.apply(ns,args),_v1353),_v1349);
            else
              return error(new ESLVal("TypeError",_v1352,new ESLVal("function arity error")));
          }
          }
          }
          }
          default: {ESLVal _v1354 = _v896;
            
            return error(new ESLVal("TypeError",l,new ESLVal("expecting a type function: ").add(ppType.apply(typeNF.apply(op,_v1349),_v1349))));
          }
        }
        }
        }
        }
        }
        }
      case "TypeClosure": {ESLVal $1576 = _v894.termRef(0);
          
          {ESLVal f = $1576;
          
          return typeNF.apply(f.apply(),_v1349);
        }
        }
      case "RecType": {ESLVal $1575 = _v894.termRef(0);
          ESLVal $1574 = _v894.termRef(1);
          ESLVal $1573 = _v894.termRef(2);
          
          {ESLVal l = $1575;
          
          {ESLVal n = $1574;
          
          {ESLVal _v1351 = $1573;
          
          return typeNF.apply(substType.apply(new ESLVal("RecType",l,n,_v1351),n,_v1351),_v1349);
        }
        }
        }
        }
      case "ExtendedAct": {ESLVal $1572 = _v894.termRef(0);
          ESLVal $1571 = _v894.termRef(1);
          ESLVal $1570 = _v894.termRef(2);
          ESLVal $1569 = _v894.termRef(3);
          
          {ESLVal l1 = $1572;
          
          {ESLVal parent = $1571;
          
          {ESLVal decs1 = $1570;
          
          {ESLVal ms1 = $1569;
          
          {ESLVal _v895 = typeNF.apply(parent,_v1349);
          
          switch(_v895.termName) {
          case "ActType": {ESLVal $1582 = _v895.termRef(0);
            ESLVal $1581 = _v895.termRef(1);
            ESLVal $1580 = _v895.termRef(2);
            
            {ESLVal l2 = $1582;
            
            {ESLVal decs2 = $1581;
            
            {ESLVal ms2 = $1580;
            
            return new ESLVal("ActType",l1,decs2.add(decs1),ms2.add(ms1));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(50547,50682)").add(ESLVal.list(_v895)));
        }
        }
        }
        }
        }
        }
        }
        default: {ESLVal _v1355 = _v894;
          
          return _v1355;
        }
      }
      }
    }
  });
  private static ESLVal getTermPatternType = new ESLVal(new Function(new ESLVal("getTermPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1348 = $args[0];
  ESLVal _v1347 = $args[1];
  ESLVal _v1346 = $args[2];
  ESLVal _v1345 = $args[3];
  ESLVal _v1344 = $args[4];
  ESLVal _v1343 = $args[5];
  ESLVal _v1342 = $args[6];
  {ESLVal t = lookupType.apply(_v1347,_v1343);
        
        if(t.eql($null).boolVal)
        return error(new ESLVal("TypeError",_v1348,new ESLVal("unknown constructor ").add(_v1347)));
        else
          if(length.apply(_v1346).gre($zero).boolVal)
            return getGenericTermPatternType.apply(_v1348,t,_v1346,_v1345,_v1344,_v1343,_v1342);
            else
              return t;
      }
    }
  });
  private static ESLVal getGenericTermPatternType = new ESLVal(new Function(new ESLVal("getGenericTermPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1339 = $args[0];
  ESLVal _v1338 = $args[1];
  ESLVal _v1337 = $args[2];
  ESLVal _v1336 = $args[3];
  ESLVal _v1335 = $args[4];
  ESLVal _v1334 = $args[5];
  ESLVal _v1333 = $args[6];
  {ESLVal _v893 = _v1338;
        
        switch(_v893.termName) {
        case "RecType": {ESLVal $1568 = _v893.termRef(0);
          ESLVal $1567 = _v893.termRef(1);
          ESLVal $1566 = _v893.termRef(2);
          
          {ESLVal rl = $1568;
          
          {ESLVal rn = $1567;
          
          {ESLVal rt = $1566;
          
          return getGenericTermPatternType.apply(_v1339,substType.apply(new ESLVal("RecType",rl,rn,rt),rn,rt),_v1337,_v1336,_v1335,_v1334,_v1333);
        }
        }
        }
        }
      case "TypeFun": {ESLVal $1565 = _v893.termRef(0);
          ESLVal $1564 = _v893.termRef(1);
          ESLVal $1563 = _v893.termRef(2);
          
          {ESLVal al = $1565;
          
          {ESLVal ns = $1564;
          
          {ESLVal _v1340 = $1563;
          
          if(length.apply(ns).eql(length.apply(_v1337)).boolVal)
          {ESLVal e = zipTypeEnv.apply(ns,_v1337);
            
            return substTypeEnv.apply(e.add(_v1333),_v1340);
          }
          else
            return error(new ESLVal("TypeError",_v1339,new ESLVal("generic constructor mismatch")));
        }
        }
        }
        }
        default: {ESLVal _v1341 = _v893;
          
          return error(new ESLVal("TypeError",_v1339,new ESLVal("expecting a generic type: ").add(ppType.apply(_v1341,_v1333))));
        }
      }
      }
    }
  });
  private static ESLVal nilType = new ESLVal(new Function(new ESLVal("nilType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1331 = $args[0];
  ESLVal _v1330 = $args[1];
  ESLVal _v1329 = $args[2];
  ESLVal _v1328 = $args[3];
  ESLVal _v1327 = $args[4];
  ESLVal _v1326 = $args[5];
  ESLVal _v1325 = $args[6];
  {ESLVal _v892 = _v1330;
        
        switch(_v892.termName) {
        case "ListType": {ESLVal $1562 = _v892.termRef(0);
          ESLVal $1561 = _v892.termRef(1);
          
          {ESLVal ltl = $1562;
          
          {ESLVal et = $1561;
          
          return _v1325.apply(new ESLVal("ForallType",_v1331,ESLVal.list(new ESLVal("T")),new ESLVal("ListType",_v1331,new ESLVal("VarType",_v1331,new ESLVal("T")))),_v1328);
        }
        }
        }
      case "TypeClosure": {ESLVal $1560 = _v892.termRef(0);
          
          {ESLVal g = $1560;
          
          return nilType.apply(_v1331,g.apply(),_v1329,_v1328,_v1327,_v1326,_v1325);
        }
        }
        default: {ESLVal _v1332 = _v892;
          
          return error(new ESLVal("TypeError",_v1331,new ESLVal("expecting a list type: ").add(ppType.apply(_v1332,_v1326))));
        }
      }
      }
    }
  });
  private static ESLVal emptyBagType = new ESLVal(new Function(new ESLVal("emptyBagType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1323 = $args[0];
  ESLVal _v1322 = $args[1];
  ESLVal _v1321 = $args[2];
  ESLVal _v1320 = $args[3];
  ESLVal _v1319 = $args[4];
  ESLVal _v1318 = $args[5];
  ESLVal _v1317 = $args[6];
  {ESLVal _v891 = _v1322;
        
        switch(_v891.termName) {
        case "BagType": {ESLVal $1559 = _v891.termRef(0);
          ESLVal $1558 = _v891.termRef(1);
          
          {ESLVal ltl = $1559;
          
          {ESLVal et = $1558;
          
          return _v1317.apply(new ESLVal("ForallType",_v1323,ESLVal.list(new ESLVal("T")),new ESLVal("BagType",_v1323,new ESLVal("VarType",_v1323,new ESLVal("T")))),_v1320);
        }
        }
        }
        default: {ESLVal _v1324 = _v891;
          
          return error(new ESLVal("TypeError",_v1323,new ESLVal("expecting a bag type: ").add(ppType.apply(_v1324,_v1318))));
        }
      }
      }
    }
  });
  private static ESLVal emptySetType = new ESLVal(new Function(new ESLVal("emptySetType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1315 = $args[0];
  ESLVal _v1314 = $args[1];
  ESLVal _v1313 = $args[2];
  ESLVal _v1312 = $args[3];
  ESLVal _v1311 = $args[4];
  ESLVal _v1310 = $args[5];
  ESLVal _v1309 = $args[6];
  {ESLVal _v890 = _v1314;
        
        switch(_v890.termName) {
        case "SetType": {ESLVal $1557 = _v890.termRef(0);
          ESLVal $1556 = _v890.termRef(1);
          
          {ESLVal ltl = $1557;
          
          {ESLVal et = $1556;
          
          return _v1309.apply(new ESLVal("ForallType",_v1315,ESLVal.list(new ESLVal("T")),new ESLVal("SetType",_v1315,new ESLVal("VarType",_v1315,new ESLVal("T")))),_v1312);
        }
        }
        }
        default: {ESLVal _v1316 = _v890;
          
          return error(new ESLVal("TypeError",_v1315,new ESLVal("expecting a set type: ").add(ppType.apply(_v1316,_v1310))));
        }
      }
      }
    }
  });
  private static ESLVal consPatternType = new ESLVal(new Function(new ESLVal("consPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1303 = $args[0];
  ESLVal _v1302 = $args[1];
  ESLVal _v1301 = $args[2];
  ESLVal _v1300 = $args[3];
  ESLVal _v1299 = $args[4];
  ESLVal _v1298 = $args[5];
  ESLVal _v1297 = $args[6];
  ESLVal _v1296 = $args[7];
  ESLVal _v1295 = $args[8];
  {ESLVal _v889 = _v1300;
        
        switch(_v889.termName) {
        case "ListType": {ESLVal $1555 = _v889.termRef(0);
          ESLVal $1554 = _v889.termRef(1);
          
          {ESLVal ltl = $1555;
          
          {ESLVal et = $1554;
          
          return patternType.apply(_v1303,_v1302,substTypeEnv.apply(_v1296,et),_v1299,_v1298,_v1297,_v1296,new ESLVal(new Function(new ESLVal("fun855"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1305 = $args[0];
          ESLVal _v1304 = $args[1];
          return patternType.apply(_v1303,_v1301,_v1300,_v1299,_v1304,_v1297,_v1296,new ESLVal(new Function(new ESLVal("fun856"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal _v1307 = $args[0];
                ESLVal _v1306 = $args[1];
                return _v1295.apply(_v1305,_v1306);
                  }
                }));
            }
          }));
        }
        }
        }
      case "TypeClosure": {ESLVal $1553 = _v889.termRef(0);
          
          {ESLVal g = $1553;
          
          return consPatternType.apply(_v1303,_v1302,_v1301,g.apply(),_v1299,_v1298,_v1297,_v1296,_v1295);
        }
        }
        default: {ESLVal _v1308 = _v889;
          
          return error(new ESLVal("TypeError",_v1303,new ESLVal("expecting a list type: ").add(ppType.apply(_v1308,_v1296))));
        }
      }
      }
    }
  });
  private static ESLVal bagConsPatternType = new ESLVal(new Function(new ESLVal("bagConsPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1289 = $args[0];
  ESLVal _v1288 = $args[1];
  ESLVal _v1287 = $args[2];
  ESLVal _v1286 = $args[3];
  ESLVal _v1285 = $args[4];
  ESLVal _v1284 = $args[5];
  ESLVal _v1283 = $args[6];
  ESLVal _v1282 = $args[7];
  ESLVal _v1281 = $args[8];
  {ESLVal _v888 = _v1286;
        
        switch(_v888.termName) {
        case "BagType": {ESLVal $1552 = _v888.termRef(0);
          ESLVal $1551 = _v888.termRef(1);
          
          {ESLVal ltl = $1552;
          
          {ESLVal et = $1551;
          
          return patternType.apply(_v1289,_v1288,substTypeEnv.apply(_v1282,et),_v1285,_v1284,_v1283,_v1282,new ESLVal(new Function(new ESLVal("fun857"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1291 = $args[0];
          ESLVal _v1290 = $args[1];
          return patternType.apply(_v1289,_v1287,_v1286,_v1285,_v1290,_v1283,_v1282,new ESLVal(new Function(new ESLVal("fun858"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal _v1293 = $args[0];
                ESLVal _v1292 = $args[1];
                return _v1281.apply(_v1291,_v1292);
                  }
                }));
            }
          }));
        }
        }
        }
        default: {ESLVal _v1294 = _v888;
          
          return error(new ESLVal("TypeError",_v1289,new ESLVal("expecting a bag type: ").add(ppType.apply(_v1294,_v1282))));
        }
      }
      }
    }
  });
  private static ESLVal setConsPatternType = new ESLVal(new Function(new ESLVal("setConsPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1275 = $args[0];
  ESLVal _v1274 = $args[1];
  ESLVal _v1273 = $args[2];
  ESLVal _v1272 = $args[3];
  ESLVal _v1271 = $args[4];
  ESLVal _v1270 = $args[5];
  ESLVal _v1269 = $args[6];
  ESLVal _v1268 = $args[7];
  ESLVal _v1267 = $args[8];
  {ESLVal _v887 = _v1272;
        
        switch(_v887.termName) {
        case "SetType": {ESLVal $1550 = _v887.termRef(0);
          ESLVal $1549 = _v887.termRef(1);
          
          {ESLVal ltl = $1550;
          
          {ESLVal et = $1549;
          
          return patternType.apply(_v1275,_v1274,substTypeEnv.apply(_v1268,et),_v1271,_v1270,_v1269,_v1268,new ESLVal(new Function(new ESLVal("fun859"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1277 = $args[0];
          ESLVal _v1276 = $args[1];
          return patternType.apply(_v1275,_v1273,_v1272,_v1271,_v1276,_v1269,_v1268,new ESLVal(new Function(new ESLVal("fun860"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal _v1279 = $args[0];
                ESLVal _v1278 = $args[1];
                return _v1267.apply(_v1277,_v1278);
                  }
                }));
            }
          }));
        }
        }
        }
        default: {ESLVal _v1280 = _v887;
          
          return error(new ESLVal("TypeError",_v1275,new ESLVal("expecting a set type: ").add(ppType.apply(_v1280,_v1268))));
        }
      }
      }
    }
  });
  private static ESLVal binExpType = new ESLVal(new Function(new ESLVal("binExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1265 = $args[0];
  ESLVal _v1264 = $args[1];
  ESLVal _v1263 = $args[2];
  ESLVal _v1262 = $args[3];
  ESLVal _v1261 = $args[4];
  ESLVal _v1260 = $args[5];
  ESLVal _v1259 = $args[6];
  ESLVal _v1258 = $args[7];
  {ESLVal _v886 = _v1263;
        
        switch(_v886.strVal) {
        case "+": return plusExpType.apply(_v1265,_v1264,_v1262,_v1261,_v1260,_v1259,_v1258);
      case "-": return subExpType.apply(_v1265,_v1264,_v1262,_v1261,_v1260,_v1259,_v1258);
      case "*": return mulExpType.apply(_v1265,_v1264,_v1262,_v1261,_v1260,_v1259,_v1258);
      case "/": return divExpType.apply(_v1265,_v1264,_v1262,_v1261,_v1260,_v1259,_v1258);
      case ":": return consExpType.apply(_v1265,_v1264,_v1262,_v1261,_v1260,_v1259,_v1258);
      case "=": return eqlExpType.apply(_v1265,_v1264,_v1262,_v1261,_v1260,_v1259,_v1258);
      case "<>": return neqlExpType.apply(_v1265,_v1264,_v1262,_v1261,_v1260,_v1259,_v1258);
      case "and": return andExpType.apply(_v1265,_v1264,_v1262,_v1261,_v1260,_v1259,_v1258);
      case "andalso": return andExpType.apply(_v1265,_v1264,_v1262,_v1261,_v1260,_v1259,_v1258);
      case "or": return orExpType.apply(_v1265,_v1264,_v1262,_v1261,_v1260,_v1259,_v1258);
      case "orelse": return orExpType.apply(_v1265,_v1264,_v1262,_v1261,_v1260,_v1259,_v1258);
      case ">": return compareExpType.apply(_v1265,_v1264,new ESLVal(">"),_v1262,_v1261,_v1260,_v1259,_v1258);
      case ">=": return compareExpType.apply(_v1265,_v1264,new ESLVal(">="),_v1262,_v1261,_v1260,_v1259,_v1258);
      case "<": return compareExpType.apply(_v1265,_v1264,new ESLVal("<"),_v1262,_v1261,_v1260,_v1259,_v1258);
      case "<=": return compareExpType.apply(_v1265,_v1264,new ESLVal("<="),_v1262,_v1261,_v1260,_v1259,_v1258);
      case "..": return dotDotExpType.apply(_v1265,_v1264,_v1262,_v1261,_v1260,_v1259,_v1258);
      case "%": return percentExpType.apply(_v1265,_v1264,_v1262,_v1261,_v1260,_v1259,_v1258);
      case "@": return atExpType.apply(_v1265,_v1264,_v1262,_v1261,_v1260,_v1259,_v1258);
        default: {ESLVal _v1266 = _v886;
          
          return error(new ESLVal("TypeError",_v1265,new ESLVal("unknown operator: ").add(_v1266)));
        }
      }
      }
    }
  });
  private static ESLVal andExpType = new ESLVal(new Function(new ESLVal("andExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1257 = $args[0];
  ESLVal _v1256 = $args[1];
  ESLVal _v1255 = $args[2];
  ESLVal _v1254 = $args[3];
  ESLVal _v1253 = $args[4];
  ESLVal _v1252 = $args[5];
  ESLVal _v1251 = $args[6];
  {ESLVal t1 = expType.apply(_v1256,_v1254,_v1253,_v1252,_v1251);
        ESLVal t2 = expType.apply(_v1255,_v1254,_v1253,_v1252,_v1251);
        
        if(isBoolType.apply(t1).and(isBoolType.apply(t2)).boolVal)
        return t1;
        else
          return error(new ESLVal("TypeError",_v1257,new ESLVal("and expects boolean arguments: ").add(ppType.apply(t1,_v1251).add(new ESLVal(" ").add(ppType.apply(t2,_v1251))))));
      }
    }
  });
  private static ESLVal atExpType = new ESLVal(new Function(new ESLVal("atExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1250 = $args[0];
  ESLVal _v1249 = $args[1];
  ESLVal _v1248 = $args[2];
  ESLVal _v1247 = $args[3];
  ESLVal _v1246 = $args[4];
  ESLVal _v1245 = $args[5];
  ESLVal _v1244 = $args[6];
  {ESLVal t1 = expType.apply(_v1249,_v1247,_v1246,_v1245,_v1244);
        ESLVal t2 = expType.apply(_v1248,_v1247,_v1246,_v1245,_v1244);
        
        if(typeEqual.apply(t1,t2).boolVal)
        return t1;
        else
          return error(new ESLVal("TypeError",_v1250,new ESLVal("@ expects arguments to be same type: ").add(ppType.apply(t1,_v1244).add(new ESLVal(" ").add(ppType.apply(t2,_v1244))))));
      }
    }
  });
  private static ESLVal dotDotExpType = new ESLVal(new Function(new ESLVal("dotDotExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1243 = $args[0];
  ESLVal _v1242 = $args[1];
  ESLVal _v1241 = $args[2];
  ESLVal _v1240 = $args[3];
  ESLVal _v1239 = $args[4];
  ESLVal _v1238 = $args[5];
  ESLVal _v1237 = $args[6];
  {ESLVal t1 = expType.apply(_v1242,_v1240,_v1239,_v1238,_v1237);
        ESLVal t2 = expType.apply(_v1241,_v1240,_v1239,_v1238,_v1237);
        
        if(isIntType.apply(t1).and(isIntType.apply(t2)).boolVal)
        return new ESLVal("ListType",_v1243,new ESLVal("IntType",_v1243));
        else
          return error(new ESLVal("TypeError",_v1243,new ESLVal(".. expects integer arguments: ").add(ppType.apply(t1,_v1237).add(new ESLVal(" ").add(ppType.apply(t2,_v1237))))));
      }
    }
  });
  private static ESLVal percentExpType = new ESLVal(new Function(new ESLVal("percentExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1236 = $args[0];
  ESLVal _v1235 = $args[1];
  ESLVal _v1234 = $args[2];
  ESLVal _v1233 = $args[3];
  ESLVal _v1232 = $args[4];
  ESLVal _v1231 = $args[5];
  ESLVal _v1230 = $args[6];
  {ESLVal t1 = expType.apply(_v1235,_v1233,_v1232,_v1231,_v1230);
        ESLVal t2 = expType.apply(_v1234,_v1233,_v1232,_v1231,_v1230);
        
        if(isIntType.apply(t1).and(isIntType.apply(t2)).boolVal)
        return new ESLVal("IntType",_v1236);
        else
          return error(new ESLVal("TypeError",_v1236,new ESLVal("% expects integer arguments: ").add(ppType.apply(t1,_v1230).add(new ESLVal(" ").add(ppType.apply(t2,_v1230))))));
      }
    }
  });
  private static ESLVal compareExpType = new ESLVal(new Function(new ESLVal("compareExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1229 = $args[0];
  ESLVal _v1228 = $args[1];
  ESLVal _v1227 = $args[2];
  ESLVal _v1226 = $args[3];
  ESLVal _v1225 = $args[4];
  ESLVal _v1224 = $args[5];
  ESLVal _v1223 = $args[6];
  ESLVal _v1222 = $args[7];
  {ESLVal t1 = expType.apply(_v1228,_v1225,_v1224,_v1223,_v1222);
        ESLVal t2 = expType.apply(_v1226,_v1225,_v1224,_v1223,_v1222);
        
        if(isNumType.apply(t1).and(isNumType.apply(t2)).boolVal)
        return new ESLVal("BoolType",_v1229);
        else
          return error(new ESLVal("TypeError",_v1229,_v1227.add(new ESLVal(" expects numeric arguments: ").add(ppType.apply(t1,_v1222).add(new ESLVal(" ").add(ppType.apply(t2,_v1222)))))));
      }
    }
  });
  private static ESLVal orExpType = new ESLVal(new Function(new ESLVal("orExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1221 = $args[0];
  ESLVal _v1220 = $args[1];
  ESLVal _v1219 = $args[2];
  ESLVal _v1218 = $args[3];
  ESLVal _v1217 = $args[4];
  ESLVal _v1216 = $args[5];
  ESLVal _v1215 = $args[6];
  {ESLVal t1 = expType.apply(_v1220,_v1218,_v1217,_v1216,_v1215);
        ESLVal t2 = expType.apply(_v1219,_v1218,_v1217,_v1216,_v1215);
        
        if(isBoolType.apply(t1).and(isBoolType.apply(t2)).boolVal)
        return t1;
        else
          return error(new ESLVal("TypeError",_v1221,new ESLVal("or expects boolean arguments: ").add(ppType.apply(t1,_v1215).add(new ESLVal(" ").add(ppType.apply(t2,_v1215))))));
      }
    }
  });
  private static ESLVal eqlExpType = new ESLVal(new Function(new ESLVal("eqlExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1214 = $args[0];
  ESLVal _v1213 = $args[1];
  ESLVal _v1212 = $args[2];
  ESLVal _v1211 = $args[3];
  ESLVal _v1210 = $args[4];
  ESLVal _v1209 = $args[5];
  ESLVal _v1208 = $args[6];
  {ESLVal t1 = expType.apply(_v1213,_v1211,_v1210,_v1209,_v1208);
        ESLVal t2 = expType.apply(_v1212,_v1211,_v1210,_v1209,_v1208);
        
        if(typeEqual.apply(t1,t2).boolVal)
        return new ESLVal("BoolType",_v1214);
        else
          return error(new ESLVal("TypeError",_v1214,new ESLVal("= expects types to agree: ").add(ppType.apply(t1,_v1208).add(new ESLVal(" <> ").add(ppType.apply(t2,_v1208))))));
      }
    }
  });
  private static ESLVal neqlExpType = new ESLVal(new Function(new ESLVal("neqlExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1207 = $args[0];
  ESLVal _v1206 = $args[1];
  ESLVal _v1205 = $args[2];
  ESLVal _v1204 = $args[3];
  ESLVal _v1203 = $args[4];
  ESLVal _v1202 = $args[5];
  ESLVal _v1201 = $args[6];
  {ESLVal t1 = expType.apply(_v1206,_v1204,_v1203,_v1202,_v1201);
        ESLVal t2 = expType.apply(_v1205,_v1204,_v1203,_v1202,_v1201);
        
        if(typeEqual.apply(t1,t2).boolVal)
        return new ESLVal("BoolType",_v1207);
        else
          return error(new ESLVal("TypeError",_v1207,new ESLVal("<> expects types to agree: ").add(ppType.apply(t1,_v1201).add(new ESLVal(" <> ").add(ppType.apply(t2,_v1201))))));
      }
    }
  });
  private static ESLVal consExpType = new ESLVal(new Function(new ESLVal("consExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1199 = $args[0];
  ESLVal _v1198 = $args[1];
  ESLVal _v1197 = $args[2];
  ESLVal _v1196 = $args[3];
  ESLVal _v1195 = $args[4];
  ESLVal _v1194 = $args[5];
  ESLVal _v1193 = $args[6];
  {ESLVal t1 = typeNF.apply(expType.apply(_v1198,_v1196,_v1195,_v1194,_v1193),_v1193);
        ESLVal t2 = typeNF.apply(expType.apply(_v1197,_v1196,_v1195,_v1194,_v1193),_v1193);
        
        {ESLVal _v885 = t2;
        ESLVal _v884 = t1;
        
        switch(_v885.termName) {
        case "ListType": {ESLVal $1548 = _v885.termRef(0);
          ESLVal $1547 = _v885.termRef(1);
          
          {ESLVal _v1200 = $1548;
          
          {ESLVal elementType = $1547;
          
          {ESLVal headType = _v884;
          
          if(subType.apply(headType,elementType).boolVal)
          return t2;
          else
            return error(new ESLVal("TypeError",_v1200,new ESLVal(": expects head type ").add(ppType.apply(headType,_v1193).add(new ESLVal(" and element type ").add(ppType.apply(elementType,_v1193).add(new ESLVal(" to agree")))))));
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(59705,59986)").add(ESLVal.list(_v885,_v884)));
      }
      }
      }
    }
  });
  private static ESLVal divExpType = new ESLVal(new Function(new ESLVal("divExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1186 = $args[0];
  ESLVal _v1185 = $args[1];
  ESLVal _v1184 = $args[2];
  ESLVal _v1183 = $args[3];
  ESLVal _v1182 = $args[4];
  ESLVal _v1181 = $args[5];
  ESLVal _v1180 = $args[6];
  {ESLVal t1 = expType.apply(_v1185,_v1183,_v1182,_v1181,_v1180);
        ESLVal t2 = expType.apply(_v1184,_v1183,_v1182,_v1181,_v1180);
        
        {ESLVal _v883 = t1;
        ESLVal _v882 = t2;
        
        switch(_v883.termName) {
        case "IntType": {ESLVal $1545 = _v883.termRef(0);
          
          switch(_v882.termName) {
          case "IntType": {ESLVal $1546 = _v882.termRef(0);
            
            {ESLVal l1 = $1545;
            
            {ESLVal l2 = $1546;
            
            return t1;
          }
          }
          }
          default: {ESLVal _v1189 = _v883;
            
            {ESLVal _v1190 = _v882;
            
            return error(new ESLVal("TypeError",_v1186,new ESLVal("incomptible types for /: ").add(ppType.apply(_v1189,_v1180).add(new ESLVal(" and ").add(ppType.apply(_v1190,_v1180))))));
          }
          }
        }
        }
      case "FloatType": {ESLVal $1543 = _v883.termRef(0);
          
          switch(_v882.termName) {
          case "FloatType": {ESLVal $1544 = _v882.termRef(0);
            
            {ESLVal l1 = $1543;
            
            {ESLVal l2 = $1544;
            
            return t1;
          }
          }
          }
          default: {ESLVal _v1187 = _v883;
            
            {ESLVal _v1188 = _v882;
            
            return error(new ESLVal("TypeError",_v1186,new ESLVal("incomptible types for /: ").add(ppType.apply(_v1187,_v1180).add(new ESLVal(" and ").add(ppType.apply(_v1188,_v1180))))));
          }
          }
        }
        }
        default: {ESLVal _v1191 = _v883;
          
          {ESLVal _v1192 = _v882;
          
          return error(new ESLVal("TypeError",_v1186,new ESLVal("incomptible types for /: ").add(ppType.apply(_v1191,_v1180).add(new ESLVal(" and ").add(ppType.apply(_v1192,_v1180))))));
        }
        }
      }
      }
      }
    }
  });
  private static ESLVal mulExpType = new ESLVal(new Function(new ESLVal("mulExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1173 = $args[0];
  ESLVal _v1172 = $args[1];
  ESLVal _v1171 = $args[2];
  ESLVal _v1170 = $args[3];
  ESLVal _v1169 = $args[4];
  ESLVal _v1168 = $args[5];
  ESLVal _v1167 = $args[6];
  {ESLVal t1 = expType.apply(_v1172,_v1170,_v1169,_v1168,_v1167);
        ESLVal t2 = expType.apply(_v1171,_v1170,_v1169,_v1168,_v1167);
        
        {ESLVal _v881 = t1;
        ESLVal _v880 = t2;
        
        switch(_v881.termName) {
        case "IntType": {ESLVal $1540 = _v881.termRef(0);
          
          switch(_v880.termName) {
          case "IntType": {ESLVal $1542 = _v880.termRef(0);
            
            {ESLVal l1 = $1540;
            
            {ESLVal l2 = $1542;
            
            return t1;
          }
          }
          }
        case "FloatType": {ESLVal $1541 = _v880.termRef(0);
            
            {ESLVal l1 = $1540;
            
            {ESLVal l2 = $1541;
            
            return t2;
          }
          }
          }
          default: {ESLVal _v1176 = _v881;
            
            {ESLVal _v1177 = _v880;
            
            return error(new ESLVal("TypeError",_v1173,new ESLVal("incomptible types for *: ").add(ppType.apply(_v1176,_v1167).add(new ESLVal(" and ").add(ppType.apply(_v1177,_v1167))))));
          }
          }
        }
        }
      case "FloatType": {ESLVal $1537 = _v881.termRef(0);
          
          switch(_v880.termName) {
          case "FloatType": {ESLVal $1539 = _v880.termRef(0);
            
            {ESLVal l1 = $1537;
            
            {ESLVal l2 = $1539;
            
            return t1;
          }
          }
          }
        case "IntType": {ESLVal $1538 = _v880.termRef(0);
            
            {ESLVal l1 = $1537;
            
            {ESLVal l2 = $1538;
            
            return t1;
          }
          }
          }
          default: {ESLVal _v1174 = _v881;
            
            {ESLVal _v1175 = _v880;
            
            return error(new ESLVal("TypeError",_v1173,new ESLVal("incomptible types for *: ").add(ppType.apply(_v1174,_v1167).add(new ESLVal(" and ").add(ppType.apply(_v1175,_v1167))))));
          }
          }
        }
        }
        default: {ESLVal _v1178 = _v881;
          
          {ESLVal _v1179 = _v880;
          
          return error(new ESLVal("TypeError",_v1173,new ESLVal("incomptible types for *: ").add(ppType.apply(_v1178,_v1167).add(new ESLVal(" and ").add(ppType.apply(_v1179,_v1167))))));
        }
        }
      }
      }
      }
    }
  });
  private static ESLVal subExpType = new ESLVal(new Function(new ESLVal("subExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1160 = $args[0];
  ESLVal _v1159 = $args[1];
  ESLVal _v1158 = $args[2];
  ESLVal _v1157 = $args[3];
  ESLVal _v1156 = $args[4];
  ESLVal _v1155 = $args[5];
  ESLVal _v1154 = $args[6];
  {ESLVal t1 = expType.apply(_v1159,_v1157,_v1156,_v1155,_v1154);
        ESLVal t2 = expType.apply(_v1158,_v1157,_v1156,_v1155,_v1154);
        
        {ESLVal _v879 = t1;
        ESLVal _v878 = t2;
        
        switch(_v879.termName) {
        case "IntType": {ESLVal $1534 = _v879.termRef(0);
          
          switch(_v878.termName) {
          case "IntType": {ESLVal $1536 = _v878.termRef(0);
            
            {ESLVal l1 = $1534;
            
            {ESLVal l2 = $1536;
            
            return t1;
          }
          }
          }
        case "FloatType": {ESLVal $1535 = _v878.termRef(0);
            
            {ESLVal l1 = $1534;
            
            {ESLVal l2 = $1535;
            
            return t2;
          }
          }
          }
          default: {ESLVal _v1163 = _v879;
            
            {ESLVal _v1164 = _v878;
            
            return error(new ESLVal("TypeError",_v1160,new ESLVal("incomptible types for -: ").add(ppType.apply(_v1163,_v1154).add(new ESLVal(" and ").add(ppType.apply(_v1164,_v1154))))));
          }
          }
        }
        }
      case "FloatType": {ESLVal $1531 = _v879.termRef(0);
          
          switch(_v878.termName) {
          case "FloatType": {ESLVal $1533 = _v878.termRef(0);
            
            {ESLVal l1 = $1531;
            
            {ESLVal l2 = $1533;
            
            return t1;
          }
          }
          }
        case "IntType": {ESLVal $1532 = _v878.termRef(0);
            
            {ESLVal l1 = $1531;
            
            {ESLVal l2 = $1532;
            
            return t1;
          }
          }
          }
          default: {ESLVal _v1161 = _v879;
            
            {ESLVal _v1162 = _v878;
            
            return error(new ESLVal("TypeError",_v1160,new ESLVal("incomptible types for -: ").add(ppType.apply(_v1161,_v1154).add(new ESLVal(" and ").add(ppType.apply(_v1162,_v1154))))));
          }
          }
        }
        }
        default: {ESLVal _v1165 = _v879;
          
          {ESLVal _v1166 = _v878;
          
          return error(new ESLVal("TypeError",_v1160,new ESLVal("incomptible types for -: ").add(ppType.apply(_v1165,_v1154).add(new ESLVal(" and ").add(ppType.apply(_v1166,_v1154))))));
        }
        }
      }
      }
      }
    }
  });
  private static ESLVal plusExpType = new ESLVal(new Function(new ESLVal("plusExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1119 = $args[0];
  ESLVal _v1118 = $args[1];
  ESLVal _v1117 = $args[2];
  ESLVal _v1116 = $args[3];
  ESLVal _v1115 = $args[4];
  ESLVal _v1114 = $args[5];
  ESLVal _v1113 = $args[6];
  {ESLVal t1 = expType.apply(_v1118,_v1116,_v1115,_v1114,_v1113);
        ESLVal t2 = expType.apply(_v1117,_v1116,_v1115,_v1114,_v1113);
        
        {ESLVal _v877 = t1;
        ESLVal _v876 = t2;
        
        switch(_v877.termName) {
        case "StrType": {ESLVal $1530 = _v877.termRef(0);
          
          {ESLVal _v1148 = $1530;
          
          {ESLVal _v1149 = _v876;
          
          return t1;
        }
        }
        }
      case "IntType": {ESLVal $1528 = _v877.termRef(0);
          
          switch(_v876.termName) {
          case "IntType": {ESLVal $1529 = _v876.termRef(0);
            
            {ESLVal l1 = $1528;
            
            {ESLVal l2 = $1529;
            
            return t1;
          }
          }
          }
          default: switch(_v876.termName) {
            case "StrType": {ESLVal $1517 = _v876.termRef(0);
              
              {ESLVal _v1144 = _v877;
              
              {ESLVal _v1145 = $1517;
              
              return t2;
            }
            }
            }
            default: {ESLVal _v1146 = _v877;
              
              {ESLVal _v1147 = _v876;
              
              return error(new ESLVal("TypeError",_v1119,new ESLVal("incomptible types for +: ").add(ppType.apply(_v1146,_v1113).add(new ESLVal(" and ").add(ppType.apply(_v1147,_v1113))))));
            }
            }
          }
        }
        }
      case "FloatType": {ESLVal $1526 = _v877.termRef(0);
          
          switch(_v876.termName) {
          case "FloatType": {ESLVal $1527 = _v876.termRef(0);
            
            {ESLVal l1 = $1526;
            
            {ESLVal l2 = $1527;
            
            return t1;
          }
          }
          }
          default: switch(_v876.termName) {
            case "StrType": {ESLVal $1517 = _v876.termRef(0);
              
              {ESLVal _v1140 = _v877;
              
              {ESLVal _v1141 = $1517;
              
              return t2;
            }
            }
            }
            default: {ESLVal _v1142 = _v877;
              
              {ESLVal _v1143 = _v876;
              
              return error(new ESLVal("TypeError",_v1119,new ESLVal("incomptible types for +: ").add(ppType.apply(_v1142,_v1113).add(new ESLVal(" and ").add(ppType.apply(_v1143,_v1113))))));
            }
            }
          }
        }
        }
      case "ListType": {ESLVal $1523 = _v877.termRef(0);
          ESLVal $1522 = _v877.termRef(1);
          
          switch(_v876.termName) {
          case "ListType": {ESLVal $1525 = _v876.termRef(0);
            ESLVal $1524 = _v876.termRef(1);
            
            {ESLVal l1 = $1523;
            
            {ESLVal _v1130 = $1522;
            
            {ESLVal l2 = $1525;
            
            {ESLVal _v1131 = $1524;
            
            if(typeEqual.apply(_v1130,_v1131).boolVal)
            return new ESLVal("ListType",l1,_v1130);
            else
              switch(_v876.termName) {
                case "StrType": {ESLVal $1517 = _v876.termRef(0);
                  
                  {ESLVal _v1132 = _v877;
                  
                  {ESLVal _v1133 = $1517;
                  
                  return _v1131;
                }
                }
                }
                default: {ESLVal _v1134 = _v877;
                  
                  {ESLVal _v1135 = _v876;
                  
                  return error(new ESLVal("TypeError",_v1119,new ESLVal("incomptible types for +: ").add(ppType.apply(_v1134,_v1113).add(new ESLVal(" and ").add(ppType.apply(_v1135,_v1113))))));
                }
                }
              }
          }
          }
          }
          }
          }
          default: switch(_v876.termName) {
            case "StrType": {ESLVal $1517 = _v876.termRef(0);
              
              {ESLVal _v1136 = _v877;
              
              {ESLVal _v1137 = $1517;
              
              return t2;
            }
            }
            }
            default: {ESLVal _v1138 = _v877;
              
              {ESLVal _v1139 = _v876;
              
              return error(new ESLVal("TypeError",_v1119,new ESLVal("incomptible types for +: ").add(ppType.apply(_v1138,_v1113).add(new ESLVal(" and ").add(ppType.apply(_v1139,_v1113))))));
            }
            }
          }
        }
        }
      case "SetType": {ESLVal $1519 = _v877.termRef(0);
          ESLVal $1518 = _v877.termRef(1);
          
          switch(_v876.termName) {
          case "SetType": {ESLVal $1521 = _v876.termRef(0);
            ESLVal $1520 = _v876.termRef(1);
            
            {ESLVal l1 = $1519;
            
            {ESLVal _v1120 = $1518;
            
            {ESLVal l2 = $1521;
            
            {ESLVal _v1121 = $1520;
            
            if(typeEqual.apply(_v1120,_v1121).boolVal)
            return new ESLVal("SetType",l1,_v1120);
            else
              switch(_v876.termName) {
                case "StrType": {ESLVal $1517 = _v876.termRef(0);
                  
                  {ESLVal _v1122 = _v877;
                  
                  {ESLVal _v1123 = $1517;
                  
                  return _v1121;
                }
                }
                }
                default: {ESLVal _v1124 = _v877;
                  
                  {ESLVal _v1125 = _v876;
                  
                  return error(new ESLVal("TypeError",_v1119,new ESLVal("incomptible types for +: ").add(ppType.apply(_v1124,_v1113).add(new ESLVal(" and ").add(ppType.apply(_v1125,_v1113))))));
                }
                }
              }
          }
          }
          }
          }
          }
          default: switch(_v876.termName) {
            case "StrType": {ESLVal $1517 = _v876.termRef(0);
              
              {ESLVal _v1126 = _v877;
              
              {ESLVal _v1127 = $1517;
              
              return t2;
            }
            }
            }
            default: {ESLVal _v1128 = _v877;
              
              {ESLVal _v1129 = _v876;
              
              return error(new ESLVal("TypeError",_v1119,new ESLVal("incomptible types for +: ").add(ppType.apply(_v1128,_v1113).add(new ESLVal(" and ").add(ppType.apply(_v1129,_v1113))))));
            }
            }
          }
        }
        }
        default: switch(_v876.termName) {
          case "StrType": {ESLVal $1517 = _v876.termRef(0);
            
            {ESLVal _v1150 = _v877;
            
            {ESLVal _v1151 = $1517;
            
            return t2;
          }
          }
          }
          default: {ESLVal _v1152 = _v877;
            
            {ESLVal _v1153 = _v876;
            
            return error(new ESLVal("TypeError",_v1119,new ESLVal("incomptible types for +: ").add(ppType.apply(_v1152,_v1113).add(new ESLVal(" and ").add(ppType.apply(_v1153,_v1113))))));
          }
          }
        }
      }
      }
      }
    }
  });
  private static ESLVal applyTypeExp = new ESLVal(new Function(new ESLVal("applyTypeExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1108 = $args[0];
  ESLVal _v1107 = $args[1];
  ESLVal _v1106 = $args[2];
  ESLVal _v1105 = $args[3];
  ESLVal _v1104 = $args[4];
  ESLVal _v1103 = $args[5];
  ESLVal _v1102 = $args[6];
  {ESLVal _v1110 = substTypesEnv.apply(_v1102,_v1106);
        ESLVal _v1109 = expType.apply(_v1107,_v1105,_v1104,_v1103,_v1102);
        
        {ESLVal _v875 = _v1109;
        
        switch(_v875.termName) {
        case "ForallType": {ESLVal $1516 = _v875.termRef(0);
          ESLVal $1515 = _v875.termRef(1);
          ESLVal $1514 = _v875.termRef(2);
          
          {ESLVal l1 = $1516;
          
          {ESLVal ns = $1515;
          
          {ESLVal _v1111 = $1514;
          
          if(length.apply(ns).eql(length.apply(_v1110)).boolVal)
          {ESLVal env = zipTypeEnv.apply(ns,_v1110);
            
            return substTypeEnv.apply(env.add(_v1104),_v1111);
          }
          else
            return error(new ESLVal("TypeError",_v1108,new ESLVal("universal type expects ").add(length.apply(ns).add(new ESLVal(" types, but supplied with ").add(length.apply(_v1110))))));
        }
        }
        }
        }
        default: {ESLVal _v1112 = _v875;
          
          return error(new ESLVal("TypeError",_v1108,new ESLVal("expecting a universal type: ").add(_v1112)));
        }
      }
      }
      }
    }
  });
  private static ESLVal expTypes = new ESLVal(new Function(new ESLVal("expTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1101 = $args[0];
  ESLVal _v1100 = $args[1];
  ESLVal _v1099 = $args[2];
  ESLVal _v1098 = $args[3];
  ESLVal _v1097 = $args[4];
  return map.apply(new ESLVal(new Function(new ESLVal("fun861"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal e = $args[0];
        return expType.apply(e,_v1100,_v1099,_v1098,_v1097);
          }
        }),_v1101);
    }
  });
  private static ESLVal applyType = new ESLVal(new Function(new ESLVal("applyType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1096 = $args[0];
  ESLVal _v1095 = $args[1];
  ESLVal _v1094 = $args[2];
  ESLVal _v1093 = $args[3];
  ESLVal _v1092 = $args[4];
  ESLVal _v1091 = $args[5];
  ESLVal _v1090 = $args[6];
  {ESLVal _v874 = typeNF.apply(expType.apply(_v1095,_v1093,_v1092,_v1091,_v1090),_v1090);
        
        switch(_v874.termName) {
        case "FunType": {ESLVal $1513 = _v874.termRef(0);
          ESLVal $1512 = _v874.termRef(1);
          ESLVal $1511 = _v874.termRef(2);
          
          {ESLVal l1 = $1513;
          
          {ESLVal domain = $1512;
          
          {ESLVal range = $1511;
          
          {ESLVal supplied = expTypes.apply(_v1094,_v1093,_v1092,_v1091,_v1090);
          
          if(length.apply(domain).eql(length.apply(supplied)).boolVal)
          if(subTypes.apply(supplied,domain).boolVal)
            return range;
            else
              return error(new ESLVal("TypeError",_v1096,new ESLVal("supplied argument types ").add(ppTypes.apply(supplied,_v1090).add(new ESLVal(" do not match function domain ").add(ppTypes.apply(domain,_v1090))))));
          else
            return error(new ESLVal("TypeError",_v1096,new ESLVal("expecting ").add(length.apply(domain).add(new ESLVal(" args, but supplied with ").add(length.apply(supplied))))));
        }
        }
        }
        }
        }
        default: {ESLVal t = _v874;
          
          return error(new ESLVal("TypeError",_v1096,new ESLVal("unknown type for apply: ").add(ppType.apply(t,_v1090))));
        }
      }
      }
    }
  });
  private static ESLVal ifType = new ESLVal(new Function(new ESLVal("ifType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1089 = $args[0];
  ESLVal _v1088 = $args[1];
  ESLVal _v1087 = $args[2];
  ESLVal _v1086 = $args[3];
  ESLVal _v1085 = $args[4];
  ESLVal _v1084 = $args[5];
  ESLVal _v1083 = $args[6];
  ESLVal _v1082 = $args[7];
  {ESLVal testType = expType.apply(_v1088,_v1085,_v1084,_v1083,_v1082);
        
        if(isBoolType.apply(testType).boolVal)
        {ESLVal conseqType = expType.apply(_v1087,_v1085,_v1084,_v1083,_v1082);
          ESLVal altType = expType.apply(_v1086,_v1085,_v1084,_v1083,_v1082);
          
          if(typeEqual.apply(conseqType,altType).boolVal)
          return conseqType;
          else
            return error(new ESLVal("TypeError",_v1089,new ESLVal("conseq and alt types do not agree: ").add(ppType.apply(conseqType,_v1082).add(new ESLVal(" ").add(ppType.apply(altType,_v1082))))));
        }
        else
          return error(new ESLVal("if expects a bool ").add(ppType.apply(testType,_v1082)));
      }
    }
  });
  private static ESLVal checkDecs = new ESLVal(new Function(new ESLVal("checkDecs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal ds = $args[0];
  {ESLVal _v872 = ds;
        
        if(_v872.isCons())
        {ESLVal $1509 = _v872.head();
          ESLVal $1510 = _v872.tail();
          
          {ESLVal d = $1509;
          
          {ESLVal _v1080 = $1510;
          
          if(member.apply(decName.apply(d),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v873 = $qualArg;
              
              {ESLVal _v1081 = _v873;
              
              return ESLVal.list(ESLVal.list(decName.apply(_v1081)));
            }
            }
          }
        }).map(_v1080).flatten().flatten()).boolVal)
          return error(new ESLVal("TypeError",decLoc.apply(d),new ESLVal(" duplicate argument ").add(decName.apply(d))));
          else
            return checkDecs.apply(_v1080);
        }
        }
        }
      else if(_v872.isNil())
        return $null;
      else return error(new ESLVal("case error at Pos(64852,65085)").add(ESLVal.list(_v872)));
      }
    }
  });
  private static ESLVal funType = new ESLVal(new Function(new ESLVal("funType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1077 = $args[0];
  ESLVal _v1076 = $args[1];
  ESLVal _v1075 = $args[2];
  ESLVal _v1074 = $args[3];
  ESLVal _v1073 = $args[4];
  ESLVal _v1072 = $args[5];
  ESLVal _v1071 = $args[6];
  ESLVal _v1070 = $args[7];
  ESLVal _v1069 = $args[8];
  {checkDecs.apply(_v1075);
      {ESLVal nType = expType.apply(_v1076,_v1072,_v1071,_v1070,_v1069);
        
        if(isStrType.apply(nType).boolVal)
        {ESLVal declaredType = substTypeEnv.apply(_v1069,_v1074);
          
          return decTypes.apply(_v1075,_v1071,_v1069,new ESLVal(new Function(new ESLVal("fun862"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1079 = $args[0];
          ESLVal _v1078 = $args[1];
          {ESLVal actualRange = expType.apply(_v1073,_v1072,_v1078,_v1070,_v1069);
                
                if(subType.apply(new ESLVal("FunType",_v1077,_v1079,actualRange),declaredType).boolVal)
                return new ESLVal("FunType",_v1077,_v1079,actualRange);
                else
                  return error(new ESLVal("TypeError",_v1077,new ESLVal("function declared type ").add(ppType.apply(declaredType,_v1069).add(new ESLVal(" but is ").add(ppType.apply(new ESLVal("FunType",_v1077,_v1079,actualRange),_v1069))))));
              }
            }
          }));
        }
        else
          return error(new ESLVal("TypeError",_v1077,new ESLVal("expecting a string for a function name: ").add(_v1076)));
      }}
    }
  });
  private static ESLVal decTypes = new ESLVal(new Function(new ESLVal("decTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1065 = $args[0];
  ESLVal _v1064 = $args[1];
  ESLVal _v1063 = $args[2];
  ESLVal _v1062 = $args[3];
  LetRec letrec = new LetRec() {
        ESLVal processDecs = new ESLVal(new Function(new ESLVal("processDecs"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1067 = $args[0];
          ESLVal _v1066 = $args[1];
          {ESLVal _v871 = _v1067;
                
                if(_v871.isCons())
                {ESLVal $1503 = _v871.head();
                  ESLVal $1504 = _v871.tail();
                  
                  switch($1503.termName) {
                  case "Dec": {ESLVal $1508 = $1503.termRef(0);
                    ESLVal $1507 = $1503.termRef(1);
                    ESLVal $1506 = $1503.termRef(2);
                    ESLVal $1505 = $1503.termRef(3);
                    
                    {ESLVal l = $1508;
                    
                    {ESLVal n = $1507;
                    
                    {ESLVal t = $1506;
                    
                    {ESLVal st = $1505;
                    
                    {ESLVal _v1068 = $1504;
                    
                    return processDecs.apply(_v1068,_v1066.cons(new ESLVal("Map",n,substTypeEnv.apply(_v1063,t))));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(66278,66503)").add(ESLVal.list(_v871)));
                }
                }
              else if(_v871.isNil())
                return _v1062.apply(reverse.apply(typeEnvRan.apply(_v1066)),_v1066.add(_v1064));
              else return error(new ESLVal("case error at Pos(66278,66503)").add(ESLVal.list(_v871)));
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "processDecs": return processDecs;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal processDecs = letrec.get("processDecs");
      
        return processDecs.apply(_v1065,$nil);
      
    }
  });
  private static ESLVal termType = new ESLVal(new Function(new ESLVal("termType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1061 = $args[0];
  ESLVal _v1060 = $args[1];
  ESLVal _v1059 = $args[2];
  ESLVal _v1058 = $args[3];
  ESLVal _v1057 = $args[4];
  ESLVal _v1056 = $args[5];
  ESLVal _v1055 = $args[6];
  ESLVal _v1054 = $args[7];
  {ESLVal t0 = lookupType.apply(_v1060,_v1055);
        
        if(t0.eql($null).boolVal)
        return error(new ESLVal("TypeError",_v1061,new ESLVal("cannot find cnstr ").add(_v1060)));
        else
          {ESLVal t = unfoldIf.apply(t0);
            
            return termTypeCheckUnion.apply(t,_v1061,_v1060,_v1059,_v1058,_v1057,_v1056,_v1055,_v1054);
          }
      }
    }
  });
  private static ESLVal termTypeCheckUnion = new ESLVal(new Function(new ESLVal("termTypeCheckUnion"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1051 = $args[0];
  ESLVal _v1050 = $args[1];
  ESLVal _v1049 = $args[2];
  ESLVal _v1048 = $args[3];
  ESLVal _v1047 = $args[4];
  ESLVal _v1046 = $args[5];
  ESLVal _v1045 = $args[6];
  ESLVal _v1044 = $args[7];
  ESLVal _v1043 = $args[8];
  if(_v1051.eql($null).boolVal)
        return error(new ESLVal("TypeError",_v1050,new ESLVal("cannot find constructor ").add(_v1049)));
        else
          {ESLVal _v869 = _v1051;
            
            switch(_v869.termName) {
            case "TypeFun": {ESLVal $1500 = _v869.termRef(0);
              ESLVal $1499 = _v869.termRef(1);
              ESLVal $1498 = _v869.termRef(2);
              
              {ESLVal lf = $1500;
              
              {ESLVal ns = $1499;
              
              {ESLVal body = $1498;
              
              if(length.apply(ns).eql(length.apply(_v1048)).boolVal)
              {ESLVal args = map.apply(new ESLVal(new Function(new ESLVal("fun863"),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      ESLVal _v1052 = $args[0];
                  return substTypeEnv.apply(_v1043,_v1052);
                    }
                  }),_v1048);
                
                {ESLVal _v870 = substTypeEnv.apply(zipTypeEnv.apply(ns,args),body);
                
                switch(_v870.termName) {
                case "UnionType": {ESLVal $1502 = _v870.termRef(0);
                  ESLVal $1501 = _v870.termRef(1);
                  
                  {ESLVal l1 = $1502;
                  
                  {ESLVal terms = $1501;
                  
                  {ESLVal ts2 = findTermArgTypes.apply(_v1049,terms);
                  
                  if(length.apply(_v1047).eql(length.apply(ts2)).boolVal)
                  {checkTermArgTypes.apply(_v1050,_v1047,ts2,_v1046,_v1045,_v1044,_v1043);
                  return new ESLVal("UnionType",l1,terms);}
                  else
                    return error(_v1049.add(new ESLVal(" expects ").add(length.apply(ts2).add(new ESLVal(" args, but you supplied ").add(length.apply(_v1047))))));
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(67376,67926)").add(ESLVal.list(_v870)));
              }
              }
              }
              else
                return error(new ESLVal("TypeError",_v1050,new ESLVal("generic constructor ").add(_v1049.add(new ESLVal(" expects ").add(length.apply(ns).add(new ESLVal(" type arguments, but received ").add(length.apply(_v1048))))))));
            }
            }
            }
            }
          case "UnionType": {ESLVal $1497 = _v869.termRef(0);
              ESLVal $1496 = _v869.termRef(1);
              
              {ESLVal l1 = $1497;
              
              {ESLVal terms = $1496;
              
              {ESLVal ts2 = findTermArgTypes.apply(_v1049,terms);
              
              if(length.apply(_v1048).neql($zero).boolVal)
              return error(new ESLVal("TypeError",_v1050,new ESLVal("generic application of non-generic constructior: ").add(_v1049)));
              else
                if(length.apply(_v1047).eql(length.apply(ts2)).boolVal)
                  {checkTermArgTypes.apply(_v1050,_v1047,ts2,_v1046,_v1045,_v1044,_v1043);
                  return _v1051;}
                  else
                    return error(_v1049.add(new ESLVal(" expects ").add(length.apply(ts2).add(new ESLVal(" args, but you supplied ").add(length.apply(_v1047))))));
            }
            }
            }
            }
            default: {ESLVal _v1053 = _v869;
              
              return error(new ESLVal("TypeError",_v1050,new ESLVal("expecting a union type for ").add(_v1049.add(new ESLVal(" but got ").add(ppType.apply(_v1053,_v1043))))));
            }
          }
          }
    }
  });
  private static ESLVal unfoldIf = new ESLVal(new Function(new ESLVal("unfoldIf"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v868 = t;
        
        switch(_v868.termName) {
        case "RecType": {ESLVal $1495 = _v868.termRef(0);
          ESLVal $1494 = _v868.termRef(1);
          ESLVal $1493 = _v868.termRef(2);
          
          {ESLVal l = $1495;
          
          {ESLVal n = $1494;
          
          {ESLVal _v1041 = $1493;
          
          return unfoldIf.apply(unfoldType.apply(l,n,_v1041));
        }
        }
        }
        }
        default: {ESLVal _v1042 = _v868;
          
          return _v1042;
        }
      }
      }
    }
  });
  private static ESLVal findTermArgTypes = new ESLVal(new Function(new ESLVal("findTermArgTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal n = $args[0];
  ESLVal terms = $args[1];
  {ESLVal _v867 = terms;
        
        if(_v867.isCons())
        {ESLVal $1488 = _v867.head();
          ESLVal $1489 = _v867.tail();
          
          switch($1488.termName) {
          case "TermType": {ESLVal $1492 = $1488.termRef(0);
            ESLVal $1491 = $1488.termRef(1);
            ESLVal $1490 = $1488.termRef(2);
            
            {ESLVal l = $1492;
            
            {ESLVal nn = $1491;
            
            {ESLVal ts = $1490;
            
            {ESLVal _v1039 = $1489;
            
            if(nn.eql(n).boolVal)
            return ts;
            else
              {ESLVal t = $1488;
                
                {ESLVal _v1040 = $1489;
                
                return findTermArgTypes.apply(n,_v1040);
              }
              }
          }
          }
          }
          }
          }
          default: {ESLVal t = $1488;
            
            {ESLVal ts = $1489;
            
            return findTermArgTypes.apply(n,ts);
          }
          }
        }
        }
      else if(_v867.isNil())
        return error(new ESLVal("cannot find constructor ").add(n));
      else return error(new ESLVal("case error at Pos(68922,69122)").add(ESLVal.list(_v867)));
      }
    }
  });
  private static ESLVal checkTermArgTypes = new ESLVal(new Function(new ESLVal("checkTermArgTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1036 = $args[0];
  ESLVal _v1035 = $args[1];
  ESLVal _v1034 = $args[2];
  ESLVal _v1033 = $args[3];
  ESLVal _v1032 = $args[4];
  ESLVal _v1031 = $args[5];
  ESLVal _v1030 = $args[6];
  {ESLVal _v866 = _v1035;
        ESLVal _v865 = _v1034;
        
        if(_v866.isCons())
        {ESLVal $1482 = _v866.head();
          ESLVal $1483 = _v866.tail();
          
          if(_v865.isCons())
          {ESLVal $1484 = _v865.head();
            ESLVal $1485 = _v865.tail();
            
            {ESLVal e = $1482;
            
            {ESLVal _v1037 = $1483;
            
            {ESLVal t = $1484;
            
            {ESLVal _v1038 = $1485;
            
            {ESLVal tt = expType.apply(e,_v1033,_v1032,_v1031,_v1030);
            
            if(typeEqual.apply(t,tt).boolVal)
            return checkTermArgTypes.apply(_v1036,_v1037,_v1038,_v1033,_v1032,_v1031,_v1030);
            else
              return error(new ESLVal("TypeError",_v1036,new ESLVal("expected constructor arg type ").add(ppType.apply(t,_v1030).add(new ESLVal(" but supplied ").add(ppType.apply(tt,_v1030))))));
          }
          }
          }
          }
          }
          }
        else if(_v865.isNil())
          return error(new ESLVal("case error at Pos(69240,69662)").add(ESLVal.list(_v866,_v865)));
        else return error(new ESLVal("case error at Pos(69240,69662)").add(ESLVal.list(_v866,_v865)));
        }
      else if(_v866.isNil())
        if(_v865.isCons())
          {ESLVal $1486 = _v865.head();
            ESLVal $1487 = _v865.tail();
            
            return error(new ESLVal("case error at Pos(69240,69662)").add(ESLVal.list(_v866,_v865)));
          }
        else if(_v865.isNil())
          return $null;
        else return error(new ESLVal("case error at Pos(69240,69662)").add(ESLVal.list(_v866,_v865)));
      else return error(new ESLVal("case error at Pos(69240,69662)").add(ESLVal.list(_v866,_v865)));
      }
    }
  });
  private static ESLVal notType = new ESLVal(new Function(new ESLVal("notType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1028 = $args[0];
  ESLVal _v1027 = $args[1];
  ESLVal _v1026 = $args[2];
  ESLVal _v1025 = $args[3];
  ESLVal _v1024 = $args[4];
  ESLVal _v1023 = $args[5];
  {ESLVal _v864 = expType.apply(_v1027,_v1026,_v1025,_v1024,_v1023);
        
        switch(_v864.termName) {
        case "BoolType": {ESLVal $1481 = _v864.termRef(0);
          
          {ESLVal _v1029 = $1481;
          
          return new ESLVal("BoolType",_v1029);
        }
        }
        default: {ESLVal t = _v864;
          
          return error(new ESLVal("TypeError",_v1028,new ESLVal("expecting a boolean: ").add(ppType.apply(t,_v1023))));
        }
      }
      }
    }
  });
  private static ESLVal varType = new ESLVal(new Function(new ESLVal("varType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal n = $args[1];
  ESLVal valueEnv = $args[2];
  {ESLVal t = lookupType.apply(n,valueEnv);
        
        if(t.eql($null).boolVal)
        return error(new ESLVal("TypeError",l,new ESLVal("unbound variable ").add(n)));
        else
          {ESLVal _v863 = t;
            
            switch(_v863.termName) {
            case "TypeClosure": {ESLVal $1480 = _v863.termRef(0);
              
              {ESLVal f = $1480;
              
              return f.apply();
            }
            }
            default: {ESLVal _v1022 = _v863;
              
              return _v1022;
            }
          }
          }
      }
    }
  });
  private static ESLVal blockType = new ESLVal(new Function(new ESLVal("blockType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1021 = $args[0];
  ESLVal _v1020 = $args[1];
  ESLVal _v1019 = $args[2];
  ESLVal _v1018 = $args[3];
  ESLVal _v1017 = $args[4];
  ESLVal _v1016 = $args[5];
  {ESLVal[] t = new ESLVal[]{new ESLVal("VoidType",_v1021)};
        
        {{
        ESLVal _v862 = _v1020;
        while(_v862.isCons()) {
          ESLVal e = _v862.headVal;
          t[0] = expType.apply(e,_v1019,_v1018,_v1017,_v1016);
          _v862 = _v862.tailVal;}
      }
      return t[0];}
      }
    }
  });
  private static ESLVal listType = new ESLVal(new Function(new ESLVal("listType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1015 = $args[0];
  ESLVal _v1014 = $args[1];
  ESLVal _v1013 = $args[2];
  ESLVal _v1012 = $args[3];
  ESLVal _v1011 = $args[4];
  ESLVal _v1010 = $args[5];
  if(_v1014.eql($nil).boolVal)
        return new ESLVal("ForallType",_v1015,ESLVal.list(new ESLVal("T")),new ESLVal("ListType",_v1015,new ESLVal("VarType",_v1015,new ESLVal("T"))));
        else
          {ESLVal ts = map.apply(new ESLVal(new Function(new ESLVal("fun864"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal e = $args[0];
              return expType.apply(e,_v1013,_v1012,_v1011,_v1010);
                }
              }),_v1014);
            
            if(allEqualTypes.apply(head.apply(ts),tail.apply(ts)).boolVal)
            return new ESLVal("ListType",_v1015,head.apply(ts));
            else
              return error(new ESLVal("TypeError",_v1015,new ESLVal("lists should have elements of the same type: ").add(_v1014)));
          }
    }
  });
  private static ESLVal setType = new ESLVal(new Function(new ESLVal("setType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1009 = $args[0];
  ESLVal _v1008 = $args[1];
  ESLVal _v1007 = $args[2];
  ESLVal _v1006 = $args[3];
  ESLVal _v1005 = $args[4];
  ESLVal _v1004 = $args[5];
  if(_v1008.eql($nil).boolVal)
        return new ESLVal("ForallType",_v1009,ESLVal.list(new ESLVal("T")),new ESLVal("SetType",_v1009,new ESLVal("VarType",_v1009,new ESLVal("T"))));
        else
          {ESLVal ts = map.apply(new ESLVal(new Function(new ESLVal("fun865"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal e = $args[0];
              return expType.apply(e,_v1007,_v1006,_v1005,_v1004);
                }
              }),_v1008);
            
            if(allEqualTypes.apply(head.apply(ts),tail.apply(ts)).boolVal)
            return new ESLVal("SetType",_v1009,head.apply(ts));
            else
              return error(new ESLVal("TypeError",_v1009,new ESLVal("sets should have elements of the same type: ").add(_v1008)));
          }
    }
  });
  private static ESLVal bagType = new ESLVal(new Function(new ESLVal("bagType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1003 = $args[0];
  ESLVal _v1002 = $args[1];
  ESLVal _v1001 = $args[2];
  ESLVal _v1000 = $args[3];
  ESLVal _v999 = $args[4];
  ESLVal _v998 = $args[5];
  if(_v1002.eql($nil).boolVal)
        return new ESLVal("ForallType",_v1003,ESLVal.list(new ESLVal("T")),new ESLVal("BagType",_v1003,new ESLVal("VarType",_v1003,new ESLVal("T"))));
        else
          {ESLVal ts = map.apply(new ESLVal(new Function(new ESLVal("fun866"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal e = $args[0];
              return expType.apply(e,_v1001,_v1000,_v999,_v998);
                }
              }),_v1002);
            
            if(allEqualTypes.apply(head.apply(ts),tail.apply(ts)).boolVal)
            return new ESLVal("BagType",_v1003,head.apply(ts));
            else
              return error(new ESLVal("TypeError",_v1003,new ESLVal("bags should have elements of the same type: ").add(_v1002)));
          }
    }
  });
  private static ESLVal recTypes = new ESLVal(new Function(new ESLVal("recTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal env = $args[0];
  LetRec letrec = new LetRec() {
        ESLVal fixEnv = new ESLVal(new Function(new ESLVal("fixEnv"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v996 = $args[0];
          {ESLVal[] e = new ESLVal[]{$null};
                
                {ESLVal fenv = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      ESLVal $qualArg = $args[0];
                  {ESLVal _v860 = $qualArg;
                        
                        {ESLVal t = _v860;
                        
                        return ESLVal.list(new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                          public ESLVal apply(ESLVal... $args) {
                            ESLVal _v997 = $args[0];
                        {ESLVal _v861 = _v997;
                              
                              {ESLVal n = _v861;
                              
                              return ESLVal.list(ESLVal.list(new ESLVal("Map",n,new ESLVal("TypeClosure",new ESLVal(new Function(new ESLVal("lookup: ").add(n),getSelf()) {
                                public ESLVal apply(ESLVal... $args) {
                                  return lookupType.apply(n,e[0]);
                                }
                              })))));
                            }
                            }
                          }
                        }).map(typeFV.apply(t)).flatten().flatten());
                      }
                      }
                    }
                  }).map(typeEnvRan.apply(_v996)).flatten().flatten();
                
                {ESLVal env1 = substOnce.apply(_v996,fenv);
                
                {e[0] = env1;
              return env1;}
              }
              }
              }
            }
          });
        ESLVal introduceRecTypes = new ESLVal(new Function(new ESLVal("introduceRecTypes"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v995 = $args[0];
          {ESLVal _v859 = _v995;
                
                if(_v859.isCons())
                {ESLVal $1474 = _v859.head();
                  ESLVal $1475 = _v859.tail();
                  
                  switch($1474.termName) {
                  case "Map": {ESLVal $1477 = $1474.termRef(0);
                    ESLVal $1476 = $1474.termRef(1);
                    
                    switch($1476.termName) {
                    case "RecordType": {ESLVal $1479 = $1476.termRef(0);
                      ESLVal $1478 = $1476.termRef(1);
                      
                      {ESLVal n = $1477;
                      
                      {ESLVal l = $1479;
                      
                      {ESLVal fs = $1478;
                      
                      {ESLVal e = $1475;
                      
                      return introduceRecTypes.apply(e).cons(new ESLVal("Map",n,new ESLVal("RecordType",l,fs)));
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal n = $1477;
                      
                      {ESLVal t = $1476;
                      
                      {ESLVal e = $1475;
                      
                      if(member.apply(n,typeFV.apply(t)).boolVal)
                      return introduceRecTypes.apply(e).cons(new ESLVal("Map",n,new ESLVal("RecType",p0,n,t)));
                      else
                        return introduceRecTypes.apply(e).cons(new ESLVal("Map",n,t));
                    }
                    }
                    }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(72211,72525)").add(ESLVal.list(_v859)));
                }
                }
              else if(_v859.isNil())
                return _v995;
              else return error(new ESLVal("case error at Pos(72211,72525)").add(ESLVal.list(_v859)));
              }
            }
          });
        ESLVal substOnce = new ESLVal(new Function(new ESLVal("substOnce"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v993 = $args[0];
          ESLVal _v992 = $args[1];
          {ESLVal map1 = new ESLVal(new Function(new ESLVal("map1"),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      ESLVal m = $args[0];
                  {ESLVal _v857 = m;
                        
                        switch(_v857.termName) {
                        case "Map": {ESLVal $1473 = _v857.termRef(0);
                          ESLVal $1472 = _v857.termRef(1);
                          
                          {ESLVal n = $1473;
                          
                          {ESLVal t = $1472;
                          
                          return new ESLVal("Map",n,substTypeEnv.apply(new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                            public ESLVal apply(ESLVal... $args) {
                              ESLVal $qualArg = $args[0];
                          {ESLVal _v858 = $qualArg;
                                
                                {ESLVal _v994 = _v858;
                                
                                return ESLVal.list(ESLVal.list(new ESLVal("Map",_v994,lookupType.apply(_v994,_v992))));
                              }
                              }
                            }
                          }).map(typeFV.apply(t)).flatten().flatten(),t));
                        }
                        }
                        }
                        default: return error(new ESLVal("case error at Pos(72635,72766)").add(ESLVal.list(_v857)));
                      }
                      }
                    }
                  });
                
                return map.apply(map1,_v993);
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "fixEnv": return fixEnv;
            
            case "introduceRecTypes": return introduceRecTypes;
            
            case "substOnce": return substOnce;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal fixEnv = letrec.get("fixEnv");
      
      ESLVal introduceRecTypes = letrec.get("introduceRecTypes");
      
      ESLVal substOnce = letrec.get("substOnce");
      
        return fixEnv.apply(introduceRecTypes.apply(env));
      
    }
  });
  private static ESLVal typeFV = new ESLVal(new Function(new ESLVal("typeFV"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  return removeDups.apply(varTypeNames.apply(typeFV1.apply(t,$nil)));
    }
  });
  private static ESLVal varTypeNames = new ESLVal(new Function(new ESLVal("varTypeNames"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal vs = $args[0];
  return map.apply(varTypeName,vs);
    }
  });
  private static ESLVal varTypeName = new ESLVal(new Function(new ESLVal("varTypeName"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v856 = t;
        
        switch(_v856.termName) {
        case "VarType": {ESLVal $1471 = _v856.termRef(0);
          ESLVal $1470 = _v856.termRef(1);
          
          {ESLVal l = $1471;
          
          {ESLVal n = $1470;
          
          return n;
        }
        }
        }
        default: {ESLVal x = _v856;
          
          return new ESLVal("<var>");
        }
      }
      }
    }
  });
  private static ESLVal tdecsFV1 = new ESLVal(new Function(new ESLVal("tdecsFV1"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal decs = $args[0];
  ESLVal fv = $args[1];
  {ESLVal _v855 = decs;
        
        if(_v855.isCons())
        {ESLVal $1468 = _v855.head();
          ESLVal $1469 = _v855.tail();
          
          {ESLVal d = $1468;
          
          {ESLVal ds = $1469;
          
          return tdecFV1.apply(d,tdecsFV1.apply(ds,fv));
        }
        }
        }
      else if(_v855.isNil())
        return fv;
      else return error(new ESLVal("case error at Pos(73152,73241)").add(ESLVal.list(_v855)));
      }
    }
  });
  private static ESLVal tdecFV1 = new ESLVal(new Function(new ESLVal("tdecFV1"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d = $args[0];
  ESLVal fv = $args[1];
  {ESLVal _v854 = d;
        
        switch(_v854.termName) {
        case "Dec": {ESLVal $1467 = _v854.termRef(0);
          ESLVal $1466 = _v854.termRef(1);
          ESLVal $1465 = _v854.termRef(2);
          ESLVal $1464 = _v854.termRef(3);
          
          {ESLVal l = $1467;
          
          {ESLVal n = $1466;
          
          {ESLVal t = $1465;
          
          {ESLVal st = $1464;
          
          return typeFV1.apply(t,fv);
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(73285,73364)").add(ESLVal.list(_v854)));
      }
      }
    }
  });
  private static ESLVal handlersFV1 = new ESLVal(new Function(new ESLVal("handlersFV1"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal handlers = $args[0];
  ESLVal fv = $args[1];
  {ESLVal _v853 = handlers;
        
        if(_v853.isCons())
        {ESLVal $1462 = _v853.head();
          ESLVal $1463 = _v853.tail();
          
          {ESLVal m = $1462;
          
          {ESLVal hs = $1463;
          
          return handlerFV1.apply(m,handlersFV1.apply(hs,fv));
        }
        }
        }
      else if(_v853.isNil())
        return fv;
      else return error(new ESLVal("case error at Pos(73422,73524)").add(ESLVal.list(_v853)));
      }
    }
  });
  private static ESLVal handlerFV1 = new ESLVal(new Function(new ESLVal("handlerFV1"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal m = $args[0];
  ESLVal fv = $args[1];
  {ESLVal _v852 = m;
        
        switch(_v852.termName) {
        case "MessageType": {ESLVal $1461 = _v852.termRef(0);
          ESLVal $1460 = _v852.termRef(1);
          
          {ESLVal l = $1461;
          
          {ESLVal ts = $1460;
          
          return typesFV1.apply(ts,fv);
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(73572,73648)").add(ESLVal.list(_v852)));
      }
      }
    }
  });
  private static ESLVal typesFV1 = new ESLVal(new Function(new ESLVal("typesFV1"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal ts = $args[0];
  ESLVal fv = $args[1];
  {ESLVal _v851 = ts;
        
        if(_v851.isCons())
        {ESLVal $1458 = _v851.head();
          ESLVal $1459 = _v851.tail();
          
          {ESLVal t = $1458;
          
          {ESLVal _v991 = $1459;
          
          return typeFV1.apply(t,typesFV1.apply(_v991,fv));
        }
        }
        }
      else if(_v851.isNil())
        return fv;
      else return error(new ESLVal("case error at Pos(73697,73784)").add(ESLVal.list(_v851)));
      }
    }
  });
  private static ESLVal typeFV1 = new ESLVal(new Function(new ESLVal("typeFV1"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  ESLVal fv = $args[1];
  {ESLVal _v846 = t;
        
        switch(_v846.termName) {
        case "ArrayType": {ESLVal $1447 = _v846.termRef(0);
          ESLVal $1446 = _v846.termRef(1);
          
          {ESLVal l = $1447;
          
          {ESLVal _v990 = $1446;
          
          return typeFV1.apply(_v990,fv);
        }
        }
        }
      case "ActType": {ESLVal $1445 = _v846.termRef(0);
          ESLVal $1444 = _v846.termRef(1);
          ESLVal $1443 = _v846.termRef(2);
          
          {ESLVal l = $1445;
          
          {ESLVal decs = $1444;
          
          {ESLVal handlers = $1443;
          
          return tdecsFV1.apply(decs,handlersFV1.apply(handlers,fv));
        }
        }
        }
        }
      case "ExtendedAct": {ESLVal $1442 = _v846.termRef(0);
          ESLVal $1441 = _v846.termRef(1);
          ESLVal $1440 = _v846.termRef(2);
          ESLVal $1439 = _v846.termRef(3);
          
          {ESLVal l = $1442;
          
          {ESLVal parent = $1441;
          
          {ESLVal decs = $1440;
          
          {ESLVal handlers = $1439;
          
          return tdecsFV1.apply(decs,handlersFV1.apply(handlers,typeFV1.apply(parent,fv)));
        }
        }
        }
        }
        }
      case "ApplyType": {ESLVal $1438 = _v846.termRef(0);
          ESLVal $1437 = _v846.termRef(1);
          ESLVal $1436 = _v846.termRef(2);
          
          {ESLVal l = $1438;
          
          {ESLVal n = $1437;
          
          {ESLVal types = $1436;
          
          return typesFV1.apply(types,fv.cons(new ESLVal("VarType",l,n)));
        }
        }
        }
        }
      case "ApplyTypeFun": {ESLVal $1435 = _v846.termRef(0);
          ESLVal $1434 = _v846.termRef(1);
          ESLVal $1433 = _v846.termRef(2);
          
          {ESLVal l = $1435;
          
          {ESLVal op = $1434;
          
          {ESLVal args = $1433;
          
          return typesFV1.apply(args,typeFV1.apply(op,fv));
        }
        }
        }
        }
      case "BoolType": {ESLVal $1432 = _v846.termRef(0);
          
          {ESLVal l = $1432;
          
          return fv;
        }
        }
      case "FieldType": {ESLVal $1431 = _v846.termRef(0);
          ESLVal $1430 = _v846.termRef(1);
          ESLVal $1429 = _v846.termRef(2);
          
          {ESLVal l = $1431;
          
          {ESLVal n = $1430;
          
          {ESLVal _v989 = $1429;
          
          return typeFV1.apply(_v989,fv);
        }
        }
        }
        }
      case "FloatType": {ESLVal $1428 = _v846.termRef(0);
          
          {ESLVal l = $1428;
          
          return fv;
        }
        }
      case "ForallType": {ESLVal $1427 = _v846.termRef(0);
          ESLVal $1426 = _v846.termRef(1);
          ESLVal $1425 = _v846.termRef(2);
          
          {ESLVal l = $1427;
          
          {ESLVal ns = $1426;
          
          {ESLVal _v986 = $1425;
          
          return filter.apply(new ESLVal(new Function(new ESLVal("fun867"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v987 = $args[0];
          {ESLVal _v850 = _v987;
                
                switch(_v850.termName) {
                case "VarType": {ESLVal $1457 = _v850.termRef(0);
                  ESLVal $1456 = _v850.termRef(1);
                  
                  {ESLVal _v988 = $1457;
                  
                  {ESLVal n = $1456;
                  
                  return member.apply(n,ns).not();
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(74623,74683)").add(ESLVal.list(_v850)));
              }
              }
            }
          }),typeFV1.apply(_v986,$nil)).add(fv);
        }
        }
        }
        }
      case "FunType": {ESLVal $1424 = _v846.termRef(0);
          ESLVal $1423 = _v846.termRef(1);
          ESLVal $1422 = _v846.termRef(2);
          
          {ESLVal l = $1424;
          
          {ESLVal d = $1423;
          
          {ESLVal r = $1422;
          
          return typesFV1.apply(d,typeFV1.apply(r,fv));
        }
        }
        }
        }
      case "IntType": {ESLVal $1421 = _v846.termRef(0);
          
          {ESLVal l = $1421;
          
          return fv;
        }
        }
      case "ListType": {ESLVal $1420 = _v846.termRef(0);
          ESLVal $1419 = _v846.termRef(1);
          
          {ESLVal l = $1420;
          
          {ESLVal _v985 = $1419;
          
          return typeFV1.apply(_v985,fv);
        }
        }
        }
      case "BagType": {ESLVal $1418 = _v846.termRef(0);
          ESLVal $1417 = _v846.termRef(1);
          
          {ESLVal l = $1418;
          
          {ESLVal _v984 = $1417;
          
          return typeFV1.apply(_v984,fv);
        }
        }
        }
      case "SetType": {ESLVal $1416 = _v846.termRef(0);
          ESLVal $1415 = _v846.termRef(1);
          
          {ESLVal l = $1416;
          
          {ESLVal _v983 = $1415;
          
          return typeFV1.apply(_v983,fv);
        }
        }
        }
      case "NullType": {ESLVal $1414 = _v846.termRef(0);
          
          {ESLVal l = $1414;
          
          return fv;
        }
        }
      case "RecordType": {ESLVal $1413 = _v846.termRef(0);
          ESLVal $1412 = _v846.termRef(1);
          
          {ESLVal l = $1413;
          
          {ESLVal fs = $1412;
          
          return typesFV1.apply(new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v849 = $qualArg;
                
                switch(_v849.termName) {
                case "Dec": {ESLVal $1455 = _v849.termRef(0);
                  ESLVal $1454 = _v849.termRef(1);
                  ESLVal $1453 = _v849.termRef(2);
                  ESLVal $1452 = _v849.termRef(3);
                  
                  {ESLVal _v981 = $1455;
                  
                  {ESLVal n = $1454;
                  
                  {ESLVal _v982 = $1453;
                  
                  {ESLVal dt = $1452;
                  
                  return ESLVal.list(ESLVal.list(_v982));
                }
                }
                }
                }
                }
                default: {ESLVal _0 = _v849;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten(),fv);
        }
        }
        }
      case "RecType": {ESLVal $1411 = _v846.termRef(0);
          ESLVal $1410 = _v846.termRef(1);
          ESLVal $1409 = _v846.termRef(2);
          
          {ESLVal l = $1411;
          
          {ESLVal a = $1410;
          
          {ESLVal _v978 = $1409;
          
          return filter.apply(new ESLVal(new Function(new ESLVal("fun868"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v979 = $args[0];
          {ESLVal _v848 = _v979;
                
                switch(_v848.termName) {
                case "VarType": {ESLVal $1451 = _v848.termRef(0);
                  ESLVal $1450 = _v848.termRef(1);
                  
                  {ESLVal _v980 = $1451;
                  
                  {ESLVal n = $1450;
                  
                  return n.eql(a).not();
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(75124,75172)").add(ESLVal.list(_v848)));
              }
              }
            }
          }),typeFV1.apply(_v978,$nil)).add(fv);
        }
        }
        }
        }
      case "StrType": {ESLVal $1408 = _v846.termRef(0);
          
          {ESLVal l = $1408;
          
          return fv;
        }
        }
      case "TableType": {ESLVal $1407 = _v846.termRef(0);
          ESLVal $1406 = _v846.termRef(1);
          ESLVal $1405 = _v846.termRef(2);
          
          {ESLVal l = $1407;
          
          {ESLVal k = $1406;
          
          {ESLVal v = $1405;
          
          return typeFV1.apply(k,typeFV1.apply(v,fv));
        }
        }
        }
        }
      case "TypeClosure": {ESLVal $1404 = _v846.termRef(0);
          
          {ESLVal f = $1404;
          
          return $nil;
        }
        }
      case "TermType": {ESLVal $1403 = _v846.termRef(0);
          ESLVal $1402 = _v846.termRef(1);
          ESLVal $1401 = _v846.termRef(2);
          
          {ESLVal l = $1403;
          
          {ESLVal n = $1402;
          
          {ESLVal ts = $1401;
          
          return typesFV1.apply(ts,fv);
        }
        }
        }
        }
      case "TypeFun": {ESLVal $1400 = _v846.termRef(0);
          ESLVal $1399 = _v846.termRef(1);
          ESLVal $1398 = _v846.termRef(2);
          
          {ESLVal l = $1400;
          
          {ESLVal ns = $1399;
          
          {ESLVal _v975 = $1398;
          
          return filter.apply(new ESLVal(new Function(new ESLVal("fun869"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v976 = $args[0];
          {ESLVal _v847 = _v976;
                
                switch(_v847.termName) {
                case "VarType": {ESLVal $1449 = _v847.termRef(0);
                  ESLVal $1448 = _v847.termRef(1);
                  
                  {ESLVal _v977 = $1449;
                  
                  {ESLVal n = $1448;
                  
                  return member.apply(n,ns).not();
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(75468,75528)").add(ESLVal.list(_v847)));
              }
              }
            }
          }),typeFV1.apply(_v975,$nil)).add(fv);
        }
        }
        }
        }
      case "UnfoldType": {ESLVal $1397 = _v846.termRef(0);
          ESLVal $1396 = _v846.termRef(1);
          
          {ESLVal l = $1397;
          
          {ESLVal _v974 = $1396;
          
          return typeFV1.apply(_v974,fv);
        }
        }
        }
      case "UnionType": {ESLVal $1395 = _v846.termRef(0);
          ESLVal $1394 = _v846.termRef(1);
          
          {ESLVal l = $1395;
          
          {ESLVal ts = $1394;
          
          return typesFV1.apply(ts,fv);
        }
        }
        }
      case "VarType": {ESLVal $1393 = _v846.termRef(0);
          ESLVal $1392 = _v846.termRef(1);
          
          {ESLVal l = $1393;
          
          {ESLVal n = $1392;
          
          return fv.cons(t);
        }
        }
        }
      case "VoidType": {ESLVal $1391 = _v846.termRef(0);
          
          {ESLVal l = $1391;
          
          return fv;
        }
        }
      case "UnionRef": {ESLVal $1390 = _v846.termRef(0);
          ESLVal $1389 = _v846.termRef(1);
          ESLVal $1388 = _v846.termRef(2);
          
          {ESLVal l = $1390;
          
          {ESLVal _v973 = $1389;
          
          {ESLVal n = $1388;
          
          return typeFV1.apply(_v973,fv);
        }
        }
        }
        }
        default: {ESLVal x = _v846;
          
          return error(x);
        }
      }
      }
    }
  });
  public static ESLVal main = new ESLVal(new Function(new ESLVal("main"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      return new ESLVal(new BehaviourAdapter(false,getSelf(),new ESLVal("main")) {
          
          public ESLVal handle(ESLVal $m) {{ESLVal _v845 = $m;
            
            return error(new ESLVal("case error at Pos(0,0)").add(ESLVal.list(_v845)));
          }}
          public ESLVal get(String name) {
            switch(name) {
              
              default: throw new Error("ref illegal " + self + "." + name);
            }
          }
        public void handleTime(ESLVal $t) {
          {}
        }
        public ESLVal init() {
            return ((Supplier<ESLVal>)() -> { 
                {new Function(new ESLVal("try"),getSelf()) {
                  public ESLVal apply(ESLVal... args) { 
                    try { 
                      return typeCheckModule.apply(new ESLVal("esl/compiler/test1.esl"));
                    } catch(ESLError $exception) {
                      ESLVal $x = $exception.value;
                      {ESLVal _v844 = $x;
                  
                  {ESLVal message = _v844;
                  
                  return print.apply(new ESLVal("Type Error: ").add(message));
                }
                }
                    }
                  }
                }.apply();
                print.apply(new ESLVal("DONE"));
                return stopAll.apply();}
              }).get();
          }
        });
    }
  });
public static void main(String[] args) {
    newActor(main,new ESLVal(new Actor())); 
  }
}