package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
// import static esl.Lists.*;
import static esl.compiler.Types.*;
import static esl.compiler.PpExp.*;
import java.util.function.Supplier;
public class Cases {
  public static ESLVal getSelf() { return $null; }
  private static ESLVal loc0 = new ESLVal("Pos",$zero,$zero);
  private static ESLVal voidType = new ESLVal("VoidType",loc0);
  private static ESLVal varCounter = $zero;
  private static ESLVal newVar = new ESLVal(new Function(new ESLVal("newVar"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      {varCounter = varCounter.add($one);
      return new ESLVal("$").add(varCounter);}
    }
  });
  private static ESLVal translateArms = new ESLVal(new Function(new ESLVal("translateArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal as = $args[0];
  {ESLVal _v2172 = as;
        
        if(_v2172.isCons())
        {ESLVal $3140 = _v2172.head();
          ESLVal $3141 = _v2172.tail();
          
          switch($3140.termName) {
          case "BArm": {ESLVal $3145 = $3140.termRef(0);
            ESLVal $3144 = $3140.termRef(1);
            ESLVal $3143 = $3140.termRef(2);
            ESLVal $3142 = $3140.termRef(3);
            
            {ESLVal l = $3145;
            
            {ESLVal ps = $3144;
            
            {ESLVal g = $3143;
            
            {ESLVal e = $3142;
            
            {ESLVal _v2198 = $3141;
            
            return translateArms.apply(_v2198).cons(new ESLVal("LArm",l,ps,$nil,g,e));
          }
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(1889,2030)").add(ESLVal.list(_v2172)));
        }
        }
      else if(_v2172.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(1889,2030)").add(ESLVal.list(_v2172)));
      }
    }
  });
  private static ESLVal newVars = new ESLVal(new Function(new ESLVal("newVars"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal n = $args[0];
  if(n.eql($zero).boolVal)
        return ESLVal.list();
        else
          return newVars.apply(n.sub($one)).cons(newVar.apply());
    }
  });
  public static ESLVal translateCases = new ESLVal(new Function(new ESLVal("translateCases"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal exp = $args[0];
  {ESLVal _v2155 = exp;
        
        switch(_v2155.termName) {
        case "Module": {ESLVal $3139 = _v2155.termRef(0);
          ESLVal $3138 = _v2155.termRef(1);
          ESLVal $3137 = _v2155.termRef(2);
          ESLVal $3136 = _v2155.termRef(3);
          ESLVal $3135 = _v2155.termRef(4);
          ESLVal $3134 = _v2155.termRef(5);
          ESLVal $3133 = _v2155.termRef(6);
          
          {ESLVal path = $3139;
          
          {ESLVal name = $3138;
          
          {ESLVal exports = $3137;
          
          {ESLVal imports = $3136;
          
          {ESLVal x = $3135;
          
          {ESLVal y = $3134;
          
          {ESLVal defs = $3133;
          
          return new ESLVal("Module",path,name,exports,imports,x,y,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v2171 = $qualArg;
                
                {ESLVal d = _v2171;
                
                return ESLVal.list(ESLVal.list(translateDef.apply(d)));
              }
              }
            }
          }).map(mergeFunDefs.apply(defs)).flatten().flatten());
        }
        }
        }
        }
        }
        }
        }
        }
      case "FunExp": {ESLVal $3132 = _v2155.termRef(0);
          ESLVal $3131 = _v2155.termRef(1);
          ESLVal $3130 = _v2155.termRef(2);
          ESLVal $3129 = _v2155.termRef(3);
          ESLVal $3128 = _v2155.termRef(4);
          
          {ESLVal l = $3132;
          
          {ESLVal n = $3131;
          
          {ESLVal args = $3130;
          
          {ESLVal t = $3129;
          
          {ESLVal e = $3128;
          
          return new ESLVal("FunExp",l,n,args,t,translateCases.apply(e));
        }
        }
        }
        }
        }
        }
      case "StrExp": {ESLVal $3127 = _v2155.termRef(0);
          ESLVal $3126 = _v2155.termRef(1);
          
          {ESLVal l = $3127;
          
          {ESLVal v = $3126;
          
          return exp;
        }
        }
        }
      case "IntExp": {ESLVal $3125 = _v2155.termRef(0);
          ESLVal $3124 = _v2155.termRef(1);
          
          {ESLVal l = $3125;
          
          {ESLVal v = $3124;
          
          return exp;
        }
        }
        }
      case "BoolExp": {ESLVal $3123 = _v2155.termRef(0);
          ESLVal $3122 = _v2155.termRef(1);
          
          {ESLVal l = $3123;
          
          {ESLVal v = $3122;
          
          return exp;
        }
        }
        }
      case "BagExp": {ESLVal $3121 = _v2155.termRef(0);
          ESLVal $3120 = _v2155.termRef(1);
          
          {ESLVal l = $3121;
          
          {ESLVal es = $3120;
          
          return new ESLVal("BagExp",l,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v2170 = $qualArg;
                
                {ESLVal e = _v2170;
                
                return ESLVal.list(ESLVal.list(translateCases.apply(e)));
              }
              }
            }
          }).map(es).flatten().flatten());
        }
        }
        }
      case "NullExp": {ESLVal $3119 = _v2155.termRef(0);
          
          {ESLVal l = $3119;
          
          return exp;
        }
        }
      case "FloatExp": {ESLVal $3118 = _v2155.termRef(0);
          ESLVal $3117 = _v2155.termRef(1);
          
          {ESLVal l = $3118;
          
          {ESLVal f = $3117;
          
          return exp;
        }
        }
        }
      case "Term": {ESLVal $3116 = _v2155.termRef(0);
          ESLVal $3115 = _v2155.termRef(1);
          ESLVal $3114 = _v2155.termRef(2);
          ESLVal $3113 = _v2155.termRef(3);
          
          {ESLVal l = $3116;
          
          {ESLVal n = $3115;
          
          {ESLVal ts = $3114;
          
          {ESLVal es = $3113;
          
          return new ESLVal("Term",l,n,ts,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v2169 = $qualArg;
                
                {ESLVal e = _v2169;
                
                return ESLVal.list(ESLVal.list(translateCases.apply(e)));
              }
              }
            }
          }).map(es).flatten().flatten());
        }
        }
        }
        }
        }
      case "List": {ESLVal $3112 = _v2155.termRef(0);
          ESLVal $3111 = _v2155.termRef(1);
          
          {ESLVal l = $3112;
          
          {ESLVal es = $3111;
          
          return new ESLVal("List",l,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v2168 = $qualArg;
                
                {ESLVal e = _v2168;
                
                return ESLVal.list(ESLVal.list(translateCases.apply(e)));
              }
              }
            }
          }).map(es).flatten().flatten());
        }
        }
        }
      case "Block": {ESLVal $3110 = _v2155.termRef(0);
          ESLVal $3109 = _v2155.termRef(1);
          
          {ESLVal l = $3110;
          
          {ESLVal es = $3109;
          
          return new ESLVal("Block",l,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v2167 = $qualArg;
                
                {ESLVal e = _v2167;
                
                return ESLVal.list(ESLVal.list(translateCases.apply(e)));
              }
              }
            }
          }).map(es).flatten().flatten());
        }
        }
        }
      case "Apply": {ESLVal $3108 = _v2155.termRef(0);
          ESLVal $3107 = _v2155.termRef(1);
          ESLVal $3106 = _v2155.termRef(2);
          
          {ESLVal l = $3108;
          
          {ESLVal op = $3107;
          
          {ESLVal args = $3106;
          
          return new ESLVal("Apply",l,translateCases.apply(op),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v2166 = $qualArg;
                
                {ESLVal e = _v2166;
                
                return ESLVal.list(ESLVal.list(translateCases.apply(e)));
              }
              }
            }
          }).map(args).flatten().flatten());
        }
        }
        }
        }
      case "ApplyTypeExp": {ESLVal $3105 = _v2155.termRef(0);
          ESLVal $3104 = _v2155.termRef(1);
          ESLVal $3103 = _v2155.termRef(2);
          
          {ESLVal l = $3105;
          
          {ESLVal op = $3104;
          
          {ESLVal args = $3103;
          
          return new ESLVal("ApplyTypeExp",l,translateCases.apply(op),args);
        }
        }
        }
        }
      case "Case": {ESLVal $3102 = _v2155.termRef(0);
          ESLVal $3101 = _v2155.termRef(1);
          ESLVal $3100 = _v2155.termRef(2);
          ESLVal $3099 = _v2155.termRef(3);
          
          {ESLVal l = $3102;
          
          {ESLVal ds = $3101;
          
          {ESLVal es = $3100;
          
          {ESLVal as = $3099;
          
          return compileCase.apply(l,es,translateArms.apply(as),new ESLVal("CaseError",l,new ESLVal("List",l,es)));
        }
        }
        }
        }
        }
      case "BinExp": {ESLVal $3098 = _v2155.termRef(0);
          ESLVal $3097 = _v2155.termRef(1);
          ESLVal $3096 = _v2155.termRef(2);
          ESLVal $3095 = _v2155.termRef(3);
          
          {ESLVal l = $3098;
          
          {ESLVal e1 = $3097;
          
          {ESLVal op = $3096;
          
          {ESLVal e2 = $3095;
          
          return new ESLVal("BinExp",l,translateCases.apply(e1),op,translateCases.apply(e2));
        }
        }
        }
        }
        }
      case "For": {ESLVal $3094 = _v2155.termRef(0);
          ESLVal $3093 = _v2155.termRef(1);
          ESLVal $3092 = _v2155.termRef(2);
          ESLVal $3091 = _v2155.termRef(3);
          
          {ESLVal l = $3094;
          
          {ESLVal p = $3093;
          
          {ESLVal e1 = $3092;
          
          {ESLVal e2 = $3091;
          
          return new ESLVal("For",l,p,translateCases.apply(e1),translateCases.apply(e2));
        }
        }
        }
        }
        }
      case "Throw": {ESLVal $3090 = _v2155.termRef(0);
          ESLVal $3089 = _v2155.termRef(1);
          ESLVal $3088 = _v2155.termRef(2);
          
          {ESLVal l = $3090;
          
          {ESLVal t = $3089;
          
          {ESLVal e = $3088;
          
          return new ESLVal("Throw",l,t,translateCases.apply(e));
        }
        }
        }
        }
      case "Try": {ESLVal $3087 = _v2155.termRef(0);
          ESLVal $3086 = _v2155.termRef(1);
          ESLVal $3085 = _v2155.termRef(2);
          
          {ESLVal l = $3087;
          
          {ESLVal e = $3086;
          
          {ESLVal as = $3085;
          
          return new ESLVal("Try",l,translateCases.apply(e),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v2165 = $qualArg;
                
                {ESLVal a = _v2165;
                
                return ESLVal.list(ESLVal.list(translateArm.apply(a)));
              }
              }
            }
          }).map(as).flatten().flatten());
        }
        }
        }
        }
      case "ActExp": {ESLVal $3084 = _v2155.termRef(0);
          ESLVal $3083 = _v2155.termRef(1);
          ESLVal $3082 = _v2155.termRef(2);
          ESLVal $3081 = _v2155.termRef(3);
          ESLVal $3080 = _v2155.termRef(4);
          ESLVal $3079 = _v2155.termRef(5);
          ESLVal $3078 = _v2155.termRef(6);
          ESLVal $3077 = _v2155.termRef(7);
          
          {ESLVal l = $3084;
          
          {ESLVal n = $3083;
          
          {ESLVal args = $3082;
          
          {ESLVal x = $3081;
          
          {ESLVal spec = $3080;
          
          {ESLVal locals = $3079;
          
          {ESLVal init = $3078;
          
          {ESLVal handlers = $3077;
          
          return new ESLVal("ActExp",l,n,args,x,spec,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v2163 = $qualArg;
                
                {ESLVal b = _v2163;
                
                return ESLVal.list(ESLVal.list(translateDef.apply(b)));
              }
              }
            }
          }).map(locals).flatten().flatten(),translateCases.apply(init),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v2164 = $qualArg;
                
                {ESLVal h = _v2164;
                
                return ESLVal.list(ESLVal.list(translateArm.apply(h)));
              }
              }
            }
          }).map(handlers).flatten().flatten());
        }
        }
        }
        }
        }
        }
        }
        }
        }
      case "If": {ESLVal $3076 = _v2155.termRef(0);
          ESLVal $3075 = _v2155.termRef(1);
          ESLVal $3074 = _v2155.termRef(2);
          ESLVal $3073 = _v2155.termRef(3);
          
          {ESLVal l = $3076;
          
          {ESLVal e1 = $3075;
          
          {ESLVal e2 = $3074;
          
          {ESLVal e3 = $3073;
          
          return new ESLVal("If",l,translateCases.apply(e1),translateCases.apply(e2),translateCases.apply(e3));
        }
        }
        }
        }
        }
      case "Self": {ESLVal $3072 = _v2155.termRef(0);
          
          {ESLVal l = $3072;
          
          return exp;
        }
        }
      case "Update": {ESLVal $3071 = _v2155.termRef(0);
          ESLVal $3070 = _v2155.termRef(1);
          ESLVal $3069 = _v2155.termRef(2);
          
          {ESLVal l = $3071;
          
          {ESLVal n = $3070;
          
          {ESLVal e = $3069;
          
          return new ESLVal("Update",l,n,translateCases.apply(e));
        }
        }
        }
        }
      case "Ref": {ESLVal $3068 = _v2155.termRef(0);
          ESLVal $3067 = _v2155.termRef(1);
          ESLVal $3066 = _v2155.termRef(2);
          
          {ESLVal l = $3068;
          
          {ESLVal e = $3067;
          
          {ESLVal n = $3066;
          
          return new ESLVal("Ref",l,translateCases.apply(e),n);
        }
        }
        }
        }
      case "Var": {ESLVal $3065 = _v2155.termRef(0);
          ESLVal $3064 = _v2155.termRef(1);
          
          {ESLVal l = $3065;
          
          {ESLVal n = $3064;
          
          return exp;
        }
        }
        }
      case "Send": {ESLVal $3063 = _v2155.termRef(0);
          ESLVal $3062 = _v2155.termRef(1);
          ESLVal $3061 = _v2155.termRef(2);
          
          {ESLVal l = $3063;
          
          {ESLVal target = $3062;
          
          {ESLVal message = $3061;
          
          return new ESLVal("Send",l,translateCases.apply(target),translateCases.apply(message));
        }
        }
        }
        }
      case "SendTimeSuper": {ESLVal $3060 = _v2155.termRef(0);
          
          {ESLVal l = $3060;
          
          return new ESLVal("SendTimeSuper",l);
        }
        }
      case "SendSuper": {ESLVal $3059 = _v2155.termRef(0);
          ESLVal $3058 = _v2155.termRef(1);
          
          {ESLVal l = $3059;
          
          {ESLVal e = $3058;
          
          return new ESLVal("SendSuper",l,translateCases.apply(e));
        }
        }
        }
      case "SetExp": {ESLVal $3057 = _v2155.termRef(0);
          ESLVal $3056 = _v2155.termRef(1);
          
          {ESLVal l = $3057;
          
          {ESLVal es = $3056;
          
          return new ESLVal("SetExp",l,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v2162 = $qualArg;
                
                {ESLVal e = _v2162;
                
                return ESLVal.list(ESLVal.list(translateCases.apply(e)));
              }
              }
            }
          }).map(es).flatten().flatten());
        }
        }
        }
      case "Cmp": {ESLVal $3055 = _v2155.termRef(0);
          ESLVal $3054 = _v2155.termRef(1);
          ESLVal $3053 = _v2155.termRef(2);
          
          {ESLVal l = $3055;
          
          {ESLVal e = $3054;
          
          {ESLVal qs = $3053;
          
          return new ESLVal("Cmp",l,translateCases.apply(e),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v2161 = $qualArg;
                
                {ESLVal q = _v2161;
                
                return ESLVal.list(ESLVal.list(translateQual.apply(q)));
              }
              }
            }
          }).map(qs).flatten().flatten());
        }
        }
        }
        }
      case "New": {ESLVal $3052 = _v2155.termRef(0);
          ESLVal $3051 = _v2155.termRef(1);
          ESLVal $3050 = _v2155.termRef(2);
          
          {ESLVal l = $3052;
          
          {ESLVal b = $3051;
          
          {ESLVal args = $3050;
          
          return new ESLVal("New",l,translateCases.apply(b),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v2160 = $qualArg;
                
                {ESLVal e = _v2160;
                
                return ESLVal.list(ESLVal.list(translateCases.apply(e)));
              }
              }
            }
          }).map(args).flatten().flatten());
        }
        }
        }
        }
      case "NewJava": {ESLVal $3049 = _v2155.termRef(0);
          ESLVal $3048 = _v2155.termRef(1);
          ESLVal $3047 = _v2155.termRef(2);
          ESLVal $3046 = _v2155.termRef(3);
          
          {ESLVal l = $3049;
          
          {ESLVal className = $3048;
          
          {ESLVal t = $3047;
          
          {ESLVal args = $3046;
          
          return new ESLVal("NewJava",l,className,t,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v2159 = $qualArg;
                
                {ESLVal e = _v2159;
                
                return ESLVal.list(ESLVal.list(translateCases.apply(e)));
              }
              }
            }
          }).map(args).flatten().flatten());
        }
        }
        }
        }
        }
      case "Let": {ESLVal $3045 = _v2155.termRef(0);
          ESLVal $3044 = _v2155.termRef(1);
          ESLVal $3043 = _v2155.termRef(2);
          
          {ESLVal l = $3045;
          
          {ESLVal bs = $3044;
          
          {ESLVal e = $3043;
          
          return new ESLVal("Let",l,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v2158 = $qualArg;
                
                {ESLVal b = _v2158;
                
                return ESLVal.list(ESLVal.list(translateDef.apply(b)));
              }
              }
            }
          }).map(bs).flatten().flatten(),translateCases.apply(e));
        }
        }
        }
        }
      case "Letrec": {ESLVal $3042 = _v2155.termRef(0);
          ESLVal $3041 = _v2155.termRef(1);
          ESLVal $3040 = _v2155.termRef(2);
          
          {ESLVal l = $3042;
          
          {ESLVal bs = $3041;
          
          {ESLVal e = $3040;
          
          return new ESLVal("Letrec",l,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v2157 = $qualArg;
                
                {ESLVal b = _v2157;
                
                return ESLVal.list(ESLVal.list(translateDef.apply(b)));
              }
              }
            }
          }).map(bs).flatten().flatten(),translateCases.apply(e));
        }
        }
        }
        }
      case "Grab": {ESLVal $3039 = _v2155.termRef(0);
          ESLVal $3038 = _v2155.termRef(1);
          ESLVal $3037 = _v2155.termRef(2);
          
          {ESLVal l = $3039;
          
          {ESLVal rs = $3038;
          
          {ESLVal e = $3037;
          
          return new ESLVal("Grab",l,rs,translateCases.apply(e));
        }
        }
        }
        }
      case "PLet": {ESLVal $3036 = _v2155.termRef(0);
          ESLVal $3035 = _v2155.termRef(1);
          ESLVal $3034 = _v2155.termRef(2);
          
          {ESLVal l = $3036;
          
          {ESLVal bs = $3035;
          
          {ESLVal e = $3034;
          
          return new ESLVal("PLet",l,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v2156 = $qualArg;
                
                {ESLVal b = _v2156;
                
                return ESLVal.list(ESLVal.list(translateDef.apply(b)));
              }
              }
            }
          }).map(bs).flatten().flatten(),translateCases.apply(e));
        }
        }
        }
        }
      case "Probably": {ESLVal $3033 = _v2155.termRef(0);
          ESLVal $3032 = _v2155.termRef(1);
          ESLVal $3031 = _v2155.termRef(2);
          ESLVal $3030 = _v2155.termRef(3);
          ESLVal $3029 = _v2155.termRef(4);
          
          {ESLVal l = $3033;
          
          {ESLVal p = $3032;
          
          {ESLVal t = $3031;
          
          {ESLVal e1 = $3030;
          
          {ESLVal e2 = $3029;
          
          return new ESLVal("Probably",l,translateCases.apply(p),t,translateCases.apply(e1),translateCases.apply(e2));
        }
        }
        }
        }
        }
        }
      case "Not": {ESLVal $3028 = _v2155.termRef(0);
          ESLVal $3027 = _v2155.termRef(1);
          
          {ESLVal l = $3028;
          
          {ESLVal e = $3027;
          
          return new ESLVal("Not",l,translateCases.apply(e));
        }
        }
        }
      case "Fold": {ESLVal $3026 = _v2155.termRef(0);
          ESLVal $3025 = _v2155.termRef(1);
          ESLVal $3024 = _v2155.termRef(2);
          
          {ESLVal l = $3026;
          
          {ESLVal t = $3025;
          
          {ESLVal e = $3024;
          
          return new ESLVal("Fold",l,t,translateCases.apply(e));
        }
        }
        }
        }
      case "Unfold": {ESLVal $3023 = _v2155.termRef(0);
          ESLVal $3022 = _v2155.termRef(1);
          ESLVal $3021 = _v2155.termRef(2);
          
          {ESLVal l = $3023;
          
          {ESLVal t = $3022;
          
          {ESLVal e = $3021;
          
          return new ESLVal("Unfold",l,t,translateCases.apply(e));
        }
        }
        }
        }
      case "Now": {ESLVal $3020 = _v2155.termRef(0);
          
          {ESLVal l = $3020;
          
          return exp;
        }
        }
      case "Become": {ESLVal $3019 = _v2155.termRef(0);
          ESLVal $3018 = _v2155.termRef(1);
          
          {ESLVal l = $3019;
          
          {ESLVal e = $3018;
          
          return new ESLVal("Become",l,translateCases.apply(e));
        }
        }
        }
        default: {ESLVal x = _v2155;
          
          return error(exp);
        }
      }
      }
    }
  });
  private static ESLVal armPatterns = new ESLVal(new Function(new ESLVal("armPatterns"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arm = $args[0];
  {ESLVal _v2154 = arm;
        
        switch(_v2154.termName) {
        case "LArm": {ESLVal $3017 = _v2154.termRef(0);
          ESLVal $3016 = _v2154.termRef(1);
          ESLVal $3015 = _v2154.termRef(2);
          ESLVal $3014 = _v2154.termRef(3);
          ESLVal $3013 = _v2154.termRef(4);
          
          {ESLVal l = $3017;
          
          {ESLVal ps = $3016;
          
          {ESLVal bs = $3015;
          
          {ESLVal g = $3014;
          
          {ESLVal e = $3013;
          
          return ps;
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(8442,8522)").add(ESLVal.list(_v2154)));
      }
      }
    }
  });
  private static ESLVal armBody = new ESLVal(new Function(new ESLVal("armBody"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arm = $args[0];
  {ESLVal _v2153 = arm;
        
        switch(_v2153.termName) {
        case "LArm": {ESLVal $3012 = _v2153.termRef(0);
          ESLVal $3011 = _v2153.termRef(1);
          ESLVal $3010 = _v2153.termRef(2);
          ESLVal $3009 = _v2153.termRef(3);
          ESLVal $3008 = _v2153.termRef(4);
          
          {ESLVal l = $3012;
          
          {ESLVal ps = $3011;
          
          {ESLVal bs = $3010;
          
          {ESLVal g = $3009;
          
          {ESLVal e = $3008;
          
          return e;
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(8551,8630)").add(ESLVal.list(_v2153)));
      }
      }
    }
  });
  private static ESLVal armGuard = new ESLVal(new Function(new ESLVal("armGuard"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arm = $args[0];
  {ESLVal _v2152 = arm;
        
        switch(_v2152.termName) {
        case "LArm": {ESLVal $3007 = _v2152.termRef(0);
          ESLVal $3006 = _v2152.termRef(1);
          ESLVal $3005 = _v2152.termRef(2);
          ESLVal $3004 = _v2152.termRef(3);
          ESLVal $3003 = _v2152.termRef(4);
          
          {ESLVal l = $3007;
          
          {ESLVal ps = $3006;
          
          {ESLVal bs = $3005;
          
          {ESLVal g = $3004;
          
          {ESLVal e = $3003;
          
          return g;
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(8660,8739)").add(ESLVal.list(_v2152)));
      }
      }
    }
  });
  private static ESLVal setArmBody = new ESLVal(new Function(new ESLVal("setArmBody"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arm = $args[0];
  ESLVal e = $args[1];
  {ESLVal _v2151 = arm;
        
        switch(_v2151.termName) {
        case "LArm": {ESLVal $3002 = _v2151.termRef(0);
          ESLVal $3001 = _v2151.termRef(1);
          ESLVal $3000 = _v2151.termRef(2);
          ESLVal $2999 = _v2151.termRef(3);
          ESLVal $2998 = _v2151.termRef(4);
          
          {ESLVal l = $3002;
          
          {ESLVal ps = $3001;
          
          {ESLVal bs = $3000;
          
          {ESLVal g = $2999;
          
          {ESLVal old = $2998;
          
          return new ESLVal("LArm",l,ps,bs,g,e);
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(8778,8875)").add(ESLVal.list(_v2151)));
      }
      }
    }
  });
  private static ESLVal setArmPatterns = new ESLVal(new Function(new ESLVal("setArmPatterns"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arm = $args[0];
  ESLVal ps = $args[1];
  {ESLVal _v2150 = arm;
        
        switch(_v2150.termName) {
        case "LArm": {ESLVal $2997 = _v2150.termRef(0);
          ESLVal $2996 = _v2150.termRef(1);
          ESLVal $2995 = _v2150.termRef(2);
          ESLVal $2994 = _v2150.termRef(3);
          ESLVal $2993 = _v2150.termRef(4);
          
          {ESLVal l = $2997;
          
          {ESLVal old = $2996;
          
          {ESLVal bs = $2995;
          
          {ESLVal g = $2994;
          
          {ESLVal e = $2993;
          
          return new ESLVal("LArm",l,ps,bs,g,e);
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(8925,9022)").add(ESLVal.list(_v2150)));
      }
      }
    }
  });
  private static ESLVal addArmBindings = new ESLVal(new Function(new ESLVal("addArmBindings"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arm = $args[0];
  ESLVal newBS = $args[1];
  {ESLVal _v2149 = arm;
        
        switch(_v2149.termName) {
        case "LArm": {ESLVal $2992 = _v2149.termRef(0);
          ESLVal $2991 = _v2149.termRef(1);
          ESLVal $2990 = _v2149.termRef(2);
          ESLVal $2989 = _v2149.termRef(3);
          ESLVal $2988 = _v2149.termRef(4);
          
          {ESLVal l = $2992;
          
          {ESLVal ps = $2991;
          
          {ESLVal bs = $2990;
          
          {ESLVal g = $2989;
          
          {ESLVal e = $2988;
          
          return new ESLVal("LArm",l,ps,bs.add(ESLVal.list(newBS)),g,e);
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(9073,9178)").add(ESLVal.list(_v2149)));
      }
      }
    }
  });
  private static ESLVal isPVar = new ESLVal(new Function(new ESLVal("isPVar"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2148 = p;
        
        switch(_v2148.termName) {
        case "PVar": {ESLVal $2987 = _v2148.termRef(0);
          ESLVal $2986 = _v2148.termRef(1);
          ESLVal $2985 = _v2148.termRef(2);
          
          {ESLVal l = $2987;
          
          {ESLVal n = $2986;
          
          {ESLVal t = $2985;
          
          return $true;
        }
        }
        }
        }
        default: {ESLVal _v2197 = _v2148;
          
          return $false;
        }
      }
      }
    }
  });
  private static ESLVal isPInt = new ESLVal(new Function(new ESLVal("isPInt"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2147 = p;
        
        switch(_v2147.termName) {
        case "PInt": {ESLVal $2984 = _v2147.termRef(0);
          ESLVal $2983 = _v2147.termRef(1);
          
          {ESLVal l = $2984;
          
          {ESLVal n = $2983;
          
          return $true;
        }
        }
        }
        default: {ESLVal _v2196 = _v2147;
          
          return $false;
        }
      }
      }
    }
  });
  private static ESLVal isPStr = new ESLVal(new Function(new ESLVal("isPStr"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2146 = p;
        
        switch(_v2146.termName) {
        case "PStr": {ESLVal $2982 = _v2146.termRef(0);
          ESLVal $2981 = _v2146.termRef(1);
          
          {ESLVal l = $2982;
          
          {ESLVal n = $2981;
          
          return $true;
        }
        }
        }
        default: {ESLVal _v2195 = _v2146;
          
          return $false;
        }
      }
      }
    }
  });
  private static ESLVal isPBool = new ESLVal(new Function(new ESLVal("isPBool"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2145 = p;
        
        switch(_v2145.termName) {
        case "PBool": {ESLVal $2980 = _v2145.termRef(0);
          ESLVal $2979 = _v2145.termRef(1);
          
          {ESLVal l = $2980;
          
          {ESLVal b = $2979;
          
          return $true;
        }
        }
        }
        default: {ESLVal _v2194 = _v2145;
          
          return $false;
        }
      }
      }
    }
  });
  private static ESLVal isPTerm = new ESLVal(new Function(new ESLVal("isPTerm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2144 = p;
        
        switch(_v2144.termName) {
        case "PTerm": {ESLVal $2978 = _v2144.termRef(0);
          ESLVal $2977 = _v2144.termRef(1);
          ESLVal $2976 = _v2144.termRef(2);
          ESLVal $2975 = _v2144.termRef(3);
          
          {ESLVal l = $2978;
          
          {ESLVal n = $2977;
          
          {ESLVal ts = $2976;
          
          {ESLVal ps = $2975;
          
          return $true;
        }
        }
        }
        }
        }
        default: {ESLVal _v2193 = _v2144;
          
          return $false;
        }
      }
      }
    }
  });
  private static ESLVal isPCons = new ESLVal(new Function(new ESLVal("isPCons"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2143 = p;
        
        switch(_v2143.termName) {
        case "PCons": {ESLVal $2974 = _v2143.termRef(0);
          ESLVal $2973 = _v2143.termRef(1);
          ESLVal $2972 = _v2143.termRef(2);
          
          {ESLVal l = $2974;
          
          {ESLVal h = $2973;
          
          {ESLVal t = $2972;
          
          return $true;
        }
        }
        }
        }
        default: {ESLVal _v2192 = _v2143;
          
          return $false;
        }
      }
      }
    }
  });
  private static ESLVal isPNil = new ESLVal(new Function(new ESLVal("isPNil"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2142 = p;
        
        switch(_v2142.termName) {
        case "PNil": {ESLVal $2971 = _v2142.termRef(0);
          
          {ESLVal l = $2971;
          
          return $true;
        }
        }
      case "PApplyType": {ESLVal $2969 = _v2142.termRef(0);
          ESLVal $2968 = _v2142.termRef(1);
          ESLVal $2967 = _v2142.termRef(2);
          
          switch($2968.termName) {
          case "PNil": {ESLVal $2970 = $2968.termRef(0);
            
            {ESLVal l1 = $2969;
            
            {ESLVal l2 = $2970;
            
            {ESLVal ts = $2967;
            
            return $true;
          }
          }
          }
          }
          default: {ESLVal _v2190 = _v2142;
            
            return $false;
          }
        }
        }
        default: {ESLVal _v2191 = _v2142;
          
          return $false;
        }
      }
      }
    }
  });
  private static ESLVal isPList = new ESLVal(new Function(new ESLVal("isPList"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  return isPCons.apply(p).or(isPNil.apply(p));
    }
  });
  private static ESLVal isPNonDetList = new ESLVal(new Function(new ESLVal("isPNonDetList"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  return isPAdd.apply(p);
    }
  });
  private static ESLVal isPSetCons = new ESLVal(new Function(new ESLVal("isPSetCons"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2141 = p;
        
        switch(_v2141.termName) {
        case "PSetCons": {ESLVal $2966 = _v2141.termRef(0);
          ESLVal $2965 = _v2141.termRef(1);
          ESLVal $2964 = _v2141.termRef(2);
          
          {ESLVal l = $2966;
          
          {ESLVal p1 = $2965;
          
          {ESLVal p2 = $2964;
          
          return $true;
        }
        }
        }
        }
        default: {ESLVal _v2189 = _v2141;
          
          return $false;
        }
      }
      }
    }
  });
  private static ESLVal isPEmptySet = new ESLVal(new Function(new ESLVal("isPEmptySet"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2140 = p;
        
        switch(_v2140.termName) {
        case "PEmptySet": {ESLVal $2963 = _v2140.termRef(0);
          
          {ESLVal l = $2963;
          
          return $true;
        }
        }
        default: {ESLVal _v2188 = _v2140;
          
          return $false;
        }
      }
      }
    }
  });
  private static ESLVal isPAdd = new ESLVal(new Function(new ESLVal("isPAdd"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2139 = p;
        
        switch(_v2139.termName) {
        case "PAdd": {ESLVal $2962 = _v2139.termRef(0);
          ESLVal $2961 = _v2139.termRef(1);
          ESLVal $2960 = _v2139.termRef(2);
          
          {ESLVal l = $2962;
          
          {ESLVal p1 = $2961;
          
          {ESLVal p2 = $2960;
          
          return $true;
        }
        }
        }
        }
        default: {ESLVal _v2187 = _v2139;
          
          return $false;
        }
      }
      }
    }
  });
  private static ESLVal isPSet = new ESLVal(new Function(new ESLVal("isPSet"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  return isPSetCons.apply(p).or(isPEmptySet.apply(p));
    }
  });
  private static ESLVal pTermName = new ESLVal(new Function(new ESLVal("pTermName"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2138 = p;
        
        switch(_v2138.termName) {
        case "PTerm": {ESLVal $2959 = _v2138.termRef(0);
          ESLVal $2958 = _v2138.termRef(1);
          ESLVal $2957 = _v2138.termRef(2);
          ESLVal $2956 = _v2138.termRef(3);
          
          {ESLVal l = $2959;
          
          {ESLVal n = $2958;
          
          {ESLVal ts = $2957;
          
          {ESLVal ps = $2956;
          
          return n;
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(10558,10626)").add(ESLVal.list(_v2138)));
      }
      }
    }
  });
  private static ESLVal pTermArgs = new ESLVal(new Function(new ESLVal("pTermArgs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2137 = p;
        
        switch(_v2137.termName) {
        case "PTerm": {ESLVal $2955 = _v2137.termRef(0);
          ESLVal $2954 = _v2137.termRef(1);
          ESLVal $2953 = _v2137.termRef(2);
          ESLVal $2952 = _v2137.termRef(3);
          
          {ESLVal l = $2955;
          
          {ESLVal n = $2954;
          
          {ESLVal ts = $2953;
          
          {ESLVal ps = $2952;
          
          return ps;
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(10666,10735)").add(ESLVal.list(_v2137)));
      }
      }
    }
  });
  private static ESLVal pVarName = new ESLVal(new Function(new ESLVal("pVarName"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2136 = p;
        
        switch(_v2136.termName) {
        case "PVar": {ESLVal $2951 = _v2136.termRef(0);
          ESLVal $2950 = _v2136.termRef(1);
          ESLVal $2949 = _v2136.termRef(2);
          
          {ESLVal l = $2951;
          
          {ESLVal n = $2950;
          
          {ESLVal t = $2949;
          
          return n;
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(10768,10818)").add(ESLVal.list(_v2136)));
      }
      }
    }
  });
  private static ESLVal pConsHead = new ESLVal(new Function(new ESLVal("pConsHead"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2135 = p;
        
        switch(_v2135.termName) {
        case "PCons": {ESLVal $2948 = _v2135.termRef(0);
          ESLVal $2947 = _v2135.termRef(1);
          ESLVal $2946 = _v2135.termRef(2);
          
          {ESLVal l = $2948;
          
          {ESLVal h = $2947;
          
          {ESLVal t = $2946;
          
          return h;
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(10856,10914)").add(ESLVal.list(_v2135)));
      }
      }
    }
  });
  private static ESLVal pConsTail = new ESLVal(new Function(new ESLVal("pConsTail"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2134 = p;
        
        switch(_v2134.termName) {
        case "PCons": {ESLVal $2945 = _v2134.termRef(0);
          ESLVal $2944 = _v2134.termRef(1);
          ESLVal $2943 = _v2134.termRef(2);
          
          {ESLVal l = $2945;
          
          {ESLVal h = $2944;
          
          {ESLVal t = $2943;
          
          return t;
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(10952,11010)").add(ESLVal.list(_v2134)));
      }
      }
    }
  });
  private static ESLVal pSetConsHead = new ESLVal(new Function(new ESLVal("pSetConsHead"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2133 = p;
        
        switch(_v2133.termName) {
        case "PSetCons": {ESLVal $2942 = _v2133.termRef(0);
          ESLVal $2941 = _v2133.termRef(1);
          ESLVal $2940 = _v2133.termRef(2);
          
          {ESLVal l = $2942;
          
          {ESLVal h = $2941;
          
          {ESLVal t = $2940;
          
          return h;
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(11051,11112)").add(ESLVal.list(_v2133)));
      }
      }
    }
  });
  private static ESLVal pSetConsTail = new ESLVal(new Function(new ESLVal("pSetConsTail"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2132 = p;
        
        switch(_v2132.termName) {
        case "PSetCons": {ESLVal $2939 = _v2132.termRef(0);
          ESLVal $2938 = _v2132.termRef(1);
          ESLVal $2937 = _v2132.termRef(2);
          
          {ESLVal l = $2939;
          
          {ESLVal h = $2938;
          
          {ESLVal t = $2937;
          
          return t;
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(11153,11214)").add(ESLVal.list(_v2132)));
      }
      }
    }
  });
  private static ESLVal pAddLeft = new ESLVal(new Function(new ESLVal("pAddLeft"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2131 = p;
        
        switch(_v2131.termName) {
        case "PAdd": {ESLVal $2936 = _v2131.termRef(0);
          ESLVal $2935 = _v2131.termRef(1);
          ESLVal $2934 = _v2131.termRef(2);
          
          {ESLVal l = $2936;
          
          {ESLVal left = $2935;
          
          {ESLVal right = $2934;
          
          return left;
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(11250,11317)").add(ESLVal.list(_v2131)));
      }
      }
    }
  });
  private static ESLVal pAddRight = new ESLVal(new Function(new ESLVal("pAddRight"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2130 = p;
        
        switch(_v2130.termName) {
        case "PAdd": {ESLVal $2933 = _v2130.termRef(0);
          ESLVal $2932 = _v2130.termRef(1);
          ESLVal $2931 = _v2130.termRef(2);
          
          {ESLVal l = $2933;
          
          {ESLVal left = $2932;
          
          {ESLVal right = $2931;
          
          return right;
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(11354,11422)").add(ESLVal.list(_v2130)));
      }
      }
    }
  });
  private static ESLVal pIntValue = new ESLVal(new Function(new ESLVal("pIntValue"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2129 = p;
        
        switch(_v2129.termName) {
        case "PInt": {ESLVal $2930 = _v2129.termRef(0);
          ESLVal $2929 = _v2129.termRef(1);
          
          {ESLVal l = $2930;
          
          {ESLVal n = $2929;
          
          return n;
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(11456,11498)").add(ESLVal.list(_v2129)));
      }
      }
    }
  });
  private static ESLVal pStrValue = new ESLVal(new Function(new ESLVal("pStrValue"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2128 = p;
        
        switch(_v2128.termName) {
        case "PStr": {ESLVal $2928 = _v2128.termRef(0);
          ESLVal $2927 = _v2128.termRef(1);
          
          {ESLVal l = $2928;
          
          {ESLVal n = $2927;
          
          return n;
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(11532,11574)").add(ESLVal.list(_v2128)));
      }
      }
    }
  });
  private static ESLVal pBoolValue = new ESLVal(new Function(new ESLVal("pBoolValue"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v2127 = p;
        
        switch(_v2127.termName) {
        case "PBool": {ESLVal $2926 = _v2127.termRef(0);
          ESLVal $2925 = _v2127.termRef(1);
          
          {ESLVal l = $2926;
          
          {ESLVal b = $2925;
          
          return b;
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(11610,11655)").add(ESLVal.list(_v2127)));
      }
      }
    }
  });
  private static ESLVal isEmptyPatterns = new ESLVal(new Function(new ESLVal("isEmptyPatterns"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  return forall.apply(new ESLVal(new Function(new ESLVal("fun1047"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return length.apply(armPatterns.apply(a)).eql($zero);
          }
        }),arms);
    }
  });
  private static ESLVal isFirstColumnVars = new ESLVal(new Function(new ESLVal("isFirstColumnVars"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  return forall.apply(new ESLVal(new Function(new ESLVal("fun1048"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPVar.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms);
    }
  });
  private static ESLVal isFirstColumnInts = new ESLVal(new Function(new ESLVal("isFirstColumnInts"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  return forall.apply(new ESLVal(new Function(new ESLVal("fun1049"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPInt.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms);
    }
  });
  private static ESLVal isFirstColumnStrs = new ESLVal(new Function(new ESLVal("isFirstColumnStrs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  return forall.apply(new ESLVal(new Function(new ESLVal("fun1050"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPStr.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms);
    }
  });
  private static ESLVal isFirstColumnBools = new ESLVal(new Function(new ESLVal("isFirstColumnBools"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  return forall.apply(new ESLVal(new Function(new ESLVal("fun1051"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPBool.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms);
    }
  });
  private static ESLVal isFirstColumnCnstrs = new ESLVal(new Function(new ESLVal("isFirstColumnCnstrs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  return forall.apply(new ESLVal(new Function(new ESLVal("fun1052"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPTerm.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms);
    }
  });
  private static ESLVal isFirstColumnSets = new ESLVal(new Function(new ESLVal("isFirstColumnSets"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  return forall.apply(new ESLVal(new Function(new ESLVal("fun1053"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPSet.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms);
    }
  });
  private static ESLVal isFirstColumnNonDetLists = new ESLVal(new Function(new ESLVal("isFirstColumnNonDetLists"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  return forall.apply(new ESLVal(new Function(new ESLVal("fun1054"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPNonDetList.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms);
    }
  });
  private static ESLVal isFirstColumnLists = new ESLVal(new Function(new ESLVal("isFirstColumnLists"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  {ESLVal isList = new ESLVal(new Function(new ESLVal("isList"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal a = $args[0];
          return isPCons.apply(head.apply(armPatterns.apply(a))).or(isPNil.apply(head.apply(armPatterns.apply(a))));
            }
          });
        
        return forall.apply(isList,arms);
      }
    }
  });
  private static ESLVal dropPattern = new ESLVal(new Function(new ESLVal("dropPattern"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arm = $args[0];
  return setArmPatterns.apply(arm,tail.apply(armPatterns.apply(arm)));
    }
  });
  private static ESLVal firstVarNames = new ESLVal(new Function(new ESLVal("firstVarNames"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  return map.apply(new ESLVal(new Function(new ESLVal("fun1055"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return pVarName.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms);
    }
  });
  private static ESLVal sharedCnstr = new ESLVal(new Function(new ESLVal("sharedCnstr"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  return pTermName.apply(head.apply(armPatterns.apply(head.apply(arms))));
    }
  });
  private static ESLVal sharedInt = new ESLVal(new Function(new ESLVal("sharedInt"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  return pIntValue.apply(head.apply(armPatterns.apply(head.apply(arms))));
    }
  });
  private static ESLVal sharedStr = new ESLVal(new Function(new ESLVal("sharedStr"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  return pStrValue.apply(head.apply(armPatterns.apply(head.apply(arms))));
    }
  });
  private static ESLVal sharedBool = new ESLVal(new Function(new ESLVal("sharedBool"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  return pBoolValue.apply(head.apply(armPatterns.apply(head.apply(arms))));
    }
  });
  private static ESLVal bindVarsBody = new ESLVal(new Function(new ESLVal("bindVarsBody"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  ESLVal vNames = $args[1];
  return new ESLVal(new Function(new ESLVal("fun1056"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal arms = $args[0];
        LetRec letrec = new LetRec() {
              ESLVal bind = new ESLVal(new Function(new ESLVal("bind"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal _v2182 = $args[0];
                ESLVal _v2181 = $args[1];
                {ESLVal _v2125 = _v2182;
                      ESLVal _v2124 = _v2181;
                      
                      if(_v2125.isCons())
                      {ESLVal $2917 = _v2125.head();
                        ESLVal $2918 = _v2125.tail();
                        
                        if(_v2124.isCons())
                        {ESLVal $2919 = _v2124.head();
                          ESLVal $2920 = _v2124.tail();
                          
                          {ESLVal a = $2917;
                          
                          {ESLVal _v2183 = $2918;
                          
                          {ESLVal v = $2919;
                          
                          {ESLVal _v2184 = $2920;
                          
                          {ESLVal _v2126 = e;
                          
                          switch(_v2126.termName) {
                          case "Var": {ESLVal $2924 = _v2126.termRef(0);
                            ESLVal $2923 = _v2126.termRef(1);
                            
                            {ESLVal l = $2924;
                            
                            {ESLVal n = $2923;
                            
                            if(n.eql(v).boolVal)
                            return bind.apply(_v2183,_v2184).cons(a);
                            else
                              {ESLVal _v2185 = _v2126;
                                
                                return bind.apply(_v2183,_v2184).cons(addArmBindings.apply(a,ESLVal.list(new ESLVal("Binding",loc0,v,voidType,voidType,_v2185))));
                              }
                          }
                          }
                          }
                          default: {ESLVal _v2186 = _v2126;
                            
                            return bind.apply(_v2183,_v2184).cons(addArmBindings.apply(a,ESLVal.list(new ESLVal("Binding",loc0,v,voidType,voidType,_v2186))));
                          }
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                      else if(_v2124.isNil())
                        return error(new ESLVal("case error at Pos(13825,14135)").add(ESLVal.list(_v2125,_v2124)));
                      else return error(new ESLVal("case error at Pos(13825,14135)").add(ESLVal.list(_v2125,_v2124)));
                      }
                    else if(_v2125.isNil())
                      if(_v2124.isCons())
                        {ESLVal $2921 = _v2124.head();
                          ESLVal $2922 = _v2124.tail();
                          
                          return error(new ESLVal("case error at Pos(13825,14135)").add(ESLVal.list(_v2125,_v2124)));
                        }
                      else if(_v2124.isNil())
                        return $nil;
                      else return error(new ESLVal("case error at Pos(13825,14135)").add(ESLVal.list(_v2125,_v2124)));
                    else return error(new ESLVal("case error at Pos(13825,14135)").add(ESLVal.list(_v2125,_v2124)));
                    }
                  }
                });
              
              public ESLVal get(String name) {
                switch(name) {
                  case "bind": return bind;
                  
                  default: throw new Error("cannot find letrec binding");
                }
                }
              };
            ESLVal bind = letrec.get("bind");
            
              return bind.apply(arms,vNames);
            
          }
        });
    }
  });
  private static ESLVal bindVars = new ESLVal(new Function(new ESLVal("bindVars"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  ESLVal arms = $args[1];
  return bindVarsBody.apply(e,firstVarNames.apply(arms)).apply(map.apply(dropPattern,arms));
    }
  });
  private static ESLVal cnstrArms = new ESLVal(new Function(new ESLVal("cnstrArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal c = $args[0];
  ESLVal arms = $args[1];
  return filter.apply(new ESLVal(new Function(new ESLVal("fun1057"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return pTermName.apply(head.apply(armPatterns.apply(a))).eql(c);
          }
        }),arms);
    }
  });
  private static ESLVal intArms = new ESLVal(new Function(new ESLVal("intArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal n = $args[0];
  ESLVal arms = $args[1];
  return filter.apply(new ESLVal(new Function(new ESLVal("fun1058"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return pIntValue.apply(head.apply(armPatterns.apply(a))).eql(n);
          }
        }),arms);
    }
  });
  private static ESLVal strArms = new ESLVal(new Function(new ESLVal("strArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal s = $args[0];
  ESLVal arms = $args[1];
  return filter.apply(new ESLVal(new Function(new ESLVal("fun1059"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return pStrValue.apply(head.apply(armPatterns.apply(a))).eql(s);
          }
        }),arms);
    }
  });
  private static ESLVal boolArms = new ESLVal(new Function(new ESLVal("boolArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal b = $args[0];
  ESLVal arms = $args[1];
  return filter.apply(new ESLVal(new Function(new ESLVal("fun1060"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return pBoolValue.apply(head.apply(armPatterns.apply(a))).eql(b);
          }
        }),arms);
    }
  });
  private static ESLVal fieldBindings = new ESLVal(new Function(new ESLVal("fieldBindings"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  ESLVal names = $args[1];
  return new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v2123 = $qualArg;
              
              {ESLVal n = _v2123;
              
              return ESLVal.list(ESLVal.list(new ESLVal("Binding",loc0,n,voidType,voidType,new ESLVal("TermRef",e,indexOf.apply(n,names)))));
            }
            }
          }
        }).map(names).flatten().flatten();
    }
  });
  private static ESLVal explodeCnstr = new ESLVal(new Function(new ESLVal("explodeCnstr"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal a = $args[0];
  return setArmPatterns.apply(a,pTermArgs.apply(head.apply(armPatterns.apply(a))).add(tail.apply(armPatterns.apply(a))));
    }
  });
  private static ESLVal explodeCons = new ESLVal(new Function(new ESLVal("explodeCons"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal a = $args[0];
  return setArmPatterns.apply(a,ESLVal.list(pConsHead.apply(head.apply(armPatterns.apply(a))),pConsTail.apply(head.apply(armPatterns.apply(a)))).add(tail.apply(armPatterns.apply(a))));
    }
  });
  private static ESLVal explodeSetCons = new ESLVal(new Function(new ESLVal("explodeSetCons"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal a = $args[0];
  return setArmPatterns.apply(a,ESLVal.list(pSetConsHead.apply(head.apply(armPatterns.apply(a))),pSetConsTail.apply(head.apply(armPatterns.apply(a)))).add(tail.apply(armPatterns.apply(a))));
    }
  });
  private static ESLVal explodeAdd = new ESLVal(new Function(new ESLVal("explodeAdd"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal a = $args[0];
  return setArmPatterns.apply(a,ESLVal.list(pAddLeft.apply(head.apply(armPatterns.apply(a))),pAddRight.apply(head.apply(armPatterns.apply(a)))).add(tail.apply(armPatterns.apply(a))));
    }
  });
  private static ESLVal cnstrArm = new ESLVal(new Function(new ESLVal("cnstrArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal e = $args[1];
  ESLVal es = $args[2];
  ESLVal arms = $args[3];
  ESLVal alt = $args[4];
  {ESLVal names = newVars.apply(length.apply(pTermArgs.apply(head.apply(armPatterns.apply(head.apply(arms))))));
        
        return new ESLVal("Let",loc0,fieldBindings.apply(e,names),compileCase.apply(l,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v2121 = $qualArg;
              
              {ESLVal n = _v2121;
              
              return ESLVal.list(ESLVal.list(new ESLVal("Var",loc0,n)));
            }
            }
          }
        }).map(names).flatten().flatten().add(es),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v2122 = $qualArg;
              
              {ESLVal a = _v2122;
              
              return ESLVal.list(ESLVal.list(explodeCnstr.apply(a)));
            }
            }
          }
        }).map(arms).flatten().flatten(),alt));
      }
    }
  });
  private static ESLVal processCnstrs = new ESLVal(new Function(new ESLVal("processCnstrs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  {ESLVal cnstrs = removeDups.apply(map.apply(pTermName,map.apply(head,map.apply(armPatterns,arms))));
        
        {ESLVal armss = map.apply(new ESLVal(new Function(new ESLVal("fun1061"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal c = $args[0];
          return cnstrArms.apply(c,arms);
            }
          }),cnstrs);
        
        return new ESLVal("CaseTerm",l,head.apply(es),createTArms.apply(l,armss,es,alt),alt);
      }
      }
    }
  });
  private static ESLVal createTArms = new ESLVal(new Function(new ESLVal("createTArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal armss = $args[1];
  ESLVal es = $args[2];
  ESLVal alt = $args[3];
  {ESLVal _v2120 = armss;
        
        if(_v2120.isCons())
        {ESLVal $2915 = _v2120.head();
          ESLVal $2916 = _v2120.tail();
          
          {ESLVal as = $2915;
          
          {ESLVal _v2180 = $2916;
          
          return createTArms.apply(l,_v2180,es,alt).cons(new ESLVal("TArm",sharedCnstr.apply(as),cnstrArm.apply(l,head.apply(es),tail.apply(es),as,alt)));
        }
        }
        }
      else if(_v2120.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(16496,16676)").add(ESLVal.list(_v2120)));
      }
    }
  });
  private static ESLVal processConsArms = new ESLVal(new Function(new ESLVal("processConsArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal loc = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  {ESLVal l = head.apply(es);
        ESLVal hn = newVar.apply();
        ESLVal tn = newVar.apply();
        
        {ESLVal hp = new ESLVal("PVar",loc0,hn,voidType);
        ESLVal tp = new ESLVal("PVar",loc0,tn,voidType);
        ESLVal hv = new ESLVal("Var",loc0,hn);
        ESLVal tv = new ESLVal("Var",loc0,tn);
        
        return new ESLVal("Let",loc0,ESLVal.list(new ESLVal("Binding",loc0,hn,voidType,voidType,new ESLVal("Head",l)),new ESLVal("Binding",loc0,tn,voidType,voidType,new ESLVal("Tail",l))),compileCase.apply(loc,ESLVal.list(hv,tv).add(tail.apply(es)),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v2119 = $qualArg;
              
              {ESLVal a = _v2119;
              
              return ESLVal.list(ESLVal.list(explodeCons.apply(a)));
            }
            }
          }
        }).map(arms).flatten().flatten(),alt));
      }
      }
    }
  });
  private static ESLVal processLists = new ESLVal(new Function(new ESLVal("processLists"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  {ESLVal consArms = filter.apply(new ESLVal(new Function(new ESLVal("fun1062"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal a = $args[0];
          return isPCons.apply(head.apply(armPatterns.apply(a)));
            }
          }),arms);
        ESLVal nilArms = map.apply(dropPattern,filter.apply(new ESLVal(new Function(new ESLVal("fun1063"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal a = $args[0];
          return isPNil.apply(head.apply(armPatterns.apply(a)));
            }
          }),arms));
        
        return new ESLVal("CaseList",l,head.apply(es),processConsArms.apply(l,es,consArms,alt),compileCase.apply(l,tail.apply(es),nilArms,alt),alt);
      }
    }
  });
  private static ESLVal processSetArms = new ESLVal(new Function(new ESLVal("processSetArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arm = $args[2];
  {ESLVal _v2118 = head.apply(armPatterns.apply(arm));
        
        switch(_v2118.termName) {
        case "PEmptySet": {ESLVal $2914 = _v2118.termRef(0);
          
          {ESLVal pl = $2914;
          
          {ESLVal fail = newVar.apply();
          
          return new ESLVal("Term",l,new ESLVal("$empty"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("emptyset")),ESLVal.list(new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase.apply(l,es,ESLVal.list(dropPattern.apply(arm)),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
        }
        }
        }
      case "PSetCons": {ESLVal $2913 = _v2118.termRef(0);
          ESLVal $2912 = _v2118.termRef(1);
          ESLVal $2911 = _v2118.termRef(2);
          
          {ESLVal pl = $2913;
          
          {ESLVal p1 = $2912;
          
          {ESLVal p2 = $2911;
          
          {ESLVal fail = newVar.apply();
          ESLVal element = newVar.apply();
          ESLVal rest = newVar.apply();
          
          return new ESLVal("Term",l,new ESLVal("$cons"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("setcons")),ESLVal.list(new ESLVal("Dec",l,element,$null,$null),new ESLVal("Dec",l,rest,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase.apply(l,ESLVal.list(new ESLVal("Var",l,element),new ESLVal("Var",l,rest)).add(es),ESLVal.list(explodeSetCons.apply(arm)),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
        }
        }
        }
        }
        }
      case "PAdd": {ESLVal $2910 = _v2118.termRef(0);
          ESLVal $2909 = _v2118.termRef(1);
          ESLVal $2908 = _v2118.termRef(2);
          
          {ESLVal pl = $2910;
          
          {ESLVal p1 = $2909;
          
          {ESLVal p2 = $2908;
          
          {ESLVal fail = newVar.apply();
          ESLVal left = newVar.apply();
          ESLVal right = newVar.apply();
          
          return new ESLVal("Term",l,new ESLVal("$add"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("setadd")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase.apply(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,right)).add(es),ESLVal.list(explodeAdd.apply(arm)),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(17621,18742)").add(ESLVal.list(_v2118)));
      }
      }
    }
  });
  private static ESLVal processNonDetListArms = new ESLVal(new Function(new ESLVal("processNonDetListArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arm = $args[2];
  {ESLVal _v2117 = head.apply(armPatterns.apply(arm));
        
        switch(_v2117.termName) {
        case "PNil": {ESLVal $2907 = _v2117.termRef(0);
          
          {ESLVal pl = $2907;
          
          {ESLVal fail = newVar.apply();
          
          return new ESLVal("Term",l,new ESLVal("$empty"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("nil")),ESLVal.list(new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase.apply(l,es,ESLVal.list(dropPattern.apply(arm)),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
        }
        }
        }
      case "PCons": {ESLVal $2906 = _v2117.termRef(0);
          ESLVal $2905 = _v2117.termRef(1);
          ESLVal $2904 = _v2117.termRef(2);
          
          {ESLVal pl = $2906;
          
          {ESLVal p1 = $2905;
          
          {ESLVal p2 = $2904;
          
          {ESLVal fail = newVar.apply();
          ESLVal element = newVar.apply();
          ESLVal rest = newVar.apply();
          
          return new ESLVal("Term",l,new ESLVal("$cons"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("cons")),ESLVal.list(new ESLVal("Dec",l,element,$null,$null),new ESLVal("Dec",l,rest,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase.apply(l,ESLVal.list(new ESLVal("Var",l,element),new ESLVal("Var",l,rest)).add(es),ESLVal.list(explodeCons.apply(arm)),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
        }
        }
        }
        }
        }
      case "PAdd": {ESLVal $2881 = _v2117.termRef(0);
          ESLVal $2880 = _v2117.termRef(1);
          ESLVal $2879 = _v2117.termRef(2);
          
          switch($2880.termName) {
          case "PCons": {ESLVal $2902 = $2880.termRef(0);
            ESLVal $2901 = $2880.termRef(1);
            ESLVal $2900 = $2880.termRef(2);
            
            switch($2900.termName) {
            case "PNil": {ESLVal $2903 = $2900.termRef(0);
              
              {ESLVal l1 = $2881;
              
              {ESLVal l2 = $2902;
              
              {ESLVal p1 = $2901;
              
              {ESLVal l3 = $2903;
              
              {ESLVal p2 = $2879;
              
              {ESLVal fail = newVar.apply();
              ESLVal left = newVar.apply();
              ESLVal right = newVar.apply();
              ESLVal newArm = setArmPatterns.apply(arm,ESLVal.list(p1,p2).add(tail.apply(armPatterns.apply(arm))));
              
              return new ESLVal("Term",l,new ESLVal("$selectLeft"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase.apply(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
            }
            }
            }
            }
            }
            }
            }
            default: switch($2879.termName) {
              case "PCons": {ESLVal $2891 = $2879.termRef(0);
                ESLVal $2890 = $2879.termRef(1);
                ESLVal $2889 = $2879.termRef(2);
                
                switch($2889.termName) {
                case "PNil": {ESLVal $2892 = $2889.termRef(0);
                  
                  {ESLVal l1 = $2881;
                  
                  {ESLVal p1 = $2880;
                  
                  {ESLVal l2 = $2891;
                  
                  {ESLVal p2 = $2890;
                  
                  {ESLVal l3 = $2892;
                  
                  {ESLVal fail = newVar.apply();
                  ESLVal left = newVar.apply();
                  ESLVal right = newVar.apply();
                  ESLVal newArm = setArmPatterns.apply(arm,ESLVal.list(p1,p2).add(tail.apply(armPatterns.apply(arm))));
                  
                  return new ESLVal("Term",l,new ESLVal("$selectRight"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase.apply(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
                }
                }
                }
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2117)));
              }
              }
            case "PAdd": {ESLVal $2884 = $2879.termRef(0);
                ESLVal $2883 = $2879.termRef(1);
                ESLVal $2882 = $2879.termRef(2);
                
                switch($2883.termName) {
                case "PCons": {ESLVal $2887 = $2883.termRef(0);
                  ESLVal $2886 = $2883.termRef(1);
                  ESLVal $2885 = $2883.termRef(2);
                  
                  switch($2885.termName) {
                  case "PNil": {ESLVal $2888 = $2885.termRef(0);
                    
                    {ESLVal l1 = $2881;
                    
                    {ESLVal p1 = $2880;
                    
                    {ESLVal l2 = $2884;
                    
                    {ESLVal l3 = $2887;
                    
                    {ESLVal p2 = $2886;
                    
                    {ESLVal l4 = $2888;
                    
                    {ESLVal p3 = $2882;
                    
                    {ESLVal fail = newVar.apply();
                    ESLVal left = newVar.apply();
                    ESLVal mid = newVar.apply();
                    ESLVal right = newVar.apply();
                    ESLVal newArm = setArmPatterns.apply(arm,ESLVal.list(p1,p2,p3).add(tail.apply(armPatterns.apply(arm))));
                    
                    return new ESLVal("Term",l,new ESLVal("$selectMid"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,mid,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase.apply(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,mid),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2117)));
                }
                }
                default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2117)));
              }
              }
              default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2117)));
            }
          }
          }
        case "PAdd": {ESLVal $2895 = $2880.termRef(0);
            ESLVal $2894 = $2880.termRef(1);
            ESLVal $2893 = $2880.termRef(2);
            
            switch($2893.termName) {
            case "PCons": {ESLVal $2898 = $2893.termRef(0);
              ESLVal $2897 = $2893.termRef(1);
              ESLVal $2896 = $2893.termRef(2);
              
              switch($2896.termName) {
              case "PNil": {ESLVal $2899 = $2896.termRef(0);
                
                {ESLVal l1 = $2881;
                
                {ESLVal l2 = $2895;
                
                {ESLVal p1 = $2894;
                
                {ESLVal l3 = $2898;
                
                {ESLVal p2 = $2897;
                
                {ESLVal l4 = $2899;
                
                {ESLVal p3 = $2879;
                
                {ESLVal fail = newVar.apply();
                ESLVal left = newVar.apply();
                ESLVal mid = newVar.apply();
                ESLVal right = newVar.apply();
                ESLVal newArm = setArmPatterns.apply(arm,ESLVal.list(p1,p2,p3).add(armPatterns.apply(arm)));
                
                return new ESLVal("Term",l,new ESLVal("$selectMid"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,mid,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase.apply(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,mid),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
              }
              }
              }
              }
              }
              }
              }
              }
              }
              default: switch($2879.termName) {
                case "PCons": {ESLVal $2891 = $2879.termRef(0);
                  ESLVal $2890 = $2879.termRef(1);
                  ESLVal $2889 = $2879.termRef(2);
                  
                  switch($2889.termName) {
                  case "PNil": {ESLVal $2892 = $2889.termRef(0);
                    
                    {ESLVal l1 = $2881;
                    
                    {ESLVal p1 = $2880;
                    
                    {ESLVal l2 = $2891;
                    
                    {ESLVal p2 = $2890;
                    
                    {ESLVal l3 = $2892;
                    
                    {ESLVal fail = newVar.apply();
                    ESLVal left = newVar.apply();
                    ESLVal right = newVar.apply();
                    ESLVal newArm = setArmPatterns.apply(arm,ESLVal.list(p1,p2).add(tail.apply(armPatterns.apply(arm))));
                    
                    return new ESLVal("Term",l,new ESLVal("$selectRight"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase.apply(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2117)));
                }
                }
              case "PAdd": {ESLVal $2884 = $2879.termRef(0);
                  ESLVal $2883 = $2879.termRef(1);
                  ESLVal $2882 = $2879.termRef(2);
                  
                  switch($2883.termName) {
                  case "PCons": {ESLVal $2887 = $2883.termRef(0);
                    ESLVal $2886 = $2883.termRef(1);
                    ESLVal $2885 = $2883.termRef(2);
                    
                    switch($2885.termName) {
                    case "PNil": {ESLVal $2888 = $2885.termRef(0);
                      
                      {ESLVal l1 = $2881;
                      
                      {ESLVal p1 = $2880;
                      
                      {ESLVal l2 = $2884;
                      
                      {ESLVal l3 = $2887;
                      
                      {ESLVal p2 = $2886;
                      
                      {ESLVal l4 = $2888;
                      
                      {ESLVal p3 = $2882;
                      
                      {ESLVal fail = newVar.apply();
                      ESLVal left = newVar.apply();
                      ESLVal mid = newVar.apply();
                      ESLVal right = newVar.apply();
                      ESLVal newArm = setArmPatterns.apply(arm,ESLVal.list(p1,p2,p3).add(tail.apply(armPatterns.apply(arm))));
                      
                      return new ESLVal("Term",l,new ESLVal("$selectMid"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,mid,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase.apply(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,mid),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2117)));
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2117)));
                }
                }
                default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2117)));
              }
            }
            }
            default: switch($2879.termName) {
              case "PCons": {ESLVal $2891 = $2879.termRef(0);
                ESLVal $2890 = $2879.termRef(1);
                ESLVal $2889 = $2879.termRef(2);
                
                switch($2889.termName) {
                case "PNil": {ESLVal $2892 = $2889.termRef(0);
                  
                  {ESLVal l1 = $2881;
                  
                  {ESLVal p1 = $2880;
                  
                  {ESLVal l2 = $2891;
                  
                  {ESLVal p2 = $2890;
                  
                  {ESLVal l3 = $2892;
                  
                  {ESLVal fail = newVar.apply();
                  ESLVal left = newVar.apply();
                  ESLVal right = newVar.apply();
                  ESLVal newArm = setArmPatterns.apply(arm,ESLVal.list(p1,p2).add(tail.apply(armPatterns.apply(arm))));
                  
                  return new ESLVal("Term",l,new ESLVal("$selectRight"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase.apply(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
                }
                }
                }
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2117)));
              }
              }
            case "PAdd": {ESLVal $2884 = $2879.termRef(0);
                ESLVal $2883 = $2879.termRef(1);
                ESLVal $2882 = $2879.termRef(2);
                
                switch($2883.termName) {
                case "PCons": {ESLVal $2887 = $2883.termRef(0);
                  ESLVal $2886 = $2883.termRef(1);
                  ESLVal $2885 = $2883.termRef(2);
                  
                  switch($2885.termName) {
                  case "PNil": {ESLVal $2888 = $2885.termRef(0);
                    
                    {ESLVal l1 = $2881;
                    
                    {ESLVal p1 = $2880;
                    
                    {ESLVal l2 = $2884;
                    
                    {ESLVal l3 = $2887;
                    
                    {ESLVal p2 = $2886;
                    
                    {ESLVal l4 = $2888;
                    
                    {ESLVal p3 = $2882;
                    
                    {ESLVal fail = newVar.apply();
                    ESLVal left = newVar.apply();
                    ESLVal mid = newVar.apply();
                    ESLVal right = newVar.apply();
                    ESLVal newArm = setArmPatterns.apply(arm,ESLVal.list(p1,p2,p3).add(tail.apply(armPatterns.apply(arm))));
                    
                    return new ESLVal("Term",l,new ESLVal("$selectMid"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,mid,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase.apply(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,mid),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2117)));
                }
                }
                default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2117)));
              }
              }
              default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2117)));
            }
          }
          }
          default: switch($2879.termName) {
            case "PCons": {ESLVal $2891 = $2879.termRef(0);
              ESLVal $2890 = $2879.termRef(1);
              ESLVal $2889 = $2879.termRef(2);
              
              switch($2889.termName) {
              case "PNil": {ESLVal $2892 = $2889.termRef(0);
                
                {ESLVal l1 = $2881;
                
                {ESLVal p1 = $2880;
                
                {ESLVal l2 = $2891;
                
                {ESLVal p2 = $2890;
                
                {ESLVal l3 = $2892;
                
                {ESLVal fail = newVar.apply();
                ESLVal left = newVar.apply();
                ESLVal right = newVar.apply();
                ESLVal newArm = setArmPatterns.apply(arm,ESLVal.list(p1,p2).add(tail.apply(armPatterns.apply(arm))));
                
                return new ESLVal("Term",l,new ESLVal("$selectRight"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase.apply(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
              }
              }
              }
              }
              }
              }
              }
              default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2117)));
            }
            }
          case "PAdd": {ESLVal $2884 = $2879.termRef(0);
              ESLVal $2883 = $2879.termRef(1);
              ESLVal $2882 = $2879.termRef(2);
              
              switch($2883.termName) {
              case "PCons": {ESLVal $2887 = $2883.termRef(0);
                ESLVal $2886 = $2883.termRef(1);
                ESLVal $2885 = $2883.termRef(2);
                
                switch($2885.termName) {
                case "PNil": {ESLVal $2888 = $2885.termRef(0);
                  
                  {ESLVal l1 = $2881;
                  
                  {ESLVal p1 = $2880;
                  
                  {ESLVal l2 = $2884;
                  
                  {ESLVal l3 = $2887;
                  
                  {ESLVal p2 = $2886;
                  
                  {ESLVal l4 = $2888;
                  
                  {ESLVal p3 = $2882;
                  
                  {ESLVal fail = newVar.apply();
                  ESLVal left = newVar.apply();
                  ESLVal mid = newVar.apply();
                  ESLVal right = newVar.apply();
                  ESLVal newArm = setArmPatterns.apply(arm,ESLVal.list(p1,p2,p3).add(tail.apply(armPatterns.apply(arm))));
                  
                  return new ESLVal("Term",l,new ESLVal("$selectMid"),ESLVal.list(),ESLVal.list(new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("add")),ESLVal.list(new ESLVal("Dec",l,left,$null,$null),new ESLVal("Dec",l,mid,$null,$null),new ESLVal("Dec",l,right,$null,$null),new ESLVal("Dec",l,fail,$null,$null)),$null,compileCase.apply(l,ESLVal.list(new ESLVal("Var",l,left),new ESLVal("Var",l,mid),new ESLVal("Var",l,right)).add(es),ESLVal.list(newArm),new ESLVal("Apply",l,new ESLVal("Var",l,fail),ESLVal.list())))));
                }
                }
                }
                }
                }
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2117)));
              }
              }
              default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2117)));
            }
            }
            default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2117)));
          }
        }
        }
        default: return error(new ESLVal("case error at Pos(18804,21622)").add(ESLVal.list(_v2117)));
      }
      }
    }
  });
  private static ESLVal processInts = new ESLVal(new Function(new ESLVal("processInts"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  {ESLVal ints = removeDups.apply(map.apply(pIntValue,map.apply(head,map.apply(armPatterns,arms))));
        
        {ESLVal armss = map.apply(new ESLVal(new Function(new ESLVal("fun1064"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal c = $args[0];
          return intArms.apply(c,arms);
            }
          }),ints);
        
        return new ESLVal("CaseInt",l,head.apply(es),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v2115 = $qualArg;
              
              {ESLVal as = _v2115;
              
              return ESLVal.list(ESLVal.list(new ESLVal("IArm",sharedInt.apply(as),compileCase.apply(l,tail.apply(es),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal _v2179 = $args[0];
              {ESLVal _v2116 = _v2179;
                    
                    {ESLVal a = _v2116;
                    
                    return ESLVal.list(ESLVal.list(dropPattern.apply(a)));
                  }
                  }
                }
              }).map(as).flatten().flatten(),alt))));
            }
            }
          }
        }).map(armss).flatten().flatten(),alt);
      }
      }
    }
  });
  private static ESLVal processStrs = new ESLVal(new Function(new ESLVal("processStrs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  {ESLVal strs = removeDups.apply(map.apply(pStrValue,map.apply(head,map.apply(armPatterns,arms))));
        
        {ESLVal armss = map.apply(new ESLVal(new Function(new ESLVal("fun1065"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal c = $args[0];
          return strArms.apply(c,arms);
            }
          }),strs);
        
        return new ESLVal("CaseStr",l,head.apply(es),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v2113 = $qualArg;
              
              {ESLVal as = _v2113;
              
              return ESLVal.list(ESLVal.list(new ESLVal("SArm",sharedStr.apply(as),compileCase.apply(l,tail.apply(es),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal _v2178 = $args[0];
              {ESLVal _v2114 = _v2178;
                    
                    {ESLVal a = _v2114;
                    
                    return ESLVal.list(ESLVal.list(dropPattern.apply(a)));
                  }
                  }
                }
              }).map(as).flatten().flatten(),alt))));
            }
            }
          }
        }).map(armss).flatten().flatten(),alt);
      }
      }
    }
  });
  private static ESLVal processBools = new ESLVal(new Function(new ESLVal("processBools"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  {ESLVal bools = removeDups.apply(map.apply(pBoolValue,map.apply(head,map.apply(armPatterns,arms))));
        
        {ESLVal armss = map.apply(new ESLVal(new Function(new ESLVal("fun1066"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal c = $args[0];
          return boolArms.apply(c,arms);
            }
          }),bools);
        
        return new ESLVal("CaseBool",l,head.apply(es),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v2111 = $qualArg;
              
              {ESLVal as = _v2111;
              
              return ESLVal.list(ESLVal.list(new ESLVal("BoolArm",sharedBool.apply(as),compileCase.apply(l,tail.apply(es),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal _v2177 = $args[0];
              {ESLVal _v2112 = _v2177;
                    
                    {ESLVal a = _v2112;
                    
                    return ESLVal.list(ESLVal.list(dropPattern.apply(a)));
                  }
                  }
                }
              }).map(as).flatten().flatten(),alt))));
            }
            }
          }
        }).map(armss).flatten().flatten(),alt);
      }
      }
    }
  });
  private static ESLVal processSets = new ESLVal(new Function(new ESLVal("processSets"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  {ESLVal f = new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("setFail")),ESLVal.list(),$null,alt);
        
        return new ESLVal("CaseSet",l,head.apply(es),new ESLVal("List",l,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v2110 = $qualArg;
              
              {ESLVal a = _v2110;
              
              return ESLVal.list(ESLVal.list(processSetArms.apply(l,tail.apply(es),a)));
            }
            }
          }
        }).map(arms).flatten().flatten()),f);
      }
    }
  });
  private static ESLVal processNonDetLists = new ESLVal(new Function(new ESLVal("processNonDetLists"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  {print.apply(new ESLVal("process nondet lists ").add(es.add(new ESLVal(" ").add(arms))));
      {ESLVal f = new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("listFail")),ESLVal.list(),$null,alt);
        
        return new ESLVal("CaseAdd",l,head.apply(es),new ESLVal("List",l,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v2109 = $qualArg;
              
              {ESLVal a = _v2109;
              
              return ESLVal.list(ESLVal.list(processNonDetListArms.apply(l,tail.apply(es),a)));
            }
            }
          }
        }).map(arms).flatten().flatten()),f);
      }}
    }
  });
  private static ESLVal splitTerms = new ESLVal(new Function(new ESLVal("splitTerms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  return compileCase.apply(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun1067"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPTerm.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),compileCase.apply(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun1068"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPTerm.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),alt));
    }
  });
  private static ESLVal splitLists = new ESLVal(new Function(new ESLVal("splitLists"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  return compileCase.apply(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun1069"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPList.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),compileCase.apply(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun1070"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPList.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),alt));
    }
  });
  private static ESLVal splitAdd = new ESLVal(new Function(new ESLVal("splitAdd"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  return compileCase.apply(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun1071"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPAdd.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),compileCase.apply(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun1072"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPAdd.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),alt));
    }
  });
  private static ESLVal splitSets = new ESLVal(new Function(new ESLVal("splitSets"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  return compileCase.apply(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun1073"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPSet.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),compileCase.apply(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun1074"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPSet.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),alt));
    }
  });
  private static ESLVal splitInts = new ESLVal(new Function(new ESLVal("splitInts"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  return compileCase.apply(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun1075"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPInt.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),compileCase.apply(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun1076"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPInt.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),alt));
    }
  });
  private static ESLVal splitStrs = new ESLVal(new Function(new ESLVal("splitStrs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  return compileCase.apply(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun1077"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPStr.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),compileCase.apply(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun1078"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPStr.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),alt));
    }
  });
  private static ESLVal splitBools = new ESLVal(new Function(new ESLVal("splitBools"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  return compileCase.apply(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun1079"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPBool.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),compileCase.apply(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun1080"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPBool.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),alt));
    }
  });
  private static ESLVal splitVars = new ESLVal(new Function(new ESLVal("splitVars"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  return compileCase.apply(l,es,select.apply(new ESLVal(new Function(new ESLVal("fun1081"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPVar.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),compileCase.apply(l,es,reject.apply(new ESLVal(new Function(new ESLVal("fun1082"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return isPVar.apply(head.apply(armPatterns.apply(a)));
          }
        }),arms),alt));
    }
  });
  private static ESLVal splitCase = new ESLVal(new Function(new ESLVal("splitCase"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  {ESLVal firstPatterns = map.apply(head,map.apply(armPatterns,arms));
        
        {ESLVal nonVarPatterns = filter.apply(new ESLVal(new Function(new ESLVal("fun1083"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal p = $args[0];
          return isPVar.apply(p).not();
            }
          }),firstPatterns);
        
        if(isPTerm.apply(head.apply(nonVarPatterns)).boolVal)
        return splitTerms.apply(l,es,arms,alt);
        else
          if(isPList.apply(head.apply(nonVarPatterns)).boolVal)
            return splitLists.apply(l,es,arms,alt);
            else
              if(isPSet.apply(head.apply(nonVarPatterns)).boolVal)
                return splitSets.apply(l,es,arms,alt);
                else
                  if(isPInt.apply(head.apply(nonVarPatterns)).boolVal)
                    return splitInts.apply(l,es,arms,alt);
                    else
                      if(isPStr.apply(head.apply(nonVarPatterns)).boolVal)
                        return splitStrs.apply(l,es,arms,alt);
                        else
                          if(isPBool.apply(head.apply(nonVarPatterns)).boolVal)
                            return splitBools.apply(l,es,arms,alt);
                            else
                              if(isPVar.apply(head.apply(firstPatterns)).boolVal)
                                return splitVars.apply(l,es,arms,alt);
                                else
                                  if(isPAdd.apply(head.apply(firstPatterns)).boolVal)
                                    return splitAdd.apply(l,es,arms,alt);
                                    else
                                      return error(new ESLVal("unknown split case: ").add(arms));
      }
      }
    }
  });
  private static ESLVal compileCase = new ESLVal(new Function(new ESLVal("compileCase"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  ESLVal alt = $args[3];
  if(arms.eql($nil).boolVal)
        return alt;
        else
          if(isEmptyPatterns.apply(arms).boolVal)
            return foldArms.apply(l,arms,alt);
            else
              if(isFirstColumnVars.apply(arms).boolVal)
                return compileCase.apply(l,tail.apply(es),bindVars.apply(head.apply(es),arms),alt);
                else
                  if(isFirstColumnCnstrs.apply(arms).boolVal)
                    return processCnstrs.apply(l,es,arms,alt);
                    else
                      if(isFirstColumnLists.apply(arms).boolVal)
                        return processLists.apply(l,es,arms,alt);
                        else
                          if(isFirstColumnInts.apply(arms).boolVal)
                            return processInts.apply(l,es,arms,alt);
                            else
                              if(isFirstColumnBools.apply(arms).boolVal)
                                return processBools.apply(l,es,arms,alt);
                                else
                                  if(isFirstColumnStrs.apply(arms).boolVal)
                                    return processStrs.apply(l,es,arms,alt);
                                    else
                                      if(isFirstColumnSets.apply(arms).boolVal)
                                        return processSets.apply(l,es,arms,alt);
                                        else
                                          if(isFirstColumnNonDetLists.apply(arms).boolVal)
                                            return processNonDetLists.apply(l,es,arms,alt);
                                            else
                                              return splitCase.apply(l,es,arms,alt);
    }
  });
  private static ESLVal foldArms = new ESLVal(new Function(new ESLVal("foldArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal arms = $args[1];
  ESLVal alt = $args[2];
  {ESLVal _v2108 = arms;
        
        if(_v2108.isCons())
        {ESLVal $2870 = _v2108.head();
          ESLVal $2871 = _v2108.tail();
          
          switch($2870.termName) {
          case "LArm": {ESLVal $2876 = $2870.termRef(0);
            ESLVal $2875 = $2870.termRef(1);
            ESLVal $2874 = $2870.termRef(2);
            ESLVal $2873 = $2870.termRef(3);
            ESLVal $2872 = $2870.termRef(4);
            
            if($2875.isCons())
            {ESLVal $2877 = $2875.head();
              ESLVal $2878 = $2875.tail();
              
              return error(new ESLVal("case error at Pos(27421,27577)").add(ESLVal.list(_v2108)));
            }
          else if($2875.isNil())
            {ESLVal al = $2876;
              
              {ESLVal bs = $2874;
              
              {ESLVal g = $2873;
              
              {ESLVal e = $2872;
              
              {ESLVal _v2176 = $2871;
              
              return foldArm.apply(al,bs,g,e,foldArms.apply(l,_v2176,alt));
            }
            }
            }
            }
            }
          else return error(new ESLVal("case error at Pos(27421,27577)").add(ESLVal.list(_v2108)));
          }
          default: return error(new ESLVal("case error at Pos(27421,27577)").add(ESLVal.list(_v2108)));
        }
        }
      else if(_v2108.isNil())
        return alt;
      else return error(new ESLVal("case error at Pos(27421,27577)").add(ESLVal.list(_v2108)));
      }
    }
  });
  private static ESLVal foldArm = new ESLVal(new Function(new ESLVal("foldArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal bss = $args[1];
  ESLVal g = $args[2];
  ESLVal e = $args[3];
  ESLVal alt = $args[4];
  {ESLVal _v2106 = bss;
        
        if(_v2106.isCons())
        {ESLVal $2866 = _v2106.head();
          ESLVal $2867 = _v2106.tail();
          
          {ESLVal bs = $2866;
          
          {ESLVal _v2173 = $2867;
          
          return new ESLVal("Let",l,bs,foldArm.apply(l,_v2173,g,e,alt));
        }
        }
        }
      else if(_v2106.isNil())
        {ESLVal _v2107 = g;
          
          switch(_v2107.termName) {
          case "BoolExp": {ESLVal $2869 = _v2107.termRef(0);
            ESLVal $2868 = _v2107.termRef(1);
            
            switch($2868.boolVal ? 1 : 0) {
            case 1: {ESLVal bl = $2869;
              
              return e;
            }
            default: {ESLVal _v2174 = _v2107;
              
              return new ESLVal("If",l,_v2174,e,alt);
            }
          }
          }
          default: {ESLVal _v2175 = _v2107;
            
            return new ESLVal("If",l,_v2175,e,alt);
          }
        }
        }
      else return error(new ESLVal("case error at Pos(27642,27842)").add(ESLVal.list(_v2106)));
      }
    }
  });
  private static ESLVal translateQual = new ESLVal(new Function(new ESLVal("translateQual"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal q = $args[0];
  {ESLVal _v2105 = q;
        
        switch(_v2105.termName) {
        case "BQual": {ESLVal $2865 = _v2105.termRef(0);
          ESLVal $2864 = _v2105.termRef(1);
          ESLVal $2863 = _v2105.termRef(2);
          
          {ESLVal l = $2865;
          
          {ESLVal p = $2864;
          
          {ESLVal e = $2863;
          
          return new ESLVal("BQual",l,p,translateCases.apply(e));
        }
        }
        }
        }
      case "PQual": {ESLVal $2862 = _v2105.termRef(0);
          ESLVal $2861 = _v2105.termRef(1);
          
          {ESLVal l = $2862;
          
          {ESLVal p = $2861;
          
          return new ESLVal("PQual",l,translateCases.apply(p));
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(27894,28031)").add(ESLVal.list(_v2105)));
      }
      }
    }
  });
  private static ESLVal translateArm = new ESLVal(new Function(new ESLVal("translateArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal a = $args[0];
  {ESLVal _v2104 = a;
        
        switch(_v2104.termName) {
        case "LArm": {ESLVal $2860 = _v2104.termRef(0);
          ESLVal $2859 = _v2104.termRef(1);
          ESLVal $2858 = _v2104.termRef(2);
          ESLVal $2857 = _v2104.termRef(3);
          ESLVal $2856 = _v2104.termRef(4);
          
          {ESLVal l = $2860;
          
          {ESLVal ps = $2859;
          
          {ESLVal bs = $2858;
          
          {ESLVal guard = $2857;
          
          {ESLVal e = $2856;
          
          return new ESLVal("LArm",l,ps,bs,translateCases.apply(guard),translateCases.apply(e));
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(28070,28203)").add(ESLVal.list(_v2104)));
      }
      }
    }
  });
  private static ESLVal translateDef = new ESLVal(new Function(new ESLVal("translateDef"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal b = $args[0];
  {ESLVal _v2103 = b;
        
        switch(_v2103.termName) {
        case "Binding": {ESLVal $2855 = _v2103.termRef(0);
          ESLVal $2854 = _v2103.termRef(1);
          ESLVal $2853 = _v2103.termRef(2);
          ESLVal $2852 = _v2103.termRef(3);
          ESLVal $2851 = _v2103.termRef(4);
          
          {ESLVal l = $2855;
          
          {ESLVal name = $2854;
          
          {ESLVal t = $2853;
          
          {ESLVal st = $2852;
          
          {ESLVal value = $2851;
          
          return new ESLVal("Binding",l,name,t,st,translateCases.apply(value));
        }
        }
        }
        }
        }
        }
      case "TypeBind": {ESLVal $2850 = _v2103.termRef(0);
          ESLVal $2849 = _v2103.termRef(1);
          ESLVal $2848 = _v2103.termRef(2);
          ESLVal $2847 = _v2103.termRef(3);
          
          {ESLVal l = $2850;
          
          {ESLVal name = $2849;
          
          {ESLVal t = $2848;
          
          {ESLVal ignore = $2847;
          
          return b;
        }
        }
        }
        }
        }
      case "DataBind": {ESLVal $2846 = _v2103.termRef(0);
          ESLVal $2845 = _v2103.termRef(1);
          ESLVal $2844 = _v2103.termRef(2);
          ESLVal $2843 = _v2103.termRef(3);
          
          {ESLVal l = $2846;
          
          {ESLVal name = $2845;
          
          {ESLVal t = $2844;
          
          {ESLVal ignore = $2843;
          
          return b;
        }
        }
        }
        }
        }
      case "FunBind": {ESLVal $2842 = _v2103.termRef(0);
          ESLVal $2841 = _v2103.termRef(1);
          ESLVal $2840 = _v2103.termRef(2);
          ESLVal $2839 = _v2103.termRef(3);
          ESLVal $2838 = _v2103.termRef(4);
          ESLVal $2837 = _v2103.termRef(5);
          ESLVal $2836 = _v2103.termRef(6);
          
          {ESLVal l = $2842;
          
          {ESLVal n = $2841;
          
          {ESLVal args = $2840;
          
          {ESLVal t = $2839;
          
          {ESLVal st = $2838;
          
          {ESLVal body = $2837;
          
          {ESLVal guard = $2836;
          
          return new ESLVal("FunBind",l,n,args,t,st,translateCases.apply(body),translateCases.apply(guard));
        }
        }
        }
        }
        }
        }
        }
        }
      case "CnstrBind": {ESLVal $2835 = _v2103.termRef(0);
          ESLVal $2834 = _v2103.termRef(1);
          ESLVal $2833 = _v2103.termRef(2);
          ESLVal $2832 = _v2103.termRef(3);
          
          {ESLVal l = $2835;
          
          {ESLVal name = $2834;
          
          {ESLVal t = $2833;
          
          {ESLVal ignore = $2832;
          
          return b;
        }
        }
        }
        }
        }
        default: {ESLVal x = _v2103;
          
          return error(x);
        }
      }
      }
    }
  });
  private static ESLVal pterm = new ESLVal(new Function(new ESLVal("pterm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal n = $args[0];
  ESLVal ps = $args[1];
  return new ESLVal("PTerm",loc0,n,$nil,ps);
    }
  });
  private static ESLVal pvar = new ESLVal(new Function(new ESLVal("pvar"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal n = $args[0];
  return new ESLVal("PVar",loc0,n,voidType);
    }
  });
  private static ESLVal var = new ESLVal(new Function(new ESLVal("var"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal n = $args[0];
  return new ESLVal("Var",loc0,n);
    }
  });
  private static ESLVal pcons = new ESLVal(new Function(new ESLVal("pcons"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal h = $args[0];
  ESLVal t = $args[1];
  return new ESLVal("PCons",loc0,h,t);
    }
  });
  private static ESLVal case0 = new ESLVal("Case",new ESLVal("Pos",$zero,$zero),$nil,ESLVal.list(new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("x")),new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("y"))),ESLVal.list(new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PVar",loc0,new ESLVal("xx"),voidType),new ESLVal("PVar",loc0,new ESLVal("yy"),voidType)),new ESLVal("BoolExp",loc0,$true),new ESLVal("Var",loc0,new ESLVal("OK")))));
  private static ESLVal case1 = new ESLVal("Case",new ESLVal("Pos",$zero,$zero),$nil,ESLVal.list(new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("x")),new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("y"))),ESLVal.list(new ESLVal("BArm",loc0,ESLVal.list(pterm.apply(new ESLVal("A"),ESLVal.list(pterm.apply(new ESLVal("B"),ESLVal.list(pvar.apply(new ESLVal("v0")))),pvar.apply(new ESLVal("v1")),pvar.apply(new ESLVal("v2")))),pterm.apply(new ESLVal("C"),ESLVal.list())),new ESLVal("BoolExp",loc0,$true),new ESLVal("Var",loc0,new ESLVal("OK1"))),new ESLVal("BArm",loc0,ESLVal.list(pvar.apply(new ESLVal("v0")),pterm.apply(new ESLVal("C"),ESLVal.list())),new ESLVal("BoolExp",loc0,$true),new ESLVal("Var",loc0,new ESLVal("OK2")))));
  private static ESLVal case2 = new ESLVal("Case",loc0,$nil,ESLVal.list(var.apply(new ESLVal("l"))),ESLVal.list(new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PNil",loc0)),var.apply(new ESLVal("g1")),var.apply(new ESLVal("M1"))),new ESLVal("BArm",loc0,ESLVal.list(pcons.apply(pterm.apply(new ESLVal("One"),ESLVal.list()),pvar.apply(new ESLVal("rest1")))),var.apply(new ESLVal("g1")),var.apply(new ESLVal("M1"))),new ESLVal("BArm",loc0,ESLVal.list(pcons.apply(pterm.apply(new ESLVal("Succ"),ESLVal.list(pterm.apply(new ESLVal("One"),ESLVal.list()))),pvar.apply(new ESLVal("rest2")))),var.apply(new ESLVal("g2")),var.apply(new ESLVal("M2"))),new ESLVal("BArm",loc0,ESLVal.list(pcons.apply(pterm.apply(new ESLVal("Infinity"),ESLVal.list()),new ESLVal("PNil",loc0))),var.apply(new ESLVal("g3")),var.apply(new ESLVal("M3")))));
  private static ESLVal case3 = new ESLVal("Case",loc0,$nil,ESLVal.list(var.apply(new ESLVal("x")),var.apply(new ESLVal("y"))),ESLVal.list(new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PInt",loc0,$zero),new ESLVal("PInt",loc0,$one)),var.apply(new ESLVal("g1")),var.apply(new ESLVal("M1"))),new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PInt",loc0,$one),new ESLVal("PInt",loc0,$zero)),var.apply(new ESLVal("g2")),var.apply(new ESLVal("M2"))),new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PInt",loc0,$zero),pvar.apply(new ESLVal("x"))),var.apply(new ESLVal("g3")),var.apply(new ESLVal("M3"))),new ESLVal("BArm",loc0,ESLVal.list(pvar.apply(new ESLVal("x")),new ESLVal("PInt",loc0,$one)),var.apply(new ESLVal("g4")),var.apply(new ESLVal("M4")))));
  private static ESLVal case4 = new ESLVal("Case",loc0,$nil,ESLVal.list(var.apply(new ESLVal("x")),var.apply(new ESLVal("y"))),ESLVal.list(new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PStr",loc0,new ESLVal("one")),new ESLVal("PInt",loc0,$one)),var.apply(new ESLVal("g1")),var.apply(new ESLVal("M1"))),new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PStr",loc0,new ESLVal("one")),new ESLVal("PInt",loc0,$zero)),var.apply(new ESLVal("g2")),var.apply(new ESLVal("M2"))),new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PStr",loc0,new ESLVal("two")),pvar.apply(new ESLVal("x"))),var.apply(new ESLVal("g3")),var.apply(new ESLVal("M3"))),new ESLVal("BArm",loc0,ESLVal.list(pvar.apply(new ESLVal("x")),new ESLVal("PInt",loc0,$one)),var.apply(new ESLVal("g4")),var.apply(new ESLVal("M4")))));
  private static ESLVal case5 = new ESLVal("Case",loc0,$nil,ESLVal.list(var.apply(new ESLVal("x")),var.apply(new ESLVal("y"))),ESLVal.list(new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PStr",loc0,new ESLVal("one")),new ESLVal("PInt",loc0,$one)),var.apply(new ESLVal("g1")),var.apply(new ESLVal("M1"))),new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PStr",loc0,new ESLVal("one")),new ESLVal("PInt",loc0,$zero)),var.apply(new ESLVal("g2")),var.apply(new ESLVal("M2"))),new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PStr",loc0,new ESLVal("two")),pvar.apply(new ESLVal("x"))),var.apply(new ESLVal("g3")),var.apply(new ESLVal("M3"))),new ESLVal("BArm",loc0,ESLVal.list(pvar.apply(new ESLVal("x")),new ESLVal("PInt",loc0,$one)),var.apply(new ESLVal("g4")),var.apply(new ESLVal("M4"))),new ESLVal("BArm",loc0,ESLVal.list(new ESLVal("PBool",loc0,$true),new ESLVal("PInt",loc0,$one)),var.apply(new ESLVal("g4")),var.apply(new ESLVal("M4")))));
  private static ESLVal case6 = new ESLVal("Case",loc0,$nil,ESLVal.list(var.apply(new ESLVal("x"))),ESLVal.list(new ESLVal("BArm",loc0,ESLVal.list(pterm.apply(new ESLVal("A"),ESLVal.list(new ESLVal("PInt",loc0,$one)))),var.apply(new ESLVal("g1")),var.apply(new ESLVal("M1")))));
  public static ESLVal main = new ESLVal(new Function(new ESLVal("main"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      return new ESLVal(new BehaviourAdapter(true,getSelf(),new ESLVal("main")) {
          
          public ESLVal handle(ESLVal $m) {{ESLVal _v2102 = $m;
            
            return error(new ESLVal("case error at Pos(0,0)").add(ESLVal.list(_v2102)));
          }}
          public ESLVal get(String name) {
            switch(name) {
              
              default: throw new Error("ref illegal " + self + "." + name);
            }
          }
        public void handleTime(ESLVal $t) {
          {ESLVal n = $t;
            
            if($true.boolVal)
            {new Function(new ESLVal("try"),getSelf()) {
              public ESLVal apply(ESLVal... args) { 
                try { 
                  return ((Supplier<ESLVal>)() -> { 
                  {print.apply(ppExp.apply($zero,translateCases.apply(case0)));
                  print.apply(ppExp.apply($zero,translateCases.apply(case1)));
                  print.apply(ppExp.apply($zero,translateCases.apply(case2)));
                  print.apply(ppExp.apply($zero,translateCases.apply(case3)));
                  print.apply(ppExp.apply($zero,translateCases.apply(case4)));
                  print.apply(ppExp.apply($zero,translateCases.apply(case5)));
                  return print.apply(ppExp.apply($zero,translateCases.apply(case6)));}
                }).get();
                } catch(ESLError $exception) {
                  ESLVal $x = $exception.value;
                  {ESLVal _v2101 = $x;
              
              {ESLVal x = _v2101;
              
              return print.apply(x);
            }
            }
                }
              }
            }.apply();
            stopAll.apply();}
            else
              {}
          }
        }
        public ESLVal init() {
            return $null;
          }
        });
    }
  });
public static void main(String[] args) {
    newActor(main,new ESLVal(new Actor())); 
  }
}