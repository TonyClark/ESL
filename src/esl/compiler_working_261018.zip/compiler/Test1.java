package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;

import java.util.function.Supplier;
public class Test1 {
  public static ESLVal getSelf() { return $null; }
  private static ESLVal e = new ESLVal(new Function(new ESLVal("e"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      return new ESLVal(new BehaviourAdapter(false,getSelf(),new ESLVal("e")) {
          
          public ESLVal handle(ESLVal $m) {{ESLVal _v6 = $m;
            
            return error(new ESLVal("case error at Pos(0,0)"));
          }}
          public ESLVal get(String name) {
            switch(name) {
              
              default: throw new Error("ref illegal " + self + "." + name);
            }
          }
        public void handleTime(ESLVal $t) {
          {}
        }
        public ESLVal init() {
            return $null;
          }
        });
    }
  });
  private static ESLVal m = new ESLVal(new Function(new ESLVal("m"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      return new ESLVal(new BehaviourAdapter(false,getSelf(),new ESLVal("m")) {
          
          public ESLVal handle(ESLVal $m) {{ESLVal _v5 = $m;
            
            switch(_v5.termName) {
            case "K": {ESLVal $11 = _v5.termRef(0);
              
              {ESLVal _v25 = $11;
              
              return $null;
            }
            }
          case "L": {ESLVal $10 = _v5.termRef(0);
              
              {ESLVal y = $10;
              
              return $null;
            }
            }
          case "N": {ESLVal $9 = _v5.termRef(0);
              
              {ESLVal _v24 = $9;
              
              return $null;
            }
            }
            default: return error(new ESLVal("case error at Pos(0,0)"));
          }
          }}
          public ESLVal get(String name) {
            switch(name) {
              
              default: throw new Error("ref illegal " + self + "." + name);
            }
          }
        public void handleTime(ESLVal $t) {
          {}
        }
        public ESLVal init() {
            return $null;
          }
        });
    }
  });
  private static ESLVal n = new ESLVal(new Function(new ESLVal("n"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      return new ESLVal(new BehaviourAdapter(false,getSelf(),new ESLVal("n")) {
          ESLVal l = newActor(m,new ESLVal(new Actor()));
          
          public ESLVal handle(ESLVal $m) {{ESLVal _v4 = $m;
            
            switch(_v4.termName) {
            case "A": {ESLVal $8 = _v4.termRef(0);
              
              {ESLVal _v23 = $8;
              
              return $null;
            }
            }
          case "K": {ESLVal $7 = _v4.termRef(0);
              
              {ESLVal _v22 = $7;
              
              return $null;
            }
            }
          case "L": {ESLVal $6 = _v4.termRef(0);
              
              {ESLVal y = $6;
              
              return $null;
            }
            }
          case "N": {ESLVal $5 = _v4.termRef(0);
              
              {ESLVal _v21 = $5;
              
              return $null;
            }
            }
            default: return error(new ESLVal("case error at Pos(0,0)"));
          }
          }}
          public ESLVal get(String name) {
            switch(name) {
              
              default: throw new Error("ref illegal " + self + "." + name);
            }
          }
        public void handleTime(ESLVal $t) {
          {}
        }
        public ESLVal init() {
            return $null;
          }
        });
    }
  });
  private static ESLVal x = new ESLVal("Branch",new ESLVal("Leaf",new ESLVal(100)),new ESLVal("Leaf",new ESLVal(300)));
  private static ESLVal f = new ESLVal(new Function(new ESLVal("f"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v20 = $args[0];
  ESLVal _v19 = $args[1];
  return _v20;
    }
  });
  private static ESLVal test = new ESLVal(new Function(new ESLVal("test"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v17 = $args[0];
  {ESLVal _v3 = _v17;
        
        switch(_v3.termName) {
        case "Branch": {ESLVal $4 = _v3.termRef(0);
          ESLVal $3 = _v3.termRef(1);
          
          {ESLVal a = $4;
          
          {ESLVal b = $3;
          
          return test.apply(a).add(test.apply(b));
        }
        }
        }
      case "Leaf": {ESLVal $2 = _v3.termRef(0);
          
          {ESLVal _v18 = $2;
          
          return _v18;
        }
        }
        default: return error(new ESLVal("case error at Pos(437,503)"));
      }
      }
    }
  });
  private static ESLVal testParBind = new ESLVal(new Function(new ESLVal("testParBind"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal a = $args[0];
  ESLVal b = $args[1];
  {ESLVal _v16 = new ESLVal(100);
        ESLVal _v15 = new ESLVal(200);
        
        return _v16;
      }
    }
  });
  private static ESLVal g = new ESLVal(new Function(new ESLVal("fun471"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v14 = $args[0];
  ESLVal _v13 = $args[1];
  return _v14.add(_v13);
    }
  });
  private static ESLVal mkTree = new ESLVal(new Function(new ESLVal("mkTree"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v11 = $args[0];
  {ESLVal _v2 = _v11;
        
        switch(_v2.intVal) {
        case 0: return new ESLVal("Leaf",$one);
        default: {ESLVal _v12 = _v2;
          
          return new ESLVal("Branch",mkTree.apply(_v12.sub($one)),mkTree.apply(_v12.sub($one)));
        }
      }
      }
    }
  });
  private static ESLVal sub = new ESLVal(new Function(new ESLVal("sub"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v9 = $args[0];
  {ESLVal _v10 = newActor(m,new ESLVal(new Actor()));
        
        return _v10;
      }
    }
  });
  private static ESLVal sub1 = new ESLVal(new Function(new ESLVal("fun472"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v8 = $args[0];
  return _v8;
    }
  });
  public static ESLVal main = new ESLVal(new Function(new ESLVal("main"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      return new ESLVal(new BehaviourAdapter(false,getSelf(),new ESLVal("main")) {
          ESLVal f = new ESLVal(new Function(new ESLVal("f"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v7 = $args[0];
            return _v7;
              }
            });
          
          public ESLVal handle(ESLVal $m) {{ESLVal _v1 = $m;
            
            switch(_v1.termName) {
            case "K": {ESLVal $1 = _v1.termRef(0);
              
              {ESLVal l = $1;
              
              return $null;
            }
            }
            default: return error(new ESLVal("case error at Pos(0,0)"));
          }
          }}
          public ESLVal get(String name) {
            switch(name) {
              
              default: throw new Error("ref illegal " + self + "." + name);
            }
          }
        public void handleTime(ESLVal $t) {
          {}
        }
        public ESLVal init() {
            return ((Supplier<ESLVal>)() -> { 
                {print.apply(test.apply(mkTree.apply(new ESLVal(20))));
                sub.apply(newActor(n,new ESLVal(new Actor())));
                sub1.apply(newActor(n,new ESLVal(new Actor())));
                return stopAll.apply();}
              }).get();
          }
        });
    }
  });
public static void main(String[] args) {
    newActor(main,new ESLVal(new Actor())); 
  }
}