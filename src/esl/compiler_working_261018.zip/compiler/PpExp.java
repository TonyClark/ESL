package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
// import static esl.Lists.*;
import static esl.compiler.Types.*;
import static esl.compiler.DynamicVars.*;
import static esl.compiler.Strings.*;
import java.util.function.Supplier;
public class PpExp {
  public static ESLVal getSelf() { return $null; }
  private static ESLVal p0 = new ESLVal("Pos",$zero,$zero);
  private static ESLVal indentStr = new ESLVal(new Function(new ESLVal("indentStr"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  if(indent.eql($zero).boolVal)
        return new ESLVal("");
        else
          return new ESLVal(" ").add(indentStr.apply(indent.sub($one)));
    }
  });
  private static ESLVal nl = new ESLVal(new Function(new ESLVal("nl"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  return new ESLVal("\n").add(indentStr.apply(indent));
    }
  });
  private static ESLVal ppJoin = new ESLVal(new Function(new ESLVal("ppJoin"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal ss = $args[1];
  {ESLVal _v44 = ss;
        
        if(_v44.isCons())
        {ESLVal $435 = _v44.head();
          ESLVal $436 = _v44.tail();
          
          if($436.isCons())
          {ESLVal $437 = $436.head();
            ESLVal $438 = $436.tail();
            
            if($438.isCons())
            {ESLVal $439 = $438.head();
              ESLVal $440 = $438.tail();
              
              {ESLVal s = $435;
              
              {ESLVal _v104 = $436;
              
              return s.add(nl.apply(indent).add(ppJoin.apply(indent,_v104)));
            }
            }
            }
          else if($438.isNil())
            {ESLVal s1 = $435;
              
              {ESLVal s2 = $437;
              
              return s1.add(nl.apply(indent).add(s2));
            }
            }
          else {ESLVal s = $435;
              
              {ESLVal _v105 = $436;
              
              return s.add(nl.apply(indent).add(ppJoin.apply(indent,_v105)));
            }
            }
          }
        else if($436.isNil())
          {ESLVal s = $435;
            
            return s;
          }
        else {ESLVal s = $435;
            
            {ESLVal _v106 = $436;
            
            return s.add(nl.apply(indent).add(ppJoin.apply(indent,_v106)));
          }
          }
        }
      else if(_v44.isNil())
        return new ESLVal("");
      else return error(new ESLVal("case error at Pos(440,598)"));
      }
    }
  });
  public static ESLVal ppTypeEnv = new ESLVal(new Function(new ESLVal("ppTypeEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal env = $args[0];
  {ESLVal[] s = new ESLVal[]{new ESLVal("[")};
        
        {{
        ESLVal _v42 = env;
        while(_v42.isCons()) {
          ESLVal _v41 = _v42.headVal;
          {ESLVal _v40 = new ESLVal(new Function(new ESLVal("forp"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  {ESLVal _v43 = _v41;
                    
                    switch(_v43.termName) {
                    case "Map": {ESLVal $434 = _v43.termRef(0);
                      ESLVal $433 = _v43.termRef(1);
                      
                      {ESLVal n = $434;
                      
                      {ESLVal t = $433;
                      
                      {s[0] = s[0].add(n.add(new ESLVal("->").add(ppType.apply(t).add(new ESLVal(",")))));
                    return $null;}
                    }
                    }
                    }
                    default: {ESLVal $$$ = _v43;
                      
                      return $null;
                    }
                  }
                  }
                }
              });
            
            _v40.apply();
          }
          _v42 = _v42.tailVal;}
      }
      return s[0].add(new ESLVal("]"));}
      }
    }
  });
  public static ESLVal ppTypes = new ESLVal(new Function(new ESLVal("ppTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal ts = $args[0];
  return map.apply(ppType,ts);
    }
  });
  public static ESLVal ppType = new ESLVal(new Function(new ESLVal("ppType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v39 = t;
        
        switch(_v39.termName) {
        case "ActType": {ESLVal $432 = _v39.termRef(0);
          ESLVal $431 = _v39.termRef(1);
          ESLVal $430 = _v39.termRef(2);
          
          {ESLVal l = $432;
          
          {ESLVal decs = $431;
          
          {ESLVal handlers = $430;
          
          return new ESLVal("").add(t);
        }
        }
        }
        }
      case "ApplyType": {ESLVal $429 = _v39.termRef(0);
          ESLVal $428 = _v39.termRef(1);
          ESLVal $427 = _v39.termRef(2);
          
          {ESLVal l = $429;
          
          {ESLVal n = $428;
          
          {ESLVal args = $427;
          
          return n.add(map.apply(ppType,args));
        }
        }
        }
        }
      case "ApplyTypeFun": {ESLVal $426 = _v39.termRef(0);
          ESLVal $425 = _v39.termRef(1);
          ESLVal $424 = _v39.termRef(2);
          
          {ESLVal l = $426;
          
          {ESLVal op = $425;
          
          {ESLVal args = $424;
          
          return ppType.apply(op).add(map.apply(ppType,args));
        }
        }
        }
        }
      case "ArrayType": {ESLVal $423 = _v39.termRef(0);
          ESLVal $422 = _v39.termRef(1);
          
          {ESLVal l = $423;
          
          {ESLVal _v103 = $422;
          
          return new ESLVal("Array[").add(ppType.apply(_v103).add(new ESLVal("]")));
        }
        }
        }
      case "BoolType": {ESLVal $421 = _v39.termRef(0);
          
          {ESLVal l = $421;
          
          return new ESLVal("Bool");
        }
        }
      case "FloatType": {ESLVal $420 = _v39.termRef(0);
          
          {ESLVal l = $420;
          
          return new ESLVal("Float");
        }
        }
      case "FieldType": {ESLVal $419 = _v39.termRef(0);
          ESLVal $418 = _v39.termRef(1);
          ESLVal $417 = _v39.termRef(2);
          
          {ESLVal l = $419;
          
          {ESLVal n = $418;
          
          {ESLVal _v102 = $417;
          
          return n.add(new ESLVal("::").add(ppType.apply(_v102)));
        }
        }
        }
        }
      case "ForallType": {ESLVal $416 = _v39.termRef(0);
          ESLVal $415 = _v39.termRef(1);
          ESLVal $414 = _v39.termRef(2);
          
          {ESLVal l = $416;
          
          {ESLVal ns = $415;
          
          {ESLVal _v101 = $414;
          
          return new ESLVal("Forall").add(ns.add(new ESLVal(".").add(ppType.apply(_v101))));
        }
        }
        }
        }
      case "FunType": {ESLVal $413 = _v39.termRef(0);
          ESLVal $412 = _v39.termRef(1);
          ESLVal $411 = _v39.termRef(2);
          
          {ESLVal l = $413;
          
          {ESLVal d = $412;
          
          {ESLVal r = $411;
          
          return map.apply(ppType,d).add(new ESLVal("->").add(ppType.apply(r)));
        }
        }
        }
        }
      case "TaggedFunType": {ESLVal $410 = _v39.termRef(0);
          ESLVal $409 = _v39.termRef(1);
          ESLVal $408 = _v39.termRef(2);
          ESLVal $407 = _v39.termRef(3);
          
          {ESLVal l = $410;
          
          {ESLVal d = $409;
          
          {ESLVal p = $408;
          
          {ESLVal r = $407;
          
          return map.apply(ppType,d).add(new ESLVal("->").add(ppType.apply(r)));
        }
        }
        }
        }
        }
      case "IntType": {ESLVal $406 = _v39.termRef(0);
          
          {ESLVal l = $406;
          
          return new ESLVal("Int");
        }
        }
      case "ListType": {ESLVal $405 = _v39.termRef(0);
          ESLVal $404 = _v39.termRef(1);
          
          {ESLVal l = $405;
          
          {ESLVal _v100 = $404;
          
          return new ESLVal("[").add(ppType.apply(_v100).add(new ESLVal("]")));
        }
        }
        }
      case "NullType": {ESLVal $403 = _v39.termRef(0);
          
          {ESLVal l = $403;
          
          return new ESLVal("Null");
        }
        }
      case "RecType": {ESLVal $402 = _v39.termRef(0);
          ESLVal $401 = _v39.termRef(1);
          ESLVal $400 = _v39.termRef(2);
          
          {ESLVal l = $402;
          
          {ESLVal n = $401;
          
          {ESLVal _v99 = $400;
          
          return new ESLVal("rec ").add(n.add(new ESLVal(".").add(ppType.apply(_v99))));
        }
        }
        }
        }
      case "RecordType": {ESLVal $399 = _v39.termRef(0);
          ESLVal $398 = _v39.termRef(1);
          
          {ESLVal l = $399;
          
          {ESLVal fs = $398;
          
          return new ESLVal("{").add(ppTypes.apply(fs).add(new ESLVal("}")));
        }
        }
        }
      case "StrType": {ESLVal $397 = _v39.termRef(0);
          
          {ESLVal l = $397;
          
          return new ESLVal("Str");
        }
        }
      case "TermType": {ESLVal $396 = _v39.termRef(0);
          ESLVal $395 = _v39.termRef(1);
          ESLVal $394 = _v39.termRef(2);
          
          {ESLVal l = $396;
          
          {ESLVal n = $395;
          
          {ESLVal ts = $394;
          
          return n.add(map.apply(ppType,ts));
        }
        }
        }
        }
      case "TypeFun": {ESLVal $393 = _v39.termRef(0);
          ESLVal $392 = _v39.termRef(1);
          ESLVal $391 = _v39.termRef(2);
          
          {ESLVal l = $393;
          
          {ESLVal ns = $392;
          
          {ESLVal _v98 = $391;
          
          return new ESLVal("Fun").add(ns.add(new ESLVal(".").add(ppType.apply(_v98))));
        }
        }
        }
        }
      case "UnfoldType": {ESLVal $390 = _v39.termRef(0);
          ESLVal $389 = _v39.termRef(1);
          
          {ESLVal l = $390;
          
          {ESLVal _v97 = $389;
          
          return new ESLVal("unfold ").add(ppType.apply(_v97));
        }
        }
        }
      case "UnionType": {ESLVal $388 = _v39.termRef(0);
          ESLVal $387 = _v39.termRef(1);
          
          {ESLVal l = $388;
          
          {ESLVal ts = $387;
          
          return new ESLVal("union ").add(map.apply(ppType,ts));
        }
        }
        }
      case "VarType": {ESLVal $386 = _v39.termRef(0);
          ESLVal $385 = _v39.termRef(1);
          
          {ESLVal l = $386;
          
          {ESLVal n = $385;
          
          return n;
        }
        }
        }
      case "VoidType": {ESLVal $384 = _v39.termRef(0);
          
          {ESLVal l = $384;
          
          return new ESLVal("Void");
        }
        }
      case "UnionRef": {ESLVal $383 = _v39.termRef(0);
          ESLVal $382 = _v39.termRef(1);
          ESLVal $381 = _v39.termRef(2);
          
          {ESLVal l = $383;
          
          {ESLVal _v96 = $382;
          
          {ESLVal n = $381;
          
          return ppType.apply(_v96).add(new ESLVal(".").add(n));
        }
        }
        }
        }
      case "TypeClosure": {ESLVal $380 = _v39.termRef(0);
          
          {ESLVal f = $380;
          
          return f.add(new ESLVal(""));
        }
        }
        default: {ESLVal x = _v39;
          
          return new ESLVal("<unknown ").add(x.add(new ESLVal(">")));
        }
      }
      }
    }
  });
  public static ESLVal ppExps = new ESLVal(new Function(new ESLVal("ppExps"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal exps = $args[1];
  ESLVal sep = $args[2];
  {ESLVal _v38 = exps;
        
        if(_v38.isCons())
        {ESLVal $376 = _v38.head();
          ESLVal $377 = _v38.tail();
          
          if($377.isCons())
          {ESLVal $378 = $377.head();
            ESLVal $379 = $377.tail();
            
            {ESLVal e1 = $376;
            
            {ESLVal e2 = $378;
            
            {ESLVal es = $379;
            
            return ppExp.apply(indent,e1).add(sep.add(ppExps.apply(indent,es.cons(e2),sep)));
          }
          }
          }
          }
        else if($377.isNil())
          {ESLVal e = $376;
            
            return ppExp.apply(indent,e);
          }
        else return error(new ESLVal("case error at Pos(2334,2492)"));
        }
      else if(_v38.isNil())
        return new ESLVal("");
      else return error(new ESLVal("case error at Pos(2334,2492)"));
      }
    }
  });
  private static ESLVal ppPattern = new ESLVal(new Function(new ESLVal("ppPattern"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v37 = p;
        
        switch(_v37.termName) {
        case "PVar": {ESLVal $375 = _v37.termRef(0);
          ESLVal $374 = _v37.termRef(1);
          ESLVal $373 = _v37.termRef(2);
          
          {ESLVal l = $375;
          
          {ESLVal n = $374;
          
          {ESLVal t = $373;
          
          return n;
        }
        }
        }
        }
      case "PTerm": {ESLVal $370 = _v37.termRef(0);
          ESLVal $369 = _v37.termRef(1);
          ESLVal $368 = _v37.termRef(2);
          ESLVal $367 = _v37.termRef(3);
          
          if($368.isCons())
          {ESLVal $371 = $368.head();
            ESLVal $372 = $368.tail();
            
            {ESLVal l = $370;
            
            {ESLVal n = $369;
            
            {ESLVal ts = $368;
            
            {ESLVal ps = $367;
            
            return n.add(ppPatterns.apply(ps));
          }
          }
          }
          }
          }
        else if($368.isNil())
          {ESLVal l = $370;
            
            {ESLVal n = $369;
            
            {ESLVal ps = $367;
            
            return n.add(ppPatterns.apply(ps));
          }
          }
          }
        else {ESLVal l = $370;
            
            {ESLVal n = $369;
            
            {ESLVal ts = $368;
            
            {ESLVal ps = $367;
            
            return n.add(ppPatterns.apply(ps));
          }
          }
          }
          }
        }
      case "PApplyType": {ESLVal $366 = _v37.termRef(0);
          ESLVal $365 = _v37.termRef(1);
          ESLVal $364 = _v37.termRef(2);
          
          {ESLVal l = $366;
          
          {ESLVal _v94 = $365;
          
          {ESLVal ts = $364;
          
          return ppPattern.apply(_v94);
        }
        }
        }
        }
      case "PNil": {ESLVal $363 = _v37.termRef(0);
          
          {ESLVal l = $363;
          
          return new ESLVal("[]");
        }
        }
      case "PInt": {ESLVal $362 = _v37.termRef(0);
          ESLVal $361 = _v37.termRef(1);
          
          {ESLVal l = $362;
          
          {ESLVal n = $361;
          
          return new ESLVal("").add(n);
        }
        }
        }
      case "PBool": {ESLVal $360 = _v37.termRef(0);
          ESLVal $359 = _v37.termRef(1);
          
          {ESLVal l = $360;
          
          {ESLVal b = $359;
          
          return new ESLVal("").add(b);
        }
        }
        }
      case "PStr": {ESLVal $358 = _v37.termRef(0);
          ESLVal $357 = _v37.termRef(1);
          
          {ESLVal l = $358;
          
          {ESLVal s = $357;
          
          return new ESLVal("\'").add(s.add(new ESLVal("\'")));
        }
        }
        }
      case "PCons": {ESLVal $356 = _v37.termRef(0);
          ESLVal $355 = _v37.termRef(1);
          ESLVal $354 = _v37.termRef(2);
          
          {ESLVal l = $356;
          
          {ESLVal h = $355;
          
          {ESLVal t = $354;
          
          return ppPattern.apply(h).add(new ESLVal(":").add(ppPattern.apply(t)));
        }
        }
        }
        }
        default: {ESLVal _v95 = _v37;
          
          return new ESLVal("<unknown: ").add(_v95.add(new ESLVal(">")));
        }
      }
      }
    }
  });
  private static ESLVal ppPatterns = new ESLVal(new Function(new ESLVal("ppPatterns"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal ps = $args[0];
  return map.apply(ppPattern,ps);
    }
  });
  public static ESLVal ppExp = new ESLVal(new Function(new ESLVal("ppExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal exp = $args[1];
  {ESLVal _v36 = exp;
        
        switch(_v36.termName) {
        case "Module": {ESLVal $353 = _v36.termRef(0);
          ESLVal $352 = _v36.termRef(1);
          ESLVal $351 = _v36.termRef(2);
          ESLVal $350 = _v36.termRef(3);
          ESLVal $349 = _v36.termRef(4);
          ESLVal $348 = _v36.termRef(5);
          ESLVal $347 = _v36.termRef(6);
          
          {ESLVal path = $353;
          
          {ESLVal name = $352;
          
          {ESLVal exports = $351;
          
          {ESLVal imports = $350;
          
          {ESLVal x = $349;
          
          {ESLVal y = $348;
          
          {ESLVal defs = $347;
          
          return new ESLVal("module ").add(name.add(new ESLVal("{").add(nl.apply(indent.add(new ESLVal(2))).add(ppBinds.apply(indent.add(new ESLVal(2)),defs).add(nl.apply(indent).add(new ESLVal("}")))))));
        }
        }
        }
        }
        }
        }
        }
        }
      case "Var": {ESLVal $346 = _v36.termRef(0);
          ESLVal $345 = _v36.termRef(1);
          
          {ESLVal l = $346;
          
          {ESLVal n = $345;
          
          return n;
        }
        }
        }
      case "StrExp": {ESLVal $344 = _v36.termRef(0);
          ESLVal $343 = _v36.termRef(1);
          
          {ESLVal l = $344;
          
          {ESLVal v = $343;
          
          return new ESLVal("\'").add(v.add(new ESLVal("\'")));
        }
        }
        }
      case "IntExp": {ESLVal $342 = _v36.termRef(0);
          ESLVal $341 = _v36.termRef(1);
          
          {ESLVal l = $342;
          
          {ESLVal v = $341;
          
          return v.add(new ESLVal(""));
        }
        }
        }
      case "BoolExp": {ESLVal $340 = _v36.termRef(0);
          ESLVal $339 = _v36.termRef(1);
          
          {ESLVal l = $340;
          
          {ESLVal v = $339;
          
          return v.add(new ESLVal(""));
        }
        }
        }
      case "NullExp": {ESLVal $338 = _v36.termRef(0);
          
          {ESLVal l = $338;
          
          return new ESLVal("null");
        }
        }
      case "FloatExp": {ESLVal $337 = _v36.termRef(0);
          ESLVal $336 = _v36.termRef(1);
          
          {ESLVal l = $337;
          
          {ESLVal f = $336;
          
          return f.add(new ESLVal(""));
        }
        }
        }
      case "Apply": {ESLVal $335 = _v36.termRef(0);
          ESLVal $334 = _v36.termRef(1);
          ESLVal $333 = _v36.termRef(2);
          
          {ESLVal l = $335;
          
          {ESLVal op = $334;
          
          {ESLVal args = $333;
          
          return ppExp.apply(indent,op).add(new ESLVal("(").add(ppExps.apply(indent,args,new ESLVal(",")).add(new ESLVal(")"))));
        }
        }
        }
        }
      case "ApplyTypeExp": {ESLVal $332 = _v36.termRef(0);
          ESLVal $331 = _v36.termRef(1);
          ESLVal $330 = _v36.termRef(2);
          
          {ESLVal l = $332;
          
          {ESLVal op = $331;
          
          {ESLVal args = $330;
          
          return ppExp.apply(indent,op);
        }
        }
        }
        }
      case "Block": {ESLVal $329 = _v36.termRef(0);
          ESLVal $328 = _v36.termRef(1);
          
          {ESLVal l = $329;
          
          {ESLVal es = $328;
          
          return new ESLVal("{").add(nl.apply(indent.add(new ESLVal(2))).add(ppExps.apply(indent.add(new ESLVal(2)),es,new ESLVal(";")).add(nl.apply(indent).add(new ESLVal("}")))));
        }
        }
        }
      case "Case": {ESLVal $327 = _v36.termRef(0);
          ESLVal $326 = _v36.termRef(1);
          ESLVal $325 = _v36.termRef(2);
          ESLVal $324 = _v36.termRef(3);
          
          {ESLVal l = $327;
          
          {ESLVal ds = $326;
          
          {ESLVal es = $325;
          
          {ESLVal as = $324;
          
          return new ESLVal("case ").add(ppExps.apply(indent,es,new ESLVal(",")).add(new ESLVal(" {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun376"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal a = $args[0];
          return ppArm.apply(indent,a);
            }
          }),as)).add(nl.apply(indent).add(new ESLVal("}")))))));
        }
        }
        }
        }
        }
      case "CaseTerm": {ESLVal $323 = _v36.termRef(0);
          ESLVal $322 = _v36.termRef(1);
          ESLVal $321 = _v36.termRef(2);
          ESLVal $320 = _v36.termRef(3);
          
          {ESLVal l = $323;
          
          {ESLVal e = $322;
          
          {ESLVal arms = $321;
          
          {ESLVal alt = $320;
          
          return new ESLVal("caseTerm ").add(ppExp.apply(indent,e).add(new ESLVal(" {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun377"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal a = $args[0];
          return ppCaseTermArm.apply(indent.add(new ESLVal(2)),a);
            }
          }),arms)).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("else ").add(ppExp.apply(indent.add(new ESLVal(4)),alt).add(nl.apply(indent).add(new ESLVal("}"))))))))));
        }
        }
        }
        }
        }
      case "CaseList": {ESLVal $319 = _v36.termRef(0);
          ESLVal $318 = _v36.termRef(1);
          ESLVal $317 = _v36.termRef(2);
          ESLVal $316 = _v36.termRef(3);
          ESLVal $315 = _v36.termRef(4);
          
          {ESLVal l = $319;
          
          {ESLVal e = $318;
          
          {ESLVal cons = $317;
          
          {ESLVal nil = $316;
          
          {ESLVal alt = $315;
          
          return new ESLVal("caseList ").add(ppExp.apply(indent,e).add(new ESLVal(" {").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("CONS ->").add(nl.apply(indent.add(new ESLVal(4))).add(ppExp.apply(indent.add(new ESLVal(4)),cons).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("NIL ->").add(nl.apply(indent.add(new ESLVal(4))).add(ppExp.apply(indent.add(new ESLVal(4)),nil).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("else ").add(ppExp.apply(indent.add(new ESLVal(4)),alt).add(nl.apply(indent).add(new ESLVal("}"))))))))))))))));
        }
        }
        }
        }
        }
        }
      case "CaseInt": {ESLVal $314 = _v36.termRef(0);
          ESLVal $313 = _v36.termRef(1);
          ESLVal $312 = _v36.termRef(2);
          ESLVal $311 = _v36.termRef(3);
          
          {ESLVal l = $314;
          
          {ESLVal e = $313;
          
          {ESLVal arms = $312;
          
          {ESLVal alt = $311;
          
          return new ESLVal("caseInt ").add(ppExp.apply(indent,e).add(new ESLVal(" {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun378"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal a = $args[0];
          return ppCaseIntsArm.apply(indent.add(new ESLVal(2)),a);
            }
          }),arms)).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("else ").add(ppExp.apply(indent.add(new ESLVal(4)),alt).add(nl.apply(indent).add(new ESLVal("}"))))))))));
        }
        }
        }
        }
        }
      case "CaseStr": {ESLVal $310 = _v36.termRef(0);
          ESLVal $309 = _v36.termRef(1);
          ESLVal $308 = _v36.termRef(2);
          ESLVal $307 = _v36.termRef(3);
          
          {ESLVal l = $310;
          
          {ESLVal e = $309;
          
          {ESLVal arms = $308;
          
          {ESLVal alt = $307;
          
          return new ESLVal("caseStr ").add(ppExp.apply(indent,e).add(new ESLVal(" {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun379"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal a = $args[0];
          return ppCaseStrsArm.apply(indent.add(new ESLVal(2)),a);
            }
          }),arms)).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("else ").add(ppExp.apply(indent.add(new ESLVal(4)),alt).add(nl.apply(indent).add(new ESLVal("}"))))))))));
        }
        }
        }
        }
        }
      case "CaseBool": {ESLVal $306 = _v36.termRef(0);
          ESLVal $305 = _v36.termRef(1);
          ESLVal $304 = _v36.termRef(2);
          ESLVal $303 = _v36.termRef(3);
          
          {ESLVal l = $306;
          
          {ESLVal e = $305;
          
          {ESLVal arms = $304;
          
          {ESLVal alt = $303;
          
          return new ESLVal("caseBool ").add(ppExp.apply(indent,e).add(new ESLVal(" {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun380"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal a = $args[0];
          return ppCaseBoolsArm.apply(indent.add(new ESLVal(2)),a);
            }
          }),arms)).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("else ").add(ppExp.apply(indent.add(new ESLVal(4)),alt).add(nl.apply(indent).add(new ESLVal("}"))))))))));
        }
        }
        }
        }
        }
      case "CaseError": {ESLVal $302 = _v36.termRef(0);
          
          {ESLVal l = $302;
          
          return new ESLVal("caseError()");
        }
        }
      case "Head": {ESLVal $301 = _v36.termRef(0);
          
          {ESLVal e = $301;
          
          return new ESLVal("head(").add(ppExp.apply(indent,e).add(new ESLVal(")")));
        }
        }
      case "Tail": {ESLVal $300 = _v36.termRef(0);
          
          {ESLVal e = $300;
          
          return new ESLVal("tail(").add(ppExp.apply(indent,e).add(new ESLVal(")")));
        }
        }
      case "Cons": {ESLVal $299 = _v36.termRef(0);
          ESLVal $298 = _v36.termRef(1);
          
          {ESLVal h = $299;
          
          {ESLVal t = $298;
          
          return new ESLVal("cons(").add(ppExp.apply(indent,h).add(new ESLVal(",").add(ppExp.apply(indent,t).add(new ESLVal(")")))));
        }
        }
        }
      case "If": {ESLVal $297 = _v36.termRef(0);
          ESLVal $296 = _v36.termRef(1);
          ESLVal $295 = _v36.termRef(2);
          ESLVal $294 = _v36.termRef(3);
          
          {ESLVal l = $297;
          
          {ESLVal e1 = $296;
          
          {ESLVal e2 = $295;
          
          {ESLVal e3 = $294;
          
          return new ESLVal("if ").add(ppExp.apply(indent,e1).add(nl.apply(indent).add(new ESLVal("then").add(nl.apply(indent.add(new ESLVal(2))).add(ppExp.apply(indent.add(new ESLVal(2)),e2).add(nl.apply(indent).add(new ESLVal("else").add(nl.apply(indent.add(new ESLVal(2))).add(ppExp.apply(indent.add(new ESLVal(2)),e3))))))))));
        }
        }
        }
        }
        }
      case "FunExp": {ESLVal $293 = _v36.termRef(0);
          ESLVal $292 = _v36.termRef(1);
          ESLVal $291 = _v36.termRef(2);
          ESLVal $290 = _v36.termRef(3);
          ESLVal $289 = _v36.termRef(4);
          
          {ESLVal l = $293;
          
          {ESLVal n = $292;
          
          {ESLVal args = $291;
          
          {ESLVal t = $290;
          
          {ESLVal e = $289;
          
          return new ESLVal("fun(").add(ppDecs.apply(indent,args).add(new ESLVal(")::").add(ppType.apply(t).add(new ESLVal(" ").add(ppExp.apply(indent.add(new ESLVal(2)),e))))));
        }
        }
        }
        }
        }
        }
      case "Let": {ESLVal $288 = _v36.termRef(0);
          ESLVal $287 = _v36.termRef(1);
          ESLVal $286 = _v36.termRef(2);
          
          {ESLVal l = $288;
          
          {ESLVal bs = $287;
          
          {ESLVal e = $286;
          
          return new ESLVal("let ").add(ppBinds.apply(indent.add(new ESLVal(4)),bs).add(nl.apply(indent).add(new ESLVal("in ").add(ppExp.apply(indent.add(new ESLVal(3)),e)))));
        }
        }
        }
        }
      case "Letrec": {ESLVal $285 = _v36.termRef(0);
          ESLVal $284 = _v36.termRef(1);
          ESLVal $283 = _v36.termRef(2);
          
          {ESLVal l = $285;
          
          {ESLVal bs = $284;
          
          {ESLVal e = $283;
          
          return new ESLVal("letrec ").add(ppBinds.apply(indent.add(new ESLVal(7)),bs).add(nl.apply(indent).add(new ESLVal("in ").add(ppExp.apply(indent.add(new ESLVal(3)),e)))));
        }
        }
        }
        }
      case "List": {ESLVal $282 = _v36.termRef(0);
          ESLVal $281 = _v36.termRef(1);
          
          {ESLVal l = $282;
          
          {ESLVal es = $281;
          
          return new ESLVal("[").add(ppExps.apply(indent,es,new ESLVal(",")).add(new ESLVal("]")));
        }
        }
        }
      case "Throw": {ESLVal $280 = _v36.termRef(0);
          ESLVal $279 = _v36.termRef(1);
          ESLVal $278 = _v36.termRef(2);
          
          {ESLVal l = $280;
          
          {ESLVal t = $279;
          
          {ESLVal e = $278;
          
          return new ESLVal("throw ").add(ppExp.apply(indent,e));
        }
        }
        }
        }
      case "Term": {ESLVal $277 = _v36.termRef(0);
          ESLVal $276 = _v36.termRef(1);
          ESLVal $275 = _v36.termRef(2);
          ESLVal $274 = _v36.termRef(3);
          
          {ESLVal l = $277;
          
          {ESLVal n = $276;
          
          {ESLVal ts = $275;
          
          {ESLVal es = $274;
          
          return n.add(new ESLVal("(").add(ppExps.apply(indent,es,new ESLVal(",")).add(new ESLVal(")"))));
        }
        }
        }
        }
        }
      case "TermRef": {ESLVal $273 = _v36.termRef(0);
          ESLVal $272 = _v36.termRef(1);
          
          {ESLVal e = $273;
          
          {ESLVal n = $272;
          
          return new ESLVal("termRef(").add(ppExp.apply(indent,e).add(new ESLVal(",").add(n.add(new ESLVal(")")))));
        }
        }
        }
      case "BinExp": {ESLVal $271 = _v36.termRef(0);
          ESLVal $270 = _v36.termRef(1);
          ESLVal $269 = _v36.termRef(2);
          ESLVal $268 = _v36.termRef(3);
          
          {ESLVal l = $271;
          
          {ESLVal e1 = $270;
          
          {ESLVal op = $269;
          
          {ESLVal e2 = $268;
          
          return ppExp.apply(indent,e1).add(op.add(ppExp.apply(indent,e2)));
        }
        }
        }
        }
        }
      case "Update": {ESLVal $267 = _v36.termRef(0);
          ESLVal $266 = _v36.termRef(1);
          ESLVal $265 = _v36.termRef(2);
          
          {ESLVal l = $267;
          
          {ESLVal n = $266;
          
          {ESLVal e = $265;
          
          return n.add(new ESLVal(" := ").add(ppExp.apply(indent,e)));
        }
        }
        }
        }
      case "NewArray": {ESLVal $264 = _v36.termRef(0);
          ESLVal $263 = _v36.termRef(1);
          ESLVal $262 = _v36.termRef(2);
          
          {ESLVal l = $264;
          
          {ESLVal t = $263;
          
          {ESLVal n = $262;
          
          return new ESLVal("new Array[").add(ppType.apply(t).add(new ESLVal("](").add(ppExp.apply(indent,n).add(new ESLVal(")")))));
        }
        }
        }
        }
      case "For": {ESLVal $261 = _v36.termRef(0);
          ESLVal $260 = _v36.termRef(1);
          ESLVal $259 = _v36.termRef(2);
          ESLVal $258 = _v36.termRef(3);
          
          {ESLVal l = $261;
          
          {ESLVal p = $260;
          
          {ESLVal e1 = $259;
          
          {ESLVal e2 = $258;
          
          return new ESLVal("for ").add(ppPattern.apply(p).add(new ESLVal(" in ").add(ppExp.apply(indent,e1).add(new ESLVal(" do {").add(nl.apply(indent.add(new ESLVal(2))).add(ppExp.apply(indent.add(new ESLVal(2)),e2).add(new ESLVal("}"))))))));
        }
        }
        }
        }
        }
      case "Try": {ESLVal $257 = _v36.termRef(0);
          ESLVal $256 = _v36.termRef(1);
          ESLVal $255 = _v36.termRef(2);
          
          {ESLVal l = $257;
          
          {ESLVal e = $256;
          
          {ESLVal as = $255;
          
          return new ESLVal("try ").add(ppExp.apply(indent,e).add(new ESLVal(" {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun381"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal a = $args[0];
          return ppArm.apply(indent,a);
            }
          }),as)).add(nl.apply(indent).add(new ESLVal("}")))))));
        }
        }
        }
        }
      case "ActExp": {ESLVal $254 = _v36.termRef(0);
          ESLVal $253 = _v36.termRef(1);
          ESLVal $252 = _v36.termRef(2);
          ESLVal $251 = _v36.termRef(3);
          ESLVal $250 = _v36.termRef(4);
          ESLVal $249 = _v36.termRef(5);
          ESLVal $248 = _v36.termRef(6);
          ESLVal $247 = _v36.termRef(7);
          
          {ESLVal l = $254;
          
          {ESLVal n = $253;
          
          {ESLVal args = $252;
          
          {ESLVal x = $251;
          
          {ESLVal parent = $250;
          
          {ESLVal locals = $249;
          
          {ESLVal init = $248;
          
          {ESLVal handlers = $247;
          
          {print.apply(new ESLVal("PARENT = ").add(parent));
        return new ESLVal("act ").add(ppExp.apply(indent,n).add(new ESLVal("(").add(ppDecs.apply(indent,args).add(new ESLVal(") {").add(nl.apply(indent.add(new ESLVal(2))).add(ppBinds.apply(indent.add(new ESLVal(5)),locals).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("-> ").add(ppExp.apply(indent.add(new ESLVal(4)),init).add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun382"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal a = $args[0];
          return ppArm.apply(indent,a);
            }
          }),handlers)).add(nl.apply(indent).add(new ESLVal("}"))))))))))))));}
        }
        }
        }
        }
        }
        }
        }
        }
        }
      case "Self": {ESLVal $246 = _v36.termRef(0);
          
          {ESLVal l = $246;
          
          return new ESLVal("self");
        }
        }
      case "Ref": {ESLVal $245 = _v36.termRef(0);
          ESLVal $244 = _v36.termRef(1);
          ESLVal $243 = _v36.termRef(2);
          
          {ESLVal l = $245;
          
          {ESLVal e = $244;
          
          {ESLVal n = $243;
          
          return ppExp.apply(indent,e).add(new ESLVal(".").add(n));
        }
        }
        }
        }
      case "Send": {ESLVal $242 = _v36.termRef(0);
          ESLVal $241 = _v36.termRef(1);
          ESLVal $240 = _v36.termRef(2);
          
          {ESLVal l = $242;
          
          {ESLVal target = $241;
          
          {ESLVal message = $240;
          
          return ppExp.apply(indent,target).add(new ESLVal(" <- ").add(ppExp.apply(indent,message)));
        }
        }
        }
        }
      case "Cmp": {ESLVal $239 = _v36.termRef(0);
          ESLVal $238 = _v36.termRef(1);
          ESLVal $237 = _v36.termRef(2);
          
          {ESLVal l = $239;
          
          {ESLVal e = $238;
          
          {ESLVal qs = $237;
          
          return new ESLVal("[").add(ppExp.apply(indent,e).add(new ESLVal(" | ").add(ppJoin.apply(indent.add(new ESLVal(2)),map.apply(new ESLVal(new Function(new ESLVal("fun383"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal q = $args[0];
          return ppQual.apply(indent,q);
            }
          }),qs)).add(new ESLVal("]")))));
        }
        }
        }
        }
      case "New": {ESLVal $236 = _v36.termRef(0);
          ESLVal $235 = _v36.termRef(1);
          ESLVal $234 = _v36.termRef(2);
          
          {ESLVal l = $236;
          
          {ESLVal b = $235;
          
          {ESLVal args = $234;
          
          return new ESLVal("new ").add(ppExp.apply(indent,b).add(new ESLVal("(").add(ppExps.apply(indent,args,new ESLVal(",")).add(new ESLVal(")")))));
        }
        }
        }
        }
      case "NewJava": {ESLVal $233 = _v36.termRef(0);
          ESLVal $232 = _v36.termRef(1);
          ESLVal $231 = _v36.termRef(2);
          ESLVal $230 = _v36.termRef(3);
          
          {ESLVal l = $233;
          
          {ESLVal className = $232;
          
          {ESLVal t = $231;
          
          {ESLVal args = $230;
          
          return new ESLVal("javaNew[").add(ppType.apply(t).add(new ESLVal("](\' + className + ").add(ppExps.apply(indent,args,new ESLVal(",")).add(new ESLVal(")")))));
        }
        }
        }
        }
        }
      case "Grab": {ESLVal $229 = _v36.termRef(0);
          ESLVal $228 = _v36.termRef(1);
          ESLVal $227 = _v36.termRef(2);
          
          {ESLVal l = $229;
          
          {ESLVal rs = $228;
          
          {ESLVal e = $227;
          
          return new ESLVal("*********grab");
        }
        }
        }
        }
      case "Probably": {ESLVal $226 = _v36.termRef(0);
          ESLVal $225 = _v36.termRef(1);
          ESLVal $224 = _v36.termRef(2);
          ESLVal $223 = _v36.termRef(3);
          ESLVal $222 = _v36.termRef(4);
          
          {ESLVal l = $226;
          
          {ESLVal p = $225;
          
          {ESLVal t = $224;
          
          {ESLVal e1 = $223;
          
          {ESLVal e2 = $222;
          
          return new ESLVal("**** probably");
        }
        }
        }
        }
        }
        }
      case "Not": {ESLVal $221 = _v36.termRef(0);
          ESLVal $220 = _v36.termRef(1);
          
          {ESLVal l = $221;
          
          {ESLVal e = $220;
          
          return new ESLVal("not(").add(ppExp.apply(indent,e).add(new ESLVal(")")));
        }
        }
        }
      case "Fold": {ESLVal $219 = _v36.termRef(0);
          ESLVal $218 = _v36.termRef(1);
          ESLVal $217 = _v36.termRef(2);
          
          {ESLVal l = $219;
          
          {ESLVal t = $218;
          
          {ESLVal e = $217;
          
          return new ESLVal("******** fold");
        }
        }
        }
        }
      case "Unfold": {ESLVal $216 = _v36.termRef(0);
          ESLVal $215 = _v36.termRef(1);
          ESLVal $214 = _v36.termRef(2);
          
          {ESLVal l = $216;
          
          {ESLVal t = $215;
          
          {ESLVal e = $214;
          
          return new ESLVal("******unfold");
        }
        }
        }
        }
      case "Now": {ESLVal $213 = _v36.termRef(0);
          
          {ESLVal l = $213;
          
          return new ESLVal("now");
        }
        }
      case "Become": {ESLVal $212 = _v36.termRef(0);
          ESLVal $211 = _v36.termRef(1);
          
          {ESLVal l = $212;
          
          {ESLVal e = $211;
          
          return new ESLVal("become ").add(ppExp.apply(indent,e));
        }
        }
        }
      case "ArrayRef": {ESLVal $210 = _v36.termRef(0);
          ESLVal $209 = _v36.termRef(1);
          ESLVal $208 = _v36.termRef(2);
          
          {ESLVal l = $210;
          
          {ESLVal a = $209;
          
          {ESLVal i = $208;
          
          return ppExp.apply(indent,a).add(new ESLVal("[").add(ppExp.apply(indent,i).add(new ESLVal("]"))));
        }
        }
        }
        }
      case "ArrayUpdate": {ESLVal $207 = _v36.termRef(0);
          ESLVal $206 = _v36.termRef(1);
          ESLVal $205 = _v36.termRef(2);
          ESLVal $204 = _v36.termRef(3);
          
          {ESLVal l = $207;
          
          {ESLVal a = $206;
          
          {ESLVal i = $205;
          
          {ESLVal v = $204;
          
          return ppExp.apply(indent,a).add(new ESLVal("[").add(ppExp.apply(indent,i).add(new ESLVal("] := ").add(ppExp.apply(indent,v)))));
        }
        }
        }
        }
        }
        default: {ESLVal x = _v36;
          
          return error(new ESLVal("ppExp: ").add(x));
        }
      }
      }
    }
  });
  private static ESLVal ppQual = new ESLVal(new Function(new ESLVal("ppQual"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal q = $args[1];
  return new ESLVal("qualifier: ").add(q);
    }
  });
  private static ESLVal ppDecs = new ESLVal(new Function(new ESLVal("ppDecs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal bs = $args[1];
  return ppJoin.apply(indent,map.apply(new ESLVal(new Function(new ESLVal("fun384"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal b = $args[0];
        return ppDec.apply(indent,b);
          }
        }),bs));
    }
  });
  private static ESLVal ppDec = new ESLVal(new Function(new ESLVal("ppDec"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal d = $args[1];
  {ESLVal _v35 = d;
        
        switch(_v35.termName) {
        case "Dec": {ESLVal $203 = _v35.termRef(0);
          ESLVal $202 = _v35.termRef(1);
          ESLVal $201 = _v35.termRef(2);
          ESLVal $200 = _v35.termRef(3);
          
          {ESLVal l = $203;
          
          {ESLVal n = $202;
          
          {ESLVal dt = $201;
          
          {ESLVal t = $200;
          
          return n.add(new ESLVal("::").add(ppType.apply(t)));
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(9506,9583)"));
      }
      }
    }
  });
  private static ESLVal ppBinds = new ESLVal(new Function(new ESLVal("ppBinds"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal bs = $args[1];
  return ppJoin.apply(indent,map.apply(new ESLVal(new Function(new ESLVal("fun385"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal b = $args[0];
        return ppBind.apply(indent,b);
          }
        }),bs));
    }
  });
  private static ESLVal ppBind = new ESLVal(new Function(new ESLVal("ppBind"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal b = $args[1];
  {ESLVal _v34 = b;
        
        switch(_v34.termName) {
        case "Binding": {ESLVal $199 = _v34.termRef(0);
          ESLVal $198 = _v34.termRef(1);
          ESLVal $197 = _v34.termRef(2);
          ESLVal $196 = _v34.termRef(3);
          ESLVal $195 = _v34.termRef(4);
          
          {ESLVal l = $199;
          
          {ESLVal name = $198;
          
          {ESLVal t = $197;
          
          {ESLVal st = $196;
          
          {ESLVal value = $195;
          
          return name.add(new ESLVal("=").add(ppExp.apply(indent,value).add(new ESLVal(";"))));
        }
        }
        }
        }
        }
        }
      case "TypeBind": {ESLVal $194 = _v34.termRef(0);
          ESLVal $193 = _v34.termRef(1);
          ESLVal $192 = _v34.termRef(2);
          ESLVal $191 = _v34.termRef(3);
          
          {ESLVal l = $194;
          
          {ESLVal name = $193;
          
          {ESLVal t = $192;
          
          {ESLVal ignore = $191;
          
          return new ESLVal("type ").add(name);
        }
        }
        }
        }
        }
      case "DataBind": {ESLVal $190 = _v34.termRef(0);
          ESLVal $189 = _v34.termRef(1);
          ESLVal $188 = _v34.termRef(2);
          ESLVal $187 = _v34.termRef(3);
          
          {ESLVal l = $190;
          
          {ESLVal name = $189;
          
          {ESLVal t = $188;
          
          {ESLVal ignore = $187;
          
          return new ESLVal("data ").add(name);
        }
        }
        }
        }
        }
      case "FunBind": {ESLVal $186 = _v34.termRef(0);
          ESLVal $185 = _v34.termRef(1);
          ESLVal $184 = _v34.termRef(2);
          ESLVal $183 = _v34.termRef(3);
          ESLVal $182 = _v34.termRef(4);
          ESLVal $181 = _v34.termRef(5);
          ESLVal $180 = _v34.termRef(6);
          
          {ESLVal l = $186;
          
          {ESLVal name = $185;
          
          {ESLVal args = $184;
          
          {ESLVal t = $183;
          
          {ESLVal st = $182;
          
          {ESLVal body = $181;
          
          {ESLVal guard = $180;
          
          return name.add(new ESLVal("(").add(ppPatterns.apply(args).add(new ESLVal(") = ").add(nl.apply(indent.add(new ESLVal(2))).add(ppExp.apply(indent.add(new ESLVal(2)),body))))));
        }
        }
        }
        }
        }
        }
        }
        }
      case "CnstrBind": {ESLVal $179 = _v34.termRef(0);
          ESLVal $178 = _v34.termRef(1);
          ESLVal $177 = _v34.termRef(2);
          ESLVal $176 = _v34.termRef(3);
          
          {ESLVal l = $179;
          
          {ESLVal name = $178;
          
          {ESLVal t = $177;
          
          {ESLVal ignore = $176;
          
          return name;
        }
        }
        }
        }
        }
        default: {ESLVal x = _v34;
          
          return error(new ESLVal("ppBind: ").add(x));
        }
      }
      }
    }
  });
  public static ESLVal ppArm = new ESLVal(new Function(new ESLVal("ppArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal a = $args[1];
  {ESLVal _v33 = a;
        
        switch(_v33.termName) {
        case "BArm": {ESLVal $175 = _v33.termRef(0);
          ESLVal $174 = _v33.termRef(1);
          ESLVal $173 = _v33.termRef(2);
          ESLVal $172 = _v33.termRef(3);
          
          {ESLVal l = $175;
          
          {ESLVal ps = $174;
          
          {ESLVal guard = $173;
          
          {ESLVal e = $172;
          
          return ppPatterns.apply(ps).add(new ESLVal(" -> ").add(nl.apply(indent.add(new ESLVal(2))).add(ppExp.apply(indent.add(new ESLVal(2)),e))));
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(10368,10506)"));
      }
      }
    }
  });
  public static ESLVal ppArms = new ESLVal(new Function(new ESLVal("ppArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal arms = $args[1];
  return ppJoin.apply(indent,map.apply(new ESLVal(new Function(new ESLVal("fun386"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal a = $args[0];
        return ppArm.apply(indent,a);
          }
        }),arms));
    }
  });
  private static ESLVal ppCaseTermArm = new ESLVal(new Function(new ESLVal("ppCaseTermArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal a = $args[1];
  {ESLVal _v32 = a;
        
        switch(_v32.termName) {
        case "TArm": {ESLVal $171 = _v32.termRef(0);
          ESLVal $170 = _v32.termRef(1);
          
          {ESLVal n = $171;
          
          {ESLVal e = $170;
          
          return n.add(new ESLVal(" -> ").add(nl.apply(indent.add(new ESLVal(2))).add(ppExp.apply(indent.add(new ESLVal(2)),e))));
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(10668,10768)"));
      }
      }
    }
  });
  private static ESLVal ppCaseIntsArm = new ESLVal(new Function(new ESLVal("ppCaseIntsArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal a = $args[1];
  {ESLVal _v31 = a;
        
        switch(_v31.termName) {
        case "IArm": {ESLVal $169 = _v31.termRef(0);
          ESLVal $168 = _v31.termRef(1);
          
          {ESLVal n = $169;
          
          {ESLVal e = $168;
          
          return n.add(new ESLVal(" -> ").add(nl.apply(indent.add(new ESLVal(2))).add(ppExp.apply(indent.add(new ESLVal(2)),e))));
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(10824,10924)"));
      }
      }
    }
  });
  private static ESLVal ppCaseStrsArm = new ESLVal(new Function(new ESLVal("ppCaseStrsArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal a = $args[1];
  {ESLVal _v30 = a;
        
        switch(_v30.termName) {
        case "SArm": {ESLVal $167 = _v30.termRef(0);
          ESLVal $166 = _v30.termRef(1);
          
          {ESLVal n = $167;
          
          {ESLVal e = $166;
          
          return new ESLVal("\'").add(n.add(new ESLVal("\'").add(new ESLVal(" -> ").add(nl.apply(indent.add(new ESLVal(2))).add(ppExp.apply(indent.add(new ESLVal(2)),e))))));
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(10980,11094)"));
      }
      }
    }
  });
  private static ESLVal ppCaseBoolsArm = new ESLVal(new Function(new ESLVal("ppCaseBoolsArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal a = $args[1];
  {ESLVal _v29 = a;
        
        switch(_v29.termName) {
        case "BoolArm": {ESLVal $165 = _v29.termRef(0);
          ESLVal $164 = _v29.termRef(1);
          
          {ESLVal b = $165;
          
          {ESLVal e = $164;
          
          return b.add(new ESLVal(" -> ").add(nl.apply(indent.add(new ESLVal(2))).add(ppExp.apply(indent.add(new ESLVal(2)),e))));
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(11152,11256)"));
      }
      }
    }
  });
  private static ESLVal getImport = new ESLVal(new Function(new ESLVal("getImport"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal sourceFile = $args[0];
  {ESLVal path = toPath.apply(sourceFile);
        
        {ESLVal p = pathToJavaPackage.apply(path);
        ESLVal className = pathToJavaClassName.apply(path);
        
        {ESLVal _v28 = sourceFile;
        
        switch(_v28.strVal) {
        case "esl/lists.esl": return new ESLVal("// import static ").add(p.add(new ESLVal(".").add(className.add(new ESLVal(".*;")))));
        default: {ESLVal x = _v28;
          
          return new ESLVal("import static ").add(p.add(new ESLVal(".").add(className.add(new ESLVal(".*;")))));
        }
      }
      }
      }
      }
    }
  });
  public static ESLVal ppJModule = new ESLVal(new Function(new ESLVal("ppJModule"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal name = $args[0];
  ESLVal p = $args[1];
  ESLVal m = $args[2];
  {ESLVal _v26 = m;
        
        switch(_v26.termName) {
        case "JModule": {ESLVal $163 = _v26.termRef(0);
          ESLVal $162 = _v26.termRef(1);
          ESLVal $161 = _v26.termRef(2);
          ESLVal $160 = _v26.termRef(3);
          
          {ESLVal n = $163;
          
          {ESLVal exports = $162;
          
          {ESLVal imports = $161;
          
          {ESLVal fields = $160;
          
          return new ESLVal("package ").add(p.add(new ESLVal(";").add(nl.apply($zero).add(new ESLVal("import esl.lib.*;").add(nl.apply($zero).add(new ESLVal("import static esl.lib.Lib.*;").add(nl.apply($zero).add(ppJoin.apply($zero,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v27 = $qualArg;
                
                {ESLVal i = _v27;
                
                return ESLVal.list(ESLVal.list(getImport.apply(i)));
              }
              }
            }
          }).map(imports).flatten().flatten()).add(nl.apply($zero).add(new ESLVal("import java.util.function.Supplier;").add(nl.apply($zero).add(new ESLVal("public class ").add(name.add(new ESLVal(" {").add(nl.apply(new ESLVal(2)).add(new ESLVal("public static ESLVal getSelf() { return $null; }").add(nl.apply(new ESLVal(2)).add(ppJoin.apply(new ESLVal(2),map.apply(new ESLVal(new Function(new ESLVal("fun387"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal f = $args[0];
          return ppJModuleField.apply(new ESLVal(2),exports,f);
            }
          }),fields)).add(nl.apply($zero).add(new ESLVal("public static void main(String[] args) {").add(nl.apply(new ESLVal(2)).add(((Supplier<ESLVal>)() -> { 
            if(member.apply(new ESLVal("main"),exports).boolVal)
              return new ESLVal("  newActor(main,new ESLVal(new Actor())); ").add(nl.apply(new ESLVal(2)));
              else
                return new ESLVal("");
          }).get().add(new ESLVal("}").add(nl.apply($zero).add(new ESLVal("}"))))))))))))))))))))))))));
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(11651,12413)"));
      }
      }
    }
  });
  private static ESLVal ppJModuleField = new ESLVal(new Function(new ESLVal("ppJModuleField"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal exports = $args[1];
  ESLVal f = $args[2];
  {ESLVal _v25 = f;
        
        switch(_v25.termName) {
        case "JField": {ESLVal $159 = _v25.termRef(0);
          ESLVal $158 = _v25.termRef(1);
          ESLVal $157 = _v25.termRef(2);
          
          switch($159.strVal) {
          case "edb": switch($157.termName) {
            case "JNull": {
              {ESLVal t = $158;
              
              return new ESLVal("// static ESLVal edb = null;");
            }
            }
            default: {ESLVal n = $159;
              
              {ESLVal t = $158;
              
              {ESLVal e = $157;
              
              return ((Supplier<ESLVal>)() -> { 
                if(member.apply(n,exports).boolVal)
                  return new ESLVal("public ");
                  else
                    return new ESLVal("private ");
              }).get().add(new ESLVal("static ESLVal ").add(n.add(new ESLVal(" = ").add(ppJExp.apply(indent,ESLVal.list(),e).add(new ESLVal(";"))))));
            }
            }
            }
          }
          default: {ESLVal n = $159;
            
            {ESLVal t = $158;
            
            {ESLVal e = $157;
            
            return ((Supplier<ESLVal>)() -> { 
              if(member.apply(n,exports).boolVal)
                return new ESLVal("public ");
                else
                  return new ESLVal("private ");
            }).get().add(new ESLVal("static ESLVal ").add(n.add(new ESLVal(" = ").add(ppJExp.apply(indent,ESLVal.list(),e).add(new ESLVal(";"))))));
          }
          }
          }
        }
        }
        default: return error(new ESLVal("case error at Pos(12482,12732)"));
      }
      }
    }
  });
  private static ESLVal ppJExps = new ESLVal(new Function(new ESLVal("ppJExps"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal exps = $args[2];
  ESLVal sep = $args[3];
  {ESLVal _v24 = exps;
        
        if(_v24.isCons())
        {ESLVal $153 = _v24.head();
          ESLVal $154 = _v24.tail();
          
          if($154.isCons())
          {ESLVal $155 = $154.head();
            ESLVal $156 = $154.tail();
            
            {ESLVal e1 = $153;
            
            {ESLVal e2 = $155;
            
            {ESLVal es = $156;
            
            return ppJExp.apply(indent,dynamics,e1).add(sep.add(ppJExps.apply(indent,dynamics,es.cons(e2),sep)));
          }
          }
          }
          }
        else if($154.isNil())
          {ESLVal e = $153;
            
            return ppJExp.apply(indent,dynamics,e);
          }
        else return error(new ESLVal("case error at Pos(12802,12996)"));
        }
      else if(_v24.isNil())
        return new ESLVal("");
      else return error(new ESLVal("case error at Pos(12802,12996)"));
      }
    }
  });
  private static ESLVal ppJDecs = new ESLVal(new Function(new ESLVal("ppJDecs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal decs = $args[1];
  ESLVal sep = $args[2];
  {ESLVal _v23 = decs;
        
        if(_v23.isCons())
        {ESLVal $149 = _v23.head();
          ESLVal $150 = _v23.tail();
          
          if($150.isCons())
          {ESLVal $151 = $150.head();
            ESLVal $152 = $150.tail();
            
            {ESLVal e1 = $149;
            
            {ESLVal e2 = $151;
            
            {ESLVal es = $152;
            
            return pJDec.apply(indent,e1).add(sep.add(ppJDecs.apply(indent,es.cons(e2),sep)));
          }
          }
          }
          }
        else if($150.isNil())
          {ESLVal e = $149;
            
            return pJDec.apply(indent,e);
          }
        else return error(new ESLVal("case error at Pos(13058,13270)"));
        }
      else if(_v23.isNil())
        return new ESLVal("");
      else return error(new ESLVal("case error at Pos(13058,13270)"));
      }
    }
  });
  private static ESLVal pJDec = new ESLVal(new Function(new ESLVal("pJDec"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal d = $args[1];
  {ESLVal _v22 = d;
        
        switch(_v22.termName) {
        case "JDec": {ESLVal $148 = _v22.termRef(0);
          ESLVal $147 = _v22.termRef(1);
          
          {ESLVal n = $148;
          
          {ESLVal t = $147;
          
          return new ESLVal("ESLVal ").add(n);
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(13316,13372)"));
      }
      }
    }
  });
  private static ESLVal ppJExp = new ESLVal(new Function(new ESLVal("ppJExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal e = $args[2];
  {ESLVal _v20 = e;
        
        switch(_v20.termName) {
        case "JArrayRef": {ESLVal $146 = _v20.termRef(0);
          ESLVal $145 = _v20.termRef(1);
          
          {ESLVal a = $146;
          
          {ESLVal i = $145;
          
          return ppJExp.apply(indent,dynamics,a).add(new ESLVal(".array[").add(ppJExp.apply(indent,dynamics,i).add(new ESLVal(".intVal]"))));
        }
        }
        }
      case "JArrayUpdate": {ESLVal $144 = _v20.termRef(0);
          ESLVal $143 = _v20.termRef(1);
          ESLVal $142 = _v20.termRef(2);
          
          {ESLVal a = $144;
          
          {ESLVal i = $143;
          
          {ESLVal v = $142;
          
          return ppJExp.apply(indent,dynamics,a).add(new ESLVal(".array[").add(ppJExp.apply(indent,dynamics,i).add(new ESLVal(".intVal] = ").add(ppJExp.apply(indent,dynamics,v)))));
        }
        }
        }
        }
      case "JBecome": {ESLVal $139 = _v20.termRef(0);
          ESLVal $138 = _v20.termRef(1);
          
          if($138.isCons())
          {ESLVal $140 = $138.head();
            ESLVal $141 = $138.tail();
            
            {ESLVal _v90 = $139;
            
            {ESLVal es = $138;
            
            return new ESLVal("become(").add(ppJExp.apply(indent.add(new ESLVal(2)),dynamics,_v90).add(new ESLVal(",getSelf(),").add(ppJExps.apply(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")")))));
          }
          }
          }
        else if($138.isNil())
          {ESLVal _v91 = $139;
            
            return new ESLVal("become(").add(ppJExp.apply(indent.add(new ESLVal(2)),dynamics,_v91).add(new ESLVal(",getSelf())")));
          }
        else {ESLVal _v92 = $139;
            
            {ESLVal es = $138;
            
            return new ESLVal("become(").add(ppJExp.apply(indent.add(new ESLVal(2)),dynamics,_v92).add(new ESLVal(",getSelf(),").add(ppJExps.apply(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")")))));
          }
          }
        }
      case "JConstExp": {ESLVal $133 = _v20.termRef(0);
          
          switch($133.termName) {
          case "JConstInt": {ESLVal $137 = $133.termRef(0);
            
            switch($137.intVal) {
            case 0: return new ESLVal("$zero");
          case 1: return new ESLVal("$one");
            default: {ESLVal n = $137;
              
              return new ESLVal("new ESLVal(").add(n.add(new ESLVal(")")));
            }
          }
          }
        case "JConstBool": {ESLVal $136 = $133.termRef(0);
            
            switch($136.boolVal ? 1 : 0) {
            case 1: return new ESLVal("$true");
          case 0: return new ESLVal("$false");
            default: {ESLVal _v88 = _v20;
              
              return new ESLVal("********** unknown expression: ").add(_v88);
            }
          }
          }
        case "JConstStr": {ESLVal $135 = $133.termRef(0);
            
            {ESLVal s = $135;
            
            return new ESLVal("new ESLVal(\"").add(javaString.apply(s).add(new ESLVal("\")")));
          }
          }
        case "JConstDouble": {ESLVal $134 = $133.termRef(0);
            
            {ESLVal d = $134;
            
            return new ESLVal("new ESLVal(").add(d.add(new ESLVal(")")));
          }
          }
          default: {ESLVal _v89 = _v20;
            
            return new ESLVal("********** unknown expression: ").add(_v89);
          }
        }
        }
      case "JNot": {ESLVal $132 = _v20.termRef(0);
          
          {ESLVal _v87 = $132;
          
          return ppJExp.apply(indent,dynamics,_v87).add(new ESLVal(".not()"));
        }
        }
      case "JNil": {ESLVal $131 = _v20.termRef(0);
          
          {ESLVal t = $131;
          
          return new ESLVal("$nil");
        }
        }
      case "JList": {ESLVal $130 = _v20.termRef(0);
          ESLVal $129 = _v20.termRef(1);
          
          {ESLVal t = $130;
          
          {ESLVal es = $129;
          
          return ppJListExp.apply(indent,dynamics,t,es);
        }
        }
        }
      case "JTerm": {ESLVal $126 = _v20.termRef(0);
          ESLVal $125 = _v20.termRef(1);
          
          if($125.isCons())
          {ESLVal $127 = $125.head();
            ESLVal $128 = $125.tail();
            
            {ESLVal n = $126;
            
            {ESLVal es = $125;
            
            return new ESLVal("new ESLVal(\"").add(n.add(new ESLVal("\",").add(ppJExps.apply(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")")))));
          }
          }
          }
        else if($125.isNil())
          {ESLVal n = $126;
            
            return new ESLVal("new ESLVal(\"").add(n.add(new ESLVal("\",new ESLVal[]{})")));
          }
        else {ESLVal n = $126;
            
            {ESLVal es = $125;
            
            return new ESLVal("new ESLVal(\"").add(n.add(new ESLVal("\",").add(ppJExps.apply(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")")))));
          }
          }
        }
      case "JFun": {ESLVal $124 = _v20.termRef(0);
          ESLVal $123 = _v20.termRef(1);
          ESLVal $122 = _v20.termRef(2);
          ESLVal $121 = _v20.termRef(3);
          
          {ESLVal n = $124;
          
          {ESLVal args = $123;
          
          {ESLVal t = $122;
          
          {ESLVal body = $121;
          
          return ppJFun.apply(indent,dynamics,n,args,t,body);
        }
        }
        }
        }
        }
      case "JBinExp": {ESLVal $120 = _v20.termRef(0);
          ESLVal $119 = _v20.termRef(1);
          ESLVal $118 = _v20.termRef(2);
          
          switch($119.strVal) {
          case "==": {ESLVal e1 = $120;
            
            {ESLVal e2 = $118;
            
            return ppJExp.apply(indent,dynamics,e1).add(new ESLVal(".equals(").add(ppJExp.apply(indent,dynamics,e2).add(new ESLVal(")"))));
          }
          }
        case "cons": {ESLVal e1 = $120;
            
            {ESLVal e2 = $118;
            
            return ppJExp.apply(indent,dynamics,e2).add(new ESLVal(".cons(").add(ppJExp.apply(indent,dynamics,e1).add(new ESLVal(")"))));
          }
          }
          default: {ESLVal e1 = $120;
            
            {ESLVal op = $119;
            
            {ESLVal e2 = $118;
            
            return ppJExp.apply(indent,dynamics,e1).add(new ESLVal(".").add(op.add(new ESLVal("(").add(ppJExp.apply(indent,dynamics,e2).add(new ESLVal(")"))))));
          }
          }
          }
        }
        }
      case "JNull": {
          return new ESLVal("$null");
        }
      case "JNow": {
          return new ESLVal("now()");
        }
      case "JVar": {ESLVal $117 = _v20.termRef(0);
          ESLVal $116 = _v20.termRef(1);
          
          {ESLVal n = $117;
          
          {ESLVal t = $116;
          
          if(member.apply(n,dynamics).boolVal)
          return n.add(new ESLVal("[0]"));
          else
            {ESLVal _v85 = $117;
              
              {ESLVal _v86 = $116;
              
              return _v85;
            }
            }
        }
        }
        }
      case "JError": {ESLVal $115 = _v20.termRef(0);
          
          {ESLVal _v84 = $115;
          
          return new ESLVal("error(").add(ppJExp.apply(indent,dynamics,_v84).add(new ESLVal(")")));
        }
        }
      case "JApply": {ESLVal $114 = _v20.termRef(0);
          ESLVal $113 = _v20.termRef(1);
          
          {ESLVal _v83 = $114;
          
          {ESLVal es = $113;
          
          return ppJExp.apply(indent,dynamics,_v83).add(new ESLVal(".apply(").add(ppJExps.apply(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")"))));
        }
        }
        }
      case "JCommandExp": {ESLVal $112 = _v20.termRef(0);
          ESLVal $111 = _v20.termRef(1);
          
          {ESLVal c = $112;
          
          {ESLVal t = $111;
          
          return new ESLVal("((Supplier<ESLVal>)() -> { ").add(nl.apply(indent.add(new ESLVal(2))).add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,c).add(nl.apply(indent).add(new ESLVal("}).get()")))));
        }
        }
        }
      case "JIfExp": {ESLVal $110 = _v20.termRef(0);
          ESLVal $109 = _v20.termRef(1);
          ESLVal $108 = _v20.termRef(2);
          
          {ESLVal _v82 = $110;
          
          {ESLVal e1 = $109;
          
          {ESLVal e2 = $108;
          
          return new ESLVal("(").add(ppJExp.apply(indent,dynamics,_v82).add(new ESLVal(".boolVal) ? (").add(ppJExp.apply(indent,dynamics,e1).add(new ESLVal(") : (").add(ppJExp.apply(indent,dynamics,e2).add(new ESLVal(")")))))));
        }
        }
        }
        }
      case "JHead": {ESLVal $107 = _v20.termRef(0);
          
          {ESLVal _v81 = $107;
          
          return ppJExp.apply(indent,dynamics,_v81).add(new ESLVal(".head()"));
        }
        }
      case "JTail": {ESLVal $106 = _v20.termRef(0);
          
          {ESLVal _v80 = $106;
          
          return ppJExp.apply(indent,dynamics,_v80).add(new ESLVal(".tail()"));
        }
        }
      case "JTermRef": {ESLVal $105 = _v20.termRef(0);
          ESLVal $104 = _v20.termRef(1);
          
          {ESLVal _v79 = $105;
          
          {ESLVal n = $104;
          
          return ppJExp.apply(indent,dynamics,_v79).add(new ESLVal(".termRef(").add(n.add(new ESLVal(")"))));
        }
        }
        }
      case "JMapFun": {ESLVal $103 = _v20.termRef(0);
          ESLVal $102 = _v20.termRef(1);
          
          {ESLVal f = $103;
          
          {ESLVal l = $102;
          
          return ppJExp.apply(indent,dynamics,f).add(new ESLVal(".map(").add(ppJExp.apply(indent,dynamics,l).add(new ESLVal(")"))));
        }
        }
        }
      case "JFlatten": {ESLVal $101 = _v20.termRef(0);
          
          {ESLVal ls = $101;
          
          return ppJExp.apply(indent,dynamics,ls).add(new ESLVal(".flatten()"));
        }
        }
      case "JBehaviour": {ESLVal $96 = _v20.termRef(0);
          ESLVal $95 = _v20.termRef(1);
          ESLVal $94 = _v20.termRef(2);
          ESLVal $93 = _v20.termRef(3);
          ESLVal $92 = _v20.termRef(4);
          
          switch($93.termName) {
          case "JFun": {ESLVal $100 = $93.termRef(0);
            ESLVal $99 = $93.termRef(1);
            ESLVal $98 = $93.termRef(2);
            ESLVal $97 = $93.termRef(3);
            
            {ESLVal es = $96;
            
            {ESLVal fs = $95;
            
            {ESLVal init = $94;
            
            {ESLVal n = $100;
            
            {ESLVal args = $99;
            
            {ESLVal t = $98;
            
            {ESLVal body = $97;
            
            {ESLVal time = $92;
            
            return new ESLVal("new ESLVal(new BehaviourAdapter(").add(((Supplier<ESLVal>)() -> { 
              if(time.eql(new ESLVal("JBlock",ESLVal.list())).boolVal)
                return new ESLVal("false");
                else
                  return new ESLVal("true");
            }).get().add(new ESLVal(",getSelf(),").add(ppJExp.apply(indent,dynamics,n).add(new ESLVal(") {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJFields.apply(indent.add(new ESLVal(2)),dynamics,fs).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal handle(ESLVal $m) {").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,body).add(new ESLVal("}").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal get(String name) {").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("switch(name) {").add(nl.apply(indent.add(new ESLVal(6))).add(ppJoin.apply(indent.add(new ESLVal(6)),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v21 = $qualArg;
                  
                  {ESLVal _v77 = _v21;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("case \"").add(_v77.add(new ESLVal("\": return ").add(_v77.add(new ESLVal(";")))))));
                }
                }
              }
            }).map(es).flatten().flatten()).add(nl.apply(indent.add(new ESLVal(6))).add(new ESLVal("default: throw new Error(\"ref illegal \" + self + \".\" + name);").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("}").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("}").add(nl.apply(indent).add(new ESLVal("public void handleTime(ESLVal $t) {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,time).add(nl.apply(indent).add(new ESLVal("}").add(nl.apply(indent).add(new ESLVal("public ESLVal init() {").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("return ").add(ppJExp.apply(indent.add(new ESLVal(6)),dynamics,init).add(new ESLVal(";").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("}").add(nl.apply(indent).add(new ESLVal("})")))))))))))))))))))))))))))))))))))))));
          }
          }
          }
          }
          }
          }
          }
          }
          }
          default: {ESLVal _v78 = _v20;
            
            return new ESLVal("********** unknown expression: ").add(_v78);
          }
        }
        }
      case "JNew": {ESLVal $89 = _v20.termRef(0);
          ESLVal $88 = _v20.termRef(1);
          
          if($88.isCons())
          {ESLVal $90 = $88.head();
            ESLVal $91 = $88.tail();
            
            {ESLVal b = $89;
            
            {ESLVal args = $88;
            
            return new ESLVal("newActor(").add(ppJExp.apply(indent,dynamics,b).add(new ESLVal(",new ESLVal(new Actor()),").add(ppJExps.apply(indent,dynamics,args,new ESLVal(",")).add(new ESLVal(")")))));
          }
          }
          }
        else if($88.isNil())
          {ESLVal b = $89;
            
            return new ESLVal("newActor(").add(ppJExp.apply(indent,dynamics,b).add(new ESLVal(",new ESLVal(new Actor()))")));
          }
        else {ESLVal b = $89;
            
            {ESLVal args = $88;
            
            return new ESLVal("newActor(").add(ppJExp.apply(indent,dynamics,b).add(new ESLVal(",new ESLVal(new Actor()),").add(ppJExps.apply(indent,dynamics,args,new ESLVal(",")).add(new ESLVal(")")))));
          }
          }
        }
      case "JNewArray": {ESLVal $87 = _v20.termRef(0);
          
          {ESLVal i = $87;
          
          return new ESLVal("newArray(").add(ppJExp.apply(indent,dynamics,i).add(new ESLVal(".intVal)")));
        }
        }
      case "JNewJava": {ESLVal $84 = _v20.termRef(0);
          ESLVal $83 = _v20.termRef(1);
          
          if($83.isCons())
          {ESLVal $85 = $83.head();
            ESLVal $86 = $83.tail();
            
            {ESLVal n = $84;
            
            {ESLVal args = $83;
            
            return new ESLVal("newJavaActor(\"").add(n.add(new ESLVal("\",").add(ppJExps.apply(indent,dynamics,args,new ESLVal(",")).add(new ESLVal(")")))));
          }
          }
          }
        else if($83.isNil())
          {ESLVal n = $84;
            
            return new ESLVal("newJavaActor(\"").add(n.add(new ESLVal("\")")));
          }
        else {ESLVal n = $84;
            
            {ESLVal args = $83;
            
            return new ESLVal("newJavaActor(\"").add(n.add(new ESLVal("\",").add(ppJExps.apply(indent,dynamics,args,new ESLVal(",")).add(new ESLVal(")")))));
          }
          }
        }
      case "JSend": {ESLVal $80 = _v20.termRef(0);
          ESLVal $79 = _v20.termRef(1);
          ESLVal $78 = _v20.termRef(2);
          
          if($78.isCons())
          {ESLVal $81 = $78.head();
            ESLVal $82 = $78.tail();
            
            {ESLVal _v74 = $80;
            
            {ESLVal m = $79;
            
            {ESLVal args = $78;
            
            return new ESLVal("Lib.send(").add(ppJExp.apply(indent,dynamics,_v74).add(new ESLVal(",\"").add(m.add(new ESLVal("\",").add(ppJExps.apply(indent,dynamics,args,new ESLVal(",")).add(new ESLVal(")")))))));
          }
          }
          }
          }
        else if($78.isNil())
          {ESLVal _v75 = $80;
            
            {ESLVal m = $79;
            
            return new ESLVal("Lib.send(").add(ppJExp.apply(indent,dynamics,_v75).add(new ESLVal(",\"").add(m.add(new ESLVal("\")")))));
          }
          }
        else {ESLVal _v76 = $80;
            
            {ESLVal m = $79;
            
            {ESLVal args = $78;
            
            return new ESLVal("Lib.send(").add(ppJExp.apply(indent,dynamics,_v76).add(new ESLVal(",\"").add(m.add(new ESLVal("\",").add(ppJExps.apply(indent,dynamics,args,new ESLVal(",")).add(new ESLVal(")")))))));
          }
          }
          }
        }
      case "JSelf": {
          return new ESLVal("getSelf()");
        }
      case "JRef": {ESLVal $77 = _v20.termRef(0);
          ESLVal $76 = _v20.termRef(1);
          
          {ESLVal _v73 = $77;
          
          {ESLVal n = $76;
          
          return ppJExp.apply(indent,dynamics,_v73).add(new ESLVal(".ref(\"").add(n.add(new ESLVal("\")"))));
        }
        }
        }
      case "JGrab": {ESLVal $75 = _v20.termRef(0);
          ESLVal $74 = _v20.termRef(1);
          
          {ESLVal es = $75;
          
          {ESLVal c = $74;
          
          return new ESLVal("lock(new Function(new ESLVal(\"grab\"),getSelf()) {").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal apply(ESLVal ...args) { ").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("return ").add(ppJExp.apply(indent,dynamics,c).add(new ESLVal(";").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("}},").add(ppJExps.apply(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")")))))))))));
        }
        }
        }
      case "JTry": {ESLVal $73 = _v20.termRef(0);
          ESLVal $72 = _v20.termRef(1);
          ESLVal $71 = _v20.termRef(2);
          
          {ESLVal _v72 = $73;
          
          {ESLVal n = $72;
          
          {ESLVal c = $71;
          
          return new ESLVal("new Function(new ESLVal(\"try\"),getSelf()) {").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal apply(ESLVal... args) { ").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("try { ").add(nl.apply(indent.add(new ESLVal(6))).add(new ESLVal("return ").add(ppJExp.apply(indent.add(new ESLVal(4)),dynamics,_v72).add(new ESLVal(";").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("} catch(ESLError $exception) {").add(nl.apply(indent.add(new ESLVal(6))).add(new ESLVal("ESLVal ").add(n.add(new ESLVal(" = $exception.value;").add(nl.apply(indent.add(new ESLVal(6))).add(ppJCommand.apply(indent,dynamics,c).add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("}").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("}").add(nl.apply(indent).add(new ESLVal("}.apply()")))))))))))))))))))))));
        }
        }
        }
        }
      case "JProbably": {ESLVal $70 = _v20.termRef(0);
          ESLVal $69 = _v20.termRef(1);
          ESLVal $68 = _v20.termRef(2);
          
          {ESLVal _v71 = $70;
          
          {ESLVal e1 = $69;
          
          {ESLVal e2 = $68;
          
          return new ESLVal("probably(").add(ppJExp.apply(indent,dynamics,_v71).add(new ESLVal(",").add(ppJExp.apply(indent,dynamics,probFun.apply(e1)).add(new ESLVal(",").add(ppJExp.apply(indent,dynamics,probFun.apply(e2)).add(new ESLVal(")")))))));
        }
        }
        }
        }
        default: {ESLVal _v93 = _v20;
          
          return new ESLVal("********** unknown expression: ").add(_v93);
        }
      }
      }
    }
  });
  private static ESLVal probFun = new ESLVal(new Function(new ESLVal("probFun"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  return new ESLVal("JFun",new ESLVal("JConstExp",new ESLVal("JConstStr",new ESLVal("probFun"))),ESLVal.list(),$null,new ESLVal("JReturn",e));
    }
  });
  private static ESLVal ppJFun = new ESLVal(new Function(new ESLVal("ppJFun"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal n = $args[2];
  ESLVal args = $args[3];
  ESLVal t = $args[4];
  ESLVal body = $args[5];
  {ESLVal freeDynamics = dynamicVarsJCommand.apply(body);
        ESLVal argNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v16 = $qualArg;
                
                switch(_v16.termName) {
                case "JDec": {ESLVal $65 = _v16.termRef(0);
                  ESLVal $64 = _v16.termRef(1);
                  
                  {ESLVal _v67 = $65;
                  
                  {ESLVal _v68 = $64;
                  
                  return ESLVal.list(ESLVal.list(_v67));
                }
                }
                }
                default: {ESLVal _0 = _v16;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(args).flatten().flatten();
        
        {ESLVal boundDynamics = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v17 = $qualArg;
                
                {ESLVal d = _v17;
                
                return ESLVal.list((member.apply(d,freeDynamics).boolVal) ? (ESLVal.list(d)) : ($nil));
              }
              }
            }
          }).map(argNames).flatten().flatten();
        
        {ESLVal dom = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v18 = $qualArg;
                
                switch(_v18.termName) {
                case "JDec": {ESLVal $67 = _v18.termRef(0);
                  ESLVal $66 = _v18.termRef(1);
                  
                  {ESLVal _v69 = $67;
                  
                  {ESLVal _v70 = $66;
                  
                  return ESLVal.list(ESLVal.list(_v70));
                }
                }
                }
                default: {ESLVal _0 = _v18;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(args).flatten().flatten();
        ESLVal ran = t;
        
        return new ESLVal("new ESLVal(new Function(").add(ppJExp.apply(indent,dynamics,n).add(new ESLVal(",getSelf()) {").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal apply(ESLVal... $args) {").add(nl.apply(indent.add(new ESLVal(4))).add(ppFunArgs.apply(indent,$zero,args,boundDynamics).add(ppJCommand.apply(indent.add(new ESLVal(4)),boundDynamics.add(new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v19 = $qualArg;
              
              {ESLVal d = _v19;
              
              return ESLVal.list((member.apply(d,argNames).not().boolVal) ? (ESLVal.list(d)) : ($nil));
            }
            }
          }
        }).map(dynamics).flatten().flatten()),body).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("}").add(nl.apply(indent).add(new ESLVal("})"))))))))))));
      }
      }
      }
    }
  });
  private static ESLVal ppFunArgs = new ESLVal(new Function(new ESLVal("ppFunArgs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal i = $args[1];
  ESLVal args = $args[2];
  ESLVal dynamicArgs = $args[3];
  {ESLVal _v15 = args;
        
        if(_v15.isCons())
        {ESLVal $60 = _v15.head();
          ESLVal $61 = _v15.tail();
          
          switch($60.termName) {
          case "JDec": {ESLVal $63 = $60.termRef(0);
            ESLVal $62 = $60.termRef(1);
            
            {ESLVal n = $63;
            
            {ESLVal t = $62;
            
            {ESLVal _v63 = $61;
            
            if(member.apply(n,dynamicArgs).boolVal)
            return new ESLVal("ESLVal[] ").add(n.add(new ESLVal(" = new ESLVal[]{$args[").add(i.add(new ESLVal("]};").add(nl.apply(indent).add(ppFunArgs.apply(indent,i.add($one),_v63,dynamicArgs)))))));
            else
              {ESLVal _v64 = $63;
                
                {ESLVal _v65 = $62;
                
                {ESLVal _v66 = $61;
                
                return new ESLVal("ESLVal ").add(_v64.add(new ESLVal(" = $args[").add(i.add(new ESLVal("];").add(nl.apply(indent).add(ppFunArgs.apply(indent,i.add($one),_v66,dynamicArgs)))))));
              }
              }
              }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(20264,20658)"));
        }
        }
      else if(_v15.isNil())
        return new ESLVal("");
      else return error(new ESLVal("case error at Pos(20264,20658)"));
      }
    }
  });
  private static ESLVal ppJCommand = new ESLVal(new Function(new ESLVal("ppJCommand"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal c = $args[2];
  {ESLVal _v6 = c;
        
        switch(_v6.termName) {
        case "JIfCommand": {ESLVal $41 = _v6.termRef(0);
          ESLVal $40 = _v6.termRef(1);
          ESLVal $39 = _v6.termRef(2);
          
          {ESLVal e = $41;
          
          {ESLVal c1 = $40;
          
          {ESLVal c2 = $39;
          
          return new ESLVal("if(").add(ppJExp.apply(indent,dynamics,e).add(new ESLVal(".boolVal)").add(nl.apply(indent.add(new ESLVal(2))).add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,c1).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("else").add(nl.apply(indent.add(new ESLVal(4))).add(ppJCommand.apply(indent.add(new ESLVal(4)),dynamics,c2)))))))));
        }
        }
        }
        }
      case "JReturn": {ESLVal $36 = _v6.termRef(0);
          
          switch($36.termName) {
          case "JCommandExp": {ESLVal $38 = $36.termRef(0);
            ESLVal $37 = $36.termRef(1);
            
            {ESLVal _v61 = $38;
            
            {ESLVal t = $37;
            
            return ppJCommand.apply(indent,dynamics,_v61);
          }
          }
          }
          default: {ESLVal e = $36;
            
            return new ESLVal("return ").add(ppJExp.apply(indent.add(new ESLVal(2)),dynamics,e).add(new ESLVal(";")));
          }
        }
        }
      case "JCaseList": {ESLVal $35 = _v6.termRef(0);
          ESLVal $34 = _v6.termRef(1);
          ESLVal $33 = _v6.termRef(2);
          ESLVal $32 = _v6.termRef(3);
          
          {ESLVal l = $35;
          
          {ESLVal cons = $34;
          
          {ESLVal nil = $33;
          
          {ESLVal alt = $32;
          
          return new ESLVal("if(").add(ppJExp.apply(indent,dynamics,l).add(new ESLVal(".isCons())").add(nl.apply(indent.add(new ESLVal(2))).add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,cons).add(nl.apply(indent).add(new ESLVal("else if(").add(ppJExp.apply(indent,dynamics,l).add(new ESLVal(".isNil())").add(nl.apply(indent.add(new ESLVal(2))).add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,nil).add(nl.apply(indent).add(new ESLVal("else ").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,alt))))))))))))));
        }
        }
        }
        }
        }
      case "JCaseTerm": {ESLVal $31 = _v6.termRef(0);
          ESLVal $30 = _v6.termRef(1);
          ESLVal $29 = _v6.termRef(2);
          
          {ESLVal e = $31;
          
          {ESLVal arms = $30;
          
          {ESLVal alt = $29;
          
          return new ESLVal("switch(").add(ppJExp.apply(indent,dynamics,e).add(new ESLVal(".termName) {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v14 = $qualArg;
                
                switch(_v14.termName) {
                case "JTArm": {ESLVal $59 = _v14.termRef(0);
                  ESLVal $58 = _v14.termRef(1);
                  ESLVal $57 = _v14.termRef(2);
                  
                  {ESLVal n = $59;
                  
                  {ESLVal i = $58;
                  
                  {ESLVal _v60 = $57;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("case \"").add(n.add(new ESLVal("\": ").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,_v60))))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v14;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten()).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("default: ").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,alt).add(nl.apply(indent).add(new ESLVal("}"))))))))));
        }
        }
        }
        }
      case "JCaseInt": {ESLVal $28 = _v6.termRef(0);
          ESLVal $27 = _v6.termRef(1);
          ESLVal $26 = _v6.termRef(2);
          
          {ESLVal e = $28;
          
          {ESLVal arms = $27;
          
          {ESLVal alt = $26;
          
          return new ESLVal("switch(").add(ppJExp.apply(indent,dynamics,e).add(new ESLVal(".intVal) {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v13 = $qualArg;
                
                switch(_v13.termName) {
                case "JIArm": {ESLVal $56 = _v13.termRef(0);
                  ESLVal $55 = _v13.termRef(1);
                  
                  {ESLVal n = $56;
                  
                  {ESLVal _v59 = $55;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("case ").add(n.add(new ESLVal(": ").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,_v59))))));
                }
                }
                }
                default: {ESLVal _0 = _v13;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten()).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("default: ").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,alt).add(nl.apply(indent).add(new ESLVal("}"))))))))));
        }
        }
        }
        }
      case "JCaseStr": {ESLVal $25 = _v6.termRef(0);
          ESLVal $24 = _v6.termRef(1);
          ESLVal $23 = _v6.termRef(2);
          
          {ESLVal e = $25;
          
          {ESLVal arms = $24;
          
          {ESLVal alt = $23;
          
          return new ESLVal("switch(").add(ppJExp.apply(indent,dynamics,e).add(new ESLVal(".strVal) {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v12 = $qualArg;
                
                switch(_v12.termName) {
                case "JSArm": {ESLVal $54 = _v12.termRef(0);
                  ESLVal $53 = _v12.termRef(1);
                  
                  {ESLVal s = $54;
                  
                  {ESLVal _v58 = $53;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("case \"").add(s.add(new ESLVal("\": ").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,_v58))))));
                }
                }
                }
                default: {ESLVal _0 = _v12;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten()).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("default: ").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,alt).add(nl.apply(indent).add(new ESLVal("}"))))))))));
        }
        }
        }
        }
      case "JCaseBool": {ESLVal $22 = _v6.termRef(0);
          ESLVal $21 = _v6.termRef(1);
          ESLVal $20 = _v6.termRef(2);
          
          {ESLVal e = $22;
          
          {ESLVal arms = $21;
          
          {ESLVal alt = $20;
          
          return new ESLVal("switch(").add(ppJExp.apply(indent,dynamics,e).add(new ESLVal(".boolVal ? 1 : 0) {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJoin.apply(indent,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v11 = $qualArg;
                
                switch(_v11.termName) {
                case "JBArm": {ESLVal $52 = _v11.termRef(0);
                  ESLVal $51 = _v11.termRef(1);
                  
                  {ESLVal b = $52;
                  
                  {ESLVal _v57 = $51;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("case ").add(((Supplier<ESLVal>)() -> { 
                    if(b.boolVal)
                      return $one;
                      else
                        return $zero;
                  }).get().add(new ESLVal(": ").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,_v57))))));
                }
                }
                }
                default: {ESLVal _0 = _v11;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten()).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("default: ").add(ppJCommand.apply(indent.add(new ESLVal(2)),dynamics,alt).add(nl.apply(indent).add(new ESLVal("}"))))))))));
        }
        }
        }
        }
      case "JLet": {ESLVal $19 = _v6.termRef(0);
          ESLVal $18 = _v6.termRef(1);
          
          {ESLVal bs = $19;
          
          {ESLVal _v56 = $18;
          
          {ESLVal boundVars = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v10 = $qualArg;
                  
                  switch(_v10.termName) {
                  case "JField": {ESLVal $50 = _v10.termRef(0);
                    ESLVal $49 = _v10.termRef(1);
                    ESLVal $48 = _v10.termRef(2);
                    
                    {ESLVal n = $50;
                    
                    {ESLVal t = $49;
                    
                    {ESLVal e = $48;
                    
                    return ESLVal.list(ESLVal.list(n));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v10;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(bs).flatten().flatten();
          ESLVal dynamicVars = dynamicVarsJCommand.apply(_v56);
          
          {ESLVal boundDynamicVars = filter.apply(new ESLVal(new Function(new ESLVal("fun388"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal s = $args[0];
            return member.apply(s,dynamicVars);
              }
            }),boundVars);
          
          return new ESLVal("{").add(ppJFields.apply(indent.add(new ESLVal(2)),dynamics.add(boundDynamicVars),bs).add(nl.apply(indent.add(new ESLVal(2))).add(ppJCommand.apply(indent,dynamics.add(boundDynamicVars),_v56).add(nl.apply(indent).add(new ESLVal("}"))))));
        }
        }
        }
        }
        }
      case "JLetRec": {ESLVal $17 = _v6.termRef(0);
          ESLVal $16 = _v6.termRef(1);
          
          {ESLVal bs = $17;
          
          {ESLVal _v55 = $16;
          
          return new ESLVal("LetRec letrec = new LetRec() {").add(nl.apply(indent.add(new ESLVal(2))).add(ppJFields.apply(indent.add(new ESLVal(2)),dynamics,bs).add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("public ESLVal get(String name) {").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("switch(name) {").add(nl.apply(indent.add(new ESLVal(6))).add(ppJoin.apply(indent.add(new ESLVal(6)),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v8 = $qualArg;
                
                switch(_v8.termName) {
                case "JField": {ESLVal $44 = _v8.termRef(0);
                  ESLVal $43 = _v8.termRef(1);
                  ESLVal $42 = _v8.termRef(2);
                  
                  {ESLVal n = $44;
                  
                  {ESLVal t = $43;
                  
                  {ESLVal e = $42;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("case \"").add(n.add(new ESLVal("\": return ").add(n.add(new ESLVal(";").add(nl.apply(indent.add(new ESLVal(6))))))))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v8;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(bs).flatten().flatten()).add(nl.apply(indent.add(new ESLVal(6))).add(new ESLVal("default: throw new Error(\"cannot find letrec binding\");").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("}").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("}").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("};").add(nl.apply(indent).add(ppJoin.apply(indent,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v9 = $qualArg;
                
                switch(_v9.termName) {
                case "JField": {ESLVal $47 = _v9.termRef(0);
                  ESLVal $46 = _v9.termRef(1);
                  ESLVal $45 = _v9.termRef(2);
                  
                  {ESLVal n = $47;
                  
                  {ESLVal t = $46;
                  
                  {ESLVal e = $45;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("ESLVal ").add(n.add(new ESLVal(" = letrec.get(\"").add(n.add(new ESLVal("\");").add(nl.apply(indent))))))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v9;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(bs).flatten().flatten()).add(nl.apply(indent.add(new ESLVal(2))).add(ppJCommand.apply(indent,dynamics,_v55).add(nl.apply(indent))))))))))))))))))))));
        }
        }
        }
      case "JBlock": {ESLVal $15 = _v6.termRef(0);
          
          {ESLVal cs = $15;
          
          return new ESLVal("{").add(ppJoin.apply(indent,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v7 = $qualArg;
                
                {ESLVal _v54 = _v7;
                
                return ESLVal.list(ESLVal.list(ppJCommand.apply(indent,dynamics,_v54)));
              }
              }
            }
          }).map(cs).flatten().flatten()).add(new ESLVal("}")));
        }
        }
      case "JUpdate": {ESLVal $14 = _v6.termRef(0);
          ESLVal $13 = _v6.termRef(1);
          
          {ESLVal n = $14;
          
          {ESLVal e = $13;
          
          if(member.apply(n,dynamics).boolVal)
          return n.add(new ESLVal("[0] = ").add(ppJExp.apply(indent,dynamics,e).add(new ESLVal(";"))));
          else
            {ESLVal _v52 = $14;
              
              {ESLVal _v53 = $13;
              
              return _v52.add(new ESLVal(" = ").add(ppJExp.apply(indent,dynamics,_v53).add(new ESLVal(";"))));
            }
            }
        }
        }
        }
      case "JFor": {ESLVal $12 = _v6.termRef(0);
          ESLVal $11 = _v6.termRef(1);
          ESLVal $10 = _v6.termRef(2);
          ESLVal $9 = _v6.termRef(3);
          
          {ESLVal listName = $12;
          
          {ESLVal varName = $11;
          
          {ESLVal e = $10;
          
          {ESLVal _v51 = $9;
          
          return new ESLVal("{").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("ESLVal ").add(listName.add(new ESLVal(" = ").add(ppJExp.apply(indent.add(new ESLVal(2)),dynamics,e).add(new ESLVal(";").add(nl.apply(indent.add(new ESLVal(2))).add(new ESLVal("while(").add(listName.add(new ESLVal(".isCons()) {").add(nl.apply(indent.add(new ESLVal(4))).add(new ESLVal("ESLVal ").add(varName.add(new ESLVal(" = ").add(listName.add(new ESLVal(".headVal;").add(nl.apply(indent.add(new ESLVal(4))).add(ppJCommand.apply(indent.add(new ESLVal(4)),dynamics,_v51).add(nl.apply(indent.add(new ESLVal(4))).add(listName.add(new ESLVal(" = ").add(listName.add(new ESLVal(".tailVal;").add(new ESLVal("}").add(nl.apply(indent).add(new ESLVal("}")))))))))))))))))))))))))));
        }
        }
        }
        }
        }
      case "JStatement": {ESLVal $8 = _v6.termRef(0);
          
          {ESLVal e = $8;
          
          return ppJExp.apply(indent,dynamics,e).add(new ESLVal(";"));
        }
        }
        default: {ESLVal _v62 = _v6;
          
          return new ESLVal("******* unknown command: ").add(_v62);
        }
      }
      }
    }
  });
  private static ESLVal ppJFields = new ESLVal(new Function(new ESLVal("ppJFields"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal bs = $args[2];
  {ESLVal _v5 = bs;
        
        if(_v5.isCons())
        {ESLVal $6 = _v5.head();
          ESLVal $7 = _v5.tail();
          
          {ESLVal f = $6;
          
          {ESLVal _v50 = $7;
          
          return ppFieldDef.apply(indent,dynamics,f).add(nl.apply(indent).add(ppJFields.apply(indent,dynamics,_v50)));
        }
        }
        }
      else if(_v5.isNil())
        return new ESLVal("");
      else return error(new ESLVal("case error at Pos(25182,25332)"));
      }
    }
  });
  private static ESLVal ppFieldDef = new ESLVal(new Function(new ESLVal("ppFieldDef"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal f = $args[2];
  {ESLVal _v4 = f;
        
        switch(_v4.termName) {
        case "JField": {ESLVal $5 = _v4.termRef(0);
          ESLVal $4 = _v4.termRef(1);
          ESLVal $3 = _v4.termRef(2);
          
          {ESLVal n = $5;
          
          {ESLVal t = $4;
          
          {ESLVal e = $3;
          
          if(member.apply(n,dynamics).boolVal)
          return new ESLVal("ESLVal[] ").add(n.add(new ESLVal(" = new ESLVal[]{").add(ppJExp.apply(indent.add(new ESLVal(2)),dynamics,e).add(new ESLVal("};")))));
          else
            {ESLVal _v47 = $5;
              
              {ESLVal _v48 = $4;
              
              {ESLVal _v49 = $3;
              
              return new ESLVal("ESLVal ").add(_v47.add(new ESLVal(" = ").add(ppJExp.apply(indent.add(new ESLVal(2)),dynamics,_v49).add(new ESLVal(";")))));
            }
            }
            }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(25396,25650)"));
      }
      }
    }
  });
  private static ESLVal ppJTerm = new ESLVal(new Function(new ESLVal("ppJTerm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal n = $args[2];
  ESLVal es = $args[3];
  {ESLVal _v3 = es;
        
        if(_v3.isCons())
        {ESLVal $1 = _v3.head();
          ESLVal $2 = _v3.tail();
          
          {ESLVal _v45 = _v3;
          
          return new ESLVal("new Term(\"").add(n.add(new ESLVal("\",").add(ppJExps.apply(indent,dynamics,_v45,new ESLVal(",")).add(new ESLVal(")")))));
        }
        }
      else if(_v3.isNil())
        return new ESLVal("new Term(\"").add(n.add(new ESLVal("\")")));
      else {ESLVal _v46 = _v3;
          
          return new ESLVal("new Term(\"").add(n.add(new ESLVal("\",").add(ppJExps.apply(indent,dynamics,_v46,new ESLVal(",")).add(new ESLVal(")")))));
        }
      }
    }
  });
  private static ESLVal ppJListExp = new ESLVal(new Function(new ESLVal("ppJListExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal indent = $args[0];
  ESLVal dynamics = $args[1];
  ESLVal t = $args[2];
  ESLVal es = $args[3];
  return new ESLVal("ESLVal.list(").add(ppJExps.apply(indent,dynamics,es,new ESLVal(",")).add(new ESLVal(")")));
    }
  });
  public static ESLVal main = new ESLVal(new Function(new ESLVal("main"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      return new ESLVal(new BehaviourAdapter(true,getSelf(),new ESLVal("main")) {
          
          public ESLVal handle(ESLVal $m) {{ESLVal _v2 = $m;
            
            return error(new ESLVal("case error at Pos(0,0)"));
          }}
          public ESLVal get(String name) {
            switch(name) {
              
              default: throw new Error("ref illegal " + self + "." + name);
            }
          }
        public void handleTime(ESLVal $t) {
          {ESLVal t = $t;
            
            if($true.boolVal)
            {new Function(new ESLVal("try"),getSelf()) {
              public ESLVal apply(ESLVal... args) { 
                try { 
                  return print.apply(ppExp.apply($zero,parse.apply(new ESLVal("esl/compiler/test1.esl"))));
                } catch(ESLError $exception) {
                  ESLVal $x = $exception.value;
                  {ESLVal _v1 = $x;
              
              {ESLVal message = _v1;
              
              return print.apply(new ESLVal("PP Error: ").add(message));
            }
            }
                }
              }
            }.apply();
            print.apply(new ESLVal("DONE"));
            stopAll.apply();}
            else
              {}
          }
        }
        public ESLVal init() {
            return $null;
          }
        });
    }
  });
public static void main(String[] args) {
    newActor(main,new ESLVal(new Actor())); 
  }
}