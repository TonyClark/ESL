package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
import static esl.compiler.Types.*;
// import static esl.Lists.*;
import java.util.function.Supplier;
public class DynamicVars {
  public static ESLVal getSelf() { return $null; }
  private static ESLVal decName = new ESLVal(new Function(new ESLVal("decName"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d = $args[0];
  {ESLVal _v633 = d;
        
        switch(_v633.termName) {
        case "JDec": {ESLVal $1173 = _v633.termRef(0);
          ESLVal $1172 = _v633.termRef(1);
          
          {ESLVal n = $1173;
          
          {ESLVal t = $1172;
          
          return n;
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(156,201)"));
      }
      }
    }
  });
  private static ESLVal fieldName = new ESLVal(new Function(new ESLVal("fieldName"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d = $args[0];
  {ESLVal _v632 = d;
        
        switch(_v632.termName) {
        case "JField": {ESLVal $1171 = _v632.termRef(0);
          ESLVal $1170 = _v632.termRef(1);
          ESLVal $1169 = _v632.termRef(2);
          
          {ESLVal n = $1171;
          
          {ESLVal t = $1170;
          
          {ESLVal e = $1169;
          
          return n;
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(236,290)"));
      }
      }
    }
  });
  private static ESLVal fieldJExp = new ESLVal(new Function(new ESLVal("fieldJExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d = $args[0];
  {ESLVal _v631 = d;
        
        switch(_v631.termName) {
        case "JField": {ESLVal $1168 = _v631.termRef(0);
          ESLVal $1167 = _v631.termRef(1);
          ESLVal $1166 = _v631.termRef(2);
          
          {ESLVal n = $1168;
          
          {ESLVal t = $1167;
          
          {ESLVal e = $1166;
          
          return e;
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(326,380)"));
      }
      }
    }
  });
  public static ESLVal dynamicVarsJModule = new ESLVal(new Function(new ESLVal("dynamicVarsJModule"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal m = $args[0];
  {ESLVal _v628 = m;
        
        switch(_v628.termName) {
        case "JModule": {ESLVal $1162 = _v628.termRef(0);
          ESLVal $1161 = _v628.termRef(1);
          ESLVal $1160 = _v628.termRef(2);
          ESLVal $1159 = _v628.termRef(3);
          
          {ESLVal n = $1162;
          
          {ESLVal exports = $1161;
          
          {ESLVal imports = $1160;
          
          {ESLVal fs = $1159;
          
          {{
          ESLVal _v629 = fs;
          while(_v629.isCons()) {
            ESLVal f = _v629.headVal;
            ((Supplier<ESLVal>)() -> { 
              {ESLVal _v630 = f;
                
                switch(_v630.termName) {
                case "JField": {ESLVal $1165 = _v630.termRef(0);
                  ESLVal $1164 = _v630.termRef(1);
                  ESLVal $1163 = _v630.termRef(2);
                  
                  {ESLVal name = $1165;
                  
                  {ESLVal t = $1164;
                  
                  {ESLVal e = $1163;
                  
                  return dynamicVarsJExp.apply(e);
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(540,638)"));
              }
              }
            }).get();
            _v629 = _v629.tailVal;}
        }
        return $null;}
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(420,650)"));
      }
      }
    }
  });
  public static ESLVal dynamicVarsJExp = new ESLVal(new Function(new ESLVal("dynamicVarsJExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal x = $args[0];
  {ESLVal _v627 = x;
        
        switch(_v627.termName) {
        case "JArrayRef": {ESLVal $1158 = _v627.termRef(0);
          ESLVal $1157 = _v627.termRef(1);
          
          {ESLVal a = $1158;
          
          {ESLVal i = $1157;
          
          return dynamicVarsJExp.apply(a).add(dynamicVarsJExp.apply(i));
        }
        }
        }
      case "JArrayUpdate": {ESLVal $1156 = _v627.termRef(0);
          ESLVal $1155 = _v627.termRef(1);
          ESLVal $1154 = _v627.termRef(2);
          
          {ESLVal a = $1156;
          
          {ESLVal i = $1155;
          
          {ESLVal v = $1154;
          
          return dynamicVarsJExp.apply(a).add(dynamicVarsJExp.apply(i).add(dynamicVarsJExp.apply(v)));
        }
        }
        }
        }
      case "JBecome": {ESLVal $1153 = _v627.termRef(0);
          ESLVal $1152 = _v627.termRef(1);
          
          {ESLVal e = $1153;
          
          {ESLVal es = $1152;
          
          return dynamicVarsJExp.apply(e).add(flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun1540"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v634 = $args[0];
          return dynamicVarsJExp.apply(_v634);
            }
          }),es)));
        }
        }
        }
      case "JFun": {ESLVal $1151 = _v627.termRef(0);
          ESLVal $1150 = _v627.termRef(1);
          ESLVal $1149 = _v627.termRef(2);
          ESLVal $1148 = _v627.termRef(3);
          
          {ESLVal v0 = $1151;
          
          {ESLVal v1 = $1150;
          
          {ESLVal v2 = $1149;
          
          {ESLVal v3 = $1148;
          
          return reject.apply(new ESLVal(new Function(new ESLVal("fun1541"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal n = $args[0];
          return member.apply(n,map.apply(decName,v1));
            }
          }),dynamicVarsJCommand.apply(v3));
        }
        }
        }
        }
        }
      case "JApply": {ESLVal $1147 = _v627.termRef(0);
          ESLVal $1146 = _v627.termRef(1);
          
          {ESLVal v0 = $1147;
          
          {ESLVal v1 = $1146;
          
          return dynamicVarsJExp.apply(v0).add(flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun1542"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal e = $args[0];
          return dynamicVarsJExp.apply(e);
            }
          }),v1)));
        }
        }
        }
      case "JBinExp": {ESLVal $1145 = _v627.termRef(0);
          ESLVal $1144 = _v627.termRef(1);
          ESLVal $1143 = _v627.termRef(2);
          
          {ESLVal v0 = $1145;
          
          {ESLVal v1 = $1144;
          
          {ESLVal v2 = $1143;
          
          return dynamicVarsJExp.apply(v0).add(dynamicVarsJExp.apply(v2));
        }
        }
        }
        }
      case "JCommandExp": {ESLVal $1142 = _v627.termRef(0);
          ESLVal $1141 = _v627.termRef(1);
          
          {ESLVal v0 = $1142;
          
          {ESLVal v1 = $1141;
          
          return dynamicVarsJCommand.apply(v0);
        }
        }
        }
      case "JIfExp": {ESLVal $1140 = _v627.termRef(0);
          ESLVal $1139 = _v627.termRef(1);
          ESLVal $1138 = _v627.termRef(2);
          
          {ESLVal v0 = $1140;
          
          {ESLVal v1 = $1139;
          
          {ESLVal v2 = $1138;
          
          return dynamicVarsJExp.apply(v0).add(dynamicVarsJExp.apply(v1).add(dynamicVarsJExp.apply(v2)));
        }
        }
        }
        }
      case "JConstExp": {ESLVal $1137 = _v627.termRef(0);
          
          {ESLVal v0 = $1137;
          
          return ESLVal.list();
        }
        }
      case "JTerm": {ESLVal $1136 = _v627.termRef(0);
          ESLVal $1135 = _v627.termRef(1);
          
          {ESLVal v0 = $1136;
          
          {ESLVal v1 = $1135;
          
          return flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun1543"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal e = $args[0];
          return dynamicVarsJExp.apply(e);
            }
          }),v1));
        }
        }
        }
      case "JTermRef": {ESLVal $1134 = _v627.termRef(0);
          ESLVal $1133 = _v627.termRef(1);
          
          {ESLVal v0 = $1134;
          
          {ESLVal v1 = $1133;
          
          return dynamicVarsJExp.apply(v0);
        }
        }
        }
      case "JList": {ESLVal $1132 = _v627.termRef(0);
          ESLVal $1131 = _v627.termRef(1);
          
          {ESLVal v0 = $1132;
          
          {ESLVal v1 = $1131;
          
          return flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun1544"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal e = $args[0];
          return dynamicVarsJExp.apply(e);
            }
          }),v1));
        }
        }
        }
      case "JNil": {ESLVal $1130 = _v627.termRef(0);
          
          {ESLVal v0 = $1130;
          
          return ESLVal.list();
        }
        }
      case "JVar": {ESLVal $1129 = _v627.termRef(0);
          ESLVal $1128 = _v627.termRef(1);
          
          {ESLVal v0 = $1129;
          
          {ESLVal v1 = $1128;
          
          return ESLVal.list();
        }
        }
        }
      case "JNull": {
          return ESLVal.list();
        }
      case "JNow": {
          return ESLVal.list();
        }
      case "JError": {ESLVal $1127 = _v627.termRef(0);
          
          {ESLVal v0 = $1127;
          
          return dynamicVarsJExp.apply(v0);
        }
        }
      case "JHead": {ESLVal $1126 = _v627.termRef(0);
          
          {ESLVal v0 = $1126;
          
          return dynamicVarsJExp.apply(v0);
        }
        }
      case "JTail": {ESLVal $1125 = _v627.termRef(0);
          
          {ESLVal v0 = $1125;
          
          return dynamicVarsJExp.apply(v0);
        }
        }
      case "JMapFun": {ESLVal $1124 = _v627.termRef(0);
          ESLVal $1123 = _v627.termRef(1);
          
          {ESLVal v0 = $1124;
          
          {ESLVal v1 = $1123;
          
          return dynamicVarsJExp.apply(v0).add(dynamicVarsJExp.apply(v1));
        }
        }
        }
      case "JFlatten": {ESLVal $1122 = _v627.termRef(0);
          
          {ESLVal v0 = $1122;
          
          return dynamicVarsJExp.apply(v0);
        }
        }
      case "JNot": {ESLVal $1121 = _v627.termRef(0);
          
          {ESLVal v0 = $1121;
          
          return dynamicVarsJExp.apply(v0);
        }
        }
      case "JBehaviour": {ESLVal $1120 = _v627.termRef(0);
          ESLVal $1119 = _v627.termRef(1);
          ESLVal $1118 = _v627.termRef(2);
          ESLVal $1117 = _v627.termRef(3);
          ESLVal $1116 = _v627.termRef(4);
          
          {ESLVal v0 = $1120;
          
          {ESLVal v1 = $1119;
          
          {ESLVal v2 = $1118;
          
          {ESLVal v3 = $1117;
          
          {ESLVal v4 = $1116;
          
          return flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun1545"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal d = $args[0];
          return dynamicVarsJFieldDef.apply(d);
            }
          }),v1)).add(dynamicVarsJExp.apply(v2).add(dynamicVarsJExp.apply(v3).add(dynamicVarsJCommand.apply(v4))));
        }
        }
        }
        }
        }
        }
      case "JNew": {ESLVal $1115 = _v627.termRef(0);
          ESLVal $1114 = _v627.termRef(1);
          
          {ESLVal v0 = $1115;
          
          {ESLVal v1 = $1114;
          
          return dynamicVarsJExp.apply(v0).add(flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun1546"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal e = $args[0];
          return dynamicVarsJExp.apply(e);
            }
          }),v1)));
        }
        }
        }
      case "JNewArray": {ESLVal $1113 = _v627.termRef(0);
          
          {ESLVal v0 = $1113;
          
          return dynamicVarsJExp.apply(v0);
        }
        }
      case "JNewJava": {ESLVal $1112 = _v627.termRef(0);
          ESLVal $1111 = _v627.termRef(1);
          
          {ESLVal v0 = $1112;
          
          {ESLVal v1 = $1111;
          
          return flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun1547"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal e = $args[0];
          return dynamicVarsJExp.apply(e);
            }
          }),v1));
        }
        }
        }
      case "JSend": {ESLVal $1110 = _v627.termRef(0);
          ESLVal $1109 = _v627.termRef(1);
          ESLVal $1108 = _v627.termRef(2);
          
          {ESLVal v0 = $1110;
          
          {ESLVal v1 = $1109;
          
          {ESLVal v2 = $1108;
          
          return dynamicVarsJExp.apply(v0).add(flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun1548"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal e = $args[0];
          return dynamicVarsJExp.apply(e);
            }
          }),v2)));
        }
        }
        }
        }
      case "JSelf": {
          return ESLVal.list();
        }
      case "JTry": {ESLVal $1107 = _v627.termRef(0);
          ESLVal $1106 = _v627.termRef(1);
          ESLVal $1105 = _v627.termRef(2);
          
          {ESLVal e = $1107;
          
          {ESLVal n = $1106;
          
          {ESLVal c = $1105;
          
          return dynamicVarsJExp.apply(e).add(dynamicVarsJCommand.apply(c));
        }
        }
        }
        }
      case "JRef": {ESLVal $1104 = _v627.termRef(0);
          ESLVal $1103 = _v627.termRef(1);
          
          {ESLVal v0 = $1104;
          
          {ESLVal v1 = $1103;
          
          return dynamicVarsJExp.apply(v0);
        }
        }
        }
      case "JGrab": {ESLVal $1102 = _v627.termRef(0);
          ESLVal $1101 = _v627.termRef(1);
          
          {ESLVal v0 = $1102;
          
          {ESLVal v1 = $1101;
          
          return flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun1549"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal e = $args[0];
          return dynamicVarsJExp.apply(e);
            }
          }),v0)).add(dynamicVarsJExp.apply(v1));
        }
        }
        }
      case "JProbably": {ESLVal $1100 = _v627.termRef(0);
          ESLVal $1099 = _v627.termRef(1);
          ESLVal $1098 = _v627.termRef(2);
          
          {ESLVal v0 = $1100;
          
          {ESLVal v1 = $1099;
          
          {ESLVal v2 = $1098;
          
          return dynamicVarsJExp.apply(v0).add(dynamicVarsJExp.apply(v1).add(dynamicVarsJExp.apply(v2)));
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(726,3400)"));
      }
      }
    }
  });
  private static ESLVal dynamicVarsJFieldDef = new ESLVal(new Function(new ESLVal("dynamicVarsJFieldDef"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d = $args[0];
  {ESLVal _v626 = d;
        
        switch(_v626.termName) {
        case "JField": {ESLVal $1097 = _v626.termRef(0);
          ESLVal $1096 = _v626.termRef(1);
          ESLVal $1095 = _v626.termRef(2);
          
          {ESLVal n = $1097;
          
          {ESLVal t = $1096;
          
          {ESLVal e = $1095;
          
          return dynamicVarsJExp.apply(e);
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(3450,3521)"));
      }
      }
    }
  });
  private static ESLVal dynamicVarsJTermArm = new ESLVal(new Function(new ESLVal("dynamicVarsJTermArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v625 = t;
        
        switch(_v625.termName) {
        case "JTArm": {ESLVal $1094 = _v625.termRef(0);
          ESLVal $1093 = _v625.termRef(1);
          ESLVal $1092 = _v625.termRef(2);
          
          {ESLVal n = $1094;
          
          {ESLVal i = $1093;
          
          {ESLVal c = $1092;
          
          return dynamicVarsJCommand.apply(c);
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(3568,3644)"));
      }
      }
    }
  });
  private static ESLVal dynamicVarsJIntArm = new ESLVal(new Function(new ESLVal("dynamicVarsJIntArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v624 = t;
        
        switch(_v624.termName) {
        case "JIArm": {ESLVal $1091 = _v624.termRef(0);
          ESLVal $1090 = _v624.termRef(1);
          
          {ESLVal i = $1091;
          
          {ESLVal c = $1090;
          
          return dynamicVarsJCommand.apply(c);
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(3689,3758)"));
      }
      }
    }
  });
  private static ESLVal dynamicVarsJStrArm = new ESLVal(new Function(new ESLVal("dynamicVarsJStrArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v623 = t;
        
        switch(_v623.termName) {
        case "JSArm": {ESLVal $1089 = _v623.termRef(0);
          ESLVal $1088 = _v623.termRef(1);
          
          {ESLVal s = $1089;
          
          {ESLVal c = $1088;
          
          return dynamicVarsJCommand.apply(c);
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(3803,3872)"));
      }
      }
    }
  });
  private static ESLVal dynamicVarsJBoolArm = new ESLVal(new Function(new ESLVal("dynamicVarsJBoolArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v622 = t;
        
        switch(_v622.termName) {
        case "JBArm": {ESLVal $1087 = _v622.termRef(0);
          ESLVal $1086 = _v622.termRef(1);
          
          {ESLVal b = $1087;
          
          {ESLVal c = $1086;
          
          return dynamicVarsJCommand.apply(c);
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(3919,3990)"));
      }
      }
    }
  });
  public static ESLVal dynamicVarsJCommand = new ESLVal(new Function(new ESLVal("dynamicVarsJCommand"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal x = $args[0];
  {ESLVal _v621 = x;
        
        switch(_v621.termName) {
        case "JBlock": {ESLVal $1085 = _v621.termRef(0);
          
          {ESLVal v0 = $1085;
          
          return flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun1550"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal e = $args[0];
          return dynamicVarsJCommand.apply(e);
            }
          }),v0));
        }
        }
      case "JReturn": {ESLVal $1084 = _v621.termRef(0);
          
          {ESLVal v0 = $1084;
          
          return dynamicVarsJExp.apply(v0);
        }
        }
      case "JIfCommand": {ESLVal $1083 = _v621.termRef(0);
          ESLVal $1082 = _v621.termRef(1);
          ESLVal $1081 = _v621.termRef(2);
          
          {ESLVal v0 = $1083;
          
          {ESLVal v1 = $1082;
          
          {ESLVal v2 = $1081;
          
          return dynamicVarsJExp.apply(v0).add(dynamicVarsJCommand.apply(v1).add(dynamicVarsJCommand.apply(v2)));
        }
        }
        }
        }
      case "JCaseList": {ESLVal $1080 = _v621.termRef(0);
          ESLVal $1079 = _v621.termRef(1);
          ESLVal $1078 = _v621.termRef(2);
          ESLVal $1077 = _v621.termRef(3);
          
          {ESLVal v0 = $1080;
          
          {ESLVal v1 = $1079;
          
          {ESLVal v2 = $1078;
          
          {ESLVal v3 = $1077;
          
          return dynamicVarsJExp.apply(v0).add(dynamicVarsJCommand.apply(v1).add(dynamicVarsJCommand.apply(v2).add(dynamicVarsJCommand.apply(v3))));
        }
        }
        }
        }
        }
      case "JCaseTerm": {ESLVal $1076 = _v621.termRef(0);
          ESLVal $1075 = _v621.termRef(1);
          ESLVal $1074 = _v621.termRef(2);
          
          {ESLVal v0 = $1076;
          
          {ESLVal v1 = $1075;
          
          {ESLVal v2 = $1074;
          
          return dynamicVarsJExp.apply(v0).add(flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun1551"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal t = $args[0];
          return dynamicVarsJTermArm.apply(t);
            }
          }),v1)).add(dynamicVarsJCommand.apply(v2)));
        }
        }
        }
        }
      case "JCaseInt": {ESLVal $1073 = _v621.termRef(0);
          ESLVal $1072 = _v621.termRef(1);
          ESLVal $1071 = _v621.termRef(2);
          
          {ESLVal v0 = $1073;
          
          {ESLVal v1 = $1072;
          
          {ESLVal v2 = $1071;
          
          return dynamicVarsJExp.apply(v0).add(flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun1552"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal t = $args[0];
          return dynamicVarsJIntArm.apply(t);
            }
          }),v1)).add(dynamicVarsJCommand.apply(v2)));
        }
        }
        }
        }
      case "JCaseStr": {ESLVal $1070 = _v621.termRef(0);
          ESLVal $1069 = _v621.termRef(1);
          ESLVal $1068 = _v621.termRef(2);
          
          {ESLVal v0 = $1070;
          
          {ESLVal v1 = $1069;
          
          {ESLVal v2 = $1068;
          
          return dynamicVarsJExp.apply(v0).add(flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun1553"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal t = $args[0];
          return dynamicVarsJStrArm.apply(t);
            }
          }),v1)).add(dynamicVarsJCommand.apply(v2)));
        }
        }
        }
        }
      case "JCaseBool": {ESLVal $1067 = _v621.termRef(0);
          ESLVal $1066 = _v621.termRef(1);
          ESLVal $1065 = _v621.termRef(2);
          
          {ESLVal v0 = $1067;
          
          {ESLVal v1 = $1066;
          
          {ESLVal v2 = $1065;
          
          return dynamicVarsJExp.apply(v0).add(flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun1554"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal t = $args[0];
          return dynamicVarsJBoolArm.apply(t);
            }
          }),v1)).add(dynamicVarsJCommand.apply(v2)));
        }
        }
        }
        }
      case "JLet": {ESLVal $1064 = _v621.termRef(0);
          ESLVal $1063 = _v621.termRef(1);
          
          {ESLVal v0 = $1064;
          
          {ESLVal v1 = $1063;
          
          return flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun1555"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal f = $args[0];
          return dynamicVarsJExp.apply(fieldJExp.apply(f));
            }
          }),v0)).add(reject.apply(new ESLVal(new Function(new ESLVal("fun1556"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal n = $args[0];
          return member.apply(n,map.apply(fieldName,v0));
            }
          }),dynamicVarsJCommand.apply(v1)));
        }
        }
        }
      case "JLetRec": {ESLVal $1062 = _v621.termRef(0);
          ESLVal $1061 = _v621.termRef(1);
          
          {ESLVal v0 = $1062;
          
          {ESLVal v1 = $1061;
          
          return reject.apply(new ESLVal(new Function(new ESLVal("fun1557"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal n = $args[0];
          return member.apply(n,map.apply(fieldName,v0));
            }
          }),flatten.apply(map.apply(new ESLVal(new Function(new ESLVal("fun1558"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal f = $args[0];
          return dynamicVarsJExp.apply(fieldJExp.apply(f));
            }
          }),v0)).add(dynamicVarsJCommand.apply(v1)));
        }
        }
        }
      case "JUpdate": {ESLVal $1060 = _v621.termRef(0);
          ESLVal $1059 = _v621.termRef(1);
          
          {ESLVal v0 = $1060;
          
          {ESLVal v1 = $1059;
          
          return ESLVal.list(v0).add(dynamicVarsJExp.apply(v1));
        }
        }
        }
      case "JStatement": {ESLVal $1058 = _v621.termRef(0);
          
          {ESLVal v0 = $1058;
          
          return dynamicVarsJExp.apply(v0);
        }
        }
      case "JFor": {ESLVal $1057 = _v621.termRef(0);
          ESLVal $1056 = _v621.termRef(1);
          ESLVal $1055 = _v621.termRef(2);
          ESLVal $1054 = _v621.termRef(3);
          
          {ESLVal listName = $1057;
          
          {ESLVal v0 = $1056;
          
          {ESLVal v1 = $1055;
          
          {ESLVal v2 = $1054;
          
          return ESLVal.list(listName).add(dynamicVarsJExp.apply(v1).add(dynamicVarsJCommand.apply(v2)));
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(4080,6007)"));
      }
      }
    }
  });
public static void main(String[] args) {
  }
}