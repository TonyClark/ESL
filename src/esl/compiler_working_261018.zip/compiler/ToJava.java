package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
import static esl.Tables.*;
// import static esl.Lists.*;
import static esl.compiler.Cases.*;
import static esl.compiler.Types.*;
import java.util.function.Supplier;
public class ToJava {
  public static ESLVal getSelf() { return $null; }
  private static ESLVal defToField = new ESLVal(new Function(new ESLVal("defToField"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d = $args[0];
  {ESLVal _v57 = d;
        
        switch(_v57.termName) {
        case "Binding": {ESLVal $461 = _v57.termRef(0);
          ESLVal $460 = _v57.termRef(1);
          ESLVal $459 = _v57.termRef(2);
          ESLVal $458 = _v57.termRef(3);
          ESLVal $457 = _v57.termRef(4);
          
          {ESLVal l = $461;
          
          {ESLVal n = $460;
           
          {ESLVal t = $459;
          
          {ESLVal st = $458;
          
          {ESLVal e = $457;
          
          return new ESLVal("JField",n,$null,expToJExp.apply(e));
        }
        }
        }
        }
        }
        }
      case "FunBind": {ESLVal $454 = _v57.termRef(0);
          ESLVal $453 = _v57.termRef(1);
          ESLVal $452 = _v57.termRef(2);
          ESLVal $451 = _v57.termRef(3);
          ESLVal $450 = _v57.termRef(4);
          ESLVal $449 = _v57.termRef(5);
          ESLVal $448 = _v57.termRef(6);
          
          switch($448.termName) {
          case "BoolExp": {ESLVal $456 = $448.termRef(0);
            ESLVal $455 = $448.termRef(1);
            
            switch($455.boolVal ? 1 : 0) {
            case 1: {ESLVal l = $454;
              
              {ESLVal n = $453;
              
              {ESLVal args = $452;
              
              {ESLVal t = $451;
              
              {ESLVal st = $450;
              
              {ESLVal e = $449;
              
              {ESLVal bl = $456;
              
              {ESLVal formals = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal $qualArg = $args[0];
                {ESLVal _v58 = $qualArg;
                      
                      switch(_v58.termName) {
                      case "PVar": {ESLVal $464 = _v58.termRef(0);
                        ESLVal $463 = _v58.termRef(1);
                        ESLVal $462 = _v58.termRef(2);
                        
                        {ESLVal _v132 = $464;
                        
                        {ESLVal _v133 = $463;
                        
                        {ESLVal _v134 = $462;
                        
                        return ESLVal.list(ESLVal.list(new ESLVal("Dec",_v132,_v133,_v134,st)));
                      }
                      }
                      }
                      }
                      default: {ESLVal _0 = _v58;
                        
                        return ESLVal.list();
                      }
                    }
                    }
                  }
                }).map(args).flatten().flatten();
              
              return new ESLVal("JField",n,$null,expToJExp.apply(new ESLVal("FunExp",l,new ESLVal("StrExp",l,n),formals,t,e)));
            }
            }
            }
            }
            }
            }
            }
            }
            default: {ESLVal l = $454;
              
              {ESLVal n = $453;
              
              {ESLVal args = $452;
              
              {ESLVal t = $451;
              
              {ESLVal st = $450;
              
              {ESLVal e = $449;
              
              {ESLVal g = $448;
              
              {ESLVal formals = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal $qualArg = $args[0];
                {ESLVal _v59 = $qualArg;
                      
                      switch(_v59.termName) {
                      case "PVar": {ESLVal $467 = _v59.termRef(0);
                        ESLVal $466 = _v59.termRef(1);
                        ESLVal $465 = _v59.termRef(2);
                        
                        {ESLVal _v135 = $467;
                        
                        {ESLVal _v136 = $466;
                        
                        {ESLVal _v137 = $465;
                        
                        return ESLVal.list(ESLVal.list(new ESLVal("Dec",_v135,_v136,_v137,st)));
                      }
                      }
                      }
                      }
                      default: {ESLVal _0 = _v59;
                        
                        return ESLVal.list();
                      }
                    }
                    }
                  }
                }).map(args).flatten().flatten();
              
              return new ESLVal("JField",n,$null,expToJExp.apply(new ESLVal("FunExp",l,new ESLVal("StrExp",l,n),formals,t,new ESLVal("If",l,g,e,new ESLVal("Throw",l,t,new ESLVal("StrExp",l,new ESLVal("guard failed for ").add(n)))))));
            }
            }
            }
            }
            }
            }
            }
            }
          }
          }
          default: {ESLVal l = $454;
            
            {ESLVal n = $453;
            
            {ESLVal args = $452;
            
            {ESLVal t = $451;
            
            {ESLVal st = $450;
            
            {ESLVal e = $449;
            
            {ESLVal g = $448;
            
            {ESLVal formals = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v60 = $qualArg;
                    
                    switch(_v60.termName) {
                    case "PVar": {ESLVal $470 = _v60.termRef(0);
                      ESLVal $469 = _v60.termRef(1);
                      ESLVal $468 = _v60.termRef(2);
                      
                      {ESLVal _v138 = $470;
                      
                      {ESLVal _v139 = $469;
                      
                      {ESLVal _v140 = $468;
                      
                      return ESLVal.list(ESLVal.list(new ESLVal("Dec",_v138,_v139,_v140,st)));
                    }
                    }
                    }
                    }
                    default: {ESLVal _0 = _v60;
                      
                      return ESLVal.list();
                    }
                  }
                  }
                }
              }).map(args).flatten().flatten();
            
            return new ESLVal("JField",n,$null,expToJExp.apply(new ESLVal("FunExp",l,new ESLVal("StrExp",l,n),formals,t,new ESLVal("If",l,g,e,new ESLVal("Throw",l,t,new ESLVal("StrExp",l,new ESLVal("guard failed for ").add(n)))))));
          }
          }
          }
          }
          }
          }
          }
          }
        }
        }
        default: return error(new ESLVal("case error at Pos(172,826)"));
      }
      }
    }
  });
  private static ESLVal decToJDec = new ESLVal(new Function(new ESLVal("decToJDec"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d = $args[0];
  {ESLVal _v56 = d;
        
        switch(_v56.termName) {
        case "Dec": {ESLVal $447 = _v56.termRef(0);
          ESLVal $446 = _v56.termRef(1);
          ESLVal $445 = _v56.termRef(2);
          ESLVal $444 = _v56.termRef(3);
          
          {ESLVal l = $447;
          
          {ESLVal n = $446;
          
          {ESLVal t = $445;
          
          {ESLVal st = $444;
          
          return new ESLVal("JDec",n,$null);
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(870,946)"));
      }
      }
    }
  });
  private static ESLVal expsToJCommands = new ESLVal(new Function(new ESLVal("expsToJCommands"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal cs = $args[0];
  ESLVal isLast = $args[1];
  {ESLVal _v55 = cs;
        
        if(_v55.isCons())
        {ESLVal $440 = _v55.head();
          ESLVal $441 = _v55.tail();
          
          if($441.isCons())
          {ESLVal $442 = $441.head();
            ESLVal $443 = $441.tail();
            
            {ESLVal c = $440;
            
            {ESLVal _v130 = $441;
            
            return expsToJCommands.apply(_v130,isLast).cons(expToJCommand.apply(c,$false));
          }
          }
          }
        else if($441.isNil())
          {ESLVal c = $440;
            
            return ESLVal.list(expToJCommand.apply(c,isLast));
          }
        else {ESLVal c = $440;
            
            {ESLVal _v131 = $441;
            
            return expsToJCommands.apply(_v131,isLast).cons(expToJCommand.apply(c,$false));
          }
          }
        }
      else if(_v55.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(1005,1165)"));
      }
    }
  });
  private static ESLVal expToJCommand = new ESLVal(new Function(new ESLVal("expToJCommand"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal c = $args[0];
  ESLVal isLast = $args[1];
  {ESLVal _v49 = c;
        
        switch(_v49.termName) {
        case "Block": {ESLVal $435 = _v49.termRef(0);
          ESLVal $434 = _v49.termRef(1);
          
          if($434.isCons())
          {ESLVal $436 = $434.head();
            ESLVal $437 = $434.tail();
            
            if($437.isCons())
            {ESLVal $438 = $437.head();
              ESLVal $439 = $437.tail();
              
              {ESLVal l = $435;
              
              {ESLVal es = $434;
              
              return new ESLVal("JBlock",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v52 = $qualArg;
                    
                    {ESLVal e = _v52;
                    
                    return ESLVal.list(ESLVal.list(expToJCommand.apply(e,$false)));
                  }
                  }
                }
              }).map(butlast.apply(es)).flatten().flatten().add(ESLVal.list(expToJCommand.apply(last.apply(es),isLast))));
            }
            }
            }
          else if($437.isNil())
            {ESLVal l = $435;
              
              {ESLVal e = $436;
              
              return expToJCommand.apply(e,isLast);
            }
            }
          else {ESLVal l = $435;
              
              {ESLVal es = $434;
              
              return new ESLVal("JBlock",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v53 = $qualArg;
                    
                    {ESLVal e = _v53;
                    
                    return ESLVal.list(ESLVal.list(expToJCommand.apply(e,$false)));
                  }
                  }
                }
              }).map(butlast.apply(es)).flatten().flatten().add(ESLVal.list(expToJCommand.apply(last.apply(es),isLast))));
            }
            }
          }
        else if($434.isNil())
          {ESLVal l = $435;
            
            if(isLast.boolVal)
            return new ESLVal("JReturn",new ESLVal("JNull",new ESLVal[]{}));
            else
              {ESLVal _v128 = $435;
                
                return new ESLVal("JBlock",$nil);
              }
          }
        else {ESLVal l = $435;
            
            {ESLVal es = $434;
            
            return new ESLVal("JBlock",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v54 = $qualArg;
                  
                  {ESLVal e = _v54;
                  
                  return ESLVal.list(ESLVal.list(expToJCommand.apply(e,$false)));
                }
                }
              }
            }).map(butlast.apply(es)).flatten().flatten().add(ESLVal.list(expToJCommand.apply(last.apply(es),isLast))));
          }
          }
        }
      case "Update": {ESLVal $433 = _v49.termRef(0);
          ESLVal $432 = _v49.termRef(1);
          ESLVal $431 = _v49.termRef(2);
          
          {ESLVal l = $433;
          
          {ESLVal n = $432;
          
          {ESLVal e = $431;
          
          if(isLast.boolVal)
          return new ESLVal("JBlock",ESLVal.list(new ESLVal("JUpdate",n,expToJExp.apply(e)),new ESLVal("JReturn",new ESLVal("JNull",new ESLVal[]{}))));
          else
            {ESLVal _v125 = $433;
              
              {ESLVal _v126 = $432;
              
              {ESLVal _v127 = $431;
              
              return new ESLVal("JUpdate",_v126,expToJExp.apply(_v127));
            }
            }
            }
        }
        }
        }
        }
      case "If": {ESLVal $430 = _v49.termRef(0);
          ESLVal $429 = _v49.termRef(1);
          ESLVal $428 = _v49.termRef(2);
          ESLVal $427 = _v49.termRef(3);
          
          {ESLVal l = $430;
          
          {ESLVal e1 = $429;
          
          {ESLVal e2 = $428;
          
          {ESLVal e3 = $427;
          
          return new ESLVal("JIfCommand",expToJExp.apply(e1),expToJCommand.apply(e2,isLast),expToJCommand.apply(e3,isLast));
        }
        }
        }
        }
        }
      case "CaseList": {ESLVal $426 = _v49.termRef(0);
          ESLVal $425 = _v49.termRef(1);
          ESLVal $424 = _v49.termRef(2);
          ESLVal $423 = _v49.termRef(3);
          ESLVal $422 = _v49.termRef(4);
          
          {ESLVal l = $426;
          
          {ESLVal e = $425;
          
          {ESLVal cons = $424;
          
          {ESLVal nil = $423;
          
          {ESLVal alt = $422;
          
          return new ESLVal("JCaseList",expToJExp.apply(e),expToJCommand.apply(cons,isLast),expToJCommand.apply(nil,isLast),expToJCommand.apply(alt,isLast));
        }
        }
        }
        }
        }
        }
      case "CaseTerm": {ESLVal $421 = _v49.termRef(0);
          ESLVal $420 = _v49.termRef(1);
          ESLVal $419 = _v49.termRef(2);
          ESLVal $418 = _v49.termRef(3);
          
          {ESLVal l = $421;
          
          {ESLVal e = $420;
          
          {ESLVal arms = $419;
          
          {ESLVal alt = $418;
          
          return new ESLVal("JCaseTerm",expToJExp.apply(e),termArmsToJTermArms.apply(arms,isLast),expToJCommand.apply(alt,isLast));
        }
        }
        }
        }
        }
      case "CaseInt": {ESLVal $417 = _v49.termRef(0);
          ESLVal $416 = _v49.termRef(1);
          ESLVal $415 = _v49.termRef(2);
          ESLVal $414 = _v49.termRef(3);
          
          {ESLVal l = $417;
          
          {ESLVal e = $416;
          
          {ESLVal arms = $415;
          
          {ESLVal alt = $414;
          
          return new ESLVal("JCaseInt",expToJExp.apply(e),intArmsToJIntArms.apply(arms,isLast),expToJCommand.apply(alt,isLast));
        }
        }
        }
        }
        }
      case "CaseStr": {ESLVal $413 = _v49.termRef(0);
          ESLVal $412 = _v49.termRef(1);
          ESLVal $411 = _v49.termRef(2);
          ESLVal $410 = _v49.termRef(3);
          
          {ESLVal l = $413;
          
          {ESLVal e = $412;
          
          {ESLVal arms = $411;
          
          {ESLVal alt = $410;
          
          return new ESLVal("JCaseStr",expToJExp.apply(e),strArmsToJStrArms.apply(arms,isLast),expToJCommand.apply(alt,isLast));
        }
        }
        }
        }
        }
      case "CaseBool": {ESLVal $409 = _v49.termRef(0);
          ESLVal $408 = _v49.termRef(1);
          ESLVal $407 = _v49.termRef(2);
          ESLVal $406 = _v49.termRef(3);
          
          {ESLVal l = $409;
          
          {ESLVal e = $408;
          
          {ESLVal arms = $407;
          
          {ESLVal alt = $406;
          
          return new ESLVal("JCaseBool",expToJExp.apply(e),boolArmsToJBoolArms.apply(arms,isLast),expToJCommand.apply(alt,isLast));
        }
        }
        }
        }
        }
      case "Let": {ESLVal $405 = _v49.termRef(0);
          ESLVal $404 = _v49.termRef(1);
          ESLVal $403 = _v49.termRef(2);
          
          {ESLVal l = $405;
          
          {ESLVal bs = $404;
          
          {ESLVal e = $403;
          
          return new ESLVal("JLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v51 = $qualArg;
                
                {ESLVal b = _v51;
                
                return ESLVal.list(ESLVal.list(defToField.apply(b)));
              }
              }
            }
          }).map(bs).flatten().flatten(),expToJCommand.apply(e,isLast));
        }
        }
        }
        }
      case "Letrec": {ESLVal $402 = _v49.termRef(0);
          ESLVal $401 = _v49.termRef(1);
          ESLVal $400 = _v49.termRef(2);
          
          {ESLVal l = $402;
          
          {ESLVal bs = $401;
          
          {ESLVal e = $400;
          
          return new ESLVal("JLetRec",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v50 = $qualArg;
                
                {ESLVal b = _v50;
                
                return ESLVal.list(ESLVal.list(defToField.apply(b)));
              }
              }
            }
          }).map(bs).flatten().flatten(),expToJCommand.apply(e,$true));
        }
        }
        }
        }
      case "For": {ESLVal $396 = _v49.termRef(0);
          ESLVal $395 = _v49.termRef(1);
          ESLVal $394 = _v49.termRef(2);
          ESLVal $393 = _v49.termRef(3);
          
          switch($395.termName) {
          case "PVar": {ESLVal $399 = $395.termRef(0);
            ESLVal $398 = $395.termRef(1);
            ESLVal $397 = $395.termRef(2);
            
            {ESLVal l1 = $396;
            
            {ESLVal l2 = $399;
            
            {ESLVal n = $398;
            
            {ESLVal t = $397;
            
            {ESLVal e = $394;
            
            {ESLVal b = $393;
            
            if(isLast.boolVal)
            return new ESLVal("JBlock",ESLVal.list(new ESLVal("JFor",newName.apply(),n,expToJExp.apply(e),expToJCommand.apply(b,$false)),new ESLVal("JReturn",new ESLVal("JNull",new ESLVal[]{}))));
            else
              {ESLVal _v119 = $396;
                
                {ESLVal _v120 = $399;
                
                {ESLVal _v121 = $398;
                
                {ESLVal _v122 = $397;
                
                {ESLVal _v123 = $394;
                
                {ESLVal _v124 = $393;
                
                return new ESLVal("JFor",newName.apply(),_v121,expToJExp.apply(_v123),expToJCommand.apply(_v124,$false));
              }
              }
              }
              }
              }
              }
          }
          }
          }
          }
          }
          }
          }
          default: {ESLVal l = $396;
            
            {ESLVal p = $395;
            
            {ESLVal e = $394;
            
            {ESLVal b = $393;
            
            {ESLVal opName = newName.apply();
            ESLVal varName = newName.apply();
            
            return expToJCommand.apply(new ESLVal("For",l,new ESLVal("PVar",l,varName,$null),e,new ESLVal("Let",l,ESLVal.list(new ESLVal("Binding",l,opName,$null,$null,new ESLVal("FunExp",l,new ESLVal("StrExp",l,new ESLVal("forp")),ESLVal.list(),$null,new ESLVal("Case",l,$nil,ESLVal.list(new ESLVal("Var",l,varName)),ESLVal.list(new ESLVal("BArm",l,ESLVal.list(p),new ESLVal("BoolExp",l,$true),b),new ESLVal("BArm",l,ESLVal.list(new ESLVal("PVar",l,new ESLVal("$$$"),$null)),new ESLVal("BoolExp",l,$true),new ESLVal("Block",l,ESLVal.list()))))))),new ESLVal("Apply",l,new ESLVal("Var",l,opName),ESLVal.list()))),isLast);
          }
          }
          }
          }
          }
        }
        }
        default: {ESLVal e = _v49;
          
          if(isLast.boolVal)
          return new ESLVal("JReturn",expToJExp.apply(e));
          else
            {ESLVal _v129 = _v49;
              
              return new ESLVal("JStatement",expToJExp.apply(_v129));
            }
        }
      }
      }
    }
  });
  private static ESLVal expsToJExps = new ESLVal(new Function(new ESLVal("expsToJExps"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal es = $args[0];
  return map.apply(new ESLVal(new Function(new ESLVal("fun1022"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal e = $args[0];
        return expToJExp.apply(e);
          }
        }),es);
    }
  });
  private static ESLVal termArmsToJTermArms = new ESLVal(new Function(new ESLVal("termArmsToJTermArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  ESLVal isLast = $args[1];
  {ESLVal _v48 = arms;
        
        if(_v48.isCons())
        {ESLVal $389 = _v48.head();
          ESLVal $390 = _v48.tail();
          
          switch($389.termName) {
          case "TArm": {ESLVal $392 = $389.termRef(0);
            ESLVal $391 = $389.termRef(1);
            
            {ESLVal n = $392;
            
            {ESLVal e = $391;
            
            {ESLVal _v118 = $390;
            
            return termArmsToJTermArms.apply(_v118,isLast).cons(new ESLVal("JTArm",n,$zero,expToJCommand.apply(e,isLast)));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(3703,3872)"));
        }
        }
      else if(_v48.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(3703,3872)"));
      }
    }
  });
  private static ESLVal intArmsToJIntArms = new ESLVal(new Function(new ESLVal("intArmsToJIntArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  ESLVal isLast = $args[1];
  {ESLVal _v47 = arms;
        
        if(_v47.isCons())
        {ESLVal $385 = _v47.head();
          ESLVal $386 = _v47.tail();
          
          switch($385.termName) {
          case "IArm": {ESLVal $388 = $385.termRef(0);
            ESLVal $387 = $385.termRef(1);
            
            {ESLVal n = $388;
            
            {ESLVal e = $387;
            
            {ESLVal _v117 = $386;
            
            return intArmsToJIntArms.apply(_v117,isLast).cons(new ESLVal("JIArm",n,expToJCommand.apply(e,isLast)));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(3941,4105)"));
        }
        }
      else if(_v47.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(3941,4105)"));
      }
    }
  });
  private static ESLVal strArmsToJStrArms = new ESLVal(new Function(new ESLVal("strArmsToJStrArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  ESLVal isLast = $args[1];
  {ESLVal _v46 = arms;
        
        if(_v46.isCons())
        {ESLVal $381 = _v46.head();
          ESLVal $382 = _v46.tail();
          
          switch($381.termName) {
          case "SArm": {ESLVal $384 = $381.termRef(0);
            ESLVal $383 = $381.termRef(1);
            
            {ESLVal s = $384;
            
            {ESLVal e = $383;
            
            {ESLVal _v116 = $382;
            
            return strArmsToJStrArms.apply(_v116,isLast).cons(new ESLVal("JSArm",s,expToJCommand.apply(e,isLast)));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(4174,4338)"));
        }
        }
      else if(_v46.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(4174,4338)"));
      }
    }
  });
  private static ESLVal boolArmsToJBoolArms = new ESLVal(new Function(new ESLVal("boolArmsToJBoolArms"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  ESLVal isLast = $args[1];
  {ESLVal _v45 = arms;
        
        if(_v45.isCons())
        {ESLVal $377 = _v45.head();
          ESLVal $378 = _v45.tail();
          
          switch($377.termName) {
          case "BoolArm": {ESLVal $380 = $377.termRef(0);
            ESLVal $379 = $377.termRef(1);
            
            {ESLVal b = $380;
            
            {ESLVal e = $379;
            
            {ESLVal _v115 = $378;
            
            return boolArmsToJBoolArms.apply(_v115,isLast).cons(new ESLVal("JBArm",b,expToJCommand.apply(e,isLast)));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(4413,4586)"));
        }
        }
      else if(_v45.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(4413,4586)"));
      }
    }
  });
  private static ESLVal opToJOp = new ESLVal(new Function(new ESLVal("opToJOp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal op = $args[0];
  {ESLVal _v44 = op;
        
        switch(_v44.strVal) {
        case "+": return new ESLVal("add");
      case "-": return new ESLVal("sub");
      case "*": return new ESLVal("mul");
      case "/": return new ESLVal("div");
      case "%": return new ESLVal("mod");
      case ">": return new ESLVal("gre");
      case ">=": return new ESLVal("greql");
      case "<": return new ESLVal("less");
      case "<=": return new ESLVal("lesseql");
      case "=": return new ESLVal("eql");
      case "<>": return new ESLVal("neql");
      case ":": return new ESLVal("cons");
      case "..": return new ESLVal("to");
      case "or": return new ESLVal("or");
      case "and": return new ESLVal("and");
      case "andalso": return new ESLVal("andalso");
      case "orelse": return new ESLVal("orelse");
        default: return error(new ESLVal("case error at Pos(4614,4966)"));
      }
      }
    }
  });
  private static ESLVal caseToJExp = new ESLVal(new Function(new ESLVal("caseToJExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal es = $args[1];
  ESLVal arms = $args[2];
  {ESLVal bindings = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v41 = $qualArg;
                
                {ESLVal e = _v41;
                
                return ESLVal.list(ESLVal.list(new ESLVal("Binding",l,newName.apply(),$null,$null,e)));
              }
              }
            }
          }).map(es).flatten().flatten();
        
        {ESLVal names = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v42 = $qualArg;
                
                switch(_v42.termName) {
                case "Binding": {ESLVal $376 = _v42.termRef(0);
                  ESLVal $375 = _v42.termRef(1);
                  ESLVal $374 = _v42.termRef(2);
                  ESLVal $373 = _v42.termRef(3);
                  ESLVal $372 = _v42.termRef(4);
                  
                  {ESLVal _v114 = $376;
                  
                  {ESLVal n = $375;
                  
                  {ESLVal dt = $374;
                  
                  {ESLVal t = $373;
                  
                  {ESLVal e = $372;
                  
                  return ESLVal.list(ESLVal.list(n));
                }
                }
                }
                }
                }
                }
                default: {ESLVal _0 = _v42;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(bindings).flatten().flatten();
        
        return expToJExp.apply(new ESLVal("Let",l,bindings,translateCases.apply(new ESLVal("Case",l,ESLVal.list(),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v43 = $qualArg;
              
              {ESLVal n = _v43;
              
              return ESLVal.list(ESLVal.list(new ESLVal("Var",l,n)));
            }
            }
          }
        }).map(names).flatten().flatten(),arms))));
      }
      }
    }
  });
  private static ESLVal expToJExp = new ESLVal(new Function(new ESLVal("expToJExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  {ESLVal _v39 = e;
        
        switch(_v39.termName) {
        case "ArrayUpdate": {ESLVal $371 = _v39.termRef(0);
          ESLVal $370 = _v39.termRef(1);
          ESLVal $369 = _v39.termRef(2);
          ESLVal $368 = _v39.termRef(3);
          
          {ESLVal l = $371;
          
          {ESLVal a = $370;
          
          {ESLVal i = $369;
          
          {ESLVal v = $368;
          
          return new ESLVal("JArrayUpdate",expToJExp.apply(a),expToJExp.apply(i),expToJExp.apply(v));
        }
        }
        }
        }
        }
      case "ArrayRef": {ESLVal $367 = _v39.termRef(0);
          ESLVal $366 = _v39.termRef(1);
          ESLVal $365 = _v39.termRef(2);
          
          {ESLVal l = $367;
          
          {ESLVal a = $366;
          
          {ESLVal i = $365;
          
          return new ESLVal("JArrayRef",expToJExp.apply(a),expToJExp.apply(i));
        }
        }
        }
        }
      case "IntExp": {ESLVal $364 = _v39.termRef(0);
          ESLVal $363 = _v39.termRef(1);
          
          {ESLVal l = $364;
          
          {ESLVal n = $363;
          
          return new ESLVal("JConstExp",new ESLVal("JConstInt",n));
        }
        }
        }
      case "StrExp": {ESLVal $362 = _v39.termRef(0);
          ESLVal $361 = _v39.termRef(1);
          
          {ESLVal l = $362;
          
          {ESLVal s = $361;
          
          return new ESLVal("JConstExp",new ESLVal("JConstStr",s));
        }
        }
        }
      case "BoolExp": {ESLVal $360 = _v39.termRef(0);
          ESLVal $359 = _v39.termRef(1);
          
          {ESLVal l = $360;
          
          {ESLVal b = $359;
          
          return new ESLVal("JConstExp",new ESLVal("JConstBool",b));
        }
        }
        }
      case "FloatExp": {ESLVal $358 = _v39.termRef(0);
          ESLVal $357 = _v39.termRef(1);
          
          {ESLVal l = $358;
          
          {ESLVal f = $357;
          
          return new ESLVal("JConstExp",new ESLVal("JConstDouble",f));
        }
        }
        }
      case "ApplyTypeExp": {ESLVal $343 = _v39.termRef(0);
          ESLVal $342 = _v39.termRef(1);
          ESLVal $341 = _v39.termRef(2);
          
          switch($342.termName) {
          case "List": {ESLVal $350 = $342.termRef(0);
            ESLVal $349 = $342.termRef(1);
            
            if($349.isCons())
            {ESLVal $351 = $349.head();
              ESLVal $352 = $349.tail();
              
              {ESLVal l = $343;
              
              {ESLVal _v107 = $342;
              
              {ESLVal ts = $341;
              
              return expToJExp.apply(_v107);
            }
            }
            }
            }
          else if($349.isNil())
            if($341.isCons())
              {ESLVal $353 = $341.head();
                ESLVal $354 = $341.tail();
                
                if($354.isCons())
                {ESLVal $355 = $354.head();
                  ESLVal $356 = $354.tail();
                  
                  {ESLVal l = $343;
                  
                  {ESLVal _v108 = $342;
                  
                  {ESLVal ts = $341;
                  
                  return expToJExp.apply(_v108);
                }
                }
                }
                }
              else if($354.isNil())
                {ESLVal l1 = $343;
                  
                  {ESLVal l2 = $350;
                  
                  {ESLVal t = $353;
                  
                  return new ESLVal("JNil",$null);
                }
                }
                }
              else {ESLVal l = $343;
                  
                  {ESLVal _v109 = $342;
                  
                  {ESLVal ts = $341;
                  
                  return expToJExp.apply(_v109);
                }
                }
                }
              }
            else if($341.isNil())
              {ESLVal l = $343;
                
                {ESLVal _v110 = $342;
                
                {ESLVal ts = $341;
                
                return expToJExp.apply(_v110);
              }
              }
              }
            else {ESLVal l = $343;
                
                {ESLVal _v111 = $342;
                
                {ESLVal ts = $341;
                
                return expToJExp.apply(_v111);
              }
              }
              }
          else {ESLVal l = $343;
              
              {ESLVal _v112 = $342;
              
              {ESLVal ts = $341;
              
              return expToJExp.apply(_v112);
            }
            }
            }
          }
        case "NullExp": {ESLVal $344 = $342.termRef(0);
            
            if($341.isCons())
            {ESLVal $345 = $341.head();
              ESLVal $346 = $341.tail();
              
              if($346.isCons())
              {ESLVal $347 = $346.head();
                ESLVal $348 = $346.tail();
                
                {ESLVal l = $343;
                
                {ESLVal _v103 = $342;
                
                {ESLVal ts = $341;
                
                return expToJExp.apply(_v103);
              }
              }
              }
              }
            else if($346.isNil())
              {ESLVal l1 = $343;
                
                {ESLVal l2 = $344;
                
                {ESLVal t = $345;
                
                return new ESLVal("JNull",new ESLVal[]{});
              }
              }
              }
            else {ESLVal l = $343;
                
                {ESLVal _v104 = $342;
                
                {ESLVal ts = $341;
                
                return expToJExp.apply(_v104);
              }
              }
              }
            }
          else if($341.isNil())
            {ESLVal l = $343;
              
              {ESLVal _v105 = $342;
              
              {ESLVal ts = $341;
              
              return expToJExp.apply(_v105);
            }
            }
            }
          else {ESLVal l = $343;
              
              {ESLVal _v106 = $342;
              
              {ESLVal ts = $341;
              
              return expToJExp.apply(_v106);
            }
            }
            }
          }
          default: {ESLVal l = $343;
            
            {ESLVal _v113 = $342;
            
            {ESLVal ts = $341;
            
            return expToJExp.apply(_v113);
          }
          }
          }
        }
        }
      case "List": {ESLVal $340 = _v39.termRef(0);
          ESLVal $339 = _v39.termRef(1);
          
          {ESLVal l = $340;
          
          {ESLVal es = $339;
          
          return new ESLVal("JList",$null,expsToJExps.apply(es));
        }
        }
        }
      case "Term": {ESLVal $338 = _v39.termRef(0);
          ESLVal $337 = _v39.termRef(1);
          ESLVal $336 = _v39.termRef(2);
          ESLVal $335 = _v39.termRef(3);
          
          {ESLVal l = $338;
          
          {ESLVal n = $337;
          
          {ESLVal ts = $336;
          
          {ESLVal es = $335;
          
          return new ESLVal("JTerm",n,expsToJExps.apply(es));
        }
        }
        }
        }
        }
      case "Case": {ESLVal $334 = _v39.termRef(0);
          ESLVal $333 = _v39.termRef(1);
          ESLVal $332 = _v39.termRef(2);
          ESLVal $331 = _v39.termRef(3);
          
          {ESLVal l = $334;
          
          {ESLVal ds = $333;
          
          {ESLVal es = $332;
          
          {ESLVal arms = $331;
          
          return caseToJExp.apply(l,es,arms);
        }
        }
        }
        }
        }
      case "CaseList": {ESLVal $330 = _v39.termRef(0);
          ESLVal $329 = _v39.termRef(1);
          ESLVal $328 = _v39.termRef(2);
          ESLVal $327 = _v39.termRef(3);
          ESLVal $326 = _v39.termRef(4);
          
          {ESLVal l = $330;
          
          {ESLVal list = $329;
          
          {ESLVal cons = $328;
          
          {ESLVal nil = $327;
          
          {ESLVal alt = $326;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
        }
        }
      case "CaseTerm": {ESLVal $325 = _v39.termRef(0);
          ESLVal $324 = _v39.termRef(1);
          ESLVal $323 = _v39.termRef(2);
          ESLVal $322 = _v39.termRef(3);
          
          {ESLVal l = $325;
          
          {ESLVal list = $324;
          
          {ESLVal arms = $323;
          
          {ESLVal alt = $322;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
        }
      case "CaseStr": {ESLVal $321 = _v39.termRef(0);
          ESLVal $320 = _v39.termRef(1);
          ESLVal $319 = _v39.termRef(2);
          ESLVal $318 = _v39.termRef(3);
          
          {ESLVal l = $321;
          
          {ESLVal s = $320;
          
          {ESLVal arms = $319;
          
          {ESLVal alt = $318;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
        }
      case "CaseBool": {ESLVal $317 = _v39.termRef(0);
          ESLVal $316 = _v39.termRef(1);
          ESLVal $315 = _v39.termRef(2);
          ESLVal $314 = _v39.termRef(3);
          
          {ESLVal l = $317;
          
          {ESLVal s = $316;
          
          {ESLVal arms = $315;
          
          {ESLVal alt = $314;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
        }
      case "Head": {ESLVal $313 = _v39.termRef(0);
          
          {ESLVal _v102 = $313;
          
          return new ESLVal("JHead",expToJExp.apply(_v102));
        }
        }
      case "Tail": {ESLVal $312 = _v39.termRef(0);
          
          {ESLVal _v101 = $312;
          
          return new ESLVal("JTail",expToJExp.apply(_v101));
        }
        }
      case "CaseError": {ESLVal $311 = _v39.termRef(0);
          
          {ESLVal l = $311;
          
          return new ESLVal("JError",new ESLVal("JConstExp",new ESLVal("JConstStr",new ESLVal("case error at ").add(l))));
        }
        }
      case "NullExp": {ESLVal $310 = _v39.termRef(0);
          
          {ESLVal l = $310;
          
          return new ESLVal("JNull",new ESLVal[]{});
        }
        }
      case "Var": {ESLVal $309 = _v39.termRef(0);
          ESLVal $308 = _v39.termRef(1);
          
          {ESLVal l = $309;
          
          {ESLVal n = $308;
          
          return new ESLVal("JVar",n,$null);
        }
        }
        }
      case "Let": {ESLVal $307 = _v39.termRef(0);
          ESLVal $306 = _v39.termRef(1);
          ESLVal $305 = _v39.termRef(2);
          
          {ESLVal l = $307;
          
          {ESLVal bs = $306;
          
          {ESLVal body = $305;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
      case "Letrec": {ESLVal $304 = _v39.termRef(0);
          ESLVal $303 = _v39.termRef(1);
          ESLVal $302 = _v39.termRef(2);
          
          {ESLVal l = $304;
          
          {ESLVal bs = $303;
          
          {ESLVal body = $302;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
      case "Throw": {ESLVal $301 = _v39.termRef(0);
          ESLVal $300 = _v39.termRef(1);
          ESLVal $299 = _v39.termRef(2);
          
          {ESLVal l = $301;
          
          {ESLVal t = $300;
          
          {ESLVal _v100 = $299;
          
          return new ESLVal("JError",expToJExp.apply(_v100));
        }
        }
        }
        }
      case "Apply": {ESLVal $298 = _v39.termRef(0);
          ESLVal $297 = _v39.termRef(1);
          ESLVal $296 = _v39.termRef(2);
          
          {ESLVal l = $298;
          
          {ESLVal op = $297;
          
          {ESLVal args = $296;
          
          return new ESLVal("JApply",expToJExp.apply(op),expsToJExps.apply(args));
        }
        }
        }
        }
      case "BinExp": {ESLVal $295 = _v39.termRef(0);
          ESLVal $294 = _v39.termRef(1);
          ESLVal $293 = _v39.termRef(2);
          ESLVal $292 = _v39.termRef(3);
          
          {ESLVal l = $295;
          
          {ESLVal e1 = $294;
          
          {ESLVal op = $293;
          
          {ESLVal e2 = $292;
          
          return new ESLVal("JBinExp",expToJExp.apply(e1),opToJOp.apply(op),expToJExp.apply(e2));
        }
        }
        }
        }
        }
      case "Become": {ESLVal $288 = _v39.termRef(0);
          ESLVal $287 = _v39.termRef(1);
          
          switch($287.termName) {
          case "Apply": {ESLVal $291 = $287.termRef(0);
            ESLVal $290 = $287.termRef(1);
            ESLVal $289 = $287.termRef(2);
            
            {ESLVal l = $288;
            
            {ESLVal al = $291;
            
            {ESLVal b = $290;
            
            {ESLVal args = $289;
            
            return new ESLVal("JBecome",expToJExp.apply(b),expsToJExps.apply(args));
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(5324,9186)"));
        }
        }
      case "Block": {ESLVal $282 = _v39.termRef(0);
          ESLVal $281 = _v39.termRef(1);
          
          if($281.isCons())
          {ESLVal $283 = $281.head();
            ESLVal $284 = $281.tail();
            
            if($284.isCons())
            {ESLVal $285 = $284.head();
              ESLVal $286 = $284.tail();
              
              {ESLVal l = $282;
              
              {ESLVal es = $281;
              
              return new ESLVal("JCommandExp",new ESLVal("JBlock",expsToJCommands.apply(es,$true)),$null);
            }
            }
            }
          else if($284.isNil())
            {ESLVal l = $282;
              
              {ESLVal _v99 = $283;
              
              return expToJExp.apply(_v99);
            }
            }
          else {ESLVal l = $282;
              
              {ESLVal es = $281;
              
              return new ESLVal("JCommandExp",new ESLVal("JBlock",expsToJCommands.apply(es,$true)),$null);
            }
            }
          }
        else if($281.isNil())
          {ESLVal l = $282;
            
            return new ESLVal("JNull",new ESLVal[]{});
          }
        else {ESLVal l = $282;
            
            {ESLVal es = $281;
            
            return new ESLVal("JCommandExp",new ESLVal("JBlock",expsToJCommands.apply(es,$true)),$null);
          }
          }
        }
      case "If": {ESLVal $280 = _v39.termRef(0);
          ESLVal $279 = _v39.termRef(1);
          ESLVal $278 = _v39.termRef(2);
          ESLVal $277 = _v39.termRef(3);
          
          {ESLVal l = $280;
          
          {ESLVal e1 = $279;
          
          {ESLVal e2 = $278;
          
          {ESLVal e3 = $277;
          
          return new ESLVal("JCommandExp",new ESLVal("JIfCommand",expToJExp.apply(e1),expToJCommand.apply(e2,$true),expToJCommand.apply(e3,$true)),$null);
        }
        }
        }
        }
        }
      case "FunExp": {ESLVal $276 = _v39.termRef(0);
          ESLVal $275 = _v39.termRef(1);
          ESLVal $274 = _v39.termRef(2);
          ESLVal $273 = _v39.termRef(3);
          ESLVal $272 = _v39.termRef(4);
          
          {ESLVal l = $276;
          
          {ESLVal n = $275;
          
          {ESLVal args = $274;
          
          {ESLVal t = $273;
          
          {ESLVal body = $272;
          
          return new ESLVal("JFun",expToJExp.apply(n),map.apply(new ESLVal(new Function(new ESLVal("fun1023"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal d = $args[0];
          return decToJDec.apply(d);
            }
          }),args),new ESLVal("JFunType",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v40 = $qualArg;
                
                {ESLVal a = _v40;
                
                return ESLVal.list(ESLVal.list($null));
              }
              }
            }
          }).map(args).flatten().flatten(),$null),expToJCommand.apply(body,$true));
        }
        }
        }
        }
        }
        }
      case "TermRef": {ESLVal $271 = _v39.termRef(0);
          ESLVal $270 = _v39.termRef(1);
          
          {ESLVal _v98 = $271;
          
          {ESLVal i = $270;
          
          return new ESLVal("JTermRef",expToJExp.apply(_v98),i);
        }
        }
        }
      case "Cmp": {ESLVal $269 = _v39.termRef(0);
          ESLVal $268 = _v39.termRef(1);
          ESLVal $267 = _v39.termRef(2);
          
          {ESLVal l = $269;
          
          {ESLVal _v97 = $268;
          
          {ESLVal qs = $267;
          
          return cmpToJExp.apply(_v97,qs);
        }
        }
        }
        }
      case "Not": {ESLVal $266 = _v39.termRef(0);
          ESLVal $265 = _v39.termRef(1);
          
          {ESLVal l = $266;
          
          {ESLVal _v96 = $265;
          
          return new ESLVal("JNot",expToJExp.apply(_v96));
        }
        }
        }
      case "New": {ESLVal $264 = _v39.termRef(0);
          ESLVal $263 = _v39.termRef(1);
          ESLVal $262 = _v39.termRef(2);
          
          {ESLVal l = $264;
          
          {ESLVal b = $263;
          
          {ESLVal args = $262;
          
          return new ESLVal("JNew",expToJExp.apply(b),expsToJExps.apply(args));
        }
        }
        }
        }
      case "NewArray": {ESLVal $261 = _v39.termRef(0);
          ESLVal $260 = _v39.termRef(1);
          ESLVal $259 = _v39.termRef(2);
          
          {ESLVal l = $261;
          
          {ESLVal t = $260;
          
          {ESLVal i = $259;
          
          return new ESLVal("JNewArray",expToJExp.apply(i));
        }
        }
        }
        }
      case "NewJava": {ESLVal $258 = _v39.termRef(0);
          ESLVal $257 = _v39.termRef(1);
          ESLVal $256 = _v39.termRef(2);
          ESLVal $255 = _v39.termRef(3);
          
          {ESLVal l = $258;
          
          {ESLVal n = $257;
          
          {ESLVal t = $256;
          
          {ESLVal args = $255;
          
          return new ESLVal("JNewJava",n,expsToJExps.apply(args));
        }
        }
        }
        }
        }
      case "Send": {ESLVal $250 = _v39.termRef(0);
          ESLVal $249 = _v39.termRef(1);
          ESLVal $248 = _v39.termRef(2);
          
          switch($248.termName) {
          case "Term": {ESLVal $254 = $248.termRef(0);
            ESLVal $253 = $248.termRef(1);
            ESLVal $252 = $248.termRef(2);
            ESLVal $251 = $248.termRef(3);
            
            {ESLVal l = $250;
            
            {ESLVal a = $249;
            
            {ESLVal lt = $254;
            
            {ESLVal n = $253;
            
            {ESLVal ts = $252;
            
            {ESLVal es = $251;
            
            return new ESLVal("JSend",expToJExp.apply(a),n,expsToJExps.apply(es));
          }
          }
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(5324,9186)"));
        }
        }
      case "Self": {ESLVal $247 = _v39.termRef(0);
          
          {ESLVal l = $247;
          
          return new ESLVal("JSelf",new ESLVal[]{});
        }
        }
      case "Fold": {ESLVal $246 = _v39.termRef(0);
          ESLVal $245 = _v39.termRef(1);
          ESLVal $244 = _v39.termRef(2);
          
          {ESLVal l = $246;
          
          {ESLVal t = $245;
          
          {ESLVal _v95 = $244;
          
          return expToJExp.apply(_v95);
        }
        }
        }
        }
      case "Now": {ESLVal $243 = _v39.termRef(0);
          
          {ESLVal l = $243;
          
          return new ESLVal("JNow",new ESLVal[]{});
        }
        }
      case "Ref": {ESLVal $242 = _v39.termRef(0);
          ESLVal $241 = _v39.termRef(1);
          ESLVal $240 = _v39.termRef(2);
          
          {ESLVal l = $242;
          
          {ESLVal _v94 = $241;
          
          {ESLVal n = $240;
          
          return new ESLVal("JRef",expToJExp.apply(_v94),n);
        }
        }
        }
        }
      case "For": {ESLVal $239 = _v39.termRef(0);
          ESLVal $238 = _v39.termRef(1);
          ESLVal $237 = _v39.termRef(2);
          ESLVal $236 = _v39.termRef(3);
          
          {ESLVal l1 = $239;
          
          {ESLVal p = $238;
          
          {ESLVal l2 = $237;
          
          {ESLVal c = $236;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
        }
      case "Grab": {ESLVal $235 = _v39.termRef(0);
          ESLVal $234 = _v39.termRef(1);
          ESLVal $233 = _v39.termRef(2);
          
          {ESLVal l = $235;
          
          {ESLVal refs = $234;
          
          {ESLVal _v93 = $233;
          
          return new ESLVal("JGrab",refsToJExps.apply(refs),expToJExp.apply(_v93));
        }
        }
        }
        }
      case "Update": {ESLVal $232 = _v39.termRef(0);
          ESLVal $231 = _v39.termRef(1);
          ESLVal $230 = _v39.termRef(2);
          
          {ESLVal l = $232;
          
          {ESLVal n = $231;
          
          {ESLVal v = $230;
          
          return new ESLVal("JCommandExp",expToJCommand.apply(e,$true),$null);
        }
        }
        }
        }
      case "Probably": {ESLVal $229 = _v39.termRef(0);
          ESLVal $228 = _v39.termRef(1);
          ESLVal $227 = _v39.termRef(2);
          ESLVal $226 = _v39.termRef(3);
          ESLVal $225 = _v39.termRef(4);
          
          {ESLVal l = $229;
          
          {ESLVal _v92 = $228;
          
          {ESLVal t = $227;
          
          {ESLVal e1 = $226;
          
          {ESLVal e2 = $225;
          
          return new ESLVal("JProbably",expToJExp.apply(_v92),expToJExp.apply(e1),expToJExp.apply(e2));
        }
        }
        }
        }
        }
        }
      case "Try": {ESLVal $224 = _v39.termRef(0);
          ESLVal $223 = _v39.termRef(1);
          ESLVal $222 = _v39.termRef(2);
          
          {ESLVal l = $224;
          
          {ESLVal _v91 = $223;
          
          {ESLVal arms = $222;
          
          return new ESLVal("JTry",expToJExp.apply(_v91),new ESLVal("$x"),expToJCommand.apply(new ESLVal("Case",l,$nil,ESLVal.list(new ESLVal("Var",l,new ESLVal("$x"))),arms),$true));
        }
        }
        }
        }
      case "ActExp": {ESLVal $221 = _v39.termRef(0);
          ESLVal $220 = _v39.termRef(1);
          ESLVal $219 = _v39.termRef(2);
          ESLVal $218 = _v39.termRef(3);
          ESLVal $217 = _v39.termRef(4);
          ESLVal $216 = _v39.termRef(5);
          ESLVal $215 = _v39.termRef(6);
          ESLVal $214 = _v39.termRef(7);
          
          {ESLVal l = $221;
          
          {ESLVal name = $220;
          
          {ESLVal decs = $219;
          
          {ESLVal exports = $218;
          
          {ESLVal parent = $217;
          
          {ESLVal defs = $216;
          
          {ESLVal init = $215;
          
          {ESLVal arms = $214;
          
          return actToJava.apply(name,decs,exports,parent,defs,init,arms);
        }
        }
        }
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(5324,9186)"));
      }
      }
    }
  });
  private static ESLVal refsToJExps = new ESLVal(new Function(new ESLVal("refsToJExps"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal refs = $args[0];
  {ESLVal _v38 = refs;
        
        if(_v38.isCons())
        {ESLVal $205 = _v38.head();
          ESLVal $206 = _v38.tail();
          
          switch($205.termName) {
          case "VarDynamicRef": {ESLVal $211 = $205.termRef(0);
            ESLVal $210 = $205.termRef(1);
            
            switch($210.termName) {
            case "Var": {ESLVal $213 = $210.termRef(0);
              ESLVal $212 = $210.termRef(1);
              
              {ESLVal l = $211;
              
              {ESLVal vl = $213;
              
              {ESLVal n = $212;
              
              {ESLVal _v90 = $206;
              
              return refsToJExps.apply(_v90).cons(new ESLVal("JVar",n,$null));
            }
            }
            }
            }
            }
            default: return error(new ESLVal("case error at Pos(9229,9470)"));
          }
          }
        case "ActorDynamicRef": {ESLVal $209 = $205.termRef(0);
            ESLVal $208 = $205.termRef(1);
            ESLVal $207 = $205.termRef(2);
            
            {ESLVal l = $209;
            
            {ESLVal e = $208;
            
            {ESLVal n = $207;
            
            {ESLVal _v89 = $206;
            
            return refsToJExps.apply(_v89).cons(new ESLVal("JRef",expToJExp.apply(e),n));
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(9229,9470)"));
        }
        }
      else if(_v38.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(9229,9470)"));
      }
    }
  });
  private static ESLVal actToJava = new ESLVal(new Function(new ESLVal("actToJava"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal name = $args[0];
  ESLVal decs = $args[1];
  ESLVal exports = $args[2];
  ESLVal parent = $args[3];
  ESLVal defs = $args[4];
  ESLVal init = $args[5];
  ESLVal arms = $args[6];
  {print.apply(new ESLVal("PARENt` = ").add(parent));
      {ESLVal timeArms = select.apply(isTimeArm,arms);
        
        {ESLVal nonTimeArms = reject.apply(isTimeArm,arms);
        
        {ESLVal timeCommand = ((Supplier<ESLVal>)() -> { 
            if(timeArms.eql(ESLVal.list()).boolVal)
              return new ESLVal("JBlock",ESLVal.list());
              else
                return timeArmsToJCommand.apply(timeArms);
          }).get();
        
        {ESLVal f = new ESLVal("FunExp",new ESLVal("Pos",$zero,$zero),name,ESLVal.list(new ESLVal("Dec",new ESLVal("Pos",$zero,$zero),new ESLVal("$m"),$null,$null)),new ESLVal("VoidType",new ESLVal("Pos",$zero,$zero)),new ESLVal("Case",new ESLVal("Pos",$zero,$zero),$nil,ESLVal.list(new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("$m"))),nonTimeArms));
        
        return new ESLVal("JBehaviour",exports,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v37 = $qualArg;
              
              {ESLVal b = _v37;
              
              return ESLVal.list(ESLVal.list(defToField.apply(b)));
            }
            }
          }
        }).map(defs).flatten().flatten(),expToJExp.apply(init),expToJExp.apply(f),timeCommand);
      }
      }
      }
      }}
    }
  });
  private static ESLVal isTimeArm = new ESLVal(new Function(new ESLVal("isTimeArm"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal a = $args[0];
  {ESLVal _v36 = a;
        
        switch(_v36.termName) {
        case "BArm": {ESLVal $196 = _v36.termRef(0);
          ESLVal $195 = _v36.termRef(1);
          ESLVal $194 = _v36.termRef(2);
          ESLVal $193 = _v36.termRef(3);
          
          if($195.isCons())
          {ESLVal $197 = $195.head();
            ESLVal $198 = $195.tail();
            
            switch($197.termName) {
            case "PTerm": {ESLVal $202 = $197.termRef(0);
              ESLVal $201 = $197.termRef(1);
              ESLVal $200 = $197.termRef(2);
              ESLVal $199 = $197.termRef(3);
              
              switch($201.strVal) {
              case "Time": if($198.isCons())
                {ESLVal $203 = $198.head();
                  ESLVal $204 = $198.tail();
                  
                  {ESLVal _v82 = _v36;
                  
                  return $false;
                }
                }
              else if($198.isNil())
                {ESLVal l = $196;
                  
                  {ESLVal pl = $202;
                  
                  {ESLVal ts = $200;
                  
                  {ESLVal ps = $199;
                  
                  {ESLVal g = $194;
                  
                  {ESLVal e = $193;
                  
                  return $true;
                }
                }
                }
                }
                }
                }
              else {ESLVal _v83 = _v36;
                  
                  return $false;
                }
              default: {ESLVal _v84 = _v36;
                
                return $false;
              }
            }
            }
            default: {ESLVal _v85 = _v36;
              
              return $false;
            }
          }
          }
        else if($195.isNil())
          {ESLVal _v86 = _v36;
            
            return $false;
          }
        else {ESLVal _v87 = _v36;
            
            return $false;
          }
        }
        default: {ESLVal _v88 = _v36;
          
          return $false;
        }
      }
      }
    }
  });
  private static ESLVal timeArmsToJCommand = new ESLVal(new Function(new ESLVal("timeArmsToJCommand"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal arms = $args[0];
  {ESLVal _v35 = arms;
        
        if(_v35.isCons())
        {ESLVal $162 = _v35.head();
          ESLVal $163 = _v35.tail();
          
          switch($162.termName) {
          case "BArm": {ESLVal $167 = $162.termRef(0);
            ESLVal $166 = $162.termRef(1);
            ESLVal $165 = $162.termRef(2);
            ESLVal $164 = $162.termRef(3);
            
            if($166.isCons())
            {ESLVal $168 = $166.head();
              ESLVal $169 = $166.tail();
              
              switch($168.termName) {
              case "PTerm": {ESLVal $173 = $168.termRef(0);
                ESLVal $172 = $168.termRef(1);
                ESLVal $171 = $168.termRef(2);
                ESLVal $170 = $168.termRef(3);
                
                switch($172.strVal) {
                case "Time": if($171.isCons())
                  {ESLVal $174 = $171.head();
                    ESLVal $175 = $171.tail();
                    
                    return error(new ESLVal("case error at Pos(10293,10823)"));
                  }
                else if($171.isNil())
                  if($170.isCons())
                    {ESLVal $176 = $170.head();
                      ESLVal $177 = $170.tail();
                      
                      switch($176.termName) {
                      case "PVar": {ESLVal $188 = $176.termRef(0);
                        ESLVal $187 = $176.termRef(1);
                        ESLVal $186 = $176.termRef(2);
                        
                        if($177.isCons())
                        {ESLVal $189 = $177.head();
                          ESLVal $190 = $177.tail();
                          
                          return error(new ESLVal("case error at Pos(10293,10823)"));
                        }
                      else if($177.isNil())
                        if($169.isCons())
                          {ESLVal $191 = $169.head();
                            ESLVal $192 = $169.tail();
                            
                            return error(new ESLVal("case error at Pos(10293,10823)"));
                          }
                        else if($169.isNil())
                          {ESLVal l = $167;
                            
                            {ESLVal tl = $173;
                            
                            {ESLVal vl = $188;
                            
                            {ESLVal n = $187;
                            
                            {ESLVal t = $186;
                            
                            {ESLVal g = $165;
                            
                            {ESLVal e = $164;
                            
                            {ESLVal _v81 = $163;
                            
                            return new ESLVal("JLet",ESLVal.list(new ESLVal("JField",n,$null,new ESLVal("JVar",new ESLVal("$t"),$null))),new ESLVal("JIfCommand",expToJExp.apply(g),expToJCommand.apply(e,$false),timeArmsToJCommand.apply(_v81)));
                          }
                          }
                          }
                          }
                          }
                          }
                          }
                          }
                        else return error(new ESLVal("case error at Pos(10293,10823)"));
                      else return error(new ESLVal("case error at Pos(10293,10823)"));
                      }
                    case "PInt": {ESLVal $179 = $176.termRef(0);
                        ESLVal $178 = $176.termRef(1);
                        
                        if($177.isCons())
                        {ESLVal $180 = $177.head();
                          ESLVal $181 = $177.tail();
                          
                          return error(new ESLVal("case error at Pos(10293,10823)"));
                        }
                      else if($177.isNil())
                        if($169.isCons())
                          {ESLVal $182 = $169.head();
                            ESLVal $183 = $169.tail();
                            
                            return error(new ESLVal("case error at Pos(10293,10823)"));
                          }
                        else if($169.isNil())
                          switch($165.termName) {
                            case "BoolExp": {ESLVal $185 = $165.termRef(0);
                              ESLVal $184 = $165.termRef(1);
                              
                              switch($184.boolVal ? 1 : 0) {
                              case 1: {ESLVal l = $167;
                                
                                {ESLVal tl = $173;
                                
                                {ESLVal vl = $179;
                                
                                {ESLVal n = $178;
                                
                                {ESLVal bl = $185;
                                
                                {ESLVal e = $164;
                                
                                {ESLVal _v80 = $163;
                                
                                return new ESLVal("JIfCommand",new ESLVal("JBinExp",new ESLVal("JVar",new ESLVal("$t"),$null),new ESLVal("eq"),new ESLVal("JConstExp",new ESLVal("JConstInt",n))),expToJCommand.apply(e,$false),timeArmsToJCommand.apply(_v80));
                              }
                              }
                              }
                              }
                              }
                              }
                              }
                              default: return error(new ESLVal("case error at Pos(10293,10823)"));
                            }
                            }
                            default: return error(new ESLVal("case error at Pos(10293,10823)"));
                          }
                        else return error(new ESLVal("case error at Pos(10293,10823)"));
                      else return error(new ESLVal("case error at Pos(10293,10823)"));
                      }
                      default: return error(new ESLVal("case error at Pos(10293,10823)"));
                    }
                    }
                  else if($170.isNil())
                    return error(new ESLVal("case error at Pos(10293,10823)"));
                  else return error(new ESLVal("case error at Pos(10293,10823)"));
                else return error(new ESLVal("case error at Pos(10293,10823)"));
                default: return error(new ESLVal("case error at Pos(10293,10823)"));
              }
              }
              default: return error(new ESLVal("case error at Pos(10293,10823)"));
            }
            }
          else if($166.isNil())
            return error(new ESLVal("case error at Pos(10293,10823)"));
          else return error(new ESLVal("case error at Pos(10293,10823)"));
          }
          default: return error(new ESLVal("case error at Pos(10293,10823)"));
        }
        }
      else if(_v35.isNil())
        return new ESLVal("JBlock",ESLVal.list());
      else return error(new ESLVal("case error at Pos(10293,10823)"));
      }
    }
  });
  private static ESLVal cmpToJExp = new ESLVal(new Function(new ESLVal("cmpToJExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  ESLVal qs = $args[1];
  {ESLVal _v34 = qs;
        
        if(_v34.isCons())
        {ESLVal $155 = _v34.head();
          ESLVal $156 = _v34.tail();
          
          switch($155.termName) {
          case "BQual": {ESLVal $161 = $155.termRef(0);
            ESLVal $160 = $155.termRef(1);
            ESLVal $159 = $155.termRef(2);
            
            {ESLVal l = $161;
            
            {ESLVal p = $160;
            
            {ESLVal v = $159;
            
            {ESLVal _v79 = $156;
            
            {ESLVal f = new ESLVal("FunExp",new ESLVal("Pos",$zero,$zero),new ESLVal("StrExp",new ESLVal("Pos",$zero,$zero),new ESLVal("qual")),ESLVal.list(new ESLVal("Dec",new ESLVal("Pos",$zero,$zero),new ESLVal("$qualArg"),$null,$null)),$null,new ESLVal("Case",new ESLVal("Pos",$zero,$zero),ESLVal.list(),ESLVal.list(new ESLVal("Var",new ESLVal("Pos",$zero,$zero),new ESLVal("$qualArg"))),ESLVal.list(new ESLVal("BArm",new ESLVal("Pos",$zero,$zero),ESLVal.list(p),new ESLVal("BoolExp",new ESLVal("Pos",$zero,$zero),$true),new ESLVal("List",new ESLVal("Pos",$zero,$zero),ESLVal.list(new ESLVal("Cmp",new ESLVal("Pos",$zero,$zero),e,_v79)))),new ESLVal("BArm",new ESLVal("Pos",$zero,$zero),ESLVal.list(new ESLVal("PVar",new ESLVal("Pos",$zero,$zero),new ESLVal("_0"),$null)),new ESLVal("BoolExp",new ESLVal("Pos",$zero,$zero),$true),new ESLVal("List",new ESLVal("Pos",$zero,$zero),$nil)))));
            
            return new ESLVal("JFlatten",new ESLVal("JFlatten",new ESLVal("JMapFun",expToJExp.apply(f),expToJExp.apply(v))));
          }
          }
          }
          }
          }
          }
        case "PQual": {ESLVal $158 = $155.termRef(0);
            ESLVal $157 = $155.termRef(1);
            
            {ESLVal l = $158;
            
            {ESLVal p = $157;
            
            {ESLVal _v78 = $156;
            
            return new ESLVal("JIfExp",expToJExp.apply(p),cmpToJExp.apply(e,_v78),new ESLVal("JNil",$null));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(10870,11538)"));
        }
        }
      else if(_v34.isNil())
        return new ESLVal("JList",$null,ESLVal.list(expToJExp.apply(e)));
      else return error(new ESLVal("case error at Pos(10870,11538)"));
      }
    }
  });
  public static ESLVal moduleToJava = new ESLVal(new Function(new ESLVal("moduleToJava"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal module = $args[0];
  {ESLVal _v32 = module;
        
        switch(_v32.termName) {
        case "Module": {ESLVal $154 = _v32.termRef(0);
          ESLVal $153 = _v32.termRef(1);
          ESLVal $152 = _v32.termRef(2);
          ESLVal $151 = _v32.termRef(3);
          ESLVal $150 = _v32.termRef(4);
          ESLVal $149 = _v32.termRef(5);
          ESLVal $148 = _v32.termRef(6);
          
          {ESLVal path = $154;
          
          {ESLVal name = $153;
          
          {ESLVal exports = $152;
          
          {ESLVal imports = $151;
          
          {ESLVal x = $150;
          
          {ESLVal y = $149;
          
          {ESLVal defs = $148;
          
          return renameJVarsModule.apply(new ESLVal("JModule",name,exports,imports,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v33 = $qualArg;
                
                {ESLVal d = _v33;
                
                return ESLVal.list((isBinding.apply(d).or(isFunBind.apply(d)).boolVal) ? (ESLVal.list(defToField.apply(d))) : ($nil));
              }
              }
            }
          }).map(defs).flatten().flatten()));
        }
        }
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(11576,11819)"));
      }
      }
    }
  });
  private static ESLVal renameJVarsModule = new ESLVal(new Function(new ESLVal("renameJVarsModule"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal m = $args[0];
  {ESLVal _v29 = m;
        
        switch(_v29.termName) {
        case "JModule": {ESLVal $141 = _v29.termRef(0);
          ESLVal $140 = _v29.termRef(1);
          ESLVal $139 = _v29.termRef(2);
          ESLVal $138 = _v29.termRef(3);
          
          {ESLVal name = $141;
          
          {ESLVal exports = $140;
          
          {ESLVal imports = $139;
          
          {ESLVal fs = $138;
          
          {ESLVal fieldNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v30 = $qualArg;
                  
                  switch(_v30.termName) {
                  case "JField": {ESLVal $144 = _v30.termRef(0);
                    ESLVal $143 = _v30.termRef(1);
                    ESLVal $142 = _v30.termRef(2);
                    
                    {ESLVal n = $144;
                    
                    {ESLVal t = $143;
                    
                    {ESLVal e = $142;
                    
                    return ESLVal.list(ESLVal.list(n));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v30;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(fs).flatten().flatten();
          
          return new ESLVal("JModule",name,exports,imports,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v31 = $qualArg;
                
                switch(_v31.termName) {
                case "JField": {ESLVal $147 = _v31.termRef(0);
                  ESLVal $146 = _v31.termRef(1);
                  ESLVal $145 = _v31.termRef(2);
                  
                  {ESLVal n = $147;
                  
                  {ESLVal t = $146;
                  
                  {ESLVal e = $145;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(e,fieldNames,emptyTable))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v31;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten());
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(11859,12166)"));
      }
      }
    }
  });
  private static ESLVal renameJVarsExp = new ESLVal(new Function(new ESLVal("renameJVarsExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  ESLVal vars = $args[1];
  ESLVal env = $args[2];
  {ESLVal _v16 = e;
        
        switch(_v16.termName) {
        case "JFun": {ESLVal $132 = _v16.termRef(0);
          ESLVal $131 = _v16.termRef(1);
          ESLVal $130 = _v16.termRef(2);
          ESLVal $129 = _v16.termRef(3);
          
          {ESLVal v0 = $132;
          
          {ESLVal v1 = $131;
          
          {ESLVal v2 = $130;
          
          {ESLVal v3 = $129;
          
          {ESLVal boundNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v26 = $qualArg;
                  
                  switch(_v26.termName) {
                  case "JDec": {ESLVal $137 = _v26.termRef(0);
                    ESLVal $136 = _v26.termRef(1);
                    
                    {ESLVal n = $137;
                    
                    {ESLVal t = $136;
                    
                    return ESLVal.list(ESLVal.list(n));
                  }
                  }
                  }
                  default: {ESLVal _0 = _v26;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v1).flatten().flatten();
          
          if(exists.apply(new ESLVal(new Function(new ESLVal("fun1024"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal n = $args[0];
        return member.apply(n,boundNames);
          }
        }),vars).boolVal)
          {ESLVal newNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v27 = $qualArg;
                    
                    {ESLVal n = _v27;
                    
                    return ESLVal.list(ESLVal.list(newName.apply()));
                  }
                  }
                }
              }).map(boundNames).flatten().flatten();
            
            {ESLVal env1 = addEntries.apply(boundNames,newNames,env);
            
            return new ESLVal("JFun",v0,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v28 = $qualArg;
                  
                  {ESLVal n = _v28;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JDec",n,$null)));
                }
                }
              }
            }).map(newNames).flatten().flatten(),v2,renameJVarsCommand.apply(v3,boundNames.add(vars),env1));
          }
          }
          else
            return new ESLVal("JFun",v0,v1,v2,renameJVarsCommand.apply(v3,boundNames.add(vars),env));
        }
        }
        }
        }
        }
        }
      case "JApply": {ESLVal $128 = _v16.termRef(0);
          ESLVal $127 = _v16.termRef(1);
          
          {ESLVal v0 = $128;
          
          {ESLVal v1 = $127;
          
          return new ESLVal("JApply",renameJVarsExp.apply(v0,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v25 = $qualArg;
                
                {ESLVal v = _v25;
                
                return ESLVal.list(ESLVal.list(renameJVarsExp.apply(v,vars,env)));
              }
              }
            }
          }).map(v1).flatten().flatten());
        }
        }
        }
      case "JArrayRef": {ESLVal $126 = _v16.termRef(0);
          ESLVal $125 = _v16.termRef(1);
          
          {ESLVal a = $126;
          
          {ESLVal i = $125;
          
          return new ESLVal("JArrayRef",renameJVarsExp.apply(a,vars,env),renameJVarsExp.apply(i,vars,env));
        }
        }
        }
      case "JArrayUpdate": {ESLVal $124 = _v16.termRef(0);
          ESLVal $123 = _v16.termRef(1);
          ESLVal $122 = _v16.termRef(2);
          
          {ESLVal a = $124;
          
          {ESLVal i = $123;
          
          {ESLVal v = $122;
          
          return new ESLVal("JArrayUpdate",renameJVarsExp.apply(a,vars,env),renameJVarsExp.apply(i,vars,env),renameJVarsExp.apply(v,vars,env));
        }
        }
        }
        }
      case "JBecome": {ESLVal $121 = _v16.termRef(0);
          ESLVal $120 = _v16.termRef(1);
          
          {ESLVal _v77 = $121;
          
          {ESLVal es = $120;
          
          return new ESLVal("JBecome",renameJVarsExp.apply(_v77,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v24 = $qualArg;
                
                {ESLVal v = _v24;
                
                return ESLVal.list(ESLVal.list(renameJVarsExp.apply(v,vars,env)));
              }
              }
            }
          }).map(es).flatten().flatten());
        }
        }
        }
      case "JBinExp": {ESLVal $119 = _v16.termRef(0);
          ESLVal $118 = _v16.termRef(1);
          ESLVal $117 = _v16.termRef(2);
          
          {ESLVal v0 = $119;
          
          {ESLVal v1 = $118;
          
          {ESLVal v2 = $117;
          
          return new ESLVal("JBinExp",renameJVarsExp.apply(v0,vars,env),v1,renameJVarsExp.apply(v2,vars,env));
        }
        }
        }
        }
      case "JCommandExp": {ESLVal $116 = _v16.termRef(0);
          ESLVal $115 = _v16.termRef(1);
          
          {ESLVal v0 = $116;
          
          {ESLVal v1 = $115;
          
          return new ESLVal("JCommandExp",renameJVarsCommand.apply(v0,vars,env),v1);
        }
        }
        }
      case "JIfExp": {ESLVal $114 = _v16.termRef(0);
          ESLVal $113 = _v16.termRef(1);
          ESLVal $112 = _v16.termRef(2);
          
          {ESLVal v0 = $114;
          
          {ESLVal v1 = $113;
          
          {ESLVal v2 = $112;
          
          return new ESLVal("JIfExp",renameJVarsExp.apply(v0,vars,env),renameJVarsExp.apply(v1,vars,env),renameJVarsExp.apply(v2,vars,env));
        }
        }
        }
        }
      case "JConstExp": {ESLVal $111 = _v16.termRef(0);
          
          {ESLVal v0 = $111;
          
          return e;
        }
        }
      case "JTerm": {ESLVal $110 = _v16.termRef(0);
          ESLVal $109 = _v16.termRef(1);
          
          {ESLVal v0 = $110;
          
          {ESLVal v1 = $109;
          
          return new ESLVal("JTerm",v0,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v23 = $qualArg;
                
                {ESLVal v = _v23;
                
                return ESLVal.list(ESLVal.list(renameJVarsExp.apply(v,vars,env)));
              }
              }
            }
          }).map(v1).flatten().flatten());
        }
        }
        }
      case "JTermRef": {ESLVal $108 = _v16.termRef(0);
          ESLVal $107 = _v16.termRef(1);
          
          {ESLVal v0 = $108;
          
          {ESLVal v1 = $107;
          
          return new ESLVal("JTermRef",renameJVarsExp.apply(v0,vars,env),v1);
        }
        }
        }
      case "JList": {ESLVal $106 = _v16.termRef(0);
          ESLVal $105 = _v16.termRef(1);
          
          {ESLVal v0 = $106;
          
          {ESLVal v1 = $105;
          
          return new ESLVal("JList",v0,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v22 = $qualArg;
                
                {ESLVal v = _v22;
                
                return ESLVal.list(ESLVal.list(renameJVarsExp.apply(v,vars,env)));
              }
              }
            }
          }).map(v1).flatten().flatten());
        }
        }
        }
      case "JNil": {ESLVal $104 = _v16.termRef(0);
          
          {ESLVal v0 = $104;
          
          return e;
        }
        }
      case "JNow": {
          return e;
        }
      case "JVar": {ESLVal $103 = _v16.termRef(0);
          ESLVal $102 = _v16.termRef(1);
          
          {ESLVal v0 = $103;
          
          {ESLVal v1 = $102;
          
          if(hasEntry.apply(v0,env).boolVal)
          return new ESLVal("JVar",lookup.apply(v0,env),v1);
          else
            return e;
        }
        }
        }
      case "JNull": {
          return e;
        }
      case "JError": {ESLVal $101 = _v16.termRef(0);
          
          {ESLVal v0 = $101;
          
          return new ESLVal("JError",renameJVarsExp.apply(v0,vars,env));
        }
        }
      case "JHead": {ESLVal $100 = _v16.termRef(0);
          
          {ESLVal v0 = $100;
          
          return new ESLVal("JHead",renameJVarsExp.apply(v0,vars,env));
        }
        }
      case "JTail": {ESLVal $99 = _v16.termRef(0);
          
          {ESLVal v0 = $99;
          
          return new ESLVal("JTail",renameJVarsExp.apply(v0,vars,env));
        }
        }
      case "JCastp": {ESLVal $98 = _v16.termRef(0);
          ESLVal $97 = _v16.termRef(1);
          ESLVal $96 = _v16.termRef(2);
          
          {ESLVal v0 = $98;
          
          {ESLVal v1 = $97;
          
          {ESLVal v2 = $96;
          
          return new ESLVal("JCastp",v0,v1,renameJVarsExp.apply(v2,vars,env));
        }
        }
        }
        }
      case "JCast": {ESLVal $95 = _v16.termRef(0);
          ESLVal $94 = _v16.termRef(1);
          
          {ESLVal v0 = $95;
          
          {ESLVal v1 = $94;
          
          return new ESLVal("JCast",v0,renameJVarsExp.apply(v1,vars,env));
        }
        }
        }
      case "JNot": {ESLVal $93 = _v16.termRef(0);
          
          {ESLVal _v76 = $93;
          
          return new ESLVal("JNot",renameJVarsExp.apply(_v76,vars,env));
        }
        }
      case "JNew": {ESLVal $92 = _v16.termRef(0);
          ESLVal $91 = _v16.termRef(1);
          
          {ESLVal b = $92;
          
          {ESLVal args = $91;
          
          return new ESLVal("JNew",renameJVarsExp.apply(b,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v21 = $qualArg;
                
                {ESLVal a = _v21;
                
                return ESLVal.list(ESLVal.list(renameJVarsExp.apply(a,vars,env)));
              }
              }
            }
          }).map(args).flatten().flatten());
        }
        }
        }
      case "JNewArray": {ESLVal $90 = _v16.termRef(0);
          
          {ESLVal b = $90;
          
          return new ESLVal("JNewArray",renameJVarsExp.apply(b,vars,env));
        }
        }
      case "JNewJava": {ESLVal $89 = _v16.termRef(0);
          ESLVal $88 = _v16.termRef(1);
          
          {ESLVal n = $89;
          
          {ESLVal args = $88;
          
          return new ESLVal("JNewJava",n,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v20 = $qualArg;
                
                {ESLVal a = _v20;
                
                return ESLVal.list(ESLVal.list(renameJVarsExp.apply(a,vars,env)));
              }
              }
            }
          }).map(args).flatten().flatten());
        }
        }
        }
      case "JMapFun": {ESLVal $87 = _v16.termRef(0);
          ESLVal $86 = _v16.termRef(1);
          
          {ESLVal f = $87;
          
          {ESLVal l = $86;
          
          return new ESLVal("JMapFun",renameJVarsExp.apply(f,vars,env),renameJVarsExp.apply(l,vars,env));
        }
        }
        }
      case "JFlatten": {ESLVal $85 = _v16.termRef(0);
          
          {ESLVal _v75 = $85;
          
          return new ESLVal("JFlatten",renameJVarsExp.apply(_v75,vars,env));
        }
        }
      case "JSend": {ESLVal $84 = _v16.termRef(0);
          ESLVal $83 = _v16.termRef(1);
          ESLVal $82 = _v16.termRef(2);
          
          {ESLVal _v73 = $84;
          
          {ESLVal n = $83;
          
          {ESLVal es = $82;
          
          return new ESLVal("JSend",renameJVarsExp.apply(_v73,vars,env),n,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v19 = $qualArg;
                
                {ESLVal _v74 = _v19;
                
                return ESLVal.list(ESLVal.list(renameJVarsExp.apply(_v74,vars,env)));
              }
              }
            }
          }).map(es).flatten().flatten());
        }
        }
        }
        }
      case "JSelf": {
          return new ESLVal("JSelf",new ESLVal[]{});
        }
      case "JRef": {ESLVal $81 = _v16.termRef(0);
          ESLVal $80 = _v16.termRef(1);
          
          {ESLVal _v72 = $81;
          
          {ESLVal n = $80;
          
          return new ESLVal("JRef",renameJVarsExp.apply(_v72,vars,env),n);
        }
        }
        }
      case "JBehaviour": {ESLVal $79 = _v16.termRef(0);
          ESLVal $78 = _v16.termRef(1);
          ESLVal $77 = _v16.termRef(2);
          ESLVal $76 = _v16.termRef(3);
          ESLVal $75 = _v16.termRef(4);
          
          {ESLVal es = $79;
          
          {ESLVal fs = $78;
          
          {ESLVal init = $77;
          
          {ESLVal handler = $76;
          
          {ESLVal time = $75;
          
          return new ESLVal("JBehaviour",es,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v18 = $qualArg;
                
                switch(_v18.termName) {
                case "JField": {ESLVal $135 = _v18.termRef(0);
                  ESLVal $134 = _v18.termRef(1);
                  ESLVal $133 = _v18.termRef(2);
                  
                  {ESLVal n = $135;
                  
                  {ESLVal t = $134;
                  
                  {ESLVal _v71 = $133;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(_v71,vars,env))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v18;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(fs).flatten().flatten(),renameJVarsExp.apply(init,vars,env),renameJVarsExp.apply(handler,vars,env),renameJVarsCommand.apply(time,vars,env));
        }
        }
        }
        }
        }
        }
      case "JTry": {ESLVal $74 = _v16.termRef(0);
          ESLVal $73 = _v16.termRef(1);
          ESLVal $72 = _v16.termRef(2);
          
          {ESLVal _v70 = $74;
          
          {ESLVal n = $73;
          
          {ESLVal c = $72;
          
          return new ESLVal("JTry",renameJVarsExp.apply(_v70,vars,env),n,renameJVarsCommand.apply(c,vars,env));
        }
        }
        }
        }
      case "JProbably": {ESLVal $71 = _v16.termRef(0);
          ESLVal $70 = _v16.termRef(1);
          ESLVal $69 = _v16.termRef(2);
          
          {ESLVal _v69 = $71;
          
          {ESLVal e1 = $70;
          
          {ESLVal e2 = $69;
          
          return new ESLVal("JProbably",renameJVarsExp.apply(_v69,vars,env),renameJVarsExp.apply(e1,vars,env),renameJVarsExp.apply(e2,vars,env));
        }
        }
        }
        }
      case "JGrab": {ESLVal $68 = _v16.termRef(0);
          ESLVal $67 = _v16.termRef(1);
          
          {ESLVal es = $68;
          
          {ESLVal c = $67;
          
          return new ESLVal("JGrab",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v17 = $qualArg;
                
                {ESLVal _v68 = _v17;
                
                return ESLVal.list(ESLVal.list(renameJVarsExp.apply(_v68,vars,env)));
              }
              }
            }
          }).map(es).flatten().flatten(),renameJVarsExp.apply(c,vars,env));
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(12236,15990)"));
      }
      }
    }
  });
  private static ESLVal nameCount = $zero;
  private static ESLVal newName = new ESLVal(new Function(new ESLVal("newName"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      {nameCount = nameCount.add($one);
      return new ESLVal("_v").add(nameCount);}
    }
  });
  private static ESLVal renameJVarsCommand = new ESLVal(new Function(new ESLVal("renameJVarsCommand"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal c = $args[0];
  ESLVal vars = $args[1];
  ESLVal env = $args[2];
  {ESLVal _v2 = c;
        
        switch(_v2.termName) {
        case "JBlock": {ESLVal $39 = _v2.termRef(0);
          
          {ESLVal v0 = $39;
          
          return new ESLVal("JBlock",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v15 = $qualArg;
                
                {ESLVal _v67 = _v15;
                
                return ESLVal.list(ESLVal.list(renameJVarsCommand.apply(_v67,vars,env)));
              }
              }
            }
          }).map(v0).flatten().flatten());
        }
        }
      case "JReturn": {ESLVal $38 = _v2.termRef(0);
          
          {ESLVal v0 = $38;
          
          return new ESLVal("JReturn",renameJVarsExp.apply(v0,vars,env));
        }
        }
      case "JSwitch": {ESLVal $37 = _v2.termRef(0);
          ESLVal $36 = _v2.termRef(1);
          ESLVal $35 = _v2.termRef(2);
          
          {ESLVal v0 = $37;
          
          {ESLVal v1 = $36;
          
          {ESLVal v2 = $35;
          
          return error(new ESLVal("jswitch should not occur"));
        }
        }
        }
        }
      case "JSwitchList": {ESLVal $34 = _v2.termRef(0);
          ESLVal $33 = _v2.termRef(1);
          ESLVal $32 = _v2.termRef(2);
          ESLVal $31 = _v2.termRef(3);
          
          {ESLVal v0 = $34;
          
          {ESLVal v1 = $33;
          
          {ESLVal v2 = $32;
          
          {ESLVal v3 = $31;
          
          return new ESLVal("JSwitchList",renameJVarsExp.apply(v0,vars,env),renameJVarsCommand.apply(v1,vars,env),renameJVarsCommand.apply(v2,vars,env),renameJVarsCommand.apply(v3,vars,env));
        }
        }
        }
        }
        }
      case "JIfCommand": {ESLVal $30 = _v2.termRef(0);
          ESLVal $29 = _v2.termRef(1);
          ESLVal $28 = _v2.termRef(2);
          
          {ESLVal v0 = $30;
          
          {ESLVal v1 = $29;
          
          {ESLVal v2 = $28;
          
          return new ESLVal("JIfCommand",renameJVarsExp.apply(v0,vars,env),renameJVarsCommand.apply(v1,vars,env),renameJVarsCommand.apply(v2,vars,env));
        }
        }
        }
        }
      case "JCaseList": {ESLVal $27 = _v2.termRef(0);
          ESLVal $26 = _v2.termRef(1);
          ESLVal $25 = _v2.termRef(2);
          ESLVal $24 = _v2.termRef(3);
          
          {ESLVal v0 = $27;
          
          {ESLVal v1 = $26;
          
          {ESLVal v2 = $25;
          
          {ESLVal v3 = $24;
          
          return new ESLVal("JCaseList",renameJVarsExp.apply(v0,vars,env),renameJVarsCommand.apply(v1,vars,env),renameJVarsCommand.apply(v2,vars,env),renameJVarsCommand.apply(v3,vars,env));
        }
        }
        }
        }
        }
      case "JCaseInt": {ESLVal $23 = _v2.termRef(0);
          ESLVal $22 = _v2.termRef(1);
          ESLVal $21 = _v2.termRef(2);
          
          {ESLVal e = $23;
          
          {ESLVal arms = $22;
          
          {ESLVal alt = $21;
          
          return new ESLVal("JCaseInt",renameJVarsExp.apply(e,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v14 = $qualArg;
                
                switch(_v14.termName) {
                case "JIArm": {ESLVal $66 = _v14.termRef(0);
                  ESLVal $65 = _v14.termRef(1);
                  
                  {ESLVal n = $66;
                  
                  {ESLVal _v66 = $65;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JIArm",n,renameJVarsCommand.apply(_v66,vars,env))));
                }
                }
                }
                default: {ESLVal _0 = _v14;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten(),renameJVarsCommand.apply(alt,vars,env));
        }
        }
        }
        }
      case "JCaseStr": {ESLVal $20 = _v2.termRef(0);
          ESLVal $19 = _v2.termRef(1);
          ESLVal $18 = _v2.termRef(2);
          
          {ESLVal e = $20;
          
          {ESLVal arms = $19;
          
          {ESLVal alt = $18;
          
          return new ESLVal("JCaseStr",renameJVarsExp.apply(e,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v13 = $qualArg;
                
                switch(_v13.termName) {
                case "JSArm": {ESLVal $64 = _v13.termRef(0);
                  ESLVal $63 = _v13.termRef(1);
                  
                  {ESLVal s = $64;
                  
                  {ESLVal _v65 = $63;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JSArm",s,renameJVarsCommand.apply(_v65,vars,env))));
                }
                }
                }
                default: {ESLVal _0 = _v13;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten(),renameJVarsCommand.apply(alt,vars,env));
        }
        }
        }
        }
      case "JCaseBool": {ESLVal $17 = _v2.termRef(0);
          ESLVal $16 = _v2.termRef(1);
          ESLVal $15 = _v2.termRef(2);
          
          {ESLVal e = $17;
          
          {ESLVal arms = $16;
          
          {ESLVal alt = $15;
          
          return new ESLVal("JCaseBool",renameJVarsExp.apply(e,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v12 = $qualArg;
                
                switch(_v12.termName) {
                case "JBArm": {ESLVal $62 = _v12.termRef(0);
                  ESLVal $61 = _v12.termRef(1);
                  
                  {ESLVal b = $62;
                  
                  {ESLVal _v64 = $61;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JBArm",b,renameJVarsCommand.apply(_v64,vars,env))));
                }
                }
                }
                default: {ESLVal _0 = _v12;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten(),renameJVarsCommand.apply(alt,vars,env));
        }
        }
        }
        }
      case "JCaseTerm": {ESLVal $14 = _v2.termRef(0);
          ESLVal $13 = _v2.termRef(1);
          ESLVal $12 = _v2.termRef(2);
          
          {ESLVal e = $14;
          
          {ESLVal arms = $13;
          
          {ESLVal alt = $12;
          
          return new ESLVal("JCaseTerm",renameJVarsExp.apply(e,vars,env),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v11 = $qualArg;
                
                switch(_v11.termName) {
                case "JTArm": {ESLVal $60 = _v11.termRef(0);
                  ESLVal $59 = _v11.termRef(1);
                  ESLVal $58 = _v11.termRef(2);
                  
                  {ESLVal n = $60;
                  
                  {ESLVal i = $59;
                  
                  {ESLVal _v63 = $58;
                  
                  return ESLVal.list(ESLVal.list(new ESLVal("JTArm",n,i,renameJVarsCommand.apply(_v63,vars,env))));
                }
                }
                }
                }
                default: {ESLVal _0 = _v11;
                  
                  return ESLVal.list();
                }
              }
              }
            }
          }).map(arms).flatten().flatten(),renameJVarsCommand.apply(alt,vars,env));
        }
        }
        }
        }
      case "JLet": {ESLVal $11 = _v2.termRef(0);
          ESLVal $10 = _v2.termRef(1);
          
          {ESLVal v0 = $11;
          
          {ESLVal v1 = $10;
          
          {ESLVal boundNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v7 = $qualArg;
                  
                  switch(_v7.termName) {
                  case "JField": {ESLVal $51 = _v7.termRef(0);
                    ESLVal $50 = _v7.termRef(1);
                    ESLVal $49 = _v7.termRef(2);
                    
                    {ESLVal n = $51;
                    
                    {ESLVal t = $50;
                    
                    {ESLVal e = $49;
                    
                    return ESLVal.list(ESLVal.list(n));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v7;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten();
          
          if(exists.apply(new ESLVal(new Function(new ESLVal("fun1025"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal n = $args[0];
        return member.apply(n,vars);
          }
        }),boundNames).boolVal)
          {ESLVal newNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v8 = $qualArg;
                    
                    {ESLVal n = _v8;
                    
                    return ESLVal.list(ESLVal.list(newName.apply()));
                  }
                  }
                }
              }).map(boundNames).flatten().flatten();
            
            {ESLVal env1 = addEntries.apply(boundNames,newNames,env);
            
            return new ESLVal("JLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v9 = $qualArg;
                  
                  switch(_v9.termName) {
                  case "JField": {ESLVal $54 = _v9.termRef(0);
                    ESLVal $53 = _v9.termRef(1);
                    ESLVal $52 = _v9.termRef(2);
                    
                    {ESLVal n = $54;
                    
                    {ESLVal t = $53;
                    
                    {ESLVal e = $52;
                    
                    return ESLVal.list(ESLVal.list(new ESLVal("JField",lookup.apply(n,env1),t,renameJVarsExp.apply(e,vars,env))));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v9;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten(),renameJVarsCommand.apply(v1,boundNames.add(vars),env1));
          }
          }
          else
            return new ESLVal("JLet",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v10 = $qualArg;
                    
                    switch(_v10.termName) {
                    case "JField": {ESLVal $57 = _v10.termRef(0);
                      ESLVal $56 = _v10.termRef(1);
                      ESLVal $55 = _v10.termRef(2);
                      
                      {ESLVal n = $57;
                      
                      {ESLVal t = $56;
                      
                      {ESLVal e = $55;
                      
                      return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(e,vars,env))));
                    }
                    }
                    }
                    }
                    default: {ESLVal _0 = _v10;
                      
                      return ESLVal.list();
                    }
                  }
                  }
                }
              }).map(v0).flatten().flatten(),renameJVarsCommand.apply(v1,boundNames.add(vars),env));
        }
        }
        }
        }
      case "JLetRec": {ESLVal $9 = _v2.termRef(0);
          ESLVal $8 = _v2.termRef(1);
          
          {ESLVal v0 = $9;
          
          {ESLVal v1 = $8;
          
          {ESLVal boundNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v3 = $qualArg;
                  
                  switch(_v3.termName) {
                  case "JField": {ESLVal $42 = _v3.termRef(0);
                    ESLVal $41 = _v3.termRef(1);
                    ESLVal $40 = _v3.termRef(2);
                    
                    {ESLVal n = $42;
                    
                    {ESLVal t = $41;
                    
                    {ESLVal e = $40;
                    
                    return ESLVal.list(ESLVal.list(n));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v3;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten();
          
          if(exists.apply(new ESLVal(new Function(new ESLVal("fun1026"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal n = $args[0];
        return member.apply(n,vars);
          }
        }),boundNames).boolVal)
          {ESLVal newNames = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v4 = $qualArg;
                    
                    {ESLVal n = _v4;
                    
                    return ESLVal.list(ESLVal.list(newName.apply()));
                  }
                  }
                }
              }).map(boundNames).flatten().flatten();
            
            {ESLVal _v62 = addEntries.apply(boundNames,newNames,env);
            
            return new ESLVal("JLetRec",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal $qualArg = $args[0];
            {ESLVal _v5 = $qualArg;
                  
                  switch(_v5.termName) {
                  case "JField": {ESLVal $45 = _v5.termRef(0);
                    ESLVal $44 = _v5.termRef(1);
                    ESLVal $43 = _v5.termRef(2);
                    
                    {ESLVal n = $45;
                    
                    {ESLVal t = $44;
                    
                    {ESLVal e = $43;
                    
                    return ESLVal.list(ESLVal.list(new ESLVal("JField",lookup.apply(n,_v62),t,renameJVarsExp.apply(e,vars,_v62))));
                  }
                  }
                  }
                  }
                  default: {ESLVal _0 = _v5;
                    
                    return ESLVal.list();
                  }
                }
                }
              }
            }).map(v0).flatten().flatten(),renameJVarsCommand.apply(v1,boundNames.add(vars),_v62));
          }
          }
          else
            return new ESLVal("JLetRec",new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal $qualArg = $args[0];
              {ESLVal _v6 = $qualArg;
                    
                    switch(_v6.termName) {
                    case "JField": {ESLVal $48 = _v6.termRef(0);
                      ESLVal $47 = _v6.termRef(1);
                      ESLVal $46 = _v6.termRef(2);
                      
                      {ESLVal n = $48;
                      
                      {ESLVal t = $47;
                      
                      {ESLVal e = $46;
                      
                      return ESLVal.list(ESLVal.list(new ESLVal("JField",n,t,renameJVarsExp.apply(e,vars,env))));
                    }
                    }
                    }
                    }
                    default: {ESLVal _0 = _v6;
                      
                      return ESLVal.list();
                    }
                  }
                  }
                }
              }).map(v0).flatten().flatten(),renameJVarsCommand.apply(v1,boundNames.add(vars),env));
        }
        }
        }
        }
      case "JStatement": {ESLVal $7 = _v2.termRef(0);
          
          {ESLVal e = $7;
          
          return new ESLVal("JStatement",renameJVarsExp.apply(e,vars,env));
        }
        }
      case "JUpdate": {ESLVal $6 = _v2.termRef(0);
          ESLVal $5 = _v2.termRef(1);
          
          {ESLVal v0 = $6;
          
          {ESLVal v1 = $5;
          
          return new ESLVal("JUpdate",v0,renameJVarsExp.apply(v1,vars,env));
        }
        }
        }
      case "JFor": {ESLVal $4 = _v2.termRef(0);
          ESLVal $3 = _v2.termRef(1);
          ESLVal $2 = _v2.termRef(2);
          ESLVal $1 = _v2.termRef(3);
          
          {ESLVal l = $4;
          
          {ESLVal n = $3;
          
          {ESLVal e = $2;
          
          {ESLVal _v61 = $1;
          
          return new ESLVal("JFor",l,n,renameJVarsExp.apply(e,vars,env),renameJVarsCommand.apply(_v61,vars,env));
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(16231,19754)"));
      }
      }
    }
  });
  public static ESLVal main = new ESLVal(new Function(new ESLVal("main"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      return new ESLVal(new BehaviourAdapter(true,getSelf(),new ESLVal("main")) {
          
          public ESLVal handle(ESLVal $m) {{ESLVal _v1 = $m;
            
            return error(new ESLVal("case error at Pos(0,0)"));
          }}
          public ESLVal get(String name) {
            switch(name) {
              
              default: throw new Error("ref illegal " + self + "." + name);
            }
          }
        public void handleTime(ESLVal $t) {
          {ESLVal n = $t;
            
            if($true.boolVal)
            {print.apply(new ESLVal("").add(emptyTable));
            stopAll.apply();}
            else
              {}
          }
        }
        public ESLVal init() {
            return $null;
          }
        });
    }
  });
public static void main(String[] args) {
    newActor(main,new ESLVal(new Actor())); 
  }
}