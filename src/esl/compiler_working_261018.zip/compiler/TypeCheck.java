package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
// import static esl.Lists.*;
import static esl.compiler.Types.*;
import static esl.Tables.*;
import java.util.function.Supplier;
public class TypeCheck {
  public static ESLVal getSelf() { return $null; }
  private static ESLVal ppPattern = new ESLVal(new Function(new ESLVal("ppPattern"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal _v767 = p;
        
        switch(_v767.termName) {
        case "PVar": {ESLVal $1898 = _v767.termRef(0);
          ESLVal $1897 = _v767.termRef(1);
          ESLVal $1896 = _v767.termRef(2);
          
          {ESLVal l = $1898;
          
          {ESLVal n = $1897;
          
          {ESLVal t = $1896;
          
          return n;
        }
        }
        }
        }
      case "PTerm": {ESLVal $1893 = _v767.termRef(0);
          ESLVal $1892 = _v767.termRef(1);
          ESLVal $1891 = _v767.termRef(2);
          ESLVal $1890 = _v767.termRef(3);
          
          if($1891.isCons())
          {ESLVal $1894 = $1891.head();
            ESLVal $1895 = $1891.tail();
            
            {ESLVal l = $1893;
            
            {ESLVal n = $1892;
            
            {ESLVal ts = $1891;
            
            {ESLVal ps = $1890;
            
            return n.add(ppTypes.apply(ts,ESLVal.list()).add(new ESLVal("").add(ppPatterns.apply(ps))));
          }
          }
          }
          }
          }
        else if($1891.isNil())
          {ESLVal l = $1893;
            
            {ESLVal n = $1892;
            
            {ESLVal ps = $1890;
            
            return n.add(ppPatterns.apply(ps));
          }
          }
          }
        else {ESLVal l = $1893;
            
            {ESLVal n = $1892;
            
            {ESLVal ts = $1891;
            
            {ESLVal ps = $1890;
            
            return n.add(ppTypes.apply(ts,ESLVal.list()).add(new ESLVal("").add(ppPatterns.apply(ps))));
          }
          }
          }
          }
        }
      case "PApplyType": {ESLVal $1889 = _v767.termRef(0);
          ESLVal $1888 = _v767.termRef(1);
          ESLVal $1887 = _v767.termRef(2);
          
          {ESLVal l = $1889;
          
          {ESLVal _v1587 = $1888;
          
          {ESLVal ts = $1887;
          
          return ppPattern.apply(_v1587).add(ppTypes.apply(ts,ESLVal.list()));
        }
        }
        }
        }
      case "PNil": {ESLVal $1886 = _v767.termRef(0);
          
          {ESLVal l = $1886;
          
          return new ESLVal("[]");
        }
        }
      case "PInt": {ESLVal $1885 = _v767.termRef(0);
          ESLVal $1884 = _v767.termRef(1);
          
          {ESLVal l = $1885;
          
          {ESLVal n = $1884;
          
          return new ESLVal("").add(n);
        }
        }
        }
      case "PBool": {ESLVal $1883 = _v767.termRef(0);
          ESLVal $1882 = _v767.termRef(1);
          
          {ESLVal l = $1883;
          
          {ESLVal b = $1882;
          
          return new ESLVal("").add(b);
        }
        }
        }
      case "PStr": {ESLVal $1881 = _v767.termRef(0);
          ESLVal $1880 = _v767.termRef(1);
          
          {ESLVal l = $1881;
          
          {ESLVal s = $1880;
          
          return s;
        }
        }
        }
      case "PCons": {ESLVal $1879 = _v767.termRef(0);
          ESLVal $1878 = _v767.termRef(1);
          ESLVal $1877 = _v767.termRef(2);
          
          {ESLVal l = $1879;
          
          {ESLVal h = $1878;
          
          {ESLVal t = $1877;
          
          return ppPattern.apply(h).add(new ESLVal(":").add(ppPattern.apply(t)));
        }
        }
        }
        }
        default: {ESLVal _v1588 = _v767;
          
          return new ESLVal("<unknown: ").add(_v1588.add(new ESLVal(">")));
        }
      }
      }
    }
  });
  private static ESLVal ppPatterns = new ESLVal(new Function(new ESLVal("ppPatterns"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal ps = $args[0];
  return map.apply(ppPattern,ps);
    }
  });
  private static ESLVal p0 = new ESLVal("Pos",$zero,$zero);
  private static ESLVal contentType = new ESLVal("UnionType",p0,ESLVal.list(new ESLVal("TermType",p0,new ESLVal("RawText"),ESLVal.list(new ESLVal("StrType",p0))),new ESLVal("TermType",p0,new ESLVal("ESLSource"),ESLVal.list(new ESLVal("StrType",p0),new ESLVal("StrType",p0))),new ESLVal("TermType",p0,new ESLVal("JavaSource"),ESLVal.list(new ESLVal("StrType",p0),new ESLVal("StrType",p0),new ESLVal("StrType",p0)))));
  private static ESLVal editMessage = new ESLVal("MessageType",p0,ESLVal.list(new ESLVal("TermType",p0,new ESLVal("Edit"),ESLVal.list(contentType))));
  private static ESLVal env0 = ESLVal.list(new ESLVal("Map",new ESLVal("edb"),new ESLVal("ActType",p0,ESLVal.list(new ESLVal("Dec",p0,new ESLVal("button"),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("StrType",p0),new ESLVal("StrType",p0),new ESLVal("StrType",p0),new ESLVal("StrType",p0),new ESLVal("FunType",p0,ESLVal.list(),new ESLVal("VoidType",p0))),new ESLVal("VoidType",p0)),$null),new ESLVal("Dec",p0,new ESLVal("display"),new ESLVal("ForallType",p0,ESLVal.list(new ESLVal("T")),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("StrType",p0),new ESLVal("VarType",p0,new ESLVal("T"))),new ESLVal("VarType",p0,new ESLVal("T")))),$null)),ESLVal.list(editMessage))),new ESLVal("Map",new ESLVal("kill"),new ESLVal("ForallType",p0,ESLVal.list(new ESLVal("T")),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("VarType",p0,new ESLVal("T"))),new ESLVal("VoidType",p0)))),new ESLVal("Map",new ESLVal("print"),new ESLVal("ForallType",p0,ESLVal.list(new ESLVal("T")),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("VarType",p0,new ESLVal("T"))),new ESLVal("VoidType",p0)))),new ESLVal("Map",new ESLVal("parse"),new ESLVal("ForallType",p0,ESLVal.list(new ESLVal("T")),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("StrType",p0)),new ESLVal("VarType",p0,new ESLVal("T"))))),new ESLVal("Map",new ESLVal("random"),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("IntType",p0)),new ESLVal("IntType",p0))),new ESLVal("Map",new ESLVal("wait"),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("IntType",p0)),new ESLVal("VoidType",p0))),new ESLVal("Map",new ESLVal("stopAll"),new ESLVal("FunType",p0,ESLVal.list(),new ESLVal("VoidType",p0))),new ESLVal("Map",new ESLVal("builtin"),new ESLVal("ForallType",p0,ESLVal.list(new ESLVal("T")),new ESLVal("FunType",p0,ESLVal.list(new ESLVal("StrType",p0),new ESLVal("StrType",p0),new ESLVal("IntType",p0)),new ESLVal("VarType",p0,new ESLVal("T"))))));
  private static ESLVal cnstrEnv0 = ESLVal.list(new ESLVal("Map",new ESLVal("Time"),new ESLVal("UnionType",p0,ESLVal.list(new ESLVal("TermType",p0,new ESLVal("Time"),ESLVal.list(new ESLVal("IntType",p0)))))));
  private static ESLVal tenv0 = ESLVal.list(new ESLVal("Map",new ESLVal("EditType"),contentType),new ESLVal("Map",new ESLVal("Time"),new ESLVal("UnionType",p0,ESLVal.list(new ESLVal("TermType",p0,new ESLVal("Time"),ESLVal.list(new ESLVal("IntType",p0)))))),new ESLVal("Map",new ESLVal("Point"),new ESLVal("UnionType",p0,ESLVal.list(new ESLVal("TermType",p0,new ESLVal("Point"),ESLVal.list(new ESLVal("IntType",p0),new ESLVal("IntType",p0)))))));
  private static ESLVal ppTypeEnv = new ESLVal(new Function(new ESLVal("ppTypeEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal env = $args[0];
  {ESLVal[] s = new ESLVal[]{new ESLVal("[")};
        
        {{
        ESLVal _v765 = env;
        while(_v765.isCons()) {
          ESLVal _v764 = _v765.headVal;
          {ESLVal _v763 = new ESLVal(new Function(new ESLVal("forp"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  {ESLVal _v766 = _v764;
                    
                    switch(_v766.termName) {
                    case "Map": {ESLVal $1876 = _v766.termRef(0);
                      ESLVal $1875 = _v766.termRef(1);
                      
                      {ESLVal n = $1876;
                      
                      {ESLVal t = $1875;
                      
                      {s[0] = s[0].add(n.add(new ESLVal("->").add(ppType.apply(t,env).add(new ESLVal(",")))));
                    return $null;}
                    }
                    }
                    }
                    default: {ESLVal $$$ = _v766;
                      
                      return $null;
                    }
                  }
                  }
                }
              });
            
            _v763.apply();
          }
          _v765 = _v765.tailVal;}
      }
      return s[0].add(new ESLVal("]"));}
      }
    }
  });
  private static ESLVal ppTypes = new ESLVal(new Function(new ESLVal("ppTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal ts = $args[0];
  ESLVal env = $args[1];
  return map.apply(ppType0.apply(env),ts);
    }
  });
  private static ESLVal getTypeName = new ESLVal(new Function(new ESLVal("getTypeName"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t0 = $args[0];
  ESLVal env = $args[1];
  {ESLVal[] name = new ESLVal[]{$null};
        
        {{
        ESLVal _v761 = env;
        while(_v761.isCons()) {
          ESLVal _v760 = _v761.headVal;
          {ESLVal _v759 = new ESLVal(new Function(new ESLVal("forp"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  {ESLVal _v762 = _v760;
                    
                    switch(_v762.termName) {
                    case "Map": {ESLVal $1874 = _v762.termRef(0);
                      ESLVal $1873 = _v762.termRef(1);
                      
                      {ESLVal n = $1874;
                      
                      {ESLVal t = $1873;
                      
                      if(typeEqual.apply(t0,t).boolVal)
                      {name[0] = n;
                      return $null;}
                      else
                        return $null;
                    }
                    }
                    }
                    default: {ESLVal $$$ = _v762;
                      
                      return $null;
                    }
                  }
                  }
                }
              });
            
            _v759.apply();
          }
          _v761 = _v761.tailVal;}
      }
      return name[0];}
      }
    }
  });
  private static ESLVal ppType0 = new ESLVal(new Function(new ESLVal("ppType0"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal env = $args[0];
  return new ESLVal(new Function(new ESLVal("fun1608"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal t = $args[0];
        return ppType.apply(t,env);
          }
        });
    }
  });
  private static ESLVal ppHandlers = new ESLVal(new Function(new ESLVal("ppHandlers"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal handlers = $args[0];
  ESLVal env = $args[1];
  {ESLVal _v758 = handlers;
        
        if(_v758.isCons())
        {ESLVal $1867 = _v758.head();
          ESLVal $1868 = _v758.tail();
          
          switch($1867.termName) {
          case "MessageType": {ESLVal $1870 = $1867.termRef(0);
            ESLVal $1869 = $1867.termRef(1);
            
            if($1869.isCons())
            {ESLVal $1871 = $1869.head();
              ESLVal $1872 = $1869.tail();
              
              {ESLVal l = $1870;
              
              {ESLVal t = $1871;
              
              {ESLVal ts = $1872;
              
              {ESLVal hs = $1868;
              
              return ppType.apply(t,env).add(new ESLVal("; ").add(ppHandlers.apply(hs,env)));
            }
            }
            }
            }
            }
          else if($1869.isNil())
            return error(new ESLVal("case error at Pos(4904,5038)"));
          else return error(new ESLVal("case error at Pos(4904,5038)"));
          }
          default: return error(new ESLVal("case error at Pos(4904,5038)"));
        }
        }
      else if(_v758.isNil())
        return new ESLVal("");
      else return error(new ESLVal("case error at Pos(4904,5038)"));
      }
    }
  });
  private static ESLVal ppType = new ESLVal(new Function(new ESLVal("ppType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  ESLVal env = $args[1];
  if(getTypeName.apply(t,env).neql($null).boolVal)
        return getTypeName.apply(t,env);
        else
          {ESLVal _v757 = t;
            
            switch(_v757.termName) {
            case "ActType": {ESLVal $1866 = _v757.termRef(0);
              ESLVal $1865 = _v757.termRef(1);
              ESLVal $1864 = _v757.termRef(2);
              
              {ESLVal l = $1866;
              
              {ESLVal decs = $1865;
              
              {ESLVal handlers = $1864;
              
              return new ESLVal("Act { ").add(ppHandlers.apply(handlers,env).add(new ESLVal(" }")));
            }
            }
            }
            }
          case "ApplyType": {ESLVal $1863 = _v757.termRef(0);
              ESLVal $1862 = _v757.termRef(1);
              ESLVal $1861 = _v757.termRef(2);
              
              {ESLVal l = $1863;
              
              {ESLVal n = $1862;
              
              {ESLVal args = $1861;
              
              return n.add(map.apply(ppType0.apply(env),args));
            }
            }
            }
            }
          case "ApplyTypeFun": {ESLVal $1860 = _v757.termRef(0);
              ESLVal $1859 = _v757.termRef(1);
              ESLVal $1858 = _v757.termRef(2);
              
              {ESLVal l = $1860;
              
              {ESLVal op = $1859;
              
              {ESLVal args = $1858;
              
              return ppType.apply(op,env).add(map.apply(ppType0.apply(env),args));
            }
            }
            }
            }
          case "ArrayType": {ESLVal $1857 = _v757.termRef(0);
              ESLVal $1856 = _v757.termRef(1);
              
              {ESLVal l = $1857;
              
              {ESLVal _v1586 = $1856;
              
              return new ESLVal("Array[").add(ppType.apply(_v1586,env).add(new ESLVal("]")));
            }
            }
            }
          case "BoolType": {ESLVal $1855 = _v757.termRef(0);
              
              {ESLVal l = $1855;
              
              return new ESLVal("Bool");
            }
            }
          case "ExtendedAct": {ESLVal $1854 = _v757.termRef(0);
              ESLVal $1853 = _v757.termRef(1);
              ESLVal $1852 = _v757.termRef(2);
              ESLVal $1851 = _v757.termRef(3);
              
              {ESLVal l = $1854;
              
              {ESLVal parent = $1853;
              
              {ESLVal decs = $1852;
              
              {ESLVal handlers = $1851;
              
              return new ESLVal("Act extends ").add(ppType.apply(parent,env).add(new ESLVal(" { ").add(ppHandlers.apply(handlers,env).add(new ESLVal(" }")))));
            }
            }
            }
            }
            }
          case "FloatType": {ESLVal $1850 = _v757.termRef(0);
              
              {ESLVal l = $1850;
              
              return new ESLVal("Float");
            }
            }
          case "FieldType": {ESLVal $1849 = _v757.termRef(0);
              ESLVal $1848 = _v757.termRef(1);
              ESLVal $1847 = _v757.termRef(2);
              
              {ESLVal l = $1849;
              
              {ESLVal n = $1848;
              
              {ESLVal _v1585 = $1847;
              
              return n.add(new ESLVal("::").add(ppType.apply(_v1585,env)));
            }
            }
            }
            }
          case "ForallType": {ESLVal $1846 = _v757.termRef(0);
              ESLVal $1845 = _v757.termRef(1);
              ESLVal $1844 = _v757.termRef(2);
              
              {ESLVal l = $1846;
              
              {ESLVal ns = $1845;
              
              {ESLVal _v1584 = $1844;
              
              return new ESLVal("Forall").add(ns.add(new ESLVal(".").add(ppType.apply(_v1584,env))));
            }
            }
            }
            }
          case "FunType": {ESLVal $1843 = _v757.termRef(0);
              ESLVal $1842 = _v757.termRef(1);
              ESLVal $1841 = _v757.termRef(2);
              
              {ESLVal l = $1843;
              
              {ESLVal d = $1842;
              
              {ESLVal r = $1841;
              
              return map.apply(ppType0.apply(env),d).add(new ESLVal("->").add(ppType.apply(r,env)));
            }
            }
            }
            }
          case "TaggedFunType": {ESLVal $1840 = _v757.termRef(0);
              ESLVal $1839 = _v757.termRef(1);
              ESLVal $1838 = _v757.termRef(2);
              ESLVal $1837 = _v757.termRef(3);
              
              {ESLVal l = $1840;
              
              {ESLVal d = $1839;
              
              {ESLVal p = $1838;
              
              {ESLVal r = $1837;
              
              return map.apply(ppType0.apply(env),d).add(new ESLVal("->").add(ppType.apply(r,env)));
            }
            }
            }
            }
            }
          case "IntType": {ESLVal $1836 = _v757.termRef(0);
              
              {ESLVal l = $1836;
              
              return new ESLVal("Int");
            }
            }
          case "ListType": {ESLVal $1835 = _v757.termRef(0);
              ESLVal $1834 = _v757.termRef(1);
              
              {ESLVal l = $1835;
              
              {ESLVal _v1583 = $1834;
              
              return new ESLVal("[").add(ppType.apply(_v1583,env).add(new ESLVal("]")));
            }
            }
            }
          case "NullType": {ESLVal $1833 = _v757.termRef(0);
              
              {ESLVal l = $1833;
              
              return new ESLVal("Null");
            }
            }
          case "RecType": {ESLVal $1832 = _v757.termRef(0);
              ESLVal $1831 = _v757.termRef(1);
              ESLVal $1830 = _v757.termRef(2);
              
              {ESLVal l = $1832;
              
              {ESLVal n = $1831;
              
              {ESLVal _v1582 = $1830;
              
              return new ESLVal("rec ").add(n.add(new ESLVal(".").add(ppType.apply(_v1582,env))));
            }
            }
            }
            }
          case "RecordType": {ESLVal $1829 = _v757.termRef(0);
              ESLVal $1828 = _v757.termRef(1);
              
              {ESLVal l = $1829;
              
              {ESLVal fs = $1828;
              
              return new ESLVal("{").add(ppTypes.apply(fs,env).add(new ESLVal("}")));
            }
            }
            }
          case "StrType": {ESLVal $1827 = _v757.termRef(0);
              
              {ESLVal l = $1827;
              
              return new ESLVal("Str");
            }
            }
          case "TermType": {ESLVal $1826 = _v757.termRef(0);
              ESLVal $1825 = _v757.termRef(1);
              ESLVal $1824 = _v757.termRef(2);
              
              {ESLVal l = $1826;
              
              {ESLVal n = $1825;
              
              {ESLVal ts = $1824;
              
              return n.add(map.apply(ppType0.apply(env),ts));
            }
            }
            }
            }
          case "TypeFun": {ESLVal $1823 = _v757.termRef(0);
              ESLVal $1822 = _v757.termRef(1);
              ESLVal $1821 = _v757.termRef(2);
              
              {ESLVal l = $1823;
              
              {ESLVal ns = $1822;
              
              {ESLVal _v1581 = $1821;
              
              return new ESLVal("Fun").add(ns.add(new ESLVal(".").add(ppType.apply(_v1581,env))));
            }
            }
            }
            }
          case "UnfoldType": {ESLVal $1820 = _v757.termRef(0);
              ESLVal $1819 = _v757.termRef(1);
              
              {ESLVal l = $1820;
              
              {ESLVal _v1580 = $1819;
              
              return new ESLVal("unfold ").add(ppType.apply(_v1580,env));
            }
            }
            }
          case "UnionType": {ESLVal $1818 = _v757.termRef(0);
              ESLVal $1817 = _v757.termRef(1);
              
              {ESLVal l = $1818;
              
              {ESLVal ts = $1817;
              
              return new ESLVal("union ").add(map.apply(ppType0.apply(env),ts));
            }
            }
            }
          case "VarType": {ESLVal $1816 = _v757.termRef(0);
              ESLVal $1815 = _v757.termRef(1);
              
              {ESLVal l = $1816;
              
              {ESLVal n = $1815;
              
              return n;
            }
            }
            }
          case "VoidType": {ESLVal $1814 = _v757.termRef(0);
              
              {ESLVal l = $1814;
              
              return new ESLVal("Void");
            }
            }
          case "UnionRef": {ESLVal $1813 = _v757.termRef(0);
              ESLVal $1812 = _v757.termRef(1);
              ESLVal $1811 = _v757.termRef(2);
              
              {ESLVal l = $1813;
              
              {ESLVal _v1579 = $1812;
              
              {ESLVal n = $1811;
              
              return ppType.apply(_v1579,env).add(new ESLVal(".").add(n));
            }
            }
            }
            }
          case "TypeClosure": {ESLVal $1810 = _v757.termRef(0);
              
              {ESLVal f = $1810;
              
              return f.add(new ESLVal(""));
            }
            }
            default: {ESLVal x = _v757;
              
              return new ESLVal("<unknown ").add(x.add(new ESLVal(">")));
            }
          }
          }
    }
  });
  private static ESLVal typeEnv = new ESLVal(new Function(new ESLVal("typeEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal defs = $args[0];
  {ESLVal _v756 = defs;
        
        if(_v756.isCons())
        {ESLVal $1800 = _v756.head();
          ESLVal $1801 = _v756.tail();
          
          switch($1800.termName) {
          case "TypeBind": {ESLVal $1809 = $1800.termRef(0);
            ESLVal $1808 = $1800.termRef(1);
            ESLVal $1807 = $1800.termRef(2);
            ESLVal $1806 = $1800.termRef(3);
            
            {ESLVal l = $1809;
            
            {ESLVal n = $1808;
            
            {ESLVal t = $1807;
            
            {ESLVal e = $1806;
            
            {ESLVal ds = $1801;
            
            return typeEnv.apply(ds).cons(new ESLVal("Map",n,t));
          }
          }
          }
          }
          }
          }
        case "DataBind": {ESLVal $1805 = $1800.termRef(0);
            ESLVal $1804 = $1800.termRef(1);
            ESLVal $1803 = $1800.termRef(2);
            ESLVal $1802 = $1800.termRef(3);
            
            {ESLVal l = $1805;
            
            {ESLVal n = $1804;
            
            {ESLVal t = $1803;
            
            {ESLVal e = $1802;
            
            {ESLVal ds = $1801;
            
            return typeEnv.apply(ds).cons(new ESLVal("Map",n,t));
          }
          }
          }
          }
          }
          }
          default: {ESLVal b = $1800;
            
            {ESLVal ds = $1801;
            
            return typeEnv.apply(ds);
          }
          }
        }
        }
      else if(_v756.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(6898,7141)"));
      }
    }
  });
  private static ESLVal cnstrEnv = new ESLVal(new Function(new ESLVal("cnstrEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal defs = $args[0];
  ESLVal env = $args[1];
  {ESLVal _v755 = defs;
        
        if(_v755.isCons())
        {ESLVal $1783 = _v755.head();
          ESLVal $1784 = _v755.tail();
          
          switch($1783.termName) {
          case "TypeBind": {ESLVal $1792 = $1783.termRef(0);
            ESLVal $1791 = $1783.termRef(1);
            ESLVal $1790 = $1783.termRef(2);
            ESLVal $1789 = $1783.termRef(3);
            
            switch($1790.termName) {
            case "RecType": {ESLVal $1797 = $1790.termRef(0);
              ESLVal $1796 = $1790.termRef(1);
              ESLVal $1795 = $1790.termRef(2);
              
              switch($1795.termName) {
              case "UnionType": {ESLVal $1799 = $1795.termRef(0);
                ESLVal $1798 = $1795.termRef(1);
                
                {ESLVal l = $1792;
                
                {ESLVal n = $1791;
                
                {ESLVal ll = $1797;
                
                {ESLVal m = $1796;
                
                {ESLVal lll = $1799;
                
                {ESLVal ts = $1798;
                
                {ESLVal e = $1789;
                
                {ESLVal ds = $1784;
                
                return getConstructors.apply(l,lookupType.apply(n,env),lookupType.apply(n,env)).add(cnstrEnv.apply(ds,env));
              }
              }
              }
              }
              }
              }
              }
              }
              }
              default: {ESLVal l = $1792;
                
                {ESLVal n = $1791;
                
                {ESLVal t = $1790;
                
                {ESLVal e = $1789;
                
                {ESLVal ds = $1784;
                
                return cnstrEnv.apply(ds,env);
              }
              }
              }
              }
              }
            }
            }
          case "UnionType": {ESLVal $1794 = $1790.termRef(0);
              ESLVal $1793 = $1790.termRef(1);
              
              {ESLVal l = $1792;
              
              {ESLVal n = $1791;
              
              {ESLVal lll = $1794;
              
              {ESLVal ts = $1793;
              
              {ESLVal e = $1789;
              
              {ESLVal ds = $1784;
              
              return getConstructors.apply(l,lookupType.apply(n,env),lookupType.apply(n,env)).add(cnstrEnv.apply(ds,env));
            }
            }
            }
            }
            }
            }
            }
            default: {ESLVal l = $1792;
              
              {ESLVal n = $1791;
              
              {ESLVal t = $1790;
              
              {ESLVal e = $1789;
              
              {ESLVal ds = $1784;
              
              return cnstrEnv.apply(ds,env);
            }
            }
            }
            }
            }
          }
          }
        case "DataBind": {ESLVal $1788 = $1783.termRef(0);
            ESLVal $1787 = $1783.termRef(1);
            ESLVal $1786 = $1783.termRef(2);
            ESLVal $1785 = $1783.termRef(3);
            
            {ESLVal l = $1788;
            
            {ESLVal n = $1787;
            
            {ESLVal t = $1786;
            
            {ESLVal e = $1785;
            
            {ESLVal ds = $1784;
            
            return getConstructors.apply(l,lookupType.apply(n,env),lookupType.apply(n,env)).add(cnstrEnv.apply(ds,env));
          }
          }
          }
          }
          }
          }
          default: {ESLVal b = $1783;
            
            {ESLVal ds = $1784;
            
            return cnstrEnv.apply(ds,env);
          }
          }
        }
        }
      else if(_v755.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(7273,7906)"));
      }
    }
  });
  private static ESLVal getConstructors = new ESLVal(new Function(new ESLVal("getConstructors"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal dataType = $args[1];
  ESLVal t = $args[2];
  {ESLVal _v753 = t;
        
        switch(_v753.termName) {
        case "RecType": {ESLVal $1779 = _v753.termRef(0);
          ESLVal $1778 = _v753.termRef(1);
          ESLVal $1777 = _v753.termRef(2);
          
          {ESLVal _v1576 = $1779;
          
          {ESLVal n = $1778;
          
          {ESLVal _v1577 = $1777;
          
          return getConstructors.apply(_v1576,dataType,_v1577);
        }
        }
        }
        }
      case "TypeFun": {ESLVal $1776 = _v753.termRef(0);
          ESLVal $1775 = _v753.termRef(1);
          ESLVal $1774 = _v753.termRef(2);
          
          {ESLVal _v1574 = $1776;
          
          {ESLVal ns = $1775;
          
          {ESLVal _v1575 = $1774;
          
          return getConstructors.apply(_v1574,dataType,_v1575);
        }
        }
        }
        }
      case "UnionType": {ESLVal $1773 = _v753.termRef(0);
          ESLVal $1772 = _v753.termRef(1);
          
          {ESLVal _v1571 = $1773;
          
          {ESLVal ts = $1772;
          
          return map.apply(new ESLVal(new Function(new ESLVal("fun1609"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1572 = $args[0];
          {ESLVal _v754 = _v1572;
                
                switch(_v754.termName) {
                case "TermType": {ESLVal $1782 = _v754.termRef(0);
                  ESLVal $1781 = _v754.termRef(1);
                  ESLVal $1780 = _v754.termRef(2);
                  
                  {ESLVal _v1573 = $1782;
                  
                  {ESLVal n = $1781;
                  
                  {ESLVal tts = $1780;
                  
                  return new ESLVal("Map",n,dataType);
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(8425,8491)"));
              }
              }
            }
          }),ts);
        }
        }
        }
        default: {ESLVal _v1578 = _v753;
          
          return error(new ESLVal("TypeError",l,new ESLVal("cannot extract constructors from ").add(ppType.apply(_v1578,ESLVal.list()))));
        }
      }
      }
    }
  });
  private static ESLVal checkFreeTypes = new ESLVal(new Function(new ESLVal("checkFreeTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  {ESLVal dom = typeEnvDom.apply(e);
        ESLVal ran = typeEnvRan.apply(e);
        
        {ESLVal freeNames = removeAll.apply(dom,flatten.apply(map.apply(typeFV,ran)));
        
        if(freeNames.eql($nil).boolVal)
        return $null;
        else
          return error(new ESLVal("TypeError",new ESLVal("Pos",$zero,$zero),new ESLVal("Unbound Types: ").add(freeNames)));
      }
      }
    }
  });
  private static ESLVal checkSingletonTypes = new ESLVal(new Function(new ESLVal("checkSingletonTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  {ESLVal _v752 = e;
        
        if(_v752.isCons())
        {ESLVal $1768 = _v752.head();
          ESLVal $1769 = _v752.tail();
          
          switch($1768.termName) {
          case "Map": {ESLVal $1771 = $1768.termRef(0);
            ESLVal $1770 = $1768.termRef(1);
            
            {ESLVal n = $1771;
            
            {ESLVal t = $1770;
            
            {ESLVal _v1570 = $1769;
            
            if(member.apply(n,typeEnvDom.apply(_v1570)).boolVal)
            return error(new ESLVal("TypeError",new ESLVal("Pos",$zero,$zero),new ESLVal("Duplicate type name: ").add(n)));
            else
              return checkSingletonTypes.apply(_v1570);
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(9195,9416)"));
        }
        }
      else if(_v752.isNil())
        return $null;
      else return error(new ESLVal("case error at Pos(9195,9416)"));
      }
    }
  });
  private static ESLVal checkSingletonConstructors = new ESLVal(new Function(new ESLVal("checkSingletonConstructors"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  {ESLVal _v751 = e;
        
        if(_v751.isCons())
        {ESLVal $1764 = _v751.head();
          ESLVal $1765 = _v751.tail();
          
          switch($1764.termName) {
          case "Map": {ESLVal $1767 = $1764.termRef(0);
            ESLVal $1766 = $1764.termRef(1);
            
            {ESLVal n = $1767;
            
            {ESLVal t = $1766;
            
            {ESLVal _v1569 = $1765;
            
            if(member.apply(n,typeEnvDom.apply(_v1569)).boolVal)
            return error(new ESLVal("Duplicate constructor name: ").add(n));
            else
              return checkSingletonConstructors.apply(_v1569);
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(9522,9737)"));
        }
        }
      else if(_v751.isNil())
        return $null;
      else return error(new ESLVal("case error at Pos(9522,9737)"));
      }
    }
  });
  private static ESLVal valueDefs = new ESLVal(new Function(new ESLVal("valueDefs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal defs = $args[0];
  {ESLVal _v750 = defs;
        
        if(_v750.isCons())
        {ESLVal $1750 = _v750.head();
          ESLVal $1751 = _v750.tail();
          
          switch($1750.termName) {
          case "TypeBind": {ESLVal $1763 = $1750.termRef(0);
            ESLVal $1762 = $1750.termRef(1);
            ESLVal $1761 = $1750.termRef(2);
            ESLVal $1760 = $1750.termRef(3);
            
            {ESLVal l = $1763;
            
            {ESLVal n = $1762;
            
            {ESLVal t = $1761;
            
            {ESLVal e = $1760;
            
            {ESLVal ds = $1751;
            
            return valueDefs.apply(ds);
          }
          }
          }
          }
          }
          }
        case "DataBind": {ESLVal $1759 = $1750.termRef(0);
            ESLVal $1758 = $1750.termRef(1);
            ESLVal $1757 = $1750.termRef(2);
            ESLVal $1756 = $1750.termRef(3);
            
            {ESLVal l1 = $1759;
            
            {ESLVal n = $1758;
            
            {ESLVal t = $1757;
            
            {ESLVal e = $1756;
            
            {ESLVal ds = $1751;
            
            return valueDefs.apply(ds);
          }
          }
          }
          }
          }
          }
        case "CnstrBind": {ESLVal $1755 = $1750.termRef(0);
            ESLVal $1754 = $1750.termRef(1);
            ESLVal $1753 = $1750.termRef(2);
            ESLVal $1752 = $1750.termRef(3);
            
            {ESLVal l1 = $1755;
            
            {ESLVal n = $1754;
            
            {ESLVal t = $1753;
            
            {ESLVal e = $1752;
            
            {ESLVal ds = $1751;
            
            return valueDefs.apply(ds);
          }
          }
          }
          }
          }
          }
          default: {ESLVal b = $1750;
            
            {ESLVal ds = $1751;
            
            return valueDefs.apply(ds).cons(b);
          }
          }
        }
        }
      else if(_v750.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(9778,10088)"));
      }
    }
  });
  private static ESLVal valueDefsToTEnv = new ESLVal(new Function(new ESLVal("valueDefsToTEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1568 = $args[0];
  ESLVal _v1567 = $args[1];
  ESLVal _v1566 = $args[2];
  ESLVal _v1565 = $args[3];
  ESLVal _v1564 = $args[4];
  {ESLVal _v749 = _v1568;
        
        if(_v749.isCons())
        {ESLVal $1736 = _v749.head();
          ESLVal $1737 = _v749.tail();
          
          switch($1736.termName) {
          case "FunBind": {ESLVal $1749 = $1736.termRef(0);
            ESLVal $1748 = $1736.termRef(1);
            ESLVal $1747 = $1736.termRef(2);
            ESLVal $1746 = $1736.termRef(3);
            ESLVal $1745 = $1736.termRef(4);
            ESLVal $1744 = $1736.termRef(5);
            ESLVal $1743 = $1736.termRef(6);
            
            {ESLVal l = $1749;
            
            {ESLVal n = $1748;
            
            {ESLVal ps = $1747;
            
            {ESLVal t = $1746;
            
            {ESLVal st = $1745;
            
            {ESLVal b = $1744;
            
            {ESLVal g = $1743;
            
            {ESLVal ds = $1737;
            
            return valueDefsToTEnv.apply(ds,_v1567,_v1566,_v1565,_v1564).cons(new ESLVal("Map",n,substTypeEnv.apply(_v1564,t)));
          }
          }
          }
          }
          }
          }
          }
          }
          }
        case "Binding": {ESLVal $1742 = $1736.termRef(0);
            ESLVal $1741 = $1736.termRef(1);
            ESLVal $1740 = $1736.termRef(2);
            ESLVal $1739 = $1736.termRef(3);
            ESLVal $1738 = $1736.termRef(4);
            
            {ESLVal l = $1742;
            
            {ESLVal n = $1741;
            
            {ESLVal t = $1740;
            
            {ESLVal st = $1739;
            
            {ESLVal e = $1738;
            
            {ESLVal ds = $1737;
            
            return valueDefsToTEnv.apply(ds,_v1567,_v1566,_v1565,_v1564).cons(new ESLVal("Map",n,substTypeEnv.apply(_v1564,t)));
          }
          }
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(10195,10881)"));
        }
        }
      else if(_v749.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(10195,10881)"));
      }
    }
  });
  public static ESLVal typeCheckModule = new ESLVal(new Function(new ESLVal("typeCheckModule"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal path = $args[0];
  {print.apply(new ESLVal("[ type check ").add(path.add(new ESLVal("]"))));
      return typeCheckModuleInternal.apply(path,emptyTable,new ESLVal(new Function(new ESLVal("fun1610"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1563 = $args[0];
        ESLVal _v1562 = $args[1];
        ESLVal _v1561 = $args[2];
        ESLVal _v1560 = $args[3];
        return $null;
          }
        }));}
    }
  });
  private static ESLVal typeCheckModuleInternal = new ESLVal(new Function(new ESLVal("typeCheckModuleInternal"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal path = $args[0];
  ESLVal cache = $args[1];
  ESLVal handler = $args[2];
  if(hasEntry.apply(path,cache).boolVal)
        {ESLVal _v748 = lookup.apply(path,cache);
          
          switch(_v748.termName) {
          case "Typed": {ESLVal $1735 = _v748.termRef(0);
            ESLVal $1734 = _v748.termRef(1);
            ESLVal $1733 = _v748.termRef(2);
            ESLVal $1732 = _v748.termRef(3);
            
            {ESLVal m = $1735;
            
            {ESLVal vEnv = $1734;
            
            {ESLVal cEnv = $1733;
            
            {ESLVal tEnv = $1732;
            
            return handler.apply(cache,vEnv,cEnv,tEnv);
          }
          }
          }
          }
          }
        case "Undefined": {
            return error(new ESLVal("recursive reference to ").add(path));
          }
          default: return error(new ESLVal("case error at Pos(11350,11584)"));
        }
        }
        else
          {ESLVal m = parse.apply(path);
            
            return typeCheckModuleCache.apply(m,addEntry.apply(path,new ESLVal("Undefined",new ESLVal[]{}),cache),new ESLVal(new Function(new ESLVal("fun1611"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v1559 = $args[0];
            ESLVal _v1558 = $args[1];
            ESLVal _v1557 = $args[2];
            ESLVal _v1556 = $args[3];
            return handler.apply(addEntry.apply(path,new ESLVal("Typed",m,_v1558,_v1557,_v1556),_v1559),_v1558,_v1557,_v1556);
              }
            }));
          }
    }
  });
  public static ESLVal typeCheckEntryPoint = new ESLVal(new Function(new ESLVal("typeCheckEntryPoint"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal module = $args[0];
  return typeCheckModuleCache.apply(module,emptyTable,new ESLVal(new Function(new ESLVal("fun1612"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1555 = $args[0];
        ESLVal _v1554 = $args[1];
        ESLVal _v1553 = $args[2];
        ESLVal _v1552 = $args[3];
        return $null;
          }
        }));
    }
  });
  private static ESLVal typeCheckModuleCache = new ESLVal(new Function(new ESLVal("typeCheckModuleCache"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal module = $args[0];
  ESLVal cache = $args[1];
  ESLVal handler = $args[2];
  return typeCheckModule0.apply(module,cache,new ESLVal(new Function(new ESLVal("fun1613"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1551 = $args[0];
        ESLVal _v1550 = $args[1];
        ESLVal _v1549 = $args[2];
        ESLVal _v1548 = $args[3];
        {ESLVal _v747 = module;
              
              switch(_v747.termName) {
              case "Module": {ESLVal $1731 = _v747.termRef(0);
                ESLVal $1730 = _v747.termRef(1);
                ESLVal $1729 = _v747.termRef(2);
                ESLVal $1728 = _v747.termRef(3);
                ESLVal $1727 = _v747.termRef(4);
                ESLVal $1726 = _v747.termRef(5);
                ESLVal $1725 = _v747.termRef(6);
                
                {ESLVal path = $1731;
                
                {ESLVal name = $1730;
                
                {ESLVal exports = $1729;
                
                {ESLVal imports = $1728;
                
                {ESLVal x = $1727;
                
                {ESLVal y = $1726;
                
                {ESLVal defs = $1725;
                
                return handler.apply(_v1551,restrictTypeEnv.apply(_v1550,exports),restrictTypeEnv.apply(_v1549,exports),restrictTypeEnv.apply(_v1548,exports));
              }
              }
              }
              }
              }
              }
              }
              }
              default: return error(new ESLVal("case error at Pos(12326,12584)"));
            }
            }
          }
        }));
    }
  });
  private static ESLVal typeCheckModule0 = new ESLVal(new Function(new ESLVal("typeCheckModule0"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal module = $args[0];
  ESLVal cache = $args[1];
  ESLVal handler = $args[2];
  LetRec letrec = new LetRec() {
        ESLVal _v1528 = new ESLVal(new Function(new ESLVal("processImports"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1537 = $args[0];
          ESLVal _v1536 = $args[1];
          ESLVal _v1535 = $args[2];
          {ESLVal _v746 = _v1537;
                
                if(_v746.isCons())
                {ESLVal $1723 = _v746.head();
                  ESLVal $1724 = _v746.tail();
                  
                  {ESLVal path = $1723;
                  
                  {ESLVal _v1538 = $1724;
                  
                  {ESLVal _v1539 = _v1538;
                  
                  return typeCheckModuleInternal.apply(path,_v1536,new ESLVal(new Function(new ESLVal("fun1614"),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      ESLVal _v1543 = $args[0];
                  ESLVal _v1542 = $args[1];
                  ESLVal _v1541 = $args[2];
                  ESLVal _v1540 = $args[3];
                  return _v1528.apply(_v1539,_v1543,new ESLVal(new Function(new ESLVal("fun1615"),getSelf()) {
                          public ESLVal apply(ESLVal... $args) {
                            ESLVal _v1547 = $args[0];
                        ESLVal _v1546 = $args[1];
                        ESLVal _v1545 = $args[2];
                        ESLVal _v1544 = $args[3];
                        return _v1535.apply(_v1547,_v1546.add(_v1542),_v1545.add(_v1541),_v1544.add(_v1540));
                          }
                        }));
                    }
                  }));
                }
                }
                }
                }
              else if(_v746.isNil())
                return _v1535.apply(_v1536,$nil,$nil,$nil);
              else return error(new ESLVal("case error at Pos(12964,13521)"));
              }
            }
          });
        ESLVal _v1527 = new ESLVal(new Function(new ESLVal("main"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              {ESLVal _v745 = module;
                
                switch(_v745.termName) {
                case "Module": {ESLVal $1722 = _v745.termRef(0);
                  ESLVal $1721 = _v745.termRef(1);
                  ESLVal $1720 = _v745.termRef(2);
                  ESLVal $1719 = _v745.termRef(3);
                  ESLVal $1718 = _v745.termRef(4);
                  ESLVal $1717 = _v745.termRef(5);
                  ESLVal $1716 = _v745.termRef(6);
                  
                  {ESLVal path = $1722;
                  
                  {ESLVal name = $1721;
                  
                  {ESLVal exports = $1720;
                  
                  {ESLVal imports = $1719;
                  
                  {ESLVal x = $1718;
                  
                  {ESLVal y = $1717;
                  
                  {ESLVal defs = $1716;
                  
                  return _v1528.apply(imports,cache,new ESLVal(new Function(new ESLVal("fun1616"),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      ESLVal _v1532 = $args[0];
                  ESLVal _v1531 = $args[1];
                  ESLVal _v1530 = $args[2];
                  ESLVal _v1529 = $args[3];
                  {ESLVal e = typeEnv.apply(defs);
                        
                        {checkDupBindings.apply(defs);
                      checkFreeTypes.apply(e.add(_v1529.add(tenv0)));
                      checkSingletonTypes.apply(e);
                      {ESLVal _v1533 = recTypes.apply(e.add(_v1529.add(tenv0)));
                        
                        {ESLVal _v1534 = cnstrEnv.apply(defs,_v1533).add(_v1530.add(cnstrEnv0));
                        
                        {checkSingletonConstructors.apply(_v1534);
                      {ESLVal valueEnv = typeCheckValues.apply(valueDefs.apply(defs),new ESLVal("NullType",p0),_v1531,_v1533,_v1534);
                        
                        return handler.apply(_v1532,valueEnv,_v1534,_v1533);
                      }}
                      }
                      }}
                      }
                    }
                  }));
                }
                }
                }
                }
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(13550,15040)"));
              }
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "_v1528": return _v1528;
            
            case "_v1527": return _v1527;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal _v1528 = letrec.get("_v1528");
      
      ESLVal _v1527 = letrec.get("_v1527");
      
        return _v1527.apply();
      
    }
  });
  private static ESLVal typeCheckValues = new ESLVal(new Function(new ESLVal("typeCheckValues"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1526 = $args[0];
  ESLVal _v1525 = $args[1];
  ESLVal _v1524 = $args[2];
  ESLVal _v1523 = $args[3];
  ESLVal _v1522 = $args[4];
  {ESLVal valueEnv = valueDefsToTEnv.apply(_v1526,_v1525,$nil,_v1522,_v1523).add(_v1524.add(env0));
        
        {{
        ESLVal _v744 = _v1526;
        while(_v744.isCons()) {
          ESLVal def = _v744.headVal;
          typeCheckDef.apply(def,_v1525,valueEnv,valueEnv,_v1522,_v1523);
          _v744 = _v744.tailVal;}
      }
      return valueEnv;}
      }
    }
  });
  private static ESLVal genericize = new ESLVal(new Function(new ESLVal("genericize"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal t = $args[1];
  if(length.apply(typeFV.apply(t)).eql($zero).boolVal)
        return t;
        else
          return new ESLVal("ForallType",l,typeFV.apply(t),t);
    }
  });
  private static ESLVal checkPatterns = new ESLVal(new Function(new ESLVal("checkPatterns"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal ps = $args[1];
  {ESLVal names = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v742 = $qualArg;
                
                {ESLVal p = _v742;
                
                return ESLVal.list(new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal _v1521 = $args[0];
                {ESLVal _v743 = _v1521;
                      
                      {ESLVal n = _v743;
                      
                      return ESLVal.list(ESLVal.list(n));
                    }
                    }
                  }
                }).map(patternNames.apply(p)).flatten().flatten());
              }
              }
            }
          }).map(ps).flatten().flatten();
        
        if(removeDups.apply(names).neql(names).boolVal)
        return error(new ESLVal("TypeError",l,new ESLVal("duplicate pattern variables")));
        else
          return $null;
      }
    }
  });
  private static ESLVal typeCheckDef = new ESLVal(new Function(new ESLVal("typeCheckDef"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1510 = $args[0];
  ESLVal _v1509 = $args[1];
  ESLVal _v1508 = $args[2];
  ESLVal _v1507 = $args[3];
  ESLVal _v1506 = $args[4];
  ESLVal _v1505 = $args[5];
  {ESLVal _v738 = _v1510;
        
        switch(_v738.termName) {
        case "FunBind": {ESLVal $1706 = _v738.termRef(0);
          ESLVal $1705 = _v738.termRef(1);
          ESLVal $1704 = _v738.termRef(2);
          ESLVal $1703 = _v738.termRef(3);
          ESLVal $1702 = _v738.termRef(4);
          ESLVal $1701 = _v738.termRef(5);
          ESLVal $1700 = _v738.termRef(6);
          
          {ESLVal l = $1706;
          
          {ESLVal n = $1705;
          
          {ESLVal ps = $1704;
          
          {ESLVal t = $1703;
          
          {ESLVal st = $1702;
          
          {ESLVal b = $1701;
          
          {ESLVal g = $1700;
          
          {checkPatterns.apply(l,ps);
        {ESLVal argTypes = map.apply(new ESLVal(new Function(new ESLVal("fun1617"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal p = $args[0];
            {ESLVal _v740 = p;
                  
                  switch(_v740.termName) {
                  case "PVar": {ESLVal $1712 = _v740.termRef(0);
                    ESLVal $1711 = _v740.termRef(1);
                    ESLVal $1710 = _v740.termRef(2);
                    
                    {ESLVal _v1515 = $1712;
                    
                    {ESLVal _v1516 = $1711;
                    
                    {ESLVal _v1517 = $1710;
                    
                    return substTypeEnv.apply(_v1505,_v1517);
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(16316,16382)"));
                }
                }
              }
            }),ps);
          ESLVal argNames = map.apply(new ESLVal(new Function(new ESLVal("fun1618"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal p = $args[0];
            {ESLVal _v739 = p;
                  
                  switch(_v739.termName) {
                  case "PVar": {ESLVal $1709 = _v739.termRef(0);
                    ESLVal $1708 = _v739.termRef(1);
                    ESLVal $1707 = _v739.termRef(2);
                    
                    {ESLVal _v1512 = $1709;
                    
                    {ESLVal _v1513 = $1708;
                    
                    {ESLVal _v1514 = $1707;
                    
                    return _v1513;
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(16456,16500)"));
                }
                }
              }
            }),ps);
          
          {ESLVal bodyType = guardedExpType.apply(l,g,b,_v1509,zipTypeEnv.apply(argNames,argTypes).add(_v1508),_v1506,_v1505);
          
          {ESLVal fType = ((Supplier<ESLVal>)() -> { 
              {ESLVal _v741 = t;
                
                switch(_v741.termName) {
                case "ForallType": {ESLVal $1715 = _v741.termRef(0);
                  ESLVal $1714 = _v741.termRef(1);
                  ESLVal $1713 = _v741.termRef(2);
                  
                  {ESLVal _v1518 = $1715;
                  
                  {ESLVal ns = $1714;
                  
                  {ESLVal _v1519 = $1713;
                  
                  return genericize.apply(_v1518,new ESLVal("FunType",_v1518,argTypes,bodyType));
                }
                }
                }
                }
                default: {ESLVal _v1520 = _v741;
                  
                  return new ESLVal("FunType",l,argTypes,bodyType);
                }
              }
              }
            }).get();
          ESLVal dType = substTypeEnv.apply(_v1505,t);
          
          if(subType.apply(fType,dType).boolVal)
          return $null;
          else
            return error(new ESLVal("TypeError",l,new ESLVal("type of ").add(n.add(new ESLVal("::").add(ppType.apply(fType,_v1505).add(new ESLVal(" does not match declaration ").add(ppType.apply(dType,_v1505))))))));
        }
        }
        }}
        }
        }
        }
        }
        }
        }
        }
        }
      case "Binding": {ESLVal $1699 = _v738.termRef(0);
          ESLVal $1698 = _v738.termRef(1);
          ESLVal $1697 = _v738.termRef(2);
          ESLVal $1696 = _v738.termRef(3);
          ESLVal $1695 = _v738.termRef(4);
          
          {ESLVal l = $1699;
          
          {ESLVal n = $1698;
          
          {ESLVal dt = $1697;
          
          {ESLVal st = $1696;
          
          {ESLVal e = $1695;
          
          {ESLVal valueType = expType.apply(e,_v1509,_v1508,_v1506,_v1505);
          
          {ESLVal valueFV = typeFV.apply(valueType);
          ESLVal declaredType = lookupType.apply(n,_v1507);
          
          {ESLVal _v1511 = ((Supplier<ESLVal>)() -> { 
              if(valueFV.eql($nil).boolVal)
                return valueType;
                else
                  return new ESLVal("ForallType",l,valueFV,valueType);
            }).get();
          
          if(subType.apply(_v1511,declaredType).boolVal)
          return $null;
          else
            return error(new ESLVal("TypeError",l,new ESLVal("type of ").add(n.add(new ESLVal(" ").add(ppType.apply(_v1511,_v1505).add(new ESLVal(" does not match declared type = ").add(ppType.apply(declaredType,_v1505))))))));
        }
        }
        }
        }
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(16130,17901)"));
      }
      }
    }
  });
  private static ESLVal guardedExpType = new ESLVal(new Function(new ESLVal("guardedExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1504 = $args[0];
  ESLVal _v1503 = $args[1];
  ESLVal _v1502 = $args[2];
  ESLVal _v1501 = $args[3];
  ESLVal _v1500 = $args[4];
  ESLVal _v1499 = $args[5];
  ESLVal _v1498 = $args[6];
  {ESLVal bt = expType.apply(_v1503,_v1501,_v1500,_v1499,_v1498);
        
        if(isBoolType.apply(bt).boolVal)
        return expType.apply(_v1502,_v1501,_v1500,_v1499,_v1498);
        else
          return error(new ESLVal("TypeError",_v1504,new ESLVal("guarded expression requires a boolean value: ").add(ppType.apply(bt,_v1498))));
      }
    }
  });
  private static ESLVal expType = new ESLVal(new Function(new ESLVal("expType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1483 = $args[0];
  ESLVal _v1482 = $args[1];
  ESLVal _v1481 = $args[2];
  ESLVal _v1480 = $args[3];
  ESLVal _v1479 = $args[4];
  {ESLVal _v736 = _v1483;
        
        switch(_v736.termName) {
        case "ActExp": {ESLVal $1694 = _v736.termRef(0);
          ESLVal $1693 = _v736.termRef(1);
          ESLVal $1692 = _v736.termRef(2);
          ESLVal $1691 = _v736.termRef(3);
          ESLVal $1690 = _v736.termRef(4);
          ESLVal $1689 = _v736.termRef(5);
          ESLVal $1688 = _v736.termRef(6);
          ESLVal $1687 = _v736.termRef(7);
          
          {ESLVal l = $1694;
          
          {ESLVal n = $1693;
          
          {ESLVal args = $1692;
          
          {ESLVal exports = $1691;
          
          {ESLVal parent = $1690;
          
          {ESLVal bindings = $1689;
          
          {ESLVal init = $1688;
          
          {ESLVal arms = $1687;
          
          return actType.apply(l,n,args,exports,bindings,init,arms,_v1482,_v1481,_v1480,_v1479);
        }
        }
        }
        }
        }
        }
        }
        }
        }
      case "Apply": {ESLVal $1686 = _v736.termRef(0);
          ESLVal $1685 = _v736.termRef(1);
          ESLVal $1684 = _v736.termRef(2);
          
          {ESLVal l = $1686;
          
          {ESLVal op = $1685;
          
          {ESLVal args = $1684;
          
          return applyType.apply(l,op,args,_v1482,_v1481,_v1480,_v1479);
        }
        }
        }
        }
      case "ApplyTypeExp": {ESLVal $1683 = _v736.termRef(0);
          ESLVal $1682 = _v736.termRef(1);
          ESLVal $1681 = _v736.termRef(2);
          
          {ESLVal l = $1683;
          
          {ESLVal _v1497 = $1682;
          
          {ESLVal ts = $1681;
          
          return applyTypeExp.apply(l,_v1497,ts,_v1482,_v1481,_v1480,_v1479);
        }
        }
        }
        }
      case "ArrayUpdate": {ESLVal $1680 = _v736.termRef(0);
          ESLVal $1679 = _v736.termRef(1);
          ESLVal $1678 = _v736.termRef(2);
          ESLVal $1677 = _v736.termRef(3);
          
          {ESLVal l = $1680;
          
          {ESLVal a = $1679;
          
          {ESLVal i = $1678;
          
          {ESLVal v = $1677;
          
          return arrayUpdateType.apply(l,a,i,v,_v1482,_v1481,_v1480,_v1479);
        }
        }
        }
        }
        }
      case "ArrayRef": {ESLVal $1676 = _v736.termRef(0);
          ESLVal $1675 = _v736.termRef(1);
          ESLVal $1674 = _v736.termRef(2);
          
          {ESLVal l = $1676;
          
          {ESLVal a = $1675;
          
          {ESLVal i = $1674;
          
          return arrayRefType.apply(l,a,i,_v1482,_v1481,_v1480,_v1479);
        }
        }
        }
        }
      case "Become": {ESLVal $1673 = _v736.termRef(0);
          ESLVal $1672 = _v736.termRef(1);
          
          {ESLVal l = $1673;
          
          {ESLVal _v1496 = $1672;
          
          return becomeType.apply(l,_v1496,_v1482,_v1481,_v1480,_v1479);
        }
        }
        }
      case "BinExp": {ESLVal $1671 = _v736.termRef(0);
          ESLVal $1670 = _v736.termRef(1);
          ESLVal $1669 = _v736.termRef(2);
          ESLVal $1668 = _v736.termRef(3);
          
          {ESLVal l = $1671;
          
          {ESLVal e1 = $1670;
          
          {ESLVal op = $1669;
          
          {ESLVal e2 = $1668;
          
          return binExpType.apply(l,e1,op,e2,_v1482,_v1481,_v1480,_v1479);
        }
        }
        }
        }
        }
      case "Block": {ESLVal $1667 = _v736.termRef(0);
          ESLVal $1666 = _v736.termRef(1);
          
          {ESLVal l = $1667;
          
          {ESLVal es = $1666;
          
          return blockType.apply(l,es,_v1482,_v1481,_v1480,_v1479);
        }
        }
        }
      case "BoolExp": {ESLVal $1665 = _v736.termRef(0);
          ESLVal $1664 = _v736.termRef(1);
          
          {ESLVal l = $1665;
          
          {ESLVal b = $1664;
          
          return new ESLVal("BoolType",l);
        }
        }
        }
      case "Case": {ESLVal $1663 = _v736.termRef(0);
          ESLVal $1662 = _v736.termRef(1);
          ESLVal $1661 = _v736.termRef(2);
          ESLVal $1660 = _v736.termRef(3);
          
          {ESLVal l = $1663;
          
          {ESLVal decs = $1662;
          
          {ESLVal es = $1661;
          
          {ESLVal arms = $1660;
          
          return caseType.apply(l,es,arms,_v1482,_v1481,_v1480,_v1479);
        }
        }
        }
        }
        }
      case "Cmp": {ESLVal $1659 = _v736.termRef(0);
          ESLVal $1658 = _v736.termRef(1);
          ESLVal $1657 = _v736.termRef(2);
          
          {ESLVal l = $1659;
          
          {ESLVal _v1495 = $1658;
          
          {ESLVal qs = $1657;
          
          return cmpType.apply(l,_v1495,qs,_v1482,_v1481,_v1480,_v1479);
        }
        }
        }
        }
      case "Grab": {ESLVal $1656 = _v736.termRef(0);
          ESLVal $1655 = _v736.termRef(1);
          ESLVal $1654 = _v736.termRef(2);
          
          {ESLVal l = $1656;
          
          {ESLVal refs = $1655;
          
          {ESLVal _v1494 = $1654;
          
          return expType.apply(_v1494,_v1482,_v1481,_v1480,_v1479);
        }
        }
        }
        }
      case "FloatExp": {ESLVal $1653 = _v736.termRef(0);
          ESLVal $1652 = _v736.termRef(1);
          
          {ESLVal l = $1653;
          
          {ESLVal f = $1652;
          
          return new ESLVal("FloatType",l);
        }
        }
        }
      case "Fold": {ESLVal $1651 = _v736.termRef(0);
          ESLVal $1650 = _v736.termRef(1);
          ESLVal $1649 = _v736.termRef(2);
          
          {ESLVal l = $1651;
          
          {ESLVal t = $1650;
          
          {ESLVal _v1493 = $1649;
          
          return foldType.apply(l,t,_v1493,_v1482,_v1481,_v1480,_v1479);
        }
        }
        }
        }
      case "For": {ESLVal $1648 = _v736.termRef(0);
          ESLVal $1647 = _v736.termRef(1);
          ESLVal $1646 = _v736.termRef(2);
          ESLVal $1645 = _v736.termRef(3);
          
          {ESLVal l = $1648;
          
          {ESLVal p = $1647;
          
          {ESLVal list = $1646;
          
          {ESLVal _v1492 = $1645;
          
          return forType.apply(l,p,list,_v1492,_v1482,_v1481,_v1480,_v1479);
        }
        }
        }
        }
        }
      case "FunExp": {ESLVal $1644 = _v736.termRef(0);
          ESLVal $1643 = _v736.termRef(1);
          ESLVal $1642 = _v736.termRef(2);
          ESLVal $1641 = _v736.termRef(3);
          ESLVal $1640 = _v736.termRef(4);
          
          {ESLVal l = $1644;
          
          {ESLVal n = $1643;
          
          {ESLVal args = $1642;
          
          {ESLVal t = $1641;
          
          {ESLVal _v1491 = $1640;
          
          return funType.apply(l,n,args,t,_v1491,_v1482,_v1481,_v1480,_v1479);
        }
        }
        }
        }
        }
        }
      case "If": {ESLVal $1639 = _v736.termRef(0);
          ESLVal $1638 = _v736.termRef(1);
          ESLVal $1637 = _v736.termRef(2);
          ESLVal $1636 = _v736.termRef(3);
          
          {ESLVal l = $1639;
          
          {ESLVal e1 = $1638;
          
          {ESLVal e2 = $1637;
          
          {ESLVal e3 = $1636;
          
          return ifType.apply(l,e1,e2,e3,_v1482,_v1481,_v1480,_v1479);
        }
        }
        }
        }
        }
      case "IntExp": {ESLVal $1635 = _v736.termRef(0);
          ESLVal $1634 = _v736.termRef(1);
          
          {ESLVal l = $1635;
          
          {ESLVal n = $1634;
          
          return new ESLVal("IntType",l);
        }
        }
        }
      case "Let": {ESLVal $1633 = _v736.termRef(0);
          ESLVal $1632 = _v736.termRef(1);
          ESLVal $1631 = _v736.termRef(2);
          
          {ESLVal l = $1633;
          
          {ESLVal bs = $1632;
          
          {ESLVal _v1490 = $1631;
          
          return letType.apply(l,bs,_v1490,_v1482,_v1481,_v1480,_v1479);
        }
        }
        }
        }
      case "Letrec": {ESLVal $1630 = _v736.termRef(0);
          ESLVal $1629 = _v736.termRef(1);
          ESLVal $1628 = _v736.termRef(2);
          
          {ESLVal l = $1630;
          
          {ESLVal bs = $1629;
          
          {ESLVal _v1489 = $1628;
          
          return letrecType.apply(l,bs,_v1489,_v1482,_v1481,_v1480,_v1479);
        }
        }
        }
        }
      case "List": {ESLVal $1627 = _v736.termRef(0);
          ESLVal $1626 = _v736.termRef(1);
          
          {ESLVal l = $1627;
          
          {ESLVal es = $1626;
          
          return listType.apply(l,es,_v1482,_v1481,_v1480,_v1479);
        }
        }
        }
      case "Now": {ESLVal $1625 = _v736.termRef(0);
          
          {ESLVal l = $1625;
          
          return new ESLVal("IntType",l);
        }
        }
      case "Probably": {ESLVal $1624 = _v736.termRef(0);
          ESLVal $1623 = _v736.termRef(1);
          ESLVal $1622 = _v736.termRef(2);
          ESLVal $1621 = _v736.termRef(3);
          ESLVal $1620 = _v736.termRef(4);
          
          {ESLVal l = $1624;
          
          {ESLVal p = $1623;
          
          {ESLVal t = $1622;
          
          {ESLVal e1 = $1621;
          
          {ESLVal e2 = $1620;
          
          return probablyType.apply(l,p,t,e1,e2,_v1482,_v1481,_v1480,_v1479);
        }
        }
        }
        }
        }
        }
      case "Record": {ESLVal $1619 = _v736.termRef(0);
          ESLVal $1618 = _v736.termRef(1);
          
          {ESLVal l = $1619;
          
          {ESLVal fields = $1618;
          
          return recordType.apply(l,fields,_v1482,_v1481,_v1480,_v1479);
        }
        }
        }
      case "Ref": {ESLVal $1617 = _v736.termRef(0);
          ESLVal $1616 = _v736.termRef(1);
          ESLVal $1615 = _v736.termRef(2);
          
          {ESLVal l = $1617;
          
          {ESLVal _v1488 = $1616;
          
          {ESLVal n = $1615;
          
          return refType.apply(l,_v1488,n,_v1482,_v1481,_v1480,_v1479);
        }
        }
        }
        }
      case "Self": {ESLVal $1614 = _v736.termRef(0);
          
          {ESLVal l = $1614;
          
          return _v1482;
        }
        }
      case "Send": {ESLVal $1609 = _v736.termRef(0);
          ESLVal $1608 = _v736.termRef(1);
          ESLVal $1607 = _v736.termRef(2);
          
          switch($1607.termName) {
          case "Term": {ESLVal $1613 = $1607.termRef(0);
            ESLVal $1612 = $1607.termRef(1);
            ESLVal $1611 = $1607.termRef(2);
            ESLVal $1610 = $1607.termRef(3);
            
            {ESLVal l = $1609;
            
            {ESLVal target = $1608;
            
            {ESLVal tl = $1613;
            
            {ESLVal n = $1612;
            
            {ESLVal ts = $1611;
            
            {ESLVal args = $1610;
            
            return sendType.apply(l,target,n,args,_v1482,_v1481,_v1480,_v1479);
          }
          }
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(18379,21779)"));
        }
        }
      case "StrExp": {ESLVal $1606 = _v736.termRef(0);
          ESLVal $1605 = _v736.termRef(1);
          
          {ESLVal l = $1606;
          
          {ESLVal s = $1605;
          
          return new ESLVal("StrType",l);
        }
        }
        }
      case "Term": {ESLVal $1604 = _v736.termRef(0);
          ESLVal $1603 = _v736.termRef(1);
          ESLVal $1602 = _v736.termRef(2);
          ESLVal $1601 = _v736.termRef(3);
          
          {ESLVal l = $1604;
          
          {ESLVal n = $1603;
          
          {ESLVal ts = $1602;
          
          {ESLVal es = $1601;
          
          return termType.apply(l,n,ts,es,_v1482,_v1481,_v1480,_v1479);
        }
        }
        }
        }
        }
      case "Throw": {ESLVal $1600 = _v736.termRef(0);
          ESLVal $1599 = _v736.termRef(1);
          ESLVal $1598 = _v736.termRef(2);
          
          {ESLVal l = $1600;
          
          {ESLVal t = $1599;
          
          {ESLVal _v1487 = $1598;
          
          return throwType.apply(l,t,_v1487,_v1482,_v1481,_v1480,_v1479);
        }
        }
        }
        }
      case "Try": {ESLVal $1597 = _v736.termRef(0);
          ESLVal $1596 = _v736.termRef(1);
          ESLVal $1595 = _v736.termRef(2);
          
          {ESLVal l = $1597;
          
          {ESLVal _v1486 = $1596;
          
          {ESLVal arms = $1595;
          
          return tryType.apply(l,_v1486,arms,_v1482,_v1481,_v1480,_v1479);
        }
        }
        }
        }
      case "New": {ESLVal $1594 = _v736.termRef(0);
          ESLVal $1593 = _v736.termRef(1);
          ESLVal $1592 = _v736.termRef(2);
          
          {ESLVal l = $1594;
          
          {ESLVal b = $1593;
          
          {ESLVal args = $1592;
          
          return newType.apply(l,b,args,_v1482,_v1481,_v1480,_v1479);
        }
        }
        }
        }
      case "NewArray": {ESLVal $1591 = _v736.termRef(0);
          ESLVal $1590 = _v736.termRef(1);
          ESLVal $1589 = _v736.termRef(2);
          
          {ESLVal l = $1591;
          
          {ESLVal t = $1590;
          
          {ESLVal i = $1589;
          
          return newArrayType.apply(l,t,i,_v1482,_v1481,_v1480,_v1479);
        }
        }
        }
        }
      case "NewJava": {ESLVal $1588 = _v736.termRef(0);
          ESLVal $1587 = _v736.termRef(1);
          ESLVal $1586 = _v736.termRef(2);
          ESLVal $1585 = _v736.termRef(3);
          
          {ESLVal l = $1588;
          
          {ESLVal path = $1587;
          
          {ESLVal t = $1586;
          
          {ESLVal args = $1585;
          
          {{
          ESLVal _v737 = args;
          while(_v737.isCons()) {
            ESLVal a = _v737.headVal;
            expType.apply(a,_v1482,_v1481,_v1480,_v1479);
            _v737 = _v737.tailVal;}
        }
        return substTypeEnv.apply(_v1479,t);}
        }
        }
        }
        }
        }
      case "Not": {ESLVal $1584 = _v736.termRef(0);
          ESLVal $1583 = _v736.termRef(1);
          
          {ESLVal l = $1584;
          
          {ESLVal _v1485 = $1583;
          
          return notType.apply(l,_v1485,_v1482,_v1481,_v1480,_v1479);
        }
        }
        }
      case "NullExp": {ESLVal $1582 = _v736.termRef(0);
          
          {ESLVal l = $1582;
          
          return new ESLVal("ForallType",l,ESLVal.list(new ESLVal("T")),new ESLVal("VarType",l,new ESLVal("T")));
        }
        }
      case "Update": {ESLVal $1581 = _v736.termRef(0);
          ESLVal $1580 = _v736.termRef(1);
          ESLVal $1579 = _v736.termRef(2);
          
          {ESLVal l = $1581;
          
          {ESLVal n = $1580;
          
          {ESLVal _v1484 = $1579;
          
          return updateType.apply(l,n,_v1484,_v1482,_v1481,_v1480,_v1479);
        }
        }
        }
        }
      case "Var": {ESLVal $1578 = _v736.termRef(0);
          ESLVal $1577 = _v736.termRef(1);
          
          {ESLVal l = $1578;
          
          {ESLVal n = $1577;
          
          return varType.apply(l,n,_v1481);
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(18379,21779)"));
      }
      }
    }
  });
  private static ESLVal throwType = new ESLVal(new Function(new ESLVal("throwType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1478 = $args[0];
  ESLVal _v1477 = $args[1];
  ESLVal _v1476 = $args[2];
  ESLVal _v1475 = $args[3];
  ESLVal _v1474 = $args[4];
  ESLVal _v1473 = $args[5];
  ESLVal _v1472 = $args[6];
  {ESLVal valType = expType.apply(_v1476,_v1475,_v1474,_v1473,_v1472);
        
        return substTypeEnv.apply(_v1472,_v1477);
      }
    }
  });
  private static ESLVal foldType = new ESLVal(new Function(new ESLVal("foldType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1471 = $args[0];
  ESLVal _v1470 = $args[1];
  ESLVal _v1469 = $args[2];
  ESLVal _v1468 = $args[3];
  ESLVal _v1467 = $args[4];
  ESLVal _v1466 = $args[5];
  ESLVal _v1465 = $args[6];
  {ESLVal eType = expType.apply(_v1469,_v1468,_v1467,_v1466,_v1465);
        
        if(typeEqual.apply(substTypeEnv.apply(_v1465,_v1470),eType).boolVal)
        return eType;
        else
          return error(new ESLVal("TypeError",_v1471,new ESLVal("fold type ").add(ppType.apply(_v1470,_v1465).add(new ESLVal(" does not equal ").add(ppType.apply(eType,_v1465))))));
      }
    }
  });
  private static ESLVal arrayUpdateType = new ESLVal(new Function(new ESLVal("arrayUpdateType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1464 = $args[0];
  ESLVal _v1463 = $args[1];
  ESLVal _v1462 = $args[2];
  ESLVal _v1461 = $args[3];
  ESLVal _v1460 = $args[4];
  ESLVal _v1459 = $args[5];
  ESLVal _v1458 = $args[6];
  ESLVal _v1457 = $args[7];
  {ESLVal aType = expType.apply(_v1463,_v1460,_v1459,_v1458,_v1457);
        ESLVal iType = expType.apply(_v1462,_v1460,_v1459,_v1458,_v1457);
        ESLVal vType = expType.apply(_v1461,_v1460,_v1459,_v1458,_v1457);
        
        {ESLVal _v735 = aType;
        
        switch(_v735.termName) {
        case "ArrayType": {ESLVal $1576 = _v735.termRef(0);
          ESLVal $1575 = _v735.termRef(1);
          
          {ESLVal al = $1576;
          
          {ESLVal t = $1575;
          
          if(isIntType.apply(iType).boolVal)
          if(typeEqual.apply(vType,t).boolVal)
            return aType;
            else
              return error(new ESLVal("TypeError",_v1464,new ESLVal("value type ").add(vType.add(new ESLVal(" does not match array type ").add(t)))));
          else
            return error(new ESLVal("TypeError",_v1464,new ESLVal("array index should be an integer ").add(_v1462)));
        }
        }
        }
        default: {ESLVal t = _v735;
          
          return error(new ESLVal("TypeError",_v1464,new ESLVal("expecting an array ").add(aType)));
        }
      }
      }
      }
    }
  });
  private static ESLVal arrayRefType = new ESLVal(new Function(new ESLVal("arrayRefType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1456 = $args[0];
  ESLVal _v1455 = $args[1];
  ESLVal _v1454 = $args[2];
  ESLVal _v1453 = $args[3];
  ESLVal _v1452 = $args[4];
  ESLVal _v1451 = $args[5];
  ESLVal _v1450 = $args[6];
  {ESLVal aType = expType.apply(_v1455,_v1453,_v1452,_v1451,_v1450);
        ESLVal iType = expType.apply(_v1454,_v1453,_v1452,_v1451,_v1450);
        
        {ESLVal _v734 = aType;
        
        switch(_v734.termName) {
        case "ArrayType": {ESLVal $1574 = _v734.termRef(0);
          ESLVal $1573 = _v734.termRef(1);
          
          {ESLVal al = $1574;
          
          {ESLVal t = $1573;
          
          if(isIntType.apply(iType).boolVal)
          return t;
          else
            return error(new ESLVal("TypeError",_v1456,new ESLVal("array index should be an integer ").add(_v1454)));
        }
        }
        }
        default: {ESLVal t = _v734;
          
          return error(new ESLVal("TypeError",_v1456,new ESLVal("expecting an array ").add(aType)));
        }
      }
      }
      }
    }
  });
  private static ESLVal newArrayType = new ESLVal(new Function(new ESLVal("newArrayType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1449 = $args[0];
  ESLVal _v1448 = $args[1];
  ESLVal _v1447 = $args[2];
  ESLVal _v1446 = $args[3];
  ESLVal _v1445 = $args[4];
  ESLVal _v1444 = $args[5];
  ESLVal _v1443 = $args[6];
  {ESLVal i = expType.apply(_v1447,_v1446,_v1445,_v1444,_v1443);
        
        if(isIntType.apply(i).boolVal)
        return new ESLVal("ArrayType",_v1449,substTypeEnv.apply(_v1443,_v1448));
        else
          return error(new ESLVal("TypeError",_v1449,new ESLVal("expecting an integer type: ").add(i)));
      }
    }
  });
  private static ESLVal becomeType = new ESLVal(new Function(new ESLVal("becomeType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1442 = $args[0];
  ESLVal _v1441 = $args[1];
  ESLVal _v1440 = $args[2];
  ESLVal _v1439 = $args[3];
  ESLVal _v1438 = $args[4];
  ESLVal _v1437 = $args[5];
  {ESLVal bType = expType.apply(_v1441,_v1440,_v1439,_v1438,_v1437);
        
        if(typeEqual.apply(bType,_v1440).boolVal)
        return bType;
        else
          return error(new ESLVal("TypeError",_v1442,new ESLVal("expecting become to match self type: ").add(ppType.apply(bType,_v1437).add(new ESLVal(" ").add(ppType.apply(_v1440,_v1437))))));
      }
    }
  });
  private static ESLVal probablyType = new ESLVal(new Function(new ESLVal("probablyType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1433 = $args[0];
  ESLVal _v1432 = $args[1];
  ESLVal _v1431 = $args[2];
  ESLVal _v1430 = $args[3];
  ESLVal _v1429 = $args[4];
  ESLVal _v1428 = $args[5];
  ESLVal _v1427 = $args[6];
  ESLVal _v1426 = $args[7];
  ESLVal _v1425 = $args[8];
  {ESLVal pt = expType.apply(_v1432,_v1428,_v1427,_v1426,_v1425);
        
        if(isIntType.apply(pt).boolVal)
        {ESLVal _v1436 = substTypeEnv.apply(_v1425,_v1431);
          ESLVal _v1435 = expType.apply(_v1430,_v1428,_v1427,_v1426,_v1425);
          ESLVal _v1434 = expType.apply(_v1429,_v1428,_v1427,_v1426,_v1425);
          
          if(typeEqual.apply(_v1436,_v1435).and(typeEqual.apply(_v1436,_v1434)).boolVal)
          return _v1436;
          else
            return error(new ESLVal("TypeError",_v1433,new ESLVal("expecting probably arm types to agree: ").add(ppType.apply(_v1435,_v1425).add(new ESLVal(" ").add(ppType.apply(_v1436,_v1425).add(new ESLVal(" ").add(ppType.apply(_v1434,_v1425))))))));
        }
        else
          return error(new ESLVal("TypeError",_v1433,new ESLVal("expecting an integer: ").add(ppType.apply(pt,_v1425))));
      }
    }
  });
  private static ESLVal newType = new ESLVal(new Function(new ESLVal("newType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1424 = $args[0];
  ESLVal _v1423 = $args[1];
  ESLVal _v1422 = $args[2];
  ESLVal _v1421 = $args[3];
  ESLVal _v1420 = $args[4];
  ESLVal _v1419 = $args[5];
  ESLVal _v1418 = $args[6];
  return expType.apply(new ESLVal("Apply",_v1424,_v1423,_v1422),_v1421,_v1420,_v1419,_v1418);
    }
  });
  private static ESLVal sendType = new ESLVal(new Function(new ESLVal("sendType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1407 = $args[0];
  ESLVal _v1406 = $args[1];
  ESLVal _v1405 = $args[2];
  ESLVal _v1404 = $args[3];
  ESLVal _v1403 = $args[4];
  ESLVal _v1402 = $args[5];
  ESLVal _v1401 = $args[6];
  ESLVal _v1400 = $args[7];
  {ESLVal _v731 = typeNF.apply(derefType.apply(expType.apply(_v1406,_v1403,_v1402,_v1401,_v1400)),_v1400);
        
        switch(_v731.termName) {
        case "ActType": {ESLVal $1552 = _v731.termRef(0);
          ESLVal $1551 = _v731.termRef(1);
          ESLVal $1550 = _v731.termRef(2);
          
          {ESLVal al = $1552;
          
          {ESLVal exports = $1551;
          
          {ESLVal handlers = $1550;
          
          LetRec letrec = new LetRec() {
          ESLVal findHandler = new ESLVal(new Function(new ESLVal("findHandler"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v1408 = $args[0];
            {ESLVal _v732 = _v1408;
                  
                  if(_v732.isCons())
                  {ESLVal $1553 = _v732.head();
                    ESLVal $1554 = _v732.tail();
                    
                    switch($1553.termName) {
                    case "MessageType": {ESLVal $1556 = $1553.termRef(0);
                      ESLVal $1555 = $1553.termRef(1);
                      
                      if($1555.isCons())
                      {ESLVal $1557 = $1555.head();
                        ESLVal $1558 = $1555.tail();
                        
                        switch($1557.termName) {
                        case "TermType": {ESLVal $1561 = $1557.termRef(0);
                          ESLVal $1560 = $1557.termRef(1);
                          ESLVal $1559 = $1557.termRef(2);
                          
                          if($1558.isCons())
                          {ESLVal $1562 = $1558.head();
                            ESLVal $1563 = $1558.tail();
                            
                            {ESLVal m = $1553;
                            
                            {ESLVal _v1409 = $1554;
                            
                            return findHandler.apply(_v1409);
                          }
                          }
                          }
                        else if($1558.isNil())
                          {ESLVal ml = $1556;
                            
                            {ESLVal tl = $1561;
                            
                            {ESLVal m = $1560;
                            
                            {ESLVal ts = $1559;
                            
                            {ESLVal rest = $1554;
                            
                            if(m.eql(_v1405).boolVal)
                            return head.apply(_v1408);
                            else
                              {ESLVal _v1410 = $1553;
                                
                                {ESLVal _v1411 = $1554;
                                
                                return findHandler.apply(_v1411);
                              }
                              }
                          }
                          }
                          }
                          }
                          }
                        else {ESLVal m = $1553;
                            
                            {ESLVal _v1412 = $1554;
                            
                            return findHandler.apply(_v1412);
                          }
                          }
                        }
                        default: {ESLVal m = $1553;
                          
                          {ESLVal _v1413 = $1554;
                          
                          return findHandler.apply(_v1413);
                        }
                        }
                      }
                      }
                    else if($1555.isNil())
                      {ESLVal m = $1553;
                        
                        {ESLVal _v1414 = $1554;
                        
                        return findHandler.apply(_v1414);
                      }
                      }
                    else {ESLVal m = $1553;
                        
                        {ESLVal _v1415 = $1554;
                        
                        return findHandler.apply(_v1415);
                      }
                      }
                    }
                    default: {ESLVal m = $1553;
                      
                      {ESLVal _v1416 = $1554;
                      
                      return findHandler.apply(_v1416);
                    }
                    }
                  }
                  }
                else if(_v732.isNil())
                  return error(new ESLVal("TypeError",_v1407,new ESLVal("cannot find message handler named ").add(_v1405)));
                else return error(new ESLVal("case error at Pos(25384,25691)"));
                }
              }
            });
          
          public ESLVal get(String name) {
            switch(name) {
              case "findHandler": return findHandler;
              
              default: throw new Error("cannot find letrec binding");
            }
            }
          };
        ESLVal findHandler = letrec.get("findHandler");
        
          {ESLVal _v733 = findHandler.apply(handlers);
          
          switch(_v733.termName) {
          case "MessageType": {ESLVal $1565 = _v733.termRef(0);
            ESLVal $1564 = _v733.termRef(1);
            
            if($1564.isCons())
            {ESLVal $1566 = $1564.head();
              ESLVal $1567 = $1564.tail();
              
              switch($1566.termName) {
              case "TermType": {ESLVal $1570 = $1566.termRef(0);
                ESLVal $1569 = $1566.termRef(1);
                ESLVal $1568 = $1566.termRef(2);
                
                if($1567.isCons())
                {ESLVal $1571 = $1567.head();
                  ESLVal $1572 = $1567.tail();
                  
                  {ESLVal m = _v733;
                  
                  return error(new ESLVal("TypeError",_v1407,new ESLVal("cannot find message handler named ").add(_v1405.add(new ESLVal(" in ").add(handlers)))));
                }
                }
              else if($1567.isNil())
                {ESLVal ml = $1565;
                  
                  {ESLVal tl = $1570;
                  
                  {ESLVal _v1417 = $1569;
                  
                  {ESLVal ts1 = $1568;
                  
                  {ESLVal ts2 = expTypes.apply(_v1404,_v1403,_v1402,_v1401,_v1400);
                  
                  if(length.apply(ts1).eql(length.apply(ts2)).boolVal)
                  if(typesEqual.apply(ts1,ts2).boolVal)
                    {expType.apply(_v1406,_v1403,_v1402,_v1401,_v1400);
                    return new ESLVal("VoidType",_v1407);}
                    else
                      return error(new ESLVal("TypeError",_v1407,new ESLVal("message argument types ").add(ppTypes.apply(ts2,_v1400).add(new ESLVal(" do not match expected types ").add(ppTypes.apply(ts1,_v1400))))));
                  else
                    return error(new ESLVal("TypeError",_v1407,new ESLVal("expecting ").add(length.apply(ts1).add(new ESLVal(" args, but received ").add(length.apply(ts2))))));
                }
                }
                }
                }
                }
              else {ESLVal m = _v733;
                  
                  return error(new ESLVal("TypeError",_v1407,new ESLVal("cannot find message handler named ").add(_v1405.add(new ESLVal(" in ").add(handlers)))));
                }
              }
              default: {ESLVal m = _v733;
                
                return error(new ESLVal("TypeError",_v1407,new ESLVal("cannot find message handler named ").add(_v1405.add(new ESLVal(" in ").add(handlers)))));
              }
            }
            }
          else if($1564.isNil())
            {ESLVal m = _v733;
              
              return error(new ESLVal("TypeError",_v1407,new ESLVal("cannot find message handler named ").add(_v1405.add(new ESLVal(" in ").add(handlers)))));
            }
          else {ESLVal m = _v733;
              
              return error(new ESLVal("TypeError",_v1407,new ESLVal("cannot find message handler named ").add(_v1405.add(new ESLVal(" in ").add(handlers)))));
            }
          }
          default: {ESLVal m = _v733;
            
            return error(new ESLVal("TypeError",_v1407,new ESLVal("cannot find message handler named ").add(_v1405.add(new ESLVal(" in ").add(handlers)))));
          }
        }
        }
        
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(25169,26519)"));
      }
      }
    }
  });
  private static ESLVal actType = new ESLVal(new Function(new ESLVal("actType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1358 = $args[0];
  ESLVal _v1357 = $args[1];
  ESLVal _v1356 = $args[2];
  ESLVal _v1355 = $args[3];
  ESLVal _v1354 = $args[4];
  ESLVal _v1353 = $args[5];
  ESLVal _v1352 = $args[6];
  ESLVal _v1351 = $args[7];
  ESLVal _v1350 = $args[8];
  ESLVal _v1349 = $args[9];
  ESLVal _v1348 = $args[10];
  LetRec letrec = new LetRec() {
        ESLVal findLoc = new ESLVal(new Function(new ESLVal("findLoc"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1391 = $args[0];
          ESLVal _v1390 = $args[1];
          {ESLVal _v730 = _v1390;
                
                if(_v730.isCons())
                {ESLVal $1536 = _v730.head();
                  ESLVal $1537 = _v730.tail();
                  
                  switch($1536.termName) {
                  case "Binding": {ESLVal $1549 = $1536.termRef(0);
                    ESLVal $1548 = $1536.termRef(1);
                    ESLVal $1547 = $1536.termRef(2);
                    ESLVal $1546 = $1536.termRef(3);
                    ESLVal $1545 = $1536.termRef(4);
                    
                    {ESLVal _v1395 = $1549;
                    
                    {ESLVal m = $1548;
                    
                    {ESLVal t = $1547;
                    
                    {ESLVal st = $1546;
                    
                    {ESLVal e = $1545;
                    
                    {ESLVal _v1396 = $1537;
                    
                    if(m.eql(_v1391).boolVal)
                    return _v1395;
                    else
                      {ESLVal b = $1536;
                        
                        {ESLVal _v1397 = $1537;
                        
                        return findLoc.apply(_v1391,_v1397);
                      }
                      }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                case "FunBind": {ESLVal $1544 = $1536.termRef(0);
                    ESLVal $1543 = $1536.termRef(1);
                    ESLVal $1542 = $1536.termRef(2);
                    ESLVal $1541 = $1536.termRef(3);
                    ESLVal $1540 = $1536.termRef(4);
                    ESLVal $1539 = $1536.termRef(5);
                    ESLVal $1538 = $1536.termRef(6);
                    
                    {ESLVal _v1392 = $1544;
                    
                    {ESLVal m = $1543;
                    
                    {ESLVal ps = $1542;
                    
                    {ESLVal t = $1541;
                    
                    {ESLVal st = $1540;
                    
                    {ESLVal g = $1539;
                    
                    {ESLVal e = $1538;
                    
                    {ESLVal _v1393 = $1537;
                    
                    if(m.eql(_v1391).boolVal)
                    return _v1392;
                    else
                      {ESLVal b = $1536;
                        
                        {ESLVal _v1394 = $1537;
                        
                        return findLoc.apply(_v1391,_v1394);
                      }
                      }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal b = $1536;
                    
                    {ESLVal _v1398 = $1537;
                    
                    return findLoc.apply(_v1391,_v1398);
                  }
                  }
                }
                }
              else if(_v730.isNil())
                return p0;
              else return error(new ESLVal("case error at Pos(27017,27321)"));
              }
            }
          });
        ESLVal findType = new ESLVal(new Function(new ESLVal("findType"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1382 = $args[0];
          ESLVal _v1381 = $args[1];
          {ESLVal _v729 = _v1381;
                
                if(_v729.isCons())
                {ESLVal $1522 = _v729.head();
                  ESLVal $1523 = _v729.tail();
                  
                  switch($1522.termName) {
                  case "Binding": {ESLVal $1535 = $1522.termRef(0);
                    ESLVal $1534 = $1522.termRef(1);
                    ESLVal $1533 = $1522.termRef(2);
                    ESLVal $1532 = $1522.termRef(3);
                    ESLVal $1531 = $1522.termRef(4);
                    
                    {ESLVal _v1386 = $1535;
                    
                    {ESLVal m = $1534;
                    
                    {ESLVal t = $1533;
                    
                    {ESLVal st = $1532;
                    
                    {ESLVal e = $1531;
                    
                    {ESLVal _v1387 = $1523;
                    
                    if(m.eql(_v1382).boolVal)
                    return substTypeEnv.apply(_v1348,t);
                    else
                      {ESLVal b = $1522;
                        
                        {ESLVal _v1388 = $1523;
                        
                        return findType.apply(_v1382,_v1388);
                      }
                      }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                case "FunBind": {ESLVal $1530 = $1522.termRef(0);
                    ESLVal $1529 = $1522.termRef(1);
                    ESLVal $1528 = $1522.termRef(2);
                    ESLVal $1527 = $1522.termRef(3);
                    ESLVal $1526 = $1522.termRef(4);
                    ESLVal $1525 = $1522.termRef(5);
                    ESLVal $1524 = $1522.termRef(6);
                    
                    {ESLVal _v1383 = $1530;
                    
                    {ESLVal m = $1529;
                    
                    {ESLVal ps = $1528;
                    
                    {ESLVal t = $1527;
                    
                    {ESLVal st = $1526;
                    
                    {ESLVal g = $1525;
                    
                    {ESLVal e = $1524;
                    
                    {ESLVal _v1384 = $1523;
                    
                    if(m.eql(_v1382).boolVal)
                    return substTypeEnv.apply(_v1348,t);
                    else
                      {ESLVal b = $1522;
                        
                        {ESLVal _v1385 = $1523;
                        
                        return findType.apply(_v1382,_v1385);
                      }
                      }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal b = $1522;
                    
                    {ESLVal _v1389 = $1523;
                    
                    return findType.apply(_v1382,_v1389);
                  }
                  }
                }
                }
              else if(_v729.isNil())
                return $null;
              else return error(new ESLVal("case error at Pos(27375,27732)"));
              }
            }
          });
        ESLVal decs = new ESLVal(new Function(new ESLVal("decs"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1377 = $args[0];
          {ESLVal _v728 = _v1377;
                
                if(_v728.isCons())
                {ESLVal $1520 = _v728.head();
                  ESLVal $1521 = _v728.tail();
                  
                  {ESLVal m = $1520;
                  
                  {ESLVal _v1378 = $1521;
                  
                  {ESLVal _v1380 = findType.apply(m,_v1354);
                  ESLVal _v1379 = findLoc.apply(m,_v1354);
                  
                  if(_v1380.eql($null).boolVal)
                  return error(new ESLVal("TypeError",_v1379,new ESLVal("cannot find exported name ").add(m)));
                  else
                    return decs.apply(_v1378).cons(new ESLVal("Dec",_v1379,m,_v1380,_v1380));
                }
                }
                }
                }
              else if(_v728.isNil())
                return $nil;
              else return error(new ESLVal("case error at Pos(27774,28105)"));
              }
            }
          });
        ESLVal getMessageTypes = new ESLVal(new Function(new ESLVal("getMessageTypes"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1374 = $args[0];
          {ESLVal _v727 = _v1374;
                
                if(_v727.isCons())
                {ESLVal $1514 = _v727.head();
                  ESLVal $1515 = _v727.tail();
                  
                  switch($1514.termName) {
                  case "BArm": {ESLVal $1519 = $1514.termRef(0);
                    ESLVal $1518 = $1514.termRef(1);
                    ESLVal $1517 = $1514.termRef(2);
                    ESLVal $1516 = $1514.termRef(3);
                    
                    {ESLVal _v1375 = $1519;
                    
                    {ESLVal ps = $1518;
                    
                    {ESLVal g = $1517;
                    
                    {ESLVal e = $1516;
                    
                    {ESLVal _v1376 = $1515;
                    
                    return getMessageTypes.apply(_v1376).cons(getMessageType.apply(ps));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(28156,28311)"));
                }
                }
              else if(_v727.isNil())
                return $nil;
              else return error(new ESLVal("case error at Pos(28156,28311)"));
              }
            }
          });
        ESLVal getMessageType = new ESLVal(new Function(new ESLVal("getMessageType"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal ps = $args[0];
          {ESLVal _v726 = ps;
                
                if(_v726.isCons())
                {ESLVal $1506 = _v726.head();
                  ESLVal $1507 = _v726.tail();
                  
                  switch($1506.termName) {
                  case "PTerm": {ESLVal $1511 = $1506.termRef(0);
                    ESLVal $1510 = $1506.termRef(1);
                    ESLVal $1509 = $1506.termRef(2);
                    ESLVal $1508 = $1506.termRef(3);
                    
                    if($1507.isCons())
                    {ESLVal $1512 = $1507.head();
                      ESLVal $1513 = $1507.tail();
                      
                      return error(new ESLVal("case error at Pos(28361,28632)"));
                    }
                  else if($1507.isNil())
                    {ESLVal pl = $1511;
                      
                      {ESLVal termName = $1510;
                      
                      {ESLVal targs = $1509;
                      
                      {ESLVal _v1373 = $1508;
                      
                      {ESLVal ts = map.apply(new ESLVal(new Function(new ESLVal("fun1619"),getSelf()) {
                          public ESLVal apply(ESLVal... $args) {
                            ESLVal p = $args[0];
                        return getPatternType.apply(_v1358,p,_v1351,_v1350,_v1349,_v1348);
                          }
                        }),_v1373);
                      
                      return new ESLVal("MessageType",pl,ESLVal.list(new ESLVal("TermType",pl,termName,ts)));
                    }
                    }
                    }
                    }
                    }
                  else return error(new ESLVal("case error at Pos(28361,28632)"));
                  }
                  default: return error(new ESLVal("case error at Pos(28361,28632)"));
                }
                }
              else if(_v726.isNil())
                return error(new ESLVal("case error at Pos(28361,28632)"));
              else return error(new ESLVal("case error at Pos(28361,28632)"));
              }
            }
          });
        ESLVal typeCheckArms = new ESLVal(new Function(new ESLVal("typeCheckArms"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1370 = $args[0];
          ESLVal _v1369 = $args[1];
          ESLVal _v1368 = $args[2];
          {ESLVal _v725 = _v1370;
                
                if(_v725.isCons())
                {ESLVal $1500 = _v725.head();
                  ESLVal $1501 = _v725.tail();
                  
                  switch($1500.termName) {
                  case "BArm": {ESLVal $1505 = $1500.termRef(0);
                    ESLVal $1504 = $1500.termRef(1);
                    ESLVal $1503 = $1500.termRef(2);
                    ESLVal $1502 = $1500.termRef(3);
                    
                    {ESLVal _v1371 = $1505;
                    
                    {ESLVal ps = $1504;
                    
                    {ESLVal g = $1503;
                    
                    {ESLVal e = $1502;
                    
                    {ESLVal _v1372 = $1501;
                    
                    {typeCheckArm.apply(_v1371,ps,g,e,_v1369,_v1368);
                  return typeCheckArms.apply(_v1372,_v1369,_v1368);}
                  }
                  }
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(28708,28935)"));
                }
                }
              else if(_v725.isNil())
                return $null;
              else return error(new ESLVal("case error at Pos(28708,28935)"));
              }
            }
          });
        ESLVal typeCheckArm = new ESLVal(new Function(new ESLVal("typeCheckArm"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1364 = $args[0];
          ESLVal _v1363 = $args[1];
          ESLVal _v1362 = $args[2];
          ESLVal _v1361 = $args[3];
          ESLVal _v1360 = $args[4];
          ESLVal _v1359 = $args[5];
          {ESLVal _v724 = _v1363;
                
                if(_v724.isCons())
                {ESLVal $1492 = _v724.head();
                  ESLVal $1493 = _v724.tail();
                  
                  switch($1492.termName) {
                  case "PTerm": {ESLVal $1497 = $1492.termRef(0);
                    ESLVal $1496 = $1492.termRef(1);
                    ESLVal $1495 = $1492.termRef(2);
                    ESLVal $1494 = $1492.termRef(3);
                    
                    if($1493.isCons())
                    {ESLVal $1498 = $1493.head();
                      ESLVal $1499 = $1493.tail();
                      
                      return error(new ESLVal("case error at Pos(29034,29483)"));
                    }
                  else if($1493.isNil())
                    {ESLVal pl = $1497;
                      
                      {ESLVal termName = $1496;
                      
                      {ESLVal targs = $1495;
                      
                      {ESLVal _v1365 = $1494;
                      
                      {ESLVal ts = map.apply(new ESLVal(new Function(new ESLVal("fun1620"),getSelf()) {
                          public ESLVal apply(ESLVal... $args) {
                            ESLVal p = $args[0];
                        return getPatternType.apply(_v1364,p,_v1360,_v1359,_v1349,_v1348);
                          }
                        }),_v1365);
                      
                      {patternTypes.apply(_v1364,_v1365,ts,_v1360,_v1359,_v1349,_v1348,new ESLVal(new Function(new ESLVal("fun1621"),getSelf()) {
                      public ESLVal apply(ESLVal... $args) {
                        ESLVal _v1367 = $args[0];
                    ESLVal _v1366 = $args[1];
                    return expType.apply(_v1361,_v1360,_v1366,_v1349,_v1348);
                      }
                    }));
                    return $null;}
                    }
                    }
                    }
                    }
                    }
                  else return error(new ESLVal("case error at Pos(29034,29483)"));
                  }
                  default: return error(new ESLVal("case error at Pos(29034,29483)"));
                }
                }
              else if(_v724.isNil())
                return error(new ESLVal("case error at Pos(29034,29483)"));
              else return error(new ESLVal("case error at Pos(29034,29483)"));
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "findLoc": return findLoc;
            
            case "findType": return findType;
            
            case "decs": return decs;
            
            case "getMessageTypes": return getMessageTypes;
            
            case "getMessageType": return getMessageType;
            
            case "typeCheckArms": return typeCheckArms;
            
            case "typeCheckArm": return typeCheckArm;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal findLoc = letrec.get("findLoc");
      
      ESLVal findType = letrec.get("findType");
      
      ESLVal decs = letrec.get("decs");
      
      ESLVal getMessageTypes = letrec.get("getMessageTypes");
      
      ESLVal getMessageType = letrec.get("getMessageType");
      
      ESLVal typeCheckArms = letrec.get("typeCheckArms");
      
      ESLVal typeCheckArm = letrec.get("typeCheckArm");
      
        {ESLVal localEnv = parBind.apply(_v1354,_v1351,_v1350,_v1349,_v1348);
        
        {ESLVal exportedDecs = decs.apply(_v1355);
        
        {ESLVal messageTypes = getMessageTypes.apply(_v1352);
        
        {ESLVal _v1399 = new ESLVal("ActType",_v1358,exportedDecs,messageTypes);
        
        {typeCheckValues.apply(valueDefs.apply(_v1354),_v1399,localEnv.add(_v1350),_v1348,_v1349);
      expType.apply(_v1353,_v1399,localEnv.add(_v1350),_v1349,_v1348);
      typeCheckArms.apply(_v1352,_v1399,localEnv.add(_v1350));
      return _v1399;}
      }
      }
      }
      }
      
    }
  });
  private static ESLVal cmpType = new ESLVal(new Function(new ESLVal("cmpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1340 = $args[0];
  ESLVal _v1339 = $args[1];
  ESLVal _v1338 = $args[2];
  ESLVal _v1337 = $args[3];
  ESLVal _v1336 = $args[4];
  ESLVal _v1335 = $args[5];
  ESLVal _v1334 = $args[6];
  {ESLVal _v722 = _v1338;
        
        if(_v722.isCons())
        {ESLVal $1483 = _v722.head();
          ESLVal $1484 = _v722.tail();
          
          switch($1483.termName) {
          case "BQual": {ESLVal $1489 = $1483.termRef(0);
            ESLVal $1488 = $1483.termRef(1);
            ESLVal $1487 = $1483.termRef(2);
            
            {ESLVal _v1343 = $1489;
            
            {ESLVal p = $1488;
            
            {ESLVal list = $1487;
            
            {ESLVal _v1344 = $1484;
            
            {ESLVal lType = expType.apply(list,_v1337,_v1336,_v1335,_v1334);
            
            {ESLVal _v723 = lType;
            
            switch(_v723.termName) {
            case "ListType": {ESLVal $1491 = _v723.termRef(0);
              ESLVal $1490 = _v723.termRef(1);
              
              {ESLVal ll = $1491;
              
              {ESLVal t = $1490;
              
              {ESLVal _v1345 = _v1344;
              
              return patternType.apply(_v1343,p,substTypeEnv.apply(_v1334,t),_v1337,_v1336,_v1335,_v1334,new ESLVal(new Function(new ESLVal("fun1622"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal _v1347 = $args[0];
              ESLVal _v1346 = $args[1];
              return cmpType.apply(_v1343,_v1339,_v1345,_v1337,_v1346,_v1335,_v1334);
                }
              }));
            }
            }
            }
            }
            default: {ESLVal t = _v723;
              
              return error(new ESLVal("TypeError",_v1343,new ESLVal("qualifier binding expects a list: ").add(ppType.apply(t,_v1334))));
            }
          }
          }
          }
          }
          }
          }
          }
          }
        case "PQual": {ESLVal $1486 = $1483.termRef(0);
            ESLVal $1485 = $1483.termRef(1);
            
            {ESLVal _v1341 = $1486;
            
            {ESLVal b = $1485;
            
            {ESLVal _v1342 = $1484;
            
            {ESLVal bType = expType.apply(b,_v1337,_v1336,_v1335,_v1334);
            
            if(isBoolType.apply(bType).boolVal)
            return cmpType.apply(_v1341,_v1339,_v1342,_v1337,_v1336,_v1335,_v1334);
            else
              return error(new ESLVal("TypeError",_v1341,new ESLVal("qualifier expects a boolean type: ").add(ppType.apply(bType,_v1334))));
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(30095,31081)"));
        }
        }
      else if(_v722.isNil())
        {ESLVal t = expType.apply(_v1339,_v1337,_v1336,_v1335,_v1334);
          
          return new ESLVal("ListType",_v1340,t);
        }
      else return error(new ESLVal("case error at Pos(30095,31081)"));
      }
    }
  });
  private static ESLVal updateType = new ESLVal(new Function(new ESLVal("updateType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1333 = $args[0];
  ESLVal _v1332 = $args[1];
  ESLVal _v1331 = $args[2];
  ESLVal _v1330 = $args[3];
  ESLVal _v1329 = $args[4];
  ESLVal _v1328 = $args[5];
  ESLVal _v1327 = $args[6];
  {ESLVal t = lookupType.apply(_v1332,_v1329);
        
        if(t.eql($null).boolVal)
        return error(new ESLVal("TypeError",_v1333,new ESLVal("unbound variable ").add(_v1332)));
        else
          {ESLVal valueType = expType.apply(_v1331,_v1330,_v1329,_v1328,_v1327);
            
            if(typeEqual.apply(valueType,t).boolVal)
            return valueType;
            else
              return error(new ESLVal("TypeError",_v1333,new ESLVal("type of variable ").add(_v1332.add(new ESLVal("::").add(ppType.apply(t,_v1327).add(new ESLVal(" does not agree with value type ").add(ppType.apply(valueType,_v1327))))))));
          }
      }
    }
  });
  private static ESLVal letType = new ESLVal(new Function(new ESLVal("letType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1326 = $args[0];
  ESLVal _v1325 = $args[1];
  ESLVal _v1324 = $args[2];
  ESLVal _v1323 = $args[3];
  ESLVal _v1322 = $args[4];
  ESLVal _v1321 = $args[5];
  ESLVal _v1320 = $args[6];
  {ESLVal env = parBind.apply(_v1325,_v1323,_v1322,_v1321,_v1320);
        
        {{
        ESLVal _v721 = _v1325;
        while(_v721.isCons()) {
          ESLVal b = _v721.headVal;
          typeCheckDef.apply(b,_v1323,_v1322,env.add(_v1322),_v1321,_v1320);
          _v721 = _v721.tailVal;}
      }
      return expType.apply(_v1324,_v1323,env.add(_v1322),_v1321,_v1320);}
      }
    }
  });
  private static ESLVal letrecType = new ESLVal(new Function(new ESLVal("letrecType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1319 = $args[0];
  ESLVal _v1318 = $args[1];
  ESLVal _v1317 = $args[2];
  ESLVal _v1316 = $args[3];
  ESLVal _v1315 = $args[4];
  ESLVal _v1314 = $args[5];
  ESLVal _v1313 = $args[6];
  {ESLVal env = recBind.apply(_v1318,_v1316,_v1315,_v1314,_v1313);
        
        {{
        ESLVal _v720 = _v1318;
        while(_v720.isCons()) {
          ESLVal b = _v720.headVal;
          typeCheckDef.apply(b,_v1316,env.add(_v1315),env.add(_v1315),_v1314,_v1313);
          _v720 = _v720.tailVal;}
      }
      return expType.apply(_v1317,_v1316,env.add(_v1315),_v1314,_v1313);}
      }
    }
  });
  private static ESLVal checkDupBindings = new ESLVal(new Function(new ESLVal("checkDupBindings"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal bs = $args[0];
  {ESLVal _v718 = bs;
        
        if(_v718.isCons())
        {ESLVal $1481 = _v718.head();
          ESLVal $1482 = _v718.tail();
          
          {ESLVal b = $1481;
          
          {ESLVal _v1311 = $1482;
          
          if(member.apply(bindingName.apply(b),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v719 = $qualArg;
              
              {ESLVal _v1312 = _v719;
              
              return ESLVal.list(ESLVal.list(bindingName.apply(_v1312)));
            }
            }
          }
        }).map(_v1311).flatten().flatten()).boolVal)
          return error(new ESLVal("TypeError",bindingLoc.apply(b),new ESLVal("duplicate definitions for ").add(bindingName.apply(b))));
          else
            return checkDupBindings.apply(_v1311);
        }
        }
        }
      else if(_v718.isNil())
        return $null;
      else return error(new ESLVal("case error at Pos(32329,32594)"));
      }
    }
  });
  private static ESLVal parBind = new ESLVal(new Function(new ESLVal("parBind"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1310 = $args[0];
  ESLVal _v1309 = $args[1];
  ESLVal _v1308 = $args[2];
  ESLVal _v1307 = $args[3];
  ESLVal _v1306 = $args[4];
  {checkDupBindings.apply(_v1310);
      return valueDefsToTEnv.apply(valueDefs.apply(_v1310),_v1309,_v1308,_v1307,_v1306);}
    }
  });
  private static ESLVal recBind = new ESLVal(new Function(new ESLVal("recBind"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1305 = $args[0];
  ESLVal _v1304 = $args[1];
  ESLVal _v1303 = $args[2];
  ESLVal _v1302 = $args[3];
  ESLVal _v1301 = $args[4];
  return valueDefsToTEnv.apply(valueDefs.apply(_v1305),_v1304,_v1303,_v1302,_v1301);
    }
  });
  private static ESLVal caseType = new ESLVal(new Function(new ESLVal("caseType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1300 = $args[0];
  ESLVal _v1299 = $args[1];
  ESLVal _v1298 = $args[2];
  ESLVal _v1297 = $args[3];
  ESLVal _v1296 = $args[4];
  ESLVal _v1295 = $args[5];
  ESLVal _v1294 = $args[6];
  {ESLVal ts1 = expTypes.apply(_v1299,_v1297,_v1296,_v1295,_v1294);
        
        {ESLVal ts2 = armTypes.apply(_v1298,ts1,_v1297,_v1296,_v1295,_v1294);
        
        if(allEqualTypes.apply(head.apply(ts2),tail.apply(ts2)).boolVal)
        return head.apply(ts2);
        else
          return error(new ESLVal("TypeError",_v1300,new ESLVal("case arm types do not agree: ").add(ppTypes.apply(ts1,_v1294).add(new ESLVal(" ").add(ppTypes.apply(ts2,_v1294))))));
      }
      }
    }
  });
  private static ESLVal tryType = new ESLVal(new Function(new ESLVal("tryType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1293 = $args[0];
  ESLVal _v1292 = $args[1];
  ESLVal _v1291 = $args[2];
  ESLVal _v1290 = $args[3];
  ESLVal _v1289 = $args[4];
  ESLVal _v1288 = $args[5];
  ESLVal _v1287 = $args[6];
  {ESLVal ts1 = expTypes.apply(ESLVal.list(_v1292),_v1290,_v1289,_v1288,_v1287);
        
        {ESLVal ts2 = armTypes.apply(_v1291,ts1,_v1290,_v1289,_v1288,_v1287);
        
        if(allEqualTypes.apply(head.apply(ts2),tail.apply(ts2)).boolVal)
        return head.apply(ts2);
        else
          return error(new ESLVal("TypeError",_v1293,new ESLVal("try arm types do not agree: ").add(ppTypes.apply(ts1,_v1287).add(new ESLVal(" ").add(ppTypes.apply(ts2,_v1287))))));
      }
      }
    }
  });
  private static ESLVal armTypes = new ESLVal(new Function(new ESLVal("armTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1285 = $args[0];
  ESLVal _v1284 = $args[1];
  ESLVal _v1283 = $args[2];
  ESLVal _v1282 = $args[3];
  ESLVal _v1281 = $args[4];
  ESLVal _v1280 = $args[5];
  {ESLVal _v717 = _v1285;
        
        if(_v717.isCons())
        {ESLVal $1479 = _v717.head();
          ESLVal $1480 = _v717.tail();
          
          {ESLVal a = $1479;
          
          {ESLVal _v1286 = $1480;
          
          return armTypes.apply(_v1286,_v1284,_v1283,_v1282,_v1281,_v1280).cons(armType.apply(a,_v1284,_v1283,_v1282,_v1281,_v1280));
        }
        }
        }
      else if(_v717.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(33959,34128)"));
      }
    }
  });
  private static ESLVal armType = new ESLVal(new Function(new ESLVal("armType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1277 = $args[0];
  ESLVal _v1276 = $args[1];
  ESLVal _v1275 = $args[2];
  ESLVal _v1274 = $args[3];
  ESLVal _v1273 = $args[4];
  ESLVal _v1272 = $args[5];
  {ESLVal _v716 = _v1277;
        
        switch(_v716.termName) {
        case "BArm": {ESLVal $1478 = _v716.termRef(0);
          ESLVal $1477 = _v716.termRef(1);
          ESLVal $1476 = _v716.termRef(2);
          ESLVal $1475 = _v716.termRef(3);
          
          {ESLVal l = $1478;
          
          {ESLVal ps = $1477;
          
          {ESLVal guard = $1476;
          
          {ESLVal exp = $1475;
          
          {checkPatterns.apply(l,ps);
        if(length.apply(ps).eql(length.apply(_v1276)).boolVal)
          return patternTypes.apply(l,ps,_v1276,_v1275,_v1274,_v1273,_v1272,new ESLVal(new Function(new ESLVal("fun1623"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v1279 = $args[0];
            ESLVal _v1278 = $args[1];
            return guardedExpType.apply(l,guard,exp,_v1275,_v1278,_v1273,_v1272);
              }
            }));
          else
            return error(new ESLVal("TypeError",l,new ESLVal("number of patterns ").add(length.apply(ps).add(new ESLVal(" does not match supplied values: ").add(length.apply(_v1276))))));}
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(34230,34691)"));
      }
      }
    }
  });
  private static ESLVal refType = new ESLVal(new Function(new ESLVal("refType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1256 = $args[0];
  ESLVal _v1255 = $args[1];
  ESLVal _v1254 = $args[2];
  ESLVal _v1253 = $args[3];
  ESLVal _v1252 = $args[4];
  ESLVal _v1251 = $args[5];
  ESLVal _v1250 = $args[6];
  LetRec letrec = new LetRec() {
        ESLVal t = derefType.apply(expType.apply(_v1255,_v1253,_v1252,_v1251,_v1250));
        ESLVal findExport = new ESLVal(new Function(new ESLVal("findExport"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal decs = $args[0];
          {ESLVal _v714 = decs;
                
                if(_v714.isCons())
                {ESLVal $1461 = _v714.head();
                  ESLVal $1462 = _v714.tail();
                  
                  switch($1461.termName) {
                  case "Dec": {ESLVal $1466 = $1461.termRef(0);
                    ESLVal $1465 = $1461.termRef(1);
                    ESLVal $1464 = $1461.termRef(2);
                    ESLVal $1463 = $1461.termRef(3);
                    
                    {ESLVal _v1262 = $1466;
                    
                    {ESLVal m = $1465;
                    
                    {ESLVal t = $1464;
                    
                    {ESLVal st = $1463;
                    
                    {ESLVal _v1263 = $1462;
                    
                    if(m.eql(_v1254).boolVal)
                    return t;
                    else
                      {ESLVal d = $1461;
                        
                        {ESLVal _v1264 = $1462;
                        
                        return findExport.apply(_v1264);
                      }
                      }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal d = $1461;
                    
                    {ESLVal _v1265 = $1462;
                    
                    return findExport.apply(_v1265);
                  }
                  }
                }
                }
              else if(_v714.isNil())
                return $null;
              else return error(new ESLVal("case error at Pos(34919,35092)"));
              }
            }
          });
        ESLVal findField = new ESLVal(new Function(new ESLVal("findField"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal fs = $args[0];
          {ESLVal _v713 = fs;
                
                if(_v713.isCons())
                {ESLVal $1456 = _v713.head();
                  ESLVal $1457 = _v713.tail();
                  
                  switch($1456.termName) {
                  case "FieldType": {ESLVal $1460 = $1456.termRef(0);
                    ESLVal $1459 = $1456.termRef(1);
                    ESLVal $1458 = $1456.termRef(2);
                    
                    {ESLVal _v1257 = $1460;
                    
                    {ESLVal m = $1459;
                    
                    {ESLVal t = $1458;
                    
                    {ESLVal _v1258 = $1457;
                    
                    if(m.eql(_v1254).boolVal)
                    return t;
                    else
                      {ESLVal _v1259 = $1456;
                        
                        {ESLVal _v1260 = $1457;
                        
                        return findField.apply(_v1260);
                      }
                      }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal t = $1456;
                    
                    {ESLVal _v1261 = $1457;
                    
                    return findField.apply(_v1261);
                  }
                  }
                }
                }
              else if(_v713.isNil())
                return error(new ESLVal("TypeError",_v1256,new ESLVal("cannot find field name ").add(_v1254)));
              else return error(new ESLVal("case error at Pos(35133,35338)"));
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "t": return t;
            
            case "findExport": return findExport;
            
            case "findField": return findField;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal t = letrec.get("t");
      
      ESLVal findExport = letrec.get("findExport");
      
      ESLVal findField = letrec.get("findField");
      
        {ESLVal _v715 = typeNF.apply(t,_v1250);
        
        switch(_v715.termName) {
        case "StrType": {ESLVal $1474 = _v715.termRef(0);
          
          {ESLVal sl = $1474;
          
          if(_v1254.eql(new ESLVal("explode")).boolVal)
          return new ESLVal("ListType",sl,new ESLVal("IntType",sl));
          else
            {ESLVal _v1269 = $1474;
              
              if(_v1254.eql(new ESLVal("writeDate")).boolVal)
              return new ESLVal("FloatType",_v1269);
              else
                {ESLVal _v1270 = _v715;
                  
                  return error(new ESLVal("TypeError",_v1256,new ESLVal("expecting a record type, but received ").add(ppType.apply(_v1270,_v1250))));
                }
            }
        }
        }
      case "ListType": {ESLVal $1473 = _v715.termRef(0);
          ESLVal $1472 = _v715.termRef(1);
          
          {ESLVal ll = $1473;
          
          {ESLVal _v1267 = $1472;
          
          if(_v1254.eql(new ESLVal("implode")).boolVal)
          return new ESLVal("StrType",ll);
          else
            {ESLVal _v1268 = _v715;
              
              return error(new ESLVal("TypeError",_v1256,new ESLVal("expecting a record type, but received ").add(ppType.apply(_v1268,_v1250))));
            }
        }
        }
        }
      case "RecordType": {ESLVal $1471 = _v715.termRef(0);
          ESLVal $1470 = _v715.termRef(1);
          
          {ESLVal rl = $1471;
          
          {ESLVal fs = $1470;
          
          return findField.apply(fs);
        }
        }
        }
      case "ActType": {ESLVal $1469 = _v715.termRef(0);
          ESLVal $1468 = _v715.termRef(1);
          ESLVal $1467 = _v715.termRef(2);
          
          {ESLVal al = $1469;
          
          {ESLVal exports = $1468;
          
          {ESLVal handlers = $1467;
          
          {ESLVal _v1266 = findExport.apply(exports);
          
          if(_v1266.eql($null).boolVal)
          return error(new ESLVal("TypeError",_v1256,new ESLVal("behaviour type does not export ").add(_v1254)));
          else
            return substTypeEnv.apply(_v1250,_v1266);
        }
        }
        }
        }
        }
        default: {ESLVal _v1271 = _v715;
          
          return error(new ESLVal("TypeError",_v1256,new ESLVal("expecting a record type, but received ").add(ppType.apply(_v1271,_v1250))));
        }
      }
      }
      
    }
  });
  private static ESLVal derefType = new ESLVal(new Function(new ESLVal("derefType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v712 = t;
        
        switch(_v712.termName) {
        case "TypeClosure": {ESLVal $1455 = _v712.termRef(0);
          
          {ESLVal f = $1455;
          
          return derefType.apply(f.apply());
        }
        }
        default: {ESLVal _v1249 = _v712;
          
          return _v1249;
        }
      }
      }
    }
  });
  private static ESLVal recordType = new ESLVal(new Function(new ESLVal("recordType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1243 = $args[0];
  ESLVal _v1242 = $args[1];
  ESLVal _v1241 = $args[2];
  ESLVal _v1240 = $args[3];
  ESLVal _v1239 = $args[4];
  ESLVal _v1238 = $args[5];
  LetRec letrec = new LetRec() {
        ESLVal fieldTypes = new ESLVal(new Function(new ESLVal("fieldTypes"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1244 = $args[0];
          {ESLVal _v711 = _v1244;
                
                if(_v711.isCons())
                {ESLVal $1448 = _v711.head();
                  ESLVal $1449 = _v711.tail();
                  
                  switch($1448.termName) {
                  case "Binding": {ESLVal $1454 = $1448.termRef(0);
                    ESLVal $1453 = $1448.termRef(1);
                    ESLVal $1452 = $1448.termRef(2);
                    ESLVal $1451 = $1448.termRef(3);
                    ESLVal $1450 = $1448.termRef(4);
                    
                    {ESLVal _v1245 = $1454;
                    
                    {ESLVal n = $1453;
                    
                    {ESLVal t = $1452;
                    
                    {ESLVal st = $1451;
                    
                    {ESLVal e = $1450;
                    
                    {ESLVal _v1246 = $1449;
                    
                    return fieldTypes.apply(_v1246).cons(new ESLVal("FieldType",_v1245,n,expType.apply(e,_v1241,_v1240,_v1239,_v1238)));
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v1247 = _v711;
                    
                    return error(new ESLVal("TypeError",_v1243,new ESLVal("unknown field representation: ").add(_v1247)));
                  }
                }
                }
              else if(_v711.isNil())
                return $nil;
              else {ESLVal _v1248 = _v711;
                  
                  return error(new ESLVal("TypeError",_v1243,new ESLVal("unknown field representation: ").add(_v1248)));
                }
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "fieldTypes": return fieldTypes;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal fieldTypes = letrec.get("fieldTypes");
      
        return new ESLVal("RecordType",_v1243,fieldTypes.apply(_v1242));
      
    }
  });
  private static ESLVal forType = new ESLVal(new Function(new ESLVal("forType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1233 = $args[0];
  ESLVal _v1232 = $args[1];
  ESLVal _v1231 = $args[2];
  ESLVal _v1230 = $args[3];
  ESLVal _v1229 = $args[4];
  ESLVal _v1228 = $args[5];
  ESLVal _v1227 = $args[6];
  ESLVal _v1226 = $args[7];
  {ESLVal _v1234 = expType.apply(_v1231,_v1229,_v1228,_v1227,_v1226);
        
        {ESLVal _v710 = _v1234;
        
        switch(_v710.termName) {
        case "ListType": {ESLVal $1447 = _v710.termRef(0);
          ESLVal $1446 = _v710.termRef(1);
          
          {ESLVal _v1235 = $1447;
          
          {ESLVal t = $1446;
          
          return patternType.apply(_v1235,_v1232,t,_v1229,_v1228,_v1227,_v1226,new ESLVal(new Function(new ESLVal("fun1624"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1237 = $args[0];
          ESLVal _v1236 = $args[1];
          return expType.apply(_v1230,_v1229,_v1236,_v1227,_v1226);
            }
          }));
        }
        }
        }
        default: {ESLVal t = _v710;
          
          return error(new ESLVal("TypeError",_v1233,new ESLVal("for type expects a list: ").add(_v1231)));
        }
      }
      }
      }
    }
  });
  private static ESLVal patternTypes = new ESLVal(new Function(new ESLVal("patternTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1207 = $args[0];
  ESLVal _v1206 = $args[1];
  ESLVal _v1205 = $args[2];
  ESLVal _v1204 = $args[3];
  ESLVal _v1203 = $args[4];
  ESLVal _v1202 = $args[5];
  ESLVal _v1201 = $args[6];
  ESLVal _v1200 = $args[7];
  {ESLVal _v709 = _v1206;
        ESLVal _v708 = _v1205;
        
        if(_v709.isCons())
        {ESLVal $1440 = _v709.head();
          ESLVal $1441 = _v709.tail();
          
          if(_v708.isCons())
          {ESLVal $1442 = _v708.head();
            ESLVal $1443 = _v708.tail();
            
            {ESLVal p = $1440;
            
            {ESLVal _v1208 = $1441;
            
            {ESLVal t = $1442;
            
            {ESLVal _v1209 = $1443;
            
            {ESLVal _v1211 = _v1208;
            ESLVal _v1210 = _v1209;
            
            return patternType.apply(_v1207,p,t,_v1204,_v1203,_v1202,_v1201,new ESLVal(new Function(new ESLVal("fun1625"),getSelf()) {
              public ESLVal apply(ESLVal... $args) {
                ESLVal _v1213 = $args[0];
            ESLVal _v1212 = $args[1];
            return patternTypes.apply(_v1207,_v1211,_v1210,_v1204,_v1212,_v1202,_v1201,new ESLVal(new Function(new ESLVal("fun1626"),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      ESLVal _v1215 = $args[0];
                  ESLVal _v1214 = $args[1];
                  return _v1200.apply(_v1215.cons(_v1213),_v1214);
                    }
                  }));
              }
            }));
          }
          }
          }
          }
          }
          }
        else if(_v708.isNil())
          {ESLVal _v1216 = _v709;
            
            {ESLVal _v1217 = _v708;
            
            return error(new ESLVal("TypeError",_v1207,new ESLVal("somthing wrong with ").add(_v1216.add(new ESLVal(" ").add(_v1217)))));
          }
          }
        else {ESLVal _v1218 = _v709;
            
            {ESLVal _v1219 = _v708;
            
            return error(new ESLVal("TypeError",_v1207,new ESLVal("somthing wrong with ").add(_v1218.add(new ESLVal(" ").add(_v1219)))));
          }
          }
        }
      else if(_v709.isNil())
        if(_v708.isCons())
          {ESLVal $1444 = _v708.head();
            ESLVal $1445 = _v708.tail();
            
            {ESLVal _v1220 = _v709;
            
            {ESLVal _v1221 = _v708;
            
            return error(new ESLVal("TypeError",_v1207,new ESLVal("somthing wrong with ").add(_v1220.add(new ESLVal(" ").add(_v1221)))));
          }
          }
          }
        else if(_v708.isNil())
          return _v1200.apply($nil,_v1203);
        else {ESLVal _v1222 = _v709;
            
            {ESLVal _v1223 = _v708;
            
            return error(new ESLVal("TypeError",_v1207,new ESLVal("somthing wrong with ").add(_v1222.add(new ESLVal(" ").add(_v1223)))));
          }
          }
      else {ESLVal _v1224 = _v709;
          
          {ESLVal _v1225 = _v708;
          
          return error(new ESLVal("TypeError",_v1207,new ESLVal("somthing wrong with ").add(_v1224.add(new ESLVal(" ").add(_v1225)))));
        }
        }
      }
    }
  });
  private static ESLVal getPatternType = new ESLVal(new Function(new ESLVal("getPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1184 = $args[0];
  ESLVal _v1183 = $args[1];
  ESLVal _v1182 = $args[2];
  ESLVal _v1181 = $args[3];
  ESLVal _v1180 = $args[4];
  ESLVal _v1179 = $args[5];
  {ESLVal _v707 = _v1183;
        
        switch(_v707.termName) {
        case "PApplyType": {ESLVal $1439 = _v707.termRef(0);
          ESLVal $1438 = _v707.termRef(1);
          ESLVal $1437 = _v707.termRef(2);
          
          {ESLVal _v1197 = $1439;
          
          {ESLVal _v1198 = $1438;
          
          {ESLVal args = $1437;
          
          return error(new ESLVal("should this happen?"));
        }
        }
        }
        }
      case "PBool": {ESLVal $1436 = _v707.termRef(0);
          ESLVal $1435 = _v707.termRef(1);
          
          {ESLVal _v1196 = $1436;
          
          {ESLVal b = $1435;
          
          return new ESLVal("BoolType",_v1196);
        }
        }
        }
      case "PCons": {ESLVal $1434 = _v707.termRef(0);
          ESLVal $1433 = _v707.termRef(1);
          ESLVal $1432 = _v707.termRef(2);
          
          {ESLVal _v1195 = $1434;
          
          {ESLVal hd = $1433;
          
          {ESLVal tl = $1432;
          
          return getPatternType.apply(_v1195,tl,_v1182,_v1181,_v1180,_v1179);
        }
        }
        }
        }
      case "PBagCons": {ESLVal $1431 = _v707.termRef(0);
          ESLVal $1430 = _v707.termRef(1);
          ESLVal $1429 = _v707.termRef(2);
          
          {ESLVal _v1194 = $1431;
          
          {ESLVal hd = $1430;
          
          {ESLVal tl = $1429;
          
          return getPatternType.apply(_v1194,tl,_v1182,_v1181,_v1180,_v1179);
        }
        }
        }
        }
      case "PSetCons": {ESLVal $1428 = _v707.termRef(0);
          ESLVal $1427 = _v707.termRef(1);
          ESLVal $1426 = _v707.termRef(2);
          
          {ESLVal _v1193 = $1428;
          
          {ESLVal hd = $1427;
          
          {ESLVal tl = $1426;
          
          return getPatternType.apply(_v1193,tl,_v1182,_v1181,_v1180,_v1179);
        }
        }
        }
        }
      case "PNil": {ESLVal $1425 = _v707.termRef(0);
          
          {ESLVal _v1192 = $1425;
          
          return new ESLVal("ForallType",_v1192,ESLVal.list(new ESLVal("T")),new ESLVal("ListType",_v1192,new ESLVal("VarType",_v1192,new ESLVal("T"))));
        }
        }
      case "PNull": {ESLVal $1424 = _v707.termRef(0);
          
          {ESLVal _v1191 = $1424;
          
          return new ESLVal("ForallType",_v1191,ESLVal.list(new ESLVal("T")),new ESLVal("VarType",_v1191,new ESLVal("T")));
        }
        }
      case "PEmptyBag": {ESLVal $1423 = _v707.termRef(0);
          
          {ESLVal _v1190 = $1423;
          
          return new ESLVal("ForallType",_v1190,ESLVal.list(new ESLVal("T")),new ESLVal("BagType",_v1190,new ESLVal("VarType",_v1190,new ESLVal("T"))));
        }
        }
      case "PEmptySet": {ESLVal $1422 = _v707.termRef(0);
          
          {ESLVal _v1189 = $1422;
          
          return new ESLVal("ForallType",_v1189,ESLVal.list(new ESLVal("T")),new ESLVal("SetType",_v1189,new ESLVal("VarType",_v1189,new ESLVal("T"))));
        }
        }
      case "PInt": {ESLVal $1421 = _v707.termRef(0);
          ESLVal $1420 = _v707.termRef(1);
          
          {ESLVal _v1188 = $1421;
          
          {ESLVal n = $1420;
          
          return new ESLVal("IntType",_v1188);
        }
        }
        }
      case "PVar": {ESLVal $1419 = _v707.termRef(0);
          ESLVal $1418 = _v707.termRef(1);
          ESLVal $1417 = _v707.termRef(2);
          
          {ESLVal _v1187 = $1419;
          
          {ESLVal n = $1418;
          
          {ESLVal pt = $1417;
          
          return substTypeEnv.apply(_v1179,pt);
        }
        }
        }
        }
      case "PStr": {ESLVal $1416 = _v707.termRef(0);
          ESLVal $1415 = _v707.termRef(1);
          
          {ESLVal _v1186 = $1416;
          
          {ESLVal s = $1415;
          
          return new ESLVal("StrType",_v1186);
        }
        }
        }
      case "PTerm": {ESLVal $1414 = _v707.termRef(0);
          ESLVal $1413 = _v707.termRef(1);
          ESLVal $1412 = _v707.termRef(2);
          ESLVal $1411 = _v707.termRef(3);
          
          {ESLVal _v1185 = $1414;
          
          {ESLVal n = $1413;
          
          {ESLVal ts = $1412;
          
          {ESLVal ps = $1411;
          
          return lookupType.apply(n,_v1180);
        }
        }
        }
        }
        }
        default: {ESLVal _v1199 = _v707;
          
          return error(new ESLVal("TypeError",_v1184,new ESLVal("unknown type of pattern: ").add(_v1199)));
        }
      }
      }
    }
  });
  private static ESLVal patternType = new ESLVal(new Function(new ESLVal("patternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1157 = $args[0];
  ESLVal _v1156 = $args[1];
  ESLVal _v1155 = $args[2];
  ESLVal _v1154 = $args[3];
  ESLVal _v1153 = $args[4];
  ESLVal _v1152 = $args[5];
  ESLVal _v1151 = $args[6];
  ESLVal _v1150 = $args[7];
  {ESLVal _v706 = _v1156;
        
        switch(_v706.termName) {
        case "PApplyType": {ESLVal $1410 = _v706.termRef(0);
          ESLVal $1409 = _v706.termRef(1);
          ESLVal $1408 = _v706.termRef(2);
          
          {ESLVal _v1176 = $1410;
          
          {ESLVal _v1177 = $1409;
          
          {ESLVal args = $1408;
          
          return applyTypePatternType.apply(_v1176,_v1177,substTypesEnv.apply(_v1151,args),_v1155,_v1154,_v1153,_v1152,_v1151,_v1150);
        }
        }
        }
        }
      case "PBool": {ESLVal $1407 = _v706.termRef(0);
          ESLVal $1406 = _v706.termRef(1);
          
          {ESLVal _v1175 = $1407;
          
          {ESLVal b = $1406;
          
          if(isBoolType.apply(_v1155).boolVal)
          return _v1150.apply(new ESLVal("BoolType",_v1175),_v1153);
          else
            return error(new ESLVal("TypeError",_v1175,new ESLVal("type mismatch: Bool and ").add(ppType.apply(_v1155,_v1151))));
        }
        }
        }
      case "PBagCons": {ESLVal $1405 = _v706.termRef(0);
          ESLVal $1404 = _v706.termRef(1);
          ESLVal $1403 = _v706.termRef(2);
          
          {ESLVal _v1172 = $1405;
          
          {ESLVal hd = $1404;
          
          {ESLVal tl = $1403;
          
          return bagConsPatternType.apply(_v1172,hd,tl,_v1155,_v1154,_v1153,_v1152,_v1151,new ESLVal(new Function(new ESLVal("fun1627"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1174 = $args[0];
          ESLVal _v1173 = $args[1];
          return _v1150.apply(new ESLVal("ListType",_v1172,_v1174),_v1173);
            }
          }));
        }
        }
        }
        }
      case "PSetCons": {ESLVal $1402 = _v706.termRef(0);
          ESLVal $1401 = _v706.termRef(1);
          ESLVal $1400 = _v706.termRef(2);
          
          {ESLVal _v1169 = $1402;
          
          {ESLVal hd = $1401;
          
          {ESLVal tl = $1400;
          
          return setConsPatternType.apply(_v1169,hd,tl,_v1155,_v1154,_v1153,_v1152,_v1151,new ESLVal(new Function(new ESLVal("fun1628"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1171 = $args[0];
          ESLVal _v1170 = $args[1];
          return _v1150.apply(new ESLVal("ListType",_v1169,_v1171),_v1170);
            }
          }));
        }
        }
        }
        }
      case "PCons": {ESLVal $1399 = _v706.termRef(0);
          ESLVal $1398 = _v706.termRef(1);
          ESLVal $1397 = _v706.termRef(2);
          
          {ESLVal _v1166 = $1399;
          
          {ESLVal hd = $1398;
          
          {ESLVal tl = $1397;
          
          return consPatternType.apply(_v1166,hd,tl,_v1155,_v1154,_v1153,_v1152,_v1151,new ESLVal(new Function(new ESLVal("fun1629"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1168 = $args[0];
          ESLVal _v1167 = $args[1];
          return _v1150.apply(new ESLVal("ListType",_v1166,_v1168),_v1167);
            }
          }));
        }
        }
        }
        }
      case "PNil": {ESLVal $1396 = _v706.termRef(0);
          
          {ESLVal _v1165 = $1396;
          
          return nilType.apply(_v1165,_v1155,_v1154,_v1153,_v1152,_v1151,_v1150);
        }
        }
      case "PNull": {ESLVal $1395 = _v706.termRef(0);
          
          {ESLVal _v1164 = $1395;
          
          return _v1150.apply(_v1155,_v1153);
        }
        }
      case "PEmptyBag": {ESLVal $1394 = _v706.termRef(0);
          
          {ESLVal _v1163 = $1394;
          
          return emptyBagType.apply(_v1163,_v1155,_v1154,_v1153,_v1152,_v1151,_v1150);
        }
        }
      case "PEmptySet": {ESLVal $1393 = _v706.termRef(0);
          
          {ESLVal _v1162 = $1393;
          
          return emptySetType.apply(_v1162,_v1155,_v1154,_v1153,_v1152,_v1151,_v1150);
        }
        }
      case "PInt": {ESLVal $1392 = _v706.termRef(0);
          ESLVal $1391 = _v706.termRef(1);
          
          {ESLVal _v1161 = $1392;
          
          {ESLVal n = $1391;
          
          if(isIntType.apply(_v1155).boolVal)
          return _v1150.apply(new ESLVal("IntType",_v1161),_v1153);
          else
            return error(new ESLVal("TypeError",_v1161,new ESLVal("type mismatch: Int and ").add(ppType.apply(_v1155,_v1151))));
        }
        }
        }
      case "PVar": {ESLVal $1390 = _v706.termRef(0);
          ESLVal $1389 = _v706.termRef(1);
          ESLVal $1388 = _v706.termRef(2);
          
          {ESLVal _v1160 = $1390;
          
          {ESLVal n = $1389;
          
          {ESLVal pt = $1388;
          
          return _v1150.apply(_v1155,ESLVal.list(new ESLVal("Map",n,_v1155)).add(_v1153));
        }
        }
        }
        }
      case "PStr": {ESLVal $1387 = _v706.termRef(0);
          ESLVal $1386 = _v706.termRef(1);
          
          {ESLVal _v1159 = $1387;
          
          {ESLVal s = $1386;
          
          if(isStrType.apply(_v1155).boolVal)
          return _v1150.apply(new ESLVal("StrType",_v1159),_v1153);
          else
            return error(new ESLVal("TypeError",_v1159,new ESLVal("type mismatch: Str and ").add(ppType.apply(_v1155,_v1151))));
        }
        }
        }
      case "PTerm": {ESLVal $1385 = _v706.termRef(0);
          ESLVal $1384 = _v706.termRef(1);
          ESLVal $1383 = _v706.termRef(2);
          ESLVal $1382 = _v706.termRef(3);
          
          {ESLVal _v1158 = $1385;
          
          {ESLVal n = $1384;
          
          {ESLVal ts = $1383;
          
          {ESLVal ps = $1382;
          
          return termPatternType.apply(_v1158,n,substTypesEnv.apply(_v1151,ts),ps,_v1155,_v1154,_v1153,_v1152,_v1151,_v1150);
        }
        }
        }
        }
        }
        default: {ESLVal _v1178 = _v706;
          
          return error(new ESLVal("TypeError",_v1157,new ESLVal("unknown type of pattern: ").add(_v1178)));
        }
      }
      }
    }
  });
  private static ESLVal applyTypePatternType = new ESLVal(new Function(new ESLVal("applyTypePatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1145 = $args[0];
  ESLVal _v1144 = $args[1];
  ESLVal _v1143 = $args[2];
  ESLVal _v1142 = $args[3];
  ESLVal _v1141 = $args[4];
  ESLVal _v1140 = $args[5];
  ESLVal _v1139 = $args[6];
  ESLVal _v1138 = $args[7];
  ESLVal _v1137 = $args[8];
  return patternType.apply(_v1145,_v1144,_v1142,_v1141,_v1140,_v1139,_v1138,new ESLVal(new Function(new ESLVal("fun1630"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal _v1147 = $args[0];
        ESLVal _v1146 = $args[1];
        {ESLVal _v705 = typeNF.apply(_v1147,_v1138);
              
              switch(_v705.termName) {
              case "TypeFun": {ESLVal $1381 = _v705.termRef(0);
                ESLVal $1380 = _v705.termRef(1);
                ESLVal $1379 = _v705.termRef(2);
                
                {ESLVal fl = $1381;
                
                {ESLVal ns = $1380;
                
                {ESLVal t = $1379;
                
                if(length.apply(_v1143).eql(length.apply(ns)).boolVal)
                {ESLVal _v1149 = substTypeEnv.apply(zipTypeEnv.apply(ns,_v1143).add(_v1138),t);
                  
                  if(typeEqual.apply(_v1149,_v1142).boolVal)
                  return _v1137.apply(_v1149,_v1146);
                  else
                    return error(new ESLVal("TypeError",_v1145,new ESLVal("value type ").add(ppType.apply(_v1142,_v1138).add(new ESLVal(" does not match pattern type ").add(ppType.apply(_v1149,_v1138).add(new ESLVal(" ").add(ppTypeEnv.apply(_v1138))))))));
                }
                else
                  return error(new ESLVal("TypeError",_v1145,new ESLVal("expecting ").add(length.apply(ns).add(new ESLVal(" args, but suplied with ").add(length.apply(_v1143))))));
              }
              }
              }
              }
            case "ForallType": {ESLVal $1378 = _v705.termRef(0);
                ESLVal $1377 = _v705.termRef(1);
                ESLVal $1376 = _v705.termRef(2);
                
                {ESLVal fl = $1378;
                
                {ESLVal ns = $1377;
                
                {ESLVal t = $1376;
                
                if(length.apply(_v1143).eql(length.apply(ns)).boolVal)
                {ESLVal _v1148 = substTypeEnv.apply(zipTypeEnv.apply(ns,_v1143).add(_v1138),t);
                  
                  if(typeEqual.apply(_v1148,_v1142).boolVal)
                  return _v1137.apply(_v1148,_v1146);
                  else
                    return error(new ESLVal("TypeError",_v1145,new ESLVal("value type ").add(ppType.apply(_v1142,_v1138).add(new ESLVal(" does not match pattern type ").add(ppType.apply(_v1148,_v1138).add(new ESLVal(" ").add(ppTypeEnv.apply(_v1138))))))));
                }
                else
                  return error(new ESLVal("TypeError",_v1145,new ESLVal("expecting ").add(length.apply(ns).add(new ESLVal(" args, but suplied with ").add(length.apply(_v1143))))));
              }
              }
              }
              }
              default: {ESLVal t = _v705;
                
                return _v1137.apply(t,_v1146);
              }
            }
            }
          }
        }));
    }
  });
  private static ESLVal termPatternType = new ESLVal(new Function(new ESLVal("termPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1129 = $args[0];
  ESLVal _v1128 = $args[1];
  ESLVal _v1127 = $args[2];
  ESLVal _v1126 = $args[3];
  ESLVal _v1125 = $args[4];
  ESLVal _v1124 = $args[5];
  ESLVal _v1123 = $args[6];
  ESLVal _v1122 = $args[7];
  ESLVal _v1121 = $args[8];
  ESLVal _v1120 = $args[9];
  {ESLVal _v1130 = getTermPatternType.apply(_v1129,_v1128,_v1127,_v1124,_v1123,_v1122,_v1121);
        
        if(typeEqual.apply(_v1130,_v1125).boolVal)
        {ESLVal _v703 = typeNF.apply(_v1125,_v1121);
          
          switch(_v703.termName) {
          case "UnionType": {ESLVal $1370 = _v703.termRef(0);
            ESLVal $1369 = _v703.termRef(1);
            
            {ESLVal ul = $1370;
            
            {ESLVal cs = $1369;
            
            LetRec letrec = new LetRec() {
            ESLVal getCnstrArgs = new ESLVal(new Function(new ESLVal("getCnstrArgs"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal _v1131 = $args[0];
              {ESLVal _v704 = _v1131;
                    
                    if(_v704.isCons())
                    {ESLVal $1371 = _v704.head();
                      ESLVal $1372 = _v704.tail();
                      
                      switch($1371.termName) {
                      case "TermType": {ESLVal $1375 = $1371.termRef(0);
                        ESLVal $1374 = $1371.termRef(1);
                        ESLVal $1373 = $1371.termRef(2);
                        
                        {ESLVal tl = $1375;
                        
                        {ESLVal m = $1374;
                        
                        {ESLVal args = $1373;
                        
                        {ESLVal _v1132 = $1372;
                        
                        if(m.eql(_v1128).boolVal)
                        return args;
                        else
                          {ESLVal t = $1371;
                            
                            {ESLVal _v1133 = $1372;
                            
                            return getCnstrArgs.apply(_v1133);
                          }
                          }
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal t = $1371;
                        
                        {ESLVal _v1134 = $1372;
                        
                        return getCnstrArgs.apply(_v1134);
                      }
                      }
                    }
                    }
                  else if(_v704.isNil())
                    return error(new ESLVal("TypeError",_v1129,new ESLVal("cannot find constructor for ").add(_v1128)));
                  else return error(new ESLVal("case error at Pos(42928,43187)"));
                  }
                }
              });
            
            public ESLVal get(String name) {
              switch(name) {
                case "getCnstrArgs": return getCnstrArgs;
                
                default: throw new Error("cannot find letrec binding");
              }
              }
            };
          ESLVal getCnstrArgs = letrec.get("getCnstrArgs");
          
            {ESLVal argTypes = getCnstrArgs.apply(cs);
            
            if(length.apply(_v1126).eql(length.apply(argTypes)).boolVal)
            return patternTypes.apply(_v1129,_v1126,argTypes,_v1124,_v1123,_v1122,_v1121,new ESLVal(new Function(new ESLVal("fun1631"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal _v1136 = $args[0];
              ESLVal _v1135 = $args[1];
              return _v1120.apply(typeNF.apply(_v1125,_v1121),_v1135);
                }
              }));
            else
              return error(new ESLVal("TypeError",_v1129,new ESLVal("arity mismatch.")));
          }
          
          }
          }
          }
          default: {ESLVal t = _v703;
            
            return error(new ESLVal("TypeError",_v1129,new ESLVal("expecting a data type: ").add(_v1125)));
          }
        }
        }
        else
          return error(new ESLVal("TypeError",_v1129,new ESLVal("term pattern type ").add(ppType.apply(_v1130,_v1121).add(new ESLVal(" does not match supplied value type ").add(ppType.apply(_v1125,_v1121))))));
      }
    }
  });
  private static ESLVal typeNF = new ESLVal(new Function(new ESLVal("typeNF"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1114 = $args[0];
  ESLVal _v1113 = $args[1];
  {ESLVal _v700 = substTypeEnv.apply(_v1113,_v1114);
        
        switch(_v700.termName) {
        case "ApplyTypeFun": {ESLVal $1362 = _v700.termRef(0);
          ESLVal $1361 = _v700.termRef(1);
          ESLVal $1360 = _v700.termRef(2);
          
          {ESLVal l = $1362;
          
          {ESLVal op = $1361;
          
          {ESLVal args = $1360;
          
          {ESLVal _v702 = typeNF.apply(op,_v1113);
          
          switch(_v702.termName) {
          case "TypeFun": {ESLVal $1368 = _v702.termRef(0);
            ESLVal $1367 = _v702.termRef(1);
            ESLVal $1366 = _v702.termRef(2);
            
            {ESLVal _v1116 = $1368;
            
            {ESLVal ns = $1367;
            
            {ESLVal _v1117 = $1366;
            
            if(length.apply(args).eql(length.apply(ns)).boolVal)
            return typeNF.apply(substTypeEnv.apply(zipTypeEnv.apply(ns,args),_v1117),_v1113);
            else
              return error(new ESLVal("TypeError",_v1116,new ESLVal("function arity error")));
          }
          }
          }
          }
          default: {ESLVal _v1118 = _v702;
            
            return error(new ESLVal("TypeError",l,new ESLVal("expecting a type function: ").add(ppType.apply(typeNF.apply(op,_v1113),_v1113))));
          }
        }
        }
        }
        }
        }
        }
      case "TypeClosure": {ESLVal $1359 = _v700.termRef(0);
          
          {ESLVal f = $1359;
          
          return typeNF.apply(f.apply(),_v1113);
        }
        }
      case "RecType": {ESLVal $1358 = _v700.termRef(0);
          ESLVal $1357 = _v700.termRef(1);
          ESLVal $1356 = _v700.termRef(2);
          
          {ESLVal l = $1358;
          
          {ESLVal n = $1357;
          
          {ESLVal _v1115 = $1356;
          
          return typeNF.apply(substType.apply(new ESLVal("RecType",l,n,_v1115),n,_v1115),_v1113);
        }
        }
        }
        }
      case "ExtendedAct": {ESLVal $1355 = _v700.termRef(0);
          ESLVal $1354 = _v700.termRef(1);
          ESLVal $1353 = _v700.termRef(2);
          ESLVal $1352 = _v700.termRef(3);
          
          {ESLVal l1 = $1355;
          
          {ESLVal parent = $1354;
          
          {ESLVal decs1 = $1353;
          
          {ESLVal ms1 = $1352;
          
          {ESLVal _v701 = typeNF.apply(parent,_v1113);
          
          switch(_v701.termName) {
          case "ActType": {ESLVal $1365 = _v701.termRef(0);
            ESLVal $1364 = _v701.termRef(1);
            ESLVal $1363 = _v701.termRef(2);
            
            {ESLVal l2 = $1365;
            
            {ESLVal decs2 = $1364;
            
            {ESLVal ms2 = $1363;
            
            return new ESLVal("ActType",l1,decs2.add(decs1),ms2.add(ms1));
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(44504,44639)"));
        }
        }
        }
        }
        }
        }
        }
        default: {ESLVal _v1119 = _v700;
          
          return _v1119;
        }
      }
      }
    }
  });
  private static ESLVal getTermPatternType = new ESLVal(new Function(new ESLVal("getTermPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1112 = $args[0];
  ESLVal _v1111 = $args[1];
  ESLVal _v1110 = $args[2];
  ESLVal _v1109 = $args[3];
  ESLVal _v1108 = $args[4];
  ESLVal _v1107 = $args[5];
  ESLVal _v1106 = $args[6];
  {ESLVal t = lookupType.apply(_v1111,_v1107);
        
        if(t.eql($null).boolVal)
        return error(new ESLVal("TypeError",_v1112,new ESLVal("unknown constructor ").add(_v1111)));
        else
          if(length.apply(_v1110).gre($zero).boolVal)
            return getGenericTermPatternType.apply(_v1112,t,_v1110,_v1109,_v1108,_v1107,_v1106);
            else
              return t;
      }
    }
  });
  private static ESLVal getGenericTermPatternType = new ESLVal(new Function(new ESLVal("getGenericTermPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1103 = $args[0];
  ESLVal _v1102 = $args[1];
  ESLVal _v1101 = $args[2];
  ESLVal _v1100 = $args[3];
  ESLVal _v1099 = $args[4];
  ESLVal _v1098 = $args[5];
  ESLVal _v1097 = $args[6];
  {ESLVal _v699 = _v1102;
        
        switch(_v699.termName) {
        case "RecType": {ESLVal $1351 = _v699.termRef(0);
          ESLVal $1350 = _v699.termRef(1);
          ESLVal $1349 = _v699.termRef(2);
          
          {ESLVal rl = $1351;
          
          {ESLVal rn = $1350;
          
          {ESLVal rt = $1349;
          
          return getGenericTermPatternType.apply(_v1103,substType.apply(new ESLVal("RecType",rl,rn,rt),rn,rt),_v1101,_v1100,_v1099,_v1098,_v1097);
        }
        }
        }
        }
      case "TypeFun": {ESLVal $1348 = _v699.termRef(0);
          ESLVal $1347 = _v699.termRef(1);
          ESLVal $1346 = _v699.termRef(2);
          
          {ESLVal al = $1348;
          
          {ESLVal ns = $1347;
          
          {ESLVal _v1104 = $1346;
          
          if(length.apply(ns).eql(length.apply(_v1101)).boolVal)
          {ESLVal e = zipTypeEnv.apply(ns,_v1101);
            
            return substTypeEnv.apply(e.add(_v1097),_v1104);
          }
          else
            return error(new ESLVal("TypeError",_v1103,new ESLVal("generic constructor mismatch")));
        }
        }
        }
        }
        default: {ESLVal _v1105 = _v699;
          
          return error(new ESLVal("TypeError",_v1103,new ESLVal("expecting a generic type: ").add(ppType.apply(_v1105,_v1097))));
        }
      }
      }
    }
  });
  private static ESLVal nilType = new ESLVal(new Function(new ESLVal("nilType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1095 = $args[0];
  ESLVal _v1094 = $args[1];
  ESLVal _v1093 = $args[2];
  ESLVal _v1092 = $args[3];
  ESLVal _v1091 = $args[4];
  ESLVal _v1090 = $args[5];
  ESLVal _v1089 = $args[6];
  {ESLVal _v698 = _v1094;
        
        switch(_v698.termName) {
        case "ListType": {ESLVal $1345 = _v698.termRef(0);
          ESLVal $1344 = _v698.termRef(1);
          
          {ESLVal ltl = $1345;
          
          {ESLVal et = $1344;
          
          return _v1089.apply(new ESLVal("ForallType",_v1095,ESLVal.list(new ESLVal("T")),new ESLVal("ListType",_v1095,new ESLVal("VarType",_v1095,new ESLVal("T")))),_v1092);
        }
        }
        }
        default: {ESLVal _v1096 = _v698;
          
          return error(new ESLVal("TypeError",_v1095,new ESLVal("expecting a list type: ").add(ppType.apply(_v1096,_v1090))));
        }
      }
      }
    }
  });
  private static ESLVal emptyBagType = new ESLVal(new Function(new ESLVal("emptyBagType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1087 = $args[0];
  ESLVal _v1086 = $args[1];
  ESLVal _v1085 = $args[2];
  ESLVal _v1084 = $args[3];
  ESLVal _v1083 = $args[4];
  ESLVal _v1082 = $args[5];
  ESLVal _v1081 = $args[6];
  {ESLVal _v697 = _v1086;
        
        switch(_v697.termName) {
        case "BagType": {ESLVal $1343 = _v697.termRef(0);
          ESLVal $1342 = _v697.termRef(1);
          
          {ESLVal ltl = $1343;
          
          {ESLVal et = $1342;
          
          return _v1081.apply(new ESLVal("ForallType",_v1087,ESLVal.list(new ESLVal("T")),new ESLVal("BagType",_v1087,new ESLVal("VarType",_v1087,new ESLVal("T")))),_v1084);
        }
        }
        }
        default: {ESLVal _v1088 = _v697;
          
          return error(new ESLVal("TypeError",_v1087,new ESLVal("expecting a bag type: ").add(ppType.apply(_v1088,_v1082))));
        }
      }
      }
    }
  });
  private static ESLVal emptySetType = new ESLVal(new Function(new ESLVal("emptySetType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1079 = $args[0];
  ESLVal _v1078 = $args[1];
  ESLVal _v1077 = $args[2];
  ESLVal _v1076 = $args[3];
  ESLVal _v1075 = $args[4];
  ESLVal _v1074 = $args[5];
  ESLVal _v1073 = $args[6];
  {ESLVal _v696 = _v1078;
        
        switch(_v696.termName) {
        case "SetType": {ESLVal $1341 = _v696.termRef(0);
          ESLVal $1340 = _v696.termRef(1);
          
          {ESLVal ltl = $1341;
          
          {ESLVal et = $1340;
          
          return _v1073.apply(new ESLVal("ForallType",_v1079,ESLVal.list(new ESLVal("T")),new ESLVal("SetType",_v1079,new ESLVal("VarType",_v1079,new ESLVal("T")))),_v1076);
        }
        }
        }
        default: {ESLVal _v1080 = _v696;
          
          return error(new ESLVal("TypeError",_v1079,new ESLVal("expecting a set type: ").add(ppType.apply(_v1080,_v1074))));
        }
      }
      }
    }
  });
  private static ESLVal consPatternType = new ESLVal(new Function(new ESLVal("consPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1067 = $args[0];
  ESLVal _v1066 = $args[1];
  ESLVal _v1065 = $args[2];
  ESLVal _v1064 = $args[3];
  ESLVal _v1063 = $args[4];
  ESLVal _v1062 = $args[5];
  ESLVal _v1061 = $args[6];
  ESLVal _v1060 = $args[7];
  ESLVal _v1059 = $args[8];
  {ESLVal _v695 = _v1064;
        
        switch(_v695.termName) {
        case "ListType": {ESLVal $1339 = _v695.termRef(0);
          ESLVal $1338 = _v695.termRef(1);
          
          {ESLVal ltl = $1339;
          
          {ESLVal et = $1338;
          
          return patternType.apply(_v1067,_v1066,substTypeEnv.apply(_v1060,et),_v1063,_v1062,_v1061,_v1060,new ESLVal(new Function(new ESLVal("fun1632"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1069 = $args[0];
          ESLVal _v1068 = $args[1];
          return patternType.apply(_v1067,_v1065,_v1064,_v1063,_v1068,_v1061,_v1060,new ESLVal(new Function(new ESLVal("fun1633"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal _v1071 = $args[0];
                ESLVal _v1070 = $args[1];
                return _v1059.apply(_v1069,_v1070);
                  }
                }));
            }
          }));
        }
        }
        }
        default: {ESLVal _v1072 = _v695;
          
          return error(new ESLVal("TypeError",_v1067,new ESLVal("expecting a list type: ").add(ppType.apply(_v1072,_v1060))));
        }
      }
      }
    }
  });
  private static ESLVal bagConsPatternType = new ESLVal(new Function(new ESLVal("bagConsPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1053 = $args[0];
  ESLVal _v1052 = $args[1];
  ESLVal _v1051 = $args[2];
  ESLVal _v1050 = $args[3];
  ESLVal _v1049 = $args[4];
  ESLVal _v1048 = $args[5];
  ESLVal _v1047 = $args[6];
  ESLVal _v1046 = $args[7];
  ESLVal _v1045 = $args[8];
  {ESLVal _v694 = _v1050;
        
        switch(_v694.termName) {
        case "BagType": {ESLVal $1337 = _v694.termRef(0);
          ESLVal $1336 = _v694.termRef(1);
          
          {ESLVal ltl = $1337;
          
          {ESLVal et = $1336;
          
          return patternType.apply(_v1053,_v1052,substTypeEnv.apply(_v1046,et),_v1049,_v1048,_v1047,_v1046,new ESLVal(new Function(new ESLVal("fun1634"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1055 = $args[0];
          ESLVal _v1054 = $args[1];
          return patternType.apply(_v1053,_v1051,_v1050,_v1049,_v1054,_v1047,_v1046,new ESLVal(new Function(new ESLVal("fun1635"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal _v1057 = $args[0];
                ESLVal _v1056 = $args[1];
                return _v1045.apply(_v1055,_v1056);
                  }
                }));
            }
          }));
        }
        }
        }
        default: {ESLVal _v1058 = _v694;
          
          return error(new ESLVal("TypeError",_v1053,new ESLVal("expecting a bag type: ").add(ppType.apply(_v1058,_v1046))));
        }
      }
      }
    }
  });
  private static ESLVal setConsPatternType = new ESLVal(new Function(new ESLVal("setConsPatternType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1039 = $args[0];
  ESLVal _v1038 = $args[1];
  ESLVal _v1037 = $args[2];
  ESLVal _v1036 = $args[3];
  ESLVal _v1035 = $args[4];
  ESLVal _v1034 = $args[5];
  ESLVal _v1033 = $args[6];
  ESLVal _v1032 = $args[7];
  ESLVal _v1031 = $args[8];
  {ESLVal _v693 = _v1036;
        
        switch(_v693.termName) {
        case "SetType": {ESLVal $1335 = _v693.termRef(0);
          ESLVal $1334 = _v693.termRef(1);
          
          {ESLVal ltl = $1335;
          
          {ESLVal et = $1334;
          
          return patternType.apply(_v1039,_v1038,substTypeEnv.apply(_v1032,et),_v1035,_v1034,_v1033,_v1032,new ESLVal(new Function(new ESLVal("fun1636"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v1041 = $args[0];
          ESLVal _v1040 = $args[1];
          return patternType.apply(_v1039,_v1037,_v1036,_v1035,_v1040,_v1033,_v1032,new ESLVal(new Function(new ESLVal("fun1637"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal _v1043 = $args[0];
                ESLVal _v1042 = $args[1];
                return _v1031.apply(_v1041,_v1042);
                  }
                }));
            }
          }));
        }
        }
        }
        default: {ESLVal _v1044 = _v693;
          
          return error(new ESLVal("TypeError",_v1039,new ESLVal("expecting a set type: ").add(ppType.apply(_v1044,_v1032))));
        }
      }
      }
    }
  });
  private static ESLVal binExpType = new ESLVal(new Function(new ESLVal("binExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1029 = $args[0];
  ESLVal _v1028 = $args[1];
  ESLVal _v1027 = $args[2];
  ESLVal _v1026 = $args[3];
  ESLVal _v1025 = $args[4];
  ESLVal _v1024 = $args[5];
  ESLVal _v1023 = $args[6];
  ESLVal _v1022 = $args[7];
  {ESLVal _v692 = _v1027;
        
        switch(_v692.strVal) {
        case "+": return plusExpType.apply(_v1029,_v1028,_v1026,_v1025,_v1024,_v1023,_v1022);
      case "-": return subExpType.apply(_v1029,_v1028,_v1026,_v1025,_v1024,_v1023,_v1022);
      case "*": return mulExpType.apply(_v1029,_v1028,_v1026,_v1025,_v1024,_v1023,_v1022);
      case "/": return divExpType.apply(_v1029,_v1028,_v1026,_v1025,_v1024,_v1023,_v1022);
      case ":": return consExpType.apply(_v1029,_v1028,_v1026,_v1025,_v1024,_v1023,_v1022);
      case "=": return eqlExpType.apply(_v1029,_v1028,_v1026,_v1025,_v1024,_v1023,_v1022);
      case "<>": return neqlExpType.apply(_v1029,_v1028,_v1026,_v1025,_v1024,_v1023,_v1022);
      case "and": return andExpType.apply(_v1029,_v1028,_v1026,_v1025,_v1024,_v1023,_v1022);
      case "andalso": return andExpType.apply(_v1029,_v1028,_v1026,_v1025,_v1024,_v1023,_v1022);
      case "or": return orExpType.apply(_v1029,_v1028,_v1026,_v1025,_v1024,_v1023,_v1022);
      case "orelse": return orExpType.apply(_v1029,_v1028,_v1026,_v1025,_v1024,_v1023,_v1022);
      case ">": return compareExpType.apply(_v1029,_v1028,new ESLVal(">"),_v1026,_v1025,_v1024,_v1023,_v1022);
      case ">=": return compareExpType.apply(_v1029,_v1028,new ESLVal(">="),_v1026,_v1025,_v1024,_v1023,_v1022);
      case "<": return compareExpType.apply(_v1029,_v1028,new ESLVal("<"),_v1026,_v1025,_v1024,_v1023,_v1022);
      case "<=": return compareExpType.apply(_v1029,_v1028,new ESLVal("<="),_v1026,_v1025,_v1024,_v1023,_v1022);
      case "..": return dotDotExpType.apply(_v1029,_v1028,_v1026,_v1025,_v1024,_v1023,_v1022);
      case "%": return percentExpType.apply(_v1029,_v1028,_v1026,_v1025,_v1024,_v1023,_v1022);
        default: {ESLVal _v1030 = _v692;
          
          return error(new ESLVal("TypeError",_v1029,new ESLVal("unknown operator: ").add(_v1030)));
        }
      }
      }
    }
  });
  private static ESLVal andExpType = new ESLVal(new Function(new ESLVal("andExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1021 = $args[0];
  ESLVal _v1020 = $args[1];
  ESLVal _v1019 = $args[2];
  ESLVal _v1018 = $args[3];
  ESLVal _v1017 = $args[4];
  ESLVal _v1016 = $args[5];
  ESLVal _v1015 = $args[6];
  {ESLVal t1 = expType.apply(_v1020,_v1018,_v1017,_v1016,_v1015);
        ESLVal t2 = expType.apply(_v1019,_v1018,_v1017,_v1016,_v1015);
        
        if(isBoolType.apply(t1).and(isBoolType.apply(t2)).boolVal)
        return t1;
        else
          return error(new ESLVal("TypeError",_v1021,new ESLVal("and expects boolean arguments: ").add(ppType.apply(t1,_v1015).add(new ESLVal(" ").add(ppType.apply(t2,_v1015))))));
      }
    }
  });
  private static ESLVal dotDotExpType = new ESLVal(new Function(new ESLVal("dotDotExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1014 = $args[0];
  ESLVal _v1013 = $args[1];
  ESLVal _v1012 = $args[2];
  ESLVal _v1011 = $args[3];
  ESLVal _v1010 = $args[4];
  ESLVal _v1009 = $args[5];
  ESLVal _v1008 = $args[6];
  {ESLVal t1 = expType.apply(_v1013,_v1011,_v1010,_v1009,_v1008);
        ESLVal t2 = expType.apply(_v1012,_v1011,_v1010,_v1009,_v1008);
        
        if(isIntType.apply(t1).and(isIntType.apply(t2)).boolVal)
        return new ESLVal("ListType",_v1014,new ESLVal("IntType",_v1014));
        else
          return error(new ESLVal("TypeError",_v1014,new ESLVal(".. expects integer arguments: ").add(ppType.apply(t1,_v1008).add(new ESLVal(" ").add(ppType.apply(t2,_v1008))))));
      }
    }
  });
  private static ESLVal percentExpType = new ESLVal(new Function(new ESLVal("percentExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1007 = $args[0];
  ESLVal _v1006 = $args[1];
  ESLVal _v1005 = $args[2];
  ESLVal _v1004 = $args[3];
  ESLVal _v1003 = $args[4];
  ESLVal _v1002 = $args[5];
  ESLVal _v1001 = $args[6];
  {ESLVal t1 = expType.apply(_v1006,_v1004,_v1003,_v1002,_v1001);
        ESLVal t2 = expType.apply(_v1005,_v1004,_v1003,_v1002,_v1001);
        
        if(isIntType.apply(t1).and(isIntType.apply(t2)).boolVal)
        return new ESLVal("IntType",_v1007);
        else
          return error(new ESLVal("TypeError",_v1007,new ESLVal("% expects integer arguments: ").add(ppType.apply(t1,_v1001).add(new ESLVal(" ").add(ppType.apply(t2,_v1001))))));
      }
    }
  });
  private static ESLVal compareExpType = new ESLVal(new Function(new ESLVal("compareExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v1000 = $args[0];
  ESLVal _v999 = $args[1];
  ESLVal _v998 = $args[2];
  ESLVal _v997 = $args[3];
  ESLVal _v996 = $args[4];
  ESLVal _v995 = $args[5];
  ESLVal _v994 = $args[6];
  ESLVal _v993 = $args[7];
  {ESLVal t1 = expType.apply(_v999,_v996,_v995,_v994,_v993);
        ESLVal t2 = expType.apply(_v997,_v996,_v995,_v994,_v993);
        
        if(isNumType.apply(t1).and(isNumType.apply(t2)).boolVal)
        return new ESLVal("BoolType",_v1000);
        else
          return error(new ESLVal("TypeError",_v1000,_v998.add(new ESLVal(" expects numeric arguments: ").add(ppType.apply(t1,_v993).add(new ESLVal(" ").add(ppType.apply(t2,_v993)))))));
      }
    }
  });
  private static ESLVal orExpType = new ESLVal(new Function(new ESLVal("orExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v992 = $args[0];
  ESLVal _v991 = $args[1];
  ESLVal _v990 = $args[2];
  ESLVal _v989 = $args[3];
  ESLVal _v988 = $args[4];
  ESLVal _v987 = $args[5];
  ESLVal _v986 = $args[6];
  {ESLVal t1 = expType.apply(_v991,_v989,_v988,_v987,_v986);
        ESLVal t2 = expType.apply(_v990,_v989,_v988,_v987,_v986);
        
        if(isBoolType.apply(t1).and(isBoolType.apply(t2)).boolVal)
        return t1;
        else
          return error(new ESLVal("TypeError",_v992,new ESLVal("or expects boolean arguments: ").add(ppType.apply(t1,_v986).add(new ESLVal(" ").add(ppType.apply(t2,_v986))))));
      }
    }
  });
  private static ESLVal eqlExpType = new ESLVal(new Function(new ESLVal("eqlExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v985 = $args[0];
  ESLVal _v984 = $args[1];
  ESLVal _v983 = $args[2];
  ESLVal _v982 = $args[3];
  ESLVal _v981 = $args[4];
  ESLVal _v980 = $args[5];
  ESLVal _v979 = $args[6];
  {ESLVal t1 = expType.apply(_v984,_v982,_v981,_v980,_v979);
        ESLVal t2 = expType.apply(_v983,_v982,_v981,_v980,_v979);
        
        if(typeEqual.apply(t1,t2).boolVal)
        return new ESLVal("BoolType",_v985);
        else
          return error(new ESLVal("TypeError",_v985,new ESLVal("= expects types to agree: ").add(ppType.apply(t1,_v979).add(new ESLVal(" <> ").add(ppType.apply(t2,_v979))))));
      }
    }
  });
  private static ESLVal neqlExpType = new ESLVal(new Function(new ESLVal("neqlExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v978 = $args[0];
  ESLVal _v977 = $args[1];
  ESLVal _v976 = $args[2];
  ESLVal _v975 = $args[3];
  ESLVal _v974 = $args[4];
  ESLVal _v973 = $args[5];
  ESLVal _v972 = $args[6];
  {ESLVal t1 = expType.apply(_v977,_v975,_v974,_v973,_v972);
        ESLVal t2 = expType.apply(_v976,_v975,_v974,_v973,_v972);
        
        if(typeEqual.apply(t1,t2).boolVal)
        return new ESLVal("BoolType",_v978);
        else
          return error(new ESLVal("TypeError",_v978,new ESLVal("<> expects types to agree: ").add(ppType.apply(t1,_v972).add(new ESLVal(" <> ").add(ppType.apply(t2,_v972))))));
      }
    }
  });
  private static ESLVal consExpType = new ESLVal(new Function(new ESLVal("consExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v970 = $args[0];
  ESLVal _v969 = $args[1];
  ESLVal _v968 = $args[2];
  ESLVal _v967 = $args[3];
  ESLVal _v966 = $args[4];
  ESLVal _v965 = $args[5];
  ESLVal _v964 = $args[6];
  {ESLVal t1 = typeNF.apply(expType.apply(_v969,_v967,_v966,_v965,_v964),_v964);
        ESLVal t2 = typeNF.apply(expType.apply(_v968,_v967,_v966,_v965,_v964),_v964);
        
        {ESLVal _v691 = t2;
        ESLVal _v690 = t1;
        
        switch(_v691.termName) {
        case "ListType": {ESLVal $1333 = _v691.termRef(0);
          ESLVal $1332 = _v691.termRef(1);
          
          {ESLVal _v971 = $1333;
          
          {ESLVal elementType = $1332;
          
          {ESLVal headType = _v690;
          
          if(typeEqual.apply(headType,elementType).boolVal)
          return t2;
          else
            return error(new ESLVal("TypeError",_v971,new ESLVal(": expects head type ").add(ppType.apply(headType,_v964).add(new ESLVal(" and element type ").add(ppType.apply(elementType,_v964).add(new ESLVal(" to agree")))))));
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(53038,53321)"));
      }
      }
      }
    }
  });
  private static ESLVal divExpType = new ESLVal(new Function(new ESLVal("divExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v957 = $args[0];
  ESLVal _v956 = $args[1];
  ESLVal _v955 = $args[2];
  ESLVal _v954 = $args[3];
  ESLVal _v953 = $args[4];
  ESLVal _v952 = $args[5];
  ESLVal _v951 = $args[6];
  {ESLVal t1 = expType.apply(_v956,_v954,_v953,_v952,_v951);
        ESLVal t2 = expType.apply(_v955,_v954,_v953,_v952,_v951);
        
        {ESLVal _v689 = t1;
        ESLVal _v688 = t2;
        
        switch(_v689.termName) {
        case "IntType": {ESLVal $1330 = _v689.termRef(0);
          
          switch(_v688.termName) {
          case "IntType": {ESLVal $1331 = _v688.termRef(0);
            
            {ESLVal l1 = $1330;
            
            {ESLVal l2 = $1331;
            
            return t1;
          }
          }
          }
          default: {ESLVal _v960 = _v689;
            
            {ESLVal _v961 = _v688;
            
            return error(new ESLVal("TypeError",_v957,new ESLVal("incomptible types for /: ").add(ppType.apply(_v960,_v951).add(new ESLVal(" and ").add(ppType.apply(_v961,_v951))))));
          }
          }
        }
        }
      case "FloatType": {ESLVal $1328 = _v689.termRef(0);
          
          switch(_v688.termName) {
          case "FloatType": {ESLVal $1329 = _v688.termRef(0);
            
            {ESLVal l1 = $1328;
            
            {ESLVal l2 = $1329;
            
            return t1;
          }
          }
          }
          default: {ESLVal _v958 = _v689;
            
            {ESLVal _v959 = _v688;
            
            return error(new ESLVal("TypeError",_v957,new ESLVal("incomptible types for /: ").add(ppType.apply(_v958,_v951).add(new ESLVal(" and ").add(ppType.apply(_v959,_v951))))));
          }
          }
        }
        }
        default: {ESLVal _v962 = _v689;
          
          {ESLVal _v963 = _v688;
          
          return error(new ESLVal("TypeError",_v957,new ESLVal("incomptible types for /: ").add(ppType.apply(_v962,_v951).add(new ESLVal(" and ").add(ppType.apply(_v963,_v951))))));
        }
        }
      }
      }
      }
    }
  });
  private static ESLVal mulExpType = new ESLVal(new Function(new ESLVal("mulExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v944 = $args[0];
  ESLVal _v943 = $args[1];
  ESLVal _v942 = $args[2];
  ESLVal _v941 = $args[3];
  ESLVal _v940 = $args[4];
  ESLVal _v939 = $args[5];
  ESLVal _v938 = $args[6];
  {ESLVal t1 = expType.apply(_v943,_v941,_v940,_v939,_v938);
        ESLVal t2 = expType.apply(_v942,_v941,_v940,_v939,_v938);
        
        {ESLVal _v687 = t1;
        ESLVal _v686 = t2;
        
        switch(_v687.termName) {
        case "IntType": {ESLVal $1325 = _v687.termRef(0);
          
          switch(_v686.termName) {
          case "IntType": {ESLVal $1327 = _v686.termRef(0);
            
            {ESLVal l1 = $1325;
            
            {ESLVal l2 = $1327;
            
            return t1;
          }
          }
          }
        case "FloatType": {ESLVal $1326 = _v686.termRef(0);
            
            {ESLVal l1 = $1325;
            
            {ESLVal l2 = $1326;
            
            return t2;
          }
          }
          }
          default: {ESLVal _v947 = _v687;
            
            {ESLVal _v948 = _v686;
            
            return error(new ESLVal("TypeError",_v944,new ESLVal("incomptible types for *: ").add(ppType.apply(_v947,_v938).add(new ESLVal(" and ").add(ppType.apply(_v948,_v938))))));
          }
          }
        }
        }
      case "FloatType": {ESLVal $1322 = _v687.termRef(0);
          
          switch(_v686.termName) {
          case "FloatType": {ESLVal $1324 = _v686.termRef(0);
            
            {ESLVal l1 = $1322;
            
            {ESLVal l2 = $1324;
            
            return t1;
          }
          }
          }
        case "IntType": {ESLVal $1323 = _v686.termRef(0);
            
            {ESLVal l1 = $1322;
            
            {ESLVal l2 = $1323;
            
            return t1;
          }
          }
          }
          default: {ESLVal _v945 = _v687;
            
            {ESLVal _v946 = _v686;
            
            return error(new ESLVal("TypeError",_v944,new ESLVal("incomptible types for *: ").add(ppType.apply(_v945,_v938).add(new ESLVal(" and ").add(ppType.apply(_v946,_v938))))));
          }
          }
        }
        }
        default: {ESLVal _v949 = _v687;
          
          {ESLVal _v950 = _v686;
          
          return error(new ESLVal("TypeError",_v944,new ESLVal("incomptible types for *: ").add(ppType.apply(_v949,_v938).add(new ESLVal(" and ").add(ppType.apply(_v950,_v938))))));
        }
        }
      }
      }
      }
    }
  });
  private static ESLVal subExpType = new ESLVal(new Function(new ESLVal("subExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v931 = $args[0];
  ESLVal _v930 = $args[1];
  ESLVal _v929 = $args[2];
  ESLVal _v928 = $args[3];
  ESLVal _v927 = $args[4];
  ESLVal _v926 = $args[5];
  ESLVal _v925 = $args[6];
  {ESLVal t1 = expType.apply(_v930,_v928,_v927,_v926,_v925);
        ESLVal t2 = expType.apply(_v929,_v928,_v927,_v926,_v925);
        
        {ESLVal _v685 = t1;
        ESLVal _v684 = t2;
        
        switch(_v685.termName) {
        case "IntType": {ESLVal $1319 = _v685.termRef(0);
          
          switch(_v684.termName) {
          case "IntType": {ESLVal $1321 = _v684.termRef(0);
            
            {ESLVal l1 = $1319;
            
            {ESLVal l2 = $1321;
            
            return t1;
          }
          }
          }
        case "FloatType": {ESLVal $1320 = _v684.termRef(0);
            
            {ESLVal l1 = $1319;
            
            {ESLVal l2 = $1320;
            
            return t2;
          }
          }
          }
          default: {ESLVal _v934 = _v685;
            
            {ESLVal _v935 = _v684;
            
            return error(new ESLVal("TypeError",_v931,new ESLVal("incomptible types for -: ").add(ppType.apply(_v934,_v925).add(new ESLVal(" and ").add(ppType.apply(_v935,_v925))))));
          }
          }
        }
        }
      case "FloatType": {ESLVal $1316 = _v685.termRef(0);
          
          switch(_v684.termName) {
          case "FloatType": {ESLVal $1318 = _v684.termRef(0);
            
            {ESLVal l1 = $1316;
            
            {ESLVal l2 = $1318;
            
            return t1;
          }
          }
          }
        case "IntType": {ESLVal $1317 = _v684.termRef(0);
            
            {ESLVal l1 = $1316;
            
            {ESLVal l2 = $1317;
            
            return t1;
          }
          }
          }
          default: {ESLVal _v932 = _v685;
            
            {ESLVal _v933 = _v684;
            
            return error(new ESLVal("TypeError",_v931,new ESLVal("incomptible types for -: ").add(ppType.apply(_v932,_v925).add(new ESLVal(" and ").add(ppType.apply(_v933,_v925))))));
          }
          }
        }
        }
        default: {ESLVal _v936 = _v685;
          
          {ESLVal _v937 = _v684;
          
          return error(new ESLVal("TypeError",_v931,new ESLVal("incomptible types for -: ").add(ppType.apply(_v936,_v925).add(new ESLVal(" and ").add(ppType.apply(_v937,_v925))))));
        }
        }
      }
      }
      }
    }
  });
  private static ESLVal plusExpType = new ESLVal(new Function(new ESLVal("plusExpType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v900 = $args[0];
  ESLVal _v899 = $args[1];
  ESLVal _v898 = $args[2];
  ESLVal _v897 = $args[3];
  ESLVal _v896 = $args[4];
  ESLVal _v895 = $args[5];
  ESLVal _v894 = $args[6];
  {ESLVal t1 = expType.apply(_v899,_v897,_v896,_v895,_v894);
        ESLVal t2 = expType.apply(_v898,_v897,_v896,_v895,_v894);
        
        {ESLVal _v683 = t1;
        ESLVal _v682 = t2;
        
        switch(_v683.termName) {
        case "StrType": {ESLVal $1315 = _v683.termRef(0);
          
          {ESLVal _v919 = $1315;
          
          {ESLVal _v920 = _v682;
          
          return t1;
        }
        }
        }
      case "IntType": {ESLVal $1313 = _v683.termRef(0);
          
          switch(_v682.termName) {
          case "IntType": {ESLVal $1314 = _v682.termRef(0);
            
            {ESLVal l1 = $1313;
            
            {ESLVal l2 = $1314;
            
            return t1;
          }
          }
          }
          default: switch(_v682.termName) {
            case "StrType": {ESLVal $1306 = _v682.termRef(0);
              
              {ESLVal _v915 = _v683;
              
              {ESLVal _v916 = $1306;
              
              return t2;
            }
            }
            }
            default: {ESLVal _v917 = _v683;
              
              {ESLVal _v918 = _v682;
              
              return error(new ESLVal("TypeError",_v900,new ESLVal("incomptible types for +: ").add(ppType.apply(_v917,_v894).add(new ESLVal(" and ").add(ppType.apply(_v918,_v894))))));
            }
            }
          }
        }
        }
      case "FloatType": {ESLVal $1311 = _v683.termRef(0);
          
          switch(_v682.termName) {
          case "FloatType": {ESLVal $1312 = _v682.termRef(0);
            
            {ESLVal l1 = $1311;
            
            {ESLVal l2 = $1312;
            
            return t1;
          }
          }
          }
          default: switch(_v682.termName) {
            case "StrType": {ESLVal $1306 = _v682.termRef(0);
              
              {ESLVal _v911 = _v683;
              
              {ESLVal _v912 = $1306;
              
              return t2;
            }
            }
            }
            default: {ESLVal _v913 = _v683;
              
              {ESLVal _v914 = _v682;
              
              return error(new ESLVal("TypeError",_v900,new ESLVal("incomptible types for +: ").add(ppType.apply(_v913,_v894).add(new ESLVal(" and ").add(ppType.apply(_v914,_v894))))));
            }
            }
          }
        }
        }
      case "ListType": {ESLVal $1308 = _v683.termRef(0);
          ESLVal $1307 = _v683.termRef(1);
          
          switch(_v682.termName) {
          case "ListType": {ESLVal $1310 = _v682.termRef(0);
            ESLVal $1309 = _v682.termRef(1);
            
            {ESLVal l1 = $1308;
            
            {ESLVal _v901 = $1307;
            
            {ESLVal l2 = $1310;
            
            {ESLVal _v902 = $1309;
            
            if(typeEqual.apply(_v901,_v902).boolVal)
            return new ESLVal("ListType",l1,_v901);
            else
              switch(_v682.termName) {
                case "StrType": {ESLVal $1306 = _v682.termRef(0);
                  
                  {ESLVal _v903 = _v683;
                  
                  {ESLVal _v904 = $1306;
                  
                  return _v902;
                }
                }
                }
                default: {ESLVal _v905 = _v683;
                  
                  {ESLVal _v906 = _v682;
                  
                  return error(new ESLVal("TypeError",_v900,new ESLVal("incomptible types for +: ").add(ppType.apply(_v905,_v894).add(new ESLVal(" and ").add(ppType.apply(_v906,_v894))))));
                }
                }
              }
          }
          }
          }
          }
          }
          default: switch(_v682.termName) {
            case "StrType": {ESLVal $1306 = _v682.termRef(0);
              
              {ESLVal _v907 = _v683;
              
              {ESLVal _v908 = $1306;
              
              return t2;
            }
            }
            }
            default: {ESLVal _v909 = _v683;
              
              {ESLVal _v910 = _v682;
              
              return error(new ESLVal("TypeError",_v900,new ESLVal("incomptible types for +: ").add(ppType.apply(_v909,_v894).add(new ESLVal(" and ").add(ppType.apply(_v910,_v894))))));
            }
            }
          }
        }
        }
        default: switch(_v682.termName) {
          case "StrType": {ESLVal $1306 = _v682.termRef(0);
            
            {ESLVal _v921 = _v683;
            
            {ESLVal _v922 = $1306;
            
            return t2;
          }
          }
          }
          default: {ESLVal _v923 = _v683;
            
            {ESLVal _v924 = _v682;
            
            return error(new ESLVal("TypeError",_v900,new ESLVal("incomptible types for +: ").add(ppType.apply(_v923,_v894).add(new ESLVal(" and ").add(ppType.apply(_v924,_v894))))));
          }
          }
        }
      }
      }
      }
    }
  });
  private static ESLVal applyTypeExp = new ESLVal(new Function(new ESLVal("applyTypeExp"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v889 = $args[0];
  ESLVal _v888 = $args[1];
  ESLVal _v887 = $args[2];
  ESLVal _v886 = $args[3];
  ESLVal _v885 = $args[4];
  ESLVal _v884 = $args[5];
  ESLVal _v883 = $args[6];
  {ESLVal _v891 = substTypesEnv.apply(_v883,_v887);
        ESLVal _v890 = expType.apply(_v888,_v886,_v885,_v884,_v883);
        
        {ESLVal _v681 = _v890;
        
        switch(_v681.termName) {
        case "ForallType": {ESLVal $1305 = _v681.termRef(0);
          ESLVal $1304 = _v681.termRef(1);
          ESLVal $1303 = _v681.termRef(2);
          
          {ESLVal l1 = $1305;
          
          {ESLVal ns = $1304;
          
          {ESLVal _v892 = $1303;
          
          if(length.apply(ns).eql(length.apply(_v891)).boolVal)
          {ESLVal env = zipTypeEnv.apply(ns,_v891);
            
            return substTypeEnv.apply(env.add(_v885),_v892);
          }
          else
            return error(new ESLVal("TypeError",_v889,new ESLVal("universal type expects ").add(length.apply(ns).add(new ESLVal(" types, but supplied with ").add(length.apply(_v891))))));
        }
        }
        }
        }
        default: {ESLVal _v893 = _v681;
          
          return error(new ESLVal("TypeError",_v889,new ESLVal("expecting a universal type: ").add(_v893)));
        }
      }
      }
      }
    }
  });
  private static ESLVal expTypes = new ESLVal(new Function(new ESLVal("expTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v882 = $args[0];
  ESLVal _v881 = $args[1];
  ESLVal _v880 = $args[2];
  ESLVal _v879 = $args[3];
  ESLVal _v878 = $args[4];
  return map.apply(new ESLVal(new Function(new ESLVal("fun1638"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal e = $args[0];
        return expType.apply(e,_v881,_v880,_v879,_v878);
          }
        }),_v882);
    }
  });
  private static ESLVal applyType = new ESLVal(new Function(new ESLVal("applyType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v877 = $args[0];
  ESLVal _v876 = $args[1];
  ESLVal _v875 = $args[2];
  ESLVal _v874 = $args[3];
  ESLVal _v873 = $args[4];
  ESLVal _v872 = $args[5];
  ESLVal _v871 = $args[6];
  {ESLVal _v680 = expType.apply(_v876,_v874,_v873,_v872,_v871);
        
        switch(_v680.termName) {
        case "FunType": {ESLVal $1302 = _v680.termRef(0);
          ESLVal $1301 = _v680.termRef(1);
          ESLVal $1300 = _v680.termRef(2);
          
          {ESLVal l1 = $1302;
          
          {ESLVal domain = $1301;
          
          {ESLVal range = $1300;
          
          {ESLVal supplied = expTypes.apply(_v875,_v874,_v873,_v872,_v871);
          
          if(length.apply(domain).eql(length.apply(supplied)).boolVal)
          if(subTypes.apply(supplied,domain).boolVal)
            return range;
            else
              return error(new ESLVal("TypeError",_v877,new ESLVal("supplied argument types ").add(ppTypes.apply(supplied,_v871).add(new ESLVal(" do not match function domain ").add(ppTypes.apply(domain,_v871))))));
          else
            return error(new ESLVal("TypeError",_v877,new ESLVal("expecting ").add(length.apply(domain).add(new ESLVal(" args, but supplied with ").add(length.apply(supplied))))));
        }
        }
        }
        }
        }
        default: {ESLVal t = _v680;
          
          return error(new ESLVal("TypeError",_v877,new ESLVal("unknown type for apply: ").add(ppType.apply(t,_v871))));
        }
      }
      }
    }
  });
  private static ESLVal ifType = new ESLVal(new Function(new ESLVal("ifType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v870 = $args[0];
  ESLVal _v869 = $args[1];
  ESLVal _v868 = $args[2];
  ESLVal _v867 = $args[3];
  ESLVal _v866 = $args[4];
  ESLVal _v865 = $args[5];
  ESLVal _v864 = $args[6];
  ESLVal _v863 = $args[7];
  {ESLVal testType = expType.apply(_v869,_v866,_v865,_v864,_v863);
        
        if(isBoolType.apply(testType).boolVal)
        {ESLVal conseqType = expType.apply(_v868,_v866,_v865,_v864,_v863);
          ESLVal altType = expType.apply(_v867,_v866,_v865,_v864,_v863);
          
          if(typeEqual.apply(conseqType,altType).boolVal)
          return conseqType;
          else
            return error(new ESLVal("TypeError",_v870,new ESLVal("conseq and alt types do not agree: ").add(ppType.apply(conseqType,_v863).add(new ESLVal(" ").add(ppType.apply(altType,_v863))))));
        }
        else
          return error(new ESLVal("if expects a bool ").add(ppType.apply(testType,_v863)));
      }
    }
  });
  private static ESLVal checkDecs = new ESLVal(new Function(new ESLVal("checkDecs"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal ds = $args[0];
  {ESLVal _v678 = ds;
        
        if(_v678.isCons())
        {ESLVal $1298 = _v678.head();
          ESLVal $1299 = _v678.tail();
          
          {ESLVal d = $1298;
          
          {ESLVal _v861 = $1299;
          
          if(member.apply(decName.apply(d),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal $qualArg = $args[0];
        {ESLVal _v679 = $qualArg;
              
              {ESLVal _v862 = _v679;
              
              return ESLVal.list(ESLVal.list(decName.apply(_v862)));
            }
            }
          }
        }).map(_v861).flatten().flatten()).boolVal)
          return error(new ESLVal("TypeError",decLoc.apply(d),new ESLVal(" duplicate argument ").add(decName.apply(d))));
          else
            return checkDecs.apply(_v861);
        }
        }
        }
      else if(_v678.isNil())
        return $null;
      else return error(new ESLVal("case error at Pos(58075,58308)"));
      }
    }
  });
  private static ESLVal funType = new ESLVal(new Function(new ESLVal("funType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v858 = $args[0];
  ESLVal _v857 = $args[1];
  ESLVal _v856 = $args[2];
  ESLVal _v855 = $args[3];
  ESLVal _v854 = $args[4];
  ESLVal _v853 = $args[5];
  ESLVal _v852 = $args[6];
  ESLVal _v851 = $args[7];
  ESLVal _v850 = $args[8];
  {checkDecs.apply(_v856);
      {ESLVal nType = expType.apply(_v857,_v853,_v852,_v851,_v850);
        
        if(isStrType.apply(nType).boolVal)
        {ESLVal declaredType = substTypeEnv.apply(_v850,_v855);
          
          return decTypes.apply(_v856,_v852,_v850,new ESLVal(new Function(new ESLVal("fun1639"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v860 = $args[0];
          ESLVal _v859 = $args[1];
          {ESLVal actualRange = expType.apply(_v854,_v853,_v859,_v851,_v850);
                
                if(subType.apply(new ESLVal("FunType",_v858,_v860,actualRange),declaredType).boolVal)
                return new ESLVal("FunType",_v858,_v860,actualRange);
                else
                  return error(new ESLVal("TypeError",_v858,new ESLVal("function declared type ").add(ppType.apply(declaredType,_v850).add(new ESLVal(" but is ").add(ppType.apply(new ESLVal("FunType",_v858,_v860,actualRange),_v850))))));
              }
            }
          }));
        }
        else
          return error(new ESLVal("TypeError",_v858,new ESLVal("expecting a string for a function name: ").add(_v857)));
      }}
    }
  });
  private static ESLVal decTypes = new ESLVal(new Function(new ESLVal("decTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v846 = $args[0];
  ESLVal _v845 = $args[1];
  ESLVal _v844 = $args[2];
  ESLVal _v843 = $args[3];
  LetRec letrec = new LetRec() {
        ESLVal processDecs = new ESLVal(new Function(new ESLVal("processDecs"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v848 = $args[0];
          ESLVal _v847 = $args[1];
          {ESLVal _v677 = _v848;
                
                if(_v677.isCons())
                {ESLVal $1292 = _v677.head();
                  ESLVal $1293 = _v677.tail();
                  
                  switch($1292.termName) {
                  case "Dec": {ESLVal $1297 = $1292.termRef(0);
                    ESLVal $1296 = $1292.termRef(1);
                    ESLVal $1295 = $1292.termRef(2);
                    ESLVal $1294 = $1292.termRef(3);
                    
                    {ESLVal l = $1297;
                    
                    {ESLVal n = $1296;
                    
                    {ESLVal t = $1295;
                    
                    {ESLVal st = $1294;
                    
                    {ESLVal _v849 = $1293;
                    
                    return processDecs.apply(_v849,_v847.cons(new ESLVal("Map",n,substTypeEnv.apply(_v844,t))));
                  }
                  }
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(59501,59726)"));
                }
                }
              else if(_v677.isNil())
                return _v843.apply(reverse.apply(typeEnvRan.apply(_v847)),_v847.add(_v845));
              else return error(new ESLVal("case error at Pos(59501,59726)"));
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "processDecs": return processDecs;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal processDecs = letrec.get("processDecs");
      
        return processDecs.apply(_v846,$nil);
      
    }
  });
  private static ESLVal termType = new ESLVal(new Function(new ESLVal("termType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v842 = $args[0];
  ESLVal _v841 = $args[1];
  ESLVal _v840 = $args[2];
  ESLVal _v839 = $args[3];
  ESLVal _v838 = $args[4];
  ESLVal _v837 = $args[5];
  ESLVal _v836 = $args[6];
  ESLVal _v835 = $args[7];
  {ESLVal t0 = lookupType.apply(_v841,_v836);
        
        if(t0.eql($null).boolVal)
        return error(new ESLVal("TypeError",_v842,new ESLVal("cannot find cnstr ").add(_v841)));
        else
          {ESLVal t = unfoldIf.apply(t0);
            
            return termTypeCheckUnion.apply(t,_v842,_v841,_v840,_v839,_v838,_v837,_v836,_v835);
          }
      }
    }
  });
  private static ESLVal termTypeCheckUnion = new ESLVal(new Function(new ESLVal("termTypeCheckUnion"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v832 = $args[0];
  ESLVal _v831 = $args[1];
  ESLVal _v830 = $args[2];
  ESLVal _v829 = $args[3];
  ESLVal _v828 = $args[4];
  ESLVal _v827 = $args[5];
  ESLVal _v826 = $args[6];
  ESLVal _v825 = $args[7];
  ESLVal _v824 = $args[8];
  if(_v832.eql($null).boolVal)
        return error(new ESLVal("TypeError",_v831,new ESLVal("cannot find constructor ").add(_v830)));
        else
          {ESLVal _v675 = _v832;
            
            switch(_v675.termName) {
            case "TypeFun": {ESLVal $1289 = _v675.termRef(0);
              ESLVal $1288 = _v675.termRef(1);
              ESLVal $1287 = _v675.termRef(2);
              
              {ESLVal lf = $1289;
              
              {ESLVal ns = $1288;
              
              {ESLVal body = $1287;
              
              if(length.apply(ns).eql(length.apply(_v829)).boolVal)
              {ESLVal args = map.apply(new ESLVal(new Function(new ESLVal("fun1640"),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      ESLVal _v833 = $args[0];
                  return substTypeEnv.apply(_v824,_v833);
                    }
                  }),_v829);
                
                {ESLVal _v676 = substTypeEnv.apply(zipTypeEnv.apply(ns,args),body);
                
                switch(_v676.termName) {
                case "UnionType": {ESLVal $1291 = _v676.termRef(0);
                  ESLVal $1290 = _v676.termRef(1);
                  
                  {ESLVal l1 = $1291;
                  
                  {ESLVal terms = $1290;
                  
                  {ESLVal ts2 = findTermArgTypes.apply(_v830,terms);
                  
                  if(length.apply(_v828).eql(length.apply(ts2)).boolVal)
                  {checkTermArgTypes.apply(_v831,_v828,ts2,_v827,_v826,_v825,_v824);
                  return new ESLVal("UnionType",l1,terms);}
                  else
                    return error(_v830.add(new ESLVal(" expects ").add(length.apply(ts2).add(new ESLVal(" args, but you supplied ").add(length.apply(_v828))))));
                }
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(60599,61149)"));
              }
              }
              }
              else
                return error(new ESLVal("TypeError",_v831,new ESLVal("generic constructor ").add(_v830.add(new ESLVal(" expects ").add(length.apply(ns).add(new ESLVal(" type arguments, but received ").add(length.apply(_v829))))))));
            }
            }
            }
            }
          case "UnionType": {ESLVal $1286 = _v675.termRef(0);
              ESLVal $1285 = _v675.termRef(1);
              
              {ESLVal l1 = $1286;
              
              {ESLVal terms = $1285;
              
              {ESLVal ts2 = findTermArgTypes.apply(_v830,terms);
              
              if(length.apply(_v829).neql($zero).boolVal)
              return error(new ESLVal("TypeError",_v831,new ESLVal("generic application of non-generic constructior: ").add(_v830)));
              else
                if(length.apply(_v828).eql(length.apply(ts2)).boolVal)
                  {checkTermArgTypes.apply(_v831,_v828,ts2,_v827,_v826,_v825,_v824);
                  return _v832;}
                  else
                    return error(_v830.add(new ESLVal(" expects ").add(length.apply(ts2).add(new ESLVal(" args, but you supplied ").add(length.apply(_v828))))));
            }
            }
            }
            }
            default: {ESLVal _v834 = _v675;
              
              return error(new ESLVal("TypeError",_v831,new ESLVal("expecting a union type for ").add(_v830.add(new ESLVal(" but got ").add(ppType.apply(_v834,_v824))))));
            }
          }
          }
    }
  });
  private static ESLVal unfoldIf = new ESLVal(new Function(new ESLVal("unfoldIf"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v674 = t;
        
        switch(_v674.termName) {
        case "RecType": {ESLVal $1284 = _v674.termRef(0);
          ESLVal $1283 = _v674.termRef(1);
          ESLVal $1282 = _v674.termRef(2);
          
          {ESLVal l = $1284;
          
          {ESLVal n = $1283;
          
          {ESLVal _v822 = $1282;
          
          return unfoldIf.apply(unfoldType.apply(l,n,_v822));
        }
        }
        }
        }
        default: {ESLVal _v823 = _v674;
          
          return _v823;
        }
      }
      }
    }
  });
  private static ESLVal findTermArgTypes = new ESLVal(new Function(new ESLVal("findTermArgTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal n = $args[0];
  ESLVal terms = $args[1];
  {ESLVal _v673 = terms;
        
        if(_v673.isCons())
        {ESLVal $1277 = _v673.head();
          ESLVal $1278 = _v673.tail();
          
          switch($1277.termName) {
          case "TermType": {ESLVal $1281 = $1277.termRef(0);
            ESLVal $1280 = $1277.termRef(1);
            ESLVal $1279 = $1277.termRef(2);
            
            {ESLVal l = $1281;
            
            {ESLVal nn = $1280;
            
            {ESLVal ts = $1279;
            
            {ESLVal _v820 = $1278;
            
            if(nn.eql(n).boolVal)
            return ts;
            else
              {ESLVal t = $1277;
                
                {ESLVal _v821 = $1278;
                
                return findTermArgTypes.apply(n,_v821);
              }
              }
          }
          }
          }
          }
          }
          default: {ESLVal t = $1277;
            
            {ESLVal ts = $1278;
            
            return findTermArgTypes.apply(n,ts);
          }
          }
        }
        }
      else if(_v673.isNil())
        return error(new ESLVal("cannot find constructor ").add(n));
      else return error(new ESLVal("case error at Pos(62145,62345)"));
      }
    }
  });
  private static ESLVal checkTermArgTypes = new ESLVal(new Function(new ESLVal("checkTermArgTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v817 = $args[0];
  ESLVal _v816 = $args[1];
  ESLVal _v815 = $args[2];
  ESLVal _v814 = $args[3];
  ESLVal _v813 = $args[4];
  ESLVal _v812 = $args[5];
  ESLVal _v811 = $args[6];
  {ESLVal _v672 = _v816;
        ESLVal _v671 = _v815;
        
        if(_v672.isCons())
        {ESLVal $1271 = _v672.head();
          ESLVal $1272 = _v672.tail();
          
          if(_v671.isCons())
          {ESLVal $1273 = _v671.head();
            ESLVal $1274 = _v671.tail();
            
            {ESLVal e = $1271;
            
            {ESLVal _v818 = $1272;
            
            {ESLVal t = $1273;
            
            {ESLVal _v819 = $1274;
            
            {ESLVal tt = expType.apply(e,_v814,_v813,_v812,_v811);
            
            if(typeEqual.apply(t,tt).boolVal)
            return checkTermArgTypes.apply(_v817,_v818,_v819,_v814,_v813,_v812,_v811);
            else
              return error(new ESLVal("TypeError",_v817,new ESLVal("expected constructor arg type ").add(ppType.apply(t,_v811).add(new ESLVal(" but supplied ").add(ppType.apply(tt,_v811))))));
          }
          }
          }
          }
          }
          }
        else if(_v671.isNil())
          return error(new ESLVal("case error at Pos(62463,62885)"));
        else return error(new ESLVal("case error at Pos(62463,62885)"));
        }
      else if(_v672.isNil())
        if(_v671.isCons())
          {ESLVal $1275 = _v671.head();
            ESLVal $1276 = _v671.tail();
            
            return error(new ESLVal("case error at Pos(62463,62885)"));
          }
        else if(_v671.isNil())
          return $null;
        else return error(new ESLVal("case error at Pos(62463,62885)"));
      else return error(new ESLVal("case error at Pos(62463,62885)"));
      }
    }
  });
  private static ESLVal notType = new ESLVal(new Function(new ESLVal("notType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v809 = $args[0];
  ESLVal _v808 = $args[1];
  ESLVal _v807 = $args[2];
  ESLVal _v806 = $args[3];
  ESLVal _v805 = $args[4];
  ESLVal _v804 = $args[5];
  {ESLVal _v670 = expType.apply(_v808,_v807,_v806,_v805,_v804);
        
        switch(_v670.termName) {
        case "BoolType": {ESLVal $1270 = _v670.termRef(0);
          
          {ESLVal _v810 = $1270;
          
          return new ESLVal("BoolType",_v810);
        }
        }
        default: {ESLVal t = _v670;
          
          return error(new ESLVal("TypeError",_v809,new ESLVal("expecting a boolean: ").add(ppType.apply(t,_v804))));
        }
      }
      }
    }
  });
  private static ESLVal varType = new ESLVal(new Function(new ESLVal("varType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal n = $args[1];
  ESLVal valueEnv = $args[2];
  {ESLVal t = lookupType.apply(n,valueEnv);
        
        if(t.eql($null).boolVal)
        return error(new ESLVal("TypeError",l,new ESLVal("unbound variable ").add(n)));
        else
          {ESLVal _v669 = t;
            
            switch(_v669.termName) {
            case "TypeClosure": {ESLVal $1269 = _v669.termRef(0);
              
              {ESLVal f = $1269;
              
              return f.apply();
            }
            }
            default: {ESLVal _v803 = _v669;
              
              return _v803;
            }
          }
          }
      }
    }
  });
  private static ESLVal blockType = new ESLVal(new Function(new ESLVal("blockType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v802 = $args[0];
  ESLVal _v801 = $args[1];
  ESLVal _v800 = $args[2];
  ESLVal _v799 = $args[3];
  ESLVal _v798 = $args[4];
  ESLVal _v797 = $args[5];
  {ESLVal[] t = new ESLVal[]{new ESLVal("VoidType",_v802)};
        
        {{
        ESLVal _v668 = _v801;
        while(_v668.isCons()) {
          ESLVal e = _v668.headVal;
          t[0] = expType.apply(e,_v800,_v799,_v798,_v797);
          _v668 = _v668.tailVal;}
      }
      return t[0];}
      }
    }
  });
  private static ESLVal listType = new ESLVal(new Function(new ESLVal("listType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal _v796 = $args[0];
  ESLVal _v795 = $args[1];
  ESLVal _v794 = $args[2];
  ESLVal _v793 = $args[3];
  ESLVal _v792 = $args[4];
  ESLVal _v791 = $args[5];
  if(_v795.eql($nil).boolVal)
        return new ESLVal("ForallType",_v796,ESLVal.list(new ESLVal("T")),new ESLVal("ListType",_v796,new ESLVal("VarType",_v796,new ESLVal("T"))));
        else
          {ESLVal ts = map.apply(new ESLVal(new Function(new ESLVal("fun1641"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal e = $args[0];
              return expType.apply(e,_v794,_v793,_v792,_v791);
                }
              }),_v795);
            
            if(allEqualTypes.apply(head.apply(ts),tail.apply(ts)).boolVal)
            return new ESLVal("ListType",_v796,head.apply(ts));
            else
              return error(new ESLVal("TypeError",_v796,new ESLVal("lists should have elements of the same type: ").add(_v795)));
          }
    }
  });
  private static ESLVal recTypes = new ESLVal(new Function(new ESLVal("recTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal env = $args[0];
  LetRec letrec = new LetRec() {
        ESLVal fixEnv = new ESLVal(new Function(new ESLVal("fixEnv"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v789 = $args[0];
          {ESLVal[] e = new ESLVal[]{$null};
                
                {ESLVal fenv = new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      ESLVal $qualArg = $args[0];
                  {ESLVal _v666 = $qualArg;
                        
                        {ESLVal t = _v666;
                        
                        return ESLVal.list(new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                          public ESLVal apply(ESLVal... $args) {
                            ESLVal _v790 = $args[0];
                        {ESLVal _v667 = _v790;
                              
                              {ESLVal n = _v667;
                              
                              return ESLVal.list(ESLVal.list(new ESLVal("Map",n,new ESLVal("TypeClosure",new ESLVal(new Function(new ESLVal("lookup: ").add(n),getSelf()) {
                                public ESLVal apply(ESLVal... $args) {
                                  return lookupType.apply(n,e[0]);
                                }
                              })))));
                            }
                            }
                          }
                        }).map(typeFV.apply(t)).flatten().flatten());
                      }
                      }
                    }
                  }).map(typeEnvRan.apply(_v789)).flatten().flatten();
                
                {ESLVal env1 = substOnce.apply(_v789,fenv);
                
                {e[0] = env1;
              return env1;}
              }
              }
              }
            }
          });
        ESLVal introduceRecTypes = new ESLVal(new Function(new ESLVal("introduceRecTypes"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v788 = $args[0];
          {ESLVal _v665 = _v788;
                
                if(_v665.isCons())
                {ESLVal $1265 = _v665.head();
                  ESLVal $1266 = _v665.tail();
                  
                  switch($1265.termName) {
                  case "Map": {ESLVal $1268 = $1265.termRef(0);
                    ESLVal $1267 = $1265.termRef(1);
                    
                    {ESLVal n = $1268;
                    
                    {ESLVal t = $1267;
                    
                    {ESLVal e = $1266;
                    
                    if(member.apply(n,typeFV.apply(t)).boolVal)
                    return introduceRecTypes.apply(e).cons(new ESLVal("Map",n,new ESLVal("RecType",p0,n,t)));
                    else
                      return introduceRecTypes.apply(e).cons(new ESLVal("Map",n,t));
                  }
                  }
                  }
                  }
                  default: return error(new ESLVal("case error at Pos(64506,64732)"));
                }
                }
              else if(_v665.isNil())
                return _v788;
              else return error(new ESLVal("case error at Pos(64506,64732)"));
              }
            }
          });
        ESLVal substOnce = new ESLVal(new Function(new ESLVal("substOnce"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v786 = $args[0];
          ESLVal _v785 = $args[1];
          {ESLVal map1 = new ESLVal(new Function(new ESLVal("map1"),getSelf()) {
                    public ESLVal apply(ESLVal... $args) {
                      ESLVal m = $args[0];
                  {ESLVal _v663 = m;
                        
                        switch(_v663.termName) {
                        case "Map": {ESLVal $1264 = _v663.termRef(0);
                          ESLVal $1263 = _v663.termRef(1);
                          
                          {ESLVal n = $1264;
                          
                          {ESLVal t = $1263;
                          
                          return new ESLVal("Map",n,substTypeEnv.apply(new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                            public ESLVal apply(ESLVal... $args) {
                              ESLVal $qualArg = $args[0];
                          {ESLVal _v664 = $qualArg;
                                
                                {ESLVal _v787 = _v664;
                                
                                return ESLVal.list(ESLVal.list(new ESLVal("Map",_v787,lookupType.apply(_v787,_v785))));
                              }
                              }
                            }
                          }).map(typeFV.apply(t)).flatten().flatten(),t));
                        }
                        }
                        }
                        default: return error(new ESLVal("case error at Pos(64842,64973)"));
                      }
                      }
                    }
                  });
                
                return map.apply(map1,_v786);
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "fixEnv": return fixEnv;
            
            case "introduceRecTypes": return introduceRecTypes;
            
            case "substOnce": return substOnce;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal fixEnv = letrec.get("fixEnv");
      
      ESLVal introduceRecTypes = letrec.get("introduceRecTypes");
      
      ESLVal substOnce = letrec.get("substOnce");
      
        return fixEnv.apply(introduceRecTypes.apply(env));
      
    }
  });
  private static ESLVal typeFV = new ESLVal(new Function(new ESLVal("typeFV"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  return removeDups.apply(varTypeNames.apply(typeFV1.apply(t,$nil)));
    }
  });
  private static ESLVal varTypeNames = new ESLVal(new Function(new ESLVal("varTypeNames"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal vs = $args[0];
  return map.apply(varTypeName,vs);
    }
  });
  private static ESLVal varTypeName = new ESLVal(new Function(new ESLVal("varTypeName"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v662 = t;
        
        switch(_v662.termName) {
        case "VarType": {ESLVal $1262 = _v662.termRef(0);
          ESLVal $1261 = _v662.termRef(1);
          
          {ESLVal l = $1262;
          
          {ESLVal n = $1261;
          
          return n;
        }
        }
        }
        default: {ESLVal x = _v662;
          
          return new ESLVal("<var>");
        }
      }
      }
    }
  });
  private static ESLVal tdecsFV1 = new ESLVal(new Function(new ESLVal("tdecsFV1"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal decs = $args[0];
  ESLVal fv = $args[1];
  {ESLVal _v661 = decs;
        
        if(_v661.isCons())
        {ESLVal $1259 = _v661.head();
          ESLVal $1260 = _v661.tail();
          
          {ESLVal d = $1259;
          
          {ESLVal ds = $1260;
          
          return tdecFV1.apply(d,tdecsFV1.apply(ds,fv));
        }
        }
        }
      else if(_v661.isNil())
        return fv;
      else return error(new ESLVal("case error at Pos(65359,65448)"));
      }
    }
  });
  private static ESLVal tdecFV1 = new ESLVal(new Function(new ESLVal("tdecFV1"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d = $args[0];
  ESLVal fv = $args[1];
  {ESLVal _v660 = d;
        
        switch(_v660.termName) {
        case "Dec": {ESLVal $1258 = _v660.termRef(0);
          ESLVal $1257 = _v660.termRef(1);
          ESLVal $1256 = _v660.termRef(2);
          ESLVal $1255 = _v660.termRef(3);
          
          {ESLVal l = $1258;
          
          {ESLVal n = $1257;
          
          {ESLVal t = $1256;
          
          {ESLVal st = $1255;
          
          return typeFV1.apply(t,fv);
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(65492,65571)"));
      }
      }
    }
  });
  private static ESLVal handlersFV1 = new ESLVal(new Function(new ESLVal("handlersFV1"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal handlers = $args[0];
  ESLVal fv = $args[1];
  {ESLVal _v659 = handlers;
        
        if(_v659.isCons())
        {ESLVal $1253 = _v659.head();
          ESLVal $1254 = _v659.tail();
          
          {ESLVal m = $1253;
          
          {ESLVal hs = $1254;
          
          return handlerFV1.apply(m,handlersFV1.apply(hs,fv));
        }
        }
        }
      else if(_v659.isNil())
        return fv;
      else return error(new ESLVal("case error at Pos(65629,65731)"));
      }
    }
  });
  private static ESLVal handlerFV1 = new ESLVal(new Function(new ESLVal("handlerFV1"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal m = $args[0];
  ESLVal fv = $args[1];
  {ESLVal _v658 = m;
        
        switch(_v658.termName) {
        case "MessageType": {ESLVal $1252 = _v658.termRef(0);
          ESLVal $1251 = _v658.termRef(1);
          
          {ESLVal l = $1252;
          
          {ESLVal ts = $1251;
          
          return typesFV1.apply(ts,fv);
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(65779,65855)"));
      }
      }
    }
  });
  private static ESLVal typesFV1 = new ESLVal(new Function(new ESLVal("typesFV1"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal ts = $args[0];
  ESLVal fv = $args[1];
  {ESLVal _v657 = ts;
        
        if(_v657.isCons())
        {ESLVal $1249 = _v657.head();
          ESLVal $1250 = _v657.tail();
          
          {ESLVal t = $1249;
          
          {ESLVal _v784 = $1250;
          
          return typeFV1.apply(t,typesFV1.apply(_v784,fv));
        }
        }
        }
      else if(_v657.isNil())
        return fv;
      else return error(new ESLVal("case error at Pos(65904,65991)"));
      }
    }
  });
  private static ESLVal typeFV1 = new ESLVal(new Function(new ESLVal("typeFV1"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  ESLVal fv = $args[1];
  {ESLVal _v653 = t;
        
        switch(_v653.termName) {
        case "ArrayType": {ESLVal $1242 = _v653.termRef(0);
          ESLVal $1241 = _v653.termRef(1);
          
          {ESLVal l = $1242;
          
          {ESLVal _v783 = $1241;
          
          return typeFV1.apply(_v783,fv);
        }
        }
        }
      case "ActType": {ESLVal $1240 = _v653.termRef(0);
          ESLVal $1239 = _v653.termRef(1);
          ESLVal $1238 = _v653.termRef(2);
          
          {ESLVal l = $1240;
          
          {ESLVal decs = $1239;
          
          {ESLVal handlers = $1238;
          
          return tdecsFV1.apply(decs,handlersFV1.apply(handlers,fv));
        }
        }
        }
        }
      case "ExtendedAct": {ESLVal $1237 = _v653.termRef(0);
          ESLVal $1236 = _v653.termRef(1);
          ESLVal $1235 = _v653.termRef(2);
          ESLVal $1234 = _v653.termRef(3);
          
          {ESLVal l = $1237;
          
          {ESLVal parent = $1236;
          
          {ESLVal decs = $1235;
          
          {ESLVal handlers = $1234;
          
          return tdecsFV1.apply(decs,handlersFV1.apply(handlers,typeFV1.apply(parent,fv)));
        }
        }
        }
        }
        }
      case "ApplyType": {ESLVal $1233 = _v653.termRef(0);
          ESLVal $1232 = _v653.termRef(1);
          ESLVal $1231 = _v653.termRef(2);
          
          {ESLVal l = $1233;
          
          {ESLVal n = $1232;
          
          {ESLVal types = $1231;
          
          return typesFV1.apply(types,fv.cons(new ESLVal("VarType",l,n)));
        }
        }
        }
        }
      case "ApplyTypeFun": {ESLVal $1230 = _v653.termRef(0);
          ESLVal $1229 = _v653.termRef(1);
          ESLVal $1228 = _v653.termRef(2);
          
          {ESLVal l = $1230;
          
          {ESLVal op = $1229;
          
          {ESLVal args = $1228;
          
          return typesFV1.apply(args,typeFV1.apply(op,fv));
        }
        }
        }
        }
      case "BoolType": {ESLVal $1227 = _v653.termRef(0);
          
          {ESLVal l = $1227;
          
          return fv;
        }
        }
      case "FieldType": {ESLVal $1226 = _v653.termRef(0);
          ESLVal $1225 = _v653.termRef(1);
          ESLVal $1224 = _v653.termRef(2);
          
          {ESLVal l = $1226;
          
          {ESLVal n = $1225;
          
          {ESLVal _v782 = $1224;
          
          return typeFV1.apply(_v782,fv);
        }
        }
        }
        }
      case "FloatType": {ESLVal $1223 = _v653.termRef(0);
          
          {ESLVal l = $1223;
          
          return fv;
        }
        }
      case "ForallType": {ESLVal $1222 = _v653.termRef(0);
          ESLVal $1221 = _v653.termRef(1);
          ESLVal $1220 = _v653.termRef(2);
          
          {ESLVal l = $1222;
          
          {ESLVal ns = $1221;
          
          {ESLVal _v779 = $1220;
          
          return filter.apply(new ESLVal(new Function(new ESLVal("fun1642"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v780 = $args[0];
          {ESLVal _v656 = _v780;
                
                switch(_v656.termName) {
                case "VarType": {ESLVal $1248 = _v656.termRef(0);
                  ESLVal $1247 = _v656.termRef(1);
                  
                  {ESLVal _v781 = $1248;
                  
                  {ESLVal n = $1247;
                  
                  return member.apply(n,ns).not();
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(66830,66890)"));
              }
              }
            }
          }),typeFV1.apply(_v779,$nil)).add(fv);
        }
        }
        }
        }
      case "FunType": {ESLVal $1219 = _v653.termRef(0);
          ESLVal $1218 = _v653.termRef(1);
          ESLVal $1217 = _v653.termRef(2);
          
          {ESLVal l = $1219;
          
          {ESLVal d = $1218;
          
          {ESLVal r = $1217;
          
          return typesFV1.apply(d,typeFV1.apply(r,fv));
        }
        }
        }
        }
      case "IntType": {ESLVal $1216 = _v653.termRef(0);
          
          {ESLVal l = $1216;
          
          return fv;
        }
        }
      case "ListType": {ESLVal $1215 = _v653.termRef(0);
          ESLVal $1214 = _v653.termRef(1);
          
          {ESLVal l = $1215;
          
          {ESLVal _v778 = $1214;
          
          return typeFV1.apply(_v778,fv);
        }
        }
        }
      case "BagType": {ESLVal $1213 = _v653.termRef(0);
          ESLVal $1212 = _v653.termRef(1);
          
          {ESLVal l = $1213;
          
          {ESLVal _v777 = $1212;
          
          return typeFV1.apply(_v777,fv);
        }
        }
        }
      case "SetType": {ESLVal $1211 = _v653.termRef(0);
          ESLVal $1210 = _v653.termRef(1);
          
          {ESLVal l = $1211;
          
          {ESLVal _v776 = $1210;
          
          return typeFV1.apply(_v776,fv);
        }
        }
        }
      case "NullType": {ESLVal $1209 = _v653.termRef(0);
          
          {ESLVal l = $1209;
          
          return fv;
        }
        }
      case "RecordType": {ESLVal $1208 = _v653.termRef(0);
          ESLVal $1207 = _v653.termRef(1);
          
          {ESLVal l = $1208;
          
          {ESLVal fs = $1207;
          
          return typesFV1.apply(fs,fv);
        }
        }
        }
      case "RecType": {ESLVal $1206 = _v653.termRef(0);
          ESLVal $1205 = _v653.termRef(1);
          ESLVal $1204 = _v653.termRef(2);
          
          {ESLVal l = $1206;
          
          {ESLVal a = $1205;
          
          {ESLVal _v773 = $1204;
          
          return filter.apply(new ESLVal(new Function(new ESLVal("fun1643"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v774 = $args[0];
          {ESLVal _v655 = _v774;
                
                switch(_v655.termName) {
                case "VarType": {ESLVal $1246 = _v655.termRef(0);
                  ESLVal $1245 = _v655.termRef(1);
                  
                  {ESLVal _v775 = $1246;
                  
                  {ESLVal n = $1245;
                  
                  return n.eql(a).not();
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(67306,67354)"));
              }
              }
            }
          }),typeFV1.apply(_v773,$nil)).add(fv);
        }
        }
        }
        }
      case "StrType": {ESLVal $1203 = _v653.termRef(0);
          
          {ESLVal l = $1203;
          
          return fv;
        }
        }
      case "TypeClosure": {ESLVal $1202 = _v653.termRef(0);
          
          {ESLVal f = $1202;
          
          return $nil;
        }
        }
      case "TermType": {ESLVal $1201 = _v653.termRef(0);
          ESLVal $1200 = _v653.termRef(1);
          ESLVal $1199 = _v653.termRef(2);
          
          {ESLVal l = $1201;
          
          {ESLVal n = $1200;
          
          {ESLVal ts = $1199;
          
          return typesFV1.apply(ts,fv);
        }
        }
        }
        }
      case "TypeFun": {ESLVal $1198 = _v653.termRef(0);
          ESLVal $1197 = _v653.termRef(1);
          ESLVal $1196 = _v653.termRef(2);
          
          {ESLVal l = $1198;
          
          {ESLVal ns = $1197;
          
          {ESLVal _v770 = $1196;
          
          return filter.apply(new ESLVal(new Function(new ESLVal("fun1644"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal _v771 = $args[0];
          {ESLVal _v654 = _v771;
                
                switch(_v654.termName) {
                case "VarType": {ESLVal $1244 = _v654.termRef(0);
                  ESLVal $1243 = _v654.termRef(1);
                  
                  {ESLVal _v772 = $1244;
                  
                  {ESLVal n = $1243;
                  
                  return member.apply(n,ns).not();
                }
                }
                }
                default: return error(new ESLVal("case error at Pos(67583,67643)"));
              }
              }
            }
          }),typeFV1.apply(_v770,$nil)).add(fv);
        }
        }
        }
        }
      case "UnfoldType": {ESLVal $1195 = _v653.termRef(0);
          ESLVal $1194 = _v653.termRef(1);
          
          {ESLVal l = $1195;
          
          {ESLVal _v769 = $1194;
          
          return typeFV1.apply(_v769,fv);
        }
        }
        }
      case "UnionType": {ESLVal $1193 = _v653.termRef(0);
          ESLVal $1192 = _v653.termRef(1);
          
          {ESLVal l = $1193;
          
          {ESLVal ts = $1192;
          
          return typesFV1.apply(ts,fv);
        }
        }
        }
      case "VarType": {ESLVal $1191 = _v653.termRef(0);
          ESLVal $1190 = _v653.termRef(1);
          
          {ESLVal l = $1191;
          
          {ESLVal n = $1190;
          
          return fv.cons(t);
        }
        }
        }
      case "VoidType": {ESLVal $1189 = _v653.termRef(0);
          
          {ESLVal l = $1189;
          
          return fv;
        }
        }
      case "UnionRef": {ESLVal $1188 = _v653.termRef(0);
          ESLVal $1187 = _v653.termRef(1);
          ESLVal $1186 = _v653.termRef(2);
          
          {ESLVal l = $1188;
          
          {ESLVal _v768 = $1187;
          
          {ESLVal n = $1186;
          
          return typeFV1.apply(_v768,fv);
        }
        }
        }
        }
        default: {ESLVal x = _v653;
          
          return error(x);
        }
      }
      }
    }
  });
  public static ESLVal main = new ESLVal(new Function(new ESLVal("main"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      return new ESLVal(new BehaviourAdapter(false,getSelf(),new ESLVal("main")) {
          
          public ESLVal handle(ESLVal $m) {{ESLVal _v652 = $m;
            
            return error(new ESLVal("case error at Pos(0,0)"));
          }}
          public ESLVal get(String name) {
            switch(name) {
              
              default: throw new Error("ref illegal " + self + "." + name);
            }
          }
        public void handleTime(ESLVal $t) {
          {}
        }
        public ESLVal init() {
            return ((Supplier<ESLVal>)() -> { 
                {new Function(new ESLVal("try"),getSelf()) {
                  public ESLVal apply(ESLVal... args) { 
                    try { 
                      return typeCheckModule.apply(new ESLVal("esl/compiler/test1.esl"));
                    } catch(ESLError $exception) {
                      ESLVal $x = $exception.value;
                      {ESLVal _v651 = $x;
                  
                  {ESLVal message = _v651;
                  
                  return print.apply(new ESLVal("Type Error: ").add(message));
                }
                }
                    }
                  }
                }.apply();
                print.apply(new ESLVal("DONE"));
                return stopAll.apply();}
              }).get();
          }
        });
    }
  });
public static void main(String[] args) {
    newActor(main,new ESLVal(new Actor())); 
  }
}