package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
// import static esl.Lists.*;
import java.util.function.Supplier;
public class Types {
  public static ESLVal getSelf() { return $null; }
  public static ESLVal decName = new ESLVal(new Function(new ESLVal("decName"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d = $args[0];
  {ESLVal _v251 = d;
        
        switch(_v251.termName) {
        case "Dec": {ESLVal $1053 = _v251.termRef(0);
          ESLVal $1052 = _v251.termRef(1);
          ESLVal $1051 = _v251.termRef(2);
          ESLVal $1050 = _v251.termRef(3);
          
          {ESLVal l = $1053;
          
          {ESLVal n = $1052;
          
          {ESLVal t = $1051;
          
          {ESLVal dt = $1050;
          
          return n;
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(4055,4176)"));
      }
      }
    }
  });
  public static ESLVal decLoc = new ESLVal(new Function(new ESLVal("decLoc"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d = $args[0];
  {ESLVal _v250 = d;
        
        switch(_v250.termName) {
        case "Dec": {ESLVal $1049 = _v250.termRef(0);
          ESLVal $1048 = _v250.termRef(1);
          ESLVal $1047 = _v250.termRef(2);
          ESLVal $1046 = _v250.termRef(3);
          
          {ESLVal l = $1049;
          
          {ESLVal n = $1048;
          
          {ESLVal t = $1047;
          
          {ESLVal dt = $1046;
          
          return l;
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(4280,4338)"));
      }
      }
    }
  });
  public static ESLVal isStrType = new ESLVal(new Function(new ESLVal("isStrType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v249 = t;
        
        switch(_v249.termName) {
        case "StrType": {ESLVal $1045 = _v249.termRef(0);
          
          {ESLVal l = $1045;
          
          return $true;
        }
        }
        default: {ESLVal _v620 = _v249;
          
          return $false;
        }
      }
      }
    }
  });
  public static ESLVal isIntType = new ESLVal(new Function(new ESLVal("isIntType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v248 = t;
        
        switch(_v248.termName) {
        case "IntType": {ESLVal $1044 = _v248.termRef(0);
          
          {ESLVal l = $1044;
          
          return $true;
        }
        }
        default: {ESLVal _v619 = _v248;
          
          return $false;
        }
      }
      }
    }
  });
  public static ESLVal isNumType = new ESLVal(new Function(new ESLVal("isNumType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v247 = t;
        
        switch(_v247.termName) {
        case "IntType": {ESLVal $1043 = _v247.termRef(0);
          
          {ESLVal l = $1043;
          
          return $true;
        }
        }
      case "FloatType": {ESLVal $1042 = _v247.termRef(0);
          
          {ESLVal l = $1042;
          
          return $true;
        }
        }
        default: {ESLVal _v618 = _v247;
          
          return $false;
        }
      }
      }
    }
  });
  public static ESLVal isBoolType = new ESLVal(new Function(new ESLVal("isBoolType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v246 = t;
        
        switch(_v246.termName) {
        case "BoolType": {ESLVal $1041 = _v246.termRef(0);
          
          {ESLVal l = $1041;
          
          return $true;
        }
        }
        default: {ESLVal _v617 = _v246;
          
          return $false;
        }
      }
      }
    }
  });
  private static ESLVal isFloatType = new ESLVal(new Function(new ESLVal("isFloatType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v245 = t;
        
        switch(_v245.termName) {
        case "FloatType": {ESLVal $1040 = _v245.termRef(0);
          
          {ESLVal l = $1040;
          
          return $true;
        }
        }
        default: {ESLVal _v616 = _v245;
          
          return $false;
        }
      }
      }
    }
  });
  public static ESLVal typeEqual = new ESLVal(new Function(new ESLVal("typeEqual"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t1 = $args[0];
  ESLVal t2 = $args[1];
  {ESLVal b = typeEqual1.apply(t1,t2);
        
        return b;
      }
    }
  });
  public static ESLVal typeEqual1 = new ESLVal(new Function(new ESLVal("typeEqual1"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t1 = $args[0];
  ESLVal t2 = $args[1];
  if(t1.eql(t2).boolVal)
        return $true;
        else
          {ESLVal _v244 = t1;
            ESLVal _v243 = t2;
            
            switch(_v244.termName) {
            case "ArrayType": {ESLVal $1037 = _v244.termRef(0);
              ESLVal $1036 = _v244.termRef(1);
              
              switch(_v243.termName) {
              case "ArrayType": {ESLVal $1039 = _v243.termRef(0);
                ESLVal $1038 = _v243.termRef(1);
                
                {ESLVal l1 = $1037;
                
                {ESLVal _v592 = $1036;
                
                {ESLVal l2 = $1039;
                
                {ESLVal _v593 = $1038;
                
                return typeEqual.apply(_v592,_v593);
              }
              }
              }
              }
              }
              default: switch(_v243.termName) {
                case "ApplyTypeFun": {ESLVal $934 = _v243.termRef(0);
                  ESLVal $933 = _v243.termRef(1);
                  ESLVal $932 = _v243.termRef(2);
                  
                  {ESLVal _v602 = _v244;
                  
                  {ESLVal l = $934;
                  
                  {ESLVal op = $933;
                  
                  {ESLVal args = $932;
                  
                  return typeEqual.apply(_v602,applyTypeFun.apply(l,forceType.apply(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $931 = _v243.termRef(0);
                  ESLVal $930 = _v243.termRef(1);
                  ESLVal $929 = _v243.termRef(2);
                  ESLVal $928 = _v243.termRef(3);
                  
                  {ESLVal _v600 = _v244;
                  
                  {ESLVal l2 = $931;
                  
                  {ESLVal _v601 = $930;
                  
                  {ESLVal ds2 = $929;
                  
                  {ESLVal ms2 = $928;
                  
                  return typeEqual.apply(_v600,flattenAct.apply(l2,_v601,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $927 = _v243.termRef(0);
                  
                  {ESLVal t = _v244;
                  
                  {ESLVal l1 = $927;
                  
                  return $true;
                }
                }
                }
              case "TermType": {ESLVal $926 = _v243.termRef(0);
                  ESLVal $925 = _v243.termRef(1);
                  ESLVal $924 = _v243.termRef(2);
                  
                  {ESLVal _v599 = _v244;
                  
                  {ESLVal l2 = $926;
                  
                  {ESLVal n2 = $925;
                  
                  {ESLVal args2 = $924;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $923 = _v243.termRef(0);
                  
                  {ESLVal _v598 = _v244;
                  
                  {ESLVal f = $923;
                  
                  return typeEqual.apply(_v598,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $922 = _v243.termRef(0);
                  ESLVal $921 = _v243.termRef(1);
                  ESLVal $920 = _v243.termRef(2);
                  
                  {ESLVal _v596 = _v244;
                  
                  {ESLVal l2 = $922;
                  
                  {ESLVal n2 = $921;
                  
                  {ESLVal _v597 = $920;
                  
                  return typeEqual.apply(_v596,substType.apply(new ESLVal("RecType",l2,n2,_v597),n2,_v597));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $919 = _v243.termRef(0);
                  ESLVal $918 = _v243.termRef(1);
                  ESLVal $917 = _v243.termRef(2);
                  
                  {ESLVal _v594 = _v244;
                  
                  {ESLVal l1 = $919;
                  
                  {ESLVal ns2 = $918;
                  
                  {ESLVal _v595 = $917;
                  
                  return typeEqual.apply(_v594,_v595);
                }
                }
                }
                }
                }
                default: {ESLVal _v603 = _v244;
                  
                  {ESLVal _v604 = _v243;
                  
                  return $false;
                }
                }
              }
            }
            }
          case "ActType": {ESLVal $1032 = _v244.termRef(0);
              ESLVal $1031 = _v244.termRef(1);
              ESLVal $1030 = _v244.termRef(2);
              
              switch(_v243.termName) {
              case "ActType": {ESLVal $1035 = _v243.termRef(0);
                ESLVal $1034 = _v243.termRef(1);
                ESLVal $1033 = _v243.termRef(2);
                
                {ESLVal l1 = $1032;
                
                {ESLVal exports1 = $1031;
                
                {ESLVal handlers1 = $1030;
                
                {ESLVal l2 = $1035;
                
                {ESLVal exports2 = $1034;
                
                {ESLVal handlers2 = $1033;
                
                return actEqual.apply(exports1,exports1,handlers1,handlers2);
              }
              }
              }
              }
              }
              }
              }
              default: switch(_v243.termName) {
                case "ApplyTypeFun": {ESLVal $934 = _v243.termRef(0);
                  ESLVal $933 = _v243.termRef(1);
                  ESLVal $932 = _v243.termRef(2);
                  
                  {ESLVal _v589 = _v244;
                  
                  {ESLVal l = $934;
                  
                  {ESLVal op = $933;
                  
                  {ESLVal args = $932;
                  
                  return typeEqual.apply(_v589,applyTypeFun.apply(l,forceType.apply(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $931 = _v243.termRef(0);
                  ESLVal $930 = _v243.termRef(1);
                  ESLVal $929 = _v243.termRef(2);
                  ESLVal $928 = _v243.termRef(3);
                  
                  {ESLVal _v587 = _v244;
                  
                  {ESLVal l2 = $931;
                  
                  {ESLVal _v588 = $930;
                  
                  {ESLVal ds2 = $929;
                  
                  {ESLVal ms2 = $928;
                  
                  return typeEqual.apply(_v587,flattenAct.apply(l2,_v588,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $927 = _v243.termRef(0);
                  
                  {ESLVal t = _v244;
                  
                  {ESLVal l1 = $927;
                  
                  return $true;
                }
                }
                }
              case "TermType": {ESLVal $926 = _v243.termRef(0);
                  ESLVal $925 = _v243.termRef(1);
                  ESLVal $924 = _v243.termRef(2);
                  
                  {ESLVal _v586 = _v244;
                  
                  {ESLVal l2 = $926;
                  
                  {ESLVal n2 = $925;
                  
                  {ESLVal args2 = $924;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $923 = _v243.termRef(0);
                  
                  {ESLVal _v585 = _v244;
                  
                  {ESLVal f = $923;
                  
                  return typeEqual.apply(_v585,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $922 = _v243.termRef(0);
                  ESLVal $921 = _v243.termRef(1);
                  ESLVal $920 = _v243.termRef(2);
                  
                  {ESLVal _v583 = _v244;
                  
                  {ESLVal l2 = $922;
                  
                  {ESLVal n2 = $921;
                  
                  {ESLVal _v584 = $920;
                  
                  return typeEqual.apply(_v583,substType.apply(new ESLVal("RecType",l2,n2,_v584),n2,_v584));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $919 = _v243.termRef(0);
                  ESLVal $918 = _v243.termRef(1);
                  ESLVal $917 = _v243.termRef(2);
                  
                  {ESLVal _v581 = _v244;
                  
                  {ESLVal l1 = $919;
                  
                  {ESLVal ns2 = $918;
                  
                  {ESLVal _v582 = $917;
                  
                  return typeEqual.apply(_v581,_v582);
                }
                }
                }
                }
                }
                default: {ESLVal _v590 = _v244;
                  
                  {ESLVal _v591 = _v243;
                  
                  return $false;
                }
                }
              }
            }
            }
          case "ApplyTypeFun": {ESLVal $1026 = _v244.termRef(0);
              ESLVal $1025 = _v244.termRef(1);
              ESLVal $1024 = _v244.termRef(2);
              
              switch(_v243.termName) {
              case "ApplyTypeFun": {ESLVal $1029 = _v243.termRef(0);
                ESLVal $1028 = _v243.termRef(1);
                ESLVal $1027 = _v243.termRef(2);
                
                {ESLVal l1 = $1026;
                
                {ESLVal op1 = $1025;
                
                {ESLVal args1 = $1024;
                
                {ESLVal l2 = $1029;
                
                {ESLVal op2 = $1028;
                
                {ESLVal args2 = $1027;
                
                return typeEqual.apply(op1,op2).and(typesEqual.apply(args1,args2));
              }
              }
              }
              }
              }
              }
              }
              default: {ESLVal l = $1026;
                
                {ESLVal op = $1025;
                
                {ESLVal args = $1024;
                
                {ESLVal _v580 = _v243;
                
                return typeEqual.apply(applyTypeFun.apply(l,forceType.apply(op),args),_v580);
              }
              }
              }
              }
            }
            }
          case "ExtendedAct": {ESLVal $1023 = _v244.termRef(0);
              ESLVal $1022 = _v244.termRef(1);
              ESLVal $1021 = _v244.termRef(2);
              ESLVal $1020 = _v244.termRef(3);
              
              {ESLVal l1 = $1023;
              
              {ESLVal _v578 = $1022;
              
              {ESLVal ds1 = $1021;
              
              {ESLVal ms1 = $1020;
              
              {ESLVal _v579 = _v243;
              
              return typeEqual.apply(flattenAct.apply(l1,_v578,ds1,ms1),_v579);
            }
            }
            }
            }
            }
            }
          case "BoolType": {ESLVal $1018 = _v244.termRef(0);
              
              switch(_v243.termName) {
              case "BoolType": {ESLVal $1019 = _v243.termRef(0);
                
                {ESLVal l1 = $1018;
                
                {ESLVal l2 = $1019;
                
                return $true;
              }
              }
              }
              default: switch(_v243.termName) {
                case "ApplyTypeFun": {ESLVal $934 = _v243.termRef(0);
                  ESLVal $933 = _v243.termRef(1);
                  ESLVal $932 = _v243.termRef(2);
                  
                  {ESLVal _v575 = _v244;
                  
                  {ESLVal l = $934;
                  
                  {ESLVal op = $933;
                  
                  {ESLVal args = $932;
                  
                  return typeEqual.apply(_v575,applyTypeFun.apply(l,forceType.apply(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $931 = _v243.termRef(0);
                  ESLVal $930 = _v243.termRef(1);
                  ESLVal $929 = _v243.termRef(2);
                  ESLVal $928 = _v243.termRef(3);
                  
                  {ESLVal _v573 = _v244;
                  
                  {ESLVal l2 = $931;
                  
                  {ESLVal _v574 = $930;
                  
                  {ESLVal ds2 = $929;
                  
                  {ESLVal ms2 = $928;
                  
                  return typeEqual.apply(_v573,flattenAct.apply(l2,_v574,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $927 = _v243.termRef(0);
                  
                  {ESLVal t = _v244;
                  
                  {ESLVal l1 = $927;
                  
                  return $true;
                }
                }
                }
              case "TermType": {ESLVal $926 = _v243.termRef(0);
                  ESLVal $925 = _v243.termRef(1);
                  ESLVal $924 = _v243.termRef(2);
                  
                  {ESLVal _v572 = _v244;
                  
                  {ESLVal l2 = $926;
                  
                  {ESLVal n2 = $925;
                  
                  {ESLVal args2 = $924;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $923 = _v243.termRef(0);
                  
                  {ESLVal _v571 = _v244;
                  
                  {ESLVal f = $923;
                  
                  return typeEqual.apply(_v571,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $922 = _v243.termRef(0);
                  ESLVal $921 = _v243.termRef(1);
                  ESLVal $920 = _v243.termRef(2);
                  
                  {ESLVal _v569 = _v244;
                  
                  {ESLVal l2 = $922;
                  
                  {ESLVal n2 = $921;
                  
                  {ESLVal _v570 = $920;
                  
                  return typeEqual.apply(_v569,substType.apply(new ESLVal("RecType",l2,n2,_v570),n2,_v570));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $919 = _v243.termRef(0);
                  ESLVal $918 = _v243.termRef(1);
                  ESLVal $917 = _v243.termRef(2);
                  
                  {ESLVal _v567 = _v244;
                  
                  {ESLVal l1 = $919;
                  
                  {ESLVal ns2 = $918;
                  
                  {ESLVal _v568 = $917;
                  
                  return typeEqual.apply(_v567,_v568);
                }
                }
                }
                }
                }
                default: {ESLVal _v576 = _v244;
                  
                  {ESLVal _v577 = _v243;
                  
                  return $false;
                }
                }
              }
            }
            }
          case "FloatType": {ESLVal $1016 = _v244.termRef(0);
              
              switch(_v243.termName) {
              case "FloatType": {ESLVal $1017 = _v243.termRef(0);
                
                {ESLVal l1 = $1016;
                
                {ESLVal l2 = $1017;
                
                return $true;
              }
              }
              }
              default: switch(_v243.termName) {
                case "ApplyTypeFun": {ESLVal $934 = _v243.termRef(0);
                  ESLVal $933 = _v243.termRef(1);
                  ESLVal $932 = _v243.termRef(2);
                  
                  {ESLVal _v564 = _v244;
                  
                  {ESLVal l = $934;
                  
                  {ESLVal op = $933;
                  
                  {ESLVal args = $932;
                  
                  return typeEqual.apply(_v564,applyTypeFun.apply(l,forceType.apply(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $931 = _v243.termRef(0);
                  ESLVal $930 = _v243.termRef(1);
                  ESLVal $929 = _v243.termRef(2);
                  ESLVal $928 = _v243.termRef(3);
                  
                  {ESLVal _v562 = _v244;
                  
                  {ESLVal l2 = $931;
                  
                  {ESLVal _v563 = $930;
                  
                  {ESLVal ds2 = $929;
                  
                  {ESLVal ms2 = $928;
                  
                  return typeEqual.apply(_v562,flattenAct.apply(l2,_v563,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $927 = _v243.termRef(0);
                  
                  {ESLVal t = _v244;
                  
                  {ESLVal l1 = $927;
                  
                  return $true;
                }
                }
                }
              case "TermType": {ESLVal $926 = _v243.termRef(0);
                  ESLVal $925 = _v243.termRef(1);
                  ESLVal $924 = _v243.termRef(2);
                  
                  {ESLVal _v561 = _v244;
                  
                  {ESLVal l2 = $926;
                  
                  {ESLVal n2 = $925;
                  
                  {ESLVal args2 = $924;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $923 = _v243.termRef(0);
                  
                  {ESLVal _v560 = _v244;
                  
                  {ESLVal f = $923;
                  
                  return typeEqual.apply(_v560,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $922 = _v243.termRef(0);
                  ESLVal $921 = _v243.termRef(1);
                  ESLVal $920 = _v243.termRef(2);
                  
                  {ESLVal _v558 = _v244;
                  
                  {ESLVal l2 = $922;
                  
                  {ESLVal n2 = $921;
                  
                  {ESLVal _v559 = $920;
                  
                  return typeEqual.apply(_v558,substType.apply(new ESLVal("RecType",l2,n2,_v559),n2,_v559));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $919 = _v243.termRef(0);
                  ESLVal $918 = _v243.termRef(1);
                  ESLVal $917 = _v243.termRef(2);
                  
                  {ESLVal _v556 = _v244;
                  
                  {ESLVal l1 = $919;
                  
                  {ESLVal ns2 = $918;
                  
                  {ESLVal _v557 = $917;
                  
                  return typeEqual.apply(_v556,_v557);
                }
                }
                }
                }
                }
                default: {ESLVal _v565 = _v244;
                  
                  {ESLVal _v566 = _v243;
                  
                  return $false;
                }
                }
              }
            }
            }
          case "IntType": {ESLVal $1014 = _v244.termRef(0);
              
              switch(_v243.termName) {
              case "IntType": {ESLVal $1015 = _v243.termRef(0);
                
                {ESLVal l1 = $1014;
                
                {ESLVal l2 = $1015;
                
                return $true;
              }
              }
              }
              default: switch(_v243.termName) {
                case "ApplyTypeFun": {ESLVal $934 = _v243.termRef(0);
                  ESLVal $933 = _v243.termRef(1);
                  ESLVal $932 = _v243.termRef(2);
                  
                  {ESLVal _v553 = _v244;
                  
                  {ESLVal l = $934;
                  
                  {ESLVal op = $933;
                  
                  {ESLVal args = $932;
                  
                  return typeEqual.apply(_v553,applyTypeFun.apply(l,forceType.apply(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $931 = _v243.termRef(0);
                  ESLVal $930 = _v243.termRef(1);
                  ESLVal $929 = _v243.termRef(2);
                  ESLVal $928 = _v243.termRef(3);
                  
                  {ESLVal _v551 = _v244;
                  
                  {ESLVal l2 = $931;
                  
                  {ESLVal _v552 = $930;
                  
                  {ESLVal ds2 = $929;
                  
                  {ESLVal ms2 = $928;
                  
                  return typeEqual.apply(_v551,flattenAct.apply(l2,_v552,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $927 = _v243.termRef(0);
                  
                  {ESLVal t = _v244;
                  
                  {ESLVal l1 = $927;
                  
                  return $true;
                }
                }
                }
              case "TermType": {ESLVal $926 = _v243.termRef(0);
                  ESLVal $925 = _v243.termRef(1);
                  ESLVal $924 = _v243.termRef(2);
                  
                  {ESLVal _v550 = _v244;
                  
                  {ESLVal l2 = $926;
                  
                  {ESLVal n2 = $925;
                  
                  {ESLVal args2 = $924;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $923 = _v243.termRef(0);
                  
                  {ESLVal _v549 = _v244;
                  
                  {ESLVal f = $923;
                  
                  return typeEqual.apply(_v549,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $922 = _v243.termRef(0);
                  ESLVal $921 = _v243.termRef(1);
                  ESLVal $920 = _v243.termRef(2);
                  
                  {ESLVal _v547 = _v244;
                  
                  {ESLVal l2 = $922;
                  
                  {ESLVal n2 = $921;
                  
                  {ESLVal _v548 = $920;
                  
                  return typeEqual.apply(_v547,substType.apply(new ESLVal("RecType",l2,n2,_v548),n2,_v548));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $919 = _v243.termRef(0);
                  ESLVal $918 = _v243.termRef(1);
                  ESLVal $917 = _v243.termRef(2);
                  
                  {ESLVal _v545 = _v244;
                  
                  {ESLVal l1 = $919;
                  
                  {ESLVal ns2 = $918;
                  
                  {ESLVal _v546 = $917;
                  
                  return typeEqual.apply(_v545,_v546);
                }
                }
                }
                }
                }
                default: {ESLVal _v554 = _v244;
                  
                  {ESLVal _v555 = _v243;
                  
                  return $false;
                }
                }
              }
            }
            }
          case "ListType": {ESLVal $1000 = _v244.termRef(0);
              ESLVal $999 = _v244.termRef(1);
              
              switch(_v243.termName) {
              case "ListType": {ESLVal $1013 = _v243.termRef(0);
                ESLVal $1012 = _v243.termRef(1);
                
                {ESLVal l1 = $1000;
                
                {ESLVal _v532 = $999;
                
                {ESLVal l2 = $1013;
                
                {ESLVal _v533 = $1012;
                
                return typeEqual.apply(_v532,_v533);
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $1003 = _v243.termRef(0);
                ESLVal $1002 = _v243.termRef(1);
                ESLVal $1001 = _v243.termRef(2);
                
                if($1002.isCons())
                {ESLVal $1004 = $1002.head();
                  ESLVal $1005 = $1002.tail();
                  
                  if($1005.isCons())
                  {ESLVal $1006 = $1005.head();
                    ESLVal $1007 = $1005.tail();
                    
                    switch(_v243.termName) {
                    case "ApplyTypeFun": {ESLVal $934 = _v243.termRef(0);
                      ESLVal $933 = _v243.termRef(1);
                      ESLVal $932 = _v243.termRef(2);
                      
                      {ESLVal _v457 = _v244;
                      
                      {ESLVal l = $934;
                      
                      {ESLVal op = $933;
                      
                      {ESLVal args = $932;
                      
                      return typeEqual.apply(_v457,applyTypeFun.apply(l,forceType.apply(op),args));
                    }
                    }
                    }
                    }
                    }
                  case "ExtendedAct": {ESLVal $931 = _v243.termRef(0);
                      ESLVal $930 = _v243.termRef(1);
                      ESLVal $929 = _v243.termRef(2);
                      ESLVal $928 = _v243.termRef(3);
                      
                      {ESLVal _v455 = _v244;
                      
                      {ESLVal l2 = $931;
                      
                      {ESLVal _v456 = $930;
                      
                      {ESLVal ds2 = $929;
                      
                      {ESLVal ms2 = $928;
                      
                      return typeEqual.apply(_v455,flattenAct.apply(l2,_v456,ds2,ms2));
                    }
                    }
                    }
                    }
                    }
                    }
                  case "VoidType": {ESLVal $927 = _v243.termRef(0);
                      
                      {ESLVal t = _v244;
                      
                      {ESLVal l1 = $927;
                      
                      return $true;
                    }
                    }
                    }
                  case "TermType": {ESLVal $926 = _v243.termRef(0);
                      ESLVal $925 = _v243.termRef(1);
                      ESLVal $924 = _v243.termRef(2);
                      
                      {ESLVal _v454 = _v244;
                      
                      {ESLVal l2 = $926;
                      
                      {ESLVal n2 = $925;
                      
                      {ESLVal args2 = $924;
                      
                      return $false;
                    }
                    }
                    }
                    }
                    }
                  case "TypeClosure": {ESLVal $923 = _v243.termRef(0);
                      
                      {ESLVal _v453 = _v244;
                      
                      {ESLVal f = $923;
                      
                      return typeEqual.apply(_v453,f.apply());
                    }
                    }
                    }
                  case "RecType": {ESLVal $922 = _v243.termRef(0);
                      ESLVal $921 = _v243.termRef(1);
                      ESLVal $920 = _v243.termRef(2);
                      
                      {ESLVal _v451 = _v244;
                      
                      {ESLVal l2 = $922;
                      
                      {ESLVal n2 = $921;
                      
                      {ESLVal _v452 = $920;
                      
                      return typeEqual.apply(_v451,substType.apply(new ESLVal("RecType",l2,n2,_v452),n2,_v452));
                    }
                    }
                    }
                    }
                    }
                  case "ForallType": {ESLVal $919 = _v243.termRef(0);
                      ESLVal $918 = _v243.termRef(1);
                      ESLVal $917 = _v243.termRef(2);
                      
                      {ESLVal _v449 = _v244;
                      
                      {ESLVal l1 = $919;
                      
                      {ESLVal ns2 = $918;
                      
                      {ESLVal _v450 = $917;
                      
                      return typeEqual.apply(_v449,_v450);
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal _v458 = _v244;
                      
                      {ESLVal _v459 = _v243;
                      
                      return $false;
                    }
                    }
                  }
                  }
                else if($1005.isNil())
                  switch($1001.termName) {
                    case "ListType": {ESLVal $1009 = $1001.termRef(0);
                      ESLVal $1008 = $1001.termRef(1);
                      
                      switch($1008.termName) {
                      case "VarType": {ESLVal $1011 = $1008.termRef(0);
                        ESLVal $1010 = $1008.termRef(1);
                        
                        {ESLVal l1 = $1000;
                        
                        {ESLVal _v460 = $999;
                        
                        {ESLVal l2 = $1003;
                        
                        {ESLVal v1 = $1004;
                        
                        {ESLVal l3 = $1009;
                        
                        {ESLVal l4 = $1011;
                        
                        {ESLVal v2 = $1010;
                        
                        if(v1.eql(v2).boolVal)
                        return $true;
                        else
                          switch(_v243.termName) {
                            case "ApplyTypeFun": {ESLVal $934 = _v243.termRef(0);
                              ESLVal $933 = _v243.termRef(1);
                              ESLVal $932 = _v243.termRef(2);
                              
                              {ESLVal _v474 = _v244;
                              
                              {ESLVal l = $934;
                              
                              {ESLVal op = $933;
                              
                              {ESLVal args = $932;
                              
                              return typeEqual.apply(_v474,applyTypeFun.apply(l,forceType.apply(op),args));
                            }
                            }
                            }
                            }
                            }
                          case "ExtendedAct": {ESLVal $931 = _v243.termRef(0);
                              ESLVal $930 = _v243.termRef(1);
                              ESLVal $929 = _v243.termRef(2);
                              ESLVal $928 = _v243.termRef(3);
                              
                              {ESLVal _v471 = _v244;
                              
                              {ESLVal _v472 = $931;
                              
                              {ESLVal _v473 = $930;
                              
                              {ESLVal ds2 = $929;
                              
                              {ESLVal ms2 = $928;
                              
                              return typeEqual.apply(_v471,flattenAct.apply(_v472,_v473,ds2,ms2));
                            }
                            }
                            }
                            }
                            }
                            }
                          case "VoidType": {ESLVal $927 = _v243.termRef(0);
                              
                              {ESLVal t = _v244;
                              
                              {ESLVal _v470 = $927;
                              
                              return $true;
                            }
                            }
                            }
                          case "TermType": {ESLVal $926 = _v243.termRef(0);
                              ESLVal $925 = _v243.termRef(1);
                              ESLVal $924 = _v243.termRef(2);
                              
                              {ESLVal _v468 = _v244;
                              
                              {ESLVal _v469 = $926;
                              
                              {ESLVal n2 = $925;
                              
                              {ESLVal args2 = $924;
                              
                              return $false;
                            }
                            }
                            }
                            }
                            }
                          case "TypeClosure": {ESLVal $923 = _v243.termRef(0);
                              
                              {ESLVal _v467 = _v244;
                              
                              {ESLVal f = $923;
                              
                              return typeEqual.apply(_v467,f.apply());
                            }
                            }
                            }
                          case "RecType": {ESLVal $922 = _v243.termRef(0);
                              ESLVal $921 = _v243.termRef(1);
                              ESLVal $920 = _v243.termRef(2);
                              
                              {ESLVal _v464 = _v244;
                              
                              {ESLVal _v465 = $922;
                              
                              {ESLVal n2 = $921;
                              
                              {ESLVal _v466 = $920;
                              
                              return typeEqual.apply(_v464,substType.apply(new ESLVal("RecType",_v465,n2,_v466),n2,_v466));
                            }
                            }
                            }
                            }
                            }
                          case "ForallType": {ESLVal $919 = _v243.termRef(0);
                              ESLVal $918 = _v243.termRef(1);
                              ESLVal $917 = _v243.termRef(2);
                              
                              {ESLVal _v461 = _v244;
                              
                              {ESLVal _v462 = $919;
                              
                              {ESLVal ns2 = $918;
                              
                              {ESLVal _v463 = $917;
                              
                              return typeEqual.apply(_v461,_v463);
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v475 = _v244;
                              
                              {ESLVal _v476 = _v243;
                              
                              return $false;
                            }
                            }
                          }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      default: switch(_v243.termName) {
                        case "ApplyTypeFun": {ESLVal $934 = _v243.termRef(0);
                          ESLVal $933 = _v243.termRef(1);
                          ESLVal $932 = _v243.termRef(2);
                          
                          {ESLVal _v485 = _v244;
                          
                          {ESLVal l = $934;
                          
                          {ESLVal op = $933;
                          
                          {ESLVal args = $932;
                          
                          return typeEqual.apply(_v485,applyTypeFun.apply(l,forceType.apply(op),args));
                        }
                        }
                        }
                        }
                        }
                      case "ExtendedAct": {ESLVal $931 = _v243.termRef(0);
                          ESLVal $930 = _v243.termRef(1);
                          ESLVal $929 = _v243.termRef(2);
                          ESLVal $928 = _v243.termRef(3);
                          
                          {ESLVal _v483 = _v244;
                          
                          {ESLVal l2 = $931;
                          
                          {ESLVal _v484 = $930;
                          
                          {ESLVal ds2 = $929;
                          
                          {ESLVal ms2 = $928;
                          
                          return typeEqual.apply(_v483,flattenAct.apply(l2,_v484,ds2,ms2));
                        }
                        }
                        }
                        }
                        }
                        }
                      case "VoidType": {ESLVal $927 = _v243.termRef(0);
                          
                          {ESLVal t = _v244;
                          
                          {ESLVal l1 = $927;
                          
                          return $true;
                        }
                        }
                        }
                      case "TermType": {ESLVal $926 = _v243.termRef(0);
                          ESLVal $925 = _v243.termRef(1);
                          ESLVal $924 = _v243.termRef(2);
                          
                          {ESLVal _v482 = _v244;
                          
                          {ESLVal l2 = $926;
                          
                          {ESLVal n2 = $925;
                          
                          {ESLVal args2 = $924;
                          
                          return $false;
                        }
                        }
                        }
                        }
                        }
                      case "TypeClosure": {ESLVal $923 = _v243.termRef(0);
                          
                          {ESLVal _v481 = _v244;
                          
                          {ESLVal f = $923;
                          
                          return typeEqual.apply(_v481,f.apply());
                        }
                        }
                        }
                      case "RecType": {ESLVal $922 = _v243.termRef(0);
                          ESLVal $921 = _v243.termRef(1);
                          ESLVal $920 = _v243.termRef(2);
                          
                          {ESLVal _v479 = _v244;
                          
                          {ESLVal l2 = $922;
                          
                          {ESLVal n2 = $921;
                          
                          {ESLVal _v480 = $920;
                          
                          return typeEqual.apply(_v479,substType.apply(new ESLVal("RecType",l2,n2,_v480),n2,_v480));
                        }
                        }
                        }
                        }
                        }
                      case "ForallType": {ESLVal $919 = _v243.termRef(0);
                          ESLVal $918 = _v243.termRef(1);
                          ESLVal $917 = _v243.termRef(2);
                          
                          {ESLVal _v477 = _v244;
                          
                          {ESLVal l1 = $919;
                          
                          {ESLVal ns2 = $918;
                          
                          {ESLVal _v478 = $917;
                          
                          return typeEqual.apply(_v477,_v478);
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal _v486 = _v244;
                          
                          {ESLVal _v487 = _v243;
                          
                          return $false;
                        }
                        }
                      }
                    }
                    }
                    default: switch(_v243.termName) {
                      case "ApplyTypeFun": {ESLVal $934 = _v243.termRef(0);
                        ESLVal $933 = _v243.termRef(1);
                        ESLVal $932 = _v243.termRef(2);
                        
                        {ESLVal _v496 = _v244;
                        
                        {ESLVal l = $934;
                        
                        {ESLVal op = $933;
                        
                        {ESLVal args = $932;
                        
                        return typeEqual.apply(_v496,applyTypeFun.apply(l,forceType.apply(op),args));
                      }
                      }
                      }
                      }
                      }
                    case "ExtendedAct": {ESLVal $931 = _v243.termRef(0);
                        ESLVal $930 = _v243.termRef(1);
                        ESLVal $929 = _v243.termRef(2);
                        ESLVal $928 = _v243.termRef(3);
                        
                        {ESLVal _v494 = _v244;
                        
                        {ESLVal l2 = $931;
                        
                        {ESLVal _v495 = $930;
                        
                        {ESLVal ds2 = $929;
                        
                        {ESLVal ms2 = $928;
                        
                        return typeEqual.apply(_v494,flattenAct.apply(l2,_v495,ds2,ms2));
                      }
                      }
                      }
                      }
                      }
                      }
                    case "VoidType": {ESLVal $927 = _v243.termRef(0);
                        
                        {ESLVal t = _v244;
                        
                        {ESLVal l1 = $927;
                        
                        return $true;
                      }
                      }
                      }
                    case "TermType": {ESLVal $926 = _v243.termRef(0);
                        ESLVal $925 = _v243.termRef(1);
                        ESLVal $924 = _v243.termRef(2);
                        
                        {ESLVal _v493 = _v244;
                        
                        {ESLVal l2 = $926;
                        
                        {ESLVal n2 = $925;
                        
                        {ESLVal args2 = $924;
                        
                        return $false;
                      }
                      }
                      }
                      }
                      }
                    case "TypeClosure": {ESLVal $923 = _v243.termRef(0);
                        
                        {ESLVal _v492 = _v244;
                        
                        {ESLVal f = $923;
                        
                        return typeEqual.apply(_v492,f.apply());
                      }
                      }
                      }
                    case "RecType": {ESLVal $922 = _v243.termRef(0);
                        ESLVal $921 = _v243.termRef(1);
                        ESLVal $920 = _v243.termRef(2);
                        
                        {ESLVal _v490 = _v244;
                        
                        {ESLVal l2 = $922;
                        
                        {ESLVal n2 = $921;
                        
                        {ESLVal _v491 = $920;
                        
                        return typeEqual.apply(_v490,substType.apply(new ESLVal("RecType",l2,n2,_v491),n2,_v491));
                      }
                      }
                      }
                      }
                      }
                    case "ForallType": {ESLVal $919 = _v243.termRef(0);
                        ESLVal $918 = _v243.termRef(1);
                        ESLVal $917 = _v243.termRef(2);
                        
                        {ESLVal _v488 = _v244;
                        
                        {ESLVal l1 = $919;
                        
                        {ESLVal ns2 = $918;
                        
                        {ESLVal _v489 = $917;
                        
                        return typeEqual.apply(_v488,_v489);
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal _v497 = _v244;
                        
                        {ESLVal _v498 = _v243;
                        
                        return $false;
                      }
                      }
                    }
                  }
                else switch(_v243.termName) {
                    case "ApplyTypeFun": {ESLVal $934 = _v243.termRef(0);
                      ESLVal $933 = _v243.termRef(1);
                      ESLVal $932 = _v243.termRef(2);
                      
                      {ESLVal _v507 = _v244;
                      
                      {ESLVal l = $934;
                      
                      {ESLVal op = $933;
                      
                      {ESLVal args = $932;
                      
                      return typeEqual.apply(_v507,applyTypeFun.apply(l,forceType.apply(op),args));
                    }
                    }
                    }
                    }
                    }
                  case "ExtendedAct": {ESLVal $931 = _v243.termRef(0);
                      ESLVal $930 = _v243.termRef(1);
                      ESLVal $929 = _v243.termRef(2);
                      ESLVal $928 = _v243.termRef(3);
                      
                      {ESLVal _v505 = _v244;
                      
                      {ESLVal l2 = $931;
                      
                      {ESLVal _v506 = $930;
                      
                      {ESLVal ds2 = $929;
                      
                      {ESLVal ms2 = $928;
                      
                      return typeEqual.apply(_v505,flattenAct.apply(l2,_v506,ds2,ms2));
                    }
                    }
                    }
                    }
                    }
                    }
                  case "VoidType": {ESLVal $927 = _v243.termRef(0);
                      
                      {ESLVal t = _v244;
                      
                      {ESLVal l1 = $927;
                      
                      return $true;
                    }
                    }
                    }
                  case "TermType": {ESLVal $926 = _v243.termRef(0);
                      ESLVal $925 = _v243.termRef(1);
                      ESLVal $924 = _v243.termRef(2);
                      
                      {ESLVal _v504 = _v244;
                      
                      {ESLVal l2 = $926;
                      
                      {ESLVal n2 = $925;
                      
                      {ESLVal args2 = $924;
                      
                      return $false;
                    }
                    }
                    }
                    }
                    }
                  case "TypeClosure": {ESLVal $923 = _v243.termRef(0);
                      
                      {ESLVal _v503 = _v244;
                      
                      {ESLVal f = $923;
                      
                      return typeEqual.apply(_v503,f.apply());
                    }
                    }
                    }
                  case "RecType": {ESLVal $922 = _v243.termRef(0);
                      ESLVal $921 = _v243.termRef(1);
                      ESLVal $920 = _v243.termRef(2);
                      
                      {ESLVal _v501 = _v244;
                      
                      {ESLVal l2 = $922;
                      
                      {ESLVal n2 = $921;
                      
                      {ESLVal _v502 = $920;
                      
                      return typeEqual.apply(_v501,substType.apply(new ESLVal("RecType",l2,n2,_v502),n2,_v502));
                    }
                    }
                    }
                    }
                    }
                  case "ForallType": {ESLVal $919 = _v243.termRef(0);
                      ESLVal $918 = _v243.termRef(1);
                      ESLVal $917 = _v243.termRef(2);
                      
                      {ESLVal _v499 = _v244;
                      
                      {ESLVal l1 = $919;
                      
                      {ESLVal ns2 = $918;
                      
                      {ESLVal _v500 = $917;
                      
                      return typeEqual.apply(_v499,_v500);
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal _v508 = _v244;
                      
                      {ESLVal _v509 = _v243;
                      
                      return $false;
                    }
                    }
                  }
                }
              else if($1002.isNil())
                switch(_v243.termName) {
                  case "ApplyTypeFun": {ESLVal $934 = _v243.termRef(0);
                    ESLVal $933 = _v243.termRef(1);
                    ESLVal $932 = _v243.termRef(2);
                    
                    {ESLVal _v518 = _v244;
                    
                    {ESLVal l = $934;
                    
                    {ESLVal op = $933;
                    
                    {ESLVal args = $932;
                    
                    return typeEqual.apply(_v518,applyTypeFun.apply(l,forceType.apply(op),args));
                  }
                  }
                  }
                  }
                  }
                case "ExtendedAct": {ESLVal $931 = _v243.termRef(0);
                    ESLVal $930 = _v243.termRef(1);
                    ESLVal $929 = _v243.termRef(2);
                    ESLVal $928 = _v243.termRef(3);
                    
                    {ESLVal _v516 = _v244;
                    
                    {ESLVal l2 = $931;
                    
                    {ESLVal _v517 = $930;
                    
                    {ESLVal ds2 = $929;
                    
                    {ESLVal ms2 = $928;
                    
                    return typeEqual.apply(_v516,flattenAct.apply(l2,_v517,ds2,ms2));
                  }
                  }
                  }
                  }
                  }
                  }
                case "VoidType": {ESLVal $927 = _v243.termRef(0);
                    
                    {ESLVal t = _v244;
                    
                    {ESLVal l1 = $927;
                    
                    return $true;
                  }
                  }
                  }
                case "TermType": {ESLVal $926 = _v243.termRef(0);
                    ESLVal $925 = _v243.termRef(1);
                    ESLVal $924 = _v243.termRef(2);
                    
                    {ESLVal _v515 = _v244;
                    
                    {ESLVal l2 = $926;
                    
                    {ESLVal n2 = $925;
                    
                    {ESLVal args2 = $924;
                    
                    return $false;
                  }
                  }
                  }
                  }
                  }
                case "TypeClosure": {ESLVal $923 = _v243.termRef(0);
                    
                    {ESLVal _v514 = _v244;
                    
                    {ESLVal f = $923;
                    
                    return typeEqual.apply(_v514,f.apply());
                  }
                  }
                  }
                case "RecType": {ESLVal $922 = _v243.termRef(0);
                    ESLVal $921 = _v243.termRef(1);
                    ESLVal $920 = _v243.termRef(2);
                    
                    {ESLVal _v512 = _v244;
                    
                    {ESLVal l2 = $922;
                    
                    {ESLVal n2 = $921;
                    
                    {ESLVal _v513 = $920;
                    
                    return typeEqual.apply(_v512,substType.apply(new ESLVal("RecType",l2,n2,_v513),n2,_v513));
                  }
                  }
                  }
                  }
                  }
                case "ForallType": {ESLVal $919 = _v243.termRef(0);
                    ESLVal $918 = _v243.termRef(1);
                    ESLVal $917 = _v243.termRef(2);
                    
                    {ESLVal _v510 = _v244;
                    
                    {ESLVal l1 = $919;
                    
                    {ESLVal ns2 = $918;
                    
                    {ESLVal _v511 = $917;
                    
                    return typeEqual.apply(_v510,_v511);
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v519 = _v244;
                    
                    {ESLVal _v520 = _v243;
                    
                    return $false;
                  }
                  }
                }
              else switch(_v243.termName) {
                  case "ApplyTypeFun": {ESLVal $934 = _v243.termRef(0);
                    ESLVal $933 = _v243.termRef(1);
                    ESLVal $932 = _v243.termRef(2);
                    
                    {ESLVal _v529 = _v244;
                    
                    {ESLVal l = $934;
                    
                    {ESLVal op = $933;
                    
                    {ESLVal args = $932;
                    
                    return typeEqual.apply(_v529,applyTypeFun.apply(l,forceType.apply(op),args));
                  }
                  }
                  }
                  }
                  }
                case "ExtendedAct": {ESLVal $931 = _v243.termRef(0);
                    ESLVal $930 = _v243.termRef(1);
                    ESLVal $929 = _v243.termRef(2);
                    ESLVal $928 = _v243.termRef(3);
                    
                    {ESLVal _v527 = _v244;
                    
                    {ESLVal l2 = $931;
                    
                    {ESLVal _v528 = $930;
                    
                    {ESLVal ds2 = $929;
                    
                    {ESLVal ms2 = $928;
                    
                    return typeEqual.apply(_v527,flattenAct.apply(l2,_v528,ds2,ms2));
                  }
                  }
                  }
                  }
                  }
                  }
                case "VoidType": {ESLVal $927 = _v243.termRef(0);
                    
                    {ESLVal t = _v244;
                    
                    {ESLVal l1 = $927;
                    
                    return $true;
                  }
                  }
                  }
                case "TermType": {ESLVal $926 = _v243.termRef(0);
                    ESLVal $925 = _v243.termRef(1);
                    ESLVal $924 = _v243.termRef(2);
                    
                    {ESLVal _v526 = _v244;
                    
                    {ESLVal l2 = $926;
                    
                    {ESLVal n2 = $925;
                    
                    {ESLVal args2 = $924;
                    
                    return $false;
                  }
                  }
                  }
                  }
                  }
                case "TypeClosure": {ESLVal $923 = _v243.termRef(0);
                    
                    {ESLVal _v525 = _v244;
                    
                    {ESLVal f = $923;
                    
                    return typeEqual.apply(_v525,f.apply());
                  }
                  }
                  }
                case "RecType": {ESLVal $922 = _v243.termRef(0);
                    ESLVal $921 = _v243.termRef(1);
                    ESLVal $920 = _v243.termRef(2);
                    
                    {ESLVal _v523 = _v244;
                    
                    {ESLVal l2 = $922;
                    
                    {ESLVal n2 = $921;
                    
                    {ESLVal _v524 = $920;
                    
                    return typeEqual.apply(_v523,substType.apply(new ESLVal("RecType",l2,n2,_v524),n2,_v524));
                  }
                  }
                  }
                  }
                  }
                case "ForallType": {ESLVal $919 = _v243.termRef(0);
                    ESLVal $918 = _v243.termRef(1);
                    ESLVal $917 = _v243.termRef(2);
                    
                    {ESLVal _v521 = _v244;
                    
                    {ESLVal l1 = $919;
                    
                    {ESLVal ns2 = $918;
                    
                    {ESLVal _v522 = $917;
                    
                    return typeEqual.apply(_v521,_v522);
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal _v530 = _v244;
                    
                    {ESLVal _v531 = _v243;
                    
                    return $false;
                  }
                  }
                }
              }
              default: switch(_v243.termName) {
                case "ApplyTypeFun": {ESLVal $934 = _v243.termRef(0);
                  ESLVal $933 = _v243.termRef(1);
                  ESLVal $932 = _v243.termRef(2);
                  
                  {ESLVal _v542 = _v244;
                  
                  {ESLVal l = $934;
                  
                  {ESLVal op = $933;
                  
                  {ESLVal args = $932;
                  
                  return typeEqual.apply(_v542,applyTypeFun.apply(l,forceType.apply(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $931 = _v243.termRef(0);
                  ESLVal $930 = _v243.termRef(1);
                  ESLVal $929 = _v243.termRef(2);
                  ESLVal $928 = _v243.termRef(3);
                  
                  {ESLVal _v540 = _v244;
                  
                  {ESLVal l2 = $931;
                  
                  {ESLVal _v541 = $930;
                  
                  {ESLVal ds2 = $929;
                  
                  {ESLVal ms2 = $928;
                  
                  return typeEqual.apply(_v540,flattenAct.apply(l2,_v541,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $927 = _v243.termRef(0);
                  
                  {ESLVal t = _v244;
                  
                  {ESLVal l1 = $927;
                  
                  return $true;
                }
                }
                }
              case "TermType": {ESLVal $926 = _v243.termRef(0);
                  ESLVal $925 = _v243.termRef(1);
                  ESLVal $924 = _v243.termRef(2);
                  
                  {ESLVal _v539 = _v244;
                  
                  {ESLVal l2 = $926;
                  
                  {ESLVal n2 = $925;
                  
                  {ESLVal args2 = $924;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $923 = _v243.termRef(0);
                  
                  {ESLVal _v538 = _v244;
                  
                  {ESLVal f = $923;
                  
                  return typeEqual.apply(_v538,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $922 = _v243.termRef(0);
                  ESLVal $921 = _v243.termRef(1);
                  ESLVal $920 = _v243.termRef(2);
                  
                  {ESLVal _v536 = _v244;
                  
                  {ESLVal l2 = $922;
                  
                  {ESLVal n2 = $921;
                  
                  {ESLVal _v537 = $920;
                  
                  return typeEqual.apply(_v536,substType.apply(new ESLVal("RecType",l2,n2,_v537),n2,_v537));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $919 = _v243.termRef(0);
                  ESLVal $918 = _v243.termRef(1);
                  ESLVal $917 = _v243.termRef(2);
                  
                  {ESLVal _v534 = _v244;
                  
                  {ESLVal l1 = $919;
                  
                  {ESLVal ns2 = $918;
                  
                  {ESLVal _v535 = $917;
                  
                  return typeEqual.apply(_v534,_v535);
                }
                }
                }
                }
                }
                default: {ESLVal _v543 = _v244;
                  
                  {ESLVal _v544 = _v243;
                  
                  return $false;
                }
                }
              }
            }
            }
          case "BagType": {ESLVal $996 = _v244.termRef(0);
              ESLVal $995 = _v244.termRef(1);
              
              switch(_v243.termName) {
              case "BagType": {ESLVal $998 = _v243.termRef(0);
                ESLVal $997 = _v243.termRef(1);
                
                {ESLVal l1 = $996;
                
                {ESLVal _v436 = $995;
                
                {ESLVal l2 = $998;
                
                {ESLVal _v437 = $997;
                
                return typeEqual.apply(_v436,_v437);
              }
              }
              }
              }
              }
              default: switch(_v243.termName) {
                case "ApplyTypeFun": {ESLVal $934 = _v243.termRef(0);
                  ESLVal $933 = _v243.termRef(1);
                  ESLVal $932 = _v243.termRef(2);
                  
                  {ESLVal _v446 = _v244;
                  
                  {ESLVal l = $934;
                  
                  {ESLVal op = $933;
                  
                  {ESLVal args = $932;
                  
                  return typeEqual.apply(_v446,applyTypeFun.apply(l,forceType.apply(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $931 = _v243.termRef(0);
                  ESLVal $930 = _v243.termRef(1);
                  ESLVal $929 = _v243.termRef(2);
                  ESLVal $928 = _v243.termRef(3);
                  
                  {ESLVal _v444 = _v244;
                  
                  {ESLVal l2 = $931;
                  
                  {ESLVal _v445 = $930;
                  
                  {ESLVal ds2 = $929;
                  
                  {ESLVal ms2 = $928;
                  
                  return typeEqual.apply(_v444,flattenAct.apply(l2,_v445,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $927 = _v243.termRef(0);
                  
                  {ESLVal t = _v244;
                  
                  {ESLVal l1 = $927;
                  
                  return $true;
                }
                }
                }
              case "TermType": {ESLVal $926 = _v243.termRef(0);
                  ESLVal $925 = _v243.termRef(1);
                  ESLVal $924 = _v243.termRef(2);
                  
                  {ESLVal _v443 = _v244;
                  
                  {ESLVal l2 = $926;
                  
                  {ESLVal n2 = $925;
                  
                  {ESLVal args2 = $924;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $923 = _v243.termRef(0);
                  
                  {ESLVal _v442 = _v244;
                  
                  {ESLVal f = $923;
                  
                  return typeEqual.apply(_v442,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $922 = _v243.termRef(0);
                  ESLVal $921 = _v243.termRef(1);
                  ESLVal $920 = _v243.termRef(2);
                  
                  {ESLVal _v440 = _v244;
                  
                  {ESLVal l2 = $922;
                  
                  {ESLVal n2 = $921;
                  
                  {ESLVal _v441 = $920;
                  
                  return typeEqual.apply(_v440,substType.apply(new ESLVal("RecType",l2,n2,_v441),n2,_v441));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $919 = _v243.termRef(0);
                  ESLVal $918 = _v243.termRef(1);
                  ESLVal $917 = _v243.termRef(2);
                  
                  {ESLVal _v438 = _v244;
                  
                  {ESLVal l1 = $919;
                  
                  {ESLVal ns2 = $918;
                  
                  {ESLVal _v439 = $917;
                  
                  return typeEqual.apply(_v438,_v439);
                }
                }
                }
                }
                }
                default: {ESLVal _v447 = _v244;
                  
                  {ESLVal _v448 = _v243;
                  
                  return $false;
                }
                }
              }
            }
            }
          case "SetType": {ESLVal $992 = _v244.termRef(0);
              ESLVal $991 = _v244.termRef(1);
              
              switch(_v243.termName) {
              case "SetType": {ESLVal $994 = _v243.termRef(0);
                ESLVal $993 = _v243.termRef(1);
                
                {ESLVal l1 = $992;
                
                {ESLVal _v423 = $991;
                
                {ESLVal l2 = $994;
                
                {ESLVal _v424 = $993;
                
                return typeEqual.apply(_v423,_v424);
              }
              }
              }
              }
              }
              default: switch(_v243.termName) {
                case "ApplyTypeFun": {ESLVal $934 = _v243.termRef(0);
                  ESLVal $933 = _v243.termRef(1);
                  ESLVal $932 = _v243.termRef(2);
                  
                  {ESLVal _v433 = _v244;
                  
                  {ESLVal l = $934;
                  
                  {ESLVal op = $933;
                  
                  {ESLVal args = $932;
                  
                  return typeEqual.apply(_v433,applyTypeFun.apply(l,forceType.apply(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $931 = _v243.termRef(0);
                  ESLVal $930 = _v243.termRef(1);
                  ESLVal $929 = _v243.termRef(2);
                  ESLVal $928 = _v243.termRef(3);
                  
                  {ESLVal _v431 = _v244;
                  
                  {ESLVal l2 = $931;
                  
                  {ESLVal _v432 = $930;
                  
                  {ESLVal ds2 = $929;
                  
                  {ESLVal ms2 = $928;
                  
                  return typeEqual.apply(_v431,flattenAct.apply(l2,_v432,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $927 = _v243.termRef(0);
                  
                  {ESLVal t = _v244;
                  
                  {ESLVal l1 = $927;
                  
                  return $true;
                }
                }
                }
              case "TermType": {ESLVal $926 = _v243.termRef(0);
                  ESLVal $925 = _v243.termRef(1);
                  ESLVal $924 = _v243.termRef(2);
                  
                  {ESLVal _v430 = _v244;
                  
                  {ESLVal l2 = $926;
                  
                  {ESLVal n2 = $925;
                  
                  {ESLVal args2 = $924;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $923 = _v243.termRef(0);
                  
                  {ESLVal _v429 = _v244;
                  
                  {ESLVal f = $923;
                  
                  return typeEqual.apply(_v429,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $922 = _v243.termRef(0);
                  ESLVal $921 = _v243.termRef(1);
                  ESLVal $920 = _v243.termRef(2);
                  
                  {ESLVal _v427 = _v244;
                  
                  {ESLVal l2 = $922;
                  
                  {ESLVal n2 = $921;
                  
                  {ESLVal _v428 = $920;
                  
                  return typeEqual.apply(_v427,substType.apply(new ESLVal("RecType",l2,n2,_v428),n2,_v428));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $919 = _v243.termRef(0);
                  ESLVal $918 = _v243.termRef(1);
                  ESLVal $917 = _v243.termRef(2);
                  
                  {ESLVal _v425 = _v244;
                  
                  {ESLVal l1 = $919;
                  
                  {ESLVal ns2 = $918;
                  
                  {ESLVal _v426 = $917;
                  
                  return typeEqual.apply(_v425,_v426);
                }
                }
                }
                }
                }
                default: {ESLVal _v434 = _v244;
                  
                  {ESLVal _v435 = _v243;
                  
                  return $false;
                }
                }
              }
            }
            }
          case "StrType": {ESLVal $989 = _v244.termRef(0);
              
              switch(_v243.termName) {
              case "StrType": {ESLVal $990 = _v243.termRef(0);
                
                {ESLVal l1 = $989;
                
                {ESLVal l2 = $990;
                
                return $true;
              }
              }
              }
              default: switch(_v243.termName) {
                case "ApplyTypeFun": {ESLVal $934 = _v243.termRef(0);
                  ESLVal $933 = _v243.termRef(1);
                  ESLVal $932 = _v243.termRef(2);
                  
                  {ESLVal _v420 = _v244;
                  
                  {ESLVal l = $934;
                  
                  {ESLVal op = $933;
                  
                  {ESLVal args = $932;
                  
                  return typeEqual.apply(_v420,applyTypeFun.apply(l,forceType.apply(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $931 = _v243.termRef(0);
                  ESLVal $930 = _v243.termRef(1);
                  ESLVal $929 = _v243.termRef(2);
                  ESLVal $928 = _v243.termRef(3);
                  
                  {ESLVal _v418 = _v244;
                  
                  {ESLVal l2 = $931;
                  
                  {ESLVal _v419 = $930;
                  
                  {ESLVal ds2 = $929;
                  
                  {ESLVal ms2 = $928;
                  
                  return typeEqual.apply(_v418,flattenAct.apply(l2,_v419,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $927 = _v243.termRef(0);
                  
                  {ESLVal t = _v244;
                  
                  {ESLVal l1 = $927;
                  
                  return $true;
                }
                }
                }
              case "TermType": {ESLVal $926 = _v243.termRef(0);
                  ESLVal $925 = _v243.termRef(1);
                  ESLVal $924 = _v243.termRef(2);
                  
                  {ESLVal _v417 = _v244;
                  
                  {ESLVal l2 = $926;
                  
                  {ESLVal n2 = $925;
                  
                  {ESLVal args2 = $924;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $923 = _v243.termRef(0);
                  
                  {ESLVal _v416 = _v244;
                  
                  {ESLVal f = $923;
                  
                  return typeEqual.apply(_v416,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $922 = _v243.termRef(0);
                  ESLVal $921 = _v243.termRef(1);
                  ESLVal $920 = _v243.termRef(2);
                  
                  {ESLVal _v414 = _v244;
                  
                  {ESLVal l2 = $922;
                  
                  {ESLVal n2 = $921;
                  
                  {ESLVal _v415 = $920;
                  
                  return typeEqual.apply(_v414,substType.apply(new ESLVal("RecType",l2,n2,_v415),n2,_v415));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $919 = _v243.termRef(0);
                  ESLVal $918 = _v243.termRef(1);
                  ESLVal $917 = _v243.termRef(2);
                  
                  {ESLVal _v412 = _v244;
                  
                  {ESLVal l1 = $919;
                  
                  {ESLVal ns2 = $918;
                  
                  {ESLVal _v413 = $917;
                  
                  return typeEqual.apply(_v412,_v413);
                }
                }
                }
                }
                }
                default: {ESLVal _v421 = _v244;
                  
                  {ESLVal _v422 = _v243;
                  
                  return $false;
                }
                }
              }
            }
            }
          case "VoidType": {ESLVal $988 = _v244.termRef(0);
              
              {ESLVal l1 = $988;
              
              {ESLVal t = _v243;
              
              return $true;
            }
            }
            }
          case "FieldType": {ESLVal $984 = _v244.termRef(0);
              ESLVal $983 = _v244.termRef(1);
              ESLVal $982 = _v244.termRef(2);
              
              switch(_v243.termName) {
              case "FieldType": {ESLVal $987 = _v243.termRef(0);
                ESLVal $986 = _v243.termRef(1);
                ESLVal $985 = _v243.termRef(2);
                
                {ESLVal l1 = $984;
                
                {ESLVal n1 = $983;
                
                {ESLVal _v399 = $982;
                
                {ESLVal l2 = $987;
                
                {ESLVal n2 = $986;
                
                {ESLVal _v400 = $985;
                
                return n1.eql(n2).and(typeEqual.apply(_v399,_v400));
              }
              }
              }
              }
              }
              }
              }
              default: switch(_v243.termName) {
                case "ApplyTypeFun": {ESLVal $934 = _v243.termRef(0);
                  ESLVal $933 = _v243.termRef(1);
                  ESLVal $932 = _v243.termRef(2);
                  
                  {ESLVal _v409 = _v244;
                  
                  {ESLVal l = $934;
                  
                  {ESLVal op = $933;
                  
                  {ESLVal args = $932;
                  
                  return typeEqual.apply(_v409,applyTypeFun.apply(l,forceType.apply(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $931 = _v243.termRef(0);
                  ESLVal $930 = _v243.termRef(1);
                  ESLVal $929 = _v243.termRef(2);
                  ESLVal $928 = _v243.termRef(3);
                  
                  {ESLVal _v407 = _v244;
                  
                  {ESLVal l2 = $931;
                  
                  {ESLVal _v408 = $930;
                  
                  {ESLVal ds2 = $929;
                  
                  {ESLVal ms2 = $928;
                  
                  return typeEqual.apply(_v407,flattenAct.apply(l2,_v408,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $927 = _v243.termRef(0);
                  
                  {ESLVal t = _v244;
                  
                  {ESLVal l1 = $927;
                  
                  return $true;
                }
                }
                }
              case "TermType": {ESLVal $926 = _v243.termRef(0);
                  ESLVal $925 = _v243.termRef(1);
                  ESLVal $924 = _v243.termRef(2);
                  
                  {ESLVal _v406 = _v244;
                  
                  {ESLVal l2 = $926;
                  
                  {ESLVal n2 = $925;
                  
                  {ESLVal args2 = $924;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $923 = _v243.termRef(0);
                  
                  {ESLVal _v405 = _v244;
                  
                  {ESLVal f = $923;
                  
                  return typeEqual.apply(_v405,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $922 = _v243.termRef(0);
                  ESLVal $921 = _v243.termRef(1);
                  ESLVal $920 = _v243.termRef(2);
                  
                  {ESLVal _v403 = _v244;
                  
                  {ESLVal l2 = $922;
                  
                  {ESLVal n2 = $921;
                  
                  {ESLVal _v404 = $920;
                  
                  return typeEqual.apply(_v403,substType.apply(new ESLVal("RecType",l2,n2,_v404),n2,_v404));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $919 = _v243.termRef(0);
                  ESLVal $918 = _v243.termRef(1);
                  ESLVal $917 = _v243.termRef(2);
                  
                  {ESLVal _v401 = _v244;
                  
                  {ESLVal l1 = $919;
                  
                  {ESLVal ns2 = $918;
                  
                  {ESLVal _v402 = $917;
                  
                  return typeEqual.apply(_v401,_v402);
                }
                }
                }
                }
                }
                default: {ESLVal _v410 = _v244;
                  
                  {ESLVal _v411 = _v243;
                  
                  return $false;
                }
                }
              }
            }
            }
          case "TermType": {ESLVal $978 = _v244.termRef(0);
              ESLVal $977 = _v244.termRef(1);
              ESLVal $976 = _v244.termRef(2);
              
              switch(_v243.termName) {
              case "TermType": {ESLVal $981 = _v243.termRef(0);
                ESLVal $980 = _v243.termRef(1);
                ESLVal $979 = _v243.termRef(2);
                
                {ESLVal l1 = $978;
                
                {ESLVal n1 = $977;
                
                {ESLVal args1 = $976;
                
                {ESLVal l2 = $981;
                
                {ESLVal n2 = $980;
                
                {ESLVal args2 = $979;
                
                if(n1.eql(n2).boolVal)
                return typesEqual.apply(args1,args2);
                else
                  return $false;
              }
              }
              }
              }
              }
              }
              }
              default: {ESLVal l1 = $978;
                
                {ESLVal n1 = $977;
                
                {ESLVal args1 = $976;
                
                {ESLVal _v398 = _v243;
                
                return $false;
              }
              }
              }
              }
            }
            }
          case "FunType": {ESLVal $972 = _v244.termRef(0);
              ESLVal $971 = _v244.termRef(1);
              ESLVal $970 = _v244.termRef(2);
              
              switch(_v243.termName) {
              case "FunType": {ESLVal $975 = _v243.termRef(0);
                ESLVal $974 = _v243.termRef(1);
                ESLVal $973 = _v243.termRef(2);
                
                {ESLVal l1 = $972;
                
                {ESLVal d1 = $971;
                
                {ESLVal r1 = $970;
                
                {ESLVal l2 = $975;
                
                {ESLVal d2 = $974;
                
                {ESLVal r2 = $973;
                
                return typeEqual.apply(r1,r2).and(typesEqual.apply(d1,d2));
              }
              }
              }
              }
              }
              }
              }
              default: switch(_v243.termName) {
                case "ApplyTypeFun": {ESLVal $934 = _v243.termRef(0);
                  ESLVal $933 = _v243.termRef(1);
                  ESLVal $932 = _v243.termRef(2);
                  
                  {ESLVal _v395 = _v244;
                  
                  {ESLVal l = $934;
                  
                  {ESLVal op = $933;
                  
                  {ESLVal args = $932;
                  
                  return typeEqual.apply(_v395,applyTypeFun.apply(l,forceType.apply(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $931 = _v243.termRef(0);
                  ESLVal $930 = _v243.termRef(1);
                  ESLVal $929 = _v243.termRef(2);
                  ESLVal $928 = _v243.termRef(3);
                  
                  {ESLVal _v393 = _v244;
                  
                  {ESLVal l2 = $931;
                  
                  {ESLVal _v394 = $930;
                  
                  {ESLVal ds2 = $929;
                  
                  {ESLVal ms2 = $928;
                  
                  return typeEqual.apply(_v393,flattenAct.apply(l2,_v394,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $927 = _v243.termRef(0);
                  
                  {ESLVal t = _v244;
                  
                  {ESLVal l1 = $927;
                  
                  return $true;
                }
                }
                }
              case "TermType": {ESLVal $926 = _v243.termRef(0);
                  ESLVal $925 = _v243.termRef(1);
                  ESLVal $924 = _v243.termRef(2);
                  
                  {ESLVal _v392 = _v244;
                  
                  {ESLVal l2 = $926;
                  
                  {ESLVal n2 = $925;
                  
                  {ESLVal args2 = $924;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $923 = _v243.termRef(0);
                  
                  {ESLVal _v391 = _v244;
                  
                  {ESLVal f = $923;
                  
                  return typeEqual.apply(_v391,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $922 = _v243.termRef(0);
                  ESLVal $921 = _v243.termRef(1);
                  ESLVal $920 = _v243.termRef(2);
                  
                  {ESLVal _v389 = _v244;
                  
                  {ESLVal l2 = $922;
                  
                  {ESLVal n2 = $921;
                  
                  {ESLVal _v390 = $920;
                  
                  return typeEqual.apply(_v389,substType.apply(new ESLVal("RecType",l2,n2,_v390),n2,_v390));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $919 = _v243.termRef(0);
                  ESLVal $918 = _v243.termRef(1);
                  ESLVal $917 = _v243.termRef(2);
                  
                  {ESLVal _v387 = _v244;
                  
                  {ESLVal l1 = $919;
                  
                  {ESLVal ns2 = $918;
                  
                  {ESLVal _v388 = $917;
                  
                  return typeEqual.apply(_v387,_v388);
                }
                }
                }
                }
                }
                default: {ESLVal _v396 = _v244;
                  
                  {ESLVal _v397 = _v243;
                  
                  return $false;
                }
                }
              }
            }
            }
          case "TypeClosure": {ESLVal $969 = _v244.termRef(0);
              
              {ESLVal f = $969;
              
              {ESLVal _v386 = _v243;
              
              return typeEqual.apply(f.apply(),_v386);
            }
            }
            }
          case "RecordType": {ESLVal $966 = _v244.termRef(0);
              ESLVal $965 = _v244.termRef(1);
              
              switch(_v243.termName) {
              case "RecordType": {ESLVal $968 = _v243.termRef(0);
                ESLVal $967 = _v243.termRef(1);
                
                {ESLVal l1 = $966;
                
                {ESLVal fs1 = $965;
                
                {ESLVal l2 = $968;
                
                {ESLVal fs2 = $967;
                
                return recordTypeEqual.apply(fs1,fs2);
              }
              }
              }
              }
              }
              default: switch(_v243.termName) {
                case "ApplyTypeFun": {ESLVal $934 = _v243.termRef(0);
                  ESLVal $933 = _v243.termRef(1);
                  ESLVal $932 = _v243.termRef(2);
                  
                  {ESLVal _v383 = _v244;
                  
                  {ESLVal l = $934;
                  
                  {ESLVal op = $933;
                  
                  {ESLVal args = $932;
                  
                  return typeEqual.apply(_v383,applyTypeFun.apply(l,forceType.apply(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $931 = _v243.termRef(0);
                  ESLVal $930 = _v243.termRef(1);
                  ESLVal $929 = _v243.termRef(2);
                  ESLVal $928 = _v243.termRef(3);
                  
                  {ESLVal _v381 = _v244;
                  
                  {ESLVal l2 = $931;
                  
                  {ESLVal _v382 = $930;
                  
                  {ESLVal ds2 = $929;
                  
                  {ESLVal ms2 = $928;
                  
                  return typeEqual.apply(_v381,flattenAct.apply(l2,_v382,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $927 = _v243.termRef(0);
                  
                  {ESLVal t = _v244;
                  
                  {ESLVal l1 = $927;
                  
                  return $true;
                }
                }
                }
              case "TermType": {ESLVal $926 = _v243.termRef(0);
                  ESLVal $925 = _v243.termRef(1);
                  ESLVal $924 = _v243.termRef(2);
                  
                  {ESLVal _v380 = _v244;
                  
                  {ESLVal l2 = $926;
                  
                  {ESLVal n2 = $925;
                  
                  {ESLVal args2 = $924;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $923 = _v243.termRef(0);
                  
                  {ESLVal _v379 = _v244;
                  
                  {ESLVal f = $923;
                  
                  return typeEqual.apply(_v379,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $922 = _v243.termRef(0);
                  ESLVal $921 = _v243.termRef(1);
                  ESLVal $920 = _v243.termRef(2);
                  
                  {ESLVal _v377 = _v244;
                  
                  {ESLVal l2 = $922;
                  
                  {ESLVal n2 = $921;
                  
                  {ESLVal _v378 = $920;
                  
                  return typeEqual.apply(_v377,substType.apply(new ESLVal("RecType",l2,n2,_v378),n2,_v378));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $919 = _v243.termRef(0);
                  ESLVal $918 = _v243.termRef(1);
                  ESLVal $917 = _v243.termRef(2);
                  
                  {ESLVal _v375 = _v244;
                  
                  {ESLVal l1 = $919;
                  
                  {ESLVal ns2 = $918;
                  
                  {ESLVal _v376 = $917;
                  
                  return typeEqual.apply(_v375,_v376);
                }
                }
                }
                }
                }
                default: {ESLVal _v384 = _v244;
                  
                  {ESLVal _v385 = _v243;
                  
                  return $false;
                }
                }
              }
            }
            }
          case "RecType": {ESLVal $961 = _v244.termRef(0);
              ESLVal $960 = _v244.termRef(1);
              ESLVal $959 = _v244.termRef(2);
              
              switch(_v243.termName) {
              case "RecType": {ESLVal $964 = _v243.termRef(0);
                ESLVal $963 = _v243.termRef(1);
                ESLVal $962 = _v243.termRef(2);
                
                {ESLVal l1 = $961;
                
                {ESLVal n1 = $960;
                
                {ESLVal _v367 = $959;
                
                {ESLVal l2 = $964;
                
                {ESLVal n2 = $963;
                
                {ESLVal _v368 = $962;
                
                if(n1.eql(n2).boolVal)
                return typeEqual.apply(_v367,_v368);
                else
                  {ESLVal _v369 = $961;
                    
                    {ESLVal _v370 = $960;
                    
                    {ESLVal _v371 = $959;
                    
                    {ESLVal _v372 = _v243;
                    
                    return typeEqual.apply(substType.apply(new ESLVal("RecType",_v369,_v370,_v371),_v370,_v371),_v372);
                  }
                  }
                  }
                  }
              }
              }
              }
              }
              }
              }
              }
              default: {ESLVal l1 = $961;
                
                {ESLVal n1 = $960;
                
                {ESLVal _v373 = $959;
                
                {ESLVal _v374 = _v243;
                
                return typeEqual.apply(substType.apply(new ESLVal("RecType",l1,n1,_v373),n1,_v373),_v374);
              }
              }
              }
              }
            }
            }
          case "UnionType": {ESLVal $956 = _v244.termRef(0);
              ESLVal $955 = _v244.termRef(1);
              
              switch(_v243.termName) {
              case "UnionType": {ESLVal $958 = _v243.termRef(0);
                ESLVal $957 = _v243.termRef(1);
                
                {ESLVal l1 = $956;
                
                {ESLVal terms1 = $955;
                
                {ESLVal l2 = $958;
                
                {ESLVal terms2 = $957;
                
                return typeSetEqual.apply(terms1,terms2);
              }
              }
              }
              }
              }
              default: switch(_v243.termName) {
                case "ApplyTypeFun": {ESLVal $934 = _v243.termRef(0);
                  ESLVal $933 = _v243.termRef(1);
                  ESLVal $932 = _v243.termRef(2);
                  
                  {ESLVal _v364 = _v244;
                  
                  {ESLVal l = $934;
                  
                  {ESLVal op = $933;
                  
                  {ESLVal args = $932;
                  
                  return typeEqual.apply(_v364,applyTypeFun.apply(l,forceType.apply(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $931 = _v243.termRef(0);
                  ESLVal $930 = _v243.termRef(1);
                  ESLVal $929 = _v243.termRef(2);
                  ESLVal $928 = _v243.termRef(3);
                  
                  {ESLVal _v362 = _v244;
                  
                  {ESLVal l2 = $931;
                  
                  {ESLVal _v363 = $930;
                  
                  {ESLVal ds2 = $929;
                  
                  {ESLVal ms2 = $928;
                  
                  return typeEqual.apply(_v362,flattenAct.apply(l2,_v363,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $927 = _v243.termRef(0);
                  
                  {ESLVal t = _v244;
                  
                  {ESLVal l1 = $927;
                  
                  return $true;
                }
                }
                }
              case "TermType": {ESLVal $926 = _v243.termRef(0);
                  ESLVal $925 = _v243.termRef(1);
                  ESLVal $924 = _v243.termRef(2);
                  
                  {ESLVal _v361 = _v244;
                  
                  {ESLVal l2 = $926;
                  
                  {ESLVal n2 = $925;
                  
                  {ESLVal args2 = $924;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $923 = _v243.termRef(0);
                  
                  {ESLVal _v360 = _v244;
                  
                  {ESLVal f = $923;
                  
                  return typeEqual.apply(_v360,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $922 = _v243.termRef(0);
                  ESLVal $921 = _v243.termRef(1);
                  ESLVal $920 = _v243.termRef(2);
                  
                  {ESLVal _v358 = _v244;
                  
                  {ESLVal l2 = $922;
                  
                  {ESLVal n2 = $921;
                  
                  {ESLVal _v359 = $920;
                  
                  return typeEqual.apply(_v358,substType.apply(new ESLVal("RecType",l2,n2,_v359),n2,_v359));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $919 = _v243.termRef(0);
                  ESLVal $918 = _v243.termRef(1);
                  ESLVal $917 = _v243.termRef(2);
                  
                  {ESLVal _v356 = _v244;
                  
                  {ESLVal l1 = $919;
                  
                  {ESLVal ns2 = $918;
                  
                  {ESLVal _v357 = $917;
                  
                  return typeEqual.apply(_v356,_v357);
                }
                }
                }
                }
                }
                default: {ESLVal _v365 = _v244;
                  
                  {ESLVal _v366 = _v243;
                  
                  return $false;
                }
                }
              }
            }
            }
          case "VarType": {ESLVal $952 = _v244.termRef(0);
              ESLVal $951 = _v244.termRef(1);
              
              switch(_v243.termName) {
              case "VarType": {ESLVal $954 = _v243.termRef(0);
                ESLVal $953 = _v243.termRef(1);
                
                {ESLVal l1 = $952;
                
                {ESLVal n1 = $951;
                
                {ESLVal l2 = $954;
                
                {ESLVal n2 = $953;
                
                return n1.eql(n2);
              }
              }
              }
              }
              }
              default: switch(_v243.termName) {
                case "ApplyTypeFun": {ESLVal $934 = _v243.termRef(0);
                  ESLVal $933 = _v243.termRef(1);
                  ESLVal $932 = _v243.termRef(2);
                  
                  {ESLVal _v353 = _v244;
                  
                  {ESLVal l = $934;
                  
                  {ESLVal op = $933;
                  
                  {ESLVal args = $932;
                  
                  return typeEqual.apply(_v353,applyTypeFun.apply(l,forceType.apply(op),args));
                }
                }
                }
                }
                }
              case "ExtendedAct": {ESLVal $931 = _v243.termRef(0);
                  ESLVal $930 = _v243.termRef(1);
                  ESLVal $929 = _v243.termRef(2);
                  ESLVal $928 = _v243.termRef(3);
                  
                  {ESLVal _v351 = _v244;
                  
                  {ESLVal l2 = $931;
                  
                  {ESLVal _v352 = $930;
                  
                  {ESLVal ds2 = $929;
                  
                  {ESLVal ms2 = $928;
                  
                  return typeEqual.apply(_v351,flattenAct.apply(l2,_v352,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "VoidType": {ESLVal $927 = _v243.termRef(0);
                  
                  {ESLVal t = _v244;
                  
                  {ESLVal l1 = $927;
                  
                  return $true;
                }
                }
                }
              case "TermType": {ESLVal $926 = _v243.termRef(0);
                  ESLVal $925 = _v243.termRef(1);
                  ESLVal $924 = _v243.termRef(2);
                  
                  {ESLVal _v350 = _v244;
                  
                  {ESLVal l2 = $926;
                  
                  {ESLVal n2 = $925;
                  
                  {ESLVal args2 = $924;
                  
                  return $false;
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $923 = _v243.termRef(0);
                  
                  {ESLVal _v349 = _v244;
                  
                  {ESLVal f = $923;
                  
                  return typeEqual.apply(_v349,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $922 = _v243.termRef(0);
                  ESLVal $921 = _v243.termRef(1);
                  ESLVal $920 = _v243.termRef(2);
                  
                  {ESLVal _v347 = _v244;
                  
                  {ESLVal l2 = $922;
                  
                  {ESLVal n2 = $921;
                  
                  {ESLVal _v348 = $920;
                  
                  return typeEqual.apply(_v347,substType.apply(new ESLVal("RecType",l2,n2,_v348),n2,_v348));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $919 = _v243.termRef(0);
                  ESLVal $918 = _v243.termRef(1);
                  ESLVal $917 = _v243.termRef(2);
                  
                  {ESLVal _v345 = _v244;
                  
                  {ESLVal l1 = $919;
                  
                  {ESLVal ns2 = $918;
                  
                  {ESLVal _v346 = $917;
                  
                  return typeEqual.apply(_v345,_v346);
                }
                }
                }
                }
                }
                default: {ESLVal _v354 = _v244;
                  
                  {ESLVal _v355 = _v243;
                  
                  return $false;
                }
                }
              }
            }
            }
          case "ForallType": {ESLVal $937 = _v244.termRef(0);
              ESLVal $936 = _v244.termRef(1);
              ESLVal $935 = _v244.termRef(2);
              
              if($936.isCons())
              {ESLVal $941 = $936.head();
                ESLVal $942 = $936.tail();
                
                if($942.isCons())
                {ESLVal $943 = $942.head();
                  ESLVal $944 = $942.tail();
                  
                  switch(_v243.termName) {
                  case "ForallType": {ESLVal $940 = _v243.termRef(0);
                    ESLVal $939 = _v243.termRef(1);
                    ESLVal $938 = _v243.termRef(2);
                    
                    {ESLVal l1 = $937;
                    
                    {ESLVal ns1 = $936;
                    
                    {ESLVal _v309 = $935;
                    
                    {ESLVal l2 = $940;
                    
                    {ESLVal ns2 = $939;
                    
                    {ESLVal _v310 = $938;
                    
                    return ns1.eql(ns2).and(typeEqual.apply(_v309,_v310));
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal l1 = $937;
                    
                    {ESLVal ns1 = $936;
                    
                    {ESLVal _v311 = $935;
                    
                    {ESLVal _v312 = _v243;
                    
                    return typeEqual.apply(_v311,_v312);
                  }
                  }
                  }
                  }
                }
                }
              else if($942.isNil())
                switch($935.termName) {
                  case "ListType": {ESLVal $946 = $935.termRef(0);
                    ESLVal $945 = $935.termRef(1);
                    
                    switch($945.termName) {
                    case "VarType": {ESLVal $948 = $945.termRef(0);
                      ESLVal $947 = $945.termRef(1);
                      
                      switch(_v243.termName) {
                      case "ListType": {ESLVal $950 = _v243.termRef(0);
                        ESLVal $949 = _v243.termRef(1);
                        
                        {ESLVal l2 = $937;
                        
                        {ESLVal v1 = $941;
                        
                        {ESLVal l3 = $946;
                        
                        {ESLVal l4 = $948;
                        
                        {ESLVal v2 = $947;
                        
                        {ESLVal l1 = $950;
                        
                        {ESLVal _v313 = $949;
                        
                        if(v1.eql(v2).boolVal)
                        return $true;
                        else
                          switch(_v243.termName) {
                            case "ForallType": {ESLVal $940 = _v243.termRef(0);
                              ESLVal $939 = _v243.termRef(1);
                              ESLVal $938 = _v243.termRef(2);
                              
                              {ESLVal _v314 = $937;
                              
                              {ESLVal ns1 = $936;
                              
                              {ESLVal _v315 = $935;
                              
                              {ESLVal _v316 = $940;
                              
                              {ESLVal ns2 = $939;
                              
                              {ESLVal _v317 = $938;
                              
                              return ns1.eql(ns2).and(typeEqual.apply(_v315,_v317));
                            }
                            }
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v318 = $937;
                              
                              {ESLVal ns1 = $936;
                              
                              {ESLVal _v319 = $935;
                              
                              {ESLVal _v320 = _v243;
                              
                              return typeEqual.apply(_v319,_v320);
                            }
                            }
                            }
                            }
                          }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      default: switch(_v243.termName) {
                        case "ForallType": {ESLVal $940 = _v243.termRef(0);
                          ESLVal $939 = _v243.termRef(1);
                          ESLVal $938 = _v243.termRef(2);
                          
                          {ESLVal l1 = $937;
                          
                          {ESLVal ns1 = $936;
                          
                          {ESLVal _v321 = $935;
                          
                          {ESLVal l2 = $940;
                          
                          {ESLVal ns2 = $939;
                          
                          {ESLVal _v322 = $938;
                          
                          return ns1.eql(ns2).and(typeEqual.apply(_v321,_v322));
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal l1 = $937;
                          
                          {ESLVal ns1 = $936;
                          
                          {ESLVal _v323 = $935;
                          
                          {ESLVal _v324 = _v243;
                          
                          return typeEqual.apply(_v323,_v324);
                        }
                        }
                        }
                        }
                      }
                    }
                    }
                    default: switch(_v243.termName) {
                      case "ForallType": {ESLVal $940 = _v243.termRef(0);
                        ESLVal $939 = _v243.termRef(1);
                        ESLVal $938 = _v243.termRef(2);
                        
                        {ESLVal l1 = $937;
                        
                        {ESLVal ns1 = $936;
                        
                        {ESLVal _v325 = $935;
                        
                        {ESLVal l2 = $940;
                        
                        {ESLVal ns2 = $939;
                        
                        {ESLVal _v326 = $938;
                        
                        return ns1.eql(ns2).and(typeEqual.apply(_v325,_v326));
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal l1 = $937;
                        
                        {ESLVal ns1 = $936;
                        
                        {ESLVal _v327 = $935;
                        
                        {ESLVal _v328 = _v243;
                        
                        return typeEqual.apply(_v327,_v328);
                      }
                      }
                      }
                      }
                    }
                  }
                  }
                  default: switch(_v243.termName) {
                    case "ForallType": {ESLVal $940 = _v243.termRef(0);
                      ESLVal $939 = _v243.termRef(1);
                      ESLVal $938 = _v243.termRef(2);
                      
                      {ESLVal l1 = $937;
                      
                      {ESLVal ns1 = $936;
                      
                      {ESLVal _v329 = $935;
                      
                      {ESLVal l2 = $940;
                      
                      {ESLVal ns2 = $939;
                      
                      {ESLVal _v330 = $938;
                      
                      return ns1.eql(ns2).and(typeEqual.apply(_v329,_v330));
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal l1 = $937;
                      
                      {ESLVal ns1 = $936;
                      
                      {ESLVal _v331 = $935;
                      
                      {ESLVal _v332 = _v243;
                      
                      return typeEqual.apply(_v331,_v332);
                    }
                    }
                    }
                    }
                  }
                }
              else switch(_v243.termName) {
                  case "ForallType": {ESLVal $940 = _v243.termRef(0);
                    ESLVal $939 = _v243.termRef(1);
                    ESLVal $938 = _v243.termRef(2);
                    
                    {ESLVal l1 = $937;
                    
                    {ESLVal ns1 = $936;
                    
                    {ESLVal _v333 = $935;
                    
                    {ESLVal l2 = $940;
                    
                    {ESLVal ns2 = $939;
                    
                    {ESLVal _v334 = $938;
                    
                    return ns1.eql(ns2).and(typeEqual.apply(_v333,_v334));
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal l1 = $937;
                    
                    {ESLVal ns1 = $936;
                    
                    {ESLVal _v335 = $935;
                    
                    {ESLVal _v336 = _v243;
                    
                    return typeEqual.apply(_v335,_v336);
                  }
                  }
                  }
                  }
                }
              }
            else if($936.isNil())
              switch(_v243.termName) {
                case "ForallType": {ESLVal $940 = _v243.termRef(0);
                  ESLVal $939 = _v243.termRef(1);
                  ESLVal $938 = _v243.termRef(2);
                  
                  {ESLVal l1 = $937;
                  
                  {ESLVal ns1 = $936;
                  
                  {ESLVal _v337 = $935;
                  
                  {ESLVal l2 = $940;
                  
                  {ESLVal ns2 = $939;
                  
                  {ESLVal _v338 = $938;
                  
                  return ns1.eql(ns2).and(typeEqual.apply(_v337,_v338));
                }
                }
                }
                }
                }
                }
                }
                default: {ESLVal l1 = $937;
                  
                  {ESLVal ns1 = $936;
                  
                  {ESLVal _v339 = $935;
                  
                  {ESLVal _v340 = _v243;
                  
                  return typeEqual.apply(_v339,_v340);
                }
                }
                }
                }
              }
            else switch(_v243.termName) {
                case "ForallType": {ESLVal $940 = _v243.termRef(0);
                  ESLVal $939 = _v243.termRef(1);
                  ESLVal $938 = _v243.termRef(2);
                  
                  {ESLVal l1 = $937;
                  
                  {ESLVal ns1 = $936;
                  
                  {ESLVal _v341 = $935;
                  
                  {ESLVal l2 = $940;
                  
                  {ESLVal ns2 = $939;
                  
                  {ESLVal _v342 = $938;
                  
                  return ns1.eql(ns2).and(typeEqual.apply(_v341,_v342));
                }
                }
                }
                }
                }
                }
                }
                default: {ESLVal l1 = $937;
                  
                  {ESLVal ns1 = $936;
                  
                  {ESLVal _v343 = $935;
                  
                  {ESLVal _v344 = _v243;
                  
                  return typeEqual.apply(_v343,_v344);
                }
                }
                }
                }
              }
            }
            default: switch(_v243.termName) {
              case "ApplyTypeFun": {ESLVal $934 = _v243.termRef(0);
                ESLVal $933 = _v243.termRef(1);
                ESLVal $932 = _v243.termRef(2);
                
                {ESLVal _v613 = _v244;
                
                {ESLVal l = $934;
                
                {ESLVal op = $933;
                
                {ESLVal args = $932;
                
                return typeEqual.apply(_v613,applyTypeFun.apply(l,forceType.apply(op),args));
              }
              }
              }
              }
              }
            case "ExtendedAct": {ESLVal $931 = _v243.termRef(0);
                ESLVal $930 = _v243.termRef(1);
                ESLVal $929 = _v243.termRef(2);
                ESLVal $928 = _v243.termRef(3);
                
                {ESLVal _v611 = _v244;
                
                {ESLVal l2 = $931;
                
                {ESLVal _v612 = $930;
                
                {ESLVal ds2 = $929;
                
                {ESLVal ms2 = $928;
                
                return typeEqual.apply(_v611,flattenAct.apply(l2,_v612,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "VoidType": {ESLVal $927 = _v243.termRef(0);
                
                {ESLVal t = _v244;
                
                {ESLVal l1 = $927;
                
                return $true;
              }
              }
              }
            case "TermType": {ESLVal $926 = _v243.termRef(0);
                ESLVal $925 = _v243.termRef(1);
                ESLVal $924 = _v243.termRef(2);
                
                {ESLVal _v610 = _v244;
                
                {ESLVal l2 = $926;
                
                {ESLVal n2 = $925;
                
                {ESLVal args2 = $924;
                
                return $false;
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $923 = _v243.termRef(0);
                
                {ESLVal _v609 = _v244;
                
                {ESLVal f = $923;
                
                return typeEqual.apply(_v609,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $922 = _v243.termRef(0);
                ESLVal $921 = _v243.termRef(1);
                ESLVal $920 = _v243.termRef(2);
                
                {ESLVal _v607 = _v244;
                
                {ESLVal l2 = $922;
                
                {ESLVal n2 = $921;
                
                {ESLVal _v608 = $920;
                
                return typeEqual.apply(_v607,substType.apply(new ESLVal("RecType",l2,n2,_v608),n2,_v608));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $919 = _v243.termRef(0);
                ESLVal $918 = _v243.termRef(1);
                ESLVal $917 = _v243.termRef(2);
                
                {ESLVal _v605 = _v244;
                
                {ESLVal l1 = $919;
                
                {ESLVal ns2 = $918;
                
                {ESLVal _v606 = $917;
                
                return typeEqual.apply(_v605,_v606);
              }
              }
              }
              }
              }
              default: {ESLVal _v614 = _v244;
                
                {ESLVal _v615 = _v243;
                
                return $false;
              }
              }
            }
          }
          }
    }
  });
  public static ESLVal subType = new ESLVal(new Function(new ESLVal("subType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal sub = $args[0];
  ESLVal parent = $args[1];
  if(sub.eql(parent).boolVal)
        return $true;
        else
          {ESLVal _v242 = sub;
            ESLVal _v241 = parent;
            
            switch(_v242.termName) {
            case "ActType": {ESLVal $913 = _v242.termRef(0);
              ESLVal $912 = _v242.termRef(1);
              ESLVal $911 = _v242.termRef(2);
              
              switch(_v241.termName) {
              case "ActType": {ESLVal $916 = _v241.termRef(0);
                ESLVal $915 = _v241.termRef(1);
                ESLVal $914 = _v241.termRef(2);
                
                {ESLVal l1 = $913;
                
                {ESLVal exports1 = $912;
                
                {ESLVal handlers1 = $911;
                
                {ESLVal l2 = $916;
                
                {ESLVal exports2 = $915;
                
                {ESLVal handlers2 = $914;
                
                return actSubType.apply(exports1,exports1,handlers1,handlers2);
              }
              }
              }
              }
              }
              }
              }
              default: switch(_v241.termName) {
                case "ExtendedAct": {ESLVal $836 = _v241.termRef(0);
                  ESLVal $835 = _v241.termRef(1);
                  ESLVal $834 = _v241.termRef(2);
                  ESLVal $833 = _v241.termRef(3);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal l2 = $836;
                  
                  {ESLVal t2 = $835;
                  
                  {ESLVal ds2 = $834;
                  
                  {ESLVal ms2 = $833;
                  
                  return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $832 = _v241.termRef(0);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal f = $832;
                  
                  return subType.apply(t1,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $831 = _v241.termRef(0);
                  ESLVal $830 = _v241.termRef(1);
                  ESLVal $829 = _v241.termRef(2);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal l2 = $831;
                  
                  {ESLVal n2 = $830;
                  
                  {ESLVal t2 = $829;
                  
                  return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $828 = _v241.termRef(0);
                  ESLVal $827 = _v241.termRef(1);
                  ESLVal $826 = _v241.termRef(2);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal l1 = $828;
                  
                  {ESLVal ns2 = $827;
                  
                  {ESLVal t2 = $826;
                  
                  return subType.apply(t1,t2);
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v242;
                  
                  {ESLVal t2 = _v241;
                  
                  return typeEqual.apply(t1,t2);
                }
                }
              }
            }
            }
          case "ExtendedAct": {ESLVal $910 = _v242.termRef(0);
              ESLVal $909 = _v242.termRef(1);
              ESLVal $908 = _v242.termRef(2);
              ESLVal $907 = _v242.termRef(3);
              
              {ESLVal l1 = $910;
              
              {ESLVal t1 = $909;
              
              {ESLVal ds1 = $908;
              
              {ESLVal ms1 = $907;
              
              {ESLVal t2 = _v241;
              
              return subType.apply(flattenAct.apply(l1,t1,ds1,ms1),t2);
            }
            }
            }
            }
            }
            }
          case "ListType": {ESLVal $893 = _v242.termRef(0);
              ESLVal $892 = _v242.termRef(1);
              
              switch(_v241.termName) {
              case "ListType": {ESLVal $906 = _v241.termRef(0);
                ESLVal $905 = _v241.termRef(1);
                
                {ESLVal l1 = $893;
                
                {ESLVal t1 = $892;
                
                {ESLVal l2 = $906;
                
                {ESLVal t2 = $905;
                
                return subType.apply(t1,t2);
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $896 = _v241.termRef(0);
                ESLVal $895 = _v241.termRef(1);
                ESLVal $894 = _v241.termRef(2);
                
                if($895.isCons())
                {ESLVal $897 = $895.head();
                  ESLVal $898 = $895.tail();
                  
                  if($898.isCons())
                  {ESLVal $899 = $898.head();
                    ESLVal $900 = $898.tail();
                    
                    switch(_v241.termName) {
                    case "ExtendedAct": {ESLVal $836 = _v241.termRef(0);
                      ESLVal $835 = _v241.termRef(1);
                      ESLVal $834 = _v241.termRef(2);
                      ESLVal $833 = _v241.termRef(3);
                      
                      {ESLVal t1 = _v242;
                      
                      {ESLVal l2 = $836;
                      
                      {ESLVal t2 = $835;
                      
                      {ESLVal ds2 = $834;
                      
                      {ESLVal ms2 = $833;
                      
                      return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                    }
                    }
                    }
                    }
                    }
                    }
                  case "TypeClosure": {ESLVal $832 = _v241.termRef(0);
                      
                      {ESLVal t1 = _v242;
                      
                      {ESLVal f = $832;
                      
                      return subType.apply(t1,f.apply());
                    }
                    }
                    }
                  case "RecType": {ESLVal $831 = _v241.termRef(0);
                      ESLVal $830 = _v241.termRef(1);
                      ESLVal $829 = _v241.termRef(2);
                      
                      {ESLVal t1 = _v242;
                      
                      {ESLVal l2 = $831;
                      
                      {ESLVal n2 = $830;
                      
                      {ESLVal t2 = $829;
                      
                      return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                    }
                    }
                    }
                    }
                    }
                  case "ForallType": {ESLVal $828 = _v241.termRef(0);
                      ESLVal $827 = _v241.termRef(1);
                      ESLVal $826 = _v241.termRef(2);
                      
                      {ESLVal t1 = _v242;
                      
                      {ESLVal l1 = $828;
                      
                      {ESLVal ns2 = $827;
                      
                      {ESLVal t2 = $826;
                      
                      return subType.apply(t1,t2);
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal t1 = _v242;
                      
                      {ESLVal t2 = _v241;
                      
                      return typeEqual.apply(t1,t2);
                    }
                    }
                  }
                  }
                else if($898.isNil())
                  switch($894.termName) {
                    case "ListType": {ESLVal $902 = $894.termRef(0);
                      ESLVal $901 = $894.termRef(1);
                      
                      switch($901.termName) {
                      case "VarType": {ESLVal $904 = $901.termRef(0);
                        ESLVal $903 = $901.termRef(1);
                        
                        {ESLVal l1 = $893;
                        
                        {ESLVal t1 = $892;
                        
                        {ESLVal l2 = $896;
                        
                        {ESLVal v1 = $897;
                        
                        {ESLVal l3 = $902;
                        
                        {ESLVal l4 = $904;
                        
                        {ESLVal v2 = $903;
                        
                        if(v1.eql(v2).boolVal)
                        return $true;
                        else
                          switch(_v241.termName) {
                            case "ExtendedAct": {ESLVal $836 = _v241.termRef(0);
                              ESLVal $835 = _v241.termRef(1);
                              ESLVal $834 = _v241.termRef(2);
                              ESLVal $833 = _v241.termRef(3);
                              
                              {ESLVal _v306 = _v242;
                              
                              {ESLVal _v307 = $836;
                              
                              {ESLVal t2 = $835;
                              
                              {ESLVal ds2 = $834;
                              
                              {ESLVal ms2 = $833;
                              
                              return subType.apply(_v306,flattenAct.apply(_v307,t2,ds2,ms2));
                            }
                            }
                            }
                            }
                            }
                            }
                          case "TypeClosure": {ESLVal $832 = _v241.termRef(0);
                              
                              {ESLVal _v305 = _v242;
                              
                              {ESLVal f = $832;
                              
                              return subType.apply(_v305,f.apply());
                            }
                            }
                            }
                          case "RecType": {ESLVal $831 = _v241.termRef(0);
                              ESLVal $830 = _v241.termRef(1);
                              ESLVal $829 = _v241.termRef(2);
                              
                              {ESLVal _v303 = _v242;
                              
                              {ESLVal _v304 = $831;
                              
                              {ESLVal n2 = $830;
                              
                              {ESLVal t2 = $829;
                              
                              return subType.apply(_v303,substType.apply(new ESLVal("RecType",_v304,n2,t2),n2,t2));
                            }
                            }
                            }
                            }
                            }
                          case "ForallType": {ESLVal $828 = _v241.termRef(0);
                              ESLVal $827 = _v241.termRef(1);
                              ESLVal $826 = _v241.termRef(2);
                              
                              {ESLVal _v301 = _v242;
                              
                              {ESLVal _v302 = $828;
                              
                              {ESLVal ns2 = $827;
                              
                              {ESLVal t2 = $826;
                              
                              return subType.apply(_v301,t2);
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v308 = _v242;
                              
                              {ESLVal t2 = _v241;
                              
                              return typeEqual.apply(_v308,t2);
                            }
                            }
                          }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      default: switch(_v241.termName) {
                        case "ExtendedAct": {ESLVal $836 = _v241.termRef(0);
                          ESLVal $835 = _v241.termRef(1);
                          ESLVal $834 = _v241.termRef(2);
                          ESLVal $833 = _v241.termRef(3);
                          
                          {ESLVal t1 = _v242;
                          
                          {ESLVal l2 = $836;
                          
                          {ESLVal t2 = $835;
                          
                          {ESLVal ds2 = $834;
                          
                          {ESLVal ms2 = $833;
                          
                          return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                        }
                        }
                        }
                        }
                        }
                        }
                      case "TypeClosure": {ESLVal $832 = _v241.termRef(0);
                          
                          {ESLVal t1 = _v242;
                          
                          {ESLVal f = $832;
                          
                          return subType.apply(t1,f.apply());
                        }
                        }
                        }
                      case "RecType": {ESLVal $831 = _v241.termRef(0);
                          ESLVal $830 = _v241.termRef(1);
                          ESLVal $829 = _v241.termRef(2);
                          
                          {ESLVal t1 = _v242;
                          
                          {ESLVal l2 = $831;
                          
                          {ESLVal n2 = $830;
                          
                          {ESLVal t2 = $829;
                          
                          return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                        }
                        }
                        }
                        }
                        }
                      case "ForallType": {ESLVal $828 = _v241.termRef(0);
                          ESLVal $827 = _v241.termRef(1);
                          ESLVal $826 = _v241.termRef(2);
                          
                          {ESLVal t1 = _v242;
                          
                          {ESLVal l1 = $828;
                          
                          {ESLVal ns2 = $827;
                          
                          {ESLVal t2 = $826;
                          
                          return subType.apply(t1,t2);
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal t1 = _v242;
                          
                          {ESLVal t2 = _v241;
                          
                          return typeEqual.apply(t1,t2);
                        }
                        }
                      }
                    }
                    }
                    default: switch(_v241.termName) {
                      case "ExtendedAct": {ESLVal $836 = _v241.termRef(0);
                        ESLVal $835 = _v241.termRef(1);
                        ESLVal $834 = _v241.termRef(2);
                        ESLVal $833 = _v241.termRef(3);
                        
                        {ESLVal t1 = _v242;
                        
                        {ESLVal l2 = $836;
                        
                        {ESLVal t2 = $835;
                        
                        {ESLVal ds2 = $834;
                        
                        {ESLVal ms2 = $833;
                        
                        return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                      }
                      }
                      }
                      }
                      }
                      }
                    case "TypeClosure": {ESLVal $832 = _v241.termRef(0);
                        
                        {ESLVal t1 = _v242;
                        
                        {ESLVal f = $832;
                        
                        return subType.apply(t1,f.apply());
                      }
                      }
                      }
                    case "RecType": {ESLVal $831 = _v241.termRef(0);
                        ESLVal $830 = _v241.termRef(1);
                        ESLVal $829 = _v241.termRef(2);
                        
                        {ESLVal t1 = _v242;
                        
                        {ESLVal l2 = $831;
                        
                        {ESLVal n2 = $830;
                        
                        {ESLVal t2 = $829;
                        
                        return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                      }
                      }
                      }
                      }
                      }
                    case "ForallType": {ESLVal $828 = _v241.termRef(0);
                        ESLVal $827 = _v241.termRef(1);
                        ESLVal $826 = _v241.termRef(2);
                        
                        {ESLVal t1 = _v242;
                        
                        {ESLVal l1 = $828;
                        
                        {ESLVal ns2 = $827;
                        
                        {ESLVal t2 = $826;
                        
                        return subType.apply(t1,t2);
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal t1 = _v242;
                        
                        {ESLVal t2 = _v241;
                        
                        return typeEqual.apply(t1,t2);
                      }
                      }
                    }
                  }
                else switch(_v241.termName) {
                    case "ExtendedAct": {ESLVal $836 = _v241.termRef(0);
                      ESLVal $835 = _v241.termRef(1);
                      ESLVal $834 = _v241.termRef(2);
                      ESLVal $833 = _v241.termRef(3);
                      
                      {ESLVal t1 = _v242;
                      
                      {ESLVal l2 = $836;
                      
                      {ESLVal t2 = $835;
                      
                      {ESLVal ds2 = $834;
                      
                      {ESLVal ms2 = $833;
                      
                      return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                    }
                    }
                    }
                    }
                    }
                    }
                  case "TypeClosure": {ESLVal $832 = _v241.termRef(0);
                      
                      {ESLVal t1 = _v242;
                      
                      {ESLVal f = $832;
                      
                      return subType.apply(t1,f.apply());
                    }
                    }
                    }
                  case "RecType": {ESLVal $831 = _v241.termRef(0);
                      ESLVal $830 = _v241.termRef(1);
                      ESLVal $829 = _v241.termRef(2);
                      
                      {ESLVal t1 = _v242;
                      
                      {ESLVal l2 = $831;
                      
                      {ESLVal n2 = $830;
                      
                      {ESLVal t2 = $829;
                      
                      return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                    }
                    }
                    }
                    }
                    }
                  case "ForallType": {ESLVal $828 = _v241.termRef(0);
                      ESLVal $827 = _v241.termRef(1);
                      ESLVal $826 = _v241.termRef(2);
                      
                      {ESLVal t1 = _v242;
                      
                      {ESLVal l1 = $828;
                      
                      {ESLVal ns2 = $827;
                      
                      {ESLVal t2 = $826;
                      
                      return subType.apply(t1,t2);
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal t1 = _v242;
                      
                      {ESLVal t2 = _v241;
                      
                      return typeEqual.apply(t1,t2);
                    }
                    }
                  }
                }
              else if($895.isNil())
                switch(_v241.termName) {
                  case "ExtendedAct": {ESLVal $836 = _v241.termRef(0);
                    ESLVal $835 = _v241.termRef(1);
                    ESLVal $834 = _v241.termRef(2);
                    ESLVal $833 = _v241.termRef(3);
                    
                    {ESLVal t1 = _v242;
                    
                    {ESLVal l2 = $836;
                    
                    {ESLVal t2 = $835;
                    
                    {ESLVal ds2 = $834;
                    
                    {ESLVal ms2 = $833;
                    
                    return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                  }
                  }
                  }
                  }
                  }
                  }
                case "TypeClosure": {ESLVal $832 = _v241.termRef(0);
                    
                    {ESLVal t1 = _v242;
                    
                    {ESLVal f = $832;
                    
                    return subType.apply(t1,f.apply());
                  }
                  }
                  }
                case "RecType": {ESLVal $831 = _v241.termRef(0);
                    ESLVal $830 = _v241.termRef(1);
                    ESLVal $829 = _v241.termRef(2);
                    
                    {ESLVal t1 = _v242;
                    
                    {ESLVal l2 = $831;
                    
                    {ESLVal n2 = $830;
                    
                    {ESLVal t2 = $829;
                    
                    return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                  }
                  }
                  }
                  }
                  }
                case "ForallType": {ESLVal $828 = _v241.termRef(0);
                    ESLVal $827 = _v241.termRef(1);
                    ESLVal $826 = _v241.termRef(2);
                    
                    {ESLVal t1 = _v242;
                    
                    {ESLVal l1 = $828;
                    
                    {ESLVal ns2 = $827;
                    
                    {ESLVal t2 = $826;
                    
                    return subType.apply(t1,t2);
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal t1 = _v242;
                    
                    {ESLVal t2 = _v241;
                    
                    return typeEqual.apply(t1,t2);
                  }
                  }
                }
              else switch(_v241.termName) {
                  case "ExtendedAct": {ESLVal $836 = _v241.termRef(0);
                    ESLVal $835 = _v241.termRef(1);
                    ESLVal $834 = _v241.termRef(2);
                    ESLVal $833 = _v241.termRef(3);
                    
                    {ESLVal t1 = _v242;
                    
                    {ESLVal l2 = $836;
                    
                    {ESLVal t2 = $835;
                    
                    {ESLVal ds2 = $834;
                    
                    {ESLVal ms2 = $833;
                    
                    return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                  }
                  }
                  }
                  }
                  }
                  }
                case "TypeClosure": {ESLVal $832 = _v241.termRef(0);
                    
                    {ESLVal t1 = _v242;
                    
                    {ESLVal f = $832;
                    
                    return subType.apply(t1,f.apply());
                  }
                  }
                  }
                case "RecType": {ESLVal $831 = _v241.termRef(0);
                    ESLVal $830 = _v241.termRef(1);
                    ESLVal $829 = _v241.termRef(2);
                    
                    {ESLVal t1 = _v242;
                    
                    {ESLVal l2 = $831;
                    
                    {ESLVal n2 = $830;
                    
                    {ESLVal t2 = $829;
                    
                    return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                  }
                  }
                  }
                  }
                  }
                case "ForallType": {ESLVal $828 = _v241.termRef(0);
                    ESLVal $827 = _v241.termRef(1);
                    ESLVal $826 = _v241.termRef(2);
                    
                    {ESLVal t1 = _v242;
                    
                    {ESLVal l1 = $828;
                    
                    {ESLVal ns2 = $827;
                    
                    {ESLVal t2 = $826;
                    
                    return subType.apply(t1,t2);
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal t1 = _v242;
                    
                    {ESLVal t2 = _v241;
                    
                    return typeEqual.apply(t1,t2);
                  }
                  }
                }
              }
              default: switch(_v241.termName) {
                case "ExtendedAct": {ESLVal $836 = _v241.termRef(0);
                  ESLVal $835 = _v241.termRef(1);
                  ESLVal $834 = _v241.termRef(2);
                  ESLVal $833 = _v241.termRef(3);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal l2 = $836;
                  
                  {ESLVal t2 = $835;
                  
                  {ESLVal ds2 = $834;
                  
                  {ESLVal ms2 = $833;
                  
                  return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $832 = _v241.termRef(0);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal f = $832;
                  
                  return subType.apply(t1,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $831 = _v241.termRef(0);
                  ESLVal $830 = _v241.termRef(1);
                  ESLVal $829 = _v241.termRef(2);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal l2 = $831;
                  
                  {ESLVal n2 = $830;
                  
                  {ESLVal t2 = $829;
                  
                  return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $828 = _v241.termRef(0);
                  ESLVal $827 = _v241.termRef(1);
                  ESLVal $826 = _v241.termRef(2);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal l1 = $828;
                  
                  {ESLVal ns2 = $827;
                  
                  {ESLVal t2 = $826;
                  
                  return subType.apply(t1,t2);
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v242;
                  
                  {ESLVal t2 = _v241;
                  
                  return typeEqual.apply(t1,t2);
                }
                }
              }
            }
            }
          case "BagType": {ESLVal $889 = _v242.termRef(0);
              ESLVal $888 = _v242.termRef(1);
              
              switch(_v241.termName) {
              case "BagType": {ESLVal $891 = _v241.termRef(0);
                ESLVal $890 = _v241.termRef(1);
                
                {ESLVal l1 = $889;
                
                {ESLVal t1 = $888;
                
                {ESLVal l2 = $891;
                
                {ESLVal t2 = $890;
                
                return subType.apply(t1,t2);
              }
              }
              }
              }
              }
              default: switch(_v241.termName) {
                case "ExtendedAct": {ESLVal $836 = _v241.termRef(0);
                  ESLVal $835 = _v241.termRef(1);
                  ESLVal $834 = _v241.termRef(2);
                  ESLVal $833 = _v241.termRef(3);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal l2 = $836;
                  
                  {ESLVal t2 = $835;
                  
                  {ESLVal ds2 = $834;
                  
                  {ESLVal ms2 = $833;
                  
                  return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $832 = _v241.termRef(0);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal f = $832;
                  
                  return subType.apply(t1,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $831 = _v241.termRef(0);
                  ESLVal $830 = _v241.termRef(1);
                  ESLVal $829 = _v241.termRef(2);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal l2 = $831;
                  
                  {ESLVal n2 = $830;
                  
                  {ESLVal t2 = $829;
                  
                  return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $828 = _v241.termRef(0);
                  ESLVal $827 = _v241.termRef(1);
                  ESLVal $826 = _v241.termRef(2);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal l1 = $828;
                  
                  {ESLVal ns2 = $827;
                  
                  {ESLVal t2 = $826;
                  
                  return subType.apply(t1,t2);
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v242;
                  
                  {ESLVal t2 = _v241;
                  
                  return typeEqual.apply(t1,t2);
                }
                }
              }
            }
            }
          case "SetType": {ESLVal $885 = _v242.termRef(0);
              ESLVal $884 = _v242.termRef(1);
              
              switch(_v241.termName) {
              case "SetType": {ESLVal $887 = _v241.termRef(0);
                ESLVal $886 = _v241.termRef(1);
                
                {ESLVal l1 = $885;
                
                {ESLVal t1 = $884;
                
                {ESLVal l2 = $887;
                
                {ESLVal t2 = $886;
                
                return subType.apply(t1,t2);
              }
              }
              }
              }
              }
              default: switch(_v241.termName) {
                case "ExtendedAct": {ESLVal $836 = _v241.termRef(0);
                  ESLVal $835 = _v241.termRef(1);
                  ESLVal $834 = _v241.termRef(2);
                  ESLVal $833 = _v241.termRef(3);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal l2 = $836;
                  
                  {ESLVal t2 = $835;
                  
                  {ESLVal ds2 = $834;
                  
                  {ESLVal ms2 = $833;
                  
                  return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $832 = _v241.termRef(0);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal f = $832;
                  
                  return subType.apply(t1,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $831 = _v241.termRef(0);
                  ESLVal $830 = _v241.termRef(1);
                  ESLVal $829 = _v241.termRef(2);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal l2 = $831;
                  
                  {ESLVal n2 = $830;
                  
                  {ESLVal t2 = $829;
                  
                  return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $828 = _v241.termRef(0);
                  ESLVal $827 = _v241.termRef(1);
                  ESLVal $826 = _v241.termRef(2);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal l1 = $828;
                  
                  {ESLVal ns2 = $827;
                  
                  {ESLVal t2 = $826;
                  
                  return subType.apply(t1,t2);
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v242;
                  
                  {ESLVal t2 = _v241;
                  
                  return typeEqual.apply(t1,t2);
                }
                }
              }
            }
            }
          case "TermType": {ESLVal $880 = _v242.termRef(0);
              ESLVal $879 = _v242.termRef(1);
              ESLVal $878 = _v242.termRef(2);
              
              switch(_v241.termName) {
              case "TermType": {ESLVal $883 = _v241.termRef(0);
                ESLVal $882 = _v241.termRef(1);
                ESLVal $881 = _v241.termRef(2);
                
                {ESLVal l1 = $880;
                
                {ESLVal n1 = $879;
                
                {ESLVal args1 = $878;
                
                {ESLVal l2 = $883;
                
                {ESLVal n2 = $882;
                
                {ESLVal args2 = $881;
                
                if(n1.eql(n2).boolVal)
                return subTypes.apply(args1,args2);
                else
                  return $false;
              }
              }
              }
              }
              }
              }
              }
              default: switch(_v241.termName) {
                case "ExtendedAct": {ESLVal $836 = _v241.termRef(0);
                  ESLVal $835 = _v241.termRef(1);
                  ESLVal $834 = _v241.termRef(2);
                  ESLVal $833 = _v241.termRef(3);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal l2 = $836;
                  
                  {ESLVal t2 = $835;
                  
                  {ESLVal ds2 = $834;
                  
                  {ESLVal ms2 = $833;
                  
                  return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $832 = _v241.termRef(0);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal f = $832;
                  
                  return subType.apply(t1,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $831 = _v241.termRef(0);
                  ESLVal $830 = _v241.termRef(1);
                  ESLVal $829 = _v241.termRef(2);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal l2 = $831;
                  
                  {ESLVal n2 = $830;
                  
                  {ESLVal t2 = $829;
                  
                  return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $828 = _v241.termRef(0);
                  ESLVal $827 = _v241.termRef(1);
                  ESLVal $826 = _v241.termRef(2);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal l1 = $828;
                  
                  {ESLVal ns2 = $827;
                  
                  {ESLVal t2 = $826;
                  
                  return subType.apply(t1,t2);
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v242;
                  
                  {ESLVal t2 = _v241;
                  
                  return typeEqual.apply(t1,t2);
                }
                }
              }
            }
            }
          case "FunType": {ESLVal $874 = _v242.termRef(0);
              ESLVal $873 = _v242.termRef(1);
              ESLVal $872 = _v242.termRef(2);
              
              switch(_v241.termName) {
              case "FunType": {ESLVal $877 = _v241.termRef(0);
                ESLVal $876 = _v241.termRef(1);
                ESLVal $875 = _v241.termRef(2);
                
                {ESLVal l1 = $874;
                
                {ESLVal d1 = $873;
                
                {ESLVal r1 = $872;
                
                {ESLVal l2 = $877;
                
                {ESLVal d2 = $876;
                
                {ESLVal r2 = $875;
                
                return subType.apply(r1,r2).and(subTypes.apply(d2,d1));
              }
              }
              }
              }
              }
              }
              }
              default: switch(_v241.termName) {
                case "ExtendedAct": {ESLVal $836 = _v241.termRef(0);
                  ESLVal $835 = _v241.termRef(1);
                  ESLVal $834 = _v241.termRef(2);
                  ESLVal $833 = _v241.termRef(3);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal l2 = $836;
                  
                  {ESLVal t2 = $835;
                  
                  {ESLVal ds2 = $834;
                  
                  {ESLVal ms2 = $833;
                  
                  return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $832 = _v241.termRef(0);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal f = $832;
                  
                  return subType.apply(t1,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $831 = _v241.termRef(0);
                  ESLVal $830 = _v241.termRef(1);
                  ESLVal $829 = _v241.termRef(2);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal l2 = $831;
                  
                  {ESLVal n2 = $830;
                  
                  {ESLVal t2 = $829;
                  
                  return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $828 = _v241.termRef(0);
                  ESLVal $827 = _v241.termRef(1);
                  ESLVal $826 = _v241.termRef(2);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal l1 = $828;
                  
                  {ESLVal ns2 = $827;
                  
                  {ESLVal t2 = $826;
                  
                  return subType.apply(t1,t2);
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v242;
                  
                  {ESLVal t2 = _v241;
                  
                  return typeEqual.apply(t1,t2);
                }
                }
              }
            }
            }
          case "TypeClosure": {ESLVal $871 = _v242.termRef(0);
              
              {ESLVal f = $871;
              
              {ESLVal t2 = _v241;
              
              return subType.apply(f.apply(),t2);
            }
            }
            }
          case "RecordType": {ESLVal $868 = _v242.termRef(0);
              ESLVal $867 = _v242.termRef(1);
              
              switch(_v241.termName) {
              case "RecordType": {ESLVal $870 = _v241.termRef(0);
                ESLVal $869 = _v241.termRef(1);
                
                {ESLVal l1 = $868;
                
                {ESLVal fs1 = $867;
                
                {ESLVal l2 = $870;
                
                {ESLVal fs2 = $869;
                
                return recordSubType.apply(fs1,fs2);
              }
              }
              }
              }
              }
              default: switch(_v241.termName) {
                case "ExtendedAct": {ESLVal $836 = _v241.termRef(0);
                  ESLVal $835 = _v241.termRef(1);
                  ESLVal $834 = _v241.termRef(2);
                  ESLVal $833 = _v241.termRef(3);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal l2 = $836;
                  
                  {ESLVal t2 = $835;
                  
                  {ESLVal ds2 = $834;
                  
                  {ESLVal ms2 = $833;
                  
                  return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $832 = _v241.termRef(0);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal f = $832;
                  
                  return subType.apply(t1,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $831 = _v241.termRef(0);
                  ESLVal $830 = _v241.termRef(1);
                  ESLVal $829 = _v241.termRef(2);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal l2 = $831;
                  
                  {ESLVal n2 = $830;
                  
                  {ESLVal t2 = $829;
                  
                  return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $828 = _v241.termRef(0);
                  ESLVal $827 = _v241.termRef(1);
                  ESLVal $826 = _v241.termRef(2);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal l1 = $828;
                  
                  {ESLVal ns2 = $827;
                  
                  {ESLVal t2 = $826;
                  
                  return subType.apply(t1,t2);
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v242;
                  
                  {ESLVal t2 = _v241;
                  
                  return typeEqual.apply(t1,t2);
                }
                }
              }
            }
            }
          case "RecType": {ESLVal $863 = _v242.termRef(0);
              ESLVal $862 = _v242.termRef(1);
              ESLVal $861 = _v242.termRef(2);
              
              switch(_v241.termName) {
              case "RecType": {ESLVal $866 = _v241.termRef(0);
                ESLVal $865 = _v241.termRef(1);
                ESLVal $864 = _v241.termRef(2);
                
                {ESLVal l1 = $863;
                
                {ESLVal n1 = $862;
                
                {ESLVal t1 = $861;
                
                {ESLVal l2 = $866;
                
                {ESLVal n2 = $865;
                
                {ESLVal t2 = $864;
                
                if(n1.eql(n2).boolVal)
                return subType.apply(t1,t2);
                else
                  {ESLVal _v297 = $863;
                    
                    {ESLVal _v298 = $862;
                    
                    {ESLVal _v299 = $861;
                    
                    {ESLVal _v300 = _v241;
                    
                    return subType.apply(substType.apply(new ESLVal("RecType",_v297,_v298,_v299),_v298,_v299),_v300);
                  }
                  }
                  }
                  }
              }
              }
              }
              }
              }
              }
              }
              default: {ESLVal l1 = $863;
                
                {ESLVal n1 = $862;
                
                {ESLVal t1 = $861;
                
                {ESLVal t2 = _v241;
                
                return subType.apply(substType.apply(new ESLVal("RecType",l1,n1,t1),n1,t1),t2);
              }
              }
              }
              }
            }
            }
          case "UnionType": {ESLVal $858 = _v242.termRef(0);
              ESLVal $857 = _v242.termRef(1);
              
              switch(_v241.termName) {
              case "UnionType": {ESLVal $860 = _v241.termRef(0);
                ESLVal $859 = _v241.termRef(1);
                
                {ESLVal l1 = $858;
                
                {ESLVal terms1 = $857;
                
                {ESLVal l2 = $860;
                
                {ESLVal terms2 = $859;
                
                return subTypes.apply(terms1,terms2);
              }
              }
              }
              }
              }
              default: switch(_v241.termName) {
                case "ExtendedAct": {ESLVal $836 = _v241.termRef(0);
                  ESLVal $835 = _v241.termRef(1);
                  ESLVal $834 = _v241.termRef(2);
                  ESLVal $833 = _v241.termRef(3);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal l2 = $836;
                  
                  {ESLVal t2 = $835;
                  
                  {ESLVal ds2 = $834;
                  
                  {ESLVal ms2 = $833;
                  
                  return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $832 = _v241.termRef(0);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal f = $832;
                  
                  return subType.apply(t1,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $831 = _v241.termRef(0);
                  ESLVal $830 = _v241.termRef(1);
                  ESLVal $829 = _v241.termRef(2);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal l2 = $831;
                  
                  {ESLVal n2 = $830;
                  
                  {ESLVal t2 = $829;
                  
                  return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $828 = _v241.termRef(0);
                  ESLVal $827 = _v241.termRef(1);
                  ESLVal $826 = _v241.termRef(2);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal l1 = $828;
                  
                  {ESLVal ns2 = $827;
                  
                  {ESLVal t2 = $826;
                  
                  return subType.apply(t1,t2);
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v242;
                  
                  {ESLVal t2 = _v241;
                  
                  return typeEqual.apply(t1,t2);
                }
                }
              }
            }
            }
          case "VarType": {ESLVal $854 = _v242.termRef(0);
              ESLVal $853 = _v242.termRef(1);
              
              switch(_v241.termName) {
              case "VarType": {ESLVal $856 = _v241.termRef(0);
                ESLVal $855 = _v241.termRef(1);
                
                {ESLVal l1 = $854;
                
                {ESLVal n1 = $853;
                
                {ESLVal l2 = $856;
                
                {ESLVal n2 = $855;
                
                return n1.eql(n2);
              }
              }
              }
              }
              }
              default: switch(_v241.termName) {
                case "ExtendedAct": {ESLVal $836 = _v241.termRef(0);
                  ESLVal $835 = _v241.termRef(1);
                  ESLVal $834 = _v241.termRef(2);
                  ESLVal $833 = _v241.termRef(3);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal l2 = $836;
                  
                  {ESLVal t2 = $835;
                  
                  {ESLVal ds2 = $834;
                  
                  {ESLVal ms2 = $833;
                  
                  return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
                }
                }
                }
                }
                }
                }
              case "TypeClosure": {ESLVal $832 = _v241.termRef(0);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal f = $832;
                  
                  return subType.apply(t1,f.apply());
                }
                }
                }
              case "RecType": {ESLVal $831 = _v241.termRef(0);
                  ESLVal $830 = _v241.termRef(1);
                  ESLVal $829 = _v241.termRef(2);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal l2 = $831;
                  
                  {ESLVal n2 = $830;
                  
                  {ESLVal t2 = $829;
                  
                  return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
                }
                }
                }
                }
                }
              case "ForallType": {ESLVal $828 = _v241.termRef(0);
                  ESLVal $827 = _v241.termRef(1);
                  ESLVal $826 = _v241.termRef(2);
                  
                  {ESLVal t1 = _v242;
                  
                  {ESLVal l1 = $828;
                  
                  {ESLVal ns2 = $827;
                  
                  {ESLVal t2 = $826;
                  
                  return subType.apply(t1,t2);
                }
                }
                }
                }
                }
                default: {ESLVal t1 = _v242;
                  
                  {ESLVal t2 = _v241;
                  
                  return typeEqual.apply(t1,t2);
                }
                }
              }
            }
            }
          case "ForallType": {ESLVal $839 = _v242.termRef(0);
              ESLVal $838 = _v242.termRef(1);
              ESLVal $837 = _v242.termRef(2);
              
              if($838.isCons())
              {ESLVal $843 = $838.head();
                ESLVal $844 = $838.tail();
                
                if($844.isCons())
                {ESLVal $845 = $844.head();
                  ESLVal $846 = $844.tail();
                  
                  switch(_v241.termName) {
                  case "ForallType": {ESLVal $842 = _v241.termRef(0);
                    ESLVal $841 = _v241.termRef(1);
                    ESLVal $840 = _v241.termRef(2);
                    
                    {ESLVal l1 = $839;
                    
                    {ESLVal ns1 = $838;
                    
                    {ESLVal t1 = $837;
                    
                    {ESLVal l2 = $842;
                    
                    {ESLVal ns2 = $841;
                    
                    {ESLVal t2 = $840;
                    
                    return ns1.eql(ns2).and(subType.apply(t1,t2));
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal l1 = $839;
                    
                    {ESLVal ns1 = $838;
                    
                    {ESLVal t1 = $837;
                    
                    {ESLVal t2 = _v241;
                    
                    return subType.apply(t1,t2);
                  }
                  }
                  }
                  }
                }
                }
              else if($844.isNil())
                switch($837.termName) {
                  case "ListType": {ESLVal $848 = $837.termRef(0);
                    ESLVal $847 = $837.termRef(1);
                    
                    switch($847.termName) {
                    case "VarType": {ESLVal $850 = $847.termRef(0);
                      ESLVal $849 = $847.termRef(1);
                      
                      switch(_v241.termName) {
                      case "ListType": {ESLVal $852 = _v241.termRef(0);
                        ESLVal $851 = _v241.termRef(1);
                        
                        {ESLVal l2 = $839;
                        
                        {ESLVal v1 = $843;
                        
                        {ESLVal l3 = $848;
                        
                        {ESLVal l4 = $850;
                        
                        {ESLVal v2 = $849;
                        
                        {ESLVal l1 = $852;
                        
                        {ESLVal t1 = $851;
                        
                        if(v1.eql(v2).boolVal)
                        return $true;
                        else
                          switch(_v241.termName) {
                            case "ForallType": {ESLVal $842 = _v241.termRef(0);
                              ESLVal $841 = _v241.termRef(1);
                              ESLVal $840 = _v241.termRef(2);
                              
                              {ESLVal _v292 = $839;
                              
                              {ESLVal ns1 = $838;
                              
                              {ESLVal _v293 = $837;
                              
                              {ESLVal _v294 = $842;
                              
                              {ESLVal ns2 = $841;
                              
                              {ESLVal t2 = $840;
                              
                              return ns1.eql(ns2).and(subType.apply(_v293,t2));
                            }
                            }
                            }
                            }
                            }
                            }
                            }
                            default: {ESLVal _v295 = $839;
                              
                              {ESLVal ns1 = $838;
                              
                              {ESLVal _v296 = $837;
                              
                              {ESLVal t2 = _v241;
                              
                              return subType.apply(_v296,t2);
                            }
                            }
                            }
                            }
                          }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      default: switch(_v241.termName) {
                        case "ForallType": {ESLVal $842 = _v241.termRef(0);
                          ESLVal $841 = _v241.termRef(1);
                          ESLVal $840 = _v241.termRef(2);
                          
                          {ESLVal l1 = $839;
                          
                          {ESLVal ns1 = $838;
                          
                          {ESLVal t1 = $837;
                          
                          {ESLVal l2 = $842;
                          
                          {ESLVal ns2 = $841;
                          
                          {ESLVal t2 = $840;
                          
                          return ns1.eql(ns2).and(subType.apply(t1,t2));
                        }
                        }
                        }
                        }
                        }
                        }
                        }
                        default: {ESLVal l1 = $839;
                          
                          {ESLVal ns1 = $838;
                          
                          {ESLVal t1 = $837;
                          
                          {ESLVal t2 = _v241;
                          
                          return subType.apply(t1,t2);
                        }
                        }
                        }
                        }
                      }
                    }
                    }
                    default: switch(_v241.termName) {
                      case "ForallType": {ESLVal $842 = _v241.termRef(0);
                        ESLVal $841 = _v241.termRef(1);
                        ESLVal $840 = _v241.termRef(2);
                        
                        {ESLVal l1 = $839;
                        
                        {ESLVal ns1 = $838;
                        
                        {ESLVal t1 = $837;
                        
                        {ESLVal l2 = $842;
                        
                        {ESLVal ns2 = $841;
                        
                        {ESLVal t2 = $840;
                        
                        return ns1.eql(ns2).and(subType.apply(t1,t2));
                      }
                      }
                      }
                      }
                      }
                      }
                      }
                      default: {ESLVal l1 = $839;
                        
                        {ESLVal ns1 = $838;
                        
                        {ESLVal t1 = $837;
                        
                        {ESLVal t2 = _v241;
                        
                        return subType.apply(t1,t2);
                      }
                      }
                      }
                      }
                    }
                  }
                  }
                  default: switch(_v241.termName) {
                    case "ForallType": {ESLVal $842 = _v241.termRef(0);
                      ESLVal $841 = _v241.termRef(1);
                      ESLVal $840 = _v241.termRef(2);
                      
                      {ESLVal l1 = $839;
                      
                      {ESLVal ns1 = $838;
                      
                      {ESLVal t1 = $837;
                      
                      {ESLVal l2 = $842;
                      
                      {ESLVal ns2 = $841;
                      
                      {ESLVal t2 = $840;
                      
                      return ns1.eql(ns2).and(subType.apply(t1,t2));
                    }
                    }
                    }
                    }
                    }
                    }
                    }
                    default: {ESLVal l1 = $839;
                      
                      {ESLVal ns1 = $838;
                      
                      {ESLVal t1 = $837;
                      
                      {ESLVal t2 = _v241;
                      
                      return subType.apply(t1,t2);
                    }
                    }
                    }
                    }
                  }
                }
              else switch(_v241.termName) {
                  case "ForallType": {ESLVal $842 = _v241.termRef(0);
                    ESLVal $841 = _v241.termRef(1);
                    ESLVal $840 = _v241.termRef(2);
                    
                    {ESLVal l1 = $839;
                    
                    {ESLVal ns1 = $838;
                    
                    {ESLVal t1 = $837;
                    
                    {ESLVal l2 = $842;
                    
                    {ESLVal ns2 = $841;
                    
                    {ESLVal t2 = $840;
                    
                    return ns1.eql(ns2).and(subType.apply(t1,t2));
                  }
                  }
                  }
                  }
                  }
                  }
                  }
                  default: {ESLVal l1 = $839;
                    
                    {ESLVal ns1 = $838;
                    
                    {ESLVal t1 = $837;
                    
                    {ESLVal t2 = _v241;
                    
                    return subType.apply(t1,t2);
                  }
                  }
                  }
                  }
                }
              }
            else if($838.isNil())
              switch(_v241.termName) {
                case "ForallType": {ESLVal $842 = _v241.termRef(0);
                  ESLVal $841 = _v241.termRef(1);
                  ESLVal $840 = _v241.termRef(2);
                  
                  {ESLVal l1 = $839;
                  
                  {ESLVal ns1 = $838;
                  
                  {ESLVal t1 = $837;
                  
                  {ESLVal l2 = $842;
                  
                  {ESLVal ns2 = $841;
                  
                  {ESLVal t2 = $840;
                  
                  return ns1.eql(ns2).and(subType.apply(t1,t2));
                }
                }
                }
                }
                }
                }
                }
                default: {ESLVal l1 = $839;
                  
                  {ESLVal ns1 = $838;
                  
                  {ESLVal t1 = $837;
                  
                  {ESLVal t2 = _v241;
                  
                  return subType.apply(t1,t2);
                }
                }
                }
                }
              }
            else switch(_v241.termName) {
                case "ForallType": {ESLVal $842 = _v241.termRef(0);
                  ESLVal $841 = _v241.termRef(1);
                  ESLVal $840 = _v241.termRef(2);
                  
                  {ESLVal l1 = $839;
                  
                  {ESLVal ns1 = $838;
                  
                  {ESLVal t1 = $837;
                  
                  {ESLVal l2 = $842;
                  
                  {ESLVal ns2 = $841;
                  
                  {ESLVal t2 = $840;
                  
                  return ns1.eql(ns2).and(subType.apply(t1,t2));
                }
                }
                }
                }
                }
                }
                }
                default: {ESLVal l1 = $839;
                  
                  {ESLVal ns1 = $838;
                  
                  {ESLVal t1 = $837;
                  
                  {ESLVal t2 = _v241;
                  
                  return subType.apply(t1,t2);
                }
                }
                }
                }
              }
            }
            default: switch(_v241.termName) {
              case "ExtendedAct": {ESLVal $836 = _v241.termRef(0);
                ESLVal $835 = _v241.termRef(1);
                ESLVal $834 = _v241.termRef(2);
                ESLVal $833 = _v241.termRef(3);
                
                {ESLVal t1 = _v242;
                
                {ESLVal l2 = $836;
                
                {ESLVal t2 = $835;
                
                {ESLVal ds2 = $834;
                
                {ESLVal ms2 = $833;
                
                return subType.apply(t1,flattenAct.apply(l2,t2,ds2,ms2));
              }
              }
              }
              }
              }
              }
            case "TypeClosure": {ESLVal $832 = _v241.termRef(0);
                
                {ESLVal t1 = _v242;
                
                {ESLVal f = $832;
                
                return subType.apply(t1,f.apply());
              }
              }
              }
            case "RecType": {ESLVal $831 = _v241.termRef(0);
                ESLVal $830 = _v241.termRef(1);
                ESLVal $829 = _v241.termRef(2);
                
                {ESLVal t1 = _v242;
                
                {ESLVal l2 = $831;
                
                {ESLVal n2 = $830;
                
                {ESLVal t2 = $829;
                
                return subType.apply(t1,substType.apply(new ESLVal("RecType",l2,n2,t2),n2,t2));
              }
              }
              }
              }
              }
            case "ForallType": {ESLVal $828 = _v241.termRef(0);
                ESLVal $827 = _v241.termRef(1);
                ESLVal $826 = _v241.termRef(2);
                
                {ESLVal t1 = _v242;
                
                {ESLVal l1 = $828;
                
                {ESLVal ns2 = $827;
                
                {ESLVal t2 = $826;
                
                return subType.apply(t1,t2);
              }
              }
              }
              }
              }
              default: {ESLVal t1 = _v242;
                
                {ESLVal t2 = _v241;
                
                return typeEqual.apply(t1,t2);
              }
              }
            }
          }
          }
    }
  });
  private static ESLVal flattenAct = new ESLVal(new Function(new ESLVal("flattenAct"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l1 = $args[0];
  ESLVal t = $args[1];
  ESLVal ds1 = $args[2];
  ESLVal ms1 = $args[3];
  {ESLVal _v240 = t;
        
        switch(_v240.termName) {
        case "ActType": {ESLVal $825 = _v240.termRef(0);
          ESLVal $824 = _v240.termRef(1);
          ESLVal $823 = _v240.termRef(2);
          
          {ESLVal l2 = $825;
          
          {ESLVal ds2 = $824;
          
          {ESLVal ms2 = $823;
          
          return new ESLVal("ActType",l1,ds1.add(ds2),ms1.add(ms2));
        }
        }
        }
        }
      case "ExtendedAct": {ESLVal $822 = _v240.termRef(0);
          ESLVal $821 = _v240.termRef(1);
          ESLVal $820 = _v240.termRef(2);
          ESLVal $819 = _v240.termRef(3);
          
          {ESLVal l2 = $822;
          
          {ESLVal _v290 = $821;
          
          {ESLVal ds2 = $820;
          
          {ESLVal ms2 = $819;
          
          return flattenAct.apply(l1,flattenAct.apply(l2,_v290,ds2,ms2),ds1,ms1);
        }
        }
        }
        }
        }
      case "TypeClosure": {ESLVal $818 = _v240.termRef(0);
          
          {ESLVal f = $818;
          
          return flattenAct.apply(l1,f.apply(),ds1,ms1);
        }
        }
      case "RecType": {ESLVal $817 = _v240.termRef(0);
          ESLVal $816 = _v240.termRef(1);
          ESLVal $815 = _v240.termRef(2);
          
          {ESLVal l2 = $817;
          
          {ESLVal n = $816;
          
          {ESLVal b = $815;
          
          return flattenAct.apply(l1,substType.apply(t,n,b),ds1,ms1);
        }
        }
        }
        }
        default: {ESLVal _v291 = _v240;
          
          return error(new ESLVal("TypeError",l1,new ESLVal("unknown type for flatten ").add(_v291)));
        }
      }
      }
    }
  });
  public static ESLVal actEqual = new ESLVal(new Function(new ESLVal("actEqual"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal exports1 = $args[0];
  ESLVal exports2 = $args[1];
  ESLVal handlers1 = $args[2];
  ESLVal handlers2 = $args[3];
  return forall.apply(new ESLVal(new Function(new ESLVal("fun1498"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal d1 = $args[0];
        return exists.apply(new ESLVal(new Function(new ESLVal("fun1499"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal d2 = $args[0];
              return equalDec.apply(d1,d2);
                }
              }),exports2);
          }
        }),exports1).and(forall.apply(new ESLVal(new Function(new ESLVal("fun1500"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal d1 = $args[0];
        return exists.apply(new ESLVal(new Function(new ESLVal("fun1501"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal d2 = $args[0];
              return equalDec.apply(d1,d2);
                }
              }),exports1);
          }
        }),exports2).and(forall.apply(new ESLVal(new Function(new ESLVal("fun1502"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal m1 = $args[0];
        return exists.apply(new ESLVal(new Function(new ESLVal("fun1503"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal m2 = $args[0];
              return equalMessage.apply(m1,m2);
                }
              }),handlers2);
          }
        }),handlers1).and(forall.apply(new ESLVal(new Function(new ESLVal("fun1504"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal m1 = $args[0];
        return exists.apply(new ESLVal(new Function(new ESLVal("fun1505"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal m2 = $args[0];
              return equalMessage.apply(m1,m2);
                }
              }),handlers1);
          }
        }),handlers2))));
    }
  });
  private static ESLVal actSubType = new ESLVal(new Function(new ESLVal("actSubType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal exports1 = $args[0];
  ESLVal exports2 = $args[1];
  ESLVal handlers1 = $args[2];
  ESLVal handlers2 = $args[3];
  return forall.apply(new ESLVal(new Function(new ESLVal("fun1506"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal d2 = $args[0];
        return exists.apply(new ESLVal(new Function(new ESLVal("fun1507"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal d1 = $args[0];
              return decSubType.apply(d1,d2);
                }
              }),exports1);
          }
        }),exports2).and(forall.apply(new ESLVal(new Function(new ESLVal("fun1508"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal m2 = $args[0];
        return exists.apply(new ESLVal(new Function(new ESLVal("fun1509"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal m1 = $args[0];
              return messSubType.apply(m1,m2);
                }
              }),handlers1);
          }
        }),handlers2));
    }
  });
  public static ESLVal equalDec = new ESLVal(new Function(new ESLVal("equalDec"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d1 = $args[0];
  ESLVal d2 = $args[1];
  {ESLVal _v239 = d1;
        ESLVal _v238 = d2;
        
        switch(_v239.termName) {
        case "Dec": {ESLVal $810 = _v239.termRef(0);
          ESLVal $809 = _v239.termRef(1);
          ESLVal $808 = _v239.termRef(2);
          ESLVal $807 = _v239.termRef(3);
          
          switch(_v238.termName) {
          case "Dec": {ESLVal $814 = _v238.termRef(0);
            ESLVal $813 = _v238.termRef(1);
            ESLVal $812 = _v238.termRef(2);
            ESLVal $811 = _v238.termRef(3);
            
            {ESLVal l1 = $810;
            
            {ESLVal n1 = $809;
            
            {ESLVal t1 = $808;
            
            {ESLVal st1 = $807;
            
            {ESLVal l2 = $814;
            
            {ESLVal n2 = $813;
            
            {ESLVal t2 = $812;
            
            {ESLVal st2 = $811;
            
            return n1.eql(n2).and(typeEqual.apply(t1,t2));
          }
          }
          }
          }
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(16583,16714)"));
        }
        }
        default: return error(new ESLVal("case error at Pos(16583,16714)"));
      }
      }
    }
  });
  private static ESLVal decSubType = new ESLVal(new Function(new ESLVal("decSubType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal d1 = $args[0];
  ESLVal d2 = $args[1];
  {ESLVal _v237 = d1;
        ESLVal _v236 = d2;
        
        switch(_v237.termName) {
        case "Dec": {ESLVal $802 = _v237.termRef(0);
          ESLVal $801 = _v237.termRef(1);
          ESLVal $800 = _v237.termRef(2);
          ESLVal $799 = _v237.termRef(3);
          
          switch(_v236.termName) {
          case "Dec": {ESLVal $806 = _v236.termRef(0);
            ESLVal $805 = _v236.termRef(1);
            ESLVal $804 = _v236.termRef(2);
            ESLVal $803 = _v236.termRef(3);
            
            {ESLVal l1 = $802;
            
            {ESLVal n1 = $801;
            
            {ESLVal t1 = $800;
            
            {ESLVal st1 = $799;
            
            {ESLVal l2 = $806;
            
            {ESLVal n2 = $805;
            
            {ESLVal t2 = $804;
            
            {ESLVal st2 = $803;
            
            return n1.eql(n2).and(subType.apply(t1,t2));
          }
          }
          }
          }
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(16758,16887)"));
        }
        }
        default: return error(new ESLVal("case error at Pos(16758,16887)"));
      }
      }
    }
  });
  public static ESLVal equalMessage = new ESLVal(new Function(new ESLVal("equalMessage"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal m1 = $args[0];
  ESLVal m2 = $args[1];
  {ESLVal _v235 = m1;
        ESLVal _v234 = m2;
        
        switch(_v235.termName) {
        case "MessageType": {ESLVal $796 = _v235.termRef(0);
          ESLVal $795 = _v235.termRef(1);
          
          switch(_v234.termName) {
          case "MessageType": {ESLVal $798 = _v234.termRef(0);
            ESLVal $797 = _v234.termRef(1);
            
            {ESLVal l1 = $796;
            
            {ESLVal ts1 = $795;
            
            {ESLVal l2 = $798;
            
            {ESLVal ts2 = $797;
            
            return typesEqual.apply(ts1,ts2);
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(16933,17043)"));
        }
        }
        default: return error(new ESLVal("case error at Pos(16933,17043)"));
      }
      }
    }
  });
  private static ESLVal messSubType = new ESLVal(new Function(new ESLVal("messSubType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal m1 = $args[0];
  ESLVal m2 = $args[1];
  {ESLVal _v233 = m1;
        ESLVal _v232 = m2;
        
        switch(_v233.termName) {
        case "MessageType": {ESLVal $792 = _v233.termRef(0);
          ESLVal $791 = _v233.termRef(1);
          
          switch(_v232.termName) {
          case "MessageType": {ESLVal $794 = _v232.termRef(0);
            ESLVal $793 = _v232.termRef(1);
            
            {ESLVal l1 = $792;
            
            {ESLVal ts1 = $791;
            
            {ESLVal l2 = $794;
            
            {ESLVal ts2 = $793;
            
            return subTypes.apply(ts1,ts2);
          }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(17088,17196)"));
        }
        }
        default: return error(new ESLVal("case error at Pos(17088,17196)"));
      }
      }
    }
  });
  public static ESLVal recordTypeEqual = new ESLVal(new Function(new ESLVal("recordTypeEqual"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal fields1 = $args[0];
  ESLVal fields2 = $args[1];
  return forall.apply(new ESLVal(new Function(new ESLVal("fun1510"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal t1 = $args[0];
        return exists.apply(new ESLVal(new Function(new ESLVal("fun1511"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal t2 = $args[0];
              return typeEqual.apply(t1,t2);
                }
              }),fields2);
          }
        }),fields1).and(forall.apply(new ESLVal(new Function(new ESLVal("fun1512"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal t1 = $args[0];
        return exists.apply(new ESLVal(new Function(new ESLVal("fun1513"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal t2 = $args[0];
              return typeEqual.apply(t1,t2);
                }
              }),fields1);
          }
        }),fields2));
    }
  });
  private static ESLVal recordSubType = new ESLVal(new Function(new ESLVal("recordSubType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal fields1 = $args[0];
  ESLVal fields2 = $args[1];
  return forall.apply(new ESLVal(new Function(new ESLVal("fun1514"),getSelf()) {
          public ESLVal apply(ESLVal... $args) {
            ESLVal t2 = $args[0];
        return exists.apply(new ESLVal(new Function(new ESLVal("fun1515"),getSelf()) {
                public ESLVal apply(ESLVal... $args) {
                  ESLVal t1 = $args[0];
              return subType.apply(t1,t2);
                }
              }),fields1);
          }
        }),fields2);
    }
  });
  public static ESLVal applyTypeFun = new ESLVal(new Function(new ESLVal("applyTypeFun"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal op = $args[1];
  ESLVal args = $args[2];
  {ESLVal _v231 = op;
        
        switch(_v231.termName) {
        case "RecType": {ESLVal $790 = _v231.termRef(0);
          ESLVal $789 = _v231.termRef(1);
          ESLVal $788 = _v231.termRef(2);
          
          {ESLVal lr = $790;
          
          {ESLVal n = $789;
          
          {ESLVal t = $788;
          
          return applyTypeFun.apply(l,unfoldType.apply(lr,n,t),args);
        }
        }
        }
        }
      case "TypeFun": {ESLVal $787 = _v231.termRef(0);
          ESLVal $786 = _v231.termRef(1);
          ESLVal $785 = _v231.termRef(2);
          
          {ESLVal _v288 = $787;
          
          {ESLVal names = $786;
          
          {ESLVal t = $785;
          
          if(length.apply(args).eql(length.apply(names)).boolVal)
          return substTypeEnv.apply(zipTypeEnv.apply(names,args),t);
          else
            return error(new ESLVal("TypeError",_v288,new ESLVal("type fun expects ").add(length.apply(names).add(new ESLVal(" args, but supplied with ").add(length.apply(args))))));
        }
        }
        }
        }
        default: {ESLVal _v289 = _v231;
          
          return error(new ESLVal("TypeError",l,new ESLVal("expecting a type function: ").add(_v289)));
        }
      }
      }
    }
  });
  public static ESLVal unfoldType = new ESLVal(new Function(new ESLVal("unfoldType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal l = $args[0];
  ESLVal n = $args[1];
  ESLVal t = $args[2];
  return substType.apply(new ESLVal("RecType",l,n,t),n,t);
    }
  });
  public static ESLVal forceType = new ESLVal(new Function(new ESLVal("forceType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  {ESLVal _v230 = t;
        
        switch(_v230.termName) {
        case "TypeClosure": {ESLVal $784 = _v230.termRef(0);
          
          {ESLVal f = $784;
          
          return forceType.apply(f.apply());
        }
        }
        default: {ESLVal _v287 = _v230;
          
          return _v287;
        }
      }
      }
    }
  });
  public static ESLVal typesEqual = new ESLVal(new Function(new ESLVal("typesEqual"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal ts1 = $args[0];
  ESLVal ts2 = $args[1];
  {ESLVal _v229 = ts1;
        ESLVal _v228 = ts2;
        
        if(_v229.isCons())
        {ESLVal $778 = _v229.head();
          ESLVal $779 = _v229.tail();
          
          if(_v228.isCons())
          {ESLVal $780 = _v228.head();
            ESLVal $781 = _v228.tail();
            
            {ESLVal t1 = $778;
            
            {ESLVal _v280 = $779;
            
            {ESLVal t2 = $780;
            
            {ESLVal _v281 = $781;
            
            return typeEqual.apply(t1,t2).and(typesEqual.apply(_v280,_v281));
          }
          }
          }
          }
          }
        else if(_v228.isNil())
          if(_v228.isCons())
            {ESLVal $776 = _v228.head();
              ESLVal $777 = _v228.tail();
              
              return error(new ESLVal("case error at Pos(18354,18564)"));
            }
          else if(_v228.isNil())
            {ESLVal _v282 = _v229;
              
              return $false;
            }
          else return error(new ESLVal("case error at Pos(18354,18564)"));
        else if(_v228.isCons())
            {ESLVal $776 = _v228.head();
              ESLVal $777 = _v228.tail();
              
              return error(new ESLVal("case error at Pos(18354,18564)"));
            }
          else if(_v228.isNil())
            {ESLVal _v283 = _v229;
              
              return $false;
            }
          else return error(new ESLVal("case error at Pos(18354,18564)"));
        }
      else if(_v229.isNil())
        if(_v228.isCons())
          {ESLVal $782 = _v228.head();
            ESLVal $783 = _v228.tail();
            
            {ESLVal _v284 = _v228;
            
            return $false;
          }
          }
        else if(_v228.isNil())
          return $true;
        else {ESLVal _v285 = _v228;
            
            return $false;
          }
      else if(_v228.isCons())
          {ESLVal $776 = _v228.head();
            ESLVal $777 = _v228.tail();
            
            return error(new ESLVal("case error at Pos(18354,18564)"));
          }
        else if(_v228.isNil())
          {ESLVal _v286 = _v229;
            
            return $false;
          }
        else return error(new ESLVal("case error at Pos(18354,18564)"));
      }
    }
  });
  public static ESLVal subTypes = new ESLVal(new Function(new ESLVal("subTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal ts1 = $args[0];
  ESLVal ts2 = $args[1];
  {ESLVal _v227 = ts1;
        ESLVal _v226 = ts2;
        
        if(_v227.isCons())
        {ESLVal $770 = _v227.head();
          ESLVal $771 = _v227.tail();
          
          if(_v226.isCons())
          {ESLVal $772 = _v226.head();
            ESLVal $773 = _v226.tail();
            
            {ESLVal t1 = $770;
            
            {ESLVal _v273 = $771;
            
            {ESLVal t2 = $772;
            
            {ESLVal _v274 = $773;
            
            return subType.apply(t1,t2).and(subTypes.apply(_v273,_v274));
          }
          }
          }
          }
          }
        else if(_v226.isNil())
          if(_v226.isCons())
            {ESLVal $768 = _v226.head();
              ESLVal $769 = _v226.tail();
              
              return error(new ESLVal("case error at Pos(18610,18816)"));
            }
          else if(_v226.isNil())
            {ESLVal _v275 = _v227;
              
              return $false;
            }
          else return error(new ESLVal("case error at Pos(18610,18816)"));
        else if(_v226.isCons())
            {ESLVal $768 = _v226.head();
              ESLVal $769 = _v226.tail();
              
              return error(new ESLVal("case error at Pos(18610,18816)"));
            }
          else if(_v226.isNil())
            {ESLVal _v276 = _v227;
              
              return $false;
            }
          else return error(new ESLVal("case error at Pos(18610,18816)"));
        }
      else if(_v227.isNil())
        if(_v226.isCons())
          {ESLVal $774 = _v226.head();
            ESLVal $775 = _v226.tail();
            
            {ESLVal _v277 = _v226;
            
            return $false;
          }
          }
        else if(_v226.isNil())
          return $true;
        else {ESLVal _v278 = _v226;
            
            return $false;
          }
      else if(_v226.isCons())
          {ESLVal $768 = _v226.head();
            ESLVal $769 = _v226.tail();
            
            return error(new ESLVal("case error at Pos(18610,18816)"));
          }
        else if(_v226.isNil())
          {ESLVal _v279 = _v227;
            
            return $false;
          }
        else return error(new ESLVal("case error at Pos(18610,18816)"));
      }
    }
  });
  public static ESLVal typeSetEqual = new ESLVal(new Function(new ESLVal("typeSetEqual"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal types1 = $args[0];
  ESLVal types2 = $args[1];
  return typeSubset.apply(types1,types2).and(typeSubset.apply(types2,types1));
    }
  });
  public static ESLVal typeSubset = new ESLVal(new Function(new ESLVal("typeSubset"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal sub = $args[0];
  ESLVal sup = $args[1];
  {ESLVal _v225 = sub;
        
        if(_v225.isCons())
        {ESLVal $766 = _v225.head();
          ESLVal $767 = _v225.tail();
          
          {ESLVal t = $766;
          
          {ESLVal _v272 = $767;
          
          return typeMember.apply(t,sup).and(typeSubset.apply(_v272,sup));
        }
        }
        }
      else if(_v225.isNil())
        return $true;
      else return error(new ESLVal("case error at Pos(18976,19082)"));
      }
    }
  });
  public static ESLVal typeMember = new ESLVal(new Function(new ESLVal("typeMember"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t = $args[0];
  ESLVal types = $args[1];
  {ESLVal _v224 = types;
        
        if(_v224.isCons())
        {ESLVal $764 = _v224.head();
          ESLVal $765 = _v224.tail();
          
          {ESLVal tt = $764;
          
          {ESLVal _v269 = $765;
          
          if(typeEqual.apply(t,tt).boolVal)
          return $true;
          else
            {ESLVal _v270 = $764;
              
              {ESLVal _v271 = $765;
              
              return typeMember.apply(t,_v271);
            }
            }
        }
        }
        }
      else if(_v224.isNil())
        return $false;
      else return error(new ESLVal("case error at Pos(19128,19275)"));
      }
    }
  });
  public static ESLVal substTypes = new ESLVal(new Function(new ESLVal("substTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal newType = $args[0];
  ESLVal n = $args[1];
  ESLVal oldTypes = $args[2];
  {ESLVal _v223 = oldTypes;
        
        if(_v223.isCons())
        {ESLVal $762 = _v223.head();
          ESLVal $763 = _v223.tail();
          
          {ESLVal t = $762;
          
          {ESLVal ts = $763;
          
          return substTypes.apply(newType,n,ts).cons(substType.apply(newType,n,t));
        }
        }
        }
      else if(_v223.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(19427,19547)"));
      }
    }
  });
  public static ESLVal substType = new ESLVal(new Function(new ESLVal("substType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal newType = $args[0];
  ESLVal n = $args[1];
  ESLVal oldType = $args[2];
  {ESLVal _v218 = oldType;
        
        switch(_v218.termName) {
        case "ApplyType": {ESLVal $761 = _v218.termRef(0);
          ESLVal $760 = _v218.termRef(1);
          ESLVal $759 = _v218.termRef(2);
          
          {ESLVal l = $761;
          
          {ESLVal m = $760;
          
          {ESLVal types = $759;
          
          if(m.eql(n).boolVal)
          return new ESLVal("ApplyTypeFun",l,newType,substTypes.apply(newType,n,types));
          else
            return new ESLVal("ApplyType",l,m,substTypes.apply(newType,n,types));
        }
        }
        }
        }
      case "ApplyTypeFun": {ESLVal $758 = _v218.termRef(0);
          ESLVal $757 = _v218.termRef(1);
          ESLVal $756 = _v218.termRef(2);
          
          {ESLVal l = $758;
          
          {ESLVal op = $757;
          
          {ESLVal args = $756;
          
          return new ESLVal("ApplyTypeFun",l,substType.apply(newType,n,op),substTypes.apply(newType,n,args));
        }
        }
        }
        }
      case "ActType": {ESLVal $755 = _v218.termRef(0);
          ESLVal $754 = _v218.termRef(1);
          ESLVal $753 = _v218.termRef(2);
          
          {ESLVal l = $755;
          
          {ESLVal decs = $754;
          
          {ESLVal handlers = $753;
          
          return new ESLVal("ActType",l,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v221 = $qualArg;
                
                {ESLVal d = _v221;
                
                return ESLVal.list(ESLVal.list(substDec.apply(newType,n,d)));
              }
              }
            }
          }).map(decs).flatten().flatten(),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v222 = $qualArg;
                
                {ESLVal m = _v222;
                
                return ESLVal.list(ESLVal.list(substMType.apply(newType,n,m)));
              }
              }
            }
          }).map(handlers).flatten().flatten());
        }
        }
        }
        }
      case "ArrayType": {ESLVal $752 = _v218.termRef(0);
          ESLVal $751 = _v218.termRef(1);
          
          {ESLVal l = $752;
          
          {ESLVal t = $751;
          
          return new ESLVal("ArrayType",l,substType.apply(newType,n,t));
        }
        }
        }
      case "BoolType": {ESLVal $750 = _v218.termRef(0);
          
          {ESLVal l = $750;
          
          return oldType;
        }
        }
      case "ExtendedAct": {ESLVal $749 = _v218.termRef(0);
          ESLVal $748 = _v218.termRef(1);
          ESLVal $747 = _v218.termRef(2);
          ESLVal $746 = _v218.termRef(3);
          
          {ESLVal l = $749;
          
          {ESLVal parent = $748;
          
          {ESLVal decs = $747;
          
          {ESLVal ms = $746;
          
          return new ESLVal("ExtendedAct",l,substType.apply(newType,n,parent),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v219 = $qualArg;
                
                {ESLVal d = _v219;
                
                return ESLVal.list(ESLVal.list(substDec.apply(newType,n,d)));
              }
              }
            }
          }).map(decs).flatten().flatten(),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v220 = $qualArg;
                
                {ESLVal m = _v220;
                
                return ESLVal.list(ESLVal.list(substMType.apply(newType,n,m)));
              }
              }
            }
          }).map(ms).flatten().flatten());
        }
        }
        }
        }
        }
      case "FloatType": {ESLVal $745 = _v218.termRef(0);
          
          {ESLVal l = $745;
          
          return oldType;
        }
        }
      case "ForallType": {ESLVal $744 = _v218.termRef(0);
          ESLVal $743 = _v218.termRef(1);
          ESLVal $742 = _v218.termRef(2);
          
          {ESLVal l = $744;
          
          {ESLVal ns = $743;
          
          {ESLVal t = $742;
          
          if(member.apply(n,ns).boolVal)
          return oldType;
          else
            return new ESLVal("ForallType",l,ns,substType.apply(newType,n,t));
        }
        }
        }
        }
      case "FunType": {ESLVal $741 = _v218.termRef(0);
          ESLVal $740 = _v218.termRef(1);
          ESLVal $739 = _v218.termRef(2);
          
          {ESLVal l = $741;
          
          {ESLVal d = $740;
          
          {ESLVal r = $739;
          
          return new ESLVal("FunType",l,substTypes.apply(newType,n,d),substType.apply(newType,n,r));
        }
        }
        }
        }
      case "IntType": {ESLVal $738 = _v218.termRef(0);
          
          {ESLVal l = $738;
          
          return oldType;
        }
        }
      case "ListType": {ESLVal $737 = _v218.termRef(0);
          ESLVal $736 = _v218.termRef(1);
          
          {ESLVal l = $737;
          
          {ESLVal t = $736;
          
          return new ESLVal("ListType",l,substType.apply(newType,n,t));
        }
        }
        }
      case "NullType": {ESLVal $735 = _v218.termRef(0);
          
          {ESLVal l = $735;
          
          return oldType;
        }
        }
      case "RecordType": {ESLVal $734 = _v218.termRef(0);
          ESLVal $733 = _v218.termRef(1);
          
          {ESLVal l = $734;
          
          {ESLVal fs = $733;
          
          return new ESLVal("RecordType",l,substTypes.apply(newType,n,fs));
        }
        }
        }
      case "RecType": {ESLVal $732 = _v218.termRef(0);
          ESLVal $731 = _v218.termRef(1);
          ESLVal $730 = _v218.termRef(2);
          
          {ESLVal l = $732;
          
          {ESLVal a = $731;
          
          {ESLVal t = $730;
          
          if(n.eql(a).boolVal)
          return oldType;
          else
            return new ESLVal("RecType",l,a,substType.apply(newType,n,t));
        }
        }
        }
        }
      case "StrType": {ESLVal $729 = _v218.termRef(0);
          
          {ESLVal l = $729;
          
          return oldType;
        }
        }
      case "TermType": {ESLVal $728 = _v218.termRef(0);
          ESLVal $727 = _v218.termRef(1);
          ESLVal $726 = _v218.termRef(2);
          
          {ESLVal l = $728;
          
          {ESLVal f = $727;
          
          {ESLVal ts = $726;
          
          return new ESLVal("TermType",l,f,substTypes.apply(newType,n,ts));
        }
        }
        }
        }
      case "TypeClosure": {ESLVal $725 = _v218.termRef(0);
          
          {ESLVal f = $725;
          
          return oldType;
        }
        }
      case "TypeFun": {ESLVal $724 = _v218.termRef(0);
          ESLVal $723 = _v218.termRef(1);
          ESLVal $722 = _v218.termRef(2);
          
          {ESLVal l = $724;
          
          {ESLVal ns = $723;
          
          {ESLVal t = $722;
          
          if(member.apply(n,ns).boolVal)
          return oldType;
          else
            return new ESLVal("TypeFun",l,ns,substType.apply(newType,n,t));
        }
        }
        }
        }
      case "UnfoldType": {ESLVal $721 = _v218.termRef(0);
          ESLVal $720 = _v218.termRef(1);
          
          {ESLVal l = $721;
          
          {ESLVal t = $720;
          
          return new ESLVal("UnfoldType",l,substType.apply(newType,n,t));
        }
        }
        }
      case "UnionType": {ESLVal $719 = _v218.termRef(0);
          ESLVal $718 = _v218.termRef(1);
          
          {ESLVal l = $719;
          
          {ESLVal ts = $718;
          
          return new ESLVal("UnionType",l,substTypes.apply(newType,n,ts));
        }
        }
        }
      case "VarType": {ESLVal $717 = _v218.termRef(0);
          ESLVal $716 = _v218.termRef(1);
          
          {ESLVal l = $717;
          
          {ESLVal name = $716;
          
          if(name.eql(n).boolVal)
          return newType;
          else
            return oldType;
        }
        }
        }
      case "VoidType": {ESLVal $715 = _v218.termRef(0);
          
          {ESLVal l = $715;
          
          return oldType;
        }
        }
      case "UnionRef": {ESLVal $714 = _v218.termRef(0);
          ESLVal $713 = _v218.termRef(1);
          ESLVal $712 = _v218.termRef(2);
          
          {ESLVal l = $714;
          
          {ESLVal t = $713;
          
          {ESLVal name = $712;
          
          return new ESLVal("UnionRef",l,substType.apply(newType,n,t),name);
        }
        }
        }
        }
        default: {ESLVal x = _v218;
          
          return error(x);
        }
      }
      }
    }
  });
  public static ESLVal substTypesEnv = new ESLVal(new Function(new ESLVal("substTypesEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal env = $args[0];
  ESLVal types = $args[1];
  {ESLVal _v217 = types;
        
        if(_v217.isCons())
        {ESLVal $710 = _v217.head();
          ESLVal $711 = _v217.tail();
          
          {ESLVal t = $710;
          
          {ESLVal ts = $711;
          
          return substTypesEnv.apply(env,ts).cons(substTypeEnv.apply(env,t));
        }
        }
        }
      else if(_v217.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(21802,21913)"));
      }
    }
  });
  public static ESLVal substTypeEnv = new ESLVal(new Function(new ESLVal("substTypeEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal env = $args[0];
  ESLVal oldType = $args[1];
  {ESLVal _v208 = oldType;
        
        switch(_v208.termName) {
        case "ApplyType": {ESLVal $709 = _v208.termRef(0);
          ESLVal $708 = _v208.termRef(1);
          ESLVal $707 = _v208.termRef(2);
          
          {ESLVal l = $709;
          
          {ESLVal n = $708;
          
          {ESLVal types = $707;
          
          {ESLVal op = lookupType.apply(n,env);
          
          if(op.eql($null).boolVal)
          return new ESLVal("ApplyType",l,n,substTypesEnv.apply(env,types));
          else
            return new ESLVal("ApplyTypeFun",l,op,substTypesEnv.apply(env,types));
        }
        }
        }
        }
        }
      case "ApplyTypeFun": {ESLVal $706 = _v208.termRef(0);
          ESLVal $705 = _v208.termRef(1);
          ESLVal $704 = _v208.termRef(2);
          
          {ESLVal l = $706;
          
          {ESLVal op = $705;
          
          {ESLVal args = $704;
          
          return new ESLVal("ApplyTypeFun",l,substTypeEnv.apply(env,op),substTypesEnv.apply(env,args));
        }
        }
        }
        }
      case "ActType": {ESLVal $703 = _v208.termRef(0);
          ESLVal $702 = _v208.termRef(1);
          ESLVal $701 = _v208.termRef(2);
          
          {ESLVal l = $703;
          
          {ESLVal decs = $702;
          
          {ESLVal handlers = $701;
          
          return new ESLVal("ActType",l,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v215 = $qualArg;
                
                {ESLVal d = _v215;
                
                return ESLVal.list(ESLVal.list(substDecEnv.apply(env,d)));
              }
              }
            }
          }).map(decs).flatten().flatten(),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v216 = $qualArg;
                
                {ESLVal m = _v216;
                
                return ESLVal.list(ESLVal.list(substMTypeEnv.apply(env,m)));
              }
              }
            }
          }).map(handlers).flatten().flatten());
        }
        }
        }
        }
      case "ExtendedAct": {ESLVal $700 = _v208.termRef(0);
          ESLVal $699 = _v208.termRef(1);
          ESLVal $698 = _v208.termRef(2);
          ESLVal $697 = _v208.termRef(3);
          
          {ESLVal l = $700;
          
          {ESLVal parent = $699;
          
          {ESLVal decs = $698;
          
          {ESLVal handlers = $697;
          
          return new ESLVal("ExtendedAct",l,substTypeEnv.apply(env,parent),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v213 = $qualArg;
                
                {ESLVal d = _v213;
                
                return ESLVal.list(ESLVal.list(substDecEnv.apply(env,d)));
              }
              }
            }
          }).map(decs).flatten().flatten(),new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v214 = $qualArg;
                
                {ESLVal m = _v214;
                
                return ESLVal.list(ESLVal.list(substMTypeEnv.apply(env,m)));
              }
              }
            }
          }).map(handlers).flatten().flatten());
        }
        }
        }
        }
        }
      case "ArrayType": {ESLVal $696 = _v208.termRef(0);
          ESLVal $695 = _v208.termRef(1);
          
          {ESLVal l = $696;
          
          {ESLVal t = $695;
          
          return new ESLVal("ArrayType",l,substTypeEnv.apply(env,t));
        }
        }
        }
      case "BoolType": {ESLVal $694 = _v208.termRef(0);
          
          {ESLVal l = $694;
          
          return oldType;
        }
        }
      case "FloatType": {ESLVal $693 = _v208.termRef(0);
          
          {ESLVal l = $693;
          
          return oldType;
        }
        }
      case "ForallType": {ESLVal $692 = _v208.termRef(0);
          ESLVal $691 = _v208.termRef(1);
          ESLVal $690 = _v208.termRef(2);
          
          {ESLVal l = $692;
          
          {ESLVal ns = $691;
          
          {ESLVal t = $690;
          
          return new ESLVal("ForallType",l,ns,substTypeEnv.apply(removeFromDom.apply(env,ns),t));
        }
        }
        }
        }
      case "FieldType": {ESLVal $689 = _v208.termRef(0);
          ESLVal $688 = _v208.termRef(1);
          ESLVal $687 = _v208.termRef(2);
          
          {ESLVal l = $689;
          
          {ESLVal n = $688;
          
          {ESLVal t = $687;
          
          return new ESLVal("FieldType",l,n,substTypeEnv.apply(env,t));
        }
        }
        }
        }
      case "FunType": {ESLVal $686 = _v208.termRef(0);
          ESLVal $685 = _v208.termRef(1);
          ESLVal $684 = _v208.termRef(2);
          
          {ESLVal l = $686;
          
          {ESLVal d = $685;
          
          {ESLVal r = $684;
          
          return new ESLVal("FunType",l,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v212 = $qualArg;
                
                {ESLVal t = _v212;
                
                return ESLVal.list(ESLVal.list(substTypeEnv.apply(env,t)));
              }
              }
            }
          }).map(d).flatten().flatten(),substTypeEnv.apply(env,r));
        }
        }
        }
        }
      case "TaggedFunType": {ESLVal $683 = _v208.termRef(0);
          ESLVal $682 = _v208.termRef(1);
          ESLVal $681 = _v208.termRef(2);
          ESLVal $680 = _v208.termRef(3);
          
          {ESLVal l = $683;
          
          {ESLVal d = $682;
          
          {ESLVal p = $681;
          
          {ESLVal r = $680;
          
          return new ESLVal("FunType",l,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v211 = $qualArg;
                
                {ESLVal t = _v211;
                
                return ESLVal.list(ESLVal.list(substTypeEnv.apply(env,t)));
              }
              }
            }
          }).map(d).flatten().flatten(),substTypeEnv.apply(env,r));
        }
        }
        }
        }
        }
      case "IntType": {ESLVal $679 = _v208.termRef(0);
          
          {ESLVal l = $679;
          
          return oldType;
        }
        }
      case "ListType": {ESLVal $678 = _v208.termRef(0);
          ESLVal $677 = _v208.termRef(1);
          
          {ESLVal l = $678;
          
          {ESLVal t = $677;
          
          return new ESLVal("ListType",l,substTypeEnv.apply(env,t));
        }
        }
        }
      case "SetType": {ESLVal $676 = _v208.termRef(0);
          ESLVal $675 = _v208.termRef(1);
          
          {ESLVal l = $676;
          
          {ESLVal t = $675;
          
          return new ESLVal("SetType",l,substTypeEnv.apply(env,t));
        }
        }
        }
      case "BagType": {ESLVal $674 = _v208.termRef(0);
          ESLVal $673 = _v208.termRef(1);
          
          {ESLVal l = $674;
          
          {ESLVal t = $673;
          
          return new ESLVal("BagType",l,substTypeEnv.apply(env,t));
        }
        }
        }
      case "NullType": {ESLVal $672 = _v208.termRef(0);
          
          {ESLVal l = $672;
          
          return oldType;
        }
        }
      case "RecType": {ESLVal $671 = _v208.termRef(0);
          ESLVal $670 = _v208.termRef(1);
          ESLVal $669 = _v208.termRef(2);
          
          {ESLVal l = $671;
          
          {ESLVal a = $670;
          
          {ESLVal t = $669;
          
          return new ESLVal("RecType",l,a,substTypeEnv.apply(removeFromDom.apply(env,ESLVal.list(a)),t));
        }
        }
        }
        }
      case "RecordType": {ESLVal $668 = _v208.termRef(0);
          ESLVal $667 = _v208.termRef(1);
          
          {ESLVal l = $668;
          
          {ESLVal fs = $667;
          
          return new ESLVal("RecordType",l,substTypesEnv.apply(env,fs));
        }
        }
        }
      case "StrType": {ESLVal $666 = _v208.termRef(0);
          
          {ESLVal l = $666;
          
          return oldType;
        }
        }
      case "TermType": {ESLVal $665 = _v208.termRef(0);
          ESLVal $664 = _v208.termRef(1);
          ESLVal $663 = _v208.termRef(2);
          
          {ESLVal l = $665;
          
          {ESLVal f = $664;
          
          {ESLVal ts = $663;
          
          return new ESLVal("TermType",l,f,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v210 = $qualArg;
                
                {ESLVal t = _v210;
                
                return ESLVal.list(ESLVal.list(substTypeEnv.apply(env,t)));
              }
              }
            }
          }).map(ts).flatten().flatten());
        }
        }
        }
        }
      case "TypeClosure": {ESLVal $662 = _v208.termRef(0);
          
          {ESLVal f = $662;
          
          return oldType;
        }
        }
      case "TypeFun": {ESLVal $661 = _v208.termRef(0);
          ESLVal $660 = _v208.termRef(1);
          ESLVal $659 = _v208.termRef(2);
          
          {ESLVal l = $661;
          
          {ESLVal ns = $660;
          
          {ESLVal t = $659;
          
          return new ESLVal("TypeFun",l,ns,substTypeEnv.apply(removeFromDom.apply(env,ns),t));
        }
        }
        }
        }
      case "UnfoldType": {ESLVal $658 = _v208.termRef(0);
          ESLVal $657 = _v208.termRef(1);
          
          {ESLVal l = $658;
          
          {ESLVal t = $657;
          
          return new ESLVal("UnfoldType",l,substTypeEnv.apply(env,t));
        }
        }
        }
      case "UnionType": {ESLVal $656 = _v208.termRef(0);
          ESLVal $655 = _v208.termRef(1);
          
          {ESLVal l = $656;
          
          {ESLVal ts = $655;
          
          return new ESLVal("UnionType",l,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v209 = $qualArg;
                
                {ESLVal t = _v209;
                
                return ESLVal.list(ESLVal.list(substTypeEnv.apply(env,t)));
              }
              }
            }
          }).map(ts).flatten().flatten());
        }
        }
        }
      case "VarType": {ESLVal $654 = _v208.termRef(0);
          ESLVal $653 = _v208.termRef(1);
          
          {ESLVal l = $654;
          
          {ESLVal name = $653;
          
          if(member.apply(name,typeEnvDom.apply(env)).boolVal)
          return lookupType.apply(name,env);
          else
            return oldType;
        }
        }
        }
      case "VoidType": {ESLVal $652 = _v208.termRef(0);
          
          {ESLVal l = $652;
          
          return oldType;
        }
        }
      case "UnionRef": {ESLVal $651 = _v208.termRef(0);
          ESLVal $650 = _v208.termRef(1);
          ESLVal $649 = _v208.termRef(2);
          
          {ESLVal l = $651;
          
          {ESLVal t = $650;
          
          {ESLVal name = $649;
          
          return new ESLVal("UnionRef",l,substTypeEnv.apply(env,t),name);
        }
        }
        }
        }
        default: {ESLVal x = _v208;
          
          return error(oldType);
        }
      }
      }
    }
  });
  public static ESLVal zipTypeEnv = new ESLVal(new Function(new ESLVal("zipTypeEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal ns = $args[0];
  ESLVal ts = $args[1];
  {ESLVal _v207 = ns;
        ESLVal _v206 = ts;
        
        if(_v207.isCons())
        {ESLVal $643 = _v207.head();
          ESLVal $644 = _v207.tail();
          
          if(_v206.isCons())
          {ESLVal $645 = _v206.head();
            ESLVal $646 = _v206.tail();
            
            {ESLVal n = $643;
            
            {ESLVal _v267 = $644;
            
            {ESLVal t = $645;
            
            {ESLVal _v268 = $646;
            
            return zipTypeEnv.apply(_v267,_v268).cons(new ESLVal("Map",n,t));
          }
          }
          }
          }
          }
        else if(_v206.isNil())
          return error(new ESLVal("case error at Pos(24504,24625)"));
        else return error(new ESLVal("case error at Pos(24504,24625)"));
        }
      else if(_v207.isNil())
        if(_v206.isCons())
          {ESLVal $647 = _v206.head();
            ESLVal $648 = _v206.tail();
            
            return error(new ESLVal("case error at Pos(24504,24625)"));
          }
        else if(_v206.isNil())
          return $nil;
        else return error(new ESLVal("case error at Pos(24504,24625)"));
      else return error(new ESLVal("case error at Pos(24504,24625)"));
      }
    }
  });
  public static ESLVal lookupType = new ESLVal(new Function(new ESLVal("lookupType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal name = $args[0];
  ESLVal env = $args[1];
  {ESLVal _v205 = env;
        
        if(_v205.isCons())
        {ESLVal $639 = _v205.head();
          ESLVal $640 = _v205.tail();
          
          switch($639.termName) {
          case "Map": {ESLVal $642 = $639.termRef(0);
            ESLVal $641 = $639.termRef(1);
            
            {ESLVal n = $642;
            
            {ESLVal t = $641;
            
            {ESLVal e = $640;
            
            if(n.eql(name).boolVal)
            return t;
            else
              {ESLVal m = $639;
                
                {ESLVal _v266 = $640;
                
                return lookupType.apply(name,_v266);
              }
              }
          }
          }
          }
          }
          default: {ESLVal m = $639;
            
            {ESLVal e = $640;
            
            return lookupType.apply(name,e);
          }
          }
        }
        }
      else if(_v205.isNil())
        return $null;
      else return error(new ESLVal("case error at Pos(24671,24808)"));
      }
    }
  });
  public static ESLVal typeEnvDom = new ESLVal(new Function(new ESLVal("typeEnvDom"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  {ESLVal _v204 = e;
        
        if(_v204.isCons())
        {ESLVal $635 = _v204.head();
          ESLVal $636 = _v204.tail();
          
          switch($635.termName) {
          case "Map": {ESLVal $638 = $635.termRef(0);
            ESLVal $637 = $635.termRef(1);
            
            {ESLVal n = $638;
            
            {ESLVal t = $637;
            
            {ESLVal x = $636;
            
            return typeEnvDom.apply(x).cons(n);
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(24843,24932)"));
        }
        }
      else if(_v204.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(24843,24932)"));
      }
    }
  });
  public static ESLVal removeFromDom = new ESLVal(new Function(new ESLVal("removeFromDom"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  ESLVal ns = $args[1];
  {ESLVal _v203 = e;
        
        if(_v203.isCons())
        {ESLVal $631 = _v203.head();
          ESLVal $632 = _v203.tail();
          
          switch($631.termName) {
          case "Map": {ESLVal $634 = $631.termRef(0);
            ESLVal $633 = $631.termRef(1);
            
            {ESLVal n = $634;
            
            {ESLVal t = $633;
            
            {ESLVal _v262 = $632;
            
            if(member.apply(n,ns).boolVal)
            return removeFromDom.apply(_v262,ns);
            else
              {ESLVal _v263 = $634;
                
                {ESLVal _v264 = $633;
                
                {ESLVal _v265 = $632;
                
                return removeFromDom.apply(_v265,ns).cons(new ESLVal("Map",_v263,_v264));
              }
              }
              }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(24979,25161)"));
        }
        }
      else if(_v203.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(24979,25161)"));
      }
    }
  });
  public static ESLVal restrictTypeEnv = new ESLVal(new Function(new ESLVal("restrictTypeEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  ESLVal ns = $args[1];
  {ESLVal _v202 = e;
        
        if(_v202.isCons())
        {ESLVal $627 = _v202.head();
          ESLVal $628 = _v202.tail();
          
          switch($627.termName) {
          case "Map": {ESLVal $630 = $627.termRef(0);
            ESLVal $629 = $627.termRef(1);
            
            {ESLVal n = $630;
            
            {ESLVal t = $629;
            
            {ESLVal _v258 = $628;
            
            if(member.apply(n,ns).not().boolVal)
            return restrictTypeEnv.apply(_v258,ns);
            else
              {ESLVal _v259 = $630;
                
                {ESLVal _v260 = $629;
                
                {ESLVal _v261 = $628;
                
                return restrictTypeEnv.apply(_v261,ns).cons(new ESLVal("Map",_v259,_v260));
              }
              }
              }
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(25210,25401)"));
        }
        }
      else if(_v202.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(25210,25401)"));
      }
    }
  });
  public static ESLVal typeEnvRan = new ESLVal(new Function(new ESLVal("typeEnvRan"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal e = $args[0];
  {ESLVal _v201 = e;
        
        if(_v201.isCons())
        {ESLVal $623 = _v201.head();
          ESLVal $624 = _v201.tail();
          
          switch($623.termName) {
          case "Map": {ESLVal $626 = $623.termRef(0);
            ESLVal $625 = $623.termRef(1);
            
            {ESLVal n = $626;
            
            {ESLVal t = $625;
            
            {ESLVal x = $624;
            
            return typeEnvRan.apply(x).cons(t);
          }
          }
          }
          }
          default: return error(new ESLVal("case error at Pos(25437,25528)"));
        }
        }
      else if(_v201.isNil())
        return $nil;
      else return error(new ESLVal("case error at Pos(25437,25528)"));
      }
    }
  });
  public static ESLVal allEqualTypes = new ESLVal(new Function(new ESLVal("allEqualTypes"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal t1 = $args[0];
  ESLVal ts = $args[1];
  {ESLVal _v200 = ts;
        
        if(_v200.isCons())
        {ESLVal $621 = _v200.head();
          ESLVal $622 = _v200.tail();
          
          {ESLVal t2 = $621;
          
          {ESLVal _v255 = $622;
          
          if(typeEqual.apply(t1,t2).boolVal)
          return allEqualTypes.apply(t1,_v255);
          else
            {ESLVal _v256 = _v200;
              
              return $false;
            }
        }
        }
        }
      else if(_v200.isNil())
        return $true;
      else {ESLVal _v257 = _v200;
          
          return $false;
        }
      }
    }
  });
  public static ESLVal substDec = new ESLVal(new Function(new ESLVal("substDec"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal newType = $args[0];
  ESLVal n = $args[1];
  ESLVal d = $args[2];
  {ESLVal _v199 = d;
        
        switch(_v199.termName) {
        case "Dec": {ESLVal $620 = _v199.termRef(0);
          ESLVal $619 = _v199.termRef(1);
          ESLVal $618 = _v199.termRef(2);
          ESLVal $617 = _v199.termRef(3);
          
          {ESLVal l = $620;
          
          {ESLVal name = $619;
          
          {ESLVal t = $618;
          
          {ESLVal st = $617;
          
          return new ESLVal("Dec",l,name,substType.apply(newType,n,t),st);
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(25761,25858)"));
      }
      }
    }
  });
  public static ESLVal substDecEnv = new ESLVal(new Function(new ESLVal("substDecEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal env = $args[0];
  ESLVal d = $args[1];
  {ESLVal _v198 = d;
        
        switch(_v198.termName) {
        case "Dec": {ESLVal $616 = _v198.termRef(0);
          ESLVal $615 = _v198.termRef(1);
          ESLVal $614 = _v198.termRef(2);
          ESLVal $613 = _v198.termRef(3);
          
          {ESLVal l = $616;
          
          {ESLVal name = $615;
          
          {ESLVal t = $614;
          
          {ESLVal st = $613;
          
          return new ESLVal("Dec",l,name,substTypeEnv.apply(env,t),st);
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(25903,25997)"));
      }
      }
    }
  });
  public static ESLVal substMType = new ESLVal(new Function(new ESLVal("substMType"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal newType = $args[0];
  ESLVal n = $args[1];
  ESLVal m = $args[2];
  {ESLVal _v196 = m;
        
        switch(_v196.termName) {
        case "MessageType": {ESLVal $612 = _v196.termRef(0);
          ESLVal $611 = _v196.termRef(1);
          
          {ESLVal l = $612;
          
          {ESLVal ts = $611;
          
          return new ESLVal("MessageType",l,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v197 = $qualArg;
                
                {ESLVal t = _v197;
                
                return ESLVal.list(ESLVal.list(substType.apply(newType,n,t)));
              }
              }
            }
          }).map(ts).flatten().flatten());
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(26057,26165)"));
      }
      }
    }
  });
  public static ESLVal substMTypeEnv = new ESLVal(new Function(new ESLVal("substMTypeEnv"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal env = $args[0];
  ESLVal m = $args[1];
  {ESLVal _v194 = m;
        
        switch(_v194.termName) {
        case "MessageType": {ESLVal $610 = _v194.termRef(0);
          ESLVal $609 = _v194.termRef(1);
          
          {ESLVal l = $610;
          
          {ESLVal ts = $609;
          
          return new ESLVal("MessageType",l,new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v195 = $qualArg;
                
                {ESLVal t = _v195;
                
                return ESLVal.list(ESLVal.list(substTypeEnv.apply(env,t)));
              }
              }
            }
          }).map(ts).flatten().flatten());
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(26217,26322)"));
      }
      }
    }
  });
  public static ESLVal patternNames = new ESLVal(new Function(new ESLVal("patternNames"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal x = $args[0];
  {ESLVal _v191 = x;
        
        switch(_v191.termName) {
        case "PVar": {ESLVal $608 = _v191.termRef(0);
          ESLVal $607 = _v191.termRef(1);
          ESLVal $606 = _v191.termRef(2);
          
          {ESLVal v0 = $608;
          
          {ESLVal v1 = $607;
          
          {ESLVal v2 = $606;
          
          return ESLVal.list(v1);
        }
        }
        }
        }
      case "PTerm": {ESLVal $605 = _v191.termRef(0);
          ESLVal $604 = _v191.termRef(1);
          ESLVal $603 = _v191.termRef(2);
          ESLVal $602 = _v191.termRef(3);
          
          {ESLVal v0 = $605;
          
          {ESLVal v1 = $604;
          
          {ESLVal v2 = $603;
          
          {ESLVal v3 = $602;
          
          return new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal $qualArg = $args[0];
          {ESLVal _v192 = $qualArg;
                
                {ESLVal p = _v192;
                
                return ESLVal.list(new ESLVal(new Function(new ESLVal("qual"),getSelf()) {
                  public ESLVal apply(ESLVal... $args) {
                    ESLVal _v254 = $args[0];
                {ESLVal _v193 = _v254;
                      
                      {ESLVal n = _v193;
                      
                      return ESLVal.list(ESLVal.list(n));
                    }
                    }
                  }
                }).map(patternNames.apply(p)).flatten().flatten());
              }
              }
            }
          }).map(v3).flatten().flatten();
        }
        }
        }
        }
        }
      case "PApplyType": {ESLVal $601 = _v191.termRef(0);
          ESLVal $600 = _v191.termRef(1);
          ESLVal $599 = _v191.termRef(2);
          
          {ESLVal v0 = $601;
          
          {ESLVal v1 = $600;
          
          {ESLVal v2 = $599;
          
          return patternNames.apply(v1);
        }
        }
        }
        }
      case "PNil": {ESLVal $598 = _v191.termRef(0);
          
          {ESLVal v0 = $598;
          
          return ESLVal.list();
        }
        }
      case "PNull": {ESLVal $597 = _v191.termRef(0);
          
          {ESLVal v0 = $597;
          
          return ESLVal.list();
        }
        }
      case "PInt": {ESLVal $596 = _v191.termRef(0);
          ESLVal $595 = _v191.termRef(1);
          
          {ESLVal v0 = $596;
          
          {ESLVal v1 = $595;
          
          return ESLVal.list();
        }
        }
        }
      case "PStr": {ESLVal $594 = _v191.termRef(0);
          ESLVal $593 = _v191.termRef(1);
          
          {ESLVal v0 = $594;
          
          {ESLVal v1 = $593;
          
          return ESLVal.list();
        }
        }
        }
      case "PBool": {ESLVal $592 = _v191.termRef(0);
          ESLVal $591 = _v191.termRef(1);
          
          {ESLVal v0 = $592;
          
          {ESLVal v1 = $591;
          
          return ESLVal.list();
        }
        }
        }
      case "PCons": {ESLVal $590 = _v191.termRef(0);
          ESLVal $589 = _v191.termRef(1);
          ESLVal $588 = _v191.termRef(2);
          
          {ESLVal v0 = $590;
          
          {ESLVal v1 = $589;
          
          {ESLVal v2 = $588;
          
          return patternNames.apply(v1).add(patternNames.apply(v2));
        }
        }
        }
        }
      case "PBagCons": {ESLVal $587 = _v191.termRef(0);
          ESLVal $586 = _v191.termRef(1);
          ESLVal $585 = _v191.termRef(2);
          
          {ESLVal v0 = $587;
          
          {ESLVal v1 = $586;
          
          {ESLVal v2 = $585;
          
          return patternNames.apply(v1).add(patternNames.apply(v2));
        }
        }
        }
        }
      case "PEmptyBag": {ESLVal $584 = _v191.termRef(0);
          
          {ESLVal v0 = $584;
          
          return ESLVal.list();
        }
        }
      case "PSetCons": {ESLVal $583 = _v191.termRef(0);
          ESLVal $582 = _v191.termRef(1);
          ESLVal $581 = _v191.termRef(2);
          
          {ESLVal v0 = $583;
          
          {ESLVal v1 = $582;
          
          {ESLVal v2 = $581;
          
          return patternNames.apply(v1).add(patternNames.apply(v2));
        }
        }
        }
        }
      case "PEmptySet": {ESLVal $580 = _v191.termRef(0);
          
          {ESLVal v0 = $580;
          
          return ESLVal.list();
        }
        }
        default: return error(new ESLVal("case error at Pos(26653,27352)"));
      }
      }
    }
  });
  public static ESLVal isBinding = new ESLVal(new Function(new ESLVal("isBinding"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal b = $args[0];
  {ESLVal _v190 = b;
        
        switch(_v190.termName) {
        case "Binding": {ESLVal $579 = _v190.termRef(0);
          ESLVal $578 = _v190.termRef(1);
          ESLVal $577 = _v190.termRef(2);
          ESLVal $576 = _v190.termRef(3);
          ESLVal $575 = _v190.termRef(4);
          
          {ESLVal l = $579;
          
          {ESLVal n = $578;
          
          {ESLVal t = $577;
          
          {ESLVal st = $576;
          
          {ESLVal e = $575;
          
          return $true;
        }
        }
        }
        }
        }
        }
        default: {ESLVal _v253 = _v190;
          
          return $false;
        }
      }
      }
    }
  });
  public static ESLVal isFunBind = new ESLVal(new Function(new ESLVal("isFunBind"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal b = $args[0];
  {ESLVal _v189 = b;
        
        switch(_v189.termName) {
        case "FunBind": {ESLVal $574 = _v189.termRef(0);
          ESLVal $573 = _v189.termRef(1);
          ESLVal $572 = _v189.termRef(2);
          ESLVal $571 = _v189.termRef(3);
          ESLVal $570 = _v189.termRef(4);
          ESLVal $569 = _v189.termRef(5);
          ESLVal $568 = _v189.termRef(6);
          
          {ESLVal l = $574;
          
          {ESLVal n = $573;
          
          {ESLVal args = $572;
          
          {ESLVal t = $571;
          
          {ESLVal st = $570;
          
          {ESLVal g = $569;
          
          {ESLVal e = $568;
          
          return $true;
        }
        }
        }
        }
        }
        }
        }
        }
        default: {ESLVal _v252 = _v189;
          
          return $false;
        }
      }
      }
    }
  });
  public static ESLVal bindingName = new ESLVal(new Function(new ESLVal("bindingName"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal b = $args[0];
  {ESLVal _v188 = b;
        
        switch(_v188.termName) {
        case "TypeBind": {ESLVal $567 = _v188.termRef(0);
          ESLVal $566 = _v188.termRef(1);
          ESLVal $565 = _v188.termRef(2);
          ESLVal $564 = _v188.termRef(3);
          
          {ESLVal v0 = $567;
          
          {ESLVal v1 = $566;
          
          {ESLVal v2 = $565;
          
          {ESLVal v3 = $564;
          
          return v1;
        }
        }
        }
        }
        }
      case "CnstrBind": {ESLVal $563 = _v188.termRef(0);
          ESLVal $562 = _v188.termRef(1);
          ESLVal $561 = _v188.termRef(2);
          ESLVal $560 = _v188.termRef(3);
          
          {ESLVal v0 = $563;
          
          {ESLVal v1 = $562;
          
          {ESLVal v2 = $561;
          
          {ESLVal v3 = $560;
          
          return v1;
        }
        }
        }
        }
        }
      case "FunBind": {ESLVal $559 = _v188.termRef(0);
          ESLVal $558 = _v188.termRef(1);
          ESLVal $557 = _v188.termRef(2);
          ESLVal $556 = _v188.termRef(3);
          ESLVal $555 = _v188.termRef(4);
          ESLVal $554 = _v188.termRef(5);
          ESLVal $553 = _v188.termRef(6);
          
          {ESLVal v0 = $559;
          
          {ESLVal v1 = $558;
          
          {ESLVal v2 = $557;
          
          {ESLVal v3 = $556;
          
          {ESLVal v4 = $555;
          
          {ESLVal v5 = $554;
          
          {ESLVal v6 = $553;
          
          return v1;
        }
        }
        }
        }
        }
        }
        }
        }
      case "Binding": {ESLVal $552 = _v188.termRef(0);
          ESLVal $551 = _v188.termRef(1);
          ESLVal $550 = _v188.termRef(2);
          ESLVal $549 = _v188.termRef(3);
          ESLVal $548 = _v188.termRef(4);
          
          {ESLVal v0 = $552;
          
          {ESLVal v1 = $551;
          
          {ESLVal v2 = $550;
          
          {ESLVal v3 = $549;
          
          {ESLVal v4 = $548;
          
          return v1;
        }
        }
        }
        }
        }
        }
      case "DataBind": {ESLVal $547 = _v188.termRef(0);
          ESLVal $546 = _v188.termRef(1);
          ESLVal $545 = _v188.termRef(2);
          ESLVal $544 = _v188.termRef(3);
          
          {ESLVal v0 = $547;
          
          {ESLVal v1 = $546;
          
          {ESLVal v2 = $545;
          
          {ESLVal v3 = $544;
          
          return v1;
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(27853,28174)"));
      }
      }
    }
  });
  public static ESLVal bindingLoc = new ESLVal(new Function(new ESLVal("bindingLoc"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal b = $args[0];
  {ESLVal _v187 = b;
        
        switch(_v187.termName) {
        case "TypeBind": {ESLVal $543 = _v187.termRef(0);
          ESLVal $542 = _v187.termRef(1);
          ESLVal $541 = _v187.termRef(2);
          ESLVal $540 = _v187.termRef(3);
          
          {ESLVal v0 = $543;
          
          {ESLVal v1 = $542;
          
          {ESLVal v2 = $541;
          
          {ESLVal v3 = $540;
          
          return v0;
        }
        }
        }
        }
        }
      case "CnstrBind": {ESLVal $539 = _v187.termRef(0);
          ESLVal $538 = _v187.termRef(1);
          ESLVal $537 = _v187.termRef(2);
          ESLVal $536 = _v187.termRef(3);
          
          {ESLVal v0 = $539;
          
          {ESLVal v1 = $538;
          
          {ESLVal v2 = $537;
          
          {ESLVal v3 = $536;
          
          return v0;
        }
        }
        }
        }
        }
      case "FunBind": {ESLVal $535 = _v187.termRef(0);
          ESLVal $534 = _v187.termRef(1);
          ESLVal $533 = _v187.termRef(2);
          ESLVal $532 = _v187.termRef(3);
          ESLVal $531 = _v187.termRef(4);
          ESLVal $530 = _v187.termRef(5);
          ESLVal $529 = _v187.termRef(6);
          
          {ESLVal v0 = $535;
          
          {ESLVal v1 = $534;
          
          {ESLVal v2 = $533;
          
          {ESLVal v3 = $532;
          
          {ESLVal v4 = $531;
          
          {ESLVal v5 = $530;
          
          {ESLVal v6 = $529;
          
          return v0;
        }
        }
        }
        }
        }
        }
        }
        }
      case "Binding": {ESLVal $528 = _v187.termRef(0);
          ESLVal $527 = _v187.termRef(1);
          ESLVal $526 = _v187.termRef(2);
          ESLVal $525 = _v187.termRef(3);
          ESLVal $524 = _v187.termRef(4);
          
          {ESLVal v0 = $528;
          
          {ESLVal v1 = $527;
          
          {ESLVal v2 = $526;
          
          {ESLVal v3 = $525;
          
          {ESLVal v4 = $524;
          
          return v0;
        }
        }
        }
        }
        }
        }
      case "DataBind": {ESLVal $523 = _v187.termRef(0);
          ESLVal $522 = _v187.termRef(1);
          ESLVal $521 = _v187.termRef(2);
          ESLVal $520 = _v187.termRef(3);
          
          {ESLVal v0 = $523;
          
          {ESLVal v1 = $522;
          
          {ESLVal v2 = $521;
          
          {ESLVal v3 = $520;
          
          return v0;
        }
        }
        }
        }
        }
        default: return error(new ESLVal("case error at Pos(28206,28527)"));
      }
      }
    }
  });
public static void main(String[] args) {
  }
}