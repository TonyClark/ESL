package esl.compiler;
import esl.lib.*;
import static esl.lib.Lib.*;
// import static esl.Lists.*;
import java.util.function.Supplier;
public class Strings {
  public static ESLVal getSelf() { return $null; }
  private static ESLVal pathSeparator = new ESLVal(47);
  public static ESLVal javaString = new ESLVal(new Function(new ESLVal("javaString"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal s = $args[0];
  LetRec letrec = new LetRec() {
        ESLVal f = new ESLVal(new Function(new ESLVal("f"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal l = $args[0];
          {ESLVal _v640 = l;
                
                if(_v640.isCons())
                {ESLVal $1184 = _v640.head();
                  ESLVal $1185 = _v640.tail();
                  
                  switch($1184.intVal) {
                  case 34: {ESLVal _v649 = $1185;
                    
                    return ESLVal.list(new ESLVal(92),new ESLVal(34)).add(f.apply(_v649));
                  }
                case 10: {ESLVal _v648 = $1185;
                    
                    return ESLVal.list(new ESLVal(92),new ESLVal(110)).add(f.apply(_v648));
                  }
                  default: {ESLVal c = $1184;
                    
                    {ESLVal _v650 = $1185;
                    
                    return f.apply(_v650).cons(c);
                  }
                  }
                }
                }
              else if(_v640.isNil())
                return $nil;
              else return error(new ESLVal("case error at Pos(251,429)"));
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "f": return f;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal f = letrec.get("f");
      
        return f.apply(s.ref("explode")).ref("implode");
      
    }
  });
  public static ESLVal replaceChar = new ESLVal(new Function(new ESLVal("replaceChar"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal s = $args[0];
  ESLVal change = $args[1];
  ESLVal insert = $args[2];
  LetRec letrec = new LetRec() {
        ESLVal replace = new ESLVal(new Function(new ESLVal("replace"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal chars = $args[0];
          {ESLVal _v639 = chars;
                
                if(_v639.isCons())
                {ESLVal $1182 = _v639.head();
                  ESLVal $1183 = _v639.tail();
                  
                  {ESLVal c = $1182;
                  
                  {ESLVal _v645 = $1183;
                  
                  if(c.eql(change).boolVal)
                  return insert.ref("explode").add(replace.apply(_v645));
                  else
                    {ESLVal _v646 = $1182;
                      
                      {ESLVal _v647 = $1183;
                      
                      return replace.apply(_v647).cons(_v646);
                    }
                    }
                }
                }
                }
              else if(_v639.isNil())
                return $nil;
              else return error(new ESLVal("case error at Pos(560,738)"));
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "replace": return replace;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal replace = letrec.get("replace");
      
        return replace.apply(s.ref("explode")).ref("implode");
      
    }
  });
  public static ESLVal splitBy = new ESLVal(new Function(new ESLVal("splitBy"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal c = $args[0];
  ESLVal s = $args[1];
  LetRec letrec = new LetRec() {
        ESLVal isNotChar = new ESLVal(new Function(new ESLVal("isNotChar"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal i = $args[0];
          return c.neql(i);
            }
          });
        ESLVal maybeDropOne = new ESLVal(new Function(new ESLVal("maybeDropOne"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal l = $args[0];
          {ESLVal _v638 = l;
                
                if(_v638.isCons())
                {ESLVal $1180 = _v638.head();
                  ESLVal $1181 = _v638.tail();
                  
                  {ESLVal h = $1180;
                  
                  {ESLVal t = $1181;
                  
                  return t;
                }
                }
                }
              else if(_v638.isNil())
                return l;
              else return error(new ESLVal("case error at Pos(890,936)"));
              }
            }
          });
        ESLVal splitter = new ESLVal(new Function(new ESLVal("splitter"),getSelf()) {
            public ESLVal apply(ESLVal... $args) {
              ESLVal chars = $args[0];
          {ESLVal _v637 = chars;
                
                if(_v637.isCons())
                {ESLVal $1178 = _v637.head();
                  ESLVal $1179 = _v637.tail();
                  
                  {ESLVal _v643 = _v637;
                  
                  return splitter.apply(maybeDropOne.apply(dropWhile.apply(isNotChar,_v643))).cons(takeWhile.apply(isNotChar,_v643).ref("implode"));
                }
                }
              else if(_v637.isNil())
                return $nil;
              else {ESLVal _v644 = _v637;
                  
                  return splitter.apply(maybeDropOne.apply(dropWhile.apply(isNotChar,_v644))).cons(takeWhile.apply(isNotChar,_v644).ref("implode"));
                }
              }
            }
          });
        
        public ESLVal get(String name) {
          switch(name) {
            case "isNotChar": return isNotChar;
            
            case "maybeDropOne": return maybeDropOne;
            
            case "splitter": return splitter;
            
            default: throw new Error("cannot find letrec binding");
          }
          }
        };
      ESLVal isNotChar = letrec.get("isNotChar");
      
      ESLVal maybeDropOne = letrec.get("maybeDropOne");
      
      ESLVal splitter = letrec.get("splitter");
      
        return splitter.apply(s.ref("explode"));
      
    }
  });
  public static ESLVal joinBy = new ESLVal(new Function(new ESLVal("joinBy"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal c = $args[0];
  ESLVal ss = $args[1];
  {ESLVal _v636 = ss;
        
        if(_v636.isCons())
        {ESLVal $1174 = _v636.head();
          ESLVal $1175 = _v636.tail();
          
          if($1175.isCons())
          {ESLVal $1176 = $1175.head();
            ESLVal $1177 = $1175.tail();
            
            {ESLVal s = $1174;
            
            {ESLVal _v641 = $1175;
            
            return s.add(ESLVal.list(c).ref("implode").add(joinBy.apply(c,_v641)));
          }
          }
          }
        else if($1175.isNil())
          {ESLVal s = $1174;
            
            return s;
          }
        else {ESLVal s = $1174;
            
            {ESLVal _v642 = $1175;
            
            return s.add(ESLVal.list(c).ref("implode").add(joinBy.apply(c,_v642)));
          }
          }
        }
      else if(_v636.isNil())
        return new ESLVal("");
      else return error(new ESLVal("case error at Pos(1223,1330)"));
      }
    }
  });
  private static ESLVal isLower = new ESLVal(new Function(new ESLVal("isLower"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal c = $args[0];
  return c.eql(new ESLVal(97)).or(c.gre(new ESLVal(97))).and(c.eql(new ESLVal(122)).or(c.less(new ESLVal(122))));
    }
  });
  private static ESLVal upcase = new ESLVal(new Function(new ESLVal("upcase"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal c = $args[0];
  if(isLower.apply(c).boolVal)
        return c.sub(new ESLVal(97)).add(new ESLVal(65));
        else
          return c;
    }
  });
  private static ESLVal upcaseInitial = new ESLVal(new Function(new ESLVal("upcaseInitial"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal s = $args[0];
  return ESLVal.list(upcase.apply(head.apply(s.ref("explode")))).add(tail.apply(s.ref("explode"))).ref("implode");
    }
  });
  public static ESLVal toPath = new ESLVal(new Function(new ESLVal("toPath"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  return splitBy.apply(pathSeparator,p);
    }
  });
  public static ESLVal pathToJavaPackage = new ESLVal(new Function(new ESLVal("pathToJavaPackage"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal names = butlast.apply(p);
        
        return joinBy.apply(new ESLVal(46),names);
      }
    }
  });
  public static ESLVal pathToJavaClassName = new ESLVal(new Function(new ESLVal("pathToJavaClassName"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      ESLVal p = $args[0];
  {ESLVal name = head.apply(splitBy.apply(new ESLVal(46),last.apply(p)));
        
        return upcaseInitial.apply(name);
      }
    }
  });
  private static ESLVal main = new ESLVal(new Function(new ESLVal("main"),getSelf()) {
    public ESLVal apply(ESLVal... $args) {
      return new ESLVal(new BehaviourAdapter(true,getSelf(),new ESLVal("main")) {
          
          public ESLVal handle(ESLVal $m) {{ESLVal _v635 = $m;
            
            return error(new ESLVal("case error at Pos(0,0)"));
          }}
          public ESLVal get(String name) {
            switch(name) {
              
              default: throw new Error("ref illegal " + self + "." + name);
            }
          }
        public void handleTime(ESLVal $t) {
          {ESLVal n = $t;
            
            if($true.boolVal)
            {print.apply(new ESLVal("\"spam\" plap\nplop"));
            print.apply(replaceChar.apply(new ESLVal("start\"plap\"end"),new ESLVal(34),new ESLVal("\"")));
            stopAll.apply();}
            else
              {}
          }
        }
        public ESLVal init() {
            return $null;
          }
        });
    }
  });
public static void main(String[] args) {
  }
}